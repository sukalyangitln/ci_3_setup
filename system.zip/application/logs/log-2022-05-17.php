<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-17 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:46:07 --> No URI present. Default controller set.
DEBUG - 2022-05-17 06:46:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 06:46:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'gvprods_gvv3'@'localhost' (using password: YES) /home3/esalesei/new1.esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-05-17 06:46:07 --> Unable to connect to the database
ERROR - 2022-05-17 06:46:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/new1.esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/new1.esalestrix.in/system/core/Common.php 570
DEBUG - 2022-05-17 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:54:39 --> No URI present. Default controller set.
DEBUG - 2022-05-17 06:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:24:39 --> Total execution time: 0.0615
DEBUG - 2022-05-17 06:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:56:11 --> No URI present. Default controller set.
DEBUG - 2022-05-17 06:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:26:11 --> Total execution time: 0.0262
DEBUG - 2022-05-17 07:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:09:12 --> No URI present. Default controller set.
DEBUG - 2022-05-17 07:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:39:12 --> Total execution time: 0.1197
DEBUG - 2022-05-17 07:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:24:35 --> No URI present. Default controller set.
DEBUG - 2022-05-17 07:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:54:35 --> Total execution time: 0.0957
DEBUG - 2022-05-17 07:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:28:47 --> No URI present. Default controller set.
DEBUG - 2022-05-17 07:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:58:47 --> Total execution time: 0.0493
DEBUG - 2022-05-17 07:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:32:49 --> No URI present. Default controller set.
DEBUG - 2022-05-17 07:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:02:49 --> Total execution time: 0.0943
DEBUG - 2022-05-17 07:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:33:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 07:33:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:33:54 --> No URI present. Default controller set.
DEBUG - 2022-05-17 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:03:54 --> Total execution time: 0.0229
DEBUG - 2022-05-17 07:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:47:50 --> No URI present. Default controller set.
DEBUG - 2022-05-17 07:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:17:50 --> Total execution time: 0.0445
DEBUG - 2022-05-17 08:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:05:19 --> No URI present. Default controller set.
DEBUG - 2022-05-17 08:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:35:19 --> Total execution time: 0.0514
DEBUG - 2022-05-17 09:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:26:54 --> No URI present. Default controller set.
DEBUG - 2022-05-17 09:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 19:56:54 --> Total execution time: 0.1069
DEBUG - 2022-05-17 09:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:27:05 --> No URI present. Default controller set.
DEBUG - 2022-05-17 09:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 19:57:05 --> Total execution time: 0.0159
DEBUG - 2022-05-17 09:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:27:06 --> No URI present. Default controller set.
DEBUG - 2022-05-17 09:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 19:57:06 --> Total execution time: 0.0145
DEBUG - 2022-05-17 09:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:27:13 --> No URI present. Default controller set.
DEBUG - 2022-05-17 09:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 19:57:13 --> Total execution time: 0.0153
DEBUG - 2022-05-17 09:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:29:15 --> No URI present. Default controller set.
DEBUG - 2022-05-17 09:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 19:59:15 --> Total execution time: 0.0130
DEBUG - 2022-05-17 09:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:32:24 --> No URI present. Default controller set.
DEBUG - 2022-05-17 09:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:02:24 --> Total execution time: 0.0176
DEBUG - 2022-05-17 09:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:39:49 --> No URI present. Default controller set.
DEBUG - 2022-05-17 09:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:09:49 --> Total execution time: 0.0441
DEBUG - 2022-05-17 09:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:46:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 09:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:46:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-17 20:16:59 --> Severity: Notice --> Trying to get property 'ID' of non-object /home3/esalesei/new1.esalestrix.in/application/helpers/project_helper.php 8
DEBUG - 2022-05-17 20:16:59 --> Total execution time: 40.2921
DEBUG - 2022-05-17 09:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:49:40 --> No URI present. Default controller set.
DEBUG - 2022-05-17 09:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:19:40 --> Total execution time: 0.0460
DEBUG - 2022-05-17 09:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:49:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 09:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:23:05 --> Total execution time: 38.8091
DEBUG - 2022-05-17 09:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 09:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 09:53:59 --> Total execution time: 0.0342
DEBUG - 2022-05-17 09:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 09:54:18 --> Total execution time: 0.0344
DEBUG - 2022-05-17 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:24:39 --> Total execution time: 0.0395
DEBUG - 2022-05-17 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:24:46 --> Total execution time: 3.2495
DEBUG - 2022-05-17 09:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:26:42 --> Total execution time: 0.0382
DEBUG - 2022-05-17 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:26:52 --> Total execution time: 0.0492
DEBUG - 2022-05-17 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:26:56 --> Total execution time: 0.0373
DEBUG - 2022-05-17 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:27:02 --> Total execution time: 0.0365
DEBUG - 2022-05-17 09:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:27:14 --> Total execution time: 0.0282
DEBUG - 2022-05-17 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:57:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:57:18 --> UTF-8 Support Enabled
ERROR - 2022-05-17 09:57:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-17 09:57:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:57:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:57:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:57:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-17 09:57:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:18 --> UTF-8 Support Enabled
ERROR - 2022-05-17 09:57:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:57:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:57:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:27:27 --> Total execution time: 0.0354
DEBUG - 2022-05-17 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:27:52 --> Total execution time: 0.0509
DEBUG - 2022-05-17 09:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:27:54 --> Total execution time: 0.0363
DEBUG - 2022-05-17 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:27:56 --> Total execution time: 0.0389
DEBUG - 2022-05-17 09:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:28:08 --> Total execution time: 0.0422
DEBUG - 2022-05-17 09:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:28:13 --> Total execution time: 0.0403
DEBUG - 2022-05-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:59:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-17 09:59:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-17 09:59:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-17 09:59:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-17 09:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 09:59:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 10:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 10:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 20:38:04 --> Total execution time: 0.0804
DEBUG - 2022-05-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 10:08:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-17 10:08:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 10:08:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 10:08:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 10:08:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 10:08:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 10:08:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-17 10:08:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-17 10:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:46:51 --> No URI present. Default controller set.
DEBUG - 2022-05-17 10:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 10:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 10:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 10:46:51 --> No URI present. Default controller set.
DEBUG - 2022-05-17 10:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 21:16:51 --> Total execution time: 0.0795
DEBUG - 2022-05-17 10:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 21:16:51 --> Total execution time: 0.0365
DEBUG - 2022-05-17 11:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:28:44 --> No URI present. Default controller set.
DEBUG - 2022-05-17 11:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 21:58:44 --> Total execution time: 0.1118
DEBUG - 2022-05-17 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 11:28:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:55:08 --> No URI present. Default controller set.
DEBUG - 2022-05-17 11:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:25:08 --> Total execution time: 0.0483
DEBUG - 2022-05-17 11:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:55:36 --> No URI present. Default controller set.
DEBUG - 2022-05-17 11:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:25:36 --> Total execution time: 0.0199
DEBUG - 2022-05-17 11:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:55:44 --> No URI present. Default controller set.
DEBUG - 2022-05-17 11:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:25:44 --> Total execution time: 0.0200
DEBUG - 2022-05-17 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:55:47 --> No URI present. Default controller set.
DEBUG - 2022-05-17 11:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:25:47 --> Total execution time: 0.0190
DEBUG - 2022-05-17 11:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:56:14 --> No URI present. Default controller set.
DEBUG - 2022-05-17 11:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:26:14 --> Total execution time: 0.0164
DEBUG - 2022-05-17 11:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:56:16 --> No URI present. Default controller set.
DEBUG - 2022-05-17 11:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:26:16 --> Total execution time: 0.0161
DEBUG - 2022-05-17 11:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:26:23 --> Total execution time: 0.0146
DEBUG - 2022-05-17 11:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 11:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:26:32 --> Total execution time: 0.0134
DEBUG - 2022-05-17 11:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:26:42 --> Total execution time: 0.0242
DEBUG - 2022-05-17 11:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:26:47 --> Total execution time: 0.0233
DEBUG - 2022-05-17 11:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:27:57 --> Total execution time: 0.2443
DEBUG - 2022-05-17 11:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:28:14 --> Total execution time: 0.2241
DEBUG - 2022-05-17 11:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 11:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 11:59:16 --> Total execution time: 0.0175
DEBUG - 2022-05-17 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 11:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 11:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 22:29:46 --> Total execution time: 0.0159
DEBUG - 2022-05-17 12:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 12:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 12:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 23:07:47 --> Total execution time: 0.1706
DEBUG - 2022-05-17 14:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:24:32 --> No URI present. Default controller set.
DEBUG - 2022-05-17 14:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:25:05 --> No URI present. Default controller set.
DEBUG - 2022-05-17 14:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:26:50 --> Total execution time: 0.0170
DEBUG - 2022-05-17 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:26:52 --> Total execution time: 0.0133
DEBUG - 2022-05-17 14:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:26:52 --> Total execution time: 0.0475
DEBUG - 2022-05-17 14:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:27:11 --> Total execution time: 0.0153
DEBUG - 2022-05-17 14:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:27:15 --> Total execution time: 0.0135
DEBUG - 2022-05-17 14:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:27:17 --> Total execution time: 0.0128
DEBUG - 2022-05-17 14:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:27:20 --> Total execution time: 0.0134
DEBUG - 2022-05-17 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:27:24 --> Total execution time: 0.0153
DEBUG - 2022-05-17 14:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:27:27 --> Total execution time: 0.0139
DEBUG - 2022-05-17 14:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:50 --> Total execution time: 0.0218
DEBUG - 2022-05-17 14:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:52 --> Total execution time: 0.0172
DEBUG - 2022-05-17 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:53 --> Total execution time: 0.0157
DEBUG - 2022-05-17 14:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:53 --> Total execution time: 0.0204
DEBUG - 2022-05-17 14:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:54 --> Total execution time: 0.0153
DEBUG - 2022-05-17 14:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:54 --> Total execution time: 0.0195
DEBUG - 2022-05-17 14:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:55 --> Total execution time: 0.0156
DEBUG - 2022-05-17 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:56 --> Total execution time: 0.0157
DEBUG - 2022-05-17 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:56 --> Total execution time: 0.0158
DEBUG - 2022-05-17 14:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:57 --> Total execution time: 0.0162
DEBUG - 2022-05-17 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:28:58 --> Total execution time: 0.0155
DEBUG - 2022-05-17 14:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:29:24 --> Total execution time: 0.0100
DEBUG - 2022-05-17 14:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:29:24 --> Total execution time: 0.0104
DEBUG - 2022-05-17 14:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:29:25 --> Total execution time: 0.0254
DEBUG - 2022-05-17 14:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:29:27 --> Total execution time: 0.0075
DEBUG - 2022-05-17 14:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:29:27 --> Total execution time: 0.0093
DEBUG - 2022-05-17 14:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:29:55 --> No URI present. Default controller set.
DEBUG - 2022-05-17 14:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:30:02 --> Total execution time: 0.0146
DEBUG - 2022-05-17 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:30:06 --> Total execution time: 0.0161
DEBUG - 2022-05-17 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:30:06 --> Total execution time: 0.0088
DEBUG - 2022-05-17 14:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:01 --> Total execution time: 0.0187
DEBUG - 2022-05-17 14:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:01 --> Total execution time: 0.0206
DEBUG - 2022-05-17 14:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:02 --> Total execution time: 0.0181
DEBUG - 2022-05-17 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:06 --> Total execution time: 0.0132
DEBUG - 2022-05-17 14:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:07 --> Total execution time: 0.0131
DEBUG - 2022-05-17 14:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:07 --> Total execution time: 0.0128
DEBUG - 2022-05-17 14:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:18 --> Total execution time: 0.0135
DEBUG - 2022-05-17 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:19 --> Total execution time: 0.0355
DEBUG - 2022-05-17 14:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:19 --> Total execution time: 0.0134
DEBUG - 2022-05-17 14:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:23 --> Total execution time: 0.0142
DEBUG - 2022-05-17 14:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:46 --> Total execution time: 0.0139
DEBUG - 2022-05-17 14:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:47 --> Total execution time: 0.0159
DEBUG - 2022-05-17 14:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:31:47 --> Total execution time: 0.0161
DEBUG - 2022-05-17 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:34:17 --> No URI present. Default controller set.
DEBUG - 2022-05-17 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:07 --> Total execution time: 0.0136
DEBUG - 2022-05-17 14:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:08 --> Total execution time: 0.0164
DEBUG - 2022-05-17 14:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:08 --> Total execution time: 0.0149
DEBUG - 2022-05-17 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:11 --> Total execution time: 0.0139
DEBUG - 2022-05-17 14:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:13 --> Total execution time: 0.0188
DEBUG - 2022-05-17 14:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:13 --> Total execution time: 0.0207
DEBUG - 2022-05-17 14:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:22 --> Total execution time: 0.0134
DEBUG - 2022-05-17 14:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:36:38 --> Total execution time: 0.0080
DEBUG - 2022-05-17 14:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:38:51 --> Total execution time: 0.0179
DEBUG - 2022-05-17 14:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:38:52 --> Total execution time: 0.0183
DEBUG - 2022-05-17 14:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:40:08 --> Total execution time: 0.0164
DEBUG - 2022-05-17 14:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:40:09 --> Total execution time: 0.0268
DEBUG - 2022-05-17 14:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:40:09 --> Total execution time: 0.0242
DEBUG - 2022-05-17 14:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:40:16 --> Total execution time: 0.0128
DEBUG - 2022-05-17 14:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:42:16 --> Total execution time: 0.0121
DEBUG - 2022-05-17 14:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:42:17 --> Total execution time: 0.0125
DEBUG - 2022-05-17 14:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:49:03 --> Total execution time: 0.0912
DEBUG - 2022-05-17 14:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:49:04 --> Total execution time: 0.0137
DEBUG - 2022-05-17 14:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:49:10 --> Total execution time: 0.0191
DEBUG - 2022-05-17 14:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:49:11 --> Total execution time: 0.0192
DEBUG - 2022-05-17 14:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:49:11 --> Total execution time: 0.0246
DEBUG - 2022-05-17 14:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 14:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 14:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 14:50:44 --> Total execution time: 0.0141
DEBUG - 2022-05-17 15:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:02:32 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:24 --> Total execution time: 0.0158
DEBUG - 2022-05-17 15:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:25 --> Total execution time: 0.0315
DEBUG - 2022-05-17 15:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:25 --> Total execution time: 0.0324
DEBUG - 2022-05-17 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:40 --> Total execution time: 0.0164
DEBUG - 2022-05-17 15:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:40 --> Total execution time: 0.0256
DEBUG - 2022-05-17 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:40 --> Total execution time: 0.0217
DEBUG - 2022-05-17 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:40 --> Total execution time: 0.0173
DEBUG - 2022-05-17 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:40 --> Total execution time: 0.0177
DEBUG - 2022-05-17 15:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:40 --> Total execution time: 0.0167
DEBUG - 2022-05-17 15:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:41 --> Total execution time: 0.0167
DEBUG - 2022-05-17 15:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:41 --> Total execution time: 0.0175
DEBUG - 2022-05-17 15:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:41 --> Total execution time: 0.0173
DEBUG - 2022-05-17 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:42 --> Total execution time: 0.0166
DEBUG - 2022-05-17 15:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:42 --> Total execution time: 0.0244
DEBUG - 2022-05-17 15:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:43 --> Total execution time: 0.0165
DEBUG - 2022-05-17 15:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:43 --> Total execution time: 0.0165
DEBUG - 2022-05-17 15:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:04:44 --> Total execution time: 0.0180
DEBUG - 2022-05-17 15:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:05:51 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:27:15 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 15:27:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 15:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:28:32 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:34:46 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:38:53 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:38:55 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:42:09 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:42:18 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 15:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 15:53:01 --> No URI present. Default controller set.
DEBUG - 2022-05-17 15:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 15:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:48:48 --> No URI present. Default controller set.
DEBUG - 2022-05-17 16:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:52:35 --> No URI present. Default controller set.
DEBUG - 2022-05-17 16:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:53:05 --> No URI present. Default controller set.
DEBUG - 2022-05-17 16:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 16:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 16:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 16:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:20 --> Total execution time: 0.0213
DEBUG - 2022-05-17 17:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:21 --> Total execution time: 0.0290
DEBUG - 2022-05-17 17:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:21 --> Total execution time: 0.0221
DEBUG - 2022-05-17 17:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:25 --> Total execution time: 0.0134
DEBUG - 2022-05-17 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:28 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:29 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:29 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:29 --> Total execution time: 0.0163
DEBUG - 2022-05-17 17:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:30 --> Total execution time: 0.0165
DEBUG - 2022-05-17 17:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:30 --> Total execution time: 0.0161
DEBUG - 2022-05-17 17:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:30 --> Total execution time: 0.0150
DEBUG - 2022-05-17 17:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:31 --> Total execution time: 0.0167
DEBUG - 2022-05-17 17:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:31 --> Total execution time: 0.0168
DEBUG - 2022-05-17 17:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:31 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:36 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:37 --> Total execution time: 0.0166
DEBUG - 2022-05-17 17:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:39 --> Total execution time: 0.0165
DEBUG - 2022-05-17 17:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:40 --> Total execution time: 0.0172
DEBUG - 2022-05-17 17:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:42 --> Total execution time: 0.0207
DEBUG - 2022-05-17 17:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:43 --> Total execution time: 0.0162
DEBUG - 2022-05-17 17:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:44 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:45 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:47 --> Total execution time: 0.0196
DEBUG - 2022-05-17 17:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:47 --> Total execution time: 0.0197
DEBUG - 2022-05-17 17:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:50 --> Total execution time: 0.0161
DEBUG - 2022-05-17 17:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:50 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:52 --> Total execution time: 0.0166
DEBUG - 2022-05-17 17:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:53 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:54 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:55 --> Total execution time: 0.0351
DEBUG - 2022-05-17 17:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:56 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:56 --> Total execution time: 0.0162
DEBUG - 2022-05-17 17:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:57 --> Total execution time: 0.0162
DEBUG - 2022-05-17 17:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:11:58 --> Total execution time: 0.0160
DEBUG - 2022-05-17 17:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:00 --> Total execution time: 0.0162
DEBUG - 2022-05-17 17:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:01 --> Total execution time: 0.0180
DEBUG - 2022-05-17 17:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:01 --> Total execution time: 0.0172
DEBUG - 2022-05-17 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:02 --> Total execution time: 0.0173
DEBUG - 2022-05-17 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:02 --> Total execution time: 0.0190
DEBUG - 2022-05-17 17:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:02 --> Total execution time: 0.0175
DEBUG - 2022-05-17 17:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:05 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:05 --> Total execution time: 0.0299
DEBUG - 2022-05-17 17:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:07 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:07 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:08 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:08 --> Total execution time: 0.0192
DEBUG - 2022-05-17 17:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:09 --> Total execution time: 0.0164
DEBUG - 2022-05-17 17:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:09 --> Total execution time: 0.0180
DEBUG - 2022-05-17 17:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:11 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:13 --> Total execution time: 0.0169
DEBUG - 2022-05-17 17:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-17 17:12:13 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_generate_id` = 'Esalestrix 👆'
DEBUG - 2022-05-17 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:14 --> Total execution time: 0.0166
DEBUG - 2022-05-17 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:14 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:14 --> Total execution time: 0.0163
DEBUG - 2022-05-17 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:14 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:14 --> Total execution time: 0.0208
DEBUG - 2022-05-17 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:14 --> Total execution time: 0.0153
DEBUG - 2022-05-17 17:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:15 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:16 --> Total execution time: 0.0155
DEBUG - 2022-05-17 17:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:16 --> Total execution time: 0.0169
DEBUG - 2022-05-17 17:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:17 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:17 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:17 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:21 --> Total execution time: 0.0171
DEBUG - 2022-05-17 17:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:23 --> Total execution time: 0.0161
DEBUG - 2022-05-17 17:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:23 --> Total execution time: 0.0225
DEBUG - 2022-05-17 17:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:25 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:25 --> Total execution time: 0.0185
DEBUG - 2022-05-17 17:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:25 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:26 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:26 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:27 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:28 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:28 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:28 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:32 --> Total execution time: 0.0179
DEBUG - 2022-05-17 17:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:32 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:33 --> Total execution time: 0.0199
DEBUG - 2022-05-17 17:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:35 --> Total execution time: 0.0244
DEBUG - 2022-05-17 17:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:35 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:36 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:37 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:37 --> Total execution time: 0.0167
DEBUG - 2022-05-17 17:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:37 --> Total execution time: 0.0187
DEBUG - 2022-05-17 17:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:38 --> Total execution time: 0.0160
DEBUG - 2022-05-17 17:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:38 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:42 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:42 --> Total execution time: 0.0372
DEBUG - 2022-05-17 17:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:45 --> Total execution time: 0.0195
DEBUG - 2022-05-17 17:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:45 --> Total execution time: 0.0184
DEBUG - 2022-05-17 17:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:47 --> Total execution time: 0.0160
DEBUG - 2022-05-17 17:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:47 --> Total execution time: 0.0155
DEBUG - 2022-05-17 17:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:48 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:48 --> Total execution time: 0.0222
DEBUG - 2022-05-17 17:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:48 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:49 --> Total execution time: 0.0164
DEBUG - 2022-05-17 17:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:49 --> Total execution time: 0.0206
DEBUG - 2022-05-17 17:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:49 --> Total execution time: 0.0169
DEBUG - 2022-05-17 17:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:50 --> Total execution time: 0.0180
DEBUG - 2022-05-17 17:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:51 --> Total execution time: 0.0215
DEBUG - 2022-05-17 17:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:52 --> Total execution time: 0.0269
DEBUG - 2022-05-17 17:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:54 --> Total execution time: 0.0162
DEBUG - 2022-05-17 17:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:55 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:55 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:55 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:56 --> Total execution time: 0.0173
DEBUG - 2022-05-17 17:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:56 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:56 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:57 --> Total execution time: 0.0167
DEBUG - 2022-05-17 17:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:57 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:12:58 --> Total execution time: 0.0163
DEBUG - 2022-05-17 17:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:00 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:01 --> Total execution time: 0.0100
DEBUG - 2022-05-17 17:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:02 --> Total execution time: 0.0099
DEBUG - 2022-05-17 17:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:03 --> Total execution time: 0.0105
DEBUG - 2022-05-17 17:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:03 --> Total execution time: 0.0131
DEBUG - 2022-05-17 17:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:04 --> Total execution time: 0.0096
DEBUG - 2022-05-17 17:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:05 --> Total execution time: 0.0121
DEBUG - 2022-05-17 17:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:06 --> Total execution time: 0.0107
DEBUG - 2022-05-17 17:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:06 --> Total execution time: 0.0102
DEBUG - 2022-05-17 17:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:08 --> Total execution time: 0.0096
DEBUG - 2022-05-17 17:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:08 --> Total execution time: 0.0098
DEBUG - 2022-05-17 17:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:09 --> Total execution time: 0.0172
DEBUG - 2022-05-17 17:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:09 --> Total execution time: 0.0101
DEBUG - 2022-05-17 17:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:10 --> Total execution time: 0.0123
DEBUG - 2022-05-17 17:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:10 --> Total execution time: 0.0111
DEBUG - 2022-05-17 17:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:11 --> Total execution time: 0.0125
DEBUG - 2022-05-17 17:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:11 --> Total execution time: 0.0117
DEBUG - 2022-05-17 17:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:13 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:13 --> Total execution time: 0.0164
DEBUG - 2022-05-17 17:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:13 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:14 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:14 --> Total execution time: 0.0162
DEBUG - 2022-05-17 17:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:15 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:16 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:17 --> Total execution time: 0.0168
DEBUG - 2022-05-17 17:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:20 --> Total execution time: 0.0155
DEBUG - 2022-05-17 17:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:20 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:22 --> Total execution time: 0.0160
DEBUG - 2022-05-17 17:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:22 --> Total execution time: 0.0178
DEBUG - 2022-05-17 17:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:22 --> Total execution time: 0.0270
DEBUG - 2022-05-17 17:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:22 --> Total execution time: 0.0162
DEBUG - 2022-05-17 17:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:24 --> Total execution time: 0.0171
DEBUG - 2022-05-17 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:26 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:26 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:27 --> Total execution time: 0.0253
DEBUG - 2022-05-17 17:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:28 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:28 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:30 --> Total execution time: 0.0196
DEBUG - 2022-05-17 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:30 --> Total execution time: 0.0153
DEBUG - 2022-05-17 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:30 --> Total execution time: 0.0194
DEBUG - 2022-05-17 17:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:31 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:32 --> Total execution time: 0.0169
DEBUG - 2022-05-17 17:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:32 --> Total execution time: 0.0162
DEBUG - 2022-05-17 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:33 --> Total execution time: 0.0206
DEBUG - 2022-05-17 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:33 --> Total execution time: 0.0192
DEBUG - 2022-05-17 17:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:34 --> Total execution time: 0.0164
DEBUG - 2022-05-17 17:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:35 --> Total execution time: 0.0172
DEBUG - 2022-05-17 17:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:35 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:35 --> Total execution time: 0.0164
DEBUG - 2022-05-17 17:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:37 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:37 --> Total execution time: 0.0278
DEBUG - 2022-05-17 17:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:37 --> Total execution time: 0.0180
DEBUG - 2022-05-17 17:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:38 --> Total execution time: 0.0154
DEBUG - 2022-05-17 17:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:40 --> Total execution time: 0.0187
DEBUG - 2022-05-17 17:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:41 --> Total execution time: 0.0180
DEBUG - 2022-05-17 17:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:41 --> Total execution time: 0.0156
DEBUG - 2022-05-17 17:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:42 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:43 --> Total execution time: 0.0174
DEBUG - 2022-05-17 17:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:44 --> Total execution time: 0.0159
DEBUG - 2022-05-17 17:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:45 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:45 --> Total execution time: 0.0157
DEBUG - 2022-05-17 17:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:46 --> Total execution time: 0.0256
DEBUG - 2022-05-17 17:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:47 --> Total execution time: 0.0158
DEBUG - 2022-05-17 17:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:55 --> Total execution time: 0.0225
DEBUG - 2022-05-17 17:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:55 --> Total execution time: 0.0336
DEBUG - 2022-05-17 17:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:56 --> Total execution time: 0.0161
DEBUG - 2022-05-17 17:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:13:57 --> Total execution time: 0.0193
DEBUG - 2022-05-17 17:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:14:00 --> Total execution time: 0.0161
DEBUG - 2022-05-17 17:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:14:00 --> Total execution time: 0.0113
DEBUG - 2022-05-17 17:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:14:00 --> Total execution time: 0.0096
DEBUG - 2022-05-17 17:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:14:00 --> Total execution time: 0.0100
DEBUG - 2022-05-17 17:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:14:13 --> Total execution time: 0.0140
DEBUG - 2022-05-17 17:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 17:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 17:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 17:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 18:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 18:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 18:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-17 21:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 21:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 21:57:37 --> Encryption: Auto-configured driver 'openssl'.
