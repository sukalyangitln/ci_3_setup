<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-23 02:46:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:46:51 --> No URI present. Default controller set.
DEBUG - 2023-01-23 02:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 02:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:16:52 --> Total execution time: 0.1831
DEBUG - 2023-01-23 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:46:53 --> No URI present. Default controller set.
DEBUG - 2023-01-23 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:16:53 --> Total execution time: 0.0511
DEBUG - 2023-01-23 02:46:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 02:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:16:55 --> Total execution time: 0.0634
DEBUG - 2023-01-23 02:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:47:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:47:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:47:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:47:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:48:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 02:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:18:48 --> Total execution time: 0.0454
DEBUG - 2023-01-23 02:54:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 02:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:24:43 --> Total execution time: 0.0737
DEBUG - 2023-01-23 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:54:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:54:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:54:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:54:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:55:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 02:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:25:08 --> Total execution time: 0.0465
DEBUG - 2023-01-23 02:55:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:55:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:55:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:55:08 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 02:55:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:55:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:55:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 02:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:25:22 --> Total execution time: 0.0599
DEBUG - 2023-01-23 02:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:55:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:55:22 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 02:55:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:55:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 02:55:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 02:58:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 02:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 02:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 02:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:28:46 --> Total execution time: 0.0713
DEBUG - 2023-01-23 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:32:21 --> Total execution time: 0.0471
DEBUG - 2023-01-23 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:02:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 03:02:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:02:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:02:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:02:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 03:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:32:54 --> Total execution time: 0.0536
DEBUG - 2023-01-23 03:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:02:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 03:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:02:54 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 03:02:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 03:02:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:02:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 03:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:34:59 --> Total execution time: 0.1582
DEBUG - 2023-01-23 03:05:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:35:55 --> Total execution time: 0.0669
DEBUG - 2023-01-23 03:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:36:05 --> Total execution time: 0.0843
DEBUG - 2023-01-23 03:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 03:06:19 --> Total execution time: 0.0462
DEBUG - 2023-01-23 03:06:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 03:06:21 --> Total execution time: 0.0423
DEBUG - 2023-01-23 03:06:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 03:06:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:36:22 --> Total execution time: 0.0470
DEBUG - 2023-01-23 03:06:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:36:25 --> Total execution time: 0.0469
DEBUG - 2023-01-23 03:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:36:28 --> Total execution time: 0.0693
DEBUG - 2023-01-23 03:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:36:28 --> Total execution time: 0.0586
DEBUG - 2023-01-23 03:10:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:40:06 --> Total execution time: 0.0487
DEBUG - 2023-01-23 03:10:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:40:06 --> Total execution time: 0.0600
DEBUG - 2023-01-23 03:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:40:22 --> Total execution time: 0.0827
DEBUG - 2023-01-23 03:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:40:22 --> Total execution time: 0.0551
DEBUG - 2023-01-23 03:10:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:40:33 --> Total execution time: 0.0555
DEBUG - 2023-01-23 03:10:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:40:33 --> Total execution time: 0.0580
DEBUG - 2023-01-23 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:10:48 --> UTF-8 Support Enabled
ERROR - 2023-01-23 03:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:41:42 --> Total execution time: 0.0688
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:11:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
ERROR - 2023-01-23 03:11:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:11:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:41:42 --> Total execution time: 0.0565
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:11:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 03:11:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 03:11:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:11:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 03:11:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 03:12:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:42:51 --> Total execution time: 0.0585
DEBUG - 2023-01-23 03:12:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:42:51 --> Total execution time: 0.0568
DEBUG - 2023-01-23 03:13:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:43:38 --> Total execution time: 0.0464
DEBUG - 2023-01-23 03:13:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:43:38 --> Total execution time: 0.0562
DEBUG - 2023-01-23 03:14:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:44:21 --> Total execution time: 0.0622
DEBUG - 2023-01-23 03:14:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:44:22 --> Total execution time: 0.0541
DEBUG - 2023-01-23 03:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:44:44 --> Total execution time: 0.1010
DEBUG - 2023-01-23 03:14:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:44:44 --> Total execution time: 0.0546
DEBUG - 2023-01-23 03:14:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:44:58 --> Total execution time: 0.0883
DEBUG - 2023-01-23 03:14:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:44:58 --> Total execution time: 0.0640
DEBUG - 2023-01-23 03:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:45:40 --> Total execution time: 0.0813
DEBUG - 2023-01-23 03:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:45:40 --> Total execution time: 0.0568
DEBUG - 2023-01-23 03:17:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:47:45 --> Total execution time: 0.0535
DEBUG - 2023-01-23 03:17:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 07:47:45 --> Total execution time: 0.0518
DEBUG - 2023-01-23 03:43:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:13:45 --> Total execution time: 0.0612
DEBUG - 2023-01-23 03:47:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:17:36 --> Total execution time: 0.0637
DEBUG - 2023-01-23 03:47:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 03:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 03:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 03:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:17:36 --> Total execution time: 0.0455
DEBUG - 2023-01-23 04:00:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:00:13 --> UTF-8 Support Enabled
ERROR - 2023-01-23 04:00:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:00:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:30:14 --> Total execution time: 0.0556
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:30:14 --> Total execution time: 0.0479
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:00:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:00:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:19 --> Severity: error --> Exception: syntax error, unexpected 'as' (T_AS) C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Welcome.php 115
DEBUG - 2023-01-23 04:00:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:00:27 --> Severity: error --> Exception: syntax error, unexpected 'as' (T_AS) C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Welcome.php 115
DEBUG - 2023-01-23 04:00:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:30:55 --> Total execution time: 0.0915
DEBUG - 2023-01-23 04:01:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:31:00 --> Total execution time: 0.0576
DEBUG - 2023-01-23 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:32:43 --> Total execution time: 0.0633
DEBUG - 2023-01-23 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:32:43 --> Total execution time: 0.0490
DEBUG - 2023-01-23 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:02:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:02:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:02:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:02:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:02:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:02:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:02:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:02:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:02:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:32:48 --> Total execution time: 0.0612
DEBUG - 2023-01-23 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:34:00 --> Total execution time: 0.0702
DEBUG - 2023-01-23 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:34:00 --> Total execution time: 0.0643
DEBUG - 2023-01-23 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:04:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:04:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:34:06 --> Total execution time: 0.0583
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:34:19 --> Total execution time: 0.0755
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:34:19 --> Total execution time: 0.0516
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:04:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:04:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:04:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:34:22 --> Total execution time: 0.0620
DEBUG - 2023-01-23 04:05:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:35:41 --> Total execution time: 0.0486
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:35:42 --> Total execution time: 0.0589
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:05:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:35:45 --> Total execution time: 0.0490
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:35:57 --> Total execution time: 0.0504
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:35:57 --> Total execution time: 0.0642
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:05:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:05:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:35:59 --> Total execution time: 0.0412
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:36:30 --> Total execution time: 0.0641
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:06:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
ERROR - 2023-01-23 04:06:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:06:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:06:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 08:36:30 --> Total execution time: 0.0543
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:06:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:06:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:06:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:06:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:36:34 --> Total execution time: 0.0594
DEBUG - 2023-01-23 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:37:15 --> Total execution time: 0.0679
DEBUG - 2023-01-23 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:07:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:07:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:07:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:37:16 --> Total execution time: 0.0584
DEBUG - 2023-01-23 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:07:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:07:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:07:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:07:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:07:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:07:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:37:18 --> Total execution time: 0.0405
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:40:25 --> Total execution time: 0.0879
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:10:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:10:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:10:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:40:25 --> Total execution time: 0.0542
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:10:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:10:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:10:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:10:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:10:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:10:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:40:29 --> Total execution time: 0.0405
DEBUG - 2023-01-23 04:18:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:48:13 --> Total execution time: 0.0670
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:48:14 --> Total execution time: 0.0587
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
ERROR - 2023-01-23 04:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:18:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:48:18 --> Total execution time: 0.0428
DEBUG - 2023-01-23 04:18:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:48:21 --> Total execution time: 0.0527
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:51:11 --> Total execution time: 0.0999
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:21:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:21:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:21:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:51:11 --> Total execution time: 0.0603
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:21:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:21:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-23 04:21:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:21:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 04:21:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-23 04:23:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:53:02 --> Total execution time: 0.0707
DEBUG - 2023-01-23 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:53:03 --> Total execution time: 0.0495
DEBUG - 2023-01-23 04:23:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:53:28 --> Total execution time: 0.0545
DEBUG - 2023-01-23 04:23:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:53:31 --> Total execution time: 0.0485
DEBUG - 2023-01-23 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:53:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:53:36 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:53:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:53:36 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:53:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:53:36 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:53:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:53:36 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:53:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:53:36 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:53:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:53:36 --> You did not select a file to upload.
DEBUG - 2023-01-23 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:53:36 --> Total execution time: 0.0473
DEBUG - 2023-01-23 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:53:36 --> Total execution time: 0.0499
DEBUG - 2023-01-23 04:24:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:54:51 --> Total execution time: 0.0464
DEBUG - 2023-01-23 04:24:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:54:51 --> Total execution time: 0.0538
DEBUG - 2023-01-23 04:25:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:55:15 --> Total execution time: 0.0667
DEBUG - 2023-01-23 04:25:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:55:16 --> Total execution time: 0.0446
DEBUG - 2023-01-23 04:25:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:55:46 --> Total execution time: 0.0553
DEBUG - 2023-01-23 04:25:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:55:48 --> Total execution time: 0.0691
DEBUG - 2023-01-23 04:25:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:55:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:55:52 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:55:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:55:52 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:55:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:55:52 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:55:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:55:52 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:55:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:55:52 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:55:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:55:52 --> You did not select a file to upload.
DEBUG - 2023-01-23 04:25:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:55:52 --> Total execution time: 0.0462
DEBUG - 2023-01-23 04:25:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:55:52 --> Total execution time: 0.0475
DEBUG - 2023-01-23 04:26:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:56:32 --> Total execution time: 0.0538
DEBUG - 2023-01-23 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:56:35 --> Total execution time: 0.0717
DEBUG - 2023-01-23 04:27:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:57:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:57:03 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:57:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:57:03 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:57:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:57:03 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:57:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:57:03 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:57:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:57:03 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:57:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:57:03 --> You did not select a file to upload.
DEBUG - 2023-01-23 04:27:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:57:03 --> Total execution time: 0.0456
DEBUG - 2023-01-23 04:27:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:57:04 --> Total execution time: 0.0490
DEBUG - 2023-01-23 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:58:34 --> Total execution time: 0.0467
DEBUG - 2023-01-23 04:28:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:58:35 --> Total execution time: 0.0498
DEBUG - 2023-01-23 04:28:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:58:41 --> Total execution time: 0.0612
DEBUG - 2023-01-23 04:28:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:58:43 --> Total execution time: 0.0496
DEBUG - 2023-01-23 04:28:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:58:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:58:47 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:58:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:58:47 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:58:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:58:47 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:58:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:58:47 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:58:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:58:47 --> You did not select a file to upload.
DEBUG - 2023-01-23 08:58:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 08:58:47 --> You did not select a file to upload.
DEBUG - 2023-01-23 04:28:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:58:47 --> Total execution time: 0.0464
DEBUG - 2023-01-23 04:28:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 08:58:47 --> Total execution time: 0.0458
DEBUG - 2023-01-23 04:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:32:06 --> No URI present. Default controller set.
DEBUG - 2023-01-23 04:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:02:07 --> Total execution time: 0.1043
DEBUG - 2023-01-23 04:33:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 04:33:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:03:51 --> Total execution time: 0.0590
DEBUG - 2023-01-23 04:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:03:58 --> Total execution time: 0.0603
DEBUG - 2023-01-23 04:34:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:04:02 --> Total execution time: 0.0482
DEBUG - 2023-01-23 04:34:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:04:02 --> Total execution time: 0.0574
DEBUG - 2023-01-23 04:38:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:08:33 --> Total execution time: 0.1032
DEBUG - 2023-01-23 04:38:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:08:33 --> Total execution time: 0.0723
DEBUG - 2023-01-23 04:39:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:39:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:25 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
DEBUG - 2023-01-23 09:09:25 --> Total execution time: 0.1066
DEBUG - 2023-01-23 04:39:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:39:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 283
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
ERROR - 2023-01-23 09:09:26 --> Severity: Notice --> Undefined property: stdClass::$city_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 286
DEBUG - 2023-01-23 09:09:26 --> Total execution time: 0.0684
DEBUG - 2023-01-23 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:09:39 --> Total execution time: 0.0856
DEBUG - 2023-01-23 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:09:39 --> Total execution time: 0.0567
DEBUG - 2023-01-23 04:40:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:10:49 --> Total execution time: 0.0517
DEBUG - 2023-01-23 04:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:10:50 --> Total execution time: 0.0461
DEBUG - 2023-01-23 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:10:51 --> Total execution time: 0.0501
DEBUG - 2023-01-23 04:41:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:11:38 --> Total execution time: 0.0538
DEBUG - 2023-01-23 04:41:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:11:38 --> Total execution time: 0.0819
DEBUG - 2023-01-23 04:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:11:46 --> Total execution time: 0.0918
DEBUG - 2023-01-23 04:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:11:46 --> Total execution time: 0.0788
DEBUG - 2023-01-23 04:41:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:11:50 --> Total execution time: 0.0704
DEBUG - 2023-01-23 04:41:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:11:50 --> Total execution time: 0.0584
DEBUG - 2023-01-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:12:44 --> Total execution time: 0.0625
DEBUG - 2023-01-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:12:44 --> Total execution time: 0.0560
DEBUG - 2023-01-23 04:43:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:13:42 --> Total execution time: 0.0466
DEBUG - 2023-01-23 04:43:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:13:42 --> Total execution time: 0.0529
DEBUG - 2023-01-23 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:06 --> Total execution time: 0.0455
DEBUG - 2023-01-23 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:06 --> Total execution time: 0.0653
DEBUG - 2023-01-23 04:44:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:32 --> Total execution time: 0.1378
DEBUG - 2023-01-23 04:44:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:38 --> No URI present. Default controller set.
DEBUG - 2023-01-23 04:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:38 --> Total execution time: 0.0485
DEBUG - 2023-01-23 04:44:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:40 --> Total execution time: 0.0785
DEBUG - 2023-01-23 04:44:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:43 --> Total execution time: 0.0980
DEBUG - 2023-01-23 04:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 04:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:48 --> Total execution time: 0.1096
DEBUG - 2023-01-23 04:44:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:52 --> Total execution time: 0.1036
DEBUG - 2023-01-23 04:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:55 --> Total execution time: 0.0644
DEBUG - 2023-01-23 04:44:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:14:56 --> Total execution time: 0.0536
DEBUG - 2023-01-23 04:46:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:16:17 --> Total execution time: 0.0865
DEBUG - 2023-01-23 04:46:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:16:17 --> Total execution time: 0.0704
DEBUG - 2023-01-23 04:47:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:17:18 --> Total execution time: 0.0907
DEBUG - 2023-01-23 04:47:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:17:18 --> Total execution time: 0.0622
DEBUG - 2023-01-23 04:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:17:21 --> Total execution time: 0.0415
DEBUG - 2023-01-23 04:47:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:17:22 --> Total execution time: 0.0672
DEBUG - 2023-01-23 04:49:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:19:38 --> Total execution time: 0.0806
DEBUG - 2023-01-23 04:49:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:19:38 --> Total execution time: 0.0672
DEBUG - 2023-01-23 04:49:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:19:42 --> Total execution time: 0.0626
DEBUG - 2023-01-23 04:49:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:19:44 --> Total execution time: 0.0509
DEBUG - 2023-01-23 04:49:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:19:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:19:48 --> You did not select a file to upload.
DEBUG - 2023-01-23 09:19:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:19:48 --> You did not select a file to upload.
DEBUG - 2023-01-23 09:19:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:19:48 --> You did not select a file to upload.
DEBUG - 2023-01-23 09:19:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:19:48 --> You did not select a file to upload.
DEBUG - 2023-01-23 09:19:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:19:48 --> You did not select a file to upload.
DEBUG - 2023-01-23 04:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:19:48 --> Total execution time: 0.0596
DEBUG - 2023-01-23 04:49:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:19:48 --> Total execution time: 0.0667
DEBUG - 2023-01-23 04:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:20:44 --> Total execution time: 0.0771
DEBUG - 2023-01-23 04:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:20:44 --> Total execution time: 0.0723
DEBUG - 2023-01-23 04:50:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:20:47 --> Total execution time: 0.0465
DEBUG - 2023-01-23 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:20:48 --> Total execution time: 0.0566
DEBUG - 2023-01-23 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:20:48 --> Total execution time: 0.0474
DEBUG - 2023-01-23 04:51:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:21:33 --> Total execution time: 0.0488
DEBUG - 2023-01-23 04:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:21:34 --> Total execution time: 0.0454
DEBUG - 2023-01-23 04:51:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:21:35 --> Total execution time: 0.0447
DEBUG - 2023-01-23 04:51:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:21:36 --> Total execution time: 0.0692
DEBUG - 2023-01-23 04:52:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:02 --> Total execution time: 0.0686
DEBUG - 2023-01-23 04:52:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:07 --> Total execution time: 0.0585
DEBUG - 2023-01-23 04:52:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:09 --> Total execution time: 0.0445
DEBUG - 2023-01-23 04:52:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:13 --> Total execution time: 0.0452
DEBUG - 2023-01-23 04:52:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:15 --> Total execution time: 0.0628
DEBUG - 2023-01-23 04:52:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:15 --> Total execution time: 0.0577
DEBUG - 2023-01-23 04:52:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:23 --> Total execution time: 0.0592
DEBUG - 2023-01-23 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:27 --> Total execution time: 0.0714
DEBUG - 2023-01-23 04:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:22:37 --> You did not select a file to upload.
DEBUG - 2023-01-23 09:22:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:22:37 --> You did not select a file to upload.
DEBUG - 2023-01-23 04:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:37 --> Total execution time: 0.0612
DEBUG - 2023-01-23 04:52:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:37 --> Total execution time: 0.0609
DEBUG - 2023-01-23 04:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:39 --> Total execution time: 0.0667
DEBUG - 2023-01-23 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:41 --> Total execution time: 0.0606
DEBUG - 2023-01-23 04:52:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:46 --> Total execution time: 0.0824
DEBUG - 2023-01-23 04:52:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:46 --> Total execution time: 0.0584
DEBUG - 2023-01-23 04:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:49 --> Total execution time: 0.0429
DEBUG - 2023-01-23 04:52:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:50 --> Total execution time: 0.0771
DEBUG - 2023-01-23 04:52:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:50 --> Total execution time: 0.0544
DEBUG - 2023-01-23 04:52:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:54 --> Total execution time: 0.0443
DEBUG - 2023-01-23 04:52:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:56 --> Total execution time: 0.0559
DEBUG - 2023-01-23 04:52:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:22:56 --> Total execution time: 0.0562
DEBUG - 2023-01-23 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:23:01 --> Total execution time: 0.0510
DEBUG - 2023-01-23 04:53:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:23:05 --> Total execution time: 0.0479
DEBUG - 2023-01-23 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:23:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:23:12 --> You did not select a file to upload.
DEBUG - 2023-01-23 09:23:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:23:12 --> You did not select a file to upload.
DEBUG - 2023-01-23 09:23:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:23:12 --> You did not select a file to upload.
DEBUG - 2023-01-23 09:23:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 09:23:12 --> You did not select a file to upload.
DEBUG - 2023-01-23 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:23:12 --> Total execution time: 0.0582
DEBUG - 2023-01-23 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:23:12 --> Total execution time: 0.0876
DEBUG - 2023-01-23 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:53:59 --> No URI present. Default controller set.
DEBUG - 2023-01-23 04:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:24:00 --> Total execution time: 0.0492
DEBUG - 2023-01-23 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 04:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-23 09:24:08 --> Severity: Notice --> Undefined property: stdClass::$p_short_description C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate.php 147
DEBUG - 2023-01-23 09:24:08 --> Total execution time: 0.0544
DEBUG - 2023-01-23 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:30:09 --> Total execution time: 0.0838
DEBUG - 2023-01-23 05:00:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:30:09 --> Total execution time: 0.0571
DEBUG - 2023-01-23 05:00:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:30:50 --> Total execution time: 0.0631
DEBUG - 2023-01-23 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 05:01:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 05:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:01:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 30
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 30
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 33
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 33
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 37
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_show_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 37
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 41
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_contact_no' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 41
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 45
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_whats_app_no' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 45
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 49
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_email' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 49
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 54
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_copyright' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 54
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 58
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_develop_by' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 58
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 59
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_develop_by_link' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 59
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 63
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 63
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 63
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_logo' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 63
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 68
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 68
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 68
ERROR - 2023-01-23 09:31:19 --> Severity: Notice --> Trying to get property 'comp_favicon' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\settings\tax-and-others.php 68
DEBUG - 2023-01-23 09:31:19 --> Total execution time: 0.0870
DEBUG - 2023-01-23 05:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:01:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:31:31 --> Total execution time: 0.0707
DEBUG - 2023-01-23 05:01:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:31:38 --> Total execution time: 0.0717
DEBUG - 2023-01-23 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:33:41 --> Total execution time: 0.0653
DEBUG - 2023-01-23 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:33:48 --> Total execution time: 0.0568
DEBUG - 2023-01-23 05:04:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:34:40 --> Total execution time: 0.0421
DEBUG - 2023-01-23 05:05:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:35:33 --> Total execution time: 0.0610
DEBUG - 2023-01-23 05:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:35:58 --> Total execution time: 0.0587
DEBUG - 2023-01-23 05:10:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:40:21 --> Total execution time: 0.0655
DEBUG - 2023-01-23 05:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 05:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:40:22 --> Total execution time: 0.0435
DEBUG - 2023-01-23 05:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 05:10:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:40:25 --> Total execution time: 0.0437
DEBUG - 2023-01-23 05:10:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 05:10:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:40:28 --> Total execution time: 0.0435
DEBUG - 2023-01-23 05:10:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:40:49 --> Total execution time: 0.0527
DEBUG - 2023-01-23 05:11:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:41:46 --> Total execution time: 0.0689
DEBUG - 2023-01-23 05:11:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:41:47 --> Total execution time: 0.0969
DEBUG - 2023-01-23 05:11:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:41:59 --> Total execution time: 0.0447
DEBUG - 2023-01-23 05:12:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:42:01 --> Total execution time: 0.0751
DEBUG - 2023-01-23 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:12:20 --> No URI present. Default controller set.
DEBUG - 2023-01-23 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:42:20 --> Total execution time: 0.0459
DEBUG - 2023-01-23 05:12:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:12:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-23 09:42:22 --> Severity: Notice --> Undefined property: stdClass::$p_short_description C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate.php 147
DEBUG - 2023-01-23 09:42:22 --> Total execution time: 0.0507
DEBUG - 2023-01-23 05:14:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:14:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-23 09:44:19 --> Severity: Notice --> Undefined property: stdClass::$p_short_description C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate.php 147
DEBUG - 2023-01-23 09:44:19 --> Total execution time: 0.0944
DEBUG - 2023-01-23 05:15:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:45:52 --> Total execution time: 0.0476
DEBUG - 2023-01-23 05:16:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:16:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 05:16:53 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 05:16:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 05:16:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 05:16:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 05:16:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:16:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 05:16:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:48:05 --> Total execution time: 0.0863
DEBUG - 2023-01-23 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:49:11 --> Total execution time: 0.0724
DEBUG - 2023-01-23 05:21:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:51:39 --> Total execution time: 0.0475
DEBUG - 2023-01-23 05:22:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:52:02 --> Total execution time: 0.0489
DEBUG - 2023-01-23 05:23:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 05:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 05:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 05:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 09:53:16 --> Total execution time: 0.0465
DEBUG - 2023-01-23 13:23:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:23:56 --> No URI present. Default controller set.
DEBUG - 2023-01-23 13:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 17:53:56 --> Total execution time: 0.0718
DEBUG - 2023-01-23 13:23:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:23:57 --> No URI present. Default controller set.
DEBUG - 2023-01-23 13:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 17:53:57 --> Total execution time: 0.0464
DEBUG - 2023-01-23 13:24:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 17:54:00 --> Total execution time: 0.0734
DEBUG - 2023-01-23 13:38:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:08:13 --> Total execution time: 0.0569
DEBUG - 2023-01-23 13:38:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:13 --> 404 Page Not Found: website/Js/custom
DEBUG - 2023-01-23 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:08:30 --> Total execution time: 0.0723
DEBUG - 2023-01-23 13:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:30 --> 404 Page Not Found: website/Js/custom
DEBUG - 2023-01-23 13:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:31 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 13:38:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:08:52 --> Total execution time: 0.0613
DEBUG - 2023-01-23 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:52 --> 404 Page Not Found: website/Js/custom
DEBUG - 2023-01-23 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:38:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:09:31 --> Total execution time: 0.0517
DEBUG - 2023-01-23 13:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:39:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:39:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:39:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:39:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:39:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:39:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:39:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:39:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:39:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:40:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:10:51 --> Total execution time: 0.0691
DEBUG - 2023-01-23 13:40:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:40:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:40:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:40:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:40:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:40:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:40:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:11:14 --> Total execution time: 0.0722
DEBUG - 2023-01-23 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:41:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:14 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 13:41:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:11:39 --> Total execution time: 0.0505
DEBUG - 2023-01-23 13:41:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:11:46 --> Total execution time: 0.0581
DEBUG - 2023-01-23 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:41:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:46 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 13:41:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:41:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:41:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:12:26 --> Total execution time: 0.0646
DEBUG - 2023-01-23 13:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:42:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:42:26 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 13:42:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:42:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:44:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:14:30 --> Total execution time: 0.0720
DEBUG - 2023-01-23 13:44:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:44:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:44:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:44:31 --> UTF-8 Support Enabled
ERROR - 2023-01-23 13:44:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:44:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:44:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:44:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:14:57 --> Total execution time: 0.0709
DEBUG - 2023-01-23 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:44:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:44:57 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 13:44:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:44:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:46:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:16:23 --> Total execution time: 0.0692
DEBUG - 2023-01-23 13:46:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:46:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:46:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:46:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:46:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:46:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:46:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:46:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:17:19 --> Total execution time: 0.0537
DEBUG - 2023-01-23 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:47:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:47:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:47:19 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 13:47:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:47:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:17:57 --> Total execution time: 0.0643
DEBUG - 2023-01-23 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:47:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:47:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:47:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:47:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:18:17 --> Total execution time: 0.0705
DEBUG - 2023-01-23 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:48:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:48:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:48:17 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 13:48:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:48:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:48:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:48:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:18:30 --> Total execution time: 0.0524
DEBUG - 2023-01-23 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:48:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:48:30 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 13:48:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:48:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:53:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:23:40 --> Total execution time: 0.0702
DEBUG - 2023-01-23 13:53:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:53:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:53:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:53:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:53:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:53:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:53:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:53:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:53:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:23:48 --> Total execution time: 0.0717
DEBUG - 2023-01-23 13:53:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:53:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:53:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:53:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:53:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:53:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:53:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:53:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:53:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 13:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 13:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:25:07 --> Total execution time: 0.0492
DEBUG - 2023-01-23 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:55:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:55:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:55:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 13:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 13:55:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:00:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:00:25 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:00:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:00:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:00:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:00:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:30:29 --> Total execution time: 0.0511
DEBUG - 2023-01-23 14:00:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:00:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:00:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:00:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:00:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:00:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:00:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:30:48 --> Total execution time: 0.0542
DEBUG - 2023-01-23 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:02:55 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:02:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:02:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:02:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:02:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:32:57 --> Total execution time: 0.0737
DEBUG - 2023-01-23 14:02:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:02:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:02:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:02:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:02:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:02:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:02:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:02:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:02:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:33:30 --> Total execution time: 0.0509
DEBUG - 2023-01-23 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:03:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:03:30 --> UTF-8 Support Enabled
ERROR - 2023-01-23 14:03:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:03:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:03:30 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:04:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:34:21 --> Total execution time: 0.0517
DEBUG - 2023-01-23 14:04:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:04:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:04:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:04:21 --> UTF-8 Support Enabled
ERROR - 2023-01-23 14:04:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:04:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:04:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:04:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:05:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:35:30 --> Total execution time: 0.0502
DEBUG - 2023-01-23 14:06:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:36:58 --> Total execution time: 0.0710
DEBUG - 2023-01-23 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:06:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:06:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:06:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:06:58 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:06:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:06:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:06:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:13 --> Total execution time: 0.0530
DEBUG - 2023-01-23 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:13 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:07:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:15 --> Total execution time: 0.0631
DEBUG - 2023-01-23 14:07:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:17 --> Total execution time: 0.0608
DEBUG - 2023-01-23 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:22 --> Total execution time: 0.0757
DEBUG - 2023-01-23 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:23 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:07:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:24 --> Total execution time: 0.0594
DEBUG - 2023-01-23 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:25 --> Total execution time: 0.0515
DEBUG - 2023-01-23 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:40 --> Total execution time: 0.0575
DEBUG - 2023-01-23 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:07:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:42 --> Total execution time: 0.0421
DEBUG - 2023-01-23 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:46 --> Total execution time: 0.0602
DEBUG - 2023-01-23 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:37:46 --> Total execution time: 0.0403
DEBUG - 2023-01-23 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:38:01 --> Total execution time: 0.0491
DEBUG - 2023-01-23 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:38:18 --> Total execution time: 0.0499
DEBUG - 2023-01-23 14:08:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:19 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:08:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:38:28 --> Total execution time: 0.0592
DEBUG - 2023-01-23 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:28 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:08:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:38:46 --> Total execution time: 0.0499
DEBUG - 2023-01-23 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:08:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:08:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:08:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:39:00 --> Total execution time: 0.0723
DEBUG - 2023-01-23 14:09:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:09:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:01 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:09:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:39:42 --> Total execution time: 0.0695
DEBUG - 2023-01-23 14:09:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:42 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:09:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:39:47 --> Total execution time: 0.0849
DEBUG - 2023-01-23 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:47 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:09:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:09:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:46 --> Total execution time: 0.0715
DEBUG - 2023-01-23 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:10:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:10:46 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:10:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:10:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:10:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:50 --> Total execution time: 0.0544
DEBUG - 2023-01-23 14:10:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:50 --> Total execution time: 0.0643
DEBUG - 2023-01-23 14:10:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:51 --> Total execution time: 0.0805
DEBUG - 2023-01-23 14:10:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:51 --> Total execution time: 0.0980
DEBUG - 2023-01-23 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:52 --> Total execution time: 0.1208
DEBUG - 2023-01-23 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:52 --> Total execution time: 0.0846
DEBUG - 2023-01-23 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:53 --> Total execution time: 0.0588
DEBUG - 2023-01-23 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:53 --> Total execution time: 0.0391
DEBUG - 2023-01-23 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:53 --> Total execution time: 0.1031
DEBUG - 2023-01-23 14:10:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:54 --> Total execution time: 0.0674
DEBUG - 2023-01-23 14:10:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:54 --> Total execution time: 0.0597
DEBUG - 2023-01-23 14:10:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:54 --> Total execution time: 0.1151
DEBUG - 2023-01-23 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:55 --> Total execution time: 0.0892
DEBUG - 2023-01-23 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:55 --> Total execution time: 0.0509
DEBUG - 2023-01-23 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:55 --> Total execution time: 0.0629
DEBUG - 2023-01-23 14:10:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:56 --> Total execution time: 0.0878
DEBUG - 2023-01-23 14:10:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:56 --> Total execution time: 0.0393
DEBUG - 2023-01-23 14:10:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:56 --> Total execution time: 0.0946
DEBUG - 2023-01-23 14:10:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:56 --> Total execution time: 0.0508
DEBUG - 2023-01-23 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:57 --> Total execution time: 0.0915
DEBUG - 2023-01-23 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:57 --> Total execution time: 0.0625
DEBUG - 2023-01-23 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:57 --> Total execution time: 0.0996
DEBUG - 2023-01-23 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:57 --> Total execution time: 0.0776
DEBUG - 2023-01-23 14:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:58 --> Total execution time: 0.0874
DEBUG - 2023-01-23 14:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:58 --> Total execution time: 0.0750
DEBUG - 2023-01-23 14:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:58 --> Total execution time: 0.0564
DEBUG - 2023-01-23 14:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:58 --> Total execution time: 0.1137
DEBUG - 2023-01-23 14:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:58 --> Total execution time: 0.0581
DEBUG - 2023-01-23 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:59 --> Total execution time: 0.0546
DEBUG - 2023-01-23 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:59 --> Total execution time: 0.0530
DEBUG - 2023-01-23 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:59 --> Total execution time: 0.0545
DEBUG - 2023-01-23 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:59 --> Total execution time: 0.1239
DEBUG - 2023-01-23 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:40:59 --> Total execution time: 0.0598
DEBUG - 2023-01-23 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:00 --> Total execution time: 0.0653
DEBUG - 2023-01-23 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:00 --> Total execution time: 0.0394
DEBUG - 2023-01-23 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:00 --> Total execution time: 0.0379
DEBUG - 2023-01-23 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:00 --> Total execution time: 0.0550
DEBUG - 2023-01-23 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:00 --> Total execution time: 0.0943
DEBUG - 2023-01-23 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:00 --> Total execution time: 0.0600
DEBUG - 2023-01-23 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:01 --> Total execution time: 0.0859
DEBUG - 2023-01-23 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:01 --> Total execution time: 0.0551
DEBUG - 2023-01-23 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:01 --> Total execution time: 0.0550
DEBUG - 2023-01-23 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:01 --> Total execution time: 0.0537
DEBUG - 2023-01-23 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:01 --> Total execution time: 0.0682
DEBUG - 2023-01-23 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:01 --> Total execution time: 0.0616
DEBUG - 2023-01-23 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:02 --> Total execution time: 0.0679
DEBUG - 2023-01-23 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:02 --> Total execution time: 0.0570
DEBUG - 2023-01-23 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:02 --> Total execution time: 0.0522
DEBUG - 2023-01-23 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:02 --> Total execution time: 0.0525
DEBUG - 2023-01-23 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:02 --> Total execution time: 0.1147
DEBUG - 2023-01-23 14:11:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:02 --> Total execution time: 0.0731
DEBUG - 2023-01-23 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:03 --> Total execution time: 0.0793
DEBUG - 2023-01-23 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:03 --> Total execution time: 0.0383
DEBUG - 2023-01-23 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:03 --> Total execution time: 0.0538
DEBUG - 2023-01-23 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:03 --> Total execution time: 0.0581
DEBUG - 2023-01-23 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:03 --> Total execution time: 0.0381
DEBUG - 2023-01-23 14:11:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:03 --> Total execution time: 0.0376
DEBUG - 2023-01-23 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:04 --> Total execution time: 0.0855
DEBUG - 2023-01-23 14:11:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:04 --> Total execution time: 0.0839
DEBUG - 2023-01-23 14:11:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:05 --> Total execution time: 0.0530
DEBUG - 2023-01-23 14:11:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:05 --> Total execution time: 0.0550
DEBUG - 2023-01-23 14:11:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:05 --> Total execution time: 0.0383
DEBUG - 2023-01-23 14:11:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:05 --> Total execution time: 0.0577
DEBUG - 2023-01-23 14:11:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:05 --> Total execution time: 0.0571
DEBUG - 2023-01-23 14:11:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:06 --> Total execution time: 0.0609
DEBUG - 2023-01-23 14:11:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:06 --> Total execution time: 0.0458
DEBUG - 2023-01-23 14:11:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:06 --> Total execution time: 0.0641
DEBUG - 2023-01-23 14:11:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:06 --> Total execution time: 0.0406
DEBUG - 2023-01-23 14:11:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:06 --> Total execution time: 0.0405
DEBUG - 2023-01-23 14:11:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:06 --> Total execution time: 0.0394
DEBUG - 2023-01-23 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:07 --> Total execution time: 0.0719
DEBUG - 2023-01-23 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:07 --> Total execution time: 0.0570
DEBUG - 2023-01-23 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:07 --> Total execution time: 0.0691
DEBUG - 2023-01-23 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:07 --> Total execution time: 0.0555
DEBUG - 2023-01-23 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:07 --> Total execution time: 0.0554
DEBUG - 2023-01-23 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:07 --> Total execution time: 0.0375
DEBUG - 2023-01-23 14:11:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:07 --> Total execution time: 0.0374
DEBUG - 2023-01-23 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:08 --> Total execution time: 0.0901
DEBUG - 2023-01-23 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:08 --> Total execution time: 0.0432
DEBUG - 2023-01-23 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:08 --> Total execution time: 0.0860
DEBUG - 2023-01-23 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:08 --> Total execution time: 0.0560
DEBUG - 2023-01-23 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:08 --> Total execution time: 0.0572
DEBUG - 2023-01-23 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:08 --> Total execution time: 0.0566
DEBUG - 2023-01-23 14:11:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:08 --> Total execution time: 0.0550
DEBUG - 2023-01-23 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:09 --> Total execution time: 0.0772
DEBUG - 2023-01-23 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:09 --> Total execution time: 0.0495
DEBUG - 2023-01-23 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:09 --> Total execution time: 0.0526
DEBUG - 2023-01-23 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:09 --> Total execution time: 0.0628
DEBUG - 2023-01-23 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:09 --> Total execution time: 0.0398
DEBUG - 2023-01-23 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:09 --> Total execution time: 0.0389
DEBUG - 2023-01-23 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:09 --> Total execution time: 0.0399
DEBUG - 2023-01-23 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:10 --> Total execution time: 0.0675
DEBUG - 2023-01-23 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:10 --> Total execution time: 0.0552
DEBUG - 2023-01-23 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:10 --> Total execution time: 0.0480
DEBUG - 2023-01-23 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:10 --> Total execution time: 0.0469
DEBUG - 2023-01-23 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:10 --> Total execution time: 0.0403
DEBUG - 2023-01-23 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:10 --> Total execution time: 0.0420
DEBUG - 2023-01-23 14:11:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:10 --> Total execution time: 0.0397
DEBUG - 2023-01-23 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:11 --> Total execution time: 0.0746
DEBUG - 2023-01-23 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:11 --> Total execution time: 0.0389
DEBUG - 2023-01-23 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:11 --> Total execution time: 0.0612
DEBUG - 2023-01-23 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:11 --> Total execution time: 0.0392
DEBUG - 2023-01-23 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:11 --> Total execution time: 0.0398
DEBUG - 2023-01-23 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:11 --> Total execution time: 0.0388
DEBUG - 2023-01-23 14:11:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:11 --> Total execution time: 0.0391
DEBUG - 2023-01-23 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:12 --> Total execution time: 0.0860
DEBUG - 2023-01-23 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:12 --> Total execution time: 0.0416
DEBUG - 2023-01-23 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:12 --> Total execution time: 0.0721
DEBUG - 2023-01-23 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:12 --> Total execution time: 0.0406
DEBUG - 2023-01-23 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:12 --> Total execution time: 0.0396
DEBUG - 2023-01-23 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:12 --> Total execution time: 0.0410
DEBUG - 2023-01-23 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:12 --> Total execution time: 0.0467
DEBUG - 2023-01-23 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:13 --> Total execution time: 0.0705
DEBUG - 2023-01-23 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:13 --> Total execution time: 0.0426
DEBUG - 2023-01-23 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:13 --> Total execution time: 0.0616
DEBUG - 2023-01-23 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:13 --> Total execution time: 0.0406
DEBUG - 2023-01-23 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:13 --> Total execution time: 0.0411
DEBUG - 2023-01-23 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:13 --> Total execution time: 0.0386
DEBUG - 2023-01-23 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:13 --> Total execution time: 0.0389
DEBUG - 2023-01-23 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:14 --> Total execution time: 0.0695
DEBUG - 2023-01-23 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:14 --> Total execution time: 0.0393
DEBUG - 2023-01-23 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:14 --> Total execution time: 0.0667
DEBUG - 2023-01-23 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:14 --> Total execution time: 0.0382
DEBUG - 2023-01-23 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:14 --> Total execution time: 0.0511
DEBUG - 2023-01-23 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:14 --> Total execution time: 0.0384
DEBUG - 2023-01-23 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:14 --> Total execution time: 0.0405
DEBUG - 2023-01-23 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:15 --> Total execution time: 0.0698
DEBUG - 2023-01-23 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:15 --> Total execution time: 0.0401
DEBUG - 2023-01-23 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:15 --> Total execution time: 0.0843
DEBUG - 2023-01-23 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:15 --> Total execution time: 0.0575
DEBUG - 2023-01-23 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:15 --> Total execution time: 0.0564
DEBUG - 2023-01-23 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:15 --> Total execution time: 0.0377
DEBUG - 2023-01-23 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:15 --> Total execution time: 0.0376
DEBUG - 2023-01-23 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:16 --> Total execution time: 0.0844
DEBUG - 2023-01-23 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:16 --> Total execution time: 0.0565
DEBUG - 2023-01-23 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:16 --> Total execution time: 0.0832
DEBUG - 2023-01-23 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:16 --> Total execution time: 0.0571
DEBUG - 2023-01-23 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:16 --> Total execution time: 0.0578
DEBUG - 2023-01-23 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:16 --> Total execution time: 0.0565
DEBUG - 2023-01-23 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:16 --> Total execution time: 0.0555
DEBUG - 2023-01-23 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:17 --> Total execution time: 0.0721
DEBUG - 2023-01-23 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:17 --> Total execution time: 0.0774
DEBUG - 2023-01-23 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:17 --> Total execution time: 0.0839
DEBUG - 2023-01-23 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:17 --> Total execution time: 0.0563
DEBUG - 2023-01-23 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:17 --> Total execution time: 0.0382
DEBUG - 2023-01-23 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:17 --> Total execution time: 0.0611
DEBUG - 2023-01-23 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:17 --> Total execution time: 0.0572
DEBUG - 2023-01-23 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:18 --> Total execution time: 0.1098
DEBUG - 2023-01-23 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:18 --> Total execution time: 0.0425
DEBUG - 2023-01-23 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:18 --> Total execution time: 0.0551
DEBUG - 2023-01-23 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:18 --> Total execution time: 0.0379
DEBUG - 2023-01-23 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:18 --> Total execution time: 0.0375
DEBUG - 2023-01-23 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:18 --> Total execution time: 0.0527
DEBUG - 2023-01-23 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:18 --> Total execution time: 0.0555
DEBUG - 2023-01-23 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:19 --> Total execution time: 0.0850
DEBUG - 2023-01-23 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:19 --> Total execution time: 0.0552
DEBUG - 2023-01-23 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:19 --> Total execution time: 0.0392
DEBUG - 2023-01-23 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:19 --> Total execution time: 0.0567
DEBUG - 2023-01-23 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:19 --> Total execution time: 0.0568
DEBUG - 2023-01-23 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:19 --> Total execution time: 0.0577
DEBUG - 2023-01-23 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:19 --> Total execution time: 0.0386
DEBUG - 2023-01-23 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:20 --> Total execution time: 0.0895
DEBUG - 2023-01-23 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:20 --> Total execution time: 0.0514
DEBUG - 2023-01-23 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:20 --> Total execution time: 0.0571
DEBUG - 2023-01-23 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:20 --> Total execution time: 0.0410
DEBUG - 2023-01-23 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:20 --> Total execution time: 0.0412
DEBUG - 2023-01-23 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:20 --> Total execution time: 0.0388
DEBUG - 2023-01-23 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:20 --> Total execution time: 0.0378
DEBUG - 2023-01-23 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:21 --> Total execution time: 0.0856
DEBUG - 2023-01-23 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:21 --> Total execution time: 0.0556
DEBUG - 2023-01-23 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:21 --> Total execution time: 0.0553
DEBUG - 2023-01-23 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:21 --> Total execution time: 0.0527
DEBUG - 2023-01-23 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:21 --> Total execution time: 0.0578
DEBUG - 2023-01-23 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:21 --> Total execution time: 0.0564
DEBUG - 2023-01-23 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:21 --> Total execution time: 0.0568
DEBUG - 2023-01-23 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:22 --> Total execution time: 0.0620
DEBUG - 2023-01-23 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:22 --> Total execution time: 0.0379
DEBUG - 2023-01-23 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:22 --> Total execution time: 0.0537
DEBUG - 2023-01-23 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:22 --> Total execution time: 0.0376
DEBUG - 2023-01-23 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:22 --> Total execution time: 0.0379
DEBUG - 2023-01-23 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:22 --> Total execution time: 0.0620
DEBUG - 2023-01-23 14:11:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:22 --> Total execution time: 0.0570
DEBUG - 2023-01-23 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:23 --> Total execution time: 0.0984
DEBUG - 2023-01-23 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:23 --> Total execution time: 0.0564
DEBUG - 2023-01-23 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:23 --> Total execution time: 0.0679
DEBUG - 2023-01-23 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:23 --> Total execution time: 0.0569
DEBUG - 2023-01-23 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:23 --> Total execution time: 0.0573
DEBUG - 2023-01-23 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:23 --> Total execution time: 0.0570
DEBUG - 2023-01-23 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:24 --> Total execution time: 0.0567
DEBUG - 2023-01-23 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:24 --> Total execution time: 0.0680
DEBUG - 2023-01-23 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:24 --> Total execution time: 0.0559
DEBUG - 2023-01-23 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:24 --> Total execution time: 0.0495
DEBUG - 2023-01-23 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:24 --> Total execution time: 0.0379
DEBUG - 2023-01-23 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:24 --> Total execution time: 0.0368
DEBUG - 2023-01-23 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:24 --> Total execution time: 0.0525
DEBUG - 2023-01-23 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:24 --> Total execution time: 0.0376
DEBUG - 2023-01-23 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:25 --> Total execution time: 0.0589
DEBUG - 2023-01-23 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:25 --> Total execution time: 0.0376
DEBUG - 2023-01-23 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:25 --> Total execution time: 0.0545
DEBUG - 2023-01-23 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:25 --> Total execution time: 0.0373
DEBUG - 2023-01-23 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:25 --> Total execution time: 0.0569
DEBUG - 2023-01-23 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:25 --> Total execution time: 0.0552
DEBUG - 2023-01-23 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:26 --> Total execution time: 0.0575
DEBUG - 2023-01-23 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:26 --> Total execution time: 0.0695
DEBUG - 2023-01-23 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:26 --> Total execution time: 0.0389
DEBUG - 2023-01-23 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:26 --> Total execution time: 0.0625
DEBUG - 2023-01-23 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:26 --> Total execution time: 0.0375
DEBUG - 2023-01-23 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:26 --> Total execution time: 0.0375
DEBUG - 2023-01-23 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:26 --> Total execution time: 0.0382
DEBUG - 2023-01-23 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:26 --> Total execution time: 0.0375
DEBUG - 2023-01-23 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:27 --> Total execution time: 0.0720
DEBUG - 2023-01-23 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:27 --> Total execution time: 0.0550
DEBUG - 2023-01-23 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:27 --> Total execution time: 0.0653
DEBUG - 2023-01-23 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:27 --> Total execution time: 0.0587
DEBUG - 2023-01-23 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:27 --> Total execution time: 0.0575
DEBUG - 2023-01-23 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:27 --> Total execution time: 0.0394
DEBUG - 2023-01-23 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:28 --> Total execution time: 0.0372
DEBUG - 2023-01-23 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:28 --> Total execution time: 0.0646
DEBUG - 2023-01-23 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:28 --> Total execution time: 0.0610
DEBUG - 2023-01-23 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:28 --> Total execution time: 0.0663
DEBUG - 2023-01-23 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:28 --> Total execution time: 0.0392
DEBUG - 2023-01-23 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:28 --> Total execution time: 0.0384
DEBUG - 2023-01-23 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:28 --> Total execution time: 0.0612
DEBUG - 2023-01-23 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:29 --> Total execution time: 0.0562
DEBUG - 2023-01-23 14:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:29 --> Total execution time: 0.0901
DEBUG - 2023-01-23 14:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:29 --> Total execution time: 0.0520
DEBUG - 2023-01-23 14:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:29 --> Total execution time: 0.0636
DEBUG - 2023-01-23 14:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:29 --> Total execution time: 0.0384
DEBUG - 2023-01-23 14:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:29 --> Total execution time: 0.0385
DEBUG - 2023-01-23 14:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:29 --> Total execution time: 0.0517
DEBUG - 2023-01-23 14:11:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:30 --> Total execution time: 0.0392
DEBUG - 2023-01-23 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:30 --> Total execution time: 0.0518
DEBUG - 2023-01-23 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:30 --> Total execution time: 0.0380
DEBUG - 2023-01-23 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:30 --> Total execution time: 0.0513
DEBUG - 2023-01-23 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:30 --> Total execution time: 0.0376
DEBUG - 2023-01-23 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:30 --> Total execution time: 0.0373
DEBUG - 2023-01-23 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:30 --> Total execution time: 0.0386
DEBUG - 2023-01-23 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:30 --> Total execution time: 0.0384
DEBUG - 2023-01-23 14:11:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:31 --> Total execution time: 0.0648
DEBUG - 2023-01-23 14:11:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:31 --> Total execution time: 0.0595
DEBUG - 2023-01-23 14:11:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:31 --> Total execution time: 0.0746
DEBUG - 2023-01-23 14:11:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:31 --> Total execution time: 0.0567
DEBUG - 2023-01-23 14:11:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:31 --> Total execution time: 0.0580
DEBUG - 2023-01-23 14:11:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:32 --> Total execution time: 0.0727
DEBUG - 2023-01-23 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:32 --> Total execution time: 0.0484
DEBUG - 2023-01-23 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:32 --> Total execution time: 0.0579
DEBUG - 2023-01-23 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:32 --> Total execution time: 0.0552
DEBUG - 2023-01-23 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:32 --> Total execution time: 0.0662
DEBUG - 2023-01-23 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:32 --> Total execution time: 0.0379
DEBUG - 2023-01-23 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:32 --> Total execution time: 0.0382
DEBUG - 2023-01-23 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:32 --> Total execution time: 0.0379
DEBUG - 2023-01-23 14:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:33 --> Total execution time: 0.0524
DEBUG - 2023-01-23 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:33 --> Total execution time: 0.0626
DEBUG - 2023-01-23 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:33 --> Total execution time: 0.0391
DEBUG - 2023-01-23 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:33 --> Total execution time: 0.0772
DEBUG - 2023-01-23 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:33 --> Total execution time: 0.0557
DEBUG - 2023-01-23 14:11:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:33 --> Total execution time: 0.0563
DEBUG - 2023-01-23 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:34 --> Total execution time: 0.0552
DEBUG - 2023-01-23 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:34 --> Total execution time: 0.0559
DEBUG - 2023-01-23 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:34 --> Total execution time: 0.0778
DEBUG - 2023-01-23 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:34 --> Total execution time: 0.0383
DEBUG - 2023-01-23 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:34 --> Total execution time: 0.0545
DEBUG - 2023-01-23 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:34 --> Total execution time: 0.0391
DEBUG - 2023-01-23 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:34 --> Total execution time: 0.0385
DEBUG - 2023-01-23 14:11:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:35 --> Total execution time: 0.0591
DEBUG - 2023-01-23 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:35 --> Total execution time: 0.0571
DEBUG - 2023-01-23 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:35 --> Total execution time: 0.0861
DEBUG - 2023-01-23 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:35 --> Total execution time: 0.0430
DEBUG - 2023-01-23 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:35 --> Total execution time: 0.0689
DEBUG - 2023-01-23 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:35 --> Total execution time: 0.0573
DEBUG - 2023-01-23 14:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:36 --> Total execution time: 0.0554
DEBUG - 2023-01-23 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:36 --> Total execution time: 0.0567
DEBUG - 2023-01-23 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:36 --> Total execution time: 0.0568
DEBUG - 2023-01-23 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:36 --> Total execution time: 0.0874
DEBUG - 2023-01-23 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:36 --> Total execution time: 0.0835
DEBUG - 2023-01-23 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:36 --> Total execution time: 0.0876
DEBUG - 2023-01-23 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:36 --> Total execution time: 0.0610
DEBUG - 2023-01-23 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:37 --> Total execution time: 0.0573
DEBUG - 2023-01-23 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:37 --> Total execution time: 0.0587
DEBUG - 2023-01-23 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:37 --> Total execution time: 0.0551
DEBUG - 2023-01-23 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:37 --> Total execution time: 0.1128
DEBUG - 2023-01-23 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:37 --> Total execution time: 0.0773
DEBUG - 2023-01-23 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:37 --> Total execution time: 0.0680
DEBUG - 2023-01-23 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:37 --> Total execution time: 0.0371
DEBUG - 2023-01-23 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:38 --> Total execution time: 0.0596
DEBUG - 2023-01-23 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:38 --> Total execution time: 0.0575
DEBUG - 2023-01-23 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:38 --> Total execution time: 0.0588
DEBUG - 2023-01-23 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:38 --> Total execution time: 0.0818
DEBUG - 2023-01-23 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:38 --> Total execution time: 0.2001
DEBUG - 2023-01-23 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:38 --> Total execution time: 0.0678
DEBUG - 2023-01-23 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:38 --> Total execution time: 0.0569
DEBUG - 2023-01-23 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:39 --> Total execution time: 0.0565
DEBUG - 2023-01-23 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:39 --> Total execution time: 0.0576
DEBUG - 2023-01-23 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:39 --> Total execution time: 0.0594
DEBUG - 2023-01-23 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:39 --> Total execution time: 0.0857
DEBUG - 2023-01-23 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:39 --> Total execution time: 0.0565
DEBUG - 2023-01-23 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:39 --> Total execution time: 0.0521
DEBUG - 2023-01-23 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:39 --> Total execution time: 0.0397
DEBUG - 2023-01-23 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:40 --> Total execution time: 0.0395
DEBUG - 2023-01-23 14:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:40 --> Total execution time: 0.0392
DEBUG - 2023-01-23 14:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:40 --> Total execution time: 0.0388
DEBUG - 2023-01-23 14:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:40 --> Total execution time: 0.0968
DEBUG - 2023-01-23 14:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:40 --> Total execution time: 0.0579
DEBUG - 2023-01-23 14:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:40 --> Total execution time: 0.0859
DEBUG - 2023-01-23 14:11:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:41 --> Total execution time: 0.0441
DEBUG - 2023-01-23 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:41 --> Total execution time: 0.0507
DEBUG - 2023-01-23 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:41 --> Total execution time: 0.0437
DEBUG - 2023-01-23 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:41 --> Total execution time: 0.0422
DEBUG - 2023-01-23 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:41 --> Total execution time: 0.0669
DEBUG - 2023-01-23 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:41 --> Total execution time: 0.0556
DEBUG - 2023-01-23 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:41 --> Total execution time: 0.0660
DEBUG - 2023-01-23 14:11:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 14:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 18:41:41 --> Total execution time: 0.0532
DEBUG - 2023-01-23 14:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:41:42 --> Total execution time: 0.0783
DEBUG - 2023-01-23 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:11:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:11:42 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:11:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:11:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:11:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:39 --> Total execution time: 0.0728
DEBUG - 2023-01-23 14:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:12:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:12:39 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:12:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:12:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:12:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:12:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:42 --> Total execution time: 0.0630
DEBUG - 2023-01-23 14:12:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:42 --> Total execution time: 0.0389
DEBUG - 2023-01-23 14:12:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:42 --> Total execution time: 0.0959
DEBUG - 2023-01-23 14:12:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:42 --> Total execution time: 0.0387
DEBUG - 2023-01-23 14:12:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:43 --> Total execution time: 0.0781
DEBUG - 2023-01-23 14:12:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:43 --> Total execution time: 0.0563
DEBUG - 2023-01-23 14:12:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:46 --> Total execution time: 0.0558
DEBUG - 2023-01-23 14:12:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:46 --> Total execution time: 0.0577
DEBUG - 2023-01-23 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:47 --> Total execution time: 0.0427
DEBUG - 2023-01-23 14:12:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:47 --> Total execution time: 0.0382
DEBUG - 2023-01-23 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:49 --> Total execution time: 0.0720
DEBUG - 2023-01-23 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:49 --> Total execution time: 0.0388
DEBUG - 2023-01-23 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:50 --> Total execution time: 0.0850
DEBUG - 2023-01-23 14:12:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:42:50 --> Total execution time: 0.0395
DEBUG - 2023-01-23 14:13:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:07 --> Total execution time: 0.0534
DEBUG - 2023-01-23 14:13:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:07 --> Total execution time: 0.0389
DEBUG - 2023-01-23 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:09 --> Total execution time: 0.0388
DEBUG - 2023-01-23 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:09 --> Total execution time: 0.0399
DEBUG - 2023-01-23 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:31 --> Total execution time: 0.0697
DEBUG - 2023-01-23 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:52 --> Total execution time: 0.0547
DEBUG - 2023-01-23 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:53 --> Total execution time: 0.0477
DEBUG - 2023-01-23 14:13:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:13:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:57 --> Total execution time: 0.0544
DEBUG - 2023-01-23 14:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:43:57 --> Total execution time: 0.0574
DEBUG - 2023-01-23 14:14:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:17 --> Total execution time: 0.0498
DEBUG - 2023-01-23 14:14:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:17 --> Total execution time: 0.0467
DEBUG - 2023-01-23 14:14:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:32 --> Total execution time: 0.0476
DEBUG - 2023-01-23 14:14:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:32 --> Total execution time: 0.0444
DEBUG - 2023-01-23 14:14:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:33 --> Total execution time: 0.0569
DEBUG - 2023-01-23 14:14:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:14:33 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:14:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:14:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:14:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:14:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:14:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:36 --> Total execution time: 0.0404
DEBUG - 2023-01-23 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:36 --> Total execution time: 0.0400
DEBUG - 2023-01-23 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:36 --> Total execution time: 0.0768
DEBUG - 2023-01-23 14:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:36 --> Total execution time: 0.0393
DEBUG - 2023-01-23 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:41 --> Total execution time: 0.0512
DEBUG - 2023-01-23 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:44:41 --> Total execution time: 0.0549
DEBUG - 2023-01-23 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:45:12 --> Total execution time: 0.0516
DEBUG - 2023-01-23 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:45:12 --> Total execution time: 0.0475
DEBUG - 2023-01-23 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:45:13 --> Total execution time: 0.0568
DEBUG - 2023-01-23 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:15:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:15:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:15:13 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:15:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:15:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:15:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:15:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:45:31 --> Total execution time: 0.0480
DEBUG - 2023-01-23 14:15:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:15:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:15:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:15:31 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:15:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:15:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:15:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:15:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:45:34 --> Total execution time: 0.0604
DEBUG - 2023-01-23 14:15:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:45:34 --> Total execution time: 0.0571
DEBUG - 2023-01-23 14:15:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:00 --> Total execution time: 0.0715
DEBUG - 2023-01-23 14:16:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:00 --> Total execution time: 0.0433
DEBUG - 2023-01-23 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:01 --> Total execution time: 0.0688
DEBUG - 2023-01-23 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:03 --> Total execution time: 0.0616
DEBUG - 2023-01-23 14:16:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:05 --> Total execution time: 0.0501
DEBUG - 2023-01-23 14:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:05 --> Total execution time: 0.1138
DEBUG - 2023-01-23 14:16:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:06 --> Total execution time: 0.0735
DEBUG - 2023-01-23 14:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:21 --> Total execution time: 0.0740
DEBUG - 2023-01-23 14:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:22 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:16:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:24 --> Total execution time: 0.0606
DEBUG - 2023-01-23 14:16:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:24 --> Total execution time: 0.0907
DEBUG - 2023-01-23 14:16:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:25 --> Total execution time: 0.0709
DEBUG - 2023-01-23 14:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:35 --> Total execution time: 0.0460
DEBUG - 2023-01-23 14:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 14:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 18:46:35 --> Total execution time: 0.0652
DEBUG - 2023-01-23 14:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:46:35 --> Total execution time: 0.0701
DEBUG - 2023-01-23 14:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:35 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:16:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:16:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:16:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:25:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:55:17 --> Total execution time: 0.0788
DEBUG - 2023-01-23 14:25:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:25:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:25:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:25:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:25:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:25:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:25:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:25:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:55:20 --> Total execution time: 0.0581
DEBUG - 2023-01-23 14:25:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:55:21 --> Total execution time: 0.0790
DEBUG - 2023-01-23 14:25:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:55:31 --> Total execution time: 0.0642
DEBUG - 2023-01-23 14:25:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:55:37 --> Total execution time: 0.0605
DEBUG - 2023-01-23 14:25:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:55:44 --> Total execution time: 0.0421
DEBUG - 2023-01-23 14:25:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 18:55:44 --> Total execution time: 0.0416
DEBUG - 2023-01-23 14:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:01:20 --> Total execution time: 0.0535
DEBUG - 2023-01-23 14:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:31:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:31:20 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:31:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:31:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:31:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:31:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_slug' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_title' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_short_description' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_slug' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_title' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_short_description' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
DEBUG - 2023-01-23 14:31:23 --> UTF-8 Support Enabled
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_slug' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
DEBUG - 2023-01-23 14:31:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_title' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_short_description' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
DEBUG - 2023-01-23 19:01:23 --> Total execution time: 0.0797
DEBUG - 2023-01-23 14:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:31:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_slug' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_title' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_short_description' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_slug' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_title' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_short_description' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 34
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 39
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_slug' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 40
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'cat_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 45
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_title' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 50
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Undefined variable: campaign C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
ERROR - 2023-01-23 19:01:23 --> Severity: Notice --> Trying to get property 'p_short_description' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 52
DEBUG - 2023-01-23 19:01:23 --> Total execution time: 0.0693
DEBUG - 2023-01-23 14:31:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:01:40 --> Total execution time: 0.0500
DEBUG - 2023-01-23 14:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:31:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:31:40 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:31:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:31:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:31:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:31:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:01:43 --> Total execution time: 0.0646
DEBUG - 2023-01-23 14:31:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:01:43 --> Total execution time: 0.0451
DEBUG - 2023-01-23 14:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:02:08 --> Total execution time: 0.0491
DEBUG - 2023-01-23 14:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:32:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:32:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:32:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:32:08 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:32:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:32:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:32:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:32:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:32:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:02:12 --> Total execution time: 0.0661
DEBUG - 2023-01-23 14:32:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:02:12 --> Total execution time: 0.0424
DEBUG - 2023-01-23 14:34:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:34:13 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 37
DEBUG - 2023-01-23 14:34:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:34:13 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 37
DEBUG - 2023-01-23 14:34:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:34:14 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Posts_Controller.php 37
DEBUG - 2023-01-23 14:34:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:04:20 --> Total execution time: 0.1007
DEBUG - 2023-01-23 14:34:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:34:20 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:34:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:34:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:34:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:34:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:34:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:04:24 --> Total execution time: 0.0663
DEBUG - 2023-01-23 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:04:24 --> Total execution time: 0.0431
DEBUG - 2023-01-23 14:34:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:04:31 --> Total execution time: 0.0399
DEBUG - 2023-01-23 14:34:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:04:53 --> Total execution time: 0.0727
DEBUG - 2023-01-23 14:36:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:06:43 --> Total execution time: 0.0450
DEBUG - 2023-01-23 14:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:07:48 --> Total execution time: 0.0473
DEBUG - 2023-01-23 14:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:37:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:37:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:37:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:37:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:37:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:07:58 --> Total execution time: 0.0577
DEBUG - 2023-01-23 14:37:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:37:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:37:59 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:37:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:37:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:08:07 --> Total execution time: 0.0831
DEBUG - 2023-01-23 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:38:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:38:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:38:07 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:38:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:38:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:08:49 --> Total execution time: 0.0586
DEBUG - 2023-01-23 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:38:49 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:38:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:38:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:41:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:11:09 --> Total execution time: 0.0795
DEBUG - 2023-01-23 14:41:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:41:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:41:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:41:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:41:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:41:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:41:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:41:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:41:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:11:30 --> Total execution time: 0.0569
DEBUG - 2023-01-23 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:11:36 --> Total execution time: 0.0715
DEBUG - 2023-01-23 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:11:36 --> Total execution time: 0.0439
DEBUG - 2023-01-23 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:11:36 --> Total execution time: 0.0820
DEBUG - 2023-01-23 14:41:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:11:40 --> Total execution time: 0.0624
DEBUG - 2023-01-23 14:41:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:11:59 --> Total execution time: 0.1100
DEBUG - 2023-01-23 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:02 --> Total execution time: 0.0619
DEBUG - 2023-01-23 14:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:42:05 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:42:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:42:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:42:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:42:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:09 --> Total execution time: 0.0472
DEBUG - 2023-01-23 14:42:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:10 --> Total execution time: 0.0994
DEBUG - 2023-01-23 14:42:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:20 --> Total execution time: 0.0523
DEBUG - 2023-01-23 14:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:21 --> Total execution time: 0.0568
DEBUG - 2023-01-23 14:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:42:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:42:21 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:42:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:42:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:26 --> Total execution time: 0.0571
DEBUG - 2023-01-23 14:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:26 --> Total execution time: 0.0401
DEBUG - 2023-01-23 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:27 --> Total execution time: 0.0791
DEBUG - 2023-01-23 14:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:28 --> Total execution time: 0.1089
DEBUG - 2023-01-23 14:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:28 --> Total execution time: 0.0399
DEBUG - 2023-01-23 14:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:28 --> Total execution time: 0.0879
DEBUG - 2023-01-23 14:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:28 --> Total execution time: 0.0424
DEBUG - 2023-01-23 14:42:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:30 --> Total execution time: 0.0454
DEBUG - 2023-01-23 14:42:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:30 --> Total execution time: 0.0606
DEBUG - 2023-01-23 14:42:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:31 --> Total execution time: 0.1324
DEBUG - 2023-01-23 14:42:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:12:55 --> Total execution time: 0.0520
DEBUG - 2023-01-23 14:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:08 --> Total execution time: 0.0517
DEBUG - 2023-01-23 14:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:43:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:43:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:43:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:43:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:43:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:43:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:11 --> Total execution time: 0.0668
DEBUG - 2023-01-23 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:12 --> Total execution time: 0.0808
DEBUG - 2023-01-23 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:12 --> Total execution time: 0.0645
DEBUG - 2023-01-23 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:16 --> Total execution time: 0.0647
DEBUG - 2023-01-23 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:16 --> Total execution time: 0.0848
DEBUG - 2023-01-23 14:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:17 --> Total execution time: 0.0690
DEBUG - 2023-01-23 14:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:17 --> Total execution time: 0.0610
DEBUG - 2023-01-23 14:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:17 --> Total execution time: 0.0678
DEBUG - 2023-01-23 14:43:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:17 --> Total execution time: 0.0495
DEBUG - 2023-01-23 14:43:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:18 --> Total execution time: 0.0625
DEBUG - 2023-01-23 14:43:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:25 --> Total execution time: 0.0700
DEBUG - 2023-01-23 14:43:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:26 --> Total execution time: 0.0479
DEBUG - 2023-01-23 14:43:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:26 --> Total execution time: 0.0428
DEBUG - 2023-01-23 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:48 --> Total execution time: 0.0656
DEBUG - 2023-01-23 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:43:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:43:48 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:43:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:43:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:43:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:54 --> Total execution time: 0.0588
DEBUG - 2023-01-23 14:43:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:13:54 --> Total execution time: 0.0420
DEBUG - 2023-01-23 14:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:14:06 --> Total execution time: 0.0608
DEBUG - 2023-01-23 14:44:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:14:06 --> Total execution time: 0.0568
DEBUG - 2023-01-23 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:14:14 --> Total execution time: 0.0428
DEBUG - 2023-01-23 14:44:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:14:22 --> Total execution time: 0.0528
DEBUG - 2023-01-23 14:44:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:44:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:44:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:44:22 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:44:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:44:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:44:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:44:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:14:25 --> Total execution time: 0.0635
DEBUG - 2023-01-23 14:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:11 --> Total execution time: 0.0696
DEBUG - 2023-01-23 14:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:45:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:45:11 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:45:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:45:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:45:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:17 --> Total execution time: 0.0671
DEBUG - 2023-01-23 14:45:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:17 --> Total execution time: 0.0589
DEBUG - 2023-01-23 14:45:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:22 --> Total execution time: 0.0689
DEBUG - 2023-01-23 14:45:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:23 --> Total execution time: 0.0607
DEBUG - 2023-01-23 14:45:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:23 --> Total execution time: 0.0658
DEBUG - 2023-01-23 14:45:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:25 --> Total execution time: 0.0639
DEBUG - 2023-01-23 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:41 --> Total execution time: 0.0526
DEBUG - 2023-01-23 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:45:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:45:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:45:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:45:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:45:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:15:53 --> Total execution time: 0.0511
DEBUG - 2023-01-23 14:46:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:16:35 --> Total execution time: 0.0807
DEBUG - 2023-01-23 14:46:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:46:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:46:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:46:35 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:46:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:46:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:46:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:16:41 --> Total execution time: 0.0464
DEBUG - 2023-01-23 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:16:53 --> Total execution time: 0.0569
DEBUG - 2023-01-23 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:16:53 --> Total execution time: 0.0426
DEBUG - 2023-01-23 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:16:53 --> Total execution time: 0.1100
DEBUG - 2023-01-23 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:16:53 --> Total execution time: 0.0531
DEBUG - 2023-01-23 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:16:53 --> Total execution time: 0.0420
DEBUG - 2023-01-23 14:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:17:09 --> Total execution time: 0.0457
DEBUG - 2023-01-23 14:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:17:09 --> Total execution time: 0.0480
DEBUG - 2023-01-23 14:47:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:17:12 --> Total execution time: 0.0483
DEBUG - 2023-01-23 14:47:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:17:12 --> Total execution time: 0.0462
DEBUG - 2023-01-23 14:50:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:29 --> Total execution time: 0.0597
DEBUG - 2023-01-23 14:50:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:30 --> Total execution time: 0.0723
DEBUG - 2023-01-23 14:50:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:32 --> Total execution time: 0.0428
DEBUG - 2023-01-23 14:50:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:32 --> Total execution time: 0.0469
DEBUG - 2023-01-23 14:50:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:36 --> Total execution time: 0.0596
DEBUG - 2023-01-23 14:50:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:37 --> Total execution time: 0.1087
DEBUG - 2023-01-23 14:50:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:37 --> Total execution time: 0.0896
DEBUG - 2023-01-23 14:50:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:39 --> Total execution time: 0.0602
DEBUG - 2023-01-23 14:50:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:40 --> Total execution time: 0.1087
DEBUG - 2023-01-23 14:50:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:40 --> Total execution time: 0.0739
DEBUG - 2023-01-23 14:50:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:40 --> Total execution time: 0.0933
DEBUG - 2023-01-23 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:41 --> Total execution time: 0.0767
DEBUG - 2023-01-23 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:41 --> Total execution time: 0.0637
DEBUG - 2023-01-23 14:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:44 --> Total execution time: 0.0599
DEBUG - 2023-01-23 14:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:44 --> Total execution time: 0.0986
DEBUG - 2023-01-23 14:50:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:49 --> Total execution time: 0.0567
DEBUG - 2023-01-23 14:50:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:51 --> Total execution time: 0.0566
DEBUG - 2023-01-23 14:50:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:20:51 --> Total execution time: 0.0897
DEBUG - 2023-01-23 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:22:35 --> Total execution time: 0.0445
DEBUG - 2023-01-23 14:52:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:22:36 --> Total execution time: 0.0761
DEBUG - 2023-01-23 14:52:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:22:36 --> Total execution time: 0.0517
DEBUG - 2023-01-23 14:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:52:39 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 14:52:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:52:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:52:39 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:52:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:22:41 --> Total execution time: 0.0662
DEBUG - 2023-01-23 14:53:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:23:17 --> Total execution time: 0.0767
DEBUG - 2023-01-23 14:53:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:53:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:53:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:53:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:53:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:53:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:53:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 14:53:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 14:53:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:23:21 --> Total execution time: 0.0586
DEBUG - 2023-01-23 14:53:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:23:23 --> Total execution time: 0.0459
DEBUG - 2023-01-23 14:53:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 14:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 14:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 14:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:23:25 --> Total execution time: 0.0646
DEBUG - 2023-01-23 15:08:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 15:08:16 --> Total execution time: 0.0515
DEBUG - 2023-01-23 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 15:08:17 --> Total execution time: 0.0401
DEBUG - 2023-01-23 15:08:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 15:08:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:38:19 --> Total execution time: 0.0458
DEBUG - 2023-01-23 15:08:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:38:25 --> Total execution time: 0.0890
DEBUG - 2023-01-23 15:11:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:41:48 --> Total execution time: 0.0567
DEBUG - 2023-01-23 15:11:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:41:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 15:11:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:41:58 --> Total execution time: 0.0456
DEBUG - 2023-01-23 15:12:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:42:00 --> Total execution time: 0.0431
DEBUG - 2023-01-23 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:42:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:42:15 --> Total execution time: 0.0437
DEBUG - 2023-01-23 15:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:43:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 15:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:43:10 --> Total execution time: 0.0671
DEBUG - 2023-01-23 15:13:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:43:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 15:13:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:43:31 --> Total execution time: 0.0646
DEBUG - 2023-01-23 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:43:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-23 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:43:45 --> Total execution time: 0.0423
DEBUG - 2023-01-23 15:16:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:46:30 --> Total execution time: 0.0707
DEBUG - 2023-01-23 15:16:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:16:40 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:46:40 --> Total execution time: 0.0591
DEBUG - 2023-01-23 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:25:51 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:55:51 --> Total execution time: 0.0559
DEBUG - 2023-01-23 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:25:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:26:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:26:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:26:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:26:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:26:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:26:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:28:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:28:42 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:58:42 --> Total execution time: 0.0732
DEBUG - 2023-01-23 15:28:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:28:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:28:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:29:31 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 19:59:31 --> Total execution time: 0.0662
DEBUG - 2023-01-23 15:29:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:29:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:32:56 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:02:56 --> Total execution time: 0.0831
DEBUG - 2023-01-23 15:32:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:32:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:32:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:33:33 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:03:33 --> Total execution time: 0.0678
DEBUG - 2023-01-23 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:33:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:33:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:33:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:33:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:33:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:34:19 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:04:19 --> Total execution time: 0.0743
DEBUG - 2023-01-23 15:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:34:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:34:19 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 15:34:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:34:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:34:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:04:26 --> Total execution time: 0.0462
DEBUG - 2023-01-23 15:34:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:04:57 --> Total execution time: 0.0692
DEBUG - 2023-01-23 15:34:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:04:59 --> Total execution time: 0.0609
DEBUG - 2023-01-23 15:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:04 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:05:04 --> Total execution time: 0.0635
DEBUG - 2023-01-23 15:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:35:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:04 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 15:35:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:04 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:05:07 --> Total execution time: 0.0620
DEBUG - 2023-01-23 15:35:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:07 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 15:35:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:08 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:05:08 --> Total execution time: 0.0613
DEBUG - 2023-01-23 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:29 --> No URI present. Default controller set.
DEBUG - 2023-01-23 15:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:05:29 --> Total execution time: 0.0662
DEBUG - 2023-01-23 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:35:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:29 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 15:35:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:29 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:05:35 --> Total execution time: 0.0766
DEBUG - 2023-01-23 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:35:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:37:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:07:35 --> Total execution time: 0.0590
DEBUG - 2023-01-23 15:43:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:13:25 --> Total execution time: 0.0533
DEBUG - 2023-01-23 15:43:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:13:38 --> Total execution time: 0.0465
DEBUG - 2023-01-23 15:43:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:13:49 --> Total execution time: 0.0711
DEBUG - 2023-01-23 15:47:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:17:58 --> Total execution time: 0.0606
DEBUG - 2023-01-23 15:47:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:17:59 --> Total execution time: 0.0557
DEBUG - 2023-01-23 15:48:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:18:10 --> Total execution time: 0.0721
DEBUG - 2023-01-23 15:48:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:18:10 --> Total execution time: 0.0478
DEBUG - 2023-01-23 15:48:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:18:13 --> Total execution time: 0.0488
DEBUG - 2023-01-23 15:48:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:18:13 --> Total execution time: 0.0516
DEBUG - 2023-01-23 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:19:31 --> Total execution time: 0.0663
DEBUG - 2023-01-23 15:49:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:19:35 --> Total execution time: 0.0590
DEBUG - 2023-01-23 15:50:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:20:59 --> Total execution time: 0.0952
DEBUG - 2023-01-23 15:51:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:21:36 --> Total execution time: 0.0467
DEBUG - 2023-01-23 15:52:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:22:27 --> Total execution time: 0.0459
DEBUG - 2023-01-23 15:52:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:22:32 --> Total execution time: 0.0602
DEBUG - 2023-01-23 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:23:08 --> Total execution time: 0.0418
DEBUG - 2023-01-23 15:53:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:23:58 --> Total execution time: 0.0455
DEBUG - 2023-01-23 15:54:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:54:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:54:02 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 15:54:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:54:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:54:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:54:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:54:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:56:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:26:30 --> Total execution time: 0.0461
DEBUG - 2023-01-23 15:56:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:56:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:56:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:56:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:56:31 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 15:56:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:56:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:56:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:58:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:28:17 --> Total execution time: 0.0441
DEBUG - 2023-01-23 15:58:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:58:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:58:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:58:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:58:18 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 15:58:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:58:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:58:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:58:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:28:42 --> Total execution time: 0.0419
DEBUG - 2023-01-23 15:58:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:58:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:58:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:58:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:58:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:58:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:58:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:58:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:58:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:59:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 15:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:29:31 --> Total execution time: 0.0661
DEBUG - 2023-01-23 15:59:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:59:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:59:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:59:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:59:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 15:59:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:59:31 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-23 15:59:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 15:59:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 15:59:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-23 15:59:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-23 16:00:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:30:12 --> Total execution time: 0.0609
DEBUG - 2023-01-23 16:00:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:30:24 --> Total execution time: 0.0734
DEBUG - 2023-01-23 16:00:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:30:29 --> Total execution time: 0.0623
DEBUG - 2023-01-23 16:00:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:30:40 --> Total execution time: 0.0449
DEBUG - 2023-01-23 16:01:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:03 --> Total execution time: 0.0450
DEBUG - 2023-01-23 16:01:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:05 --> Total execution time: 0.0450
DEBUG - 2023-01-23 16:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:08 --> Total execution time: 0.0412
DEBUG - 2023-01-23 16:01:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:33 --> Total execution time: 0.0651
DEBUG - 2023-01-23 16:01:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:34 --> Total execution time: 0.0478
DEBUG - 2023-01-23 16:01:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:40 --> Total execution time: 0.0667
DEBUG - 2023-01-23 16:01:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:41 --> Total execution time: 0.0495
DEBUG - 2023-01-23 16:01:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:43 --> Total execution time: 0.0433
DEBUG - 2023-01-23 16:01:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:46 --> Total execution time: 0.0413
DEBUG - 2023-01-23 16:01:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:31:57 --> Total execution time: 0.0461
DEBUG - 2023-01-23 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:02:08 --> No URI present. Default controller set.
DEBUG - 2023-01-23 16:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:32:08 --> Total execution time: 0.0492
DEBUG - 2023-01-23 16:04:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:34:31 --> Total execution time: 0.0455
DEBUG - 2023-01-23 16:04:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:34:36 --> Total execution time: 0.0563
DEBUG - 2023-01-23 16:04:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:34:47 --> Total execution time: 0.0722
DEBUG - 2023-01-23 16:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:34:59 --> Total execution time: 0.0592
DEBUG - 2023-01-23 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:35:04 --> Total execution time: 0.0462
DEBUG - 2023-01-23 16:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:36:05 --> Total execution time: 0.0424
DEBUG - 2023-01-23 16:06:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-23 16:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-23 16:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-23 16:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-23 20:36:43 --> Total execution time: 0.0458
