<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-06 01:43:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:43:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:13:52 --> Total execution time: 1.5847
DEBUG - 2021-11-06 01:43:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:43:57 --> No URI present. Default controller set.
DEBUG - 2021-11-06 01:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:13:57 --> Total execution time: 0.0852
DEBUG - 2021-11-06 01:43:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 01:43:57 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 01:43:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:43:57 --> No URI present. Default controller set.
DEBUG - 2021-11-06 01:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:13:57 --> Total execution time: 0.0342
DEBUG - 2021-11-06 01:44:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:44:03 --> Total execution time: 0.1031
DEBUG - 2021-11-06 01:44:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:44:05 --> Total execution time: 0.0342
DEBUG - 2021-11-06 01:44:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:44:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:14:11 --> Total execution time: 0.1478
DEBUG - 2021-11-06 01:44:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:14:16 --> Total execution time: 0.0940
DEBUG - 2021-11-06 01:44:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:14:29 --> Total execution time: 0.9100
DEBUG - 2021-11-06 01:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:50:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 07:20:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/cron/InstanceCheckLogout.php 54
DEBUG - 2021-11-06 07:20:38 --> Total execution time: 1.2243
DEBUG - 2021-11-06 01:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:51:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:52:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:22:43 --> Total execution time: 1.1623
DEBUG - 2021-11-06 01:53:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:23:18 --> Total execution time: 1.1682
DEBUG - 2021-11-06 01:53:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:23:39 --> Total execution time: 1.1345
DEBUG - 2021-11-06 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:24:10 --> Total execution time: 1.1474
DEBUG - 2021-11-06 01:55:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:14 --> Total execution time: 0.0475
DEBUG - 2021-11-06 01:55:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:18 --> Total execution time: 1.1754
DEBUG - 2021-11-06 01:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:18 --> Total execution time: 0.2314
DEBUG - 2021-11-06 01:55:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:19 --> Total execution time: 0.0355
DEBUG - 2021-11-06 01:55:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:20 --> Total execution time: 0.0379
DEBUG - 2021-11-06 01:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:22 --> Total execution time: 0.0346
DEBUG - 2021-11-06 01:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:22 --> Total execution time: 0.0433
DEBUG - 2021-11-06 01:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:23 --> Total execution time: 1.0873
DEBUG - 2021-11-06 01:55:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:31 --> Total execution time: 0.0393
DEBUG - 2021-11-06 01:55:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:33 --> Total execution time: 0.0600
DEBUG - 2021-11-06 01:55:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:50 --> Total execution time: 0.0334
DEBUG - 2021-11-06 01:55:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.3121
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.2184
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.2549
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.2843
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.3122
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.1140
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.0713
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.0815
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.0832
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.0697
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.0963
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.1348
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.0605
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.0368
DEBUG - 2021-11-06 01:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:55 --> Total execution time: 0.0640
DEBUG - 2021-11-06 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:56 --> Total execution time: 0.0660
DEBUG - 2021-11-06 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:56 --> Total execution time: 0.0569
DEBUG - 2021-11-06 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:56 --> Total execution time: 0.0576
DEBUG - 2021-11-06 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:56 --> Total execution time: 0.0708
DEBUG - 2021-11-06 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:56 --> Total execution time: 0.0342
DEBUG - 2021-11-06 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:56 --> Total execution time: 0.0662
DEBUG - 2021-11-06 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:56 --> Total execution time: 0.0614
DEBUG - 2021-11-06 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:57 --> Total execution time: 0.0745
DEBUG - 2021-11-06 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:57 --> Total execution time: 0.0610
DEBUG - 2021-11-06 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:57 --> Total execution time: 0.0782
DEBUG - 2021-11-06 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:57 --> Total execution time: 0.0582
DEBUG - 2021-11-06 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:57 --> Total execution time: 0.0344
DEBUG - 2021-11-06 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:57 --> Total execution time: 0.0561
DEBUG - 2021-11-06 01:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:58 --> Total execution time: 0.0585
DEBUG - 2021-11-06 01:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:58 --> Total execution time: 0.0589
DEBUG - 2021-11-06 01:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:58 --> Total execution time: 0.0596
DEBUG - 2021-11-06 01:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:58 --> Total execution time: 0.0615
DEBUG - 2021-11-06 01:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 07:25:58 --> Total execution time: 0.0571
DEBUG - 2021-11-06 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:25:58 --> Total execution time: 0.0431
DEBUG - 2021-11-06 01:56:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:00 --> Total execution time: 0.0316
DEBUG - 2021-11-06 01:56:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:01 --> Total execution time: 0.0483
DEBUG - 2021-11-06 01:56:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:01 --> Total execution time: 0.0335
DEBUG - 2021-11-06 01:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:02 --> Total execution time: 0.0350
DEBUG - 2021-11-06 01:56:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:03 --> Total execution time: 0.0321
DEBUG - 2021-11-06 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:05 --> Total execution time: 0.0454
DEBUG - 2021-11-06 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:05 --> Total execution time: 0.0337
DEBUG - 2021-11-06 01:56:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:06 --> Total execution time: 0.0327
DEBUG - 2021-11-06 01:56:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:07 --> Total execution time: 0.0396
DEBUG - 2021-11-06 01:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:10 --> Total execution time: 0.0383
DEBUG - 2021-11-06 01:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:10 --> Total execution time: 0.0366
DEBUG - 2021-11-06 01:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:10 --> Total execution time: 0.0366
DEBUG - 2021-11-06 01:56:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:11 --> Total execution time: 0.3000
DEBUG - 2021-11-06 01:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:14 --> Total execution time: 0.0469
DEBUG - 2021-11-06 01:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:14 --> Total execution time: 0.0342
DEBUG - 2021-11-06 01:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:15 --> Total execution time: 0.0358
DEBUG - 2021-11-06 01:56:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:15 --> Total execution time: 0.0406
DEBUG - 2021-11-06 01:56:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:17 --> Total execution time: 0.0320
DEBUG - 2021-11-06 01:56:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:20 --> Total execution time: 0.0333
DEBUG - 2021-11-06 01:56:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:20 --> Total execution time: 0.0315
DEBUG - 2021-11-06 01:56:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:21 --> Total execution time: 0.0343
DEBUG - 2021-11-06 01:56:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:21 --> Total execution time: 0.0531
DEBUG - 2021-11-06 01:56:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:21 --> Total execution time: 0.0328
DEBUG - 2021-11-06 01:56:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:22 --> Total execution time: 0.0322
DEBUG - 2021-11-06 01:56:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:23 --> Total execution time: 0.0355
DEBUG - 2021-11-06 01:56:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:27 --> Total execution time: 0.0387
DEBUG - 2021-11-06 01:56:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:33 --> Total execution time: 0.0429
DEBUG - 2021-11-06 01:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:34 --> Total execution time: 0.0675
DEBUG - 2021-11-06 01:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:34 --> Total execution time: 0.0486
DEBUG - 2021-11-06 01:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:34 --> Total execution time: 0.0344
DEBUG - 2021-11-06 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:35 --> Total execution time: 0.0336
DEBUG - 2021-11-06 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:35 --> Total execution time: 0.0318
DEBUG - 2021-11-06 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:35 --> Total execution time: 0.0346
DEBUG - 2021-11-06 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:35 --> Total execution time: 0.0328
DEBUG - 2021-11-06 01:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:36 --> Total execution time: 0.0375
DEBUG - 2021-11-06 01:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:36 --> Total execution time: 0.0420
DEBUG - 2021-11-06 01:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:36 --> Total execution time: 0.0308
DEBUG - 2021-11-06 01:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:37 --> Total execution time: 0.0490
DEBUG - 2021-11-06 01:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:37 --> Total execution time: 0.0573
DEBUG - 2021-11-06 01:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:37 --> Total execution time: 0.0423
DEBUG - 2021-11-06 01:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:38 --> Total execution time: 0.0340
DEBUG - 2021-11-06 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:38 --> Total execution time: 0.0332
DEBUG - 2021-11-06 01:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:44 --> No URI present. Default controller set.
DEBUG - 2021-11-06 01:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:44 --> Total execution time: 0.0260
DEBUG - 2021-11-06 01:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 01:56:44 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 01:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:44 --> No URI present. Default controller set.
DEBUG - 2021-11-06 01:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:44 --> Total execution time: 0.0303
DEBUG - 2021-11-06 01:56:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:48 --> Total execution time: 0.1512
DEBUG - 2021-11-06 01:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:26:59 --> Total execution time: 0.1392
DEBUG - 2021-11-06 01:57:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:02 --> Total execution time: 0.1601
DEBUG - 2021-11-06 01:57:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:03 --> Total execution time: 0.0531
DEBUG - 2021-11-06 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:07 --> Total execution time: 1.9294
DEBUG - 2021-11-06 01:57:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:08 --> Total execution time: 0.0430
DEBUG - 2021-11-06 01:57:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:09 --> Total execution time: 0.0464
DEBUG - 2021-11-06 01:57:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:10 --> Total execution time: 0.0361
DEBUG - 2021-11-06 01:57:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:10 --> Total execution time: 0.0342
DEBUG - 2021-11-06 01:57:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:11 --> Total execution time: 0.0640
DEBUG - 2021-11-06 01:57:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:12 --> Total execution time: 0.0377
DEBUG - 2021-11-06 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:13 --> Total execution time: 0.0365
DEBUG - 2021-11-06 01:57:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:15 --> Total execution time: 0.0406
DEBUG - 2021-11-06 01:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:25 --> Total execution time: 0.0442
DEBUG - 2021-11-06 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:26 --> Total execution time: 0.0346
DEBUG - 2021-11-06 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:26 --> Total execution time: 0.0339
DEBUG - 2021-11-06 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:26 --> Total execution time: 0.0418
DEBUG - 2021-11-06 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:26 --> Total execution time: 0.0331
DEBUG - 2021-11-06 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:27 --> Total execution time: 0.0340
DEBUG - 2021-11-06 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:27 --> Total execution time: 0.0368
DEBUG - 2021-11-06 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:27 --> Total execution time: 0.0337
DEBUG - 2021-11-06 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:27 --> Total execution time: 0.0504
DEBUG - 2021-11-06 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:28 --> Total execution time: 0.0372
DEBUG - 2021-11-06 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:28 --> Total execution time: 0.0356
DEBUG - 2021-11-06 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:28 --> Total execution time: 0.0422
DEBUG - 2021-11-06 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:28 --> Total execution time: 0.0355
DEBUG - 2021-11-06 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:28 --> Total execution time: 0.0336
DEBUG - 2021-11-06 01:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:29 --> Total execution time: 0.0362
DEBUG - 2021-11-06 01:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:29 --> Total execution time: 0.0316
DEBUG - 2021-11-06 01:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:29 --> Total execution time: 0.0325
DEBUG - 2021-11-06 01:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:29 --> Total execution time: 0.0329
DEBUG - 2021-11-06 01:57:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:27:50 --> Total execution time: 0.0372
DEBUG - 2021-11-06 01:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 01:58:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:28:44 --> Total execution time: 1.9205
DEBUG - 2021-11-06 01:58:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 01:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 01:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:28:45 --> {"session_id":"20211106072706496960","body":{"id":"3EB0C2999996D365533F","serialized":"false_919091982795@c.us_3EB0C2999996D365533F","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=b36b7fa69d4c52d95b5a9d009d54a869&oe=618A4C95","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":1,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi [client_name],\r\nYour whatsApp account disconnected from [site_name] site.","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636163924,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 07:28:45 --> Total execution time: 0.0529
DEBUG - 2021-11-06 02:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:36:42 --> Total execution time: 0.0635
DEBUG - 2021-11-06 02:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:41:31 --> Total execution time: 0.0469
DEBUG - 2021-11-06 02:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:42:25 --> Total execution time: 2.4031
DEBUG - 2021-11-06 02:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:42:27 --> {"session_id":"20211106072706496960","body":{"id":"3EB0238F4ACA25714AB1","serialized":"false_919091982795@c.us_3EB0238F4ACA25714AB1","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=b36b7fa69d4c52d95b5a9d009d54a869&oe=618A4C95","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":1,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi Dinesh Barman,\r\nYour whatsApp account disconnected from WHATSAPP API site.","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636164745,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 07:42:27 --> Total execution time: 0.0334
DEBUG - 2021-11-06 02:13:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:43:14 --> Total execution time: 2.0479
DEBUG - 2021-11-06 02:13:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:43:16 --> {"session_id":"20211106072706496960","body":{"id":"3EB0E2E6802AF6366311","serialized":"false_919091982795@c.us_3EB0E2E6802AF6366311","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=b36b7fa69d4c52d95b5a9d009d54a869&oe=618A4C95","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":1,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi Dinesh Barman,\r\nYour whatsApp account disconnected from WHATSAPP API site.","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636164795,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 07:43:16 --> Total execution time: 0.0313
DEBUG - 2021-11-06 02:13:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:43:22 --> Total execution time: 0.0437
DEBUG - 2021-11-06 02:13:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:43:44 --> Total execution time: 0.0523
DEBUG - 2021-11-06 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:44:05 --> Total execution time: 0.5896
DEBUG - 2021-11-06 02:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:44:18 --> Total execution time: 0.0518
DEBUG - 2021-11-06 02:15:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:45:03 --> Total execution time: 0.1259
DEBUG - 2021-11-06 02:23:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:53:06 --> Total execution time: 0.0554
DEBUG - 2021-11-06 02:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:53:46 --> Total execution time: 0.0491
DEBUG - 2021-11-06 02:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 07:56:15 --> Total execution time: 0.0384
DEBUG - 2021-11-06 02:32:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:32:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 08:02:44 --> Severity: Notice --> Undefined variable: admin_inst /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/cron/Package_Controller.php 28
DEBUG - 2021-11-06 08:02:44 --> Total execution time: 0.0537
DEBUG - 2021-11-06 02:33:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:03:18 --> Total execution time: 3.1084
DEBUG - 2021-11-06 02:33:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:03:20 --> {"session_id":"20211106072706496960","body":{"id":"3EB08DC1180600B94AB3","serialized":"false_919091982795@c.us_3EB08DC1180600B94AB3","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=b36b7fa69d4c52d95b5a9d009d54a869&oe=618A4C95","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":1,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi Dinesh Barman,\r\nYour whatsApp account disconnected from WHATSAPP API site.","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636165998,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 08:03:20 --> Total execution time: 0.0369
DEBUG - 2021-11-06 02:34:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:04:22 --> Total execution time: 1.5256
DEBUG - 2021-11-06 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:04:24 --> {"session_id":"20211106072706496960","body":{"id":"3EB044AC1537633DF79B","serialized":"false_919091982795@c.us_3EB044AC1537633DF79B","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=b36b7fa69d4c52d95b5a9d009d54a869&oe=618A4C95","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":1,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi Dinesh Barman,\r\nYour whatsApp account disconnected from WHATSAPP API site.","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636166063,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 08:04:24 --> Total execution time: 0.0258
DEBUG - 2021-11-06 02:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:05:11 --> Total execution time: 1.5401
DEBUG - 2021-11-06 02:35:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:05:13 --> {"session_id":"20211106072706496960","body":{"id":"3EB00972525962D0FF52","serialized":"false_919091982795@c.us_3EB00972525962D0FF52","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=b36b7fa69d4c52d95b5a9d009d54a869&oe=618A4C95","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":1,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi Dinesh Barman\r\nYour Trial package expire from WHATSAPP API, expire date 4 Days. Please renew package. ","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636166112,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 08:05:13 --> Total execution time: 0.0378
DEBUG - 2021-11-06 02:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 02:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:07:08 --> Total execution time: 0.0386
DEBUG - 2021-11-06 02:37:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:07:14 --> Total execution time: 1.4769
DEBUG - 2021-11-06 02:37:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:07:16 --> {"session_id":"20211106072706496960","body":{"id":"3EB049D5D1E8A55F2413","serialized":"false_919091982795@c.us_3EB049D5D1E8A55F2413","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=b36b7fa69d4c52d95b5a9d009d54a869&oe=618A4C95","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":1,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi Dinesh Barman\r\nYour Trial package expire from WHATSAPP API, package valid to 4 Days. Please renew package.","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636166234,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 08:07:16 --> Total execution time: 0.0314
DEBUG - 2021-11-06 02:37:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 02:37:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:07:35 --> Total execution time: 0.0304
DEBUG - 2021-11-06 02:37:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:07:39 --> Total execution time: 1.6289
DEBUG - 2021-11-06 02:37:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 02:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 02:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 08:07:41 --> {"session_id":"20211106072706496960","body":{"id":"3EB0872B18411B0AB047","serialized":"false_919091982795@c.us_3EB0872B18411B0AB047","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=b36b7fa69d4c52d95b5a9d009d54a869&oe=618A4C95","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi Dinesh Barman\r\nYour Trial package expire from WHATSAPP API, package valid for 4 Days. Please renew package.","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636166259,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 08:07:41 --> Total execution time: 0.0355
DEBUG - 2021-11-06 10:47:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 10:47:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:17:53 --> Total execution time: 3.1056
DEBUG - 2021-11-06 10:47:53 --> Total execution time: 0.1735
DEBUG - 2021-11-06 10:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:47:58 --> No URI present. Default controller set.
DEBUG - 2021-11-06 10:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:17:58 --> Total execution time: 0.1562
DEBUG - 2021-11-06 10:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:47:58 --> No URI present. Default controller set.
DEBUG - 2021-11-06 10:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:17:58 --> Total execution time: 0.0342
ERROR - 2021-11-06 10:47:58 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 10:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 10:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:18:10 --> Total execution time: 0.1350
DEBUG - 2021-11-06 10:48:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 10:48:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:18:19 --> Total execution time: 0.1370
DEBUG - 2021-11-06 10:48:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:18:25 --> Total execution time: 0.0906
DEBUG - 2021-11-06 10:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:18:44 --> Total execution time: 0.0430
DEBUG - 2021-11-06 10:50:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:20:56 --> Total execution time: 0.3318
DEBUG - 2021-11-06 10:51:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:17 --> Total execution time: 0.0601
DEBUG - 2021-11-06 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:23 --> Total execution time: 1.6843
DEBUG - 2021-11-06 10:51:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:24 --> Total execution time: 0.2589
DEBUG - 2021-11-06 10:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:25 --> Total execution time: 0.0360
DEBUG - 2021-11-06 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:26 --> Total execution time: 0.0383
DEBUG - 2021-11-06 10:51:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:27 --> Total execution time: 0.0366
DEBUG - 2021-11-06 10:51:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:28 --> Total execution time: 0.0385
DEBUG - 2021-11-06 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:29 --> Total execution time: 0.0727
DEBUG - 2021-11-06 10:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:30 --> Total execution time: 0.3285
DEBUG - 2021-11-06 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:30 --> Total execution time: 0.0395
DEBUG - 2021-11-06 10:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:31 --> Total execution time: 0.0378
DEBUG - 2021-11-06 10:51:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:32 --> Total execution time: 0.0377
DEBUG - 2021-11-06 10:51:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:35 --> Total execution time: 0.0355
DEBUG - 2021-11-06 10:51:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:40 --> Total execution time: 0.0395
DEBUG - 2021-11-06 10:51:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:41 --> Total execution time: 0.0529
DEBUG - 2021-11-06 10:51:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:41 --> Total execution time: 0.0348
DEBUG - 2021-11-06 10:51:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:42 --> Total execution time: 0.0298
DEBUG - 2021-11-06 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:42 --> Total execution time: 0.0524
DEBUG - 2021-11-06 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:21:42 --> Total execution time: 0.0377
DEBUG - 2021-11-06 10:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:42 --> Total execution time: 0.0341
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0381
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0389
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0348
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0341
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0336
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0389
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0364
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0315
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0307
DEBUG - 2021-11-06 10:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:43 --> Total execution time: 0.0452
DEBUG - 2021-11-06 10:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:44 --> Total execution time: 0.0479
DEBUG - 2021-11-06 10:51:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:58 --> Total execution time: 0.0465
DEBUG - 2021-11-06 10:51:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:21:59 --> Total execution time: 0.0423
DEBUG - 2021-11-06 10:52:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:22:02 --> Total execution time: 0.0578
DEBUG - 2021-11-06 10:52:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:22:08 --> Total execution time: 0.0300
DEBUG - 2021-11-06 10:52:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:22:11 --> Total execution time: 0.8436
DEBUG - 2021-11-06 10:53:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:23:19 --> Total execution time: 0.0403
DEBUG - 2021-11-06 10:54:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:24:26 --> Total execution time: 0.0383
DEBUG - 2021-11-06 10:54:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:24:58 --> Total execution time: 0.0378
DEBUG - 2021-11-06 10:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:55:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 16:25:02 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 791
DEBUG - 2021-11-06 16:25:02 --> Total execution time: 1.5677
DEBUG - 2021-11-06 10:56:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:26:33 --> Total execution time: 0.0498
DEBUG - 2021-11-06 10:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:26:35 --> Total execution time: 0.0737
DEBUG - 2021-11-06 10:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 10:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 10:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:26:45 --> Total execution time: 0.8441
DEBUG - 2021-11-06 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:31:30 --> Total execution time: 0.0402
DEBUG - 2021-11-06 11:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:31:42 --> Total execution time: 0.0435
DEBUG - 2021-11-06 11:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:31:51 --> Total execution time: 0.0361
DEBUG - 2021-11-06 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:32:41 --> Total execution time: 1.6265
DEBUG - 2021-11-06 11:34:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:34:40 --> No URI present. Default controller set.
DEBUG - 2021-11-06 11:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:04:40 --> Total execution time: 0.0365
DEBUG - 2021-11-06 11:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 11:34:41 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 11:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:34:41 --> No URI present. Default controller set.
DEBUG - 2021-11-06 11:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:04:41 --> Total execution time: 0.0317
DEBUG - 2021-11-06 11:35:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 11:35:00 --> Total execution time: 0.0337
DEBUG - 2021-11-06 11:35:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 11:35:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:05:03 --> Total execution time: 0.0583
DEBUG - 2021-11-06 11:35:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:05:08 --> Total execution time: 0.3872
DEBUG - 2021-11-06 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:05:17 --> Total execution time: 0.0370
DEBUG - 2021-11-06 11:45:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:15:29 --> Total execution time: 0.2205
DEBUG - 2021-11-06 11:45:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:15:34 --> Total execution time: 0.0339
DEBUG - 2021-11-06 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 11:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 11:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:15:39 --> Total execution time: 0.0324
DEBUG - 2021-11-06 12:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:34:58 --> Total execution time: 0.0356
DEBUG - 2021-11-06 12:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:35:28 --> Total execution time: 0.0359
DEBUG - 2021-11-06 12:06:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:36:40 --> Total execution time: 0.0621
DEBUG - 2021-11-06 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:36:42 --> Total execution time: 0.0441
DEBUG - 2021-11-06 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:13:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 12:13:55 --> 404 Page Not Found: Api-send-file-with-message-group/index
DEBUG - 2021-11-06 12:14:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:44:11 --> Total execution time: 0.0384
DEBUG - 2021-11-06 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:44:16 --> Total execution time: 0.0413
DEBUG - 2021-11-06 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:44:22 --> Total execution time: 4.1638
DEBUG - 2021-11-06 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:47:13 --> Total execution time: 0.0396
DEBUG - 2021-11-06 12:17:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 12:17:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:47:19 --> Total execution time: 0.0400
DEBUG - 2021-11-06 12:17:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:47:50 --> Total execution time: 0.0367
DEBUG - 2021-11-06 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:51:37 --> Total execution time: 0.0572
DEBUG - 2021-11-06 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:51:43 --> Total execution time: 0.0397
DEBUG - 2021-11-06 12:21:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:21:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 17:51:47 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 883
DEBUG - 2021-11-06 17:51:47 --> Total execution time: 1.3683
DEBUG - 2021-11-06 12:22:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:52:24 --> Total execution time: 1.4490
DEBUG - 2021-11-06 12:24:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:54:55 --> Total execution time: 0.0456
DEBUG - 2021-11-06 12:24:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:54:57 --> Total execution time: 0.0315
DEBUG - 2021-11-06 12:26:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 12:26:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:56:27 --> Total execution time: 0.0419
DEBUG - 2021-11-06 12:28:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:58:06 --> Total execution time: 0.0491
DEBUG - 2021-11-06 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:58:12 --> Total execution time: 0.0385
DEBUG - 2021-11-06 12:28:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:28:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 17:58:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 928
DEBUG - 2021-11-06 17:58:14 --> Total execution time: 0.8271
DEBUG - 2021-11-06 12:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:59:18 --> Total execution time: 1.2429
DEBUG - 2021-11-06 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 17:59:24 --> Total execution time: 0.1175
DEBUG - 2021-11-06 12:29:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:29:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 12:29:25 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-06 12:30:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:00:18 --> Total execution time: 2.4786
DEBUG - 2021-11-06 12:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:01:03 --> Total execution time: 0.8270
DEBUG - 2021-11-06 12:31:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:01:26 --> Total execution time: 0.0605
DEBUG - 2021-11-06 12:32:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:02:22 --> Total execution time: 0.0456
DEBUG - 2021-11-06 12:35:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:35:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:05:53 --> Severity: Compile Error --> Cannot redeclare SendMessageGroup() (previously declared in /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php:910) /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 996
DEBUG - 2021-11-06 12:36:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:06:12 --> Total execution time: 0.1032
DEBUG - 2021-11-06 12:36:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:06:17 --> Total execution time: 0.0338
DEBUG - 2021-11-06 12:36:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:36:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:06:19 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 973
DEBUG - 2021-11-06 18:06:19 --> Total execution time: 0.6898
DEBUG - 2021-11-06 12:37:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:07:07 --> Total execution time: 1.9734
DEBUG - 2021-11-06 12:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:07:08 --> {"session_id":"20211106162122728980","body":{"id":"3EB035A396495E4EB09A","serialized":"false_120363039621385092@g.us_3EB035A396495E4EB09A","numberRegistered":"917501561206","numberFrom":"120363039621385092","photoProfile":"","name":"Test 123 Group","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636202227,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 18:07:08 --> Total execution time: 0.1626
DEBUG - 2021-11-06 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:38:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:08:05 --> Severity: error --> Exception: syntax error, unexpected ''status' (T_ENCAPSED_AND_WHITESPACE), expecting ']' /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 268
DEBUG - 2021-11-06 12:38:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:38:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:08:07 --> Severity: error --> Exception: Call to undefined function CreateGroup() /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/API/API_Controller.php 259
ERROR - 2021-11-06 18:08:07 --> Severity: Compile Warning --> Unterminated comment starting line 321 /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 321
DEBUG - 2021-11-06 12:38:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:08:14 --> Total execution time: 1.8601
DEBUG - 2021-11-06 12:38:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:08:15 --> {"session_id":"20211106162122728980","body":{"id":"3EB02641E78ECC03B4BF","serialized":"false_120363020011340815@g.us_3EB02641E78ECC03B4BF","numberRegistered":"917501561206","numberFrom":"120363020011340815","photoProfile":"","name":"Test 123 Group","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636202294,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 18:08:15 --> Total execution time: 0.0371
DEBUG - 2021-11-06 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:09:15 --> Total execution time: 0.0401
DEBUG - 2021-11-06 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 12:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:09:41 --> Total execution time: 0.0459
DEBUG - 2021-11-06 12:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:10:01 --> Total execution time: 0.0395
DEBUG - 2021-11-06 12:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 12:40:01 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-06 12:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:10:30 --> Total execution time: 0.0456
DEBUG - 2021-11-06 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:14:23 --> Total execution time: 0.0544
DEBUG - 2021-11-06 12:44:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:14:51 --> Total execution time: 0.0475
DEBUG - 2021-11-06 12:44:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:14:54 --> Total execution time: 1.5745
DEBUG - 2021-11-06 12:45:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:15:12 --> Total execution time: 0.0369
DEBUG - 2021-11-06 12:45:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 12:45:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:15:19 --> Total execution time: 0.0565
DEBUG - 2021-11-06 12:45:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:15:56 --> Total execution time: 0.0364
DEBUG - 2021-11-06 12:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:46:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:16:14 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-06 18:16:14 --> Total execution time: 1.2411
DEBUG - 2021-11-06 12:46:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:46:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:17:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-06 18:17:00 --> Total execution time: 1.1843
DEBUG - 2021-11-06 12:48:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:18:34 --> {"session_id":"20211106162122728980","body":{"id":"3EB07129A55937DCFE35","serialized":"false_120363038415064078@g.us_3EB07129A55937DCFE35","numberRegistered":"917501561206","numberFrom":"120363038415064078","photoProfile":"","name":"Test api","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636202913,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 18:18:34 --> Total execution time: 0.0425
DEBUG - 2021-11-06 12:48:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:48:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:18:39 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-06 18:18:39 --> Total execution time: 1.3052
DEBUG - 2021-11-06 12:48:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:48:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:18:58 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-06 18:18:58 --> Total execution time: 1.5258
DEBUG - 2021-11-06 12:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:49:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:19:38 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-06 18:19:38 --> Total execution time: 1.3930
DEBUG - 2021-11-06 12:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:49:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:19:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-06 18:19:46 --> Total execution time: 1.1454
DEBUG - 2021-11-06 12:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:21:21 --> Total execution time: 0.0512
DEBUG - 2021-11-06 12:52:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:52:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:22:18 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-06 18:22:18 --> Total execution time: 1.8914
DEBUG - 2021-11-06 12:53:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:53:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:23:03 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 655
DEBUG - 2021-11-06 18:23:03 --> Total execution time: 1.3168
DEBUG - 2021-11-06 12:53:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:53:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:23:48 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 656
DEBUG - 2021-11-06 18:23:48 --> Total execution time: 1.3311
DEBUG - 2021-11-06 12:54:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:24:04 --> Total execution time: 1.4541
DEBUG - 2021-11-06 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:24:40 --> Total execution time: 1.4517
DEBUG - 2021-11-06 12:54:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 12:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 12:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:24:43 --> Total execution time: 1.3721
DEBUG - 2021-11-06 13:00:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:30:12 --> Total execution time: 1.3201
DEBUG - 2021-11-06 13:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:00:19 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-06 13:00:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:30:25 --> Total execution time: 0.0494
DEBUG - 2021-11-06 13:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:00:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:00:26 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-06 13:11:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:41:49 --> Total execution time: 0.0486
DEBUG - 2021-11-06 13:15:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:45:54 --> Total execution time: 0.1689
DEBUG - 2021-11-06 13:16:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 13:16:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:46:56 --> Total execution time: 0.0401
DEBUG - 2021-11-06 13:22:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:22:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:22:12 --> Severity: error --> Exception: syntax error, unexpected ';' /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Front/Instance_Controller.php 64
DEBUG - 2021-11-06 13:22:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:52:33 --> Total execution time: 0.0529
DEBUG - 2021-11-06 13:22:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:22:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:22:36 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 13:23:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:23:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 18:53:57 --> Severity: Notice --> Undefined variable: session_id /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Front/Instance_Controller.php 68
DEBUG - 2021-11-06 18:53:57 --> Total execution time: 0.5152
DEBUG - 2021-11-06 13:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:54:44 --> Total execution time: 0.6865
DEBUG - 2021-11-06 13:25:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:11 --> Total execution time: 0.0533
DEBUG - 2021-11-06 13:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 13:25:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:15 --> Total execution time: 1.1029
DEBUG - 2021-11-06 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:16 --> Total execution time: 0.0648
DEBUG - 2021-11-06 13:25:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:17 --> Total execution time: 0.0331
DEBUG - 2021-11-06 13:25:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:18 --> Total execution time: 0.0452
DEBUG - 2021-11-06 13:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:19 --> Total execution time: 0.0363
DEBUG - 2021-11-06 13:25:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:20 --> Total execution time: 0.0407
DEBUG - 2021-11-06 13:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:21 --> Total execution time: 0.0486
DEBUG - 2021-11-06 13:25:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:22 --> Total execution time: 0.0383
DEBUG - 2021-11-06 13:25:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:23 --> Total execution time: 0.0607
DEBUG - 2021-11-06 13:25:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:23 --> Total execution time: 0.1921
DEBUG - 2021-11-06 13:25:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:24 --> Total execution time: 0.0355
DEBUG - 2021-11-06 13:25:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:25 --> Total execution time: 0.0503
DEBUG - 2021-11-06 13:25:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:26 --> Total execution time: 0.0391
DEBUG - 2021-11-06 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:27 --> Total execution time: 0.0362
DEBUG - 2021-11-06 13:25:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:28 --> Total execution time: 0.0332
DEBUG - 2021-11-06 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:29 --> Total execution time: 0.0331
DEBUG - 2021-11-06 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:30 --> Total execution time: 0.0363
DEBUG - 2021-11-06 13:25:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:31 --> Total execution time: 0.0443
DEBUG - 2021-11-06 13:25:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:33 --> Total execution time: 0.0376
DEBUG - 2021-11-06 13:25:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:33 --> Total execution time: 0.0364
DEBUG - 2021-11-06 13:25:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:35 --> Total execution time: 0.0471
DEBUG - 2021-11-06 13:25:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:35 --> Total execution time: 0.0443
DEBUG - 2021-11-06 13:25:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:36 --> Total execution time: 0.0300
DEBUG - 2021-11-06 13:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:36 --> Total execution time: 0.0377
DEBUG - 2021-11-06 13:25:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 13:25:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:36 --> Total execution time: 0.0329
DEBUG - 2021-11-06 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 18:55:39 --> Total execution time: 0.0312
DEBUG - 2021-11-06 13:34:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:04:18 --> Total execution time: 0.0464
DEBUG - 2021-11-06 13:34:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:04:21 --> Total execution time: 0.0408
DEBUG - 2021-11-06 13:34:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:34:22 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 13:35:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:05:49 --> Total execution time: 1.9529
DEBUG - 2021-11-06 13:35:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:05:52 --> {"session_id":"20211106162122728980","body":{"id":"3EB0FAFB44CB378244FF","serialized":"false_919091982795@c.us_3EB0FAFB44CB378244FF","numberRegistered":"917501561206","numberFrom":"919091982795","photoProfile":"https:\/\/pps.whatsapp.net\/v\/t61.24694-24\/186853013_593855165092190_2348862871019494260_n.jpg?ccb=11-4&oh=f5a1594353093710267f1b3239e6a6d8&oe=618B9E15","name":"Dinesh Barman","pushName":"Dinesh Barman","isGroup":false,"participantsGroup":"","unreadCount":1,"hasMedia":false,"mediaKey":"","url_file":"","type":"chat","body":"Hi Dinesh Barman,\r\nYour OTP is 284268 from WHATSAPP API site.","sendBy":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636205749,"broadcast":false,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":true,"isWAContact":true,"isBusiness":false,"isEnterprise":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 19:05:52 --> Total execution time: 0.0299
DEBUG - 2021-11-06 13:36:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:06:20 --> Total execution time: 0.0537
DEBUG - 2021-11-06 13:36:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:36:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:36:21 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:07:56 --> Total execution time: 0.0532
DEBUG - 2021-11-06 13:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:07:59 --> Total execution time: 0.0391
DEBUG - 2021-11-06 13:38:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:08:08 --> Total execution time: 1.2182
DEBUG - 2021-11-06 13:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:08:42 --> Total execution time: 1.1740
DEBUG - 2021-11-06 13:38:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:08:44 --> Total execution time: 0.1246
DEBUG - 2021-11-06 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:38:45 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 13:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:38:45 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:08:45 --> Total execution time: 0.3462
DEBUG - 2021-11-06 13:40:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:10:49 --> Total execution time: 0.1402
DEBUG - 2021-11-06 13:40:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:40:50 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 13:40:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 13:40:50 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:10:52 --> Total execution time: 0.0439
DEBUG - 2021-11-06 13:40:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:10:54 --> Total execution time: 0.0522
DEBUG - 2021-11-06 13:40:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:10:57 --> Total execution time: 1.6972
DEBUG - 2021-11-06 13:40:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:10:58 --> Total execution time: 0.0391
DEBUG - 2021-11-06 13:40:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:10:58 --> Total execution time: 0.0453
DEBUG - 2021-11-06 13:40:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:10:59 --> Total execution time: 0.0381
DEBUG - 2021-11-06 13:41:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:01 --> Total execution time: 0.0455
DEBUG - 2021-11-06 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:01 --> Total execution time: 0.0338
DEBUG - 2021-11-06 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:01 --> Total execution time: 0.0771
DEBUG - 2021-11-06 13:41:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:02 --> Total execution time: 0.0369
DEBUG - 2021-11-06 13:41:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:03 --> Total execution time: 0.0333
DEBUG - 2021-11-06 13:41:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:04 --> Total execution time: 0.0511
DEBUG - 2021-11-06 13:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:05 --> Total execution time: 0.0326
DEBUG - 2021-11-06 13:41:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:06 --> Total execution time: 0.0494
DEBUG - 2021-11-06 13:41:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:07 --> Total execution time: 0.0366
DEBUG - 2021-11-06 13:41:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:09 --> Total execution time: 0.0382
DEBUG - 2021-11-06 13:41:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:10 --> Total execution time: 0.0323
DEBUG - 2021-11-06 13:41:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:10 --> Total execution time: 0.0348
DEBUG - 2021-11-06 13:41:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:11 --> Total execution time: 0.0348
DEBUG - 2021-11-06 13:41:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:12 --> Total execution time: 0.0378
DEBUG - 2021-11-06 13:41:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:12 --> Total execution time: 0.0342
DEBUG - 2021-11-06 13:41:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:11:50 --> Total execution time: 0.0397
DEBUG - 2021-11-06 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:12:38 --> Total execution time: 1.7959
DEBUG - 2021-11-06 13:42:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:12:40 --> {"session_id":"20211106191056529933","body":{"id":"3EB04A66468EA6A134F7","serialized":"false_120363020872863836@g.us_3EB04A66468EA6A134F7","numberRegistered":"917501561206","numberFrom":"120363020872863836","photoProfile":"","name":"Your Group Name","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636206159,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 19:12:40 --> Total execution time: 0.0328
DEBUG - 2021-11-06 13:42:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:12:54 --> Total execution time: 0.0348
DEBUG - 2021-11-06 13:43:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:13:26 --> Total execution time: 0.1018
DEBUG - 2021-11-06 13:43:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:13:35 --> Total execution time: 0.9556
DEBUG - 2021-11-06 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:14:26 --> Total execution time: 0.0360
DEBUG - 2021-11-06 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:14:39 --> Total execution time: 1.9136
DEBUG - 2021-11-06 13:44:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:14:54 --> Total execution time: 0.0433
DEBUG - 2021-11-06 13:45:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:15:02 --> Total execution time: 1.8302
DEBUG - 2021-11-06 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:15:09 --> {"session_id":"20211106191056529933","body":{"id":"3EB06527171054D12A79","serialized":"false_120363041611356310@g.us_3EB06527171054D12A79","numberRegistered":"917501561206","numberFrom":"120363041611356310","photoProfile":"","name":"Test 123 Group","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636206302,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 19:15:09 --> Total execution time: 0.0290
DEBUG - 2021-11-06 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:15:14 --> Total execution time: 0.0291
DEBUG - 2021-11-06 13:45:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:15:28 --> Total execution time: 0.8323
DEBUG - 2021-11-06 13:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:16:35 --> Total execution time: 0.8319
DEBUG - 2021-11-06 13:49:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 13:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 13:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:19:04 --> Total execution time: 0.8278
DEBUG - 2021-11-06 14:00:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:30:44 --> {"session_id":"20211106191056529933","body":{"id":"3EB00D86A0FF6225D717","serialized":"false_120363037133809022@g.us_3EB00D86A0FF6225D717","numberRegistered":"917501561206","numberFrom":"120363037133809022","photoProfile":"","name":"Test api","pushName":"","isGroup":true,"participantsGroup":2,"unreadCount":0,"hasMedia":false,"mediaKey":"","url_file":"","type":"e2e_notification","body":"","isForwarded":false,"isStatus":false,"isStarred":false,"location":"","timestamp":1636207243,"fromMe":false,"hasQuotedMsg":false,"vCards":[],"mentionedIds":[],"links":[],"isBlocked":false,"isMyContact":false,"isWAContact":false,"selectedButtonId":""},"number":"917501561206"}
DEBUG - 2021-11-06 19:30:44 --> Total execution time: 0.0376
DEBUG - 2021-11-06 14:00:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:30:51 --> Total execution time: 1.0449
DEBUG - 2021-11-06 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:32:34 --> Total execution time: 0.0681
DEBUG - 2021-11-06 14:07:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:37:27 --> Total execution time: 0.0523
DEBUG - 2021-11-06 14:07:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:37:32 --> Total execution time: 0.0376
DEBUG - 2021-11-06 14:07:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:37:34 --> Total execution time: 0.0442
DEBUG - 2021-11-06 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:38:10 --> Total execution time: 0.0460
DEBUG - 2021-11-06 14:08:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:38:46 --> Total execution time: 2.1320
DEBUG - 2021-11-06 14:09:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:39:55 --> Total execution time: 2.0967
DEBUG - 2021-11-06 14:10:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:40:13 --> Total execution time: 0.0511
DEBUG - 2021-11-06 14:10:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 14:10:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:40:25 --> Total execution time: 0.0413
DEBUG - 2021-11-06 14:10:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:40:42 --> Total execution time: 0.0383
DEBUG - 2021-11-06 14:13:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:43:25 --> Total execution time: 0.0570
DEBUG - 2021-11-06 14:13:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:43:42 --> Total execution time: 0.0379
DEBUG - 2021-11-06 14:13:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:43:46 --> Total execution time: 2.0737
DEBUG - 2021-11-06 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:44:01 --> Total execution time: 0.0359
DEBUG - 2021-11-06 14:14:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:44:09 --> Total execution time: 0.0443
DEBUG - 2021-11-06 14:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 14:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:44:20 --> Total execution time: 0.0469
DEBUG - 2021-11-06 14:17:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:47:54 --> Total execution time: 0.0361
DEBUG - 2021-11-06 14:20:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:50:56 --> Total execution time: 0.1668
DEBUG - 2021-11-06 14:20:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:50:59 --> Total execution time: 0.0345
DEBUG - 2021-11-06 14:21:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:51:03 --> Total execution time: 1.6476
DEBUG - 2021-11-06 14:21:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:51:20 --> Total execution time: 0.0336
DEBUG - 2021-11-06 14:21:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 14:21:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:51:25 --> Total execution time: 0.0352
DEBUG - 2021-11-06 14:21:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:51:48 --> Total execution time: 0.0493
DEBUG - 2021-11-06 14:24:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:54:26 --> Total execution time: 0.0736
DEBUG - 2021-11-06 14:24:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:54:39 --> Total execution time: 0.0413
DEBUG - 2021-11-06 14:24:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:54:42 --> Total execution time: 0.0327
DEBUG - 2021-11-06 14:24:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:25:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 19:55:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 1396
DEBUG - 2021-11-06 19:55:46 --> Total execution time: 60.6099
ERROR - 2021-11-06 19:55:46 --> Severity: Warning --> Error while sending QUERY packet. PID=7070 /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/system/database/drivers/mysqli/mysqli_driver.php 305
ERROR - 2021-11-06 19:55:46 --> Query error: MySQL server has gone away - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1636208746
WHERE `id` = '88460e331a415731053d16941151e7dcddb53d5e'
ERROR - 2021-11-06 19:55:46 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-11-06 19:55:46 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: /opt/alt/php72/var/lib/php/session) Unknown 0
ERROR - 2021-11-06 19:55:46 --> Query error: MySQL server has gone away - Invalid query: SELECT RELEASE_LOCK('5c371869580f540438ac2187fd439220') AS ci_session_lock
ERROR - 2021-11-06 19:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/system/core/Common.php 570
ERROR - 2021-11-06 19:55:46 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/helpers/api_helper.php 1396
DEBUG - 2021-11-06 19:55:46 --> Total execution time: 27.3463
DEBUG - 2021-11-06 14:26:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:56:20 --> Total execution time: 1.5584
DEBUG - 2021-11-06 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:57:24 --> Total execution time: 0.0368
DEBUG - 2021-11-06 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:59:04 --> Total execution time: 0.0554
DEBUG - 2021-11-06 14:29:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:59:22 --> Total execution time: 0.7846
DEBUG - 2021-11-06 14:29:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 14:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 14:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 19:59:28 --> Total execution time: 0.0338
DEBUG - 2021-11-06 15:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:02:04 --> Total execution time: 0.2020
DEBUG - 2021-11-06 15:33:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:33:21 --> Total execution time: 0.0522
DEBUG - 2021-11-06 15:35:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:35:24 --> Total execution time: 0.0578
DEBUG - 2021-11-06 15:50:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:50:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:20:19 --> Total execution time: 0.0446
DEBUG - 2021-11-06 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:20:23 --> Total execution time: 0.1664
DEBUG - 2021-11-06 15:50:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:20:33 --> Total execution time: 0.0632
DEBUG - 2021-11-06 15:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:20:36 --> Total execution time: 0.1603
DEBUG - 2021-11-06 15:50:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:20:41 --> Total execution time: 0.0811
DEBUG - 2021-11-06 15:50:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:20:47 --> Total execution time: 0.0383
DEBUG - 2021-11-06 15:50:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:20:53 --> Total execution time: 0.0726
DEBUG - 2021-11-06 15:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:21:19 --> Total execution time: 0.1472
DEBUG - 2021-11-06 15:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:21:25 --> Total execution time: 0.0303
DEBUG - 2021-11-06 15:51:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:21:41 --> Total execution time: 0.0554
DEBUG - 2021-11-06 15:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:21:45 --> Total execution time: 1.1574
DEBUG - 2021-11-06 15:51:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:51:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:21:53 --> Total execution time: 0.0810
DEBUG - 2021-11-06 15:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:22:00 --> Total execution time: 0.0836
DEBUG - 2021-11-06 15:52:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:22:57 --> Total execution time: 0.2050
DEBUG - 2021-11-06 15:53:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:23:01 --> Total execution time: 0.0454
DEBUG - 2021-11-06 15:53:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:23:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-06 15:53:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:23:22 --> Total execution time: 0.0358
DEBUG - 2021-11-06 15:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:23:46 --> Total execution time: 0.0447
DEBUG - 2021-11-06 15:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:36 --> Total execution time: 0.0328
DEBUG - 2021-11-06 15:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:39 --> Total execution time: 1.0647
DEBUG - 2021-11-06 15:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:40 --> Total execution time: 0.2265
DEBUG - 2021-11-06 15:56:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:41 --> Total execution time: 0.0376
DEBUG - 2021-11-06 15:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:42 --> Total execution time: 0.0383
DEBUG - 2021-11-06 15:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:43 --> Total execution time: 0.0383
DEBUG - 2021-11-06 15:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:43 --> Total execution time: 0.0305
DEBUG - 2021-11-06 15:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:44 --> Total execution time: 0.0478
DEBUG - 2021-11-06 15:56:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:48 --> Total execution time: 1.0468
DEBUG - 2021-11-06 15:56:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:48 --> Total execution time: 0.0365
DEBUG - 2021-11-06 15:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:49 --> Total execution time: 0.0366
DEBUG - 2021-11-06 15:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:50 --> Total execution time: 0.0335
DEBUG - 2021-11-06 15:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 21:26:52 --> Total execution time: 1.0540
DEBUG - 2021-11-06 15:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:52 --> Total execution time: 0.4954
DEBUG - 2021-11-06 15:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:52 --> Total execution time: 0.0330
DEBUG - 2021-11-06 15:56:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:53 --> Total execution time: 0.0331
DEBUG - 2021-11-06 15:56:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:54 --> Total execution time: 0.0464
DEBUG - 2021-11-06 15:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:55 --> Total execution time: 0.0387
DEBUG - 2021-11-06 15:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:55 --> Total execution time: 0.0404
DEBUG - 2021-11-06 15:56:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:56 --> Total execution time: 0.1218
DEBUG - 2021-11-06 15:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:57 --> Total execution time: 0.0407
DEBUG - 2021-11-06 15:56:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:58 --> Total execution time: 0.0338
DEBUG - 2021-11-06 15:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:26:59 --> Total execution time: 0.0381
DEBUG - 2021-11-06 15:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:00 --> Total execution time: 0.0316
DEBUG - 2021-11-06 15:57:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:01 --> Total execution time: 0.2413
DEBUG - 2021-11-06 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:02 --> Total execution time: 0.0476
DEBUG - 2021-11-06 15:57:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:03 --> Total execution time: 0.0413
DEBUG - 2021-11-06 15:57:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:04 --> Total execution time: 0.0342
DEBUG - 2021-11-06 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:05 --> Total execution time: 0.0327
DEBUG - 2021-11-06 15:57:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:06 --> Total execution time: 0.0343
DEBUG - 2021-11-06 15:57:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:07 --> Total execution time: 0.0369
DEBUG - 2021-11-06 15:57:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:08 --> Total execution time: 0.0429
DEBUG - 2021-11-06 15:57:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:09 --> Total execution time: 0.0385
DEBUG - 2021-11-06 15:57:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:10 --> Total execution time: 0.0355
DEBUG - 2021-11-06 15:57:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:11 --> Total execution time: 0.0332
DEBUG - 2021-11-06 15:57:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:12 --> Total execution time: 0.0350
DEBUG - 2021-11-06 15:57:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:13 --> Total execution time: 0.0318
DEBUG - 2021-11-06 15:57:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:14 --> Total execution time: 0.0340
DEBUG - 2021-11-06 15:57:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:14 --> Total execution time: 0.0440
DEBUG - 2021-11-06 15:57:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:15 --> Total execution time: 0.2151
DEBUG - 2021-11-06 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:16 --> Total execution time: 0.0324
DEBUG - 2021-11-06 15:57:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:17 --> Total execution time: 0.0370
DEBUG - 2021-11-06 15:57:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:18 --> Total execution time: 0.0309
DEBUG - 2021-11-06 15:57:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:18 --> Total execution time: 0.0344
DEBUG - 2021-11-06 15:57:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:57:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:18 --> Total execution time: 0.0302
DEBUG - 2021-11-06 15:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:27:30 --> Total execution time: 0.0352
DEBUG - 2021-11-06 15:58:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:58:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:58:04 --> Total execution time: 0.0526
DEBUG - 2021-11-06 15:58:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:08 --> No URI present. Default controller set.
DEBUG - 2021-11-06 15:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:28:08 --> Total execution time: 0.0750
DEBUG - 2021-11-06 15:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:09 --> No URI present. Default controller set.
DEBUG - 2021-11-06 15:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 15:58:09 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 15:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:28:09 --> Total execution time: 0.0324
DEBUG - 2021-11-06 15:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:27 --> No URI present. Default controller set.
DEBUG - 2021-11-06 15:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:28:27 --> Total execution time: 0.0332
DEBUG - 2021-11-06 15:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 15:58:27 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 15:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:58:27 --> No URI present. Default controller set.
DEBUG - 2021-11-06 15:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:28:27 --> Total execution time: 0.0454
DEBUG - 2021-11-06 15:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:59:08 --> Total execution time: 0.0350
DEBUG - 2021-11-06 15:59:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:59:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:29:13 --> Total execution time: 0.0382
DEBUG - 2021-11-06 15:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:29:32 --> Total execution time: 0.0504
DEBUG - 2021-11-06 15:59:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:59:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 15:59:47 --> Total execution time: 0.0315
DEBUG - 2021-11-06 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:55 --> No URI present. Default controller set.
DEBUG - 2021-11-06 15:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:29:55 --> Total execution time: 0.0301
DEBUG - 2021-11-06 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 15:59:55 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 15:59:55 --> No URI present. Default controller set.
DEBUG - 2021-11-06 15:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 15:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:29:55 --> Total execution time: 0.0278
DEBUG - 2021-11-06 16:00:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 16:00:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:00:16 --> No URI present. Default controller set.
DEBUG - 2021-11-06 16:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:30:16 --> Total execution time: 0.0432
DEBUG - 2021-11-06 16:00:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:00:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-06 16:00:17 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-06 16:00:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:00:17 --> No URI present. Default controller set.
DEBUG - 2021-11-06 16:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:30:17 --> Total execution time: 0.0446
DEBUG - 2021-11-06 16:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:02:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 21:32:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Account_details /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/system/core/Loader.php 348
DEBUG - 2021-11-06 16:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:02:03 --> No URI present. Default controller set.
DEBUG - 2021-11-06 16:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:32:03 --> Total execution time: 0.0737
DEBUG - 2021-11-06 16:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:02:03 --> No URI present. Default controller set.
DEBUG - 2021-11-06 16:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:32:03 --> Total execution time: 0.0676
DEBUG - 2021-11-06 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:02:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-06 21:32:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Account_details /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/system/core/Loader.php 348
DEBUG - 2021-11-06 16:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:02:11 --> No URI present. Default controller set.
DEBUG - 2021-11-06 16:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:32:11 --> Total execution time: 0.0348
DEBUG - 2021-11-06 16:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-06 16:02:11 --> No URI present. Default controller set.
DEBUG - 2021-11-06 16:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-06 16:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-06 21:32:11 --> Total execution time: 0.0366
