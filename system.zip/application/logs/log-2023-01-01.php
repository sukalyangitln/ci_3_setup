<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-01 00:00:02 --> Total execution time: 0.0991
DEBUG - 2023-01-01 00:00:34 --> Total execution time: 0.0970
DEBUG - 2023-01-01 00:01:14 --> Total execution time: 0.1058
DEBUG - 2023-01-01 00:01:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 00:01:20 --> You did not select a file to upload.
DEBUG - 2023-01-01 00:01:20 --> You did not select a file to upload.
DEBUG - 2023-01-01 00:01:20 --> Total execution time: 0.0938
DEBUG - 2023-01-01 00:01:22 --> Total execution time: 0.1047
DEBUG - 2023-01-01 00:01:48 --> Total execution time: 0.1233
DEBUG - 2023-01-01 00:02:01 --> Total execution time: 0.1120
DEBUG - 2023-01-01 00:02:24 --> Total execution time: 0.1051
DEBUG - 2023-01-01 00:02:38 --> Total execution time: 0.0980
DEBUG - 2023-01-01 00:02:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 00:02:46 --> You did not select a file to upload.
DEBUG - 2023-01-01 00:02:46 --> You did not select a file to upload.
DEBUG - 2023-01-01 00:02:46 --> Total execution time: 0.0877
DEBUG - 2023-01-01 00:02:48 --> Total execution time: 0.1025
DEBUG - 2023-01-01 00:03:24 --> Total execution time: 0.1062
DEBUG - 2023-01-01 00:06:16 --> Total execution time: 0.1074
DEBUG - 2023-01-01 00:06:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 00:06:27 --> You did not select a file to upload.
DEBUG - 2023-01-01 00:06:27 --> You did not select a file to upload.
DEBUG - 2023-01-01 00:06:28 --> Total execution time: 0.1283
DEBUG - 2023-01-01 00:06:29 --> Total execution time: 0.1247
DEBUG - 2023-01-01 00:06:43 --> Total execution time: 0.0894
DEBUG - 2023-01-01 00:06:47 --> Total execution time: 0.1045
DEBUG - 2023-01-01 00:07:06 --> Total execution time: 0.0884
DEBUG - 2023-01-01 00:07:09 --> Total execution time: 0.0879
DEBUG - 2023-01-01 00:07:44 --> Total execution time: 0.1202
DEBUG - 2023-01-01 00:07:50 --> Total execution time: 0.0972
DEBUG - 2023-01-01 00:08:57 --> Total execution time: 0.1033
DEBUG - 2023-01-01 00:09:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 00:09:06 --> You did not select a file to upload.
DEBUG - 2023-01-01 00:09:06 --> Total execution time: 0.0896
DEBUG - 2023-01-01 00:09:08 --> Total execution time: 0.1055
DEBUG - 2023-01-01 00:09:26 --> Total execution time: 0.0960
DEBUG - 2023-01-01 00:09:53 --> Total execution time: 0.0916
DEBUG - 2023-01-01 00:11:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 00:11:02 --> You did not select a file to upload.
DEBUG - 2023-01-01 00:11:03 --> Total execution time: 0.0931
DEBUG - 2023-01-01 00:11:04 --> Total execution time: 0.1097
DEBUG - 2023-01-01 00:12:14 --> Total execution time: 0.1023
DEBUG - 2023-01-01 00:13:46 --> Total execution time: 0.1012
ERROR - 2023-01-01 00:13:58 --> Severity: Notice --> Undefined property: Profile_Controller::$Bank_accounts C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Profile_Controller.php 311
ERROR - 2023-01-01 00:13:58 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Profile_Controller.php 311
DEBUG - 2023-01-01 00:14:07 --> Total execution time: 0.0916
DEBUG - 2023-01-01 00:14:11 --> Total execution time: 0.0851
DEBUG - 2023-01-01 00:14:50 --> Total execution time: 0.1001
DEBUG - 2023-01-01 00:24:59 --> Total execution time: 0.0983
DEBUG - 2023-01-01 00:25:35 --> Total execution time: 0.0926
DEBUG - 2023-01-01 00:26:25 --> Total execution time: 0.1005
DEBUG - 2023-01-01 00:26:43 --> Total execution time: 0.1059
DEBUG - 2023-01-01 00:27:06 --> Total execution time: 0.0988
DEBUG - 2023-01-01 00:29:47 --> Total execution time: 0.1291
DEBUG - 2023-01-01 00:30:15 --> Total execution time: 0.1081
DEBUG - 2023-01-01 00:31:27 --> Total execution time: 0.0886
DEBUG - 2023-01-01 00:31:40 --> Total execution time: 0.0980
DEBUG - 2023-01-01 00:32:18 --> Total execution time: 0.0977
DEBUG - 2023-01-01 00:32:36 --> Total execution time: 0.2283
DEBUG - 2023-01-01 00:33:17 --> Total execution time: 0.0964
DEBUG - 2023-01-01 00:33:19 --> Total execution time: 0.0967
DEBUG - 2023-01-01 00:33:19 --> Total execution time: 0.1213
DEBUG - 2023-01-01 00:34:08 --> Total execution time: 0.0923
DEBUG - 2023-01-01 00:34:35 --> Total execution time: 0.1047
DEBUG - 2023-01-01 00:36:02 --> Total execution time: 0.1002
DEBUG - 2023-01-01 00:36:18 --> Total execution time: 0.0920
DEBUG - 2023-01-01 00:37:37 --> Total execution time: 0.1075
DEBUG - 2023-01-01 00:42:32 --> Total execution time: 0.0836
DEBUG - 2023-01-01 00:42:42 --> Total execution time: 0.0882
DEBUG - 2023-01-01 00:42:45 --> Total execution time: 0.0915
DEBUG - 2023-01-01 00:42:47 --> Total execution time: 0.0976
DEBUG - 2023-01-01 00:44:46 --> Total execution time: 0.1065
DEBUG - 2023-01-01 00:44:53 --> Total execution time: 0.0959
DEBUG - 2023-01-01 00:45:20 --> Total execution time: 0.0989
DEBUG - 2023-01-01 00:45:22 --> Total execution time: 0.0994
DEBUG - 2023-01-01 00:52:09 --> Total execution time: 0.0893
DEBUG - 2023-01-01 00:53:20 --> Total execution time: 0.1001
DEBUG - 2023-01-01 00:56:57 --> Total execution time: 0.0961
DEBUG - 2023-01-01 00:57:29 --> Total execution time: 0.1027
DEBUG - 2023-01-01 00:59:07 --> Total execution time: 0.0968
DEBUG - 2023-01-01 01:02:12 --> Total execution time: 0.1221
DEBUG - 2023-01-01 01:02:20 --> Total execution time: 0.1023
DEBUG - 2023-01-01 01:02:50 --> Total execution time: 0.0979
DEBUG - 2023-01-01 01:03:01 --> Total execution time: 0.0934
DEBUG - 2023-01-01 01:03:23 --> Total execution time: 0.1031
DEBUG - 2023-01-01 01:04:00 --> Total execution time: 0.0982
DEBUG - 2023-01-01 01:05:35 --> Total execution time: 0.1135
DEBUG - 2023-01-01 01:05:38 --> Total execution time: 0.0903
DEBUG - 2023-01-01 01:06:03 --> Total execution time: 0.0916
DEBUG - 2023-01-01 01:06:15 --> Total execution time: 0.0950
DEBUG - 2023-01-01 01:06:17 --> Total execution time: 0.0960
DEBUG - 2023-01-01 01:06:20 --> Total execution time: 0.0958
DEBUG - 2023-01-01 01:06:21 --> Total execution time: 0.0916
DEBUG - 2023-01-01 01:06:26 --> Total execution time: 0.0911
DEBUG - 2023-01-01 01:07:10 --> Total execution time: 0.0957
DEBUG - 2023-01-01 01:07:10 --> Total execution time: 0.0822
DEBUG - 2023-01-01 01:08:30 --> Total execution time: 0.1083
DEBUG - 2023-01-01 01:08:30 --> Total execution time: 0.0918
DEBUG - 2023-01-01 01:11:05 --> Total execution time: 0.1599
DEBUG - 2023-01-01 01:11:18 --> Total execution time: 0.0931
DEBUG - 2023-01-01 01:13:31 --> Total execution time: 0.1016
DEBUG - 2023-01-01 01:18:23 --> Total execution time: 0.0993
DEBUG - 2023-01-01 01:18:31 --> Total execution time: 0.0924
DEBUG - 2023-01-01 01:18:34 --> Total execution time: 0.0865
DEBUG - 2023-01-01 01:18:37 --> Total execution time: 0.0947
DEBUG - 2023-01-01 01:18:37 --> Total execution time: 0.0918
DEBUG - 2023-01-01 01:18:41 --> Total execution time: 0.0882
DEBUG - 2023-01-01 01:18:43 --> Total execution time: 0.0880
DEBUG - 2023-01-01 01:18:45 --> Total execution time: 0.0975
DEBUG - 2023-01-01 01:18:47 --> Total execution time: 0.0905
DEBUG - 2023-01-01 01:18:49 --> Total execution time: 0.0922
DEBUG - 2023-01-01 01:19:00 --> Total execution time: 0.0841
DEBUG - 2023-01-01 01:19:02 --> Total execution time: 0.0871
DEBUG - 2023-01-01 01:19:05 --> Total execution time: 0.0972
DEBUG - 2023-01-01 01:21:09 --> Total execution time: 0.0959
DEBUG - 2023-01-01 01:21:10 --> Total execution time: 0.1138
DEBUG - 2023-01-01 01:21:12 --> Total execution time: 0.0881
DEBUG - 2023-01-01 01:21:15 --> Total execution time: 0.0948
DEBUG - 2023-01-01 01:21:28 --> Total execution time: 0.0875
DEBUG - 2023-01-01 01:22:26 --> Total execution time: 0.1033
DEBUG - 2023-01-01 01:27:44 --> Total execution time: 0.0970
DEBUG - 2023-01-01 01:47:01 --> Total execution time: 0.0985
DEBUG - 2023-01-01 01:47:29 --> Total execution time: 0.0934
DEBUG - 2023-01-01 02:08:25 --> Total execution time: 0.0885
DEBUG - 2023-01-01 02:08:39 --> Total execution time: 0.0868
DEBUG - 2023-01-01 02:08:52 --> Total execution time: 0.0879
DEBUG - 2023-01-01 02:09:05 --> Total execution time: 0.1255
DEBUG - 2023-01-01 02:09:06 --> Total execution time: 0.0913
DEBUG - 2023-01-01 02:09:14 --> Total execution time: 0.0896
DEBUG - 2023-01-01 02:09:46 --> Total execution time: 0.0917
DEBUG - 2023-01-01 02:09:52 --> Total execution time: 0.0916
DEBUG - 2023-01-01 02:10:16 --> Total execution time: 0.0861
DEBUG - 2023-01-01 02:14:34 --> Total execution time: 0.0998
DEBUG - 2023-01-01 02:14:47 --> Total execution time: 0.1033
DEBUG - 2023-01-01 02:14:50 --> Total execution time: 0.0914
DEBUG - 2023-01-01 02:14:53 --> Total execution time: 0.0898
DEBUG - 2023-01-01 02:14:57 --> Total execution time: 0.1030
DEBUG - 2023-01-01 02:15:09 --> Total execution time: 0.0895
DEBUG - 2023-01-01 02:15:46 --> Total execution time: 0.0895
DEBUG - 2023-01-01 02:16:49 --> Total execution time: 0.0928
DEBUG - 2023-01-01 02:17:02 --> Total execution time: 0.0911
DEBUG - 2023-01-01 02:17:06 --> Total execution time: 0.0923
DEBUG - 2023-01-01 02:17:34 --> Total execution time: 0.0931
DEBUG - 2023-01-01 02:17:38 --> Total execution time: 0.0918
DEBUG - 2023-01-01 02:17:44 --> Total execution time: 0.0868
DEBUG - 2023-01-01 02:17:47 --> Total execution time: 0.0914
DEBUG - 2023-01-01 02:18:06 --> Total execution time: 0.0955
DEBUG - 2023-01-01 02:20:06 --> Total execution time: 0.1003
DEBUG - 2023-01-01 02:23:17 --> Total execution time: 0.1074
DEBUG - 2023-01-01 02:32:35 --> Total execution time: 0.1232
DEBUG - 2023-01-01 02:32:38 --> Total execution time: 0.0965
DEBUG - 2023-01-01 02:32:41 --> Total execution time: 0.0972
DEBUG - 2023-01-01 02:33:18 --> Total execution time: 0.1086
DEBUG - 2023-01-01 02:34:33 --> Total execution time: 0.1032
DEBUG - 2023-01-01 02:38:35 --> Total execution time: 0.1378
DEBUG - 2023-01-01 02:38:55 --> Total execution time: 0.0951
DEBUG - 2023-01-01 02:39:16 --> Total execution time: 0.1097
DEBUG - 2023-01-01 02:39:37 --> Total execution time: 0.1054
DEBUG - 2023-01-01 02:39:38 --> Total execution time: 0.0942
DEBUG - 2023-01-01 02:39:42 --> Total execution time: 0.1040
DEBUG - 2023-01-01 02:40:07 --> Total execution time: 0.1029
DEBUG - 2023-01-01 02:40:33 --> Total execution time: 0.1346
DEBUG - 2023-01-01 02:40:55 --> Total execution time: 0.0941
DEBUG - 2023-01-01 02:42:30 --> Total execution time: 0.1036
DEBUG - 2023-01-01 02:42:34 --> Total execution time: 0.1045
DEBUG - 2023-01-01 02:42:50 --> Total execution time: 0.1051
DEBUG - 2023-01-01 02:42:52 --> Total execution time: 0.0892
DEBUG - 2023-01-01 02:43:14 --> Total execution time: 0.0871
DEBUG - 2023-01-01 02:43:29 --> Total execution time: 0.1000
DEBUG - 2023-01-01 02:43:35 --> Total execution time: 0.0951
DEBUG - 2023-01-01 02:45:01 --> Total execution time: 0.1066
DEBUG - 2023-01-01 02:46:57 --> Total execution time: 0.1070
DEBUG - 2023-01-01 02:47:22 --> Total execution time: 0.0937
DEBUG - 2023-01-01 02:47:28 --> Total execution time: 0.0925
DEBUG - 2023-01-01 02:47:44 --> Total execution time: 0.1133
DEBUG - 2023-01-01 02:47:50 --> Total execution time: 0.1063
DEBUG - 2023-01-01 02:48:00 --> Total execution time: 0.1115
DEBUG - 2023-01-01 02:48:03 --> Total execution time: 0.1069
DEBUG - 2023-01-01 02:48:12 --> Total execution time: 0.1055
DEBUG - 2023-01-01 02:48:38 --> Total execution time: 0.1282
DEBUG - 2023-01-01 02:48:46 --> Total execution time: 0.0969
DEBUG - 2023-01-01 02:48:49 --> Total execution time: 0.0952
DEBUG - 2023-01-01 02:48:53 --> Total execution time: 0.1213
DEBUG - 2023-01-01 02:49:03 --> Total execution time: 0.1069
DEBUG - 2023-01-01 02:49:08 --> Total execution time: 0.0942
DEBUG - 2023-01-01 02:49:28 --> Total execution time: 0.1042
DEBUG - 2023-01-01 02:49:37 --> Total execution time: 0.0967
DEBUG - 2023-01-01 02:49:42 --> Total execution time: 0.1012
DEBUG - 2023-01-01 02:51:03 --> Total execution time: 0.1046
DEBUG - 2023-01-01 02:51:17 --> Total execution time: 0.1062
DEBUG - 2023-01-01 02:51:31 --> Total execution time: 0.0943
DEBUG - 2023-01-01 02:51:53 --> Total execution time: 0.1124
DEBUG - 2023-01-01 02:52:59 --> Total execution time: 0.1021
DEBUG - 2023-01-01 02:53:06 --> Total execution time: 0.0967
DEBUG - 2023-01-01 02:53:12 --> Total execution time: 0.1209
ERROR - 2023-01-01 02:54:16 --> Severity: Notice --> Undefined variable: kyc C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 25
ERROR - 2023-01-01 02:54:16 --> Severity: Notice --> Undefined variable: kyc C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 32
DEBUG - 2023-01-01 02:54:16 --> Total execution time: 0.1358
ERROR - 2023-01-01 02:54:23 --> Severity: Notice --> Undefined variable: kyc C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 25
DEBUG - 2023-01-01 02:54:23 --> Total execution time: 0.1177
DEBUG - 2023-01-01 02:54:35 --> Total execution time: 0.1043
DEBUG - 2023-01-01 02:54:44 --> Total execution time: 0.0999
DEBUG - 2023-01-01 02:54:55 --> Total execution time: 0.1075
DEBUG - 2023-01-01 02:55:01 --> Total execution time: 0.0887
DEBUG - 2023-01-01 02:55:03 --> Total execution time: 0.0986
DEBUG - 2023-01-01 02:55:05 --> Total execution time: 0.0894
DEBUG - 2023-01-01 02:55:07 --> Total execution time: 0.0889
DEBUG - 2023-01-01 02:55:11 --> Total execution time: 0.0995
DEBUG - 2023-01-01 02:55:15 --> Total execution time: 0.0997
DEBUG - 2023-01-01 02:56:12 --> Total execution time: 0.0982
DEBUG - 2023-01-01 02:59:30 --> Total execution time: 0.1039
ERROR - 2023-01-01 03:00:36 --> Severity: Notice --> Undefined property: stdClass::$p_image_path C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\view\fundraiser-view.php 141
ERROR - 2023-01-01 03:00:36 --> Severity: Notice --> Undefined property: stdClass::$p_image C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\view\fundraiser-view.php 141
ERROR - 2023-01-01 03:00:36 --> Severity: Notice --> Undefined property: stdClass::$p_image_path C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\view\fundraiser-view.php 141
ERROR - 2023-01-01 03:00:36 --> Severity: Notice --> Undefined property: stdClass::$p_image C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\view\fundraiser-view.php 141
DEBUG - 2023-01-01 03:00:36 --> Total execution time: 0.1127
DEBUG - 2023-01-01 03:01:12 --> Total execution time: 0.1009
DEBUG - 2023-01-01 12:52:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 12:52:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 12:52:56 --> Total execution time: 0.1117
DEBUG - 2023-01-01 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 12:52:57 --> Total execution time: 0.0552
DEBUG - 2023-01-01 12:52:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 12:52:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:22:59 --> Total execution time: 0.1280
DEBUG - 2023-01-01 12:52:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:52:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:23:03 --> Total execution time: 0.1474
DEBUG - 2023-01-01 12:53:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:53:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:23:08 --> Total execution time: 0.0643
DEBUG - 2023-01-01 12:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:53:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:54:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:24:49 --> Total execution time: 0.0719
DEBUG - 2023-01-01 12:54:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:54:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:55:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:55:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 17:25:35 --> Severity: Notice --> Undefined variable: lists C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\view\fundraiser-view.php 132
DEBUG - 2023-01-01 17:25:35 --> Total execution time: 0.0649
DEBUG - 2023-01-01 12:55:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:55:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:56:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:26:04 --> Total execution time: 0.0674
DEBUG - 2023-01-01 12:56:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:56:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:56:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:27:05 --> Total execution time: 0.0646
DEBUG - 2023-01-01 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:57:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:57:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:27:10 --> Total execution time: 0.0614
DEBUG - 2023-01-01 12:57:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:57:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:57:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:58:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:28:20 --> Total execution time: 0.0750
DEBUG - 2023-01-01 12:58:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:58:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:58:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:58:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:28:32 --> Total execution time: 0.0668
DEBUG - 2023-01-01 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:58:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:28:35 --> Total execution time: 0.0601
DEBUG - 2023-01-01 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:58:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:59:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:29:10 --> Total execution time: 0.0627
DEBUG - 2023-01-01 12:59:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:59:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:29:19 --> Total execution time: 0.0538
DEBUG - 2023-01-01 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:59:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:59:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 12:59:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 12:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 12:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:29:22 --> Total execution time: 0.0815
DEBUG - 2023-01-01 12:59:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 12:59:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 12:59:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:00:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:30:26 --> Total execution time: 0.0638
DEBUG - 2023-01-01 13:00:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:00:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:00:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:30:28 --> Total execution time: 0.0618
DEBUG - 2023-01-01 13:00:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:00:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:00:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:00:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:00:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 17:30:45 --> Severity: Notice --> Undefined variable: dtl C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\view\fundraiser-view.php 87
ERROR - 2023-01-01 17:30:45 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\fundraiser\view\fundraiser-view.php 87
DEBUG - 2023-01-01 17:30:45 --> Total execution time: 0.0977
DEBUG - 2023-01-01 13:00:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:00:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:31:05 --> Total execution time: 0.0601
DEBUG - 2023-01-01 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:01:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:01:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:31:13 --> Total execution time: 0.0775
DEBUG - 2023-01-01 13:01:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:01:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:02:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:32:10 --> Total execution time: 0.0841
DEBUG - 2023-01-01 13:02:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:02:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:02:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:32:10 --> Total execution time: 0.0862
DEBUG - 2023-01-01 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:02:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:02:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:02:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:02:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:02:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:02:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:02:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:02:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:03:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:33:06 --> Total execution time: 0.0827
DEBUG - 2023-01-01 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:03:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:35:00 --> Total execution time: 0.1113
DEBUG - 2023-01-01 13:05:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:05:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:13:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:43:30 --> Total execution time: 0.0791
DEBUG - 2023-01-01 13:13:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:13:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:32 --> 404 Page Not Found: admin/fundraiser/Campaign-status/index
DEBUG - 2023-01-01 13:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:34 --> 404 Page Not Found: admin/fundraiser/Campaign-status/index
DEBUG - 2023-01-01 13:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:13:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:37 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:13:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:13:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:13:37 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:13:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:43:42 --> Total execution time: 0.0614
DEBUG - 2023-01-01 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:13:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:13:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:43:50 --> Total execution time: 0.0790
DEBUG - 2023-01-01 13:13:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:13:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:50 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:13:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:13:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:13:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:13:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:13:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:45:05 --> Total execution time: 0.0871
DEBUG - 2023-01-01 13:15:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:45:16 --> Total execution time: 0.0512
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:45:19 --> Total execution time: 0.0673
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:15:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:15:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:15:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:45:50 --> Total execution time: 0.0631
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:15:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:15:50 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:15:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:15:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:15:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:15:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:16:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:46:03 --> Total execution time: 0.0600
DEBUG - 2023-01-01 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:46:05 --> Total execution time: 0.0681
DEBUG - 2023-01-01 13:16:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:46:16 --> Total execution time: 0.1116
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:46:19 --> Total execution time: 0.0839
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:16:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:16:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:46:57 --> Total execution time: 0.0636
DEBUG - 2023-01-01 13:17:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:47:06 --> Total execution time: 0.0530
DEBUG - 2023-01-01 13:17:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:47:28 --> Total execution time: 0.0686
DEBUG - 2023-01-01 13:17:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:47:29 --> Total execution time: 0.0671
DEBUG - 2023-01-01 13:17:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:17:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:17:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:17:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:47:43 --> Total execution time: 0.0704
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:47:59 --> Total execution time: 0.0664
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:17:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:18:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:01 --> Total execution time: 0.1010
DEBUG - 2023-01-01 13:18:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:03 --> Total execution time: 0.0750
DEBUG - 2023-01-01 13:18:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:04 --> Total execution time: 0.0839
DEBUG - 2023-01-01 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:04 --> Total execution time: 0.1006
DEBUG - 2023-01-01 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:17 --> Total execution time: 0.1159
DEBUG - 2023-01-01 13:18:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:19 --> Total execution time: 0.0618
DEBUG - 2023-01-01 13:18:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:23 --> Total execution time: 0.0674
DEBUG - 2023-01-01 13:18:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:24 --> Total execution time: 0.1025
DEBUG - 2023-01-01 13:18:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:25 --> Total execution time: 0.0701
DEBUG - 2023-01-01 13:18:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:44 --> Total execution time: 0.0659
DEBUG - 2023-01-01 13:18:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:49 --> Total execution time: 0.0685
DEBUG - 2023-01-01 13:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:53 --> Total execution time: 0.0618
DEBUG - 2023-01-01 13:18:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:56 --> Total execution time: 0.0825
DEBUG - 2023-01-01 13:18:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:56 --> Total execution time: 0.0891
DEBUG - 2023-01-01 13:18:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:18:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:48:58 --> Total execution time: 0.0677
DEBUG - 2023-01-01 13:18:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:18:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:00 --> Total execution time: 0.0707
DEBUG - 2023-01-01 13:19:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:19:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:19:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:03 --> Total execution time: 0.0876
DEBUG - 2023-01-01 13:19:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:19:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:19:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:18 --> Total execution time: 0.0609
DEBUG - 2023-01-01 13:19:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:19:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:19:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:26 --> Total execution time: 0.0645
DEBUG - 2023-01-01 13:19:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:19:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:29 --> Total execution time: 0.1087
DEBUG - 2023-01-01 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:19:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:19:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:19:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:19:37 --> Total execution time: 0.0566
DEBUG - 2023-01-01 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:40 --> No URI present. Default controller set.
DEBUG - 2023-01-01 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:40 --> Total execution time: 0.0844
DEBUG - 2023-01-01 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:43 --> Total execution time: 0.0590
DEBUG - 2023-01-01 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:51 --> Total execution time: 0.0568
DEBUG - 2023-01-01 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:19:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:19:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:49:59 --> Total execution time: 0.0784
DEBUG - 2023-01-01 13:19:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:19:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:50:38 --> Total execution time: 0.0603
DEBUG - 2023-01-01 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:20:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:20:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:21:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:21:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:51:31 --> Total execution time: 0.0761
DEBUG - 2023-01-01 13:21:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:39 --> No URI present. Default controller set.
DEBUG - 2023-01-01 13:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:51:39 --> Total execution time: 0.0679
DEBUG - 2023-01-01 13:21:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:21:42 --> Total execution time: 0.0627
DEBUG - 2023-01-01 13:21:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:21:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:51:49 --> Total execution time: 0.0607
DEBUG - 2023-01-01 13:21:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:21:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:51:56 --> Total execution time: 0.0607
DEBUG - 2023-01-01 13:21:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:21:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:55:45 --> Total execution time: 0.0789
DEBUG - 2023-01-01 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:25:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:25:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:27:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:57:52 --> Total execution time: 0.0753
DEBUG - 2023-01-01 13:27:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:27:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 17:59:55 --> Total execution time: 0.0804
DEBUG - 2023-01-01 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:29:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:30:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:00:29 --> Total execution time: 0.0706
DEBUG - 2023-01-01 13:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:31:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 18:01:20 --> Severity: Notice --> Undefined variable: camp_opt C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 37
ERROR - 2023-01-01 18:01:20 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 44
ERROR - 2023-01-01 18:01:20 --> Severity: Notice --> Undefined variable: to_date C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 50
ERROR - 2023-01-01 18:01:20 --> Severity: Notice --> Undefined variable: payment C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 57
ERROR - 2023-01-01 18:01:20 --> Severity: Notice --> Undefined variable: payment C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 58
ERROR - 2023-01-01 18:01:20 --> Severity: Notice --> Undefined variable: payment C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 59
ERROR - 2023-01-01 18:01:20 --> Severity: Notice --> Undefined variable: payment C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 60
ERROR - 2023-01-01 18:01:20 --> Severity: Notice --> Undefined variable: lists C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 98
ERROR - 2023-01-01 18:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\donate-list.php 98
DEBUG - 2023-01-01 18:01:20 --> Total execution time: 0.1159
DEBUG - 2023-01-01 13:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:31:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:02:36 --> Total execution time: 0.0649
DEBUG - 2023-01-01 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:32:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:32:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:35:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:05:24 --> Total execution time: 0.0783
DEBUG - 2023-01-01 13:35:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:35:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:35:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:37:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:07:15 --> Total execution time: 0.0724
DEBUG - 2023-01-01 13:37:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:37:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:45:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:45:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:45:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:45:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:15:06 --> Total execution time: 0.0835
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:45:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:06 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:45:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:45:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:45:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:45:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:15:16 --> Total execution time: 0.0747
DEBUG - 2023-01-01 13:45:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:15:16 --> Total execution time: 0.0609
DEBUG - 2023-01-01 13:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:15:18 --> Total execution time: 0.0652
DEBUG - 2023-01-01 13:45:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:15:19 --> Total execution time: 0.0742
DEBUG - 2023-01-01 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:16:45 --> Total execution time: 0.0851
DEBUG - 2023-01-01 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:46:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:46:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:46:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:46:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:46:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:46:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:46:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:46:46 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:46:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:46:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:46:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:46:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:46:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:16:48 --> Total execution time: 0.0661
DEBUG - 2023-01-01 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:16:49 --> Total execution time: 0.0685
DEBUG - 2023-01-01 13:46:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:16:50 --> Total execution time: 0.0735
DEBUG - 2023-01-01 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:09 --> Total execution time: 0.0638
DEBUG - 2023-01-01 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:09 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:47:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:10 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:47:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:14 --> Total execution time: 0.0789
DEBUG - 2023-01-01 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:14 --> Total execution time: 0.0615
DEBUG - 2023-01-01 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:21 --> Total execution time: 0.0604
DEBUG - 2023-01-01 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:47:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:22 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:47:22 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 13:47:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:22 --> UTF-8 Support Enabled
ERROR - 2023-01-01 13:47:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 13:47:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:47:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:24 --> Total execution time: 0.0627
DEBUG - 2023-01-01 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:32 --> Total execution time: 0.0831
DEBUG - 2023-01-01 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:47:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:37 --> Total execution time: 0.0695
DEBUG - 2023-01-01 13:47:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:47:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:55 --> Total execution time: 0.0612
DEBUG - 2023-01-01 13:47:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:47:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:17:59 --> Total execution time: 0.0607
DEBUG - 2023-01-01 13:47:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:47:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:47:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:18:35 --> Total execution time: 0.0606
DEBUG - 2023-01-01 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:48:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:48:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:49:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:19:51 --> Total execution time: 0.0870
DEBUG - 2023-01-01 13:49:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:49:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:49:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:20:38 --> Total execution time: 0.0962
DEBUG - 2023-01-01 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:50:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:50:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:20:40 --> Total execution time: 0.0580
DEBUG - 2023-01-01 13:50:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:20:41 --> Total execution time: 0.0624
DEBUG - 2023-01-01 13:50:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:50:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:50:47 --> Total execution time: 0.0542
DEBUG - 2023-01-01 13:50:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:20:49 --> Total execution time: 0.0618
DEBUG - 2023-01-01 13:51:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:01 --> Total execution time: 0.0726
DEBUG - 2023-01-01 13:51:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:51:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:07 --> Total execution time: 0.0612
DEBUG - 2023-01-01 13:51:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:51:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:12 --> Total execution time: 0.0759
DEBUG - 2023-01-01 13:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:12 --> Total execution time: 0.0535
DEBUG - 2023-01-01 13:51:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:14 --> Total execution time: 0.0636
DEBUG - 2023-01-01 13:51:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:51:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:51:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 13:51:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:21:18 --> Total execution time: 0.0919
DEBUG - 2023-01-01 13:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:18 --> Total execution time: 0.0554
DEBUG - 2023-01-01 13:51:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:21 --> Total execution time: 0.0641
DEBUG - 2023-01-01 13:51:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:51:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:51:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:23 --> Total execution time: 0.0644
DEBUG - 2023-01-01 13:51:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:24 --> Total execution time: 0.0578
DEBUG - 2023-01-01 13:51:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:27 --> Total execution time: 0.0629
DEBUG - 2023-01-01 13:51:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:51:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:51:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:30 --> Total execution time: 0.0644
DEBUG - 2023-01-01 13:51:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:51:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:31 --> Total execution time: 0.0644
DEBUG - 2023-01-01 13:51:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:51:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 13:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 13:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 13:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:21:34 --> Total execution time: 0.0684
DEBUG - 2023-01-01 13:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 13:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 13:51:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:31:46 --> Total execution time: 0.0665
DEBUG - 2023-01-01 14:01:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:01:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:01:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:01:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:31:58 --> Total execution time: 0.0625
DEBUG - 2023-01-01 14:01:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:01:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:02:28 --> 404 Page Not Found: fundraiser/Pending-payout/index
DEBUG - 2023-01-01 14:02:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:32:30 --> Total execution time: 0.0850
DEBUG - 2023-01-01 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:37:24 --> Total execution time: 0.0733
DEBUG - 2023-01-01 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:07:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 14:07:26 --> Total execution time: 0.0723
DEBUG - 2023-01-01 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:37:46 --> Total execution time: 0.0651
DEBUG - 2023-01-01 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:07:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:37:47 --> Total execution time: 0.0669
DEBUG - 2023-01-01 14:09:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:39:28 --> Total execution time: 0.0796
DEBUG - 2023-01-01 14:09:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:09:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:39:30 --> Total execution time: 0.0745
DEBUG - 2023-01-01 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:39:40 --> Total execution time: 0.0656
DEBUG - 2023-01-01 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:09:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:39:48 --> Total execution time: 0.0634
DEBUG - 2023-01-01 14:09:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:09:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:10:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:40:01 --> Total execution time: 0.0671
DEBUG - 2023-01-01 14:10:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:10:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:10:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:40:35 --> Total execution time: 0.0883
DEBUG - 2023-01-01 14:10:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:10:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 14:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:40:38 --> Total execution time: 0.0787
DEBUG - 2023-01-01 14:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:10:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:41 --> UTF-8 Support Enabled
ERROR - 2023-01-01 14:10:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:10:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:10:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:10:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:10:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:10:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:10:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:10:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:10:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:10:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:41:01 --> Total execution time: 0.0781
DEBUG - 2023-01-01 14:11:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:11:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:11:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:41:37 --> Total execution time: 0.0780
DEBUG - 2023-01-01 14:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:11:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:12:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:12:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 18:42:38 --> Severity: Notice --> Undefined variable: ul_id C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 180
ERROR - 2023-01-01 18:42:38 --> Query error: Unknown column 'ul_id' in 'where clause' - Invalid query: SELECT *
FROM `kyc`
WHERE `ul_id` IS NULL
AND `kyc_status` = 1
DEBUG - 2023-01-01 14:12:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:12:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:12:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:12:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 18:42:46 --> Query error: Unknown column 'ul_id' in 'where clause' - Invalid query: SELECT *
FROM `kyc`
WHERE `ul_id` = '1'
AND `kyc_status` = 1
DEBUG - 2023-01-01 14:12:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:12:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:12:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:13:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:43:01 --> Total execution time: 0.0822
DEBUG - 2023-01-01 14:13:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:13:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:43:11 --> Total execution time: 0.0876
DEBUG - 2023-01-01 14:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:13:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:43:13 --> Total execution time: 0.0713
DEBUG - 2023-01-01 14:13:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:13:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:43:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 18:43:18 --> You did not select a file to upload.
DEBUG - 2023-01-01 18:43:18 --> You did not select a file to upload.
DEBUG - 2023-01-01 14:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:43:18 --> Total execution time: 0.0691
DEBUG - 2023-01-01 14:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:13:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:13:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:43:20 --> Total execution time: 0.0879
DEBUG - 2023-01-01 14:13:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:13:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:13:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:12 --> Total execution time: 0.0820
DEBUG - 2023-01-01 14:14:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:19 --> Total execution time: 0.0716
DEBUG - 2023-01-01 14:14:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:21 --> Total execution time: 0.0645
DEBUG - 2023-01-01 14:14:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:22 --> Total execution time: 0.0721
DEBUG - 2023-01-01 14:14:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:24 --> Total execution time: 0.0669
DEBUG - 2023-01-01 14:14:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:26 --> Total execution time: 0.0780
DEBUG - 2023-01-01 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 18:44:40 --> You did not select a file to upload.
DEBUG - 2023-01-01 18:44:40 --> You did not select a file to upload.
DEBUG - 2023-01-01 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:40 --> Total execution time: 0.0684
DEBUG - 2023-01-01 14:14:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:42 --> Total execution time: 0.0784
DEBUG - 2023-01-01 14:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:44:45 --> Total execution time: 0.0632
DEBUG - 2023-01-01 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:14:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:15:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:45:00 --> Total execution time: 0.0666
DEBUG - 2023-01-01 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:15:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:45:20 --> Total execution time: 0.0674
DEBUG - 2023-01-01 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:15:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:15:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:45:54 --> Total execution time: 0.0664
DEBUG - 2023-01-01 14:15:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:15:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:45:55 --> Total execution time: 0.0756
DEBUG - 2023-01-01 14:15:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:15:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:15:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:45:57 --> Total execution time: 0.0806
DEBUG - 2023-01-01 14:15:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:45:57 --> Total execution time: 0.0691
DEBUG - 2023-01-01 14:17:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:17:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:17:20 --> UTF-8 Support Enabled
ERROR - 2023-01-01 14:17:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:17:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:17:20 --> UTF-8 Support Enabled
ERROR - 2023-01-01 14:17:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:17:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:17:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:17:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:17:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:17:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:17:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:17:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:17:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:17:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:17:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:18:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:48:30 --> Total execution time: 0.0729
DEBUG - 2023-01-01 14:18:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:18:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:18:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:18:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:18:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:18:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:18:31 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:18:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:18:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:18:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:49:10 --> Total execution time: 0.0946
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:19:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 14:19:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:19:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:19:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 14:19:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:49:39 --> Total execution time: 0.0781
DEBUG - 2023-01-01 14:19:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:19:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:56:43 --> Total execution time: 0.0793
DEBUG - 2023-01-01 14:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:26:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:26:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:26:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 18:56:47 --> Severity: Notice --> Undefined variable: camp_opt C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\settlement-pending.php 37
ERROR - 2023-01-01 18:56:47 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\settlement-pending.php 44
ERROR - 2023-01-01 18:56:47 --> Severity: Notice --> Undefined variable: to_date C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\settlement-pending.php 50
ERROR - 2023-01-01 18:56:47 --> Severity: Notice --> Undefined variable: payment C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\settlement-pending.php 57
ERROR - 2023-01-01 18:56:47 --> Severity: Notice --> Undefined variable: payment C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\settlement-pending.php 58
ERROR - 2023-01-01 18:56:47 --> Severity: Notice --> Undefined variable: payment C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\settlement-pending.php 59
ERROR - 2023-01-01 18:56:47 --> Severity: Notice --> Undefined variable: payment C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\settlement-pending.php 60
DEBUG - 2023-01-01 18:56:47 --> Total execution time: 0.1059
DEBUG - 2023-01-01 14:26:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:26:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:26:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:27:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:57:21 --> Total execution time: 0.0787
DEBUG - 2023-01-01 14:27:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:27:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:27:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:28:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:28:57 --> 404 Page Not Found: fundraiser/Settlement-pending/index
DEBUG - 2023-01-01 14:29:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:59:02 --> Total execution time: 0.0789
DEBUG - 2023-01-01 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:30:06 --> 404 Page Not Found: fundraiser/Campaign-running-list/index
DEBUG - 2023-01-01 14:31:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:31:50 --> 404 Page Not Found: fundraiser/Campaign/Campaign_Controller
DEBUG - 2023-01-01 14:32:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:02:04 --> Total execution time: 0.0867
DEBUG - 2023-01-01 14:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:03:45 --> Total execution time: 0.1055
DEBUG - 2023-01-01 14:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:33:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:34:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:04:28 --> Total execution time: 0.0745
DEBUG - 2023-01-01 14:34:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:34:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:34:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:04:35 --> Total execution time: 0.0704
DEBUG - 2023-01-01 14:34:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:34:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:34:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:04:58 --> Total execution time: 0.0731
DEBUG - 2023-01-01 14:34:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:34:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:05:25 --> Total execution time: 0.0676
DEBUG - 2023-01-01 14:35:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:35:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 14:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:05:30 --> Total execution time: 0.0638
DEBUG - 2023-01-01 14:35:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 14:35:36 --> Total execution time: 0.0675
DEBUG - 2023-01-01 14:35:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 14:35:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:05:40 --> Total execution time: 0.0631
DEBUG - 2023-01-01 14:35:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:35:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:35:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:05:43 --> Total execution time: 0.0676
DEBUG - 2023-01-01 14:35:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:35:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:35:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:05:45 --> Total execution time: 0.0659
DEBUG - 2023-01-01 14:35:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:35:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:35:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 14:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 14:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 14:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:09:23 --> Total execution time: 0.0806
DEBUG - 2023-01-01 14:39:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 14:39:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 14:39:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:09:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:39:15 --> Total execution time: 0.1147
DEBUG - 2023-01-01 15:09:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:09:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:11:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:41:47 --> Total execution time: 0.0814
DEBUG - 2023-01-01 15:11:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:11:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:11:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:12:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:12:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:12:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:12:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:12:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:33 --> Total execution time: 0.0942
DEBUG - 2023-01-01 15:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:13:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:34 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:13:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:34 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:13:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:45 --> Total execution time: 0.0799
DEBUG - 2023-01-01 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:13:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:13:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:13:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:13:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:13:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:52 --> Total execution time: 0.0767
DEBUG - 2023-01-01 15:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:52 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:13:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:52 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:13:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:13:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:53 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:13:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:53 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:13:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:57 --> Total execution time: 0.0842
DEBUG - 2023-01-01 15:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:13:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:14:16 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:14:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:14:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:14:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:14:16 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:14:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:14:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:14:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:14:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:14:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:45:09 --> Total execution time: 0.0976
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:15:09 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:46:22 --> Total execution time: 0.0981
DEBUG - 2023-01-01 15:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/website_esa
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:16:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:46:34 --> Total execution time: 0.0965
DEBUG - 2023-01-01 15:16:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:16:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:46:55 --> Total execution time: 0.0932
DEBUG - 2023-01-01 15:16:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:16:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:16:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:17:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:47:37 --> Total execution time: 0.0711
DEBUG - 2023-01-01 15:17:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:17:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:47:54 --> Total execution time: 0.0730
DEBUG - 2023-01-01 15:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:17:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:17:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:47:58 --> Total execution time: 0.0806
DEBUG - 2023-01-01 15:17:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:17:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:48:14 --> Total execution time: 0.0996
DEBUG - 2023-01-01 15:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:18:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:18:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:48:41 --> Total execution time: 0.0827
DEBUG - 2023-01-01 15:18:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:18:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:18:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:18:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:18:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:18:54 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:18:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:18:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:18:54 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:18:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:18:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:18:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:18:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:18:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:18:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:18:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:18:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:18:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:18:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:18:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:50:00 --> Total execution time: 0.0818
DEBUG - 2023-01-01 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:20:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:20:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:20:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:20:00 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:20:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:20:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:20:01 --> UTF-8 Support Enabled
ERROR - 2023-01-01 15:20:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:20:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 15:20:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:20:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:20:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:20:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 15:20:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:50:20 --> Total execution time: 0.0923
DEBUG - 2023-01-01 15:20:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:20:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:20:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:51:12 --> Total execution time: 0.0845
DEBUG - 2023-01-01 15:21:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:21:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:21:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:51:13 --> Total execution time: 0.0806
DEBUG - 2023-01-01 15:21:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:21:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:51:14 --> Total execution time: 0.0836
DEBUG - 2023-01-01 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:21:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:21:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:51:32 --> Total execution time: 0.0752
DEBUG - 2023-01-01 15:21:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:21:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:21:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:51:34 --> Total execution time: 0.0812
DEBUG - 2023-01-01 15:21:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:21:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:21:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 19:51:58 --> Severity: Notice --> Undefined variable: list C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 58
ERROR - 2023-01-01 19:51:58 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 58
ERROR - 2023-01-01 19:51:58 --> Severity: Notice --> Undefined variable: list C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 58
ERROR - 2023-01-01 19:51:58 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 58
ERROR - 2023-01-01 19:51:58 --> Severity: Notice --> Undefined variable: list C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 58
ERROR - 2023-01-01 19:51:58 --> Severity: Notice --> Trying to get property 'p_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 58
DEBUG - 2023-01-01 19:51:58 --> Total execution time: 0.1185
DEBUG - 2023-01-01 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:21:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:22:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:52:08 --> Total execution time: 0.0746
DEBUG - 2023-01-01 15:22:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:22:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:22:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:52:15 --> Total execution time: 0.0791
DEBUG - 2023-01-01 15:22:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:22:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:22:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:52:25 --> Total execution time: 0.0724
DEBUG - 2023-01-01 15:22:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:22:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:22:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:52:47 --> Total execution time: 0.0740
DEBUG - 2023-01-01 15:22:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:52:49 --> Total execution time: 0.0984
DEBUG - 2023-01-01 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:22:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:26:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 15:26:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 15:26:33 --> Total execution time: 0.0632
DEBUG - 2023-01-01 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 15:26:56 --> Total execution time: 0.0649
DEBUG - 2023-01-01 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:05 --> No URI present. Default controller set.
DEBUG - 2023-01-01 15:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:57:05 --> Total execution time: 0.0748
DEBUG - 2023-01-01 15:27:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:57:07 --> Total execution time: 0.0654
DEBUG - 2023-01-01 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:57:31 --> Total execution time: 0.0666
DEBUG - 2023-01-01 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:27:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:27:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:57:37 --> Total execution time: 0.0670
DEBUG - 2023-01-01 15:27:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:27:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:27:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:27:41 --> 404 Page Not Found: fundraiser/Campaign-list/index
DEBUG - 2023-01-01 15:27:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:57:43 --> Total execution time: 0.0748
DEBUG - 2023-01-01 15:27:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:57:45 --> Total execution time: 0.0775
DEBUG - 2023-01-01 15:27:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:27:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:28:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:58:49 --> Total execution time: 0.0765
DEBUG - 2023-01-01 15:28:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:28:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:29:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:59:25 --> Total execution time: 0.0818
DEBUG - 2023-01-01 15:29:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:29:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:29:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:59:57 --> Total execution time: 0.0744
DEBUG - 2023-01-01 15:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:29:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:34:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:04:00 --> Total execution time: 0.1043
DEBUG - 2023-01-01 15:34:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:34:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:04:19 --> Total execution time: 0.0671
DEBUG - 2023-01-01 15:34:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:34:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:34:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:34:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 20:04:21 --> Severity: Notice --> Undefined property: Campaign_Controller::$Posts C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Campaign_Controller.php 29
ERROR - 2023-01-01 20:04:21 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Campaign_Controller.php 29
DEBUG - 2023-01-01 15:35:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:35:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 20:05:25 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\inc\header.php 59
ERROR - 2023-01-01 20:05:25 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2023-01-01 20:05:25 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2023-01-01 20:05:25 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\inc\header.php 61
ERROR - 2023-01-01 20:05:25 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 8
DEBUG - 2023-01-01 20:05:25 --> Total execution time: 0.1707
DEBUG - 2023-01-01 15:35:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:35:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:35:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:35:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:05:52 --> Total execution time: 0.1426
DEBUG - 2023-01-01 15:35:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:35:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:35:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:36:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:06:22 --> Total execution time: 0.1021
DEBUG - 2023-01-01 15:36:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:36:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:36:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:36:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:06:51 --> Total execution time: 0.1154
DEBUG - 2023-01-01 15:36:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:36:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:36:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:37:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:07:45 --> Total execution time: 0.1000
DEBUG - 2023-01-01 15:37:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:37:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:08:22 --> Total execution time: 0.0814
DEBUG - 2023-01-01 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:38:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:10:06 --> Total execution time: 0.0950
DEBUG - 2023-01-01 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:40:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:10:14 --> Total execution time: 0.0703
DEBUG - 2023-01-01 15:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:40:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:40:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:10:20 --> Total execution time: 0.0633
DEBUG - 2023-01-01 15:40:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:10:47 --> Total execution time: 0.0736
DEBUG - 2023-01-01 15:40:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:40:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:40:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:41:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:41:02 --> 404 Page Not Found: fundraiser/Campaign-list/index
DEBUG - 2023-01-01 15:41:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:11:04 --> Total execution time: 0.0830
DEBUG - 2023-01-01 15:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:41:06 --> 404 Page Not Found: fundraiser/Campaign-list/index
DEBUG - 2023-01-01 15:42:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:42:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 20:12:59 --> Severity: error --> Exception: Call to undefined method Campaign_Controller::admin_view() C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Campaign_Controller.php 16
DEBUG - 2023-01-01 15:43:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:43:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-01 20:13:38 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\inc\header.php 59
ERROR - 2023-01-01 20:13:38 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2023-01-01 20:13:38 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 16
ERROR - 2023-01-01 20:13:38 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\inc\header.php 61
ERROR - 2023-01-01 20:13:38 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 8
DEBUG - 2023-01-01 20:13:38 --> Total execution time: 0.1095
DEBUG - 2023-01-01 15:43:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:43:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:43:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:14:02 --> Total execution time: 0.0726
DEBUG - 2023-01-01 15:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:44:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:15:11 --> Total execution time: 0.0799
DEBUG - 2023-01-01 15:45:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:45:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:45:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:15:29 --> Total execution time: 0.1008
DEBUG - 2023-01-01 15:45:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:45:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:45:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:15:37 --> Total execution time: 0.0893
DEBUG - 2023-01-01 15:45:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:45:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:45:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:15:50 --> Total execution time: 0.0782
DEBUG - 2023-01-01 15:45:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:45:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:45:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:15:58 --> Total execution time: 0.0913
DEBUG - 2023-01-01 15:45:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:45:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:16:11 --> Total execution time: 0.0986
DEBUG - 2023-01-01 15:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:46:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:16:13 --> Total execution time: 0.0741
DEBUG - 2023-01-01 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:46:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:46:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:16:27 --> Total execution time: 0.0858
DEBUG - 2023-01-01 15:46:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:46:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:46:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:16:28 --> Total execution time: 0.0741
DEBUG - 2023-01-01 15:46:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:46:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:46:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:16:37 --> Total execution time: 0.0948
DEBUG - 2023-01-01 15:46:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:46:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:47:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:17:39 --> Total execution time: 0.0812
DEBUG - 2023-01-01 15:47:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:47:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:47:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:48:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:18:06 --> Total execution time: 0.1227
DEBUG - 2023-01-01 15:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:48:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:48:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:18:41 --> Total execution time: 0.0893
DEBUG - 2023-01-01 15:48:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:48:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:49:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:19:12 --> Total execution time: 0.0880
DEBUG - 2023-01-01 15:49:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:49:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:19:16 --> Total execution time: 0.1076
DEBUG - 2023-01-01 15:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:49:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:49:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:19:17 --> Total execution time: 0.1178
DEBUG - 2023-01-01 15:49:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:49:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:49:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 15:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 15:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 15:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:19:25 --> Total execution time: 0.0891
DEBUG - 2023-01-01 15:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 15:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 15:49:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:04:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:04:21 --> Total execution time: 0.9096
DEBUG - 2023-01-01 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:04:21 --> Total execution time: 0.0755
DEBUG - 2023-01-01 18:04:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:04:47 --> Total execution time: 0.0973
DEBUG - 2023-01-01 18:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:34:53 --> Total execution time: 0.1234
DEBUG - 2023-01-01 18:04:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:04:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:04:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:04:58 --> No URI present. Default controller set.
DEBUG - 2023-01-01 18:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:34:58 --> Total execution time: 0.1858
DEBUG - 2023-01-01 18:04:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:04:58 --> No URI present. Default controller set.
DEBUG - 2023-01-01 18:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:34:58 --> Total execution time: 0.1770
DEBUG - 2023-01-01 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:35:00 --> Total execution time: 0.1094
DEBUG - 2023-01-01 18:05:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 18:05:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:35:41 --> Total execution time: 0.1124
DEBUG - 2023-01-01 18:05:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:05:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:35:47 --> Total execution time: 0.1611
DEBUG - 2023-01-01 18:05:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:05:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:35:51 --> Total execution time: 0.1421
DEBUG - 2023-01-01 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:05:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:05:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:35:52 --> Total execution time: 0.0971
DEBUG - 2023-01-01 18:05:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:05:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:05:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:35:59 --> Total execution time: 0.0699
DEBUG - 2023-01-01 18:06:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:06:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:06:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:06:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:36:02 --> Total execution time: 0.0723
DEBUG - 2023-01-01 18:06:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:06:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:06:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:36:04 --> Total execution time: 0.1092
DEBUG - 2023-01-01 18:06:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:06:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:06:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:36:06 --> Total execution time: 0.2032
DEBUG - 2023-01-01 18:06:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:06:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:07:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:37:06 --> Total execution time: 0.0868
DEBUG - 2023-01-01 18:07:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:07:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:07:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:07:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:37:21 --> Total execution time: 0.0794
DEBUG - 2023-01-01 18:07:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:37:39 --> Total execution time: 0.1008
DEBUG - 2023-01-01 18:07:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:07:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:19:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:49:23 --> Total execution time: 0.0848
DEBUG - 2023-01-01 18:19:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:19:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 18:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 18:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 18:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:59:57 --> Total execution time: 0.0830
DEBUG - 2023-01-01 18:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 18:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 18:29:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:03:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:33:18 --> Total execution time: 0.0851
DEBUG - 2023-01-01 19:03:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:03:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:35:29 --> Total execution time: 0.0915
DEBUG - 2023-01-01 19:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:05:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:06:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:25 --> Total execution time: 0.1114
DEBUG - 2023-01-01 19:06:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:06:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:28 --> Total execution time: 0.0740
DEBUG - 2023-01-01 19:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:06:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:06:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:29 --> Total execution time: 0.0938
DEBUG - 2023-01-01 19:06:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 23:36:34 --> You did not select a file to upload.
DEBUG - 2023-01-01 23:36:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 23:36:35 --> You did not select a file to upload.
DEBUG - 2023-01-01 19:06:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:35 --> Total execution time: 0.0686
DEBUG - 2023-01-01 19:06:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:06:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:06:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:35 --> Total execution time: 0.0978
DEBUG - 2023-01-01 19:06:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:37 --> Total execution time: 0.0911
DEBUG - 2023-01-01 19:06:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:06:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:06:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 23:36:42 --> You did not select a file to upload.
DEBUG - 2023-01-01 23:36:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-01 23:36:42 --> You did not select a file to upload.
DEBUG - 2023-01-01 19:06:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:42 --> Total execution time: 0.0696
DEBUG - 2023-01-01 19:06:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:06:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:06:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:42 --> Total execution time: 0.1024
DEBUG - 2023-01-01 19:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:36:43 --> Total execution time: 0.0934
DEBUG - 2023-01-01 19:06:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:06:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:11:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:41:58 --> Total execution time: 0.0840
DEBUG - 2023-01-01 19:11:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:11:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:12:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:12:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:12:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:12:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:12:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:12:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:12:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:12:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:12:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:42:10 --> Total execution time: 0.0771
DEBUG - 2023-01-01 19:31:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:31:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:31:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:32:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:32:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:32:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:32:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:32:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:33:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:33:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:33:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:33:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:33:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:33:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:33:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:33:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:33:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:33:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:33:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:33:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:33:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:33:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:33:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:33:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:33:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:33:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:34:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:34:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:34:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:34:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:34:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:34:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:34:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:34:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:34:26 --> UTF-8 Support Enabled
ERROR - 2023-01-01 19:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:34:26 --> UTF-8 Support Enabled
ERROR - 2023-01-01 19:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:34:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:34:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:34:26 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:34:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:34:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:35:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:36:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:36:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:36:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:36:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:36:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:36:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:36:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:36:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:36:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:36:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:36:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:36:49 --> UTF-8 Support Enabled
ERROR - 2023-01-01 19:36:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:36:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:36:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:36:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:36:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:36:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:36:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:37:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:37:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:37:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:38:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
ERROR - 2023-01-01 19:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:38:42 --> UTF-8 Support Enabled
ERROR - 2023-01-01 19:38:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:38:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:38:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:38:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:38:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:01 --> UTF-8 Support Enabled
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:39:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 19:39:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 19:39:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:41:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:41:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:41:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:41:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:43:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:43:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:43:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:43:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:43:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:43:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:43:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:43:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:43:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:44:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:44:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:44:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:58:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 19:58:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 19:58:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 19:58:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 19:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 19:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 19:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:00:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:00:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:12:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:12:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:12:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:12:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:12:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:13:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:13:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:13:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:13:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:13:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:13:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:13:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:13:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:13:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:13:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:13:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:25:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:25:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:25:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:25:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:25:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:25:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:25:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:26:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:26:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:26:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:26:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:26:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:26:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:26:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:26:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:26:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:26:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:32:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:02 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:32:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:32:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:32:03 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:32:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:32:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:32:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:32:07 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:32:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:32:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:32:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:40:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:40:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:40:53 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:40:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:40:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:40:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:40:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:40:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:40:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:40:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:40:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:40:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:40:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:40:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:42:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:42:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:42:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:42:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:42:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:42:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:44:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:44:50 --> UTF-8 Support Enabled
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:44:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 20:44:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:44:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:45:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:45:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:45:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:45:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:45:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:45:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:45:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:45:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:46:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:46:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:46:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:46:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:46:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:46:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:46:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:46:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:46:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:46:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:47:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:47:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:48:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:48:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:48:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:48:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:51:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:51:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:51:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:51:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:51:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:52:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:52:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:52:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:52:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:52:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:52:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:52:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:52:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:52:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 20:53:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 20:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 20:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 20:53:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 20:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 20:53:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 21:45:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 21:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 21:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 21:45:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 21:45:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 21:46:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 21:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 21:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 21:46:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 21:46:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 21:49:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 21:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 21:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 21:49:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 21:49:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 21:49:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 21:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 21:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 21:49:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 21:49:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 21:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 21:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 21:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 21:53:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:00:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:00:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:00:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:00:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:00:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:00:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:00:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:01:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:01:14 --> Total execution time: 0.0674
DEBUG - 2023-01-01 22:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:01:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:01:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:01:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:01:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:01:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:01:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:01:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:01:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:04:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:04:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:04:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:05:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:05:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:05:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:05:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:05:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:09:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:09:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:09:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:13:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:13:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:13:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:13:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:13:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:13:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:13:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:13:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:13:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:14:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:14:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:14:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:14:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:14:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:14:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:14:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:14:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:14:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:14:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:14:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:15:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:15:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:15:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:15:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:15:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:15:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:15:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:15:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:15:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:15:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:15:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:15:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:17:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:17:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:17:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:17:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:18:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:18:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:18:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:18:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:18:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:18:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:22:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:22:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:22:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:22:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:22:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:22:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:22:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:22:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:22:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:22:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:22:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:24:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:24:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:24:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:24:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:24:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:24:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:24:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:24:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:24:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:25:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:25:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:25:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:25:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:25:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:25:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:26:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:26:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:26:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:26:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:26:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:26:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:26:54 --> 404 Page Not Found: fundraiser/Account_Controller/withdraw_list
DEBUG - 2023-01-01 22:27:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:27:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:27:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:29:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:29:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:29:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:30:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:31:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:31:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:31:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:31:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:31:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:31:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:31:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:31:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:31:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:31:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:31:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:31:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:31:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:31:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:31:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:37:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:41:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:41:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:41:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:41:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:42:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:42:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:42:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:42:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:42:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:42:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:43:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:43:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:43:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:43:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:43:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:43:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:43:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:43:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:45:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:45:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:45:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:45:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:45:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:45:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:45:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:45:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:45:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:47:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:47:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:47:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:47:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:47:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:47:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:47:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:47:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:47:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:47:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:47:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:47:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:47:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:47:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:48:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:48:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:48:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:48:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:48:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:48:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:48:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:49:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:49:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:49:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:49:30 --> UTF-8 Support Enabled
ERROR - 2023-01-01 22:49:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:49:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:49:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 22:49:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 22:49:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:49:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 22:49:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 22:49:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:50:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:50:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:50:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:50:10 --> UTF-8 Support Enabled
ERROR - 2023-01-01 22:50:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 22:50:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:50:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:50:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:50:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 22:50:10 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 22:50:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 22:50:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:50:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:50:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:50:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:50:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:50:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:50:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:50:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:51:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:51:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:51:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:51:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:57:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:57:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:57:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:57:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:57:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:57:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:57:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:57:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:57:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:57:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:57:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:57:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:57:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:57:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:57:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:57:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 22:58:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 22:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 22:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 22:58:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 22:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 22:58:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:06:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 23:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:06:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 23:06:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 23:06:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 23:06:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:06:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 23:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:06:43 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-01 23:06:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-01 23:08:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:08:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:08:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:09:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:09:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:09:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:09:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:09:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:09:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:09:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:09:34 --> 404 Page Not Found: fundraiser/Account_Controller/withdrawal_request
DEBUG - 2023-01-01 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:10:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:10:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:11:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:11:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:12:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:12:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:12:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:13:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:13:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:13:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:29:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:29:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:29:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:29:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:29:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:29:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:29:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:29:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:30:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:30:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-01 23:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-01 23:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-01 23:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-01 23:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-01 23:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-01 23:30:06 --> 404 Page Not Found: Assets/website_esa
