<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-01 00:03:50 --> Total execution time: 0.0991
DEBUG - 2022-07-01 00:03:52 --> Total execution time: 0.0354
DEBUG - 2022-07-01 00:05:00 --> Total execution time: 0.0332
DEBUG - 2022-07-01 00:05:51 --> Total execution time: 0.0735
DEBUG - 2022-07-01 00:07:36 --> Total execution time: 0.1343
DEBUG - 2022-07-01 00:29:33 --> Total execution time: 0.1076
DEBUG - 2022-07-01 00:30:02 --> Total execution time: 0.1444
DEBUG - 2022-07-01 00:31:38 --> Total execution time: 0.0367
DEBUG - 2022-07-01 00:31:46 --> Total execution time: 0.0314
DEBUG - 2022-07-01 00:31:47 --> Total execution time: 0.0304
DEBUG - 2022-07-01 00:31:49 --> Total execution time: 0.0311
DEBUG - 2022-07-01 00:43:16 --> Total execution time: 0.1926
DEBUG - 2022-07-01 00:43:24 --> Total execution time: 0.2791
DEBUG - 2022-07-01 00:43:52 --> Total execution time: 0.1181
DEBUG - 2022-07-01 00:45:04 --> Total execution time: 0.0489
DEBUG - 2022-07-01 00:46:19 --> Total execution time: 0.1464
DEBUG - 2022-07-01 00:46:32 --> Total execution time: 0.1447
DEBUG - 2022-07-01 00:46:56 --> Total execution time: 0.0571
DEBUG - 2022-07-01 00:47:00 --> Total execution time: 0.0738
DEBUG - 2022-07-01 00:47:28 --> Total execution time: 0.0697
DEBUG - 2022-07-01 00:47:31 --> Total execution time: 0.0404
DEBUG - 2022-07-01 00:47:33 --> Total execution time: 0.0752
DEBUG - 2022-07-01 00:47:34 --> Total execution time: 0.0348
DEBUG - 2022-07-01 00:47:41 --> Total execution time: 0.0493
DEBUG - 2022-07-01 00:47:43 --> Total execution time: 0.0520
DEBUG - 2022-07-01 00:47:45 --> Total execution time: 0.0604
DEBUG - 2022-07-01 00:47:47 --> Total execution time: 0.0606
DEBUG - 2022-07-01 00:47:53 --> Total execution time: 0.0455
DEBUG - 2022-07-01 00:49:00 --> Total execution time: 0.0587
DEBUG - 2022-07-01 00:49:10 --> Total execution time: 0.0581
DEBUG - 2022-07-01 00:49:11 --> Total execution time: 0.0611
DEBUG - 2022-07-01 00:49:12 --> Total execution time: 0.0613
DEBUG - 2022-07-01 00:49:15 --> Total execution time: 0.0422
DEBUG - 2022-07-01 00:49:19 --> Total execution time: 0.0447
DEBUG - 2022-07-01 00:49:22 --> Total execution time: 0.0506
DEBUG - 2022-07-01 00:49:24 --> Total execution time: 0.0443
DEBUG - 2022-07-01 00:49:28 --> Total execution time: 0.0399
DEBUG - 2022-07-01 00:49:30 --> Total execution time: 0.0470
DEBUG - 2022-07-01 00:49:32 --> Total execution time: 0.0621
DEBUG - 2022-07-01 00:49:36 --> Total execution time: 0.0552
DEBUG - 2022-07-01 00:49:42 --> Total execution time: 0.0510
DEBUG - 2022-07-01 00:49:49 --> Total execution time: 0.0669
DEBUG - 2022-07-01 00:49:54 --> Total execution time: 0.0784
DEBUG - 2022-07-01 00:50:45 --> Total execution time: 0.0440
DEBUG - 2022-07-01 00:50:52 --> Total execution time: 0.0495
DEBUG - 2022-07-01 00:50:56 --> Total execution time: 0.0506
DEBUG - 2022-07-01 00:50:59 --> Total execution time: 0.0545
DEBUG - 2022-07-01 00:51:06 --> Total execution time: 0.0507
DEBUG - 2022-07-01 00:51:07 --> Total execution time: 0.0326
DEBUG - 2022-07-01 00:51:33 --> Total execution time: 0.1495
DEBUG - 2022-07-01 00:51:45 --> Total execution time: 0.0530
DEBUG - 2022-07-01 00:52:36 --> Total execution time: 0.0580
DEBUG - 2022-07-01 00:52:45 --> Total execution time: 0.0555
DEBUG - 2022-07-01 00:53:06 --> Total execution time: 0.0645
DEBUG - 2022-07-01 00:56:07 --> Total execution time: 0.1255
DEBUG - 2022-07-01 00:57:24 --> Total execution time: 0.0455
DEBUG - 2022-07-01 01:10:16 --> Total execution time: 0.1728
DEBUG - 2022-07-01 01:30:03 --> Total execution time: 0.1421
DEBUG - 2022-07-01 01:46:57 --> Total execution time: 0.1120
DEBUG - 2022-07-01 01:49:03 --> Total execution time: 0.0344
DEBUG - 2022-07-01 01:50:05 --> Total execution time: 0.1197
DEBUG - 2022-07-01 01:50:08 --> Total execution time: 0.0600
DEBUG - 2022-07-01 01:50:11 --> Total execution time: 0.0526
DEBUG - 2022-07-01 01:50:13 --> Total execution time: 0.0579
DEBUG - 2022-07-01 01:50:23 --> Total execution time: 0.0671
DEBUG - 2022-07-01 01:52:10 --> Total execution time: 0.0588
DEBUG - 2022-07-01 01:52:48 --> Total execution time: 0.0453
DEBUG - 2022-07-01 01:59:16 --> Total execution time: 0.1766
DEBUG - 2022-07-01 02:12:58 --> Total execution time: 0.0935
DEBUG - 2022-07-01 02:23:52 --> Total execution time: 0.0737
DEBUG - 2022-07-01 02:23:53 --> Total execution time: 0.0338
DEBUG - 2022-07-01 02:30:02 --> Total execution time: 0.1209
DEBUG - 2022-07-01 02:41:43 --> Total execution time: 0.1080
DEBUG - 2022-07-01 02:41:47 --> Total execution time: 0.0392
DEBUG - 2022-07-01 02:43:38 --> Total execution time: 0.0383
DEBUG - 2022-07-01 02:46:38 --> Total execution time: 0.0845
DEBUG - 2022-07-01 02:46:41 --> Total execution time: 0.0326
DEBUG - 2022-07-01 02:47:06 --> Total execution time: 0.0657
DEBUG - 2022-07-01 02:47:18 --> Total execution time: 0.0692
DEBUG - 2022-07-01 02:47:21 --> Total execution time: 0.0594
DEBUG - 2022-07-01 02:47:36 --> Total execution time: 0.0460
DEBUG - 2022-07-01 02:47:40 --> Total execution time: 0.0623
DEBUG - 2022-07-01 02:47:43 --> Total execution time: 0.0535
DEBUG - 2022-07-01 02:47:51 --> Total execution time: 0.0596
DEBUG - 2022-07-01 03:00:35 --> Total execution time: 0.1478
DEBUG - 2022-07-01 03:00:37 --> Total execution time: 0.0349
DEBUG - 2022-07-01 03:17:00 --> Total execution time: 0.1051
DEBUG - 2022-07-01 03:24:19 --> Total execution time: 0.0977
DEBUG - 2022-07-01 03:24:24 --> Total execution time: 0.0474
DEBUG - 2022-07-01 03:24:39 --> Total execution time: 0.0926
DEBUG - 2022-07-01 03:24:46 --> Total execution time: 0.1032
DEBUG - 2022-07-01 03:24:54 --> Total execution time: 0.0554
DEBUG - 2022-07-01 03:25:10 --> Total execution time: 0.0485
DEBUG - 2022-07-01 03:30:05 --> Total execution time: 0.1650
DEBUG - 2022-07-01 03:41:26 --> Total execution time: 0.0918
DEBUG - 2022-07-01 03:42:15 --> Total execution time: 0.1414
DEBUG - 2022-07-01 03:42:19 --> Total execution time: 0.0653
DEBUG - 2022-07-01 03:42:40 --> Total execution time: 0.0541
DEBUG - 2022-07-01 03:51:23 --> Total execution time: 0.1021
DEBUG - 2022-07-01 03:51:28 --> Total execution time: 0.0597
DEBUG - 2022-07-01 03:51:44 --> Total execution time: 0.0553
DEBUG - 2022-07-01 03:51:47 --> Total execution time: 0.0837
DEBUG - 2022-07-01 03:52:15 --> Total execution time: 0.0452
DEBUG - 2022-07-01 03:52:20 --> Total execution time: 0.0453
DEBUG - 2022-07-01 03:52:24 --> Total execution time: 0.0488
DEBUG - 2022-07-01 03:52:25 --> Total execution time: 0.0442
DEBUG - 2022-07-01 03:52:26 --> Total execution time: 0.0453
DEBUG - 2022-07-01 03:52:27 --> Total execution time: 0.0475
DEBUG - 2022-07-01 04:02:23 --> Total execution time: 0.1040
DEBUG - 2022-07-01 04:30:03 --> Total execution time: 0.3683
DEBUG - 2022-07-01 04:37:42 --> Total execution time: 0.1353
DEBUG - 2022-07-01 04:39:24 --> Total execution time: 0.1315
DEBUG - 2022-07-01 04:41:00 --> Total execution time: 0.0340
DEBUG - 2022-07-01 04:41:02 --> Total execution time: 0.0380
DEBUG - 2022-07-01 04:54:52 --> Total execution time: 0.1897
DEBUG - 2022-07-01 04:54:54 --> Total execution time: 0.0433
DEBUG - 2022-07-01 05:30:04 --> Total execution time: 0.2880
DEBUG - 2022-07-01 05:45:05 --> Total execution time: 0.1267
DEBUG - 2022-07-01 05:49:26 --> Total execution time: 0.1018
DEBUG - 2022-07-01 05:59:27 --> Total execution time: 0.1005
DEBUG - 2022-07-01 05:59:30 --> Total execution time: 0.0478
DEBUG - 2022-07-01 05:59:33 --> Total execution time: 0.0493
DEBUG - 2022-07-01 05:59:43 --> Total execution time: 0.0341
DEBUG - 2022-07-01 05:59:44 --> Total execution time: 0.0404
DEBUG - 2022-07-01 05:59:57 --> Total execution time: 0.0337
DEBUG - 2022-07-01 05:59:57 --> Total execution time: 0.0271
DEBUG - 2022-07-01 06:00:17 --> Total execution time: 0.0332
DEBUG - 2022-07-01 06:00:31 --> Total execution time: 0.0328
DEBUG - 2022-07-01 06:07:36 --> Total execution time: 0.1099
DEBUG - 2022-07-01 06:19:04 --> Total execution time: 0.1037
DEBUG - 2022-07-01 06:19:17 --> Total execution time: 0.0442
DEBUG - 2022-07-01 06:19:31 --> Total execution time: 0.0683
DEBUG - 2022-07-01 06:19:40 --> Total execution time: 0.0647
DEBUG - 2022-07-01 06:19:47 --> Total execution time: 0.0713
DEBUG - 2022-07-01 06:20:33 --> Total execution time: 0.0530
DEBUG - 2022-07-01 06:21:03 --> Total execution time: 0.0746
DEBUG - 2022-07-01 06:21:20 --> Total execution time: 0.0499
DEBUG - 2022-07-01 06:21:24 --> Total execution time: 0.0553
DEBUG - 2022-07-01 06:21:34 --> Total execution time: 0.0718
DEBUG - 2022-07-01 06:21:53 --> Total execution time: 0.0463
DEBUG - 2022-07-01 06:21:57 --> Total execution time: 0.0519
DEBUG - 2022-07-01 06:22:04 --> Total execution time: 0.0545
DEBUG - 2022-07-01 06:22:10 --> Total execution time: 0.1012
DEBUG - 2022-07-01 06:23:11 --> Total execution time: 0.0556
DEBUG - 2022-07-01 06:23:14 --> Total execution time: 0.0501
DEBUG - 2022-07-01 06:23:31 --> Total execution time: 0.0519
DEBUG - 2022-07-01 06:24:08 --> Total execution time: 0.0524
DEBUG - 2022-07-01 06:24:15 --> Total execution time: 0.0559
DEBUG - 2022-07-01 06:24:46 --> Total execution time: 0.1149
DEBUG - 2022-07-01 06:24:51 --> Total execution time: 0.0784
DEBUG - 2022-07-01 06:24:55 --> Total execution time: 0.0695
DEBUG - 2022-07-01 06:25:01 --> Total execution time: 0.0552
DEBUG - 2022-07-01 06:25:16 --> Total execution time: 0.0773
DEBUG - 2022-07-01 06:25:29 --> Total execution time: 0.0689
DEBUG - 2022-07-01 06:25:37 --> Total execution time: 0.0819
DEBUG - 2022-07-01 06:25:44 --> Total execution time: 0.0512
DEBUG - 2022-07-01 06:25:58 --> Total execution time: 0.0590
DEBUG - 2022-07-01 06:26:15 --> Total execution time: 0.0509
DEBUG - 2022-07-01 06:26:18 --> Total execution time: 0.0506
DEBUG - 2022-07-01 06:26:27 --> Total execution time: 0.0468
DEBUG - 2022-07-01 06:26:29 --> Total execution time: 0.0627
DEBUG - 2022-07-01 06:26:32 --> Total execution time: 0.0517
DEBUG - 2022-07-01 06:26:44 --> Total execution time: 0.0606
DEBUG - 2022-07-01 06:27:00 --> Total execution time: 0.0709
DEBUG - 2022-07-01 06:27:20 --> Total execution time: 0.0486
DEBUG - 2022-07-01 06:27:23 --> Total execution time: 0.0496
DEBUG - 2022-07-01 06:27:27 --> Total execution time: 0.0587
DEBUG - 2022-07-01 06:27:38 --> Total execution time: 0.0521
DEBUG - 2022-07-01 06:28:15 --> Total execution time: 0.0377
DEBUG - 2022-07-01 06:28:18 --> Total execution time: 0.0326
DEBUG - 2022-07-01 06:28:32 --> Total execution time: 0.0325
DEBUG - 2022-07-01 06:30:02 --> Total execution time: 0.0364
DEBUG - 2022-07-01 06:32:49 --> Total execution time: 0.0693
DEBUG - 2022-07-01 06:32:54 --> Total execution time: 0.0613
DEBUG - 2022-07-01 06:32:58 --> Total execution time: 0.0655
DEBUG - 2022-07-01 06:33:18 --> Total execution time: 0.0611
DEBUG - 2022-07-01 06:33:26 --> Total execution time: 0.0553
DEBUG - 2022-07-01 06:33:30 --> Total execution time: 0.0569
DEBUG - 2022-07-01 06:33:41 --> Total execution time: 0.0472
DEBUG - 2022-07-01 06:33:47 --> Total execution time: 0.0471
DEBUG - 2022-07-01 06:36:48 --> Total execution time: 0.0479
DEBUG - 2022-07-01 06:37:05 --> Total execution time: 0.0501
DEBUG - 2022-07-01 06:37:18 --> Total execution time: 0.0571
DEBUG - 2022-07-01 06:37:28 --> Total execution time: 0.0575
DEBUG - 2022-07-01 06:37:49 --> Total execution time: 0.0521
DEBUG - 2022-07-01 06:37:56 --> Total execution time: 0.0479
DEBUG - 2022-07-01 06:38:19 --> Total execution time: 0.0475
DEBUG - 2022-07-01 06:38:29 --> Total execution time: 0.0479
DEBUG - 2022-07-01 06:39:09 --> Total execution time: 0.0603
DEBUG - 2022-07-01 06:39:19 --> Total execution time: 0.0541
DEBUG - 2022-07-01 06:39:24 --> Total execution time: 0.0560
DEBUG - 2022-07-01 06:39:34 --> Total execution time: 0.0474
DEBUG - 2022-07-01 06:39:39 --> Total execution time: 0.0405
DEBUG - 2022-07-01 06:39:46 --> Total execution time: 0.0347
DEBUG - 2022-07-01 06:39:54 --> Total execution time: 0.0685
DEBUG - 2022-07-01 06:39:58 --> Total execution time: 0.0678
DEBUG - 2022-07-01 06:40:10 --> Total execution time: 0.0555
DEBUG - 2022-07-01 06:40:11 --> Total execution time: 0.0591
DEBUG - 2022-07-01 06:40:11 --> Total execution time: 0.0575
DEBUG - 2022-07-01 06:41:29 --> Total execution time: 0.0729
DEBUG - 2022-07-01 06:41:29 --> Total execution time: 0.0657
DEBUG - 2022-07-01 06:41:32 --> Total execution time: 0.0525
DEBUG - 2022-07-01 06:41:37 --> Total execution time: 0.0488
DEBUG - 2022-07-01 06:41:43 --> Total execution time: 0.0509
DEBUG - 2022-07-01 06:42:57 --> Total execution time: 0.0457
DEBUG - 2022-07-01 06:46:40 --> Total execution time: 0.1734
DEBUG - 2022-07-01 06:46:46 --> Total execution time: 0.0625
DEBUG - 2022-07-01 06:46:56 --> Total execution time: 0.0467
DEBUG - 2022-07-01 06:47:09 --> Total execution time: 0.0505
DEBUG - 2022-07-01 06:47:15 --> Total execution time: 0.0726
DEBUG - 2022-07-01 06:48:13 --> Total execution time: 0.1384
DEBUG - 2022-07-01 06:48:13 --> Total execution time: 0.0505
DEBUG - 2022-07-01 06:48:17 --> Total execution time: 0.0439
DEBUG - 2022-07-01 06:48:30 --> Total execution time: 0.0628
DEBUG - 2022-07-01 06:48:36 --> Total execution time: 0.0418
DEBUG - 2022-07-01 06:48:55 --> Total execution time: 0.0641
DEBUG - 2022-07-01 06:49:00 --> Total execution time: 0.0621
DEBUG - 2022-07-01 06:49:04 --> Total execution time: 0.0496
DEBUG - 2022-07-01 06:49:06 --> Total execution time: 0.0498
DEBUG - 2022-07-01 06:49:18 --> Total execution time: 0.0604
DEBUG - 2022-07-01 06:52:22 --> Total execution time: 0.1189
DEBUG - 2022-07-01 06:52:33 --> Total execution time: 0.1206
DEBUG - 2022-07-01 06:52:37 --> Total execution time: 0.0484
DEBUG - 2022-07-01 06:52:43 --> Total execution time: 0.0738
DEBUG - 2022-07-01 06:55:10 --> Total execution time: 0.0300
DEBUG - 2022-07-01 06:56:59 --> Total execution time: 0.0440
DEBUG - 2022-07-01 07:02:57 --> Total execution time: 0.1026
DEBUG - 2022-07-01 07:04:28 --> Total execution time: 0.0338
DEBUG - 2022-07-01 07:05:40 --> Total execution time: 0.0529
DEBUG - 2022-07-01 07:05:51 --> Total execution time: 0.0513
DEBUG - 2022-07-01 07:05:57 --> Total execution time: 0.0619
DEBUG - 2022-07-01 07:06:06 --> Total execution time: 0.0697
DEBUG - 2022-07-01 07:06:32 --> Total execution time: 0.0493
DEBUG - 2022-07-01 07:07:23 --> Total execution time: 0.0460
DEBUG - 2022-07-01 07:09:57 --> Total execution time: 0.1153
DEBUG - 2022-07-01 07:13:10 --> Total execution time: 0.1141
DEBUG - 2022-07-01 07:17:19 --> Total execution time: 0.1094
DEBUG - 2022-07-01 07:18:14 --> Total execution time: 0.0566
DEBUG - 2022-07-01 07:19:59 --> Total execution time: 0.0452
DEBUG - 2022-07-01 07:30:03 --> Total execution time: 0.1295
DEBUG - 2022-07-01 07:34:27 --> Total execution time: 0.0910
DEBUG - 2022-07-01 07:34:43 --> Total execution time: 0.0352
DEBUG - 2022-07-01 07:34:51 --> Total execution time: 0.0603
DEBUG - 2022-07-01 07:35:01 --> Total execution time: 0.0559
DEBUG - 2022-07-01 07:35:08 --> Total execution time: 0.0558
DEBUG - 2022-07-01 07:35:13 --> Total execution time: 0.0618
DEBUG - 2022-07-01 07:35:24 --> Total execution time: 0.0501
DEBUG - 2022-07-01 07:35:32 --> Total execution time: 0.0488
DEBUG - 2022-07-01 07:35:36 --> Total execution time: 0.0528
DEBUG - 2022-07-01 07:35:36 --> Total execution time: 0.0512
DEBUG - 2022-07-01 07:35:42 --> Total execution time: 0.0575
DEBUG - 2022-07-01 07:41:09 --> Total execution time: 0.0368
DEBUG - 2022-07-01 07:58:45 --> Total execution time: 0.0500
DEBUG - 2022-07-01 07:59:31 --> Total execution time: 0.0389
DEBUG - 2022-07-01 08:16:00 --> Total execution time: 0.0888
DEBUG - 2022-07-01 08:16:11 --> Total execution time: 0.0730
DEBUG - 2022-07-01 08:16:14 --> Total execution time: 0.0774
DEBUG - 2022-07-01 08:16:30 --> Total execution time: 0.1030
DEBUG - 2022-07-01 08:16:38 --> Total execution time: 0.0498
DEBUG - 2022-07-01 08:16:44 --> Total execution time: 0.0437
DEBUG - 2022-07-01 08:18:24 --> Total execution time: 0.0340
DEBUG - 2022-07-01 08:21:25 --> Total execution time: 0.1834
DEBUG - 2022-07-01 08:27:31 --> Total execution time: 0.0498
DEBUG - 2022-07-01 08:27:50 --> Total execution time: 0.0696
DEBUG - 2022-07-01 08:27:55 --> Total execution time: 0.0846
DEBUG - 2022-07-01 08:28:05 --> Total execution time: 0.0502
DEBUG - 2022-07-01 08:28:08 --> Total execution time: 0.0584
DEBUG - 2022-07-01 08:28:11 --> Total execution time: 0.0626
DEBUG - 2022-07-01 08:28:27 --> Total execution time: 0.0477
DEBUG - 2022-07-01 08:28:47 --> Total execution time: 0.0466
DEBUG - 2022-07-01 08:28:56 --> Total execution time: 0.0465
DEBUG - 2022-07-01 08:30:02 --> Total execution time: 0.0418
DEBUG - 2022-07-01 08:31:42 --> Total execution time: 0.0400
DEBUG - 2022-07-01 08:31:44 --> Total execution time: 0.0364
DEBUG - 2022-07-01 08:31:51 --> Total execution time: 0.0506
DEBUG - 2022-07-01 08:31:54 --> Total execution time: 0.0586
DEBUG - 2022-07-01 08:32:02 --> Total execution time: 0.0755
DEBUG - 2022-07-01 08:32:04 --> Total execution time: 0.0495
DEBUG - 2022-07-01 08:32:08 --> Total execution time: 0.0518
DEBUG - 2022-07-01 08:32:33 --> Total execution time: 0.0460
DEBUG - 2022-07-01 08:33:15 --> Total execution time: 0.0594
DEBUG - 2022-07-01 08:35:29 --> Total execution time: 0.1687
DEBUG - 2022-07-01 08:35:43 --> Total execution time: 0.0473
DEBUG - 2022-07-01 08:56:01 --> Total execution time: 0.1483
DEBUG - 2022-07-01 08:56:05 --> Total execution time: 0.0337
DEBUG - 2022-07-01 08:56:23 --> Total execution time: 0.0567
DEBUG - 2022-07-01 08:56:38 --> Total execution time: 0.0592
DEBUG - 2022-07-01 09:03:36 --> Total execution time: 0.0453
DEBUG - 2022-07-01 09:03:42 --> Total execution time: 0.0508
DEBUG - 2022-07-01 09:06:46 --> Total execution time: 0.0964
DEBUG - 2022-07-01 09:07:10 --> Total execution time: 0.1539
DEBUG - 2022-07-01 09:07:14 --> Total execution time: 0.0545
DEBUG - 2022-07-01 09:07:17 --> Total execution time: 0.0700
DEBUG - 2022-07-01 09:07:25 --> Total execution time: 0.0686
DEBUG - 2022-07-01 09:07:26 --> Total execution time: 0.0602
DEBUG - 2022-07-01 09:07:33 --> Total execution time: 0.0499
DEBUG - 2022-07-01 09:07:39 --> Total execution time: 0.0539
DEBUG - 2022-07-01 09:08:26 --> Total execution time: 0.0487
DEBUG - 2022-07-01 09:08:48 --> Total execution time: 0.0314
DEBUG - 2022-07-01 09:09:08 --> Total execution time: 0.0664
DEBUG - 2022-07-01 09:09:26 --> Total execution time: 0.0565
DEBUG - 2022-07-01 09:10:15 --> Total execution time: 0.0550
DEBUG - 2022-07-01 09:10:31 --> Total execution time: 0.0619
DEBUG - 2022-07-01 09:10:43 --> Total execution time: 0.0491
DEBUG - 2022-07-01 09:11:34 --> Total execution time: 0.0446
DEBUG - 2022-07-01 09:17:26 --> Total execution time: 0.1023
DEBUG - 2022-07-01 09:18:06 --> Total execution time: 0.0490
DEBUG - 2022-07-01 09:18:19 --> Total execution time: 0.0564
DEBUG - 2022-07-01 09:28:19 --> Total execution time: 0.0924
DEBUG - 2022-07-01 09:28:20 --> Total execution time: 0.0361
DEBUG - 2022-07-01 09:28:24 --> Total execution time: 0.0366
DEBUG - 2022-07-01 09:28:55 --> Total execution time: 0.0817
DEBUG - 2022-07-01 09:29:13 --> Total execution time: 0.0651
DEBUG - 2022-07-01 09:29:22 --> Total execution time: 0.1041
DEBUG - 2022-07-01 09:30:02 --> Total execution time: 0.1047
DEBUG - 2022-07-01 09:33:18 --> Total execution time: 0.0893
DEBUG - 2022-07-01 09:33:28 --> Total execution time: 0.0717
DEBUG - 2022-07-01 09:33:38 --> Total execution time: 0.0716
DEBUG - 2022-07-01 09:33:58 --> Total execution time: 0.0628
DEBUG - 2022-07-01 09:34:09 --> Total execution time: 0.0491
DEBUG - 2022-07-01 09:34:35 --> Total execution time: 0.1273
DEBUG - 2022-07-01 09:34:43 --> Total execution time: 0.0520
DEBUG - 2022-07-01 09:34:43 --> Total execution time: 0.1318
DEBUG - 2022-07-01 09:34:55 --> Total execution time: 0.0447
DEBUG - 2022-07-01 09:35:10 --> Total execution time: 0.0417
DEBUG - 2022-07-01 09:35:12 --> Total execution time: 0.0505
DEBUG - 2022-07-01 09:35:18 --> Total execution time: 0.0472
DEBUG - 2022-07-01 09:35:20 --> Total execution time: 0.0501
DEBUG - 2022-07-01 09:35:21 --> Total execution time: 0.0591
DEBUG - 2022-07-01 09:35:24 --> Total execution time: 0.0635
DEBUG - 2022-07-01 09:35:26 --> Total execution time: 0.0491
DEBUG - 2022-07-01 09:35:28 --> Total execution time: 0.0470
DEBUG - 2022-07-01 09:35:30 --> Total execution time: 0.0451
DEBUG - 2022-07-01 09:35:36 --> Total execution time: 0.0527
DEBUG - 2022-07-01 09:36:44 --> Total execution time: 0.0710
DEBUG - 2022-07-01 09:37:06 --> Total execution time: 0.1145
DEBUG - 2022-07-01 09:37:44 --> Total execution time: 0.0308
DEBUG - 2022-07-01 09:37:46 --> Total execution time: 0.0551
DEBUG - 2022-07-01 09:37:47 --> Total execution time: 0.0474
DEBUG - 2022-07-01 09:37:54 --> Total execution time: 0.0487
DEBUG - 2022-07-01 09:38:06 --> Total execution time: 0.0995
DEBUG - 2022-07-01 09:38:06 --> Total execution time: 0.0897
DEBUG - 2022-07-01 09:38:11 --> Total execution time: 0.0659
DEBUG - 2022-07-01 09:38:14 --> Total execution time: 0.0605
DEBUG - 2022-07-01 09:38:19 --> Total execution time: 0.0889
DEBUG - 2022-07-01 09:38:25 --> Total execution time: 0.0493
DEBUG - 2022-07-01 09:39:20 --> Total execution time: 0.0626
DEBUG - 2022-07-01 09:39:21 --> Total execution time: 0.0565
DEBUG - 2022-07-01 09:39:23 --> Total execution time: 0.0514
DEBUG - 2022-07-01 09:39:25 --> Total execution time: 0.0719
DEBUG - 2022-07-01 09:39:27 --> Total execution time: 0.0739
DEBUG - 2022-07-01 09:39:28 --> Total execution time: 0.0739
DEBUG - 2022-07-01 09:39:28 --> Total execution time: 0.0667
DEBUG - 2022-07-01 09:39:31 --> Total execution time: 0.0700
DEBUG - 2022-07-01 09:39:32 --> Total execution time: 0.0564
DEBUG - 2022-07-01 09:39:35 --> Total execution time: 0.1140
DEBUG - 2022-07-01 09:39:37 --> Total execution time: 0.0501
DEBUG - 2022-07-01 09:39:40 --> Total execution time: 0.0551
DEBUG - 2022-07-01 09:39:40 --> Total execution time: 0.0726
DEBUG - 2022-07-01 09:39:42 --> Total execution time: 0.0506
DEBUG - 2022-07-01 09:39:46 --> Total execution time: 0.0532
DEBUG - 2022-07-01 09:40:34 --> Total execution time: 0.0532
DEBUG - 2022-07-01 09:40:57 --> Total execution time: 0.0409
DEBUG - 2022-07-01 09:41:01 --> Total execution time: 0.0727
DEBUG - 2022-07-01 09:41:15 --> Total execution time: 0.0538
DEBUG - 2022-07-01 09:41:16 --> Total execution time: 0.0715
DEBUG - 2022-07-01 09:41:20 --> Total execution time: 0.0508
DEBUG - 2022-07-01 09:41:22 --> Total execution time: 0.0757
DEBUG - 2022-07-01 09:41:22 --> Total execution time: 0.0599
DEBUG - 2022-07-01 09:41:30 --> Total execution time: 0.1339
DEBUG - 2022-07-01 09:41:38 --> Total execution time: 0.0491
DEBUG - 2022-07-01 09:41:54 --> Total execution time: 0.0494
DEBUG - 2022-07-01 09:41:57 --> Total execution time: 0.0524
DEBUG - 2022-07-01 09:48:52 --> Total execution time: 0.1377
DEBUG - 2022-07-01 09:49:12 --> Total execution time: 0.0503
DEBUG - 2022-07-01 09:49:18 --> Total execution time: 0.0497
DEBUG - 2022-07-01 09:49:18 --> Total execution time: 0.0428
DEBUG - 2022-07-01 09:49:56 --> Total execution time: 0.0397
DEBUG - 2022-07-01 09:50:03 --> Total execution time: 0.0460
DEBUG - 2022-07-01 09:50:03 --> Total execution time: 0.0535
DEBUG - 2022-07-01 09:50:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:50:05 --> Total execution time: 0.0545
DEBUG - 2022-07-01 09:52:11 --> Total execution time: 0.1165
DEBUG - 2022-07-01 09:52:16 --> Total execution time: 0.0741
DEBUG - 2022-07-01 09:52:26 --> Total execution time: 0.0606
DEBUG - 2022-07-01 09:52:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:52:27 --> Total execution time: 0.0471
DEBUG - 2022-07-01 09:54:08 --> Total execution time: 0.0595
DEBUG - 2022-07-01 09:55:20 --> Total execution time: 0.1621
DEBUG - 2022-07-01 09:55:39 --> Total execution time: 0.0466
DEBUG - 2022-07-01 09:56:13 --> Total execution time: 0.0575
DEBUG - 2022-07-01 09:56:40 --> Total execution time: 0.0497
DEBUG - 2022-07-01 09:57:45 --> Total execution time: 0.0802
DEBUG - 2022-07-01 09:57:56 --> Total execution time: 0.0767
DEBUG - 2022-07-01 09:57:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:57:58 --> Total execution time: 0.0491
DEBUG - 2022-07-01 10:00:11 --> Total execution time: 0.1413
DEBUG - 2022-07-01 10:11:45 --> Total execution time: 0.0424
DEBUG - 2022-07-01 10:12:07 --> Total execution time: 0.1477
DEBUG - 2022-07-01 10:12:28 --> Total execution time: 0.0672
DEBUG - 2022-07-01 10:12:36 --> Total execution time: 0.0550
DEBUG - 2022-07-01 10:12:39 --> Total execution time: 0.0591
DEBUG - 2022-07-01 10:12:48 --> Total execution time: 0.0491
DEBUG - 2022-07-01 10:15:22 --> Total execution time: 0.0530
DEBUG - 2022-07-01 10:16:42 --> Total execution time: 0.1388
DEBUG - 2022-07-01 10:16:52 --> Total execution time: 0.0720
DEBUG - 2022-07-01 10:23:24 --> Total execution time: 0.2199
DEBUG - 2022-07-01 10:23:36 --> Total execution time: 0.0626
DEBUG - 2022-07-01 10:23:40 --> Total execution time: 0.0496
DEBUG - 2022-07-01 10:23:50 --> Total execution time: 0.0865
DEBUG - 2022-07-01 10:23:53 --> Total execution time: 0.0503
DEBUG - 2022-07-01 10:24:01 --> Total execution time: 0.0903
DEBUG - 2022-07-01 10:24:13 --> Total execution time: 0.0529
DEBUG - 2022-07-01 10:24:17 --> Total execution time: 0.0574
DEBUG - 2022-07-01 10:24:20 --> Total execution time: 0.0720
DEBUG - 2022-07-01 10:24:25 --> Total execution time: 0.0645
DEBUG - 2022-07-01 10:24:27 --> Total execution time: 0.0500
DEBUG - 2022-07-01 10:24:35 --> Total execution time: 0.0464
DEBUG - 2022-07-01 10:24:39 --> Total execution time: 0.0744
DEBUG - 2022-07-01 10:24:49 --> Total execution time: 0.0702
DEBUG - 2022-07-01 10:24:56 --> Total execution time: 0.0923
DEBUG - 2022-07-01 10:24:59 --> Total execution time: 0.0646
DEBUG - 2022-07-01 10:25:01 --> Total execution time: 0.0522
DEBUG - 2022-07-01 10:25:05 --> Total execution time: 0.0530
DEBUG - 2022-07-01 10:25:26 --> Total execution time: 0.0506
DEBUG - 2022-07-01 10:26:16 --> Total execution time: 0.0499
DEBUG - 2022-07-01 10:26:46 --> Total execution time: 0.0778
DEBUG - 2022-07-01 10:26:50 --> Total execution time: 0.0466
DEBUG - 2022-07-01 10:26:56 --> Total execution time: 0.0455
DEBUG - 2022-07-01 10:27:00 --> Total execution time: 0.0453
DEBUG - 2022-07-01 10:27:03 --> Total execution time: 0.0476
DEBUG - 2022-07-01 10:27:11 --> Total execution time: 0.0503
DEBUG - 2022-07-01 10:29:19 --> Total execution time: 0.1964
DEBUG - 2022-07-01 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:30:02 --> Total execution time: 0.0762
DEBUG - 2022-07-01 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:00 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:00 --> Total execution time: 0.0881
DEBUG - 2022-07-01 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:01 --> Total execution time: 0.1914
DEBUG - 2022-07-01 00:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:05 --> Total execution time: 0.0347
DEBUG - 2022-07-01 00:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:17 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:17 --> Total execution time: 0.0322
DEBUG - 2022-07-01 00:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:19 --> Total execution time: 0.0615
DEBUG - 2022-07-01 00:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:23 --> Total execution time: 0.0676
DEBUG - 2022-07-01 00:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:28 --> Total execution time: 0.1871
DEBUG - 2022-07-01 00:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:32 --> Total execution time: 0.0921
DEBUG - 2022-07-01 00:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:32 --> Total execution time: 0.0552
DEBUG - 2022-07-01 00:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:37 --> Total execution time: 0.0494
DEBUG - 2022-07-01 00:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:33:48 --> Total execution time: 0.0959
DEBUG - 2022-07-01 00:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:34:00 --> Total execution time: 0.0468
DEBUG - 2022-07-01 00:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:36:06 --> Total execution time: 0.1345
DEBUG - 2022-07-01 00:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:36:27 --> Total execution time: 0.0538
DEBUG - 2022-07-01 00:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:36:54 --> Total execution time: 0.0524
DEBUG - 2022-07-01 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:38:51 --> Total execution time: 0.0416
DEBUG - 2022-07-01 00:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:38:57 --> Total execution time: 0.0744
DEBUG - 2022-07-01 00:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:39:03 --> Total execution time: 0.0600
DEBUG - 2022-07-01 00:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:39:11 --> Total execution time: 0.0627
DEBUG - 2022-07-01 00:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:39:14 --> Total execution time: 0.0577
DEBUG - 2022-07-01 00:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:39:19 --> Total execution time: 0.0684
DEBUG - 2022-07-01 00:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:40:14 --> Total execution time: 0.0956
DEBUG - 2022-07-01 00:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:10:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:40:33 --> Total execution time: 0.0590
DEBUG - 2022-07-01 00:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:40:38 --> Total execution time: 0.0489
DEBUG - 2022-07-01 00:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:08 --> Total execution time: 0.0549
DEBUG - 2022-07-01 00:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:21 --> Total execution time: 0.0713
DEBUG - 2022-07-01 00:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:29 --> Total execution time: 0.1107
DEBUG - 2022-07-01 00:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:33 --> Total execution time: 0.0537
DEBUG - 2022-07-01 00:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:36 --> Total execution time: 0.0716
DEBUG - 2022-07-01 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:46 --> Total execution time: 0.1116
DEBUG - 2022-07-01 00:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:49 --> Total execution time: 0.0632
DEBUG - 2022-07-01 00:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:53 --> Total execution time: 0.0612
DEBUG - 2022-07-01 00:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:41:58 --> Total execution time: 0.0762
DEBUG - 2022-07-01 00:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:42:06 --> Total execution time: 0.0527
DEBUG - 2022-07-01 00:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:42:08 --> Total execution time: 0.0519
DEBUG - 2022-07-01 00:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:12:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:42:08 --> Total execution time: 0.0473
DEBUG - 2022-07-01 00:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:45:29 --> Total execution time: 0.1281
DEBUG - 2022-07-01 00:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:16:57 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:46:57 --> Total execution time: 0.0599
DEBUG - 2022-07-01 00:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:47:01 --> Total execution time: 0.0451
DEBUG - 2022-07-01 00:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:47:06 --> Total execution time: 0.0782
DEBUG - 2022-07-01 00:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:47:09 --> Total execution time: 0.0693
DEBUG - 2022-07-01 00:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:47:16 --> Total execution time: 0.0524
DEBUG - 2022-07-01 00:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:47:21 --> Total execution time: 0.0485
DEBUG - 2022-07-01 00:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:47:28 --> Total execution time: 0.0714
DEBUG - 2022-07-01 00:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:17:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:47:37 --> Total execution time: 0.0573
DEBUG - 2022-07-01 00:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:48:50 --> Total execution time: 0.0508
DEBUG - 2022-07-01 00:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:48:54 --> Total execution time: 0.0602
DEBUG - 2022-07-01 00:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:50:56 --> Total execution time: 0.2071
DEBUG - 2022-07-01 00:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:50:56 --> Total execution time: 0.0529
DEBUG - 2022-07-01 00:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:51:59 --> Total execution time: 0.0832
DEBUG - 2022-07-01 00:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:03 --> Total execution time: 0.0468
DEBUG - 2022-07-01 00:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:35 --> Total execution time: 0.0602
DEBUG - 2022-07-01 00:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:39 --> Total execution time: 0.0576
DEBUG - 2022-07-01 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:42 --> Total execution time: 0.0506
DEBUG - 2022-07-01 00:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:48 --> Total execution time: 0.0562
DEBUG - 2022-07-01 00:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:52 --> Total execution time: 0.0675
DEBUG - 2022-07-01 00:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:55 --> Total execution time: 0.1185
DEBUG - 2022-07-01 00:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:59 --> Total execution time: 0.0634
DEBUG - 2022-07-01 00:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:53:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 00:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:53:00 --> Total execution time: 0.0416
DEBUG - 2022-07-01 00:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:54:07 --> Total execution time: 0.0621
DEBUG - 2022-07-01 00:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:24:18 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 00:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:54:31 --> Total execution time: 0.0506
DEBUG - 2022-07-01 00:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:55:04 --> Total execution time: 0.0462
DEBUG - 2022-07-01 00:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:55:17 --> Total execution time: 0.0518
DEBUG - 2022-07-01 00:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:26:44 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 00:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:56:58 --> Total execution time: 0.0483
DEBUG - 2022-07-01 00:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:56:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 00:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:56:59 --> Total execution time: 0.0506
DEBUG - 2022-07-01 00:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:28:50 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 00:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:58:53 --> Total execution time: 0.1153
DEBUG - 2022-07-01 00:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:58:55 --> Total execution time: 0.0576
DEBUG - 2022-07-01 00:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:29:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:59:08 --> Total execution time: 0.0579
DEBUG - 2022-07-01 00:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:59:16 --> Total execution time: 0.1295
DEBUG - 2022-07-01 00:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:59:20 --> Total execution time: 0.0484
DEBUG - 2022-07-01 00:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:59:32 --> Total execution time: 0.0602
DEBUG - 2022-07-01 00:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:59:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 00:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:59:33 --> Total execution time: 0.0580
DEBUG - 2022-07-01 00:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:30:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:00:05 --> Total execution time: 0.0387
DEBUG - 2022-07-01 00:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:30:39 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:00:39 --> Total execution time: 0.0407
DEBUG - 2022-07-01 00:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:00:53 --> Total execution time: 0.0535
DEBUG - 2022-07-01 00:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:00:59 --> Total execution time: 0.0646
DEBUG - 2022-07-01 00:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:01:02 --> Total execution time: 0.0482
DEBUG - 2022-07-01 00:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:01:12 --> Total execution time: 0.0498
DEBUG - 2022-07-01 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:01:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 00:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:01:14 --> Total execution time: 0.0395
DEBUG - 2022-07-01 00:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:31:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:01:49 --> Total execution time: 0.0518
DEBUG - 2022-07-01 00:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:00 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:00 --> Total execution time: 0.0447
DEBUG - 2022-07-01 00:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:06 --> Total execution time: 0.0458
DEBUG - 2022-07-01 00:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:20 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:20 --> Total execution time: 0.0560
DEBUG - 2022-07-01 00:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:24 --> Total execution time: 0.0439
DEBUG - 2022-07-01 00:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:24 --> Total execution time: 0.0475
DEBUG - 2022-07-01 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:51 --> Total execution time: 0.1053
DEBUG - 2022-07-01 00:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:53 --> Total execution time: 0.0517
DEBUG - 2022-07-01 00:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:55 --> Total execution time: 0.0506
DEBUG - 2022-07-01 00:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:08 --> Total execution time: 0.0608
DEBUG - 2022-07-01 00:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:22 --> Total execution time: 0.0559
DEBUG - 2022-07-01 00:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:35 --> Total execution time: 0.0906
DEBUG - 2022-07-01 00:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:38 --> Total execution time: 0.0470
DEBUG - 2022-07-01 00:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:38 --> Total execution time: 0.0502
DEBUG - 2022-07-01 00:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:44 --> Total execution time: 0.0615
DEBUG - 2022-07-01 00:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:48 --> Total execution time: 0.0583
DEBUG - 2022-07-01 00:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 00:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:49 --> Total execution time: 0.0763
DEBUG - 2022-07-01 00:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:04:13 --> Total execution time: 0.1410
DEBUG - 2022-07-01 00:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:04:16 --> Total execution time: 0.0591
DEBUG - 2022-07-01 00:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:04:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 00:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:04:17 --> Total execution time: 0.0489
DEBUG - 2022-07-01 00:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:04:23 --> Total execution time: 0.0661
DEBUG - 2022-07-01 00:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:34:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:04:33 --> Total execution time: 0.0457
DEBUG - 2022-07-01 00:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:34:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:04:36 --> Total execution time: 0.0471
DEBUG - 2022-07-01 00:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:35:20 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:05:20 --> Total execution time: 0.0333
DEBUG - 2022-07-01 00:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:06:04 --> Total execution time: 0.1273
DEBUG - 2022-07-01 00:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:36:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:36:05 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 00:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:06:08 --> Total execution time: 0.0574
DEBUG - 2022-07-01 00:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:06:14 --> Total execution time: 0.0567
DEBUG - 2022-07-01 00:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:06:23 --> Total execution time: 0.0447
DEBUG - 2022-07-01 00:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:06:40 --> Total execution time: 0.0454
DEBUG - 2022-07-01 00:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:07:02 --> Total execution time: 0.0694
DEBUG - 2022-07-01 00:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:07:05 --> Total execution time: 0.0734
DEBUG - 2022-07-01 00:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:07:05 --> Total execution time: 0.0500
DEBUG - 2022-07-01 00:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:07:11 --> Total execution time: 0.1142
DEBUG - 2022-07-01 00:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:07:11 --> Total execution time: 0.0523
DEBUG - 2022-07-01 00:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:37:27 --> Total execution time: 0.0476
DEBUG - 2022-07-01 00:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:37:28 --> Total execution time: 0.0798
DEBUG - 2022-07-01 00:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:37:28 --> Total execution time: 0.0897
DEBUG - 2022-07-01 00:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:08:19 --> Total execution time: 0.0688
DEBUG - 2022-07-01 00:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:08:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 00:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:08:20 --> Total execution time: 0.0607
DEBUG - 2022-07-01 00:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:08:46 --> Total execution time: 0.0483
DEBUG - 2022-07-01 00:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:39:46 --> Total execution time: 0.0501
DEBUG - 2022-07-01 00:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:39:47 --> Total execution time: 0.0541
DEBUG - 2022-07-01 00:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:39:47 --> Total execution time: 0.0658
DEBUG - 2022-07-01 00:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:39:54 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:09:54 --> Total execution time: 0.0514
DEBUG - 2022-07-01 00:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:10:00 --> Total execution time: 0.0628
DEBUG - 2022-07-01 00:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:13 --> Total execution time: 0.1166
DEBUG - 2022-07-01 00:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:15 --> Total execution time: 0.0479
DEBUG - 2022-07-01 00:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:17 --> Total execution time: 0.0533
DEBUG - 2022-07-01 00:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:19 --> Total execution time: 0.0551
DEBUG - 2022-07-01 00:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:22 --> Total execution time: 0.1247
DEBUG - 2022-07-01 00:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:23 --> Total execution time: 0.0509
DEBUG - 2022-07-01 00:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:25 --> Total execution time: 0.0488
DEBUG - 2022-07-01 00:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:28 --> Total execution time: 0.0542
DEBUG - 2022-07-01 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:31 --> Total execution time: 0.0505
DEBUG - 2022-07-01 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:35 --> Total execution time: 0.0534
DEBUG - 2022-07-01 00:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:12:06 --> Total execution time: 0.0483
DEBUG - 2022-07-01 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:12:07 --> Total execution time: 0.0564
DEBUG - 2022-07-01 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:12:12 --> Total execution time: 0.0570
DEBUG - 2022-07-01 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:12:15 --> Total execution time: 0.0455
DEBUG - 2022-07-01 00:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:12:40 --> Total execution time: 0.0582
DEBUG - 2022-07-01 00:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:12:47 --> Total execution time: 0.0479
DEBUG - 2022-07-01 00:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:12:57 --> Total execution time: 0.0658
DEBUG - 2022-07-01 00:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:43:10 --> Total execution time: 0.0562
DEBUG - 2022-07-01 00:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:43:11 --> Total execution time: 0.0574
DEBUG - 2022-07-01 00:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:43:11 --> Total execution time: 0.1029
DEBUG - 2022-07-01 00:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:13:21 --> Total execution time: 0.0578
DEBUG - 2022-07-01 00:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:13:27 --> Total execution time: 0.0527
DEBUG - 2022-07-01 00:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:13:50 --> Total execution time: 0.0485
DEBUG - 2022-07-01 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:13:59 --> Total execution time: 0.0573
DEBUG - 2022-07-01 00:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:14:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:14:00 --> Total execution time: 0.0473
DEBUG - 2022-07-01 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:14:06 --> Total execution time: 0.0481
DEBUG - 2022-07-01 00:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:32 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:14:33 --> Total execution time: 0.0816
DEBUG - 2022-07-01 00:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:14:37 --> Total execution time: 0.0505
DEBUG - 2022-07-01 00:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:41 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:14:41 --> Total execution time: 0.0541
DEBUG - 2022-07-01 00:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:14:43 --> Total execution time: 0.0316
DEBUG - 2022-07-01 00:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:44:44 --> Total execution time: 0.0490
DEBUG - 2022-07-01 00:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:46 --> Total execution time: 0.0503
DEBUG - 2022-07-01 00:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:44:46 --> Total execution time: 0.0580
DEBUG - 2022-07-01 00:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:44:48 --> Total execution time: 0.0479
DEBUG - 2022-07-01 00:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:44:49 --> Total execution time: 0.0570
DEBUG - 2022-07-01 00:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:44:49 --> Total execution time: 0.0911
DEBUG - 2022-07-01 00:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:44:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:44:59 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 00:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:45:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:45:02 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 00:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:15:30 --> Total execution time: 0.1415
DEBUG - 2022-07-01 00:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:17:27 --> Total execution time: 0.1594
DEBUG - 2022-07-01 00:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:17:32 --> Total execution time: 0.0521
DEBUG - 2022-07-01 00:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:23 --> No URI present. Default controller set.
DEBUG - 2022-07-01 00:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:23 --> Total execution time: 0.0574
DEBUG - 2022-07-01 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:27 --> Total execution time: 0.0285
DEBUG - 2022-07-01 00:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:37 --> Total execution time: 0.0552
DEBUG - 2022-07-01 00:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:44 --> Total execution time: 0.0468
DEBUG - 2022-07-01 00:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:46 --> Total execution time: 0.0565
DEBUG - 2022-07-01 00:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:48 --> Total execution time: 0.0529
DEBUG - 2022-07-01 00:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:56 --> Total execution time: 0.0657
DEBUG - 2022-07-01 00:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:59 --> Total execution time: 0.1041
DEBUG - 2022-07-01 00:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:19:11 --> Total execution time: 0.0635
DEBUG - 2022-07-01 00:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:19:11 --> Total execution time: 0.0646
DEBUG - 2022-07-01 00:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:19:47 --> Total execution time: 0.0822
DEBUG - 2022-07-01 00:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:20:10 --> Total execution time: 0.0814
DEBUG - 2022-07-01 00:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:20:13 --> Total execution time: 0.0561
DEBUG - 2022-07-01 00:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:20:25 --> Total execution time: 0.0486
DEBUG - 2022-07-01 00:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:51:04 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-01 00:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:51:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 00:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:51:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 00:51:38 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 00:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:26:18 --> Total execution time: 0.0517
DEBUG - 2022-07-01 00:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:26:21 --> Total execution time: 0.0527
DEBUG - 2022-07-01 00:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 00:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:26:31 --> Total execution time: 0.0531
DEBUG - 2022-07-01 00:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:26:35 --> Total execution time: 0.0611
DEBUG - 2022-07-01 00:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:26:38 --> Total execution time: 0.0632
DEBUG - 2022-07-01 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 00:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 00:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:26:48 --> Total execution time: 0.0768
DEBUG - 2022-07-01 01:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:30:03 --> Total execution time: 0.1752
DEBUG - 2022-07-01 01:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:01:01 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:31:02 --> Total execution time: 0.1576
DEBUG - 2022-07-01 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:31:28 --> Total execution time: 0.1100
DEBUG - 2022-07-01 01:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:31:33 --> Total execution time: 0.0550
DEBUG - 2022-07-01 01:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:32:10 --> Total execution time: 0.0873
DEBUG - 2022-07-01 01:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:32:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 01:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:32:11 --> Total execution time: 0.0505
DEBUG - 2022-07-01 01:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 01:02:33 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-07-01 01:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 01:02:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 01:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 01:02:40 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-07-01 01:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 01:02:42 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-07-01 01:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 01:02:44 --> 404 Page Not Found: User/forgot-password-email-otp
DEBUG - 2022-07-01 01:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:32:44 --> Total execution time: 0.0576
DEBUG - 2022-07-01 01:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:32:49 --> Total execution time: 0.0465
DEBUG - 2022-07-01 01:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:32:51 --> Total execution time: 0.0582
DEBUG - 2022-07-01 01:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:33:01 --> Total execution time: 0.0584
DEBUG - 2022-07-01 01:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:33:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 01:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:33:02 --> Total execution time: 0.0450
DEBUG - 2022-07-01 01:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:04:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:34:15 --> Total execution time: 0.0819
DEBUG - 2022-07-01 01:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:34:19 --> Total execution time: 0.0336
DEBUG - 2022-07-01 01:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:34:28 --> Total execution time: 0.0533
DEBUG - 2022-07-01 01:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:34:33 --> Total execution time: 0.0714
DEBUG - 2022-07-01 01:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:34:46 --> Total execution time: 0.0500
DEBUG - 2022-07-01 01:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:34:52 --> Total execution time: 0.0553
DEBUG - 2022-07-01 01:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:34:55 --> Total execution time: 0.0709
DEBUG - 2022-07-01 01:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:35:12 --> Total execution time: 0.0450
DEBUG - 2022-07-01 01:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:35:14 --> Total execution time: 0.0519
DEBUG - 2022-07-01 01:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:36:01 --> Total execution time: 0.0470
DEBUG - 2022-07-01 01:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:08:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:38:48 --> Total execution time: 0.1263
DEBUG - 2022-07-01 01:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:09:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:39:02 --> Total execution time: 0.0526
DEBUG - 2022-07-01 01:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:39:33 --> Total execution time: 0.0544
DEBUG - 2022-07-01 01:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:39:35 --> Total execution time: 0.0497
DEBUG - 2022-07-01 01:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:39:48 --> Total execution time: 0.0447
DEBUG - 2022-07-01 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:39:57 --> Total execution time: 0.0624
DEBUG - 2022-07-01 01:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:02 --> Total execution time: 0.0657
DEBUG - 2022-07-01 01:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:10 --> Total execution time: 0.0942
DEBUG - 2022-07-01 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:18 --> Total execution time: 0.0471
DEBUG - 2022-07-01 01:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:19 --> Total execution time: 0.0482
DEBUG - 2022-07-01 01:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:10:28 --> Total execution time: 0.0357
DEBUG - 2022-07-01 01:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:10:29 --> Total execution time: 0.0599
DEBUG - 2022-07-01 01:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:10:29 --> Total execution time: 0.0788
DEBUG - 2022-07-01 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:39 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:39 --> Total execution time: 0.0418
DEBUG - 2022-07-01 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:39 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:39 --> Total execution time: 0.0376
DEBUG - 2022-07-01 01:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:50 --> Total execution time: 0.0441
DEBUG - 2022-07-01 01:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:54 --> Total execution time: 0.0444
DEBUG - 2022-07-01 01:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:40:55 --> Total execution time: 0.0680
DEBUG - 2022-07-01 01:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:41:02 --> Total execution time: 0.0534
DEBUG - 2022-07-01 01:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:41:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 01:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:41:03 --> Total execution time: 0.0480
DEBUG - 2022-07-01 01:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:11:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:41:07 --> Total execution time: 0.0677
DEBUG - 2022-07-01 01:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:02 --> Total execution time: 0.0879
DEBUG - 2022-07-01 01:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:22 --> Total execution time: 0.0644
DEBUG - 2022-07-01 01:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:12:31 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:31 --> Total execution time: 0.0535
DEBUG - 2022-07-01 01:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:32 --> Total execution time: 0.0887
DEBUG - 2022-07-01 01:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:19 --> Total execution time: 0.0824
DEBUG - 2022-07-01 01:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:21 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:21 --> Total execution time: 0.0470
DEBUG - 2022-07-01 01:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:25 --> Total execution time: 0.0452
DEBUG - 2022-07-01 01:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:28 --> Total execution time: 0.0989
DEBUG - 2022-07-01 01:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:37 --> Total execution time: 0.0451
DEBUG - 2022-07-01 01:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:39 --> Total execution time: 0.0512
DEBUG - 2022-07-01 01:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:43 --> Total execution time: 0.0529
DEBUG - 2022-07-01 01:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:48 --> Total execution time: 0.0489
DEBUG - 2022-07-01 01:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:56 --> Total execution time: 0.0614
DEBUG - 2022-07-01 01:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:59 --> Total execution time: 0.0519
DEBUG - 2022-07-01 01:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:04 --> Total execution time: 0.1321
DEBUG - 2022-07-01 01:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:15 --> Total execution time: 0.0759
DEBUG - 2022-07-01 01:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:21 --> Total execution time: 0.1262
DEBUG - 2022-07-01 01:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:24 --> Total execution time: 0.0723
DEBUG - 2022-07-01 01:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:26 --> Total execution time: 0.1024
DEBUG - 2022-07-01 01:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:29 --> Total execution time: 0.0574
DEBUG - 2022-07-01 01:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:40 --> Total execution time: 0.0555
DEBUG - 2022-07-01 01:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:41 --> Total execution time: 0.0579
DEBUG - 2022-07-01 01:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:50 --> Total execution time: 0.0670
DEBUG - 2022-07-01 01:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:51 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:51 --> Total execution time: 0.0551
DEBUG - 2022-07-01 01:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:55 --> Total execution time: 0.0514
DEBUG - 2022-07-01 01:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:44:58 --> Total execution time: 0.0817
DEBUG - 2022-07-01 01:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:45:12 --> Total execution time: 0.0534
DEBUG - 2022-07-01 01:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:46:11 --> Total execution time: 0.0485
DEBUG - 2022-07-01 01:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:46:41 --> Total execution time: 0.0496
DEBUG - 2022-07-01 01:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:47:15 --> Total execution time: 0.0669
DEBUG - 2022-07-01 01:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:47:18 --> Total execution time: 0.0500
DEBUG - 2022-07-01 01:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:47:30 --> Total execution time: 0.0597
DEBUG - 2022-07-01 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:47:31 --> Total execution time: 0.0834
DEBUG - 2022-07-01 01:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:47:48 --> Total execution time: 0.1159
DEBUG - 2022-07-01 01:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:47:51 --> Total execution time: 0.0496
DEBUG - 2022-07-01 01:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:47:53 --> Total execution time: 0.0518
DEBUG - 2022-07-01 01:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:00 --> Total execution time: 0.0493
DEBUG - 2022-07-01 01:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:01 --> Total execution time: 0.1264
DEBUG - 2022-07-01 01:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:03 --> Total execution time: 0.0456
DEBUG - 2022-07-01 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:04 --> Total execution time: 0.0560
DEBUG - 2022-07-01 01:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:05 --> Total execution time: 0.0726
DEBUG - 2022-07-01 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:06 --> Total execution time: 0.0447
DEBUG - 2022-07-01 01:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:35 --> Total execution time: 0.0687
DEBUG - 2022-07-01 01:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:39 --> Total execution time: 0.0859
DEBUG - 2022-07-01 01:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:48:39 --> Total execution time: 0.1026
DEBUG - 2022-07-01 01:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:19:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:49:13 --> Total execution time: 0.0343
DEBUG - 2022-07-01 01:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:23:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:53:05 --> Total execution time: 0.1034
DEBUG - 2022-07-01 01:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:53:49 --> Total execution time: 0.0512
DEBUG - 2022-07-01 01:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:23:58 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:53:58 --> Total execution time: 0.1358
DEBUG - 2022-07-01 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:05 --> Total execution time: 0.1130
DEBUG - 2022-07-01 01:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:26 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:26 --> Total execution time: 0.0670
DEBUG - 2022-07-01 01:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:26 --> Total execution time: 0.0557
DEBUG - 2022-07-01 01:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:30 --> Total execution time: 0.0565
DEBUG - 2022-07-01 01:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:38 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:38 --> Total execution time: 0.0513
DEBUG - 2022-07-01 01:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:41 --> Total execution time: 0.1404
DEBUG - 2022-07-01 01:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:47 --> Total execution time: 0.1086
DEBUG - 2022-07-01 01:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:54 --> Total execution time: 0.0450
DEBUG - 2022-07-01 01:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:05 --> Total execution time: 0.0550
DEBUG - 2022-07-01 01:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:05 --> Total execution time: 0.1462
DEBUG - 2022-07-01 01:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:06 --> Total execution time: 0.0654
DEBUG - 2022-07-01 01:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:07 --> Total execution time: 0.0911
DEBUG - 2022-07-01 01:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:09 --> Total execution time: 0.0541
DEBUG - 2022-07-01 01:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:12 --> Total execution time: 0.0698
DEBUG - 2022-07-01 01:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:12 --> Total execution time: 0.0861
DEBUG - 2022-07-01 01:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:14 --> Total execution time: 0.0562
DEBUG - 2022-07-01 01:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:24 --> Total execution time: 0.0584
DEBUG - 2022-07-01 01:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:55:49 --> Total execution time: 0.0510
DEBUG - 2022-07-01 01:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:57:25 --> Total execution time: 0.0614
DEBUG - 2022-07-01 01:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:27:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:57:33 --> Total execution time: 0.0519
DEBUG - 2022-07-01 01:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:57:34 --> Total execution time: 0.0548
DEBUG - 2022-07-01 01:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:57:42 --> Total execution time: 0.0535
DEBUG - 2022-07-01 01:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:57:49 --> Total execution time: 0.0781
DEBUG - 2022-07-01 01:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:58:00 --> Total execution time: 0.0802
DEBUG - 2022-07-01 01:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:29:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:59:07 --> Total execution time: 0.0756
DEBUG - 2022-07-01 01:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:29:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:59:10 --> Total execution time: 0.1327
DEBUG - 2022-07-01 01:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:29:16 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:59:16 --> Total execution time: 0.0567
DEBUG - 2022-07-01 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:29:38 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:59:38 --> Total execution time: 0.0626
DEBUG - 2022-07-01 01:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:30:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:00:24 --> Total execution time: 0.0490
DEBUG - 2022-07-01 01:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:30:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:00:37 --> Total execution time: 0.0370
DEBUG - 2022-07-01 01:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:00:44 --> Total execution time: 0.0562
DEBUG - 2022-07-01 01:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:07 --> Total execution time: 0.0735
DEBUG - 2022-07-01 01:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:08 --> Total execution time: 0.0383
DEBUG - 2022-07-01 01:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:09 --> Total execution time: 0.0545
DEBUG - 2022-07-01 01:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:16 --> Total execution time: 0.0951
DEBUG - 2022-07-01 01:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:16 --> Total execution time: 0.0708
DEBUG - 2022-07-01 01:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:23 --> Total execution time: 0.0798
DEBUG - 2022-07-01 01:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:48 --> Total execution time: 0.0750
DEBUG - 2022-07-01 01:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:50 --> Total execution time: 0.0704
DEBUG - 2022-07-01 01:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:53 --> Total execution time: 0.0607
DEBUG - 2022-07-01 01:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:31:54 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:01:55 --> Total execution time: 0.0682
DEBUG - 2022-07-01 01:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:02:22 --> Total execution time: 0.0532
DEBUG - 2022-07-01 01:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:02:33 --> Total execution time: 0.0660
DEBUG - 2022-07-01 01:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:02:37 --> Total execution time: 0.0455
DEBUG - 2022-07-01 01:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:02:41 --> Total execution time: 0.0550
DEBUG - 2022-07-01 01:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:02:43 --> Total execution time: 0.0453
DEBUG - 2022-07-01 01:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:02:43 --> Total execution time: 0.0518
DEBUG - 2022-07-01 01:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:02:46 --> Total execution time: 0.0472
DEBUG - 2022-07-01 01:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:02:47 --> Total execution time: 0.0519
DEBUG - 2022-07-01 01:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:03:04 --> Total execution time: 0.0708
DEBUG - 2022-07-01 01:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:33:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:03:08 --> Total execution time: 0.0476
DEBUG - 2022-07-01 01:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:33:17 --> Total execution time: 0.0609
DEBUG - 2022-07-01 01:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:33:18 --> Total execution time: 0.0891
DEBUG - 2022-07-01 01:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:33:18 --> Total execution time: 0.1674
DEBUG - 2022-07-01 01:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:33:26 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:03:26 --> Total execution time: 0.0679
DEBUG - 2022-07-01 01:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:03:52 --> Total execution time: 0.0587
DEBUG - 2022-07-01 01:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:04:42 --> Total execution time: 0.1359
DEBUG - 2022-07-01 01:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:04:46 --> Total execution time: 0.0714
DEBUG - 2022-07-01 01:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:04:56 --> Total execution time: 0.0621
DEBUG - 2022-07-01 01:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:06 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:05:06 --> Total execution time: 0.0386
DEBUG - 2022-07-01 01:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:05:06 --> Total execution time: 0.0477
DEBUG - 2022-07-01 01:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:16 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:05:16 --> Total execution time: 0.0378
DEBUG - 2022-07-01 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:05:30 --> Total execution time: 0.0523
DEBUG - 2022-07-01 01:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:05:42 --> Total execution time: 0.0556
DEBUG - 2022-07-01 01:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:05:47 --> Total execution time: 0.0782
DEBUG - 2022-07-01 01:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:05:57 --> Total execution time: 0.0752
DEBUG - 2022-07-01 01:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:06:11 --> Total execution time: 0.0471
DEBUG - 2022-07-01 01:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:06:14 --> Total execution time: 0.1192
DEBUG - 2022-07-01 01:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:06:15 --> Total execution time: 0.0552
DEBUG - 2022-07-01 01:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:36:24 --> Total execution time: 0.0527
DEBUG - 2022-07-01 01:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:36:26 --> Total execution time: 0.0681
DEBUG - 2022-07-01 01:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:36:26 --> Total execution time: 0.0897
DEBUG - 2022-07-01 01:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:36:32 --> Total execution time: 0.0467
DEBUG - 2022-07-01 01:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:36:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 01:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:06:43 --> Total execution time: 2.0350
DEBUG - 2022-07-01 01:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 01:36:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 01:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:36:47 --> Total execution time: 0.0542
DEBUG - 2022-07-01 01:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:36:47 --> Total execution time: 0.0693
DEBUG - 2022-07-01 01:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:38:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 01:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:08:18 --> Total execution time: 0.0647
DEBUG - 2022-07-01 01:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:08:18 --> Total execution time: 1.6342
DEBUG - 2022-07-01 01:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:08:19 --> Total execution time: 0.0570
DEBUG - 2022-07-01 01:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 01:38:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 01:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:08:26 --> Total execution time: 0.0447
DEBUG - 2022-07-01 01:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:08:39 --> Total execution time: 0.0977
DEBUG - 2022-07-01 01:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:08:44 --> Total execution time: 0.0712
DEBUG - 2022-07-01 01:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:38:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 01:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:01 --> Total execution time: 1.5090
DEBUG - 2022-07-01 01:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:05 --> Total execution time: 0.0523
DEBUG - 2022-07-01 01:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:09 --> Total execution time: 0.0512
DEBUG - 2022-07-01 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 01:39:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:15 --> Total execution time: 0.0702
DEBUG - 2022-07-01 01:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:16 --> Total execution time: 0.1322
DEBUG - 2022-07-01 01:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:19 --> Total execution time: 0.0686
DEBUG - 2022-07-01 01:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:19 --> Total execution time: 0.1164
DEBUG - 2022-07-01 01:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:23 --> Total execution time: 0.0495
DEBUG - 2022-07-01 01:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:27 --> Total execution time: 0.0736
DEBUG - 2022-07-01 01:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:29 --> Total execution time: 0.0609
DEBUG - 2022-07-01 01:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:30 --> Total execution time: 0.0631
DEBUG - 2022-07-01 01:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:35 --> Total execution time: 0.0642
DEBUG - 2022-07-01 01:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:38 --> Total execution time: 0.0548
DEBUG - 2022-07-01 01:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:39 --> Total execution time: 0.0563
DEBUG - 2022-07-01 01:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 01:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:41 --> Total execution time: 0.0660
DEBUG - 2022-07-01 01:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 12:09:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 12:09:43 --> Total execution time: 0.2109
DEBUG - 2022-07-01 01:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:43 --> Total execution time: 0.0718
DEBUG - 2022-07-01 01:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:44 --> Total execution time: 0.0693
DEBUG - 2022-07-01 01:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:51 --> Total execution time: 0.0442
DEBUG - 2022-07-01 01:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:09:57 --> Total execution time: 0.0582
DEBUG - 2022-07-01 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:10:15 --> Total execution time: 0.0707
DEBUG - 2022-07-01 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:10:37 --> Total execution time: 0.1088
DEBUG - 2022-07-01 01:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:11:32 --> Total execution time: 0.0789
DEBUG - 2022-07-01 01:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:11:42 --> Total execution time: 0.1234
DEBUG - 2022-07-01 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:11:46 --> Total execution time: 0.0605
DEBUG - 2022-07-01 01:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:41:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:11:48 --> Total execution time: 0.0545
DEBUG - 2022-07-01 01:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:11:48 --> Total execution time: 0.0847
DEBUG - 2022-07-01 01:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:12 --> Total execution time: 0.0540
DEBUG - 2022-07-01 01:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:16 --> Total execution time: 0.0610
DEBUG - 2022-07-01 01:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:26 --> Total execution time: 0.0511
DEBUG - 2022-07-01 01:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:26 --> Total execution time: 0.0540
DEBUG - 2022-07-01 01:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:28 --> Total execution time: 0.0524
DEBUG - 2022-07-01 01:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:33 --> Total execution time: 0.0886
DEBUG - 2022-07-01 01:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:44 --> Total execution time: 0.0472
DEBUG - 2022-07-01 01:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:45 --> Total execution time: 0.0917
DEBUG - 2022-07-01 01:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:12:58 --> Total execution time: 0.0489
DEBUG - 2022-07-01 01:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:13:05 --> Total execution time: 0.0740
DEBUG - 2022-07-01 01:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:13:09 --> Total execution time: 0.0891
DEBUG - 2022-07-01 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:13:18 --> Total execution time: 0.0823
DEBUG - 2022-07-01 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:13:19 --> Total execution time: 0.0660
DEBUG - 2022-07-01 01:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:13:28 --> Total execution time: 0.0742
DEBUG - 2022-07-01 01:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:13:50 --> Total execution time: 0.0499
DEBUG - 2022-07-01 01:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:13:58 --> Total execution time: 0.0799
DEBUG - 2022-07-01 01:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:36 --> Total execution time: 0.0492
DEBUG - 2022-07-01 01:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:40 --> Total execution time: 0.0457
DEBUG - 2022-07-01 01:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:44 --> Total execution time: 0.0532
DEBUG - 2022-07-01 01:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:52 --> Total execution time: 0.0437
DEBUG - 2022-07-01 01:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:44:57 --> Total execution time: 0.0596
DEBUG - 2022-07-01 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:45:00 --> Total execution time: 0.0539
DEBUG - 2022-07-01 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:45:00 --> Total execution time: 0.0545
DEBUG - 2022-07-01 01:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:45:26 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:15:26 --> Total execution time: 0.0501
DEBUG - 2022-07-01 01:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:15:51 --> Total execution time: 0.1230
DEBUG - 2022-07-01 01:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:16:04 --> Total execution time: 0.0530
DEBUG - 2022-07-01 01:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:16:10 --> Total execution time: 0.0949
DEBUG - 2022-07-01 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:17:54 --> Total execution time: 0.0493
DEBUG - 2022-07-01 01:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:18:07 --> Total execution time: 0.0877
DEBUG - 2022-07-01 01:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:18:14 --> Total execution time: 0.0969
DEBUG - 2022-07-01 01:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:18:21 --> Total execution time: 0.0501
DEBUG - 2022-07-01 01:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:18:29 --> Total execution time: 0.0716
DEBUG - 2022-07-01 01:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:18:32 --> Total execution time: 0.0559
DEBUG - 2022-07-01 01:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:18:39 --> Total execution time: 0.0781
DEBUG - 2022-07-01 01:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:18:41 --> Total execution time: 1.4852
DEBUG - 2022-07-01 01:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:19:09 --> Total execution time: 0.0701
DEBUG - 2022-07-01 01:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:19:14 --> Total execution time: 0.0701
DEBUG - 2022-07-01 01:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:21:46 --> Total execution time: 0.1268
DEBUG - 2022-07-01 01:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:52:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:22:35 --> Total execution time: 0.0423
DEBUG - 2022-07-01 01:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:52:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 01:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:22:36 --> Total execution time: 0.0273
DEBUG - 2022-07-01 01:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:23:56 --> Total execution time: 0.1616
DEBUG - 2022-07-01 01:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:24:03 --> Total execution time: 0.0748
DEBUG - 2022-07-01 01:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:24:06 --> Total execution time: 0.0702
DEBUG - 2022-07-01 01:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:24:10 --> Total execution time: 0.0517
DEBUG - 2022-07-01 01:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:55:37 --> Total execution time: 0.0484
DEBUG - 2022-07-01 01:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:25:51 --> Total execution time: 0.0542
DEBUG - 2022-07-01 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:25:58 --> Total execution time: 0.1157
DEBUG - 2022-07-01 01:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:26:03 --> Total execution time: 0.0895
DEBUG - 2022-07-01 01:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:26:11 --> Total execution time: 0.0513
DEBUG - 2022-07-01 01:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:26:15 --> Total execution time: 0.1153
DEBUG - 2022-07-01 01:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:26:27 --> Total execution time: 0.0786
DEBUG - 2022-07-01 01:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:26:28 --> Total execution time: 0.0868
DEBUG - 2022-07-01 01:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:26:40 --> Total execution time: 0.0908
DEBUG - 2022-07-01 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:27:13 --> Total execution time: 0.0495
DEBUG - 2022-07-01 01:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:27:14 --> Total execution time: 0.0614
DEBUG - 2022-07-01 01:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:27:31 --> Total execution time: 0.0863
DEBUG - 2022-07-01 01:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:27:49 --> Total execution time: 0.0755
DEBUG - 2022-07-01 01:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:27:50 --> Total execution time: 0.1031
DEBUG - 2022-07-01 01:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:27:58 --> Total execution time: 0.0579
DEBUG - 2022-07-01 01:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 01:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:28:08 --> Total execution time: 0.0529
DEBUG - 2022-07-01 01:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:28:16 --> Total execution time: 0.1096
DEBUG - 2022-07-01 01:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:28:23 --> Total execution time: 0.0468
DEBUG - 2022-07-01 01:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:28:24 --> Total execution time: 0.0566
DEBUG - 2022-07-01 01:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:28:28 --> Total execution time: 0.0512
DEBUG - 2022-07-01 01:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:28:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 01:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:28:30 --> Total execution time: 0.0713
DEBUG - 2022-07-01 01:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:28:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 12:28:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 12:28:31 --> Total execution time: 0.2024
DEBUG - 2022-07-01 01:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 01:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 01:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:29:27 --> Total execution time: 0.0796
DEBUG - 2022-07-01 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:30:03 --> Total execution time: 0.0609
DEBUG - 2022-07-01 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:30:04 --> Total execution time: 0.1621
DEBUG - 2022-07-01 02:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:30:14 --> Total execution time: 0.0641
DEBUG - 2022-07-01 02:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 02:00:19 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 02:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:02:01 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:32:01 --> Total execution time: 0.0556
DEBUG - 2022-07-01 02:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:32:01 --> Total execution time: 0.1538
DEBUG - 2022-07-01 02:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:32:21 --> Total execution time: 0.0612
DEBUG - 2022-07-01 02:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:32:38 --> Total execution time: 0.0500
DEBUG - 2022-07-01 02:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 02:02:49 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 02:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:04:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 02:04:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 02:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 02:08:47 --> 404 Page Not Found: Course-category/development
DEBUG - 2022-07-01 02:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:10:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:40:37 --> Total execution time: 0.0946
DEBUG - 2022-07-01 02:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:40:42 --> Total execution time: 0.1337
DEBUG - 2022-07-01 02:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:40:49 --> Total execution time: 0.1431
DEBUG - 2022-07-01 02:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:42:02 --> Total execution time: 0.1802
DEBUG - 2022-07-01 02:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:42:18 --> Total execution time: 0.0666
DEBUG - 2022-07-01 02:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:18 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:42:18 --> Total execution time: 0.0279
DEBUG - 2022-07-01 02:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:42:22 --> Total execution time: 0.0546
DEBUG - 2022-07-01 02:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:42:33 --> Total execution time: 0.0483
DEBUG - 2022-07-01 02:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:42:39 --> Total execution time: 0.0475
DEBUG - 2022-07-01 02:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:42:48 --> Total execution time: 0.0514
DEBUG - 2022-07-01 02:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:42:51 --> Total execution time: 0.0645
DEBUG - 2022-07-01 02:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:43:06 --> Total execution time: 0.0689
DEBUG - 2022-07-01 02:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:43:11 --> Total execution time: 0.1125
DEBUG - 2022-07-01 02:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:43:20 --> Total execution time: 0.0490
DEBUG - 2022-07-01 02:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:50:20 --> Total execution time: 0.1237
DEBUG - 2022-07-01 02:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:26:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:56:04 --> Total execution time: 0.1152
DEBUG - 2022-07-01 02:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:57:24 --> Total execution time: 0.0342
DEBUG - 2022-07-01 02:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:27:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 02:27:37 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 02:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:28:19 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:58:19 --> Total execution time: 0.0567
DEBUG - 2022-07-01 02:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:58:25 --> Total execution time: 0.1721
DEBUG - 2022-07-01 02:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:58:42 --> Total execution time: 0.0530
DEBUG - 2022-07-01 02:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:58:55 --> Total execution time: 0.0576
DEBUG - 2022-07-01 02:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:59:12 --> Total execution time: 0.0957
DEBUG - 2022-07-01 02:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:29:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:59:24 --> Total execution time: 0.0442
DEBUG - 2022-07-01 02:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:59:25 --> Total execution time: 0.0457
DEBUG - 2022-07-01 02:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:59:28 --> Total execution time: 0.0642
DEBUG - 2022-07-01 02:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:59:39 --> Total execution time: 0.0661
DEBUG - 2022-07-01 02:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:28 --> Total execution time: 0.0391
DEBUG - 2022-07-01 02:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:29 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:29 --> Total execution time: 0.0450
DEBUG - 2022-07-01 02:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:30 --> Total execution time: 0.0330
DEBUG - 2022-07-01 02:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:38 --> Total execution time: 0.0331
DEBUG - 2022-07-01 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:43 --> Total execution time: 0.0413
DEBUG - 2022-07-01 02:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:54 --> Total execution time: 0.1209
DEBUG - 2022-07-01 02:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:57 --> Total execution time: 0.0563
DEBUG - 2022-07-01 02:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:58 --> Total execution time: 0.0538
DEBUG - 2022-07-01 02:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:02:00 --> Total execution time: 0.0796
DEBUG - 2022-07-01 02:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:02:04 --> Total execution time: 0.0449
DEBUG - 2022-07-01 02:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:02:05 --> Total execution time: 0.0623
DEBUG - 2022-07-01 02:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:02:20 --> Total execution time: 0.0610
DEBUG - 2022-07-01 02:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:02:21 --> Total execution time: 0.0493
DEBUG - 2022-07-01 02:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:02:36 --> Total execution time: 0.0719
DEBUG - 2022-07-01 02:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:03:10 --> Total execution time: 0.0500
DEBUG - 2022-07-01 02:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:34:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:04:28 --> Total execution time: 0.1346
DEBUG - 2022-07-01 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:04:31 --> Total execution time: 0.0509
DEBUG - 2022-07-01 02:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:04:44 --> Total execution time: 0.0493
DEBUG - 2022-07-01 02:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:04:48 --> Total execution time: 0.0537
DEBUG - 2022-07-01 02:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:04:50 --> Total execution time: 0.0787
DEBUG - 2022-07-01 02:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:05:00 --> Total execution time: 0.0548
DEBUG - 2022-07-01 02:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:05:01 --> Total execution time: 0.1337
DEBUG - 2022-07-01 02:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:05:03 --> Total execution time: 0.0482
DEBUG - 2022-07-01 02:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:05:07 --> Total execution time: 0.0541
DEBUG - 2022-07-01 02:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:05:09 --> Total execution time: 0.0480
DEBUG - 2022-07-01 02:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:35:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:05:10 --> Total execution time: 0.0462
DEBUG - 2022-07-01 02:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:36:40 --> Total execution time: 0.0587
DEBUG - 2022-07-01 02:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:06:45 --> Total execution time: 0.0653
DEBUG - 2022-07-01 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:36:47 --> Total execution time: 0.0960
DEBUG - 2022-07-01 02:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:37:16 --> Total execution time: 0.0600
DEBUG - 2022-07-01 02:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:37:29 --> Total execution time: 0.0499
DEBUG - 2022-07-01 02:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:37:33 --> Total execution time: 0.0642
DEBUG - 2022-07-01 02:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:08:26 --> Total execution time: 0.1240
DEBUG - 2022-07-01 02:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:08:34 --> Total execution time: 0.0570
DEBUG - 2022-07-01 02:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:08:36 --> Total execution time: 0.0559
DEBUG - 2022-07-01 02:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:08:41 --> Total execution time: 0.0523
DEBUG - 2022-07-01 02:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:09:16 --> Total execution time: 0.0802
DEBUG - 2022-07-01 02:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:09:31 --> Total execution time: 0.1245
DEBUG - 2022-07-01 02:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:09:35 --> Total execution time: 0.0516
DEBUG - 2022-07-01 02:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:09:47 --> Total execution time: 0.0464
DEBUG - 2022-07-01 02:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:10:08 --> Total execution time: 0.0577
DEBUG - 2022-07-01 02:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:42:06 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:12:06 --> Total execution time: 0.0655
DEBUG - 2022-07-01 02:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:42:16 --> Total execution time: 0.0791
DEBUG - 2022-07-01 02:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:42:17 --> Total execution time: 0.0555
DEBUG - 2022-07-01 02:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:42:17 --> Total execution time: 0.1140
DEBUG - 2022-07-01 02:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:12:58 --> Total execution time: 0.1381
DEBUG - 2022-07-01 02:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:13:00 --> Total execution time: 0.0597
DEBUG - 2022-07-01 02:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:13:04 --> Total execution time: 0.0700
DEBUG - 2022-07-01 02:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:13:09 --> Total execution time: 0.0540
DEBUG - 2022-07-01 02:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:13:42 --> Total execution time: 0.1172
DEBUG - 2022-07-01 02:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:13:58 --> Total execution time: 0.0489
DEBUG - 2022-07-01 02:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:14:02 --> Total execution time: 0.0542
DEBUG - 2022-07-01 02:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:14:10 --> Total execution time: 0.0668
DEBUG - 2022-07-01 02:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:14:15 --> Total execution time: 0.0646
DEBUG - 2022-07-01 02:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:14:18 --> Total execution time: 0.0530
DEBUG - 2022-07-01 02:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:44:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 02:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:14:40 --> Total execution time: 1.5509
DEBUG - 2022-07-01 02:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 02:44:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 02:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:44:55 --> Total execution time: 0.0399
DEBUG - 2022-07-01 02:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:01 --> Total execution time: 0.0716
DEBUG - 2022-07-01 02:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:10 --> Total execution time: 0.0712
DEBUG - 2022-07-01 02:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:11 --> Total execution time: 0.0763
DEBUG - 2022-07-01 02:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:21 --> Total execution time: 0.0780
DEBUG - 2022-07-01 02:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:33 --> Total execution time: 0.0485
DEBUG - 2022-07-01 02:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:34 --> Total execution time: 0.0492
DEBUG - 2022-07-01 02:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:39 --> Total execution time: 0.0603
DEBUG - 2022-07-01 02:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 02:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:40 --> Total execution time: 0.0656
DEBUG - 2022-07-01 02:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 13:15:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 13:15:41 --> Total execution time: 0.2241
DEBUG - 2022-07-01 02:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:50 --> Total execution time: 0.0689
DEBUG - 2022-07-01 02:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:57 --> Total execution time: 0.0620
DEBUG - 2022-07-01 02:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:16:05 --> Total execution time: 0.0724
DEBUG - 2022-07-01 02:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:16:09 --> Total execution time: 0.0667
DEBUG - 2022-07-01 02:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:23 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:16:23 --> Total execution time: 0.0422
DEBUG - 2022-07-01 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:16:49 --> Total execution time: 0.1151
DEBUG - 2022-07-01 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:16:49 --> Total execution time: 0.1319
DEBUG - 2022-07-01 02:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:16:53 --> Total execution time: 0.0713
DEBUG - 2022-07-01 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:16:53 --> Total execution time: 0.0527
DEBUG - 2022-07-01 02:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:16:58 --> Total execution time: 0.0505
DEBUG - 2022-07-01 02:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:17:01 --> Total execution time: 0.0537
DEBUG - 2022-07-01 02:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:17:03 --> Total execution time: 0.0563
DEBUG - 2022-07-01 02:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:17:17 --> Total execution time: 0.0478
DEBUG - 2022-07-01 02:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:17:18 --> Total execution time: 0.0405
DEBUG - 2022-07-01 02:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:17:35 --> Total execution time: 0.0549
DEBUG - 2022-07-01 02:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:17:42 --> Total execution time: 0.0513
DEBUG - 2022-07-01 02:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:18:01 --> Total execution time: 0.0544
DEBUG - 2022-07-01 02:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:18:11 --> Total execution time: 0.0509
DEBUG - 2022-07-01 02:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:18:14 --> Total execution time: 0.0668
DEBUG - 2022-07-01 02:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:18:19 --> Total execution time: 0.0661
DEBUG - 2022-07-01 02:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:18:47 --> Total execution time: 0.0422
DEBUG - 2022-07-01 02:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:18:50 --> Total execution time: 0.0583
DEBUG - 2022-07-01 02:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:18:51 --> Total execution time: 0.0500
DEBUG - 2022-07-01 02:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:18:53 --> Total execution time: 0.0592
DEBUG - 2022-07-01 02:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:19:00 --> Total execution time: 0.0471
DEBUG - 2022-07-01 02:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:19:36 --> Total execution time: 0.1500
DEBUG - 2022-07-01 02:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:19:56 --> Total execution time: 0.0544
DEBUG - 2022-07-01 02:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:20:01 --> Total execution time: 0.0788
DEBUG - 2022-07-01 02:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:20:02 --> Total execution time: 0.0737
DEBUG - 2022-07-01 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:20:35 --> Total execution time: 0.0639
DEBUG - 2022-07-01 02:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:22:34 --> Total execution time: 0.1285
DEBUG - 2022-07-01 02:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:22:39 --> Total execution time: 0.0543
DEBUG - 2022-07-01 02:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 02:54:20 --> 404 Page Not Found: Wp-classphp/index
DEBUG - 2022-07-01 02:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:24:36 --> Total execution time: 0.0463
DEBUG - 2022-07-01 02:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 02:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:24:47 --> Total execution time: 0.0373
DEBUG - 2022-07-01 02:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:24:52 --> Total execution time: 0.0481
DEBUG - 2022-07-01 02:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:24:52 --> Total execution time: 0.0492
DEBUG - 2022-07-01 02:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:24:59 --> Total execution time: 0.0524
DEBUG - 2022-07-01 02:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:25:00 --> Total execution time: 0.1215
DEBUG - 2022-07-01 02:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:25:02 --> Total execution time: 0.0523
DEBUG - 2022-07-01 02:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:25:04 --> Total execution time: 0.0557
DEBUG - 2022-07-01 02:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:25:11 --> Total execution time: 0.0467
DEBUG - 2022-07-01 02:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:25:13 --> Total execution time: 0.0448
DEBUG - 2022-07-01 02:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:25:17 --> Total execution time: 0.0498
DEBUG - 2022-07-01 02:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:25:18 --> Total execution time: 0.0676
DEBUG - 2022-07-01 02:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:55:34 --> Total execution time: 0.0496
DEBUG - 2022-07-01 02:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:55:54 --> Total execution time: 0.0669
DEBUG - 2022-07-01 02:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 02:55:54 --> Total execution time: 0.1300
DEBUG - 2022-07-01 02:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:28:25 --> Total execution time: 0.1252
DEBUG - 2022-07-01 02:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:28:34 --> Total execution time: 0.0470
DEBUG - 2022-07-01 02:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:29:11 --> Total execution time: 0.0764
DEBUG - 2022-07-01 02:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:29:34 --> Total execution time: 0.0731
DEBUG - 2022-07-01 02:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 02:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 02:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:29:42 --> Total execution time: 0.1490
DEBUG - 2022-07-01 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:02 --> Total execution time: 0.0766
DEBUG - 2022-07-01 03:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:26 --> Total execution time: 0.0738
DEBUG - 2022-07-01 03:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:30 --> Total execution time: 0.0634
DEBUG - 2022-07-01 03:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:37 --> Total execution time: 0.0735
DEBUG - 2022-07-01 03:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:42 --> Total execution time: 0.0509
DEBUG - 2022-07-01 03:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:31:36 --> Total execution time: 0.0493
DEBUG - 2022-07-01 03:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:31:49 --> Total execution time: 0.0518
DEBUG - 2022-07-01 03:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:31:52 --> Total execution time: 0.0305
DEBUG - 2022-07-01 03:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:09 --> Total execution time: 0.1121
DEBUG - 2022-07-01 03:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:10 --> Total execution time: 0.0606
DEBUG - 2022-07-01 03:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:17 --> Total execution time: 0.0772
DEBUG - 2022-07-01 03:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:20 --> Total execution time: 0.0601
DEBUG - 2022-07-01 03:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:25 --> Total execution time: 0.0592
DEBUG - 2022-07-01 03:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:30 --> Total execution time: 0.0718
DEBUG - 2022-07-01 03:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:36 --> Total execution time: 0.0575
DEBUG - 2022-07-01 03:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:43 --> Total execution time: 0.0506
DEBUG - 2022-07-01 03:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:32:51 --> Total execution time: 0.0465
DEBUG - 2022-07-01 03:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:33:22 --> Total execution time: 0.0422
DEBUG - 2022-07-01 03:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:34:05 --> Total execution time: 0.1139
DEBUG - 2022-07-01 03:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:34:11 --> Total execution time: 0.0753
DEBUG - 2022-07-01 03:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:35:08 --> Total execution time: 0.0607
DEBUG - 2022-07-01 03:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:36:25 --> Total execution time: 0.0541
DEBUG - 2022-07-01 03:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:36:37 --> Total execution time: 0.0699
DEBUG - 2022-07-01 03:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:37:30 --> Total execution time: 0.0545
DEBUG - 2022-07-01 03:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:37:38 --> Total execution time: 0.0503
DEBUG - 2022-07-01 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:37:41 --> Total execution time: 0.0493
DEBUG - 2022-07-01 03:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:37:53 --> Total execution time: 0.1242
DEBUG - 2022-07-01 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:08:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:38:02 --> Total execution time: 0.0549
DEBUG - 2022-07-01 03:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:08:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:38:03 --> Total execution time: 0.0362
DEBUG - 2022-07-01 03:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:08:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:38:43 --> Total execution time: 0.0357
DEBUG - 2022-07-01 03:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:38:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 03:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:38:49 --> Total execution time: 0.1105
DEBUG - 2022-07-01 03:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:38:59 --> Total execution time: 0.0760
DEBUG - 2022-07-01 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:09:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:39:02 --> Total execution time: 0.0346
DEBUG - 2022-07-01 03:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:39:07 --> Total execution time: 0.1491
DEBUG - 2022-07-01 03:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:39:21 --> Total execution time: 0.0532
DEBUG - 2022-07-01 03:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:40:00 --> Total execution time: 0.0453
DEBUG - 2022-07-01 03:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:40:31 --> Total execution time: 0.0568
DEBUG - 2022-07-01 03:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:40:32 --> Total execution time: 0.0839
DEBUG - 2022-07-01 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:40:52 --> Total execution time: 0.0596
DEBUG - 2022-07-01 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:40:54 --> Total execution time: 0.0510
DEBUG - 2022-07-01 03:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:40:58 --> Total execution time: 0.0576
DEBUG - 2022-07-01 03:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:40:59 --> Total execution time: 0.0463
DEBUG - 2022-07-01 03:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:10 --> Total execution time: 0.0342
DEBUG - 2022-07-01 03:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:14 --> Total execution time: 0.0464
DEBUG - 2022-07-01 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:19 --> Total execution time: 0.0584
DEBUG - 2022-07-01 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:19 --> Total execution time: 0.0650
DEBUG - 2022-07-01 03:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:24 --> Total execution time: 0.0540
DEBUG - 2022-07-01 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:28 --> Total execution time: 0.0668
DEBUG - 2022-07-01 03:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:35 --> Total execution time: 0.0517
DEBUG - 2022-07-01 03:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:38 --> Total execution time: 0.0515
DEBUG - 2022-07-01 03:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:40 --> Total execution time: 0.0460
DEBUG - 2022-07-01 03:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:43 --> Total execution time: 0.0451
DEBUG - 2022-07-01 03:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:41:49 --> Total execution time: 0.0621
DEBUG - 2022-07-01 03:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:03 --> Total execution time: 0.0770
DEBUG - 2022-07-01 03:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:05 --> Total execution time: 0.0799
DEBUG - 2022-07-01 03:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:12 --> Total execution time: 0.0515
DEBUG - 2022-07-01 03:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:16 --> Total execution time: 0.0629
DEBUG - 2022-07-01 03:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:21 --> Total execution time: 0.0604
DEBUG - 2022-07-01 03:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 03:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:22 --> Total execution time: 0.0600
DEBUG - 2022-07-01 03:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:43 --> Total execution time: 0.1438
DEBUG - 2022-07-01 03:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:42:50 --> Total execution time: 0.0525
DEBUG - 2022-07-01 03:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:44:26 --> Total execution time: 0.1180
DEBUG - 2022-07-01 03:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:44:35 --> Total execution time: 0.0669
DEBUG - 2022-07-01 03:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:44:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 03:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:44:36 --> Total execution time: 0.0489
DEBUG - 2022-07-01 03:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:45:40 --> Total execution time: 0.0544
DEBUG - 2022-07-01 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:45:44 --> Total execution time: 0.0539
DEBUG - 2022-07-01 03:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:45:45 --> Total execution time: 0.0726
DEBUG - 2022-07-01 03:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:45:52 --> Total execution time: 0.0582
DEBUG - 2022-07-01 03:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:04 --> Total execution time: 0.0725
DEBUG - 2022-07-01 03:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:06 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:06 --> Total execution time: 0.0427
DEBUG - 2022-07-01 03:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:13 --> Total execution time: 0.0661
DEBUG - 2022-07-01 03:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 03:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:14 --> Total execution time: 0.0360
DEBUG - 2022-07-01 03:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:14 --> Total execution time: 0.0478
DEBUG - 2022-07-01 03:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:18 --> Total execution time: 0.0524
DEBUG - 2022-07-01 03:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:23 --> Total execution time: 0.0592
DEBUG - 2022-07-01 03:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:16:26 --> Total execution time: 0.0624
DEBUG - 2022-07-01 03:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:30 --> Total execution time: 0.0544
DEBUG - 2022-07-01 03:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:37 --> Total execution time: 0.0607
DEBUG - 2022-07-01 03:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:50 --> Total execution time: 0.0521
DEBUG - 2022-07-01 03:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:53 --> Total execution time: 0.0455
DEBUG - 2022-07-01 03:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:46:59 --> Total execution time: 0.0502
DEBUG - 2022-07-01 03:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:47:00 --> Total execution time: 0.0508
DEBUG - 2022-07-01 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:47:02 --> Total execution time: 0.0726
DEBUG - 2022-07-01 03:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:47:15 --> Total execution time: 0.0541
DEBUG - 2022-07-01 03:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:47:23 --> Total execution time: 0.0567
DEBUG - 2022-07-01 03:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:47:28 --> Total execution time: 0.0747
DEBUG - 2022-07-01 03:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:47:57 --> Total execution time: 0.0847
DEBUG - 2022-07-01 03:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:48:24 --> Total execution time: 0.0692
DEBUG - 2022-07-01 03:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:48:37 --> Total execution time: 0.1229
DEBUG - 2022-07-01 03:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:48:46 --> Total execution time: 0.0464
DEBUG - 2022-07-01 03:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:18:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:48:48 --> Total execution time: 0.0554
DEBUG - 2022-07-01 03:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:49:15 --> Total execution time: 0.0584
DEBUG - 2022-07-01 03:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:50:43 --> Total execution time: 1.6258
DEBUG - 2022-07-01 03:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:50:44 --> Total execution time: 2.6016
DEBUG - 2022-07-01 03:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:20:56 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:50:56 --> Total execution time: 0.0393
DEBUG - 2022-07-01 03:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:51:00 --> Total execution time: 1.6066
DEBUG - 2022-07-01 03:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 03:21:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 03:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:51:36 --> Total execution time: 0.0563
DEBUG - 2022-07-01 03:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:06 --> Total execution time: 0.0343
DEBUG - 2022-07-01 03:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:18 --> Total execution time: 0.0507
DEBUG - 2022-07-01 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:34 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:34 --> Total execution time: 0.0436
DEBUG - 2022-07-01 03:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:38 --> Total execution time: 0.1243
DEBUG - 2022-07-01 03:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:43 --> Total execution time: 0.1161
DEBUG - 2022-07-01 03:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:43 --> Total execution time: 0.0946
DEBUG - 2022-07-01 03:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:45 --> Total execution time: 0.0686
DEBUG - 2022-07-01 03:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:50 --> Total execution time: 0.0516
DEBUG - 2022-07-01 03:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:52:56 --> Total execution time: 0.0560
DEBUG - 2022-07-01 03:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:53:00 --> Total execution time: 1.6087
DEBUG - 2022-07-01 03:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:53:02 --> Total execution time: 0.0657
DEBUG - 2022-07-01 03:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:53:07 --> Total execution time: 0.0536
DEBUG - 2022-07-01 03:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:53:09 --> Total execution time: 0.0496
DEBUG - 2022-07-01 03:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:53:46 --> Total execution time: 0.0451
DEBUG - 2022-07-01 03:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:23:46 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:53:46 --> Total execution time: 0.0328
DEBUG - 2022-07-01 03:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:53:53 --> Total execution time: 0.0480
DEBUG - 2022-07-01 03:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:24:00 --> Total execution time: 0.0435
DEBUG - 2022-07-01 03:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:02 --> Total execution time: 0.2661
DEBUG - 2022-07-01 03:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:05 --> Total execution time: 0.0661
DEBUG - 2022-07-01 03:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:09 --> Total execution time: 0.0490
DEBUG - 2022-07-01 03:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:11 --> Total execution time: 0.0564
DEBUG - 2022-07-01 03:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:14 --> Total execution time: 0.0528
DEBUG - 2022-07-01 03:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:19 --> Total execution time: 0.0615
DEBUG - 2022-07-01 03:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:20 --> Total execution time: 0.0520
DEBUG - 2022-07-01 03:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:26 --> Total execution time: 0.0500
DEBUG - 2022-07-01 03:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:24:30 --> Total execution time: 0.0614
DEBUG - 2022-07-01 03:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:47 --> Total execution time: 0.0464
DEBUG - 2022-07-01 03:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:50 --> Total execution time: 0.0503
DEBUG - 2022-07-01 03:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:54 --> Total execution time: 0.0564
DEBUG - 2022-07-01 03:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:54:54 --> Total execution time: 0.0454
DEBUG - 2022-07-01 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:55:05 --> Total execution time: 0.0483
DEBUG - 2022-07-01 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:55:05 --> Total execution time: 0.0507
DEBUG - 2022-07-01 03:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:25:27 --> Total execution time: 0.0575
DEBUG - 2022-07-01 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:25:29 --> Total execution time: 0.0538
DEBUG - 2022-07-01 03:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:25:29 --> Total execution time: 0.0996
DEBUG - 2022-07-01 03:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:55:37 --> Total execution time: 0.0685
DEBUG - 2022-07-01 03:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:55:39 --> Total execution time: 0.0462
DEBUG - 2022-07-01 03:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:55:47 --> Total execution time: 0.0484
DEBUG - 2022-07-01 03:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:55:55 --> Total execution time: 0.0596
DEBUG - 2022-07-01 03:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:26:02 --> Total execution time: 0.0318
DEBUG - 2022-07-01 03:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:02 --> Total execution time: 0.0515
DEBUG - 2022-07-01 03:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:12 --> Total execution time: 0.0572
DEBUG - 2022-07-01 03:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:18 --> Total execution time: 0.0362
DEBUG - 2022-07-01 03:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:26:25 --> Total execution time: 0.0697
DEBUG - 2022-07-01 03:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:26:26 --> Total execution time: 0.0444
DEBUG - 2022-07-01 03:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:26:26 --> Total execution time: 0.1083
DEBUG - 2022-07-01 03:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:27 --> Total execution time: 0.0606
DEBUG - 2022-07-01 03:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:35 --> Total execution time: 0.0515
DEBUG - 2022-07-01 03:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:35 --> Total execution time: 0.0589
DEBUG - 2022-07-01 03:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:36 --> Total execution time: 0.0504
DEBUG - 2022-07-01 03:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:36 --> Total execution time: 0.0682
DEBUG - 2022-07-01 03:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:37 --> Total execution time: 0.0547
DEBUG - 2022-07-01 03:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:39 --> Total execution time: 0.0464
DEBUG - 2022-07-01 03:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:39 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:39 --> Total execution time: 0.0508
DEBUG - 2022-07-01 03:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:41 --> Total execution time: 0.0475
DEBUG - 2022-07-01 03:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:41 --> Total execution time: 0.0516
DEBUG - 2022-07-01 03:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:43 --> Total execution time: 0.0592
DEBUG - 2022-07-01 03:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:56:47 --> Total execution time: 0.0857
DEBUG - 2022-07-01 03:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:57:16 --> Total execution time: 0.0511
DEBUG - 2022-07-01 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:57:21 --> Total execution time: 0.0580
DEBUG - 2022-07-01 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:27:21 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:57:21 --> Total execution time: 0.0327
DEBUG - 2022-07-01 03:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:57:40 --> Total execution time: 0.0450
DEBUG - 2022-07-01 03:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:58:08 --> Total execution time: 0.0582
DEBUG - 2022-07-01 03:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:58:26 --> Total execution time: 0.0499
DEBUG - 2022-07-01 03:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:58:27 --> Total execution time: 0.0470
DEBUG - 2022-07-01 03:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:58:28 --> Total execution time: 0.0648
DEBUG - 2022-07-01 03:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:58:44 --> Total execution time: 0.1169
DEBUG - 2022-07-01 03:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:58:54 --> Total execution time: 0.0474
DEBUG - 2022-07-01 03:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:28:57 --> Total execution time: 0.0469
DEBUG - 2022-07-01 03:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:28:58 --> Total execution time: 0.0737
DEBUG - 2022-07-01 03:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:28:59 --> Total execution time: 0.1236
DEBUG - 2022-07-01 03:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:59:00 --> Total execution time: 0.0420
DEBUG - 2022-07-01 03:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:59:18 --> Total execution time: 0.0815
DEBUG - 2022-07-01 03:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:59:20 --> Total execution time: 0.0453
DEBUG - 2022-07-01 03:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:59:28 --> Total execution time: 0.0452
DEBUG - 2022-07-01 03:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:59:34 --> Total execution time: 0.0699
DEBUG - 2022-07-01 03:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:29:40 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:59:40 --> Total execution time: 0.0463
DEBUG - 2022-07-01 03:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:07 --> Total execution time: 0.0707
DEBUG - 2022-07-01 03:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:11 --> Total execution time: 0.0503
DEBUG - 2022-07-01 03:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:14 --> Total execution time: 0.0926
DEBUG - 2022-07-01 03:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:22 --> Total execution time: 0.1411
DEBUG - 2022-07-01 03:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:27 --> Total execution time: 0.0495
DEBUG - 2022-07-01 03:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:30:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:43 --> Total execution time: 0.0470
DEBUG - 2022-07-01 03:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:47 --> Total execution time: 0.0841
DEBUG - 2022-07-01 03:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:59 --> Total execution time: 0.1108
DEBUG - 2022-07-01 03:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:01:06 --> Total execution time: 0.0517
DEBUG - 2022-07-01 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:01:21 --> Total execution time: 0.0558
DEBUG - 2022-07-01 03:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:31:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:31:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:01:24 --> Total execution time: 0.0473
DEBUG - 2022-07-01 03:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:01:24 --> Total execution time: 0.1147
DEBUG - 2022-07-01 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:01:45 --> Total execution time: 0.1120
DEBUG - 2022-07-01 03:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:31:51 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:01:51 --> Total execution time: 0.0330
DEBUG - 2022-07-01 03:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:02:17 --> Total execution time: 0.0500
DEBUG - 2022-07-01 03:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:32:58 --> Total execution time: 0.1559
DEBUG - 2022-07-01 03:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:32:58 --> Total execution time: 0.0901
DEBUG - 2022-07-01 03:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:33:00 --> Total execution time: 0.0745
DEBUG - 2022-07-01 03:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:33:00 --> Total execution time: 0.1832
DEBUG - 2022-07-01 03:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:04:48 --> Total execution time: 0.1360
DEBUG - 2022-07-01 03:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:04:55 --> Total execution time: 0.0452
DEBUG - 2022-07-01 03:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:35:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:05:08 --> Total execution time: 0.1229
DEBUG - 2022-07-01 03:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:05:13 --> Total execution time: 0.0455
DEBUG - 2022-07-01 03:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:06:29 --> Total execution time: 0.0490
DEBUG - 2022-07-01 03:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:37:19 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:07:20 --> Total execution time: 0.0433
DEBUG - 2022-07-01 03:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 03:37:59 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 03:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:08:22 --> Total execution time: 0.0568
DEBUG - 2022-07-01 03:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:08:33 --> Total execution time: 0.0470
DEBUG - 2022-07-01 03:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:08:49 --> Total execution time: 0.1194
DEBUG - 2022-07-01 03:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:08:54 --> Total execution time: 0.0644
DEBUG - 2022-07-01 03:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:39:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:09:02 --> Total execution time: 0.0427
DEBUG - 2022-07-01 03:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:09:25 --> Total execution time: 0.0721
DEBUG - 2022-07-01 03:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 03:40:26 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 03:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:11:07 --> Total execution time: 0.1242
DEBUG - 2022-07-01 03:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:11:29 --> Total execution time: 0.0514
DEBUG - 2022-07-01 03:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:42:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:12:08 --> Total execution time: 0.0444
DEBUG - 2022-07-01 03:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:42:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:12:10 --> Total execution time: 0.0598
DEBUG - 2022-07-01 03:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:12:14 --> Total execution time: 0.0516
DEBUG - 2022-07-01 03:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 03:42:31 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 03:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:12:38 --> Total execution time: 0.1767
DEBUG - 2022-07-01 03:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:13:07 --> Total execution time: 0.0553
DEBUG - 2022-07-01 03:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:13:09 --> Total execution time: 0.0502
DEBUG - 2022-07-01 03:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 03:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:13:11 --> Total execution time: 0.0638
DEBUG - 2022-07-01 03:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:13:14 --> Total execution time: 0.0500
DEBUG - 2022-07-01 03:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:13:27 --> Total execution time: 0.0673
DEBUG - 2022-07-01 03:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 03:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:13:30 --> Total execution time: 0.0521
DEBUG - 2022-07-01 03:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:13:51 --> Total execution time: 0.0636
DEBUG - 2022-07-01 03:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:13:55 --> Total execution time: 0.0633
DEBUG - 2022-07-01 03:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:14:03 --> Total execution time: 0.0524
DEBUG - 2022-07-01 03:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:14:45 --> Total execution time: 0.1250
DEBUG - 2022-07-01 03:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:14:48 --> Total execution time: 0.0900
DEBUG - 2022-07-01 03:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:14:57 --> Total execution time: 0.0505
DEBUG - 2022-07-01 03:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:14:59 --> Total execution time: 0.0579
DEBUG - 2022-07-01 03:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:15:07 --> Total execution time: 0.0706
DEBUG - 2022-07-01 03:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:17:37 --> Total execution time: 0.1124
DEBUG - 2022-07-01 03:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:21:01 --> Total execution time: 0.0499
DEBUG - 2022-07-01 03:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:21:28 --> Total execution time: 0.0503
DEBUG - 2022-07-01 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:25:51 --> Total execution time: 0.1213
DEBUG - 2022-07-01 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:25:51 --> Total execution time: 0.0508
DEBUG - 2022-07-01 03:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:25:54 --> Total execution time: 0.0735
DEBUG - 2022-07-01 03:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:27:45 --> Total execution time: 0.1278
DEBUG - 2022-07-01 03:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:27:46 --> Total execution time: 0.0545
DEBUG - 2022-07-01 03:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:27:50 --> Total execution time: 0.0545
DEBUG - 2022-07-01 03:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:27:54 --> Total execution time: 0.0504
DEBUG - 2022-07-01 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:27:59 --> Total execution time: 0.0537
DEBUG - 2022-07-01 03:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:28:04 --> Total execution time: 0.0576
DEBUG - 2022-07-01 03:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 03:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 03:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:28:07 --> Total execution time: 0.0571
DEBUG - 2022-07-01 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:30:02 --> Total execution time: 0.0950
DEBUG - 2022-07-01 04:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:02:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:32:24 --> Total execution time: 0.0394
DEBUG - 2022-07-01 04:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:32:58 --> Total execution time: 0.0342
DEBUG - 2022-07-01 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:33:33 --> Total execution time: 0.1613
DEBUG - 2022-07-01 04:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:33:42 --> Total execution time: 0.0528
DEBUG - 2022-07-01 04:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:33:46 --> Total execution time: 0.0513
DEBUG - 2022-07-01 04:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:33:50 --> Total execution time: 0.0600
DEBUG - 2022-07-01 04:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:33:52 --> Total execution time: 0.1117
DEBUG - 2022-07-01 04:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:34:04 --> Total execution time: 0.0602
DEBUG - 2022-07-01 04:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:05:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:35:28 --> Total execution time: 0.0502
DEBUG - 2022-07-01 04:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:05:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:35:30 --> Total execution time: 0.0341
DEBUG - 2022-07-01 04:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 04:05:38 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 04:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:06:25 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:25 --> Total execution time: 0.0340
DEBUG - 2022-07-01 04:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:06:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:28 --> Total execution time: 0.0369
DEBUG - 2022-07-01 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:39 --> Total execution time: 0.0854
DEBUG - 2022-07-01 04:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:44 --> Total execution time: 0.0340
DEBUG - 2022-07-01 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:58 --> Total execution time: 0.0394
DEBUG - 2022-07-01 04:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:37:06 --> Total execution time: 0.0736
DEBUG - 2022-07-01 04:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:07:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:37:12 --> Total execution time: 0.0476
DEBUG - 2022-07-01 04:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:07:32 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:37:32 --> Total execution time: 0.0866
DEBUG - 2022-07-01 04:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:37:37 --> Total execution time: 0.0499
DEBUG - 2022-07-01 04:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:38:07 --> Total execution time: 0.0359
DEBUG - 2022-07-01 04:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:38:55 --> Total execution time: 0.0547
DEBUG - 2022-07-01 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:11 --> Total execution time: 0.1290
DEBUG - 2022-07-01 04:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:15 --> Total execution time: 0.0694
DEBUG - 2022-07-01 04:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:41 --> Total execution time: 0.1178
DEBUG - 2022-07-01 04:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:41 --> Total execution time: 0.1949
DEBUG - 2022-07-01 04:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:41 --> Total execution time: 0.5685
DEBUG - 2022-07-01 04:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:43 --> Total execution time: 0.3248
DEBUG - 2022-07-01 04:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:46 --> Total execution time: 0.1020
DEBUG - 2022-07-01 04:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:51 --> Total execution time: 0.0566
DEBUG - 2022-07-01 04:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:56 --> Total execution time: 0.0798
DEBUG - 2022-07-01 04:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:39:58 --> Total execution time: 0.0607
DEBUG - 2022-07-01 04:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:10:05 --> Total execution time: 0.0760
DEBUG - 2022-07-01 04:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:06 --> Total execution time: 0.0474
DEBUG - 2022-07-01 04:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:06 --> Total execution time: 0.0831
DEBUG - 2022-07-01 04:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:11 --> Total execution time: 0.1048
DEBUG - 2022-07-01 04:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:15 --> Total execution time: 0.0613
DEBUG - 2022-07-01 04:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:21 --> Total execution time: 0.0575
DEBUG - 2022-07-01 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:25 --> Total execution time: 0.0729
DEBUG - 2022-07-01 04:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:44 --> Total execution time: 0.0564
DEBUG - 2022-07-01 04:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:46 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:46 --> Total execution time: 0.0422
DEBUG - 2022-07-01 04:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:49 --> Total execution time: 0.0451
DEBUG - 2022-07-01 04:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:52 --> Total execution time: 0.0605
DEBUG - 2022-07-01 04:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:59 --> Total execution time: 0.0489
DEBUG - 2022-07-01 04:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:41:08 --> Total execution time: 0.0698
DEBUG - 2022-07-01 04:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:41:14 --> Total execution time: 0.0511
DEBUG - 2022-07-01 04:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:41:15 --> Total execution time: 0.0857
DEBUG - 2022-07-01 04:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:41:36 --> Total execution time: 0.0814
DEBUG - 2022-07-01 04:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:41:54 --> Total execution time: 0.1275
DEBUG - 2022-07-01 04:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:42:21 --> Total execution time: 0.0539
DEBUG - 2022-07-01 04:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:13:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:43:11 --> Total execution time: 0.0428
DEBUG - 2022-07-01 04:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:13:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:43:11 --> Total execution time: 0.0332
DEBUG - 2022-07-01 04:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:13:46 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:43:46 --> Total execution time: 0.0336
DEBUG - 2022-07-01 04:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:13:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:43:47 --> Total execution time: 0.0582
DEBUG - 2022-07-01 04:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:44:03 --> Total execution time: 0.0838
DEBUG - 2022-07-01 04:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:44:06 --> Total execution time: 0.0546
DEBUG - 2022-07-01 04:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:44:17 --> Total execution time: 0.0495
DEBUG - 2022-07-01 04:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:44:29 --> Total execution time: 0.0540
DEBUG - 2022-07-01 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:44:36 --> Total execution time: 0.1235
DEBUG - 2022-07-01 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:42 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:44:42 --> Total execution time: 0.0337
DEBUG - 2022-07-01 04:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:44:51 --> Total execution time: 0.0553
DEBUG - 2022-07-01 04:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:45:13 --> Total execution time: 0.0669
DEBUG - 2022-07-01 04:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:15:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:45:14 --> Total execution time: 0.0544
DEBUG - 2022-07-01 04:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:46:49 --> Total execution time: 0.0552
DEBUG - 2022-07-01 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:47:01 --> Total execution time: 0.0506
DEBUG - 2022-07-01 04:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:47:05 --> Total execution time: 0.0936
DEBUG - 2022-07-01 04:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:47:17 --> Total execution time: 0.0497
DEBUG - 2022-07-01 04:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:49:23 --> Total execution time: 0.0586
DEBUG - 2022-07-01 04:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:49:35 --> Total execution time: 0.1456
DEBUG - 2022-07-01 04:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:50:01 --> Total execution time: 0.0741
DEBUG - 2022-07-01 04:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:50:38 --> Total execution time: 0.0472
DEBUG - 2022-07-01 04:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:50:47 --> Total execution time: 0.1090
DEBUG - 2022-07-01 04:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:51:08 --> Total execution time: 0.0468
DEBUG - 2022-07-01 04:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:24:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:54:48 --> Total execution time: 0.1090
DEBUG - 2022-07-01 04:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:54:52 --> Total execution time: 0.0376
DEBUG - 2022-07-01 04:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:54:59 --> Total execution time: 0.0612
DEBUG - 2022-07-01 04:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:55:16 --> Total execution time: 0.0579
DEBUG - 2022-07-01 04:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:55:28 --> Total execution time: 0.0532
DEBUG - 2022-07-01 04:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:25:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:55:28 --> Total execution time: 0.1296
DEBUG - 2022-07-01 04:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:55:37 --> Total execution time: 0.0705
DEBUG - 2022-07-01 04:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:55:37 --> Total execution time: 0.0630
DEBUG - 2022-07-01 04:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:55:40 --> Total execution time: 0.0558
DEBUG - 2022-07-01 04:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:55:40 --> Total execution time: 0.0472
DEBUG - 2022-07-01 04:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:55:43 --> Total execution time: 0.0504
DEBUG - 2022-07-01 04:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:56:13 --> Total execution time: 0.0468
DEBUG - 2022-07-01 04:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:26:17 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:56:17 --> Total execution time: 0.0870
DEBUG - 2022-07-01 04:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:56:17 --> Total execution time: 0.1435
DEBUG - 2022-07-01 04:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:57:17 --> Total execution time: 0.0477
DEBUG - 2022-07-01 04:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:57:31 --> Total execution time: 0.0534
DEBUG - 2022-07-01 04:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:27:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:57:49 --> Total execution time: 0.0324
DEBUG - 2022-07-01 04:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:57:59 --> Total execution time: 0.0463
DEBUG - 2022-07-01 04:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:28:09 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:58:09 --> Total execution time: 0.0363
DEBUG - 2022-07-01 04:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:28:09 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:58:09 --> Total execution time: 0.0632
DEBUG - 2022-07-01 04:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:58:18 --> Total execution time: 0.0516
DEBUG - 2022-07-01 04:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:58:33 --> Total execution time: 0.0566
DEBUG - 2022-07-01 04:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:58:47 --> Total execution time: 0.0903
DEBUG - 2022-07-01 04:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:58:53 --> Total execution time: 0.0718
DEBUG - 2022-07-01 04:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:58:54 --> Total execution time: 0.1823
DEBUG - 2022-07-01 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:59:19 --> Total execution time: 0.1530
DEBUG - 2022-07-01 04:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:59:24 --> Total execution time: 0.0443
DEBUG - 2022-07-01 04:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:59:37 --> Total execution time: 0.0503
DEBUG - 2022-07-01 04:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:59:50 --> Total execution time: 0.0747
DEBUG - 2022-07-01 04:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:30:01 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:00:01 --> Total execution time: 0.0453
DEBUG - 2022-07-01 04:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:00:04 --> Total execution time: 0.0448
DEBUG - 2022-07-01 04:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:00:11 --> Total execution time: 0.1214
DEBUG - 2022-07-01 04:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:00:36 --> Total execution time: 0.0403
DEBUG - 2022-07-01 04:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:01:00 --> Total execution time: 0.0549
DEBUG - 2022-07-01 04:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:31:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:01:04 --> Total execution time: 0.0458
DEBUG - 2022-07-01 04:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:01:29 --> Total execution time: 0.0502
DEBUG - 2022-07-01 04:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:01:43 --> Total execution time: 0.1135
DEBUG - 2022-07-01 04:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:01:49 --> Total execution time: 0.0501
DEBUG - 2022-07-01 04:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:02:59 --> Total execution time: 1.5605
DEBUG - 2022-07-01 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:03:03 --> Total execution time: 0.0586
DEBUG - 2022-07-01 04:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 04:33:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 04:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:34:39 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:04:39 --> Total execution time: 0.0407
DEBUG - 2022-07-01 04:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:36:47 --> Total execution time: 0.1145
DEBUG - 2022-07-01 04:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:36:49 --> Total execution time: 0.0565
DEBUG - 2022-07-01 04:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:36:49 --> Total execution time: 0.1024
DEBUG - 2022-07-01 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:07:04 --> Total execution time: 0.1492
DEBUG - 2022-07-01 04:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:37:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:07:05 --> Total execution time: 0.0530
DEBUG - 2022-07-01 04:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:08:05 --> Total execution time: 0.1595
DEBUG - 2022-07-01 04:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:08:29 --> Total execution time: 0.0573
DEBUG - 2022-07-01 04:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:08:58 --> Total execution time: 0.0715
DEBUG - 2022-07-01 04:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:09:19 --> Total execution time: 0.0534
DEBUG - 2022-07-01 04:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:10:25 --> Total execution time: 0.0710
DEBUG - 2022-07-01 04:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:41:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 04:41:19 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-01 04:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:41:20 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:11:20 --> Total execution time: 0.1152
DEBUG - 2022-07-01 04:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:43:16 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:13:16 --> Total execution time: 0.0639
DEBUG - 2022-07-01 04:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:13:35 --> Total execution time: 1.4807
DEBUG - 2022-07-01 04:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:49:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:19:04 --> Total execution time: 0.1919
DEBUG - 2022-07-01 04:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:19:08 --> Total execution time: 0.0609
DEBUG - 2022-07-01 04:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:19:14 --> Total execution time: 0.0616
DEBUG - 2022-07-01 04:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:19:17 --> Total execution time: 0.0665
DEBUG - 2022-07-01 04:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:19:26 --> Total execution time: 0.0583
DEBUG - 2022-07-01 04:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:53:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:23:53 --> Total execution time: 0.0346
DEBUG - 2022-07-01 04:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:24:00 --> Total execution time: 0.0322
DEBUG - 2022-07-01 04:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:54:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:24:37 --> Total execution time: 0.0395
DEBUG - 2022-07-01 04:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:24:38 --> Total execution time: 0.0469
DEBUG - 2022-07-01 04:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:24:40 --> Total execution time: 0.0448
DEBUG - 2022-07-01 04:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:55:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:25:37 --> Total execution time: 0.1260
DEBUG - 2022-07-01 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:55:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:25:43 --> Total execution time: 0.0498
DEBUG - 2022-07-01 04:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:55:58 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:25:58 --> Total execution time: 0.0495
DEBUG - 2022-07-01 04:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:26:17 --> Total execution time: 0.1136
DEBUG - 2022-07-01 04:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:26:47 --> Total execution time: 0.1193
DEBUG - 2022-07-01 04:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 04:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:27:00 --> Total execution time: 0.0533
DEBUG - 2022-07-01 04:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:28:33 --> Total execution time: 0.0978
DEBUG - 2022-07-01 04:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:29:11 --> Total execution time: 0.0666
DEBUG - 2022-07-01 04:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:29:18 --> Total execution time: 0.0512
DEBUG - 2022-07-01 04:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:29:23 --> Total execution time: 0.0657
DEBUG - 2022-07-01 04:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:29:27 --> Total execution time: 0.0804
DEBUG - 2022-07-01 04:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:29:35 --> Total execution time: 0.0924
DEBUG - 2022-07-01 04:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:29:43 --> Total execution time: 0.0698
DEBUG - 2022-07-01 04:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 04:59:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 04:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 04:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:29:49 --> Total execution time: 0.0473
DEBUG - 2022-07-01 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:30:02 --> Total execution time: 0.0805
DEBUG - 2022-07-01 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:31:01 --> Total execution time: 0.1036
DEBUG - 2022-07-01 05:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:04:59 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:34:59 --> Total execution time: 0.1389
DEBUG - 2022-07-01 05:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:05:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:35:03 --> Total execution time: 0.0539
DEBUG - 2022-07-01 05:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:35:07 --> Total execution time: 0.0473
DEBUG - 2022-07-01 05:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:35:30 --> Total execution time: 0.2469
DEBUG - 2022-07-01 05:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:35:40 --> Total execution time: 0.0778
DEBUG - 2022-07-01 05:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:35:50 --> Total execution time: 0.1116
DEBUG - 2022-07-01 05:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:36:18 --> Total execution time: 0.0914
DEBUG - 2022-07-01 05:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:36:18 --> Total execution time: 0.0593
DEBUG - 2022-07-01 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:36:51 --> Total execution time: 0.0473
DEBUG - 2022-07-01 05:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:37:00 --> Total execution time: 0.0582
DEBUG - 2022-07-01 05:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:37:05 --> Total execution time: 0.0496
DEBUG - 2022-07-01 05:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:37:18 --> Total execution time: 0.0796
DEBUG - 2022-07-01 05:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:37:45 --> Total execution time: 0.0690
DEBUG - 2022-07-01 05:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:07:53 --> Total execution time: 0.0433
DEBUG - 2022-07-01 05:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:37:59 --> Total execution time: 0.0543
DEBUG - 2022-07-01 05:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:38:08 --> Total execution time: 0.0763
DEBUG - 2022-07-01 05:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:38:16 --> Total execution time: 0.0402
DEBUG - 2022-07-01 05:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:38:32 --> Total execution time: 0.0594
DEBUG - 2022-07-01 05:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:38:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:38:33 --> Total execution time: 0.0497
DEBUG - 2022-07-01 05:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:38:54 --> Total execution time: 0.0473
DEBUG - 2022-07-01 05:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:01 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:39:01 --> Total execution time: 0.0479
DEBUG - 2022-07-01 05:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:39:13 --> Total execution time: 0.0591
DEBUG - 2022-07-01 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:39:28 --> Total execution time: 0.0531
DEBUG - 2022-07-01 05:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:39:29 --> Total execution time: 0.0480
DEBUG - 2022-07-01 05:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:39:37 --> Total execution time: 0.0602
DEBUG - 2022-07-01 05:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:09:39 --> Total execution time: 0.0518
DEBUG - 2022-07-01 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:09:46 --> Total execution time: 0.0832
DEBUG - 2022-07-01 05:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:09:46 --> Total execution time: 0.1315
DEBUG - 2022-07-01 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:39:58 --> Total execution time: 0.0541
DEBUG - 2022-07-01 05:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:40:08 --> Total execution time: 0.0731
DEBUG - 2022-07-01 05:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:40:16 --> Total execution time: 0.0527
DEBUG - 2022-07-01 05:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:40:22 --> Total execution time: 0.0580
DEBUG - 2022-07-01 05:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:40:26 --> Total execution time: 0.0488
DEBUG - 2022-07-01 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:40:36 --> Total execution time: 0.0626
DEBUG - 2022-07-01 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:10:58 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:40:58 --> Total execution time: 0.1150
DEBUG - 2022-07-01 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:41:04 --> Total execution time: 0.0486
DEBUG - 2022-07-01 05:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:11:17 --> Total execution time: 0.0542
DEBUG - 2022-07-01 05:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:11:22 --> Total execution time: 0.1078
DEBUG - 2022-07-01 05:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:41:23 --> Total execution time: 0.0660
DEBUG - 2022-07-01 05:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:41:35 --> Total execution time: 0.0900
DEBUG - 2022-07-01 05:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:41:39 --> Total execution time: 0.0477
DEBUG - 2022-07-01 05:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:41:42 --> Total execution time: 0.0484
DEBUG - 2022-07-01 05:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:41:52 --> Total execution time: 0.0903
DEBUG - 2022-07-01 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:42:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:42:20 --> Total execution time: 0.0748
DEBUG - 2022-07-01 05:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:42:24 --> Total execution time: 0.0548
DEBUG - 2022-07-01 05:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:42:37 --> Total execution time: 0.0447
DEBUG - 2022-07-01 05:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:12:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:42:42 --> Total execution time: 1.5187
DEBUG - 2022-07-01 05:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:12:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 05:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:43:26 --> Total execution time: 0.0795
DEBUG - 2022-07-01 05:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:43:47 --> Total execution time: 0.0872
DEBUG - 2022-07-01 05:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:44:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:44:25 --> Total execution time: 0.0653
DEBUG - 2022-07-01 05:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:44:28 --> Total execution time: 0.0593
DEBUG - 2022-07-01 05:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:44:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 15:44:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 15:44:34 --> Total execution time: 0.1897
DEBUG - 2022-07-01 05:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:44:46 --> Total execution time: 0.0575
DEBUG - 2022-07-01 05:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:15:55 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:45:55 --> Total execution time: 0.0421
DEBUG - 2022-07-01 05:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:46:04 --> Total execution time: 0.0333
DEBUG - 2022-07-01 05:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:16:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:46:07 --> Total execution time: 0.0628
DEBUG - 2022-07-01 05:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:16:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:46:43 --> Total execution time: 0.0333
DEBUG - 2022-07-01 05:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:46:44 --> Total execution time: 0.0442
DEBUG - 2022-07-01 05:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:16:45 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:46:45 --> Total execution time: 0.0346
DEBUG - 2022-07-01 05:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:16:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:46:53 --> Total execution time: 0.0347
DEBUG - 2022-07-01 05:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:09 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:09 --> Total execution time: 0.0350
DEBUG - 2022-07-01 05:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:10 --> Total execution time: 0.0433
DEBUG - 2022-07-01 05:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:13 --> Total execution time: 0.0533
DEBUG - 2022-07-01 15:47:13 --> Total execution time: 1.5956
DEBUG - 2022-07-01 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:13 --> Total execution time: 0.0292
DEBUG - 2022-07-01 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:15 --> Total execution time: 0.0309
DEBUG - 2022-07-01 05:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:21 --> Total execution time: 0.0689
DEBUG - 2022-07-01 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:27 --> Total execution time: 0.0607
DEBUG - 2022-07-01 05:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:17:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 05:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:44 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:44 --> Total execution time: 0.1172
DEBUG - 2022-07-01 05:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:44 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:44 --> Total execution time: 0.0533
DEBUG - 2022-07-01 05:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:47:46 --> Total execution time: 0.0794
DEBUG - 2022-07-01 05:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:48:01 --> Total execution time: 0.0617
DEBUG - 2022-07-01 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:48:06 --> Total execution time: 0.0940
DEBUG - 2022-07-01 05:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:48:08 --> Total execution time: 0.0517
DEBUG - 2022-07-01 05:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:48:19 --> Total execution time: 0.0928
DEBUG - 2022-07-01 05:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:48:22 --> Total execution time: 0.0306
DEBUG - 2022-07-01 05:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:18:41 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:48:41 --> Total execution time: 0.0514
DEBUG - 2022-07-01 05:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:18:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:48:47 --> Total execution time: 0.0342
DEBUG - 2022-07-01 05:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:18:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:48:48 --> Total execution time: 0.0533
DEBUG - 2022-07-01 05:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:19:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:49:07 --> Total execution time: 0.0459
DEBUG - 2022-07-01 05:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:19:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:49:10 --> Total execution time: 0.0962
DEBUG - 2022-07-01 05:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:19:17 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:49:17 --> Total execution time: 0.0457
DEBUG - 2022-07-01 05:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:49:19 --> Total execution time: 0.0464
DEBUG - 2022-07-01 05:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:49:38 --> Total execution time: 0.0580
DEBUG - 2022-07-01 05:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:19:59 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 05:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:20:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:50:33 --> Total execution time: 0.0481
DEBUG - 2022-07-01 05:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:20:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:50:49 --> Total execution time: 0.0512
DEBUG - 2022-07-01 05:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:50:53 --> Total execution time: 0.0475
DEBUG - 2022-07-01 05:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:04 --> Total execution time: 0.0452
DEBUG - 2022-07-01 05:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:08 --> Total execution time: 0.1358
DEBUG - 2022-07-01 05:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:09 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:09 --> Total execution time: 0.0475
DEBUG - 2022-07-01 05:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:13 --> Total execution time: 0.0673
DEBUG - 2022-07-01 05:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:21 --> Total execution time: 0.0988
DEBUG - 2022-07-01 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:25 --> Total execution time: 0.0433
DEBUG - 2022-07-01 05:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:35 --> Total execution time: 0.0500
DEBUG - 2022-07-01 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:45 --> Total execution time: 0.0739
DEBUG - 2022-07-01 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:51:51 --> Total execution time: 0.0824
DEBUG - 2022-07-01 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:22:09 --> Total execution time: 0.0390
DEBUG - 2022-07-01 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:22:10 --> Total execution time: 0.0552
DEBUG - 2022-07-01 05:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:22:10 --> Total execution time: 0.1027
DEBUG - 2022-07-01 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:52:25 --> Total execution time: 0.0486
DEBUG - 2022-07-01 05:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:22:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:22:32 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:53:11 --> Total execution time: 0.0391
DEBUG - 2022-07-01 05:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:53:14 --> Total execution time: 0.1354
DEBUG - 2022-07-01 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:53:35 --> Total execution time: 0.0475
DEBUG - 2022-07-01 05:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:53:45 --> Total execution time: 0.0395
DEBUG - 2022-07-01 05:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:23:54 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:53:54 --> Total execution time: 0.1106
DEBUG - 2022-07-01 05:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:54:00 --> Total execution time: 0.1570
DEBUG - 2022-07-01 05:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:54:16 --> Total execution time: 0.0455
DEBUG - 2022-07-01 05:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:24:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:24:43 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 05:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:55:26 --> Total execution time: 0.0548
DEBUG - 2022-07-01 05:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:55:43 --> Total execution time: 0.0576
DEBUG - 2022-07-01 05:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:55:47 --> Total execution time: 0.0958
DEBUG - 2022-07-01 05:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:56:07 --> Total execution time: 0.0493
DEBUG - 2022-07-01 05:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:20 --> Total execution time: 0.0515
DEBUG - 2022-07-01 05:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:25 --> Total execution time: 0.0641
DEBUG - 2022-07-01 05:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:26 --> Total execution time: 0.0514
DEBUG - 2022-07-01 05:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:29 --> Total execution time: 0.0500
DEBUG - 2022-07-01 05:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:31 --> Total execution time: 0.0442
DEBUG - 2022-07-01 05:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:32 --> Total execution time: 0.0531
DEBUG - 2022-07-01 05:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:33 --> Total execution time: 0.0503
DEBUG - 2022-07-01 05:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:33 --> Total execution time: 0.0915
DEBUG - 2022-07-01 05:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:33 --> Total execution time: 0.0896
DEBUG - 2022-07-01 05:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:33 --> Total execution time: 0.0612
DEBUG - 2022-07-01 05:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:34 --> Total execution time: 0.0476
DEBUG - 2022-07-01 05:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:38 --> Total execution time: 0.0692
DEBUG - 2022-07-01 05:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:43 --> Total execution time: 0.0506
DEBUG - 2022-07-01 05:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:48 --> Total execution time: 0.0542
DEBUG - 2022-07-01 05:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:57:59 --> Total execution time: 0.0452
DEBUG - 2022-07-01 05:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:58:17 --> Total execution time: 0.0478
DEBUG - 2022-07-01 05:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:58:31 --> Total execution time: 0.1273
DEBUG - 2022-07-01 05:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:58:39 --> Total execution time: 0.0558
DEBUG - 2022-07-01 05:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:58:41 --> Total execution time: 0.0432
DEBUG - 2022-07-01 05:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:58:47 --> Total execution time: 0.0438
DEBUG - 2022-07-01 05:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:29:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:59:36 --> Total execution time: 0.0343
DEBUG - 2022-07-01 05:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:29:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:59:36 --> Total execution time: 0.0321
DEBUG - 2022-07-01 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:59:43 --> Total execution time: 0.1072
DEBUG - 2022-07-01 05:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:59:55 --> Total execution time: 0.0412
DEBUG - 2022-07-01 05:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:00:02 --> Total execution time: 0.0981
DEBUG - 2022-07-01 05:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:00:12 --> Total execution time: 0.0684
DEBUG - 2022-07-01 05:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:00:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:00:13 --> Total execution time: 0.0483
DEBUG - 2022-07-01 05:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:32:38 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:02:38 --> Total execution time: 0.1069
DEBUG - 2022-07-01 05:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:33:11 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-01 05:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:33:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 05:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:33:14 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-01 05:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:04:54 --> Total execution time: 0.1297
DEBUG - 2022-07-01 05:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:05:01 --> Total execution time: 0.0586
DEBUG - 2022-07-01 05:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:05:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:05:03 --> Total execution time: 0.0541
DEBUG - 2022-07-01 05:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:05:56 --> Total execution time: 0.0614
DEBUG - 2022-07-01 05:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:06:44 --> Total execution time: 0.0499
DEBUG - 2022-07-01 05:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:07:18 --> Total execution time: 0.0448
DEBUG - 2022-07-01 05:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:39:20 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:09:21 --> Total execution time: 0.1233
DEBUG - 2022-07-01 05:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:39:50 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:09:50 --> Total execution time: 0.0466
DEBUG - 2022-07-01 05:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:09:53 --> Total execution time: 0.1167
DEBUG - 2022-07-01 05:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:39:57 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:09:57 --> Total execution time: 0.0359
DEBUG - 2022-07-01 05:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:39:58 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:09:58 --> Total execution time: 0.0459
DEBUG - 2022-07-01 05:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:39:59 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:09:59 --> Total execution time: 0.0329
DEBUG - 2022-07-01 05:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:01 --> Total execution time: 0.0581
DEBUG - 2022-07-01 05:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:05 --> Total execution time: 0.0304
DEBUG - 2022-07-01 05:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:09 --> Total execution time: 0.0309
DEBUG - 2022-07-01 05:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:23 --> Total execution time: 0.0487
DEBUG - 2022-07-01 05:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:25 --> Total execution time: 0.0455
DEBUG - 2022-07-01 05:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:33 --> Total execution time: 0.4555
DEBUG - 2022-07-01 05:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:41 --> Total execution time: 0.0454
DEBUG - 2022-07-01 05:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:42 --> Total execution time: 0.0612
DEBUG - 2022-07-01 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:43 --> Total execution time: 0.0313
DEBUG - 2022-07-01 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:43 --> Total execution time: 0.0569
DEBUG - 2022-07-01 05:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:57 --> Total execution time: 0.0452
DEBUG - 2022-07-01 05:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:11:18 --> Total execution time: 0.0454
DEBUG - 2022-07-01 05:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:11:28 --> Total execution time: 0.0574
DEBUG - 2022-07-01 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:11:45 --> Total execution time: 0.0518
DEBUG - 2022-07-01 05:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:11:48 --> Total execution time: 0.0458
DEBUG - 2022-07-01 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:11:53 --> Total execution time: 0.0658
DEBUG - 2022-07-01 05:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:11:56 --> Total execution time: 0.0648
DEBUG - 2022-07-01 05:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:03 --> Total execution time: 0.1330
DEBUG - 2022-07-01 05:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:13 --> Total execution time: 0.0470
DEBUG - 2022-07-01 05:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:15 --> Total execution time: 0.0491
DEBUG - 2022-07-01 05:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:17 --> Total execution time: 0.0713
DEBUG - 2022-07-01 05:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:23 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:23 --> Total execution time: 0.0741
DEBUG - 2022-07-01 05:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:27 --> Total execution time: 0.0496
DEBUG - 2022-07-01 05:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:31 --> Total execution time: 0.0666
DEBUG - 2022-07-01 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:34 --> Total execution time: 0.0483
DEBUG - 2022-07-01 05:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:44 --> Total execution time: 0.0484
DEBUG - 2022-07-01 05:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:57 --> Total execution time: 0.2003
DEBUG - 2022-07-01 05:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:58 --> Total execution time: 0.0562
DEBUG - 2022-07-01 05:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:12:59 --> Total execution time: 0.0835
DEBUG - 2022-07-01 05:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:00 --> Total execution time: 0.0485
DEBUG - 2022-07-01 05:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:02 --> Total execution time: 0.0522
DEBUG - 2022-07-01 05:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:04 --> Total execution time: 0.0575
DEBUG - 2022-07-01 05:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:05 --> Total execution time: 0.0546
DEBUG - 2022-07-01 05:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:09 --> Total execution time: 0.0476
DEBUG - 2022-07-01 05:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:11 --> Total execution time: 0.0639
DEBUG - 2022-07-01 05:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:12 --> Total execution time: 0.0623
DEBUG - 2022-07-01 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:27 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:27 --> Total execution time: 0.0500
DEBUG - 2022-07-01 05:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:43:40 --> Total execution time: 0.0544
DEBUG - 2022-07-01 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:43:42 --> Total execution time: 0.0578
DEBUG - 2022-07-01 05:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:43:42 --> Total execution time: 0.0930
DEBUG - 2022-07-01 05:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:55 --> Total execution time: 0.0327
DEBUG - 2022-07-01 05:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:31 --> Total execution time: 0.0487
DEBUG - 2022-07-01 05:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:42 --> Total execution time: 0.0743
DEBUG - 2022-07-01 05:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:43 --> Total execution time: 0.0424
DEBUG - 2022-07-01 05:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:17 --> Total execution time: 0.0536
DEBUG - 2022-07-01 05:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:34 --> Total execution time: 0.0490
DEBUG - 2022-07-01 05:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:51 --> Total execution time: 0.0529
DEBUG - 2022-07-01 05:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:16:19 --> Total execution time: 0.0462
DEBUG - 2022-07-01 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:16:37 --> Total execution time: 0.0386
DEBUG - 2022-07-01 05:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:46:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:16:47 --> Total execution time: 0.0539
DEBUG - 2022-07-01 05:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:17:05 --> Total execution time: 0.0474
DEBUG - 2022-07-01 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:17:21 --> Total execution time: 0.0608
DEBUG - 2022-07-01 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:17:41 --> Total execution time: 0.0448
DEBUG - 2022-07-01 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:48:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:12 --> Total execution time: 0.0426
DEBUG - 2022-07-01 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 05:48:39 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 05:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:12 --> Total execution time: 0.0420
DEBUG - 2022-07-01 05:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:30 --> Total execution time: 0.0548
DEBUG - 2022-07-01 05:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:54 --> Total execution time: 0.0485
DEBUG - 2022-07-01 05:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:59 --> Total execution time: 0.0467
DEBUG - 2022-07-01 05:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:05 --> Total execution time: 0.1189
DEBUG - 2022-07-01 16:20:05 --> Total execution time: 0.1100
DEBUG - 2022-07-01 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:07 --> Total execution time: 0.0560
DEBUG - 2022-07-01 05:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:08 --> Total execution time: 0.0475
DEBUG - 2022-07-01 05:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:25 --> Total execution time: 0.0510
DEBUG - 2022-07-01 05:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:27 --> Total execution time: 0.0523
DEBUG - 2022-07-01 05:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:48 --> Total execution time: 0.0522
DEBUG - 2022-07-01 05:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:59 --> Total execution time: 0.1261
DEBUG - 2022-07-01 05:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:20:59 --> Total execution time: 0.0574
DEBUG - 2022-07-01 05:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:07 --> Total execution time: 0.1331
DEBUG - 2022-07-01 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:22 --> Total execution time: 0.0456
DEBUG - 2022-07-01 05:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:22:01 --> Total execution time: 0.0689
DEBUG - 2022-07-01 05:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:22:31 --> Total execution time: 0.0591
DEBUG - 2022-07-01 05:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:52:36 --> Total execution time: 0.0553
DEBUG - 2022-07-01 05:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:22:47 --> Total execution time: 0.0443
DEBUG - 2022-07-01 05:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:52:49 --> Total execution time: 0.0637
DEBUG - 2022-07-01 05:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:04 --> Total execution time: 0.0534
DEBUG - 2022-07-01 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:19 --> Total execution time: 0.0832
DEBUG - 2022-07-01 05:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:25 --> Total execution time: 0.0546
DEBUG - 2022-07-01 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:42 --> Total execution time: 0.0600
DEBUG - 2022-07-01 05:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:53:53 --> Total execution time: 0.0439
DEBUG - 2022-07-01 05:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:58 --> Total execution time: 0.0722
DEBUG - 2022-07-01 05:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:05 --> Total execution time: 0.0536
DEBUG - 2022-07-01 05:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:06 --> Total execution time: 0.0590
DEBUG - 2022-07-01 05:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:26 --> Total execution time: 0.0580
DEBUG - 2022-07-01 05:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:31 --> Total execution time: 0.0456
DEBUG - 2022-07-01 05:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:48 --> Total execution time: 0.0448
DEBUG - 2022-07-01 05:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:25:05 --> Total execution time: 0.0655
DEBUG - 2022-07-01 05:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:25:19 --> Total execution time: 0.0453
DEBUG - 2022-07-01 05:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:55:21 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:25:21 --> Total execution time: 0.0317
DEBUG - 2022-07-01 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:25:22 --> Total execution time: 0.0556
DEBUG - 2022-07-01 05:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:25:59 --> Total execution time: 0.0529
DEBUG - 2022-07-01 05:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:26:04 --> Total execution time: 0.0440
DEBUG - 2022-07-01 05:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:26:13 --> Total execution time: 0.0598
DEBUG - 2022-07-01 05:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:26:33 --> Total execution time: 0.0492
DEBUG - 2022-07-01 05:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:26:56 --> Total execution time: 0.0522
DEBUG - 2022-07-01 05:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:27:16 --> Total execution time: 0.0561
DEBUG - 2022-07-01 05:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:27:35 --> Total execution time: 0.0878
DEBUG - 2022-07-01 05:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:27:48 --> Total execution time: 0.1083
DEBUG - 2022-07-01 05:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:57:56 --> Total execution time: 0.1093
DEBUG - 2022-07-01 05:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:57:57 --> Total execution time: 0.0509
DEBUG - 2022-07-01 05:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:57:57 --> Total execution time: 0.0552
DEBUG - 2022-07-01 05:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:00 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:00 --> Total execution time: 0.0415
DEBUG - 2022-07-01 05:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 05:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:04 --> Total execution time: 0.0621
DEBUG - 2022-07-01 05:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:06 --> Total execution time: 0.0532
DEBUG - 2022-07-01 05:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:09 --> Total execution time: 0.0493
DEBUG - 2022-07-01 05:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:13 --> Total execution time: 0.0320
DEBUG - 2022-07-01 05:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:13 --> Total execution time: 0.0529
DEBUG - 2022-07-01 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:18 --> Total execution time: 0.0545
DEBUG - 2022-07-01 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:23 --> Total execution time: 0.0502
DEBUG - 2022-07-01 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:28 --> Total execution time: 0.0502
DEBUG - 2022-07-01 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:36 --> Total execution time: 0.0453
DEBUG - 2022-07-01 05:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:42 --> Total execution time: 0.0485
DEBUG - 2022-07-01 05:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:43 --> Total execution time: 0.0469
DEBUG - 2022-07-01 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:44 --> Total execution time: 0.0725
DEBUG - 2022-07-01 05:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:48 --> Total execution time: 0.0770
DEBUG - 2022-07-01 05:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:49 --> Total execution time: 0.0736
DEBUG - 2022-07-01 05:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:54 --> Total execution time: 0.0668
DEBUG - 2022-07-01 05:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 05:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:29:33 --> Total execution time: 0.0499
DEBUG - 2022-07-01 05:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:29:36 --> Total execution time: 0.0517
DEBUG - 2022-07-01 05:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 05:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 05:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:29:40 --> Total execution time: 0.0491
DEBUG - 2022-07-01 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:02 --> Total execution time: 0.1146
DEBUG - 2022-07-01 06:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:00:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:31 --> Total execution time: 0.5192
DEBUG - 2022-07-01 06:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:35 --> Total execution time: 0.2832
DEBUG - 2022-07-01 06:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:51 --> Total execution time: 0.0573
DEBUG - 2022-07-01 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:22 --> Total execution time: 0.1404
DEBUG - 2022-07-01 06:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:25 --> Total execution time: 0.0914
DEBUG - 2022-07-01 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:30 --> Total execution time: 0.0545
DEBUG - 2022-07-01 06:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:36 --> Total execution time: 0.0503
DEBUG - 2022-07-01 06:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:41 --> Total execution time: 0.0707
DEBUG - 2022-07-01 06:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:01 --> Total execution time: 0.0562
DEBUG - 2022-07-01 06:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:04 --> Total execution time: 0.0550
DEBUG - 2022-07-01 06:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:14 --> Total execution time: 0.0631
DEBUG - 2022-07-01 06:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:15 --> Total execution time: 0.0466
DEBUG - 2022-07-01 06:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:29 --> Total execution time: 0.0885
DEBUG - 2022-07-01 06:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:30 --> Total execution time: 0.0760
DEBUG - 2022-07-01 06:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:08 --> Total execution time: 0.1697
DEBUG - 2022-07-01 06:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:40 --> Total execution time: 0.1171
DEBUG - 2022-07-01 06:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:01 --> Total execution time: 0.0483
DEBUG - 2022-07-01 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:02 --> Total execution time: 0.1117
DEBUG - 2022-07-01 06:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:17 --> Total execution time: 0.0503
DEBUG - 2022-07-01 06:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:36 --> Total execution time: 0.0510
DEBUG - 2022-07-01 06:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:57 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:58 --> Total execution time: 0.0541
DEBUG - 2022-07-01 06:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:58 --> Total execution time: 0.0418
DEBUG - 2022-07-01 06:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:03 --> Total execution time: 0.0683
DEBUG - 2022-07-01 06:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:04 --> Total execution time: 0.0920
DEBUG - 2022-07-01 06:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:08 --> Total execution time: 0.1068
DEBUG - 2022-07-01 06:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:22 --> Total execution time: 0.1447
DEBUG - 2022-07-01 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:31 --> Total execution time: 0.0499
DEBUG - 2022-07-01 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 06:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:32 --> Total execution time: 0.0471
DEBUG - 2022-07-01 06:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:36:38 --> Total execution time: 0.0655
DEBUG - 2022-07-01 06:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:36:40 --> Total execution time: 0.0476
DEBUG - 2022-07-01 06:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:36:54 --> Total execution time: 0.0624
DEBUG - 2022-07-01 06:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:37:03 --> Total execution time: 0.0615
DEBUG - 2022-07-01 06:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:37:12 --> Total execution time: 0.0770
DEBUG - 2022-07-01 06:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:38:24 --> Total execution time: 0.0767
DEBUG - 2022-07-01 06:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:10:10 --> Total execution time: 0.0771
DEBUG - 2022-07-01 06:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:10:18 --> Total execution time: 0.0591
DEBUG - 2022-07-01 06:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:11:57 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:41:58 --> Total execution time: 0.1009
DEBUG - 2022-07-01 06:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:41:58 --> Total execution time: 0.1443
DEBUG - 2022-07-01 06:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:42:30 --> Total execution time: 0.0657
DEBUG - 2022-07-01 06:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:42:41 --> Total execution time: 0.0622
DEBUG - 2022-07-01 06:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:42:48 --> Total execution time: 0.1346
DEBUG - 2022-07-01 06:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:42:53 --> Total execution time: 0.0565
DEBUG - 2022-07-01 06:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:42:56 --> Total execution time: 0.0503
DEBUG - 2022-07-01 06:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:43:04 --> Total execution time: 0.0914
DEBUG - 2022-07-01 06:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:43:10 --> Total execution time: 0.0517
DEBUG - 2022-07-01 06:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:13:36 --> Total execution time: 0.0847
DEBUG - 2022-07-01 06:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:13:44 --> Total execution time: 0.0821
DEBUG - 2022-07-01 06:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:44:27 --> Total execution time: 0.0745
DEBUG - 2022-07-01 06:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:14:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:44:37 --> Total execution time: 0.0402
DEBUG - 2022-07-01 06:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:44:50 --> Total execution time: 0.0956
DEBUG - 2022-07-01 06:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:44:52 --> Total execution time: 0.0719
DEBUG - 2022-07-01 06:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:04 --> Total execution time: 0.0459
DEBUG - 2022-07-01 06:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:08 --> Total execution time: 0.0492
DEBUG - 2022-07-01 06:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:16 --> Total execution time: 0.0510
DEBUG - 2022-07-01 06:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:22 --> Total execution time: 0.0467
DEBUG - 2022-07-01 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:39 --> Total execution time: 0.0452
DEBUG - 2022-07-01 06:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:54 --> Total execution time: 0.0454
DEBUG - 2022-07-01 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:59 --> Total execution time: 0.0440
DEBUG - 2022-07-01 06:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:04 --> Total execution time: 0.0391
DEBUG - 2022-07-01 06:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:17 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:17 --> Total execution time: 0.0693
DEBUG - 2022-07-01 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:21 --> Total execution time: 0.0560
DEBUG - 2022-07-01 06:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:22 --> Total execution time: 0.0496
DEBUG - 2022-07-01 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:28 --> Total execution time: 0.0716
DEBUG - 2022-07-01 06:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:34 --> Total execution time: 0.0467
DEBUG - 2022-07-01 06:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:34 --> Total execution time: 0.0486
DEBUG - 2022-07-01 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:41 --> Total execution time: 0.0948
DEBUG - 2022-07-01 06:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:49 --> Total execution time: 0.0549
DEBUG - 2022-07-01 06:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:53 --> Total execution time: 0.0881
DEBUG - 2022-07-01 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:58 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:58 --> Total execution time: 0.0492
DEBUG - 2022-07-01 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:58 --> Total execution time: 0.0555
DEBUG - 2022-07-01 06:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:04 --> Total execution time: 0.0532
DEBUG - 2022-07-01 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:08 --> Total execution time: 0.0485
DEBUG - 2022-07-01 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:09 --> Total execution time: 0.0490
DEBUG - 2022-07-01 06:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:56 --> Total execution time: 0.0471
DEBUG - 2022-07-01 06:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:48:02 --> Total execution time: 0.0663
DEBUG - 2022-07-01 06:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:48:04 --> Total execution time: 0.0612
DEBUG - 2022-07-01 06:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:18:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:48:04 --> Total execution time: 0.0469
DEBUG - 2022-07-01 06:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:18:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:48:53 --> Total execution time: 0.0326
DEBUG - 2022-07-01 06:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:18:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:48:53 --> Total execution time: 0.0295
DEBUG - 2022-07-01 06:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:48:57 --> Total execution time: 0.0255
DEBUG - 2022-07-01 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:49:03 --> Total execution time: 0.0497
DEBUG - 2022-07-01 06:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:49:07 --> Total execution time: 0.0573
DEBUG - 2022-07-01 06:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:49:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 06:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:49:36 --> Total execution time: 0.0702
DEBUG - 2022-07-01 06:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:15 --> Total execution time: 0.0334
DEBUG - 2022-07-01 06:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:22 --> Total execution time: 0.0375
DEBUG - 2022-07-01 06:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:24 --> Total execution time: 0.0340
DEBUG - 2022-07-01 06:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:25 --> Total execution time: 0.0312
DEBUG - 2022-07-01 06:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:26 --> Total execution time: 0.0343
DEBUG - 2022-07-01 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:38 --> Total execution time: 0.0562
DEBUG - 2022-07-01 06:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:41 --> Total execution time: 0.0361
DEBUG - 2022-07-01 06:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:56 --> Total execution time: 0.0803
DEBUG - 2022-07-01 06:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:50:59 --> Total execution time: 0.0424
DEBUG - 2022-07-01 06:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:51:12 --> Total execution time: 0.0810
DEBUG - 2022-07-01 06:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:51:46 --> Total execution time: 0.0997
DEBUG - 2022-07-01 06:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:51:54 --> Total execution time: 0.0563
DEBUG - 2022-07-01 06:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:51:57 --> Total execution time: 0.0568
DEBUG - 2022-07-01 06:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:52:10 --> Total execution time: 0.0596
DEBUG - 2022-07-01 06:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:52:22 --> Total execution time: 0.1181
DEBUG - 2022-07-01 06:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:52:26 --> Total execution time: 0.0640
DEBUG - 2022-07-01 06:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:52:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 06:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:52:27 --> Total execution time: 0.0546
DEBUG - 2022-07-01 06:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:22:54 --> Total execution time: 0.0668
DEBUG - 2022-07-01 06:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:23:04 --> Total execution time: 0.0601
DEBUG - 2022-07-01 06:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:53:54 --> Total execution time: 0.0814
DEBUG - 2022-07-01 06:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:54:08 --> Total execution time: 0.0681
DEBUG - 2022-07-01 06:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:54:13 --> Total execution time: 0.0654
DEBUG - 2022-07-01 06:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:54:16 --> Total execution time: 0.0611
DEBUG - 2022-07-01 06:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:56:58 --> Total execution time: 0.1190
DEBUG - 2022-07-01 06:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:56:59 --> Total execution time: 0.0546
DEBUG - 2022-07-01 06:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:57:11 --> Total execution time: 0.0470
DEBUG - 2022-07-01 06:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:57:20 --> Total execution time: 0.0489
DEBUG - 2022-07-01 06:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:57:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 06:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:57:21 --> Total execution time: 0.0492
DEBUG - 2022-07-01 06:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:57:24 --> Total execution time: 0.1315
DEBUG - 2022-07-01 06:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:57:33 --> Total execution time: 0.0510
DEBUG - 2022-07-01 06:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:57:48 --> Total execution time: 0.0456
DEBUG - 2022-07-01 06:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:28:09 --> Total execution time: 0.0718
DEBUG - 2022-07-01 06:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:32:16 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:02:16 --> Total execution time: 0.1295
DEBUG - 2022-07-01 06:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:35:27 --> Total execution time: 0.0522
DEBUG - 2022-07-01 06:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:35:40 --> Total execution time: 0.0558
DEBUG - 2022-07-01 06:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:35:54 --> Total execution time: 0.0514
DEBUG - 2022-07-01 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:36:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:06:37 --> Total execution time: 0.0421
DEBUG - 2022-07-01 06:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:36:46 --> Total execution time: 0.0578
DEBUG - 2022-07-01 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:36:48 --> Total execution time: 0.0582
DEBUG - 2022-07-01 06:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:36:48 --> Total execution time: 0.1017
DEBUG - 2022-07-01 06:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:07:37 --> Total execution time: 0.0336
DEBUG - 2022-07-01 06:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:08:03 --> Total execution time: 0.0352
DEBUG - 2022-07-01 06:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:08:14 --> Total execution time: 0.0359
DEBUG - 2022-07-01 06:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:08:26 --> Total execution time: 0.0764
DEBUG - 2022-07-01 06:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:38:28 --> Total execution time: 0.0800
DEBUG - 2022-07-01 06:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:08:32 --> Total execution time: 0.0568
DEBUG - 2022-07-01 06:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:08:33 --> Total execution time: 0.0693
DEBUG - 2022-07-01 06:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:08:36 --> Total execution time: 0.0524
DEBUG - 2022-07-01 06:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:08:40 --> Total execution time: 0.0388
DEBUG - 2022-07-01 06:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:08:56 --> Total execution time: 0.0466
DEBUG - 2022-07-01 06:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:04 --> Total execution time: 0.0444
DEBUG - 2022-07-01 06:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:18 --> Total execution time: 0.0624
DEBUG - 2022-07-01 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:36 --> Total execution time: 0.0322
DEBUG - 2022-07-01 06:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:38 --> Total execution time: 0.0470
DEBUG - 2022-07-01 06:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:44 --> Total execution time: 0.0454
DEBUG - 2022-07-01 06:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:49 --> Total execution time: 0.0610
DEBUG - 2022-07-01 06:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:54 --> Total execution time: 0.0841
DEBUG - 2022-07-01 06:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:57 --> Total execution time: 0.0581
DEBUG - 2022-07-01 06:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:59 --> Total execution time: 0.0763
DEBUG - 2022-07-01 06:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:09:59 --> Total execution time: 0.0833
DEBUG - 2022-07-01 06:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:10:02 --> Total execution time: 0.0904
DEBUG - 2022-07-01 06:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:10:08 --> Total execution time: 0.0648
DEBUG - 2022-07-01 06:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:40:23 --> Total execution time: 0.1117
DEBUG - 2022-07-01 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:40:24 --> Total execution time: 0.0452
DEBUG - 2022-07-01 06:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:40:24 --> Total execution time: 0.0894
DEBUG - 2022-07-01 06:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:14 --> Total execution time: 0.0495
DEBUG - 2022-07-01 06:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:21 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:21 --> Total execution time: 0.0486
DEBUG - 2022-07-01 06:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 17:11:31 --> Total execution time: 0.0584
DEBUG - 2022-07-01 06:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:31 --> Total execution time: 0.0769
DEBUG - 2022-07-01 06:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:31 --> Total execution time: 0.0826
DEBUG - 2022-07-01 06:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:35 --> Total execution time: 0.0450
DEBUG - 2022-07-01 06:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:37 --> Total execution time: 0.0452
DEBUG - 2022-07-01 06:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:44 --> Total execution time: 0.0503
DEBUG - 2022-07-01 06:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:46 --> Total execution time: 0.0529
DEBUG - 2022-07-01 06:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:49 --> Total execution time: 0.0607
DEBUG - 2022-07-01 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:52 --> Total execution time: 0.0570
DEBUG - 2022-07-01 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:15:56 --> Total execution time: 0.1166
DEBUG - 2022-07-01 06:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:47:00 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:17:01 --> Total execution time: 0.0440
DEBUG - 2022-07-01 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:17:21 --> Total execution time: 0.0480
DEBUG - 2022-07-01 06:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:49:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:19:14 --> Total execution time: 0.0552
DEBUG - 2022-07-01 06:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:19:20 --> Total execution time: 0.0469
DEBUG - 2022-07-01 06:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:50:34 --> Total execution time: 0.0469
DEBUG - 2022-07-01 06:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:50:37 --> Total execution time: 0.0530
DEBUG - 2022-07-01 06:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:50:37 --> Total execution time: 0.0992
DEBUG - 2022-07-01 06:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:50:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 06:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:20:48 --> Total execution time: 0.0507
DEBUG - 2022-07-01 06:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:20:52 --> Total execution time: 0.0657
DEBUG - 2022-07-01 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:21:03 --> Total execution time: 0.0696
DEBUG - 2022-07-01 06:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:22:13 --> Total execution time: 0.0726
DEBUG - 2022-07-01 06:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:22:44 --> Total execution time: 0.0515
DEBUG - 2022-07-01 06:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:23:47 --> Total execution time: 0.0580
DEBUG - 2022-07-01 06:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:23:55 --> Total execution time: 0.0400
DEBUG - 2022-07-01 06:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 06:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:24:19 --> Total execution time: 0.0512
DEBUG - 2022-07-01 06:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:24:24 --> Total execution time: 0.0628
DEBUG - 2022-07-01 06:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:24:31 --> Total execution time: 0.0569
DEBUG - 2022-07-01 06:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:24:44 --> Total execution time: 0.0495
DEBUG - 2022-07-01 06:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:25:36 --> Total execution time: 0.0542
DEBUG - 2022-07-01 06:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 06:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:29:10 --> Total execution time: 0.1148
DEBUG - 2022-07-01 06:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 06:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 06:59:59 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:30:03 --> Total execution time: 0.1462
DEBUG - 2022-07-01 07:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 07:02:31 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 07:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 07:04:35 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 07:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:08:50 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:38:51 --> Total execution time: 0.1819
DEBUG - 2022-07-01 07:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:38:51 --> Total execution time: 0.0585
DEBUG - 2022-07-01 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:38:59 --> Total execution time: 0.0636
DEBUG - 2022-07-01 07:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:39:08 --> Total execution time: 0.0524
DEBUG - 2022-07-01 07:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:39:18 --> Total execution time: 0.0538
DEBUG - 2022-07-01 07:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:39:27 --> Total execution time: 0.0683
DEBUG - 2022-07-01 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:39:49 --> Total execution time: 0.0482
DEBUG - 2022-07-01 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:40:05 --> Total execution time: 0.0468
DEBUG - 2022-07-01 07:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:41:44 --> Total execution time: 0.1355
DEBUG - 2022-07-01 07:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:12:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:42:30 --> Total execution time: 0.0369
DEBUG - 2022-07-01 07:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:12:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:42:36 --> Total execution time: 0.0467
DEBUG - 2022-07-01 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:43:03 --> Total execution time: 0.0337
DEBUG - 2022-07-01 07:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:43:19 --> Total execution time: 0.0466
DEBUG - 2022-07-01 07:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:43:23 --> Total execution time: 0.0419
DEBUG - 2022-07-01 07:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:43:27 --> Total execution time: 0.0834
DEBUG - 2022-07-01 07:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:43:30 --> Total execution time: 0.0534
DEBUG - 2022-07-01 07:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:43:33 --> Total execution time: 0.0313
DEBUG - 2022-07-01 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:43:39 --> Total execution time: 0.0448
DEBUG - 2022-07-01 07:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:44:13 --> Total execution time: 0.0600
DEBUG - 2022-07-01 07:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:44:29 --> Total execution time: 0.0617
DEBUG - 2022-07-01 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:14:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:44:36 --> Total execution time: 0.0691
DEBUG - 2022-07-01 07:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:15:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:45:13 --> Total execution time: 0.0783
DEBUG - 2022-07-01 07:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:45:19 --> Total execution time: 0.0317
DEBUG - 2022-07-01 07:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:15:56 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:45:56 --> Total execution time: 0.0342
DEBUG - 2022-07-01 07:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:46:01 --> Total execution time: 0.0448
DEBUG - 2022-07-01 07:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:46:10 --> Total execution time: 0.0573
DEBUG - 2022-07-01 07:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:46:18 --> Total execution time: 0.0518
DEBUG - 2022-07-01 07:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:46:32 --> Total execution time: 0.0620
DEBUG - 2022-07-01 07:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:46:51 --> Total execution time: 0.0513
DEBUG - 2022-07-01 07:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:46:53 --> Total execution time: 0.0633
DEBUG - 2022-07-01 07:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:46:59 --> Total execution time: 0.0565
DEBUG - 2022-07-01 07:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:48:33 --> Total execution time: 0.1294
DEBUG - 2022-07-01 07:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:48:34 --> Total execution time: 0.0625
DEBUG - 2022-07-01 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:48:44 --> Total execution time: 0.0578
DEBUG - 2022-07-01 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:48:50 --> Total execution time: 0.0778
DEBUG - 2022-07-01 07:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:48:51 --> Total execution time: 0.0780
DEBUG - 2022-07-01 07:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:48:54 --> Total execution time: 0.0563
DEBUG - 2022-07-01 07:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:49:01 --> Total execution time: 0.1094
DEBUG - 2022-07-01 07:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:19:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:49:35 --> Total execution time: 0.0337
DEBUG - 2022-07-01 07:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:50:42 --> Total execution time: 0.0478
DEBUG - 2022-07-01 07:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:52:24 --> Total execution time: 0.0509
DEBUG - 2022-07-01 07:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:52:27 --> Total execution time: 0.0469
DEBUG - 2022-07-01 07:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:52:54 --> Total execution time: 0.0513
DEBUG - 2022-07-01 07:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:53:00 --> Total execution time: 0.0844
DEBUG - 2022-07-01 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:23:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:53:15 --> Total execution time: 0.0381
DEBUG - 2022-07-01 07:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:23:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:53:53 --> Total execution time: 0.0335
DEBUG - 2022-07-01 07:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:23:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:53:53 --> Total execution time: 0.0334
DEBUG - 2022-07-01 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:25:25 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:55:25 --> Total execution time: 0.1214
DEBUG - 2022-07-01 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:25:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:55:43 --> Total execution time: 0.0495
DEBUG - 2022-07-01 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:26:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:56:02 --> Total execution time: 0.1237
DEBUG - 2022-07-01 07:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:26:21 --> Total execution time: 0.0508
DEBUG - 2022-07-01 07:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:26:29 --> Total execution time: 0.0714
DEBUG - 2022-07-01 07:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:26:30 --> Total execution time: 0.0936
DEBUG - 2022-07-01 07:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 07:28:09 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 07:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:28:36 --> Total execution time: 0.0550
DEBUG - 2022-07-01 07:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:28:38 --> Total execution time: 0.0495
DEBUG - 2022-07-01 07:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:28:38 --> Total execution time: 0.0666
DEBUG - 2022-07-01 07:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:29:16 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:59:16 --> Total execution time: 0.0575
DEBUG - 2022-07-01 07:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:29:35 --> Total execution time: 0.0561
DEBUG - 2022-07-01 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:29:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:59:41 --> Total execution time: 1.5684
DEBUG - 2022-07-01 07:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 07:29:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 07:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:05:03 --> Total execution time: 0.0500
DEBUG - 2022-07-01 07:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:35:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:05:07 --> Total execution time: 0.0566
DEBUG - 2022-07-01 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:07:17 --> Total execution time: 0.1235
DEBUG - 2022-07-01 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:38:29 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:08:29 --> Total execution time: 0.0431
DEBUG - 2022-07-01 07:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:38:59 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:08:59 --> Total execution time: 0.0425
DEBUG - 2022-07-01 07:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:39:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:09:07 --> Total execution time: 0.0617
DEBUG - 2022-07-01 07:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:09:24 --> Total execution time: 0.0471
DEBUG - 2022-07-01 07:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:09:32 --> Total execution time: 0.0538
DEBUG - 2022-07-01 07:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:09:48 --> Total execution time: 0.0632
DEBUG - 2022-07-01 07:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 07:40:33 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-07-01 07:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:40:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 07:40:41 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-07-01 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:40:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 07:40:48 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-07-01 07:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:13:01 --> Total execution time: 0.0553
DEBUG - 2022-07-01 07:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:43:24 --> Total execution time: 0.0519
DEBUG - 2022-07-01 07:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:13:53 --> Total execution time: 0.0672
DEBUG - 2022-07-01 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:45:55 --> Total execution time: 0.1012
DEBUG - 2022-07-01 07:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:47:07 --> Total execution time: 0.1135
DEBUG - 2022-07-01 07:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:18:24 --> Total execution time: 0.0769
DEBUG - 2022-07-01 07:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:18:42 --> Total execution time: 0.0823
DEBUG - 2022-07-01 07:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:18:56 --> Total execution time: 0.0814
DEBUG - 2022-07-01 07:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:19:11 --> Total execution time: 0.1981
DEBUG - 2022-07-01 07:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:22:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 07:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:22:24 --> Total execution time: 0.0531
DEBUG - 2022-07-01 07:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:22:55 --> Total execution time: 0.0695
DEBUG - 2022-07-01 07:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:22:55 --> Total execution time: 0.0603
DEBUG - 2022-07-01 07:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:01 --> Total execution time: 0.0521
DEBUG - 2022-07-01 07:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:02 --> Total execution time: 0.0577
DEBUG - 2022-07-01 07:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:06 --> Total execution time: 0.0520
DEBUG - 2022-07-01 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:11 --> Total execution time: 0.0745
DEBUG - 2022-07-01 07:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:17 --> Total execution time: 0.1287
DEBUG - 2022-07-01 07:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:32 --> Total execution time: 0.1210
DEBUG - 2022-07-01 07:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:43 --> Total execution time: 0.1203
DEBUG - 2022-07-01 07:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:43 --> Total execution time: 0.0725
DEBUG - 2022-07-01 07:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:45 --> Total execution time: 0.0651
DEBUG - 2022-07-01 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:47 --> Total execution time: 0.0560
DEBUG - 2022-07-01 07:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:48 --> Total execution time: 0.0496
DEBUG - 2022-07-01 07:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:51 --> Total execution time: 0.0532
DEBUG - 2022-07-01 07:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:53 --> Total execution time: 0.0735
DEBUG - 2022-07-01 07:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:55 --> Total execution time: 0.0742
DEBUG - 2022-07-01 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:23:57 --> Total execution time: 0.0770
DEBUG - 2022-07-01 07:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:24:00 --> Total execution time: 0.0480
DEBUG - 2022-07-01 07:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:24:02 --> Total execution time: 0.0596
DEBUG - 2022-07-01 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:24:03 --> Total execution time: 0.0492
DEBUG - 2022-07-01 07:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:24:16 --> Total execution time: 0.0526
DEBUG - 2022-07-01 07:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:24:27 --> Total execution time: 0.0711
DEBUG - 2022-07-01 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:26:43 --> Total execution time: 0.1962
DEBUG - 2022-07-01 07:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:59:16 --> No URI present. Default controller set.
DEBUG - 2022-07-01 07:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:29:16 --> Total execution time: 0.1117
DEBUG - 2022-07-01 07:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:29:22 --> Total execution time: 0.0405
DEBUG - 2022-07-01 07:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 07:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:29:41 --> Total execution time: 0.0674
DEBUG - 2022-07-01 07:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 07:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 07:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:29:56 --> Total execution time: 0.1915
DEBUG - 2022-07-01 08:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:30:02 --> Total execution time: 0.1632
DEBUG - 2022-07-01 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:30:02 --> Total execution time: 0.0829
DEBUG - 2022-07-01 08:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:30:15 --> Total execution time: 0.0343
DEBUG - 2022-07-01 08:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:00:16 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-01 08:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:30:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 08:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:30:31 --> Total execution time: 0.0916
DEBUG - 2022-07-01 08:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:30:43 --> Total execution time: 0.0496
DEBUG - 2022-07-01 08:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:30:58 --> Total execution time: 0.0597
DEBUG - 2022-07-01 08:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:31:12 --> Total execution time: 0.1137
DEBUG - 2022-07-01 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:01:46 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:31:46 --> Total execution time: 0.0343
DEBUG - 2022-07-01 08:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:34:03 --> Total execution time: 0.0572
DEBUG - 2022-07-01 08:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:04:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:34:07 --> Total execution time: 0.0380
DEBUG - 2022-07-01 08:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:34:12 --> Total execution time: 0.0338
DEBUG - 2022-07-01 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:34:17 --> Total execution time: 0.0523
DEBUG - 2022-07-01 08:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:34:44 --> Total execution time: 0.0539
DEBUG - 2022-07-01 08:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:34:49 --> Total execution time: 0.0971
DEBUG - 2022-07-01 08:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:35:14 --> Total execution time: 0.0551
DEBUG - 2022-07-01 08:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:35:28 --> Total execution time: 0.0721
DEBUG - 2022-07-01 08:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:35:32 --> Total execution time: 0.0544
DEBUG - 2022-07-01 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:36:06 --> Total execution time: 0.0787
DEBUG - 2022-07-01 08:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:36:07 --> Total execution time: 0.0674
DEBUG - 2022-07-01 08:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:36:23 --> Total execution time: 0.0671
DEBUG - 2022-07-01 08:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:36:29 --> Total execution time: 0.0561
DEBUG - 2022-07-01 08:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:06:43 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-01 08:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:41:43 --> Total execution time: 0.1690
DEBUG - 2022-07-01 08:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:16:39 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:46:40 --> Total execution time: 0.0949
DEBUG - 2022-07-01 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:20:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:50:28 --> Total execution time: 0.1609
DEBUG - 2022-07-01 18:50:28 --> Total execution time: 0.1736
DEBUG - 2022-07-01 08:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:50:36 --> Total execution time: 0.0551
DEBUG - 2022-07-01 08:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:50:45 --> Total execution time: 0.0500
DEBUG - 2022-07-01 08:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:51:14 --> Total execution time: 0.0780
DEBUG - 2022-07-01 08:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:51:32 --> Total execution time: 0.0690
DEBUG - 2022-07-01 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:52:13 --> Total execution time: 0.0592
DEBUG - 2022-07-01 08:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:32:21 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:02:21 --> Total execution time: 0.1995
DEBUG - 2022-07-01 08:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:02:21 --> Total execution time: 0.0747
DEBUG - 2022-07-01 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:03:13 --> Total execution time: 0.0536
DEBUG - 2022-07-01 08:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:03:29 --> Total execution time: 0.0713
DEBUG - 2022-07-01 08:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:33:38 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:03:38 --> Total execution time: 0.0345
DEBUG - 2022-07-01 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:03:40 --> Total execution time: 0.0516
DEBUG - 2022-07-01 08:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:03:48 --> Total execution time: 0.0610
DEBUG - 2022-07-01 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:03:57 --> Total execution time: 0.0566
DEBUG - 2022-07-01 08:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:37:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:07:24 --> Total execution time: 0.1192
DEBUG - 2022-07-01 08:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:37:25 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:07:25 --> Total execution time: 0.0380
DEBUG - 2022-07-01 08:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:07:46 --> Total execution time: 0.0343
DEBUG - 2022-07-01 08:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:08:01 --> Total execution time: 0.0647
DEBUG - 2022-07-01 08:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:08:07 --> Total execution time: 0.1057
DEBUG - 2022-07-01 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:39:03 --> 404 Page Not Found: Course/clickbank-mastery
DEBUG - 2022-07-01 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:39:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:39:19 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:09:29 --> Total execution time: 0.0303
DEBUG - 2022-07-01 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:09:36 --> Total execution time: 0.0694
DEBUG - 2022-07-01 08:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:09:37 --> Total execution time: 0.0503
DEBUG - 2022-07-01 08:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:09:42 --> Total execution time: 0.0901
DEBUG - 2022-07-01 08:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:10:18 --> Total execution time: 0.0494
DEBUG - 2022-07-01 08:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:10:29 --> Total execution time: 0.0542
DEBUG - 2022-07-01 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:10:50 --> Total execution time: 0.0693
DEBUG - 2022-07-01 08:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:11:20 --> Total execution time: 0.0606
DEBUG - 2022-07-01 08:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:41:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:41:50 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 08:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:44:00 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 08:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:14:11 --> Total execution time: 0.1336
DEBUG - 2022-07-01 08:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:20:15 --> Total execution time: 0.0822
DEBUG - 2022-07-01 08:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:50:55 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:20:55 --> Total execution time: 0.0483
DEBUG - 2022-07-01 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:21:02 --> Total execution time: 0.0520
DEBUG - 2022-07-01 08:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:21:09 --> Total execution time: 0.0552
DEBUG - 2022-07-01 08:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:21:22 --> Total execution time: 0.0660
DEBUG - 2022-07-01 08:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:21:36 --> Total execution time: 0.0591
DEBUG - 2022-07-01 08:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:21:53 --> Total execution time: 0.0614
DEBUG - 2022-07-01 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:22:05 --> Total execution time: 0.0494
DEBUG - 2022-07-01 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:52:10 --> Total execution time: 0.0702
DEBUG - 2022-07-01 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:52:30 --> Total execution time: 0.0481
DEBUG - 2022-07-01 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:52:35 --> Total execution time: 0.0503
DEBUG - 2022-07-01 08:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:52:38 --> Total execution time: 0.0470
DEBUG - 2022-07-01 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:52:39 --> Total execution time: 0.0451
DEBUG - 2022-07-01 08:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:22:41 --> Total execution time: 0.0899
DEBUG - 2022-07-01 08:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:22:44 --> Total execution time: 0.0482
DEBUG - 2022-07-01 08:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:22:48 --> Total execution time: 0.0557
DEBUG - 2022-07-01 08:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:22:58 --> Total execution time: 0.0766
DEBUG - 2022-07-01 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:53:19 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-01 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:53:19 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-07-01 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:53:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:53:21 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-07-01 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:53:21 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-07-01 08:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:53:22 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-07-01 08:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:53:22 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-01 08:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:53:22 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-01 08:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:23:38 --> Total execution time: 0.0733
DEBUG - 2022-07-01 08:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:24:00 --> Total execution time: 0.0700
DEBUG - 2022-07-01 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:24:17 --> Total execution time: 0.0530
DEBUG - 2022-07-01 08:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:24:23 --> Total execution time: 0.0559
DEBUG - 2022-07-01 08:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:24:26 --> Total execution time: 0.0414
DEBUG - 2022-07-01 08:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:24:30 --> Total execution time: 0.0796
DEBUG - 2022-07-01 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:54:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:24:43 --> Total execution time: 0.0547
DEBUG - 2022-07-01 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:24:47 --> Total execution time: 0.0490
DEBUG - 2022-07-01 08:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:04 --> Total execution time: 0.0571
DEBUG - 2022-07-01 08:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:06 --> Total execution time: 0.0487
DEBUG - 2022-07-01 08:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:20 --> Total execution time: 0.0496
DEBUG - 2022-07-01 08:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:21 --> Total execution time: 0.0618
DEBUG - 2022-07-01 08:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:27 --> Total execution time: 0.0407
DEBUG - 2022-07-01 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:55:29 --> Total execution time: 0.0411
DEBUG - 2022-07-01 08:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:30 --> Total execution time: 0.0294
DEBUG - 2022-07-01 08:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:38 --> Total execution time: 0.0460
DEBUG - 2022-07-01 08:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:44 --> Total execution time: 0.0733
DEBUG - 2022-07-01 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:46 --> Total execution time: 0.0424
DEBUG - 2022-07-01 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:55:46 --> Total execution time: 0.0451
DEBUG - 2022-07-01 08:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:25:47 --> Total execution time: 0.0473
DEBUG - 2022-07-01 08:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:56:00 --> Total execution time: 0.0450
DEBUG - 2022-07-01 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:56:07 --> Total execution time: 0.0571
DEBUG - 2022-07-01 08:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:56:09 --> Total execution time: 0.0446
DEBUG - 2022-07-01 08:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:26:09 --> Total execution time: 0.0447
DEBUG - 2022-07-01 08:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:26:21 --> Total execution time: 0.0823
DEBUG - 2022-07-01 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:26:28 --> Total execution time: 0.0645
DEBUG - 2022-07-01 08:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:26:35 --> Total execution time: 0.0739
DEBUG - 2022-07-01 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:26:48 --> Total execution time: 0.1238
DEBUG - 2022-07-01 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:27:06 --> Total execution time: 0.0484
DEBUG - 2022-07-01 08:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 08:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 08:57:44 --> 404 Page Not Found: Shop/feed
DEBUG - 2022-07-01 08:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 08:58:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 08:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 08:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:28:02 --> Total execution time: 0.0540
DEBUG - 2022-07-01 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:30:03 --> Total execution time: 0.4385
DEBUG - 2022-07-01 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:32:35 --> Total execution time: 0.0415
DEBUG - 2022-07-01 09:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:32:42 --> Total execution time: 0.0530
DEBUG - 2022-07-01 09:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:32:51 --> Total execution time: 0.0498
DEBUG - 2022-07-01 09:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:32:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:32:52 --> Total execution time: 0.0464
DEBUG - 2022-07-01 09:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:33:05 --> Total execution time: 0.0485
DEBUG - 2022-07-01 09:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:33:15 --> Total execution time: 0.0556
DEBUG - 2022-07-01 09:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:34:40 --> Total execution time: 0.0577
DEBUG - 2022-07-01 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:35:21 --> Total execution time: 0.0497
DEBUG - 2022-07-01 09:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:35:26 --> Total execution time: 0.0512
DEBUG - 2022-07-01 09:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:35:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:35:27 --> Total execution time: 0.0455
DEBUG - 2022-07-01 09:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:35:52 --> Total execution time: 0.0502
DEBUG - 2022-07-01 09:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:06:45 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:36:45 --> Total execution time: 0.0377
DEBUG - 2022-07-01 09:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:06:45 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:36:45 --> Total execution time: 0.0391
DEBUG - 2022-07-01 09:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:06:54 --> 404 Page Not Found: Category/health
DEBUG - 2022-07-01 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:37:01 --> Total execution time: 0.0540
DEBUG - 2022-07-01 09:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:37:07 --> Total execution time: 0.0566
DEBUG - 2022-07-01 09:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:37:19 --> Total execution time: 0.1327
DEBUG - 2022-07-01 09:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:07:33 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 09:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:38:05 --> Total execution time: 0.0316
DEBUG - 2022-07-01 09:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:09:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:09:07 --> 404 Page Not Found: Category/culture
DEBUG - 2022-07-01 09:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:11:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:11:55 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-01 09:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:11:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:11:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 09:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:13:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:13:12 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 09:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:13:18 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-01 09:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:43:38 --> Total execution time: 0.2433
DEBUG - 2022-07-01 09:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:43:46 --> Total execution time: 0.1283
DEBUG - 2022-07-01 09:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:43:50 --> Total execution time: 0.1177
DEBUG - 2022-07-01 09:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:43:58 --> Total execution time: 0.1095
DEBUG - 2022-07-01 09:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:44:02 --> Total execution time: 0.2797
DEBUG - 2022-07-01 09:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:44:47 --> Total execution time: 0.3642
DEBUG - 2022-07-01 09:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:44:53 --> Total execution time: 0.2527
DEBUG - 2022-07-01 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:45:06 --> Total execution time: 0.0998
DEBUG - 2022-07-01 09:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:45:10 --> Total execution time: 0.1258
DEBUG - 2022-07-01 09:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:45:14 --> Total execution time: 0.2039
DEBUG - 2022-07-01 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:45:28 --> Total execution time: 0.0561
DEBUG - 2022-07-01 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:45:28 --> Total execution time: 0.0860
DEBUG - 2022-07-01 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:45:28 --> Total execution time: 0.0580
DEBUG - 2022-07-01 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:45:28 --> Total execution time: 0.1316
DEBUG - 2022-07-01 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:45:28 --> Total execution time: 0.1339
DEBUG - 2022-07-01 09:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:16:35 --> Total execution time: 0.0447
DEBUG - 2022-07-01 09:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:16:36 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-07-01 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:16:37 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-07-01 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:16:37 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-07-01 09:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:16:38 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-01 09:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:48:34 --> Total execution time: 0.0812
DEBUG - 2022-07-01 09:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:49:23 --> Total execution time: 0.1217
DEBUG - 2022-07-01 09:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:49:46 --> Total execution time: 0.0556
DEBUG - 2022-07-01 09:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:49:50 --> Total execution time: 0.0923
DEBUG - 2022-07-01 09:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:50:07 --> Total execution time: 0.0968
DEBUG - 2022-07-01 09:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:50:17 --> Total execution time: 0.0983
DEBUG - 2022-07-01 09:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:50:29 --> Total execution time: 0.1633
DEBUG - 2022-07-01 09:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:20:39 --> Total execution time: 0.1510
DEBUG - 2022-07-01 09:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:50:46 --> Total execution time: 0.1434
DEBUG - 2022-07-01 09:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:20:50 --> Total execution time: 0.0848
DEBUG - 2022-07-01 09:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:20:54 --> Total execution time: 0.0824
DEBUG - 2022-07-01 09:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:50:54 --> Total execution time: 0.1172
DEBUG - 2022-07-01 09:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:50:58 --> Total execution time: 0.1020
DEBUG - 2022-07-01 09:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:51:00 --> Total execution time: 0.2920
DEBUG - 2022-07-01 09:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:51:04 --> Total execution time: 0.0980
DEBUG - 2022-07-01 09:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:51:05 --> Total execution time: 0.1959
DEBUG - 2022-07-01 09:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:53:54 --> Total execution time: 0.3120
DEBUG - 2022-07-01 09:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:54:01 --> Total execution time: 0.4155
DEBUG - 2022-07-01 09:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:54:25 --> Total execution time: 0.1972
DEBUG - 2022-07-01 09:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:25:17 --> 404 Page Not Found: Category/reviews
DEBUG - 2022-07-01 09:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:26:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:56:34 --> Total execution time: 0.1230
DEBUG - 2022-07-01 09:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:56:55 --> Total execution time: 0.0872
DEBUG - 2022-07-01 09:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:57:03 --> Total execution time: 0.2111
DEBUG - 2022-07-01 09:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:57:05 --> Total execution time: 0.2311
DEBUG - 2022-07-01 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:57:08 --> Total execution time: 0.1997
DEBUG - 2022-07-01 09:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:57:18 --> Total execution time: 0.0916
DEBUG - 2022-07-01 09:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:57:24 --> Total execution time: 0.1688
DEBUG - 2022-07-01 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:27:29 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:57:29 --> Total execution time: 0.0717
DEBUG - 2022-07-01 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:27:29 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:57:29 --> Total execution time: 0.0502
DEBUG - 2022-07-01 09:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:57:38 --> Total execution time: 0.0710
DEBUG - 2022-07-01 09:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:14 --> Total execution time: 0.3056
DEBUG - 2022-07-01 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:17 --> Total execution time: 0.0738
DEBUG - 2022-07-01 09:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:26 --> Total execution time: 0.0784
DEBUG - 2022-07-01 09:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:28 --> Total execution time: 0.0763
DEBUG - 2022-07-01 09:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:36 --> Total execution time: 0.1420
DEBUG - 2022-07-01 09:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:42 --> Total execution time: 0.0858
DEBUG - 2022-07-01 09:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:45 --> Total execution time: 0.0649
DEBUG - 2022-07-01 09:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 19:58:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 19:58:46 --> Total execution time: 0.2119
DEBUG - 2022-07-01 09:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:51 --> Total execution time: 0.0727
DEBUG - 2022-07-01 09:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:56 --> Total execution time: 0.0462
DEBUG - 2022-07-01 09:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 09:28:58 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 09:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:59:26 --> Total execution time: 0.2019
DEBUG - 2022-07-01 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:00:08 --> Total execution time: 0.2804
DEBUG - 2022-07-01 09:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:00:27 --> Total execution time: 0.1156
DEBUG - 2022-07-01 09:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:30:40 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:00:40 --> Total execution time: 0.0555
DEBUG - 2022-07-01 09:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:31:50 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:01:50 --> Total execution time: 0.0596
DEBUG - 2022-07-01 09:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:01:50 --> Total execution time: 0.1396
DEBUG - 2022-07-01 09:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:01:55 --> Total execution time: 0.0632
DEBUG - 2022-07-01 09:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:02:01 --> Total execution time: 0.1158
DEBUG - 2022-07-01 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:02:07 --> Total execution time: 0.0534
DEBUG - 2022-07-01 09:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:32:09 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:02:09 --> Total execution time: 0.0829
DEBUG - 2022-07-01 09:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:33:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:03:48 --> Total execution time: 0.0552
DEBUG - 2022-07-01 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:34:21 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:04:21 --> Total execution time: 0.1402
DEBUG - 2022-07-01 09:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:04:27 --> Total execution time: 0.0589
DEBUG - 2022-07-01 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:04:29 --> Total execution time: 0.0475
DEBUG - 2022-07-01 09:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:12:33 --> Total execution time: 0.1272
DEBUG - 2022-07-01 09:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:43:38 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:13:38 --> Total execution time: 0.0515
DEBUG - 2022-07-01 09:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:13:47 --> Total execution time: 0.0481
DEBUG - 2022-07-01 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:13:50 --> Total execution time: 0.0549
DEBUG - 2022-07-01 09:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:14:04 --> Total execution time: 0.0999
DEBUG - 2022-07-01 09:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:14:08 --> Total execution time: 0.0781
DEBUG - 2022-07-01 09:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:14:15 --> Total execution time: 0.0874
DEBUG - 2022-07-01 09:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:22 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:22 --> Total execution time: 0.0400
DEBUG - 2022-07-01 09:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:23 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:23 --> Total execution time: 0.0361
DEBUG - 2022-07-01 09:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:33 --> Total execution time: 0.0561
DEBUG - 2022-07-01 09:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:42 --> Total execution time: 0.0644
DEBUG - 2022-07-01 09:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:49 --> Total execution time: 0.0666
DEBUG - 2022-07-01 09:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:52 --> Total execution time: 0.0704
DEBUG - 2022-07-01 09:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:57 --> Total execution time: 0.0777
DEBUG - 2022-07-01 09:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:59 --> Total execution time: 0.0678
DEBUG - 2022-07-01 09:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:17:32 --> Total execution time: 0.0685
DEBUG - 2022-07-01 09:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:17:36 --> Total execution time: 0.0576
DEBUG - 2022-07-01 09:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:17:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:17:37 --> Total execution time: 0.0551
DEBUG - 2022-07-01 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:48:23 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:18:23 --> Total execution time: 0.0430
DEBUG - 2022-07-01 09:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:19:30 --> Total execution time: 0.0527
DEBUG - 2022-07-01 09:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:19:38 --> Total execution time: 0.0567
DEBUG - 2022-07-01 09:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:19:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:19:39 --> Total execution time: 0.0434
DEBUG - 2022-07-01 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:19:51 --> Total execution time: 0.0526
DEBUG - 2022-07-01 09:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:20:18 --> Total execution time: 0.0622
DEBUG - 2022-07-01 09:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:20:22 --> Total execution time: 0.0491
DEBUG - 2022-07-01 09:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:20:33 --> Total execution time: 0.0673
DEBUG - 2022-07-01 09:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:23:52 --> Total execution time: 0.0442
DEBUG - 2022-07-01 09:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:23:57 --> Total execution time: 0.0627
DEBUG - 2022-07-01 09:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:27:35 --> Total execution time: 0.0466
DEBUG - 2022-07-01 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:27:45 --> Total execution time: 0.0328
DEBUG - 2022-07-01 09:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:08 --> Total execution time: 0.0475
DEBUG - 2022-07-01 09:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:13 --> Total execution time: 0.0536
DEBUG - 2022-07-01 09:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:13 --> Total execution time: 0.0470
DEBUG - 2022-07-01 09:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:14 --> Total execution time: 0.0752
DEBUG - 2022-07-01 09:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:14 --> Total execution time: 0.0456
DEBUG - 2022-07-01 09:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:15 --> Total execution time: 0.0518
DEBUG - 2022-07-01 09:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:15 --> Total execution time: 0.1233
DEBUG - 2022-07-01 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:17 --> Total execution time: 0.0551
DEBUG - 2022-07-01 09:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:18 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:18 --> Total execution time: 0.1199
DEBUG - 2022-07-01 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:27 --> Total execution time: 0.0887
DEBUG - 2022-07-01 09:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 09:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:33 --> Total execution time: 0.0488
DEBUG - 2022-07-01 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:40 --> Total execution time: 0.0506
DEBUG - 2022-07-01 09:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:42 --> Total execution time: 0.0468
DEBUG - 2022-07-01 09:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:44 --> Total execution time: 0.0490
DEBUG - 2022-07-01 09:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:48 --> Total execution time: 0.0735
DEBUG - 2022-07-01 09:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:53 --> Total execution time: 0.0543
DEBUG - 2022-07-01 09:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:28:56 --> Total execution time: 0.0500
DEBUG - 2022-07-01 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:03 --> Total execution time: 0.0595
DEBUG - 2022-07-01 09:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 09:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:06 --> Total execution time: 0.1073
DEBUG - 2022-07-01 09:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:15 --> Total execution time: 0.0450
DEBUG - 2022-07-01 09:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:25 --> Total execution time: 0.0747
DEBUG - 2022-07-01 09:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:31 --> Total execution time: 0.0497
DEBUG - 2022-07-01 09:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:51 --> Total execution time: 0.0581
DEBUG - 2022-07-01 09:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:51 --> Total execution time: 0.0515
DEBUG - 2022-07-01 09:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 09:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 09:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:29:52 --> Total execution time: 0.0630
DEBUG - 2022-07-01 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:30:02 --> Total execution time: 0.0425
DEBUG - 2022-07-01 10:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:00:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:30:36 --> Total execution time: 0.0328
DEBUG - 2022-07-01 10:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:31:04 --> Total execution time: 0.0547
DEBUG - 2022-07-01 10:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:31:15 --> Total execution time: 0.0489
DEBUG - 2022-07-01 10:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:31:17 --> Total execution time: 0.0635
DEBUG - 2022-07-01 10:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:31:18 --> Total execution time: 0.0529
DEBUG - 2022-07-01 10:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:19 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:31:19 --> Total execution time: 0.0625
DEBUG - 2022-07-01 10:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:29 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:31:29 --> Total execution time: 0.0409
DEBUG - 2022-07-01 10:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:01:31 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-01 10:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:01:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 10:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:31:39 --> Total execution time: 0.0448
DEBUG - 2022-07-01 10:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:31:42 --> Total execution time: 0.0445
DEBUG - 2022-07-01 10:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:02:31 --> 404 Page Not Found: List_teacher/index
DEBUG - 2022-07-01 10:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:03 --> Total execution time: 0.0495
DEBUG - 2022-07-01 10:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:19 --> Total execution time: 0.0465
DEBUG - 2022-07-01 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:26 --> Total execution time: 0.0479
DEBUG - 2022-07-01 10:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:27 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:27 --> Total execution time: 0.0478
DEBUG - 2022-07-01 10:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:31 --> Total execution time: 0.0558
DEBUG - 2022-07-01 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:38 --> Total execution time: 0.0842
DEBUG - 2022-07-01 10:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:40 --> Total execution time: 0.0712
DEBUG - 2022-07-01 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:42 --> Total execution time: 0.0594
DEBUG - 2022-07-01 10:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:48 --> Total execution time: 0.0612
DEBUG - 2022-07-01 10:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:51 --> Total execution time: 0.0935
DEBUG - 2022-07-01 10:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:34:04 --> Total execution time: 0.0534
DEBUG - 2022-07-01 10:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:34:46 --> Total execution time: 0.0443
DEBUG - 2022-07-01 10:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:35:14 --> Total execution time: 0.0445
DEBUG - 2022-07-01 10:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:05:32 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:35:32 --> Total execution time: 0.0372
DEBUG - 2022-07-01 10:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:08:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:38:47 --> Total execution time: 0.1108
DEBUG - 2022-07-01 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:38:52 --> Total execution time: 0.0422
DEBUG - 2022-07-01 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:38:53 --> Total execution time: 0.1225
DEBUG - 2022-07-01 10:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:08:56 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:38:56 --> Total execution time: 0.0477
DEBUG - 2022-07-01 10:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:39:12 --> Total execution time: 0.0620
DEBUG - 2022-07-01 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:39:24 --> Total execution time: 0.0944
DEBUG - 2022-07-01 10:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:39:29 --> Total execution time: 0.0768
DEBUG - 2022-07-01 10:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:09:31 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:39:31 --> Total execution time: 0.0328
DEBUG - 2022-07-01 10:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:39:32 --> Total execution time: 0.0458
DEBUG - 2022-07-01 10:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:39:39 --> Total execution time: 0.0487
DEBUG - 2022-07-01 10:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:39:44 --> Total execution time: 0.0558
DEBUG - 2022-07-01 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:40:12 --> Total execution time: 0.1063
DEBUG - 2022-07-01 10:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:10:34 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:40:34 --> Total execution time: 0.0729
DEBUG - 2022-07-01 10:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:40:37 --> Total execution time: 0.0366
DEBUG - 2022-07-01 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:41:00 --> Total execution time: 0.0487
DEBUG - 2022-07-01 10:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:41:09 --> Total execution time: 0.0521
DEBUG - 2022-07-01 10:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:41:14 --> Total execution time: 0.0734
DEBUG - 2022-07-01 10:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:41:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 10:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:41:15 --> Total execution time: 0.0564
DEBUG - 2022-07-01 10:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:08 --> Total execution time: 0.0470
DEBUG - 2022-07-01 10:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:24 --> Total execution time: 0.0614
DEBUG - 2022-07-01 10:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:28 --> Total execution time: 0.0522
DEBUG - 2022-07-01 10:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:28 --> Total execution time: 0.0577
DEBUG - 2022-07-01 10:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:33 --> Total execution time: 0.1186
DEBUG - 2022-07-01 10:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:37 --> Total execution time: 0.0423
DEBUG - 2022-07-01 10:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:40 --> Total execution time: 0.1238
DEBUG - 2022-07-01 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:40 --> Total execution time: 0.0428
DEBUG - 2022-07-01 10:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:45 --> Total execution time: 0.0719
DEBUG - 2022-07-01 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:46 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:46 --> Total execution time: 0.0533
DEBUG - 2022-07-01 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:47 --> Total execution time: 0.0465
DEBUG - 2022-07-01 10:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:48 --> Total execution time: 0.0435
DEBUG - 2022-07-01 10:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:53 --> Total execution time: 0.0526
DEBUG - 2022-07-01 10:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:53 --> Total execution time: 0.0883
DEBUG - 2022-07-01 10:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:56 --> Total execution time: 0.0682
DEBUG - 2022-07-01 10:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:42:59 --> Total execution time: 0.0473
DEBUG - 2022-07-01 10:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:07 --> Total execution time: 0.0807
DEBUG - 2022-07-01 10:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:10 --> Total execution time: 0.0535
DEBUG - 2022-07-01 10:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:14 --> Total execution time: 0.0921
DEBUG - 2022-07-01 10:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:18 --> Total execution time: 0.0842
DEBUG - 2022-07-01 10:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:18 --> Total execution time: 0.1330
DEBUG - 2022-07-01 10:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:24 --> Total execution time: 0.0565
DEBUG - 2022-07-01 10:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:26 --> Total execution time: 0.0675
DEBUG - 2022-07-01 10:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:32 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:32 --> Total execution time: 0.0377
DEBUG - 2022-07-01 10:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:55 --> Total execution time: 0.0497
DEBUG - 2022-07-01 10:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:43:58 --> Total execution time: 0.0540
DEBUG - 2022-07-01 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:44:02 --> Total execution time: 0.0915
DEBUG - 2022-07-01 10:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:44:03 --> Total execution time: 0.0463
DEBUG - 2022-07-01 10:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:44:06 --> Total execution time: 0.0495
DEBUG - 2022-07-01 10:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:44:11 --> Total execution time: 0.0528
DEBUG - 2022-07-01 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:45:19 --> Total execution time: 0.0614
DEBUG - 2022-07-01 10:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:46:53 --> Total execution time: 0.2181
DEBUG - 2022-07-01 10:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:47:02 --> Total execution time: 0.0749
DEBUG - 2022-07-01 10:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:47:04 --> Total execution time: 0.0681
DEBUG - 2022-07-01 10:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:47:46 --> Total execution time: 0.1256
DEBUG - 2022-07-01 10:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:48:02 --> Total execution time: 0.0661
DEBUG - 2022-07-01 10:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:18:17 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:48:17 --> Total execution time: 0.0338
DEBUG - 2022-07-01 10:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:48:28 --> Total execution time: 0.0486
DEBUG - 2022-07-01 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:18:36 --> Total execution time: 0.0489
DEBUG - 2022-07-01 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:18:38 --> Total execution time: 0.0487
DEBUG - 2022-07-01 10:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:18:38 --> Total execution time: 0.1072
DEBUG - 2022-07-01 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:49:35 --> Total execution time: 0.0516
DEBUG - 2022-07-01 10:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:49:45 --> Total execution time: 0.0462
DEBUG - 2022-07-01 10:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:19:46 --> Total execution time: 0.0471
DEBUG - 2022-07-01 10:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:19:47 --> Total execution time: 0.0630
DEBUG - 2022-07-01 10:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:19:47 --> Total execution time: 0.1064
DEBUG - 2022-07-01 10:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:49:49 --> Total execution time: 0.0486
DEBUG - 2022-07-01 10:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:50:12 --> Total execution time: 0.1220
DEBUG - 2022-07-01 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:20:47 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 10:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:23:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 10:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:53:23 --> Total execution time: 0.0521
DEBUG - 2022-07-01 10:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:53:39 --> Total execution time: 0.0465
DEBUG - 2022-07-01 10:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:54:07 --> Total execution time: 0.0448
DEBUG - 2022-07-01 10:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:54:23 --> Total execution time: 0.0458
DEBUG - 2022-07-01 10:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:54:37 --> Total execution time: 0.0520
DEBUG - 2022-07-01 10:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:55:16 --> Total execution time: 0.0500
DEBUG - 2022-07-01 10:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:25:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:25:31 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 10:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:55:43 --> Total execution time: 0.0515
DEBUG - 2022-07-01 10:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:26:19 --> Total execution time: 0.0990
DEBUG - 2022-07-01 10:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:56:22 --> Total execution time: 0.1256
DEBUG - 2022-07-01 10:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:56:31 --> Total execution time: 0.0500
DEBUG - 2022-07-01 10:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:26:31 --> Total execution time: 0.1210
DEBUG - 2022-07-01 10:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:56:34 --> Total execution time: 0.0515
DEBUG - 2022-07-01 10:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:57:44 --> Total execution time: 0.0917
DEBUG - 2022-07-01 10:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:57:48 --> Total execution time: 0.0689
DEBUG - 2022-07-01 10:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:57:55 --> Total execution time: 0.0561
DEBUG - 2022-07-01 10:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:58:13 --> Total execution time: 0.1003
DEBUG - 2022-07-01 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:59:26 --> Total execution time: 0.0761
DEBUG - 2022-07-01 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:00:05 --> Total execution time: 0.0791
DEBUG - 2022-07-01 10:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:30:19 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:00:19 --> Total execution time: 0.0431
DEBUG - 2022-07-01 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:00:45 --> Total execution time: 0.1246
DEBUG - 2022-07-01 10:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:01:02 --> Total execution time: 0.0737
DEBUG - 2022-07-01 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:31:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:31:33 --> 404 Page Not Found: Zbilakntkhdamephp/index
DEBUG - 2022-07-01 10:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:31:35 --> 404 Page Not Found: 0php/index
DEBUG - 2022-07-01 10:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:31:40 --> 404 Page Not Found: 01php/index
DEBUG - 2022-07-01 10:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:31:47 --> 404 Page Not Found: 0bytephp/index
DEBUG - 2022-07-01 10:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:31:51 --> 404 Page Not Found: 1php/index
DEBUG - 2022-07-01 10:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:31:55 --> 404 Page Not Found: 10php/index
DEBUG - 2022-07-01 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:00 --> 404 Page Not Found: 100php/index
DEBUG - 2022-07-01 10:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:06 --> 404 Page Not Found: 11indexphp/index
DEBUG - 2022-07-01 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:07 --> 404 Page Not Found: 13php/index
DEBUG - 2022-07-01 10:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:09 --> 404 Page Not Found: 1337php/index
DEBUG - 2022-07-01 10:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:11 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-07-01 10:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:16 --> 404 Page Not Found: 1xleetphp/index
DEBUG - 2022-07-01 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:17 --> 404 Page Not Found: 2php/index
DEBUG - 2022-07-01 10:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:19 --> 404 Page Not Found: 2indexphp/index
DEBUG - 2022-07-01 10:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:02:20 --> Total execution time: 0.0505
DEBUG - 2022-07-01 10:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:24 --> 404 Page Not Found: 3php/index
DEBUG - 2022-07-01 10:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:34 --> 404 Page Not Found: 3indexphp/index
DEBUG - 2022-07-01 10:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:41 --> 404 Page Not Found: 4php/index
DEBUG - 2022-07-01 10:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:51 --> 404 Page Not Found: 403php/index
DEBUG - 2022-07-01 10:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:53 --> 404 Page Not Found: 404php/index
DEBUG - 2022-07-01 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:57 --> 404 Page Not Found: 4indexphp/index
DEBUG - 2022-07-01 10:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:32:59 --> 404 Page Not Found: 5php/index
DEBUG - 2022-07-01 10:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:06 --> 404 Page Not Found: 5indexphp/index
DEBUG - 2022-07-01 10:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:09 --> 404 Page Not Found: 6indexphp/index
DEBUG - 2022-07-01 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:17 --> 404 Page Not Found: 7php/index
DEBUG - 2022-07-01 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:19 --> 404 Page Not Found: 777php/index
DEBUG - 2022-07-01 10:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:23 --> 404 Page Not Found: 7indexphp/index
DEBUG - 2022-07-01 10:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:26 --> 404 Page Not Found: 8indexphp/index
DEBUG - 2022-07-01 10:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:34 --> 404 Page Not Found: 9php/index
DEBUG - 2022-07-01 10:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:35 --> 404 Page Not Found: 9indexphp/index
DEBUG - 2022-07-01 10:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:39 --> 404 Page Not Found: FoxWSOphp/index
DEBUG - 2022-07-01 10:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:48 --> 404 Page Not Found: Leafphp/index
DEBUG - 2022-07-01 10:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:50 --> 404 Page Not Found: Uploaderphp/index
DEBUG - 2022-07-01 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:56 --> 404 Page Not Found: V5php/index
DEBUG - 2022-07-01 10:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:33:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:33:58 --> 404 Page Not Found: WSOphp/index
DEBUG - 2022-07-01 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:03 --> 404 Page Not Found: Aphp/index
DEBUG - 2022-07-01 10:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:05 --> 404 Page Not Found: Aboutphp/index
DEBUG - 2022-07-01 10:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:08 --> 404 Page Not Found: Alexphp/index
DEBUG - 2022-07-01 10:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:11 --> 404 Page Not Found: Alexusphp/index
DEBUG - 2022-07-01 10:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:16 --> 404 Page Not Found: Alfphp/index
DEBUG - 2022-07-01 10:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:22 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-07-01 10:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:28 --> 404 Page Not Found: Alfashellphp/index
DEBUG - 2022-07-01 10:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:35 --> 404 Page Not Found: Alwsophp/index
DEBUG - 2022-07-01 10:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:44 --> 404 Page Not Found: Amphp/index
DEBUG - 2022-07-01 10:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:50 --> 404 Page Not Found: Autoload_classmapphp/index
DEBUG - 2022-07-01 10:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:34:54 --> 404 Page Not Found: Bphp/index
DEBUG - 2022-07-01 10:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:35:00 --> 404 Page Not Found: Baindexphp/index
DEBUG - 2022-07-01 10:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:35:06 --> 404 Page Not Found: Bbphp/index
DEBUG - 2022-07-01 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:07 --> Total execution time: 0.0375
DEBUG - 2022-07-01 10:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:35:08 --> 404 Page Not Found: Blogphp/index
DEBUG - 2022-07-01 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:35:13 --> 404 Page Not Found: Blog/fw.php
DEBUG - 2022-07-01 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:13 --> Total execution time: 0.0451
DEBUG - 2022-07-01 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:13 --> Total execution time: 0.0360
DEBUG - 2022-07-01 10:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:35:15 --> 404 Page Not Found: Bypassphp/index
DEBUG - 2022-07-01 10:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:35:18 --> 404 Page Not Found: Cphp/index
DEBUG - 2022-07-01 10:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:26 --> Total execution time: 0.0631
DEBUG - 2022-07-01 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:26 --> Total execution time: 0.0554
DEBUG - 2022-07-01 10:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:30 --> Total execution time: 0.0929
DEBUG - 2022-07-01 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:33 --> Total execution time: 0.0492
DEBUG - 2022-07-01 10:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:45 --> Total execution time: 0.0499
DEBUG - 2022-07-01 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:48 --> Total execution time: 0.0597
DEBUG - 2022-07-01 10:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:48 --> Total execution time: 0.0489
DEBUG - 2022-07-01 10:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:51 --> Total execution time: 0.0554
DEBUG - 2022-07-01 10:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:05:59 --> Total execution time: 0.0480
DEBUG - 2022-07-01 10:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:06:11 --> Total execution time: 0.0837
DEBUG - 2022-07-01 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:06:19 --> Total execution time: 0.0851
DEBUG - 2022-07-01 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:06:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:06:55 --> Total execution time: 0.0715
DEBUG - 2022-07-01 10:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:07:37 --> Total execution time: 0.0986
DEBUG - 2022-07-01 10:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:01 --> Total execution time: 0.0832
DEBUG - 2022-07-01 10:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:39 --> Total execution time: 0.0480
DEBUG - 2022-07-01 10:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:11:03 --> Total execution time: 0.1208
DEBUG - 2022-07-01 10:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:13:27 --> Total execution time: 0.2027
DEBUG - 2022-07-01 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:14:40 --> Total execution time: 0.0550
DEBUG - 2022-07-01 10:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:45:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:15:11 --> Total execution time: 0.0578
DEBUG - 2022-07-01 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:45:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:15:12 --> Total execution time: 0.0585
DEBUG - 2022-07-01 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:15:18 --> Total execution time: 0.0368
DEBUG - 2022-07-01 10:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:45:29 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:15:29 --> Total execution time: 0.0562
DEBUG - 2022-07-01 10:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:15:39 --> Total execution time: 0.0354
DEBUG - 2022-07-01 10:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:46:48 --> Total execution time: 0.0602
DEBUG - 2022-07-01 10:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:16:54 --> Total execution time: 0.0521
DEBUG - 2022-07-01 10:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:02 --> Total execution time: 0.0726
DEBUG - 2022-07-01 10:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:04 --> Total execution time: 0.0864
DEBUG - 2022-07-01 10:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:09 --> Total execution time: 0.0584
DEBUG - 2022-07-01 10:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:17 --> Total execution time: 0.0681
DEBUG - 2022-07-01 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:20 --> Total execution time: 0.0884
DEBUG - 2022-07-01 10:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:27 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:27 --> Total execution time: 0.0370
DEBUG - 2022-07-01 10:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:29 --> Total execution time: 0.0933
DEBUG - 2022-07-01 10:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:47:52 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:52 --> Total execution time: 0.0377
DEBUG - 2022-07-01 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:02 --> Total execution time: 0.1852
DEBUG - 2022-07-01 10:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:48:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:03 --> Total execution time: 0.1222
DEBUG - 2022-07-01 10:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:07 --> Total execution time: 0.1448
DEBUG - 2022-07-01 10:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:12 --> Total execution time: 0.1103
DEBUG - 2022-07-01 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:17 --> Total execution time: 0.1077
DEBUG - 2022-07-01 10:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:25 --> Total execution time: 0.1607
DEBUG - 2022-07-01 10:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:47 --> Total execution time: 0.1295
DEBUG - 2022-07-01 10:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:49:24 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 10:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:19:56 --> Total execution time: 0.1474
DEBUG - 2022-07-01 10:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:20:03 --> Total execution time: 0.0437
DEBUG - 2022-07-01 10:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:50:50 --> Total execution time: 0.1286
DEBUG - 2022-07-01 10:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:50:51 --> Total execution time: 0.0497
DEBUG - 2022-07-01 10:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:50:51 --> Total execution time: 0.1062
DEBUG - 2022-07-01 10:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:50:56 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:20:56 --> Total execution time: 0.0472
DEBUG - 2022-07-01 10:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:50:58 --> Total execution time: 0.0493
DEBUG - 2022-07-01 10:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:51:00 --> Total execution time: 0.0583
DEBUG - 2022-07-01 10:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:51:00 --> Total execution time: 0.0877
DEBUG - 2022-07-01 10:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:21:10 --> Total execution time: 0.0564
DEBUG - 2022-07-01 10:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:21:28 --> Total execution time: 0.0602
DEBUG - 2022-07-01 10:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 10:52:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 10:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:22:26 --> Total execution time: 1.5155
DEBUG - 2022-07-01 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:52:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 10:52:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 10:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:25:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 10:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:25:07 --> Total execution time: 0.0565
DEBUG - 2022-07-01 10:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:25:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 21:25:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 21:25:09 --> Total execution time: 0.1883
DEBUG - 2022-07-01 10:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:25:11 --> Total execution time: 0.0599
DEBUG - 2022-07-01 10:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:25:14 --> Total execution time: 0.0667
DEBUG - 2022-07-01 10:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:56:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:26:02 --> Total execution time: 0.1603
DEBUG - 2022-07-01 10:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:26:54 --> Total execution time: 0.0634
DEBUG - 2022-07-01 10:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:57:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:27:03 --> Total execution time: 0.0575
DEBUG - 2022-07-01 10:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 10:58:32 --> No URI present. Default controller set.
DEBUG - 2022-07-01 10:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 10:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:32 --> Total execution time: 0.0537
DEBUG - 2022-07-01 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:30:02 --> Total execution time: 0.0670
DEBUG - 2022-07-01 11:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:02:51 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:32:51 --> Total execution time: 0.1926
DEBUG - 2022-07-01 11:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:32:53 --> Total execution time: 0.1094
DEBUG - 2022-07-01 11:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:32:58 --> Total execution time: 0.0486
DEBUG - 2022-07-01 11:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:04 --> Total execution time: 0.0702
DEBUG - 2022-07-01 11:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:21 --> Total execution time: 0.0491
DEBUG - 2022-07-01 11:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:25 --> Total execution time: 0.0692
DEBUG - 2022-07-01 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:04:34 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:34:34 --> Total execution time: 0.1187
DEBUG - 2022-07-01 11:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:04:58 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:34:58 --> Total execution time: 0.1236
DEBUG - 2022-07-01 11:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:05:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:35:10 --> Total execution time: 0.0358
DEBUG - 2022-07-01 11:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:35:20 --> Total execution time: 0.0494
DEBUG - 2022-07-01 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:35:29 --> Total execution time: 0.0584
DEBUG - 2022-07-01 11:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:35:55 --> Total execution time: 0.0464
DEBUG - 2022-07-01 11:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:36:53 --> Total execution time: 0.0513
DEBUG - 2022-07-01 11:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:07:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:37:03 --> Total execution time: 0.0508
DEBUG - 2022-07-01 11:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:09:32 --> 404 Page Not Found: Category/uncategorized
DEBUG - 2022-07-01 11:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:10:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:40:15 --> Total execution time: 0.1120
DEBUG - 2022-07-01 11:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:10:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:40:15 --> Total execution time: 0.0345
DEBUG - 2022-07-01 11:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:40:28 --> Total execution time: 0.0339
DEBUG - 2022-07-01 11:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:40:40 --> Total execution time: 0.0361
DEBUG - 2022-07-01 11:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:40:54 --> Total execution time: 0.1431
DEBUG - 2022-07-01 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:41:12 --> Total execution time: 0.0662
DEBUG - 2022-07-01 11:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:41:23 --> Total execution time: 0.0481
DEBUG - 2022-07-01 11:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:41:37 --> Total execution time: 0.0603
DEBUG - 2022-07-01 11:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:13:47 --> Total execution time: 0.1001
DEBUG - 2022-07-01 11:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:13:53 --> Total execution time: 0.0711
DEBUG - 2022-07-01 11:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:44:18 --> Total execution time: 0.0506
DEBUG - 2022-07-01 11:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:44:46 --> Total execution time: 0.0502
DEBUG - 2022-07-01 11:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:45:50 --> Total execution time: 0.0610
DEBUG - 2022-07-01 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:46:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:46:51 --> Total execution time: 0.0731
DEBUG - 2022-07-01 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:44 --> Total execution time: 0.0503
DEBUG - 2022-07-01 11:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:52 --> Total execution time: 0.0541
DEBUG - 2022-07-01 11:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:17:58 --> Total execution time: 0.0497
DEBUG - 2022-07-01 11:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:02 --> Total execution time: 0.0875
DEBUG - 2022-07-01 11:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:02 --> Total execution time: 0.0656
DEBUG - 2022-07-01 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:09 --> Total execution time: 0.0787
DEBUG - 2022-07-01 11:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:28 --> Total execution time: 0.0468
DEBUG - 2022-07-01 11:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:38 --> Total execution time: 0.0517
DEBUG - 2022-07-01 11:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:57 --> Total execution time: 0.0561
DEBUG - 2022-07-01 11:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:49:55 --> Total execution time: 0.0478
DEBUG - 2022-07-01 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:06 --> Total execution time: 0.0523
DEBUG - 2022-07-01 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:37 --> Total execution time: 0.0499
DEBUG - 2022-07-01 11:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:44 --> Total execution time: 0.0831
DEBUG - 2022-07-01 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:54 --> Total execution time: 0.1184
DEBUG - 2022-07-01 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:21:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:21:12 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 11:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:51:18 --> Total execution time: 0.0688
DEBUG - 2022-07-01 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:21:24 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:51:27 --> Total execution time: 0.0869
DEBUG - 2022-07-01 11:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:21:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:21:41 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:51:52 --> Total execution time: 0.0538
DEBUG - 2022-07-01 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:21:53 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 11:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:26:41 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:56:41 --> Total execution time: 0.0402
DEBUG - 2022-07-01 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:59:58 --> Total execution time: 0.0400
DEBUG - 2022-07-01 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:30:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:00:02 --> Total execution time: 0.0494
DEBUG - 2022-07-01 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:00:12 --> Total execution time: 0.0391
DEBUG - 2022-07-01 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:00:28 --> Total execution time: 0.0409
DEBUG - 2022-07-01 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:00:46 --> Total execution time: 0.0453
DEBUG - 2022-07-01 11:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:01:07 --> Total execution time: 0.0693
DEBUG - 2022-07-01 11:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:01:11 --> Total execution time: 0.0717
DEBUG - 2022-07-01 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:31:12 --> Total execution time: 0.0414
DEBUG - 2022-07-01 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:31:15 --> Total execution time: 0.0477
DEBUG - 2022-07-01 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:31:15 --> Total execution time: 0.1105
DEBUG - 2022-07-01 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:01:16 --> Total execution time: 0.0422
DEBUG - 2022-07-01 11:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:01:23 --> Total execution time: 0.1387
DEBUG - 2022-07-01 11:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:01:24 --> Total execution time: 0.0438
DEBUG - 2022-07-01 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:01:26 --> Total execution time: 0.0522
DEBUG - 2022-07-01 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:01:32 --> Total execution time: 0.0635
DEBUG - 2022-07-01 11:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:02:52 --> Total execution time: 0.1300
DEBUG - 2022-07-01 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:03:13 --> Total execution time: 0.0613
DEBUG - 2022-07-01 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:03:21 --> Total execution time: 0.0507
DEBUG - 2022-07-01 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:04:32 --> Total execution time: 0.0473
DEBUG - 2022-07-01 11:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:35:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:05:08 --> Total execution time: 0.0340
DEBUG - 2022-07-01 11:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:35:38 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:05:38 --> Total execution time: 0.0365
DEBUG - 2022-07-01 11:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:36:02 --> 404 Page Not Found: Otc/index
DEBUG - 2022-07-01 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:36:03 --> 404 Page Not Found: App/index
DEBUG - 2022-07-01 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:36:03 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-01 11:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:06:12 --> Total execution time: 0.0475
DEBUG - 2022-07-01 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:06:13 --> Total execution time: 0.0494
DEBUG - 2022-07-01 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:06:14 --> Total execution time: 0.0648
DEBUG - 2022-07-01 11:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:06:43 --> Total execution time: 0.0665
DEBUG - 2022-07-01 11:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:06:48 --> Total execution time: 0.1136
DEBUG - 2022-07-01 11:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:06:51 --> Total execution time: 0.0503
DEBUG - 2022-07-01 11:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:36:53 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 11:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:06:53 --> Total execution time: 0.0531
DEBUG - 2022-07-01 11:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:06:57 --> Total execution time: 0.0572
DEBUG - 2022-07-01 11:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:00 --> Total execution time: 0.0609
DEBUG - 2022-07-01 11:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:05 --> Total execution time: 0.0538
DEBUG - 2022-07-01 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:13 --> Total execution time: 0.0735
DEBUG - 2022-07-01 11:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:37:22 --> 404 Page Not Found: Api/notice
DEBUG - 2022-07-01 11:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:23 --> Total execution time: 0.1279
DEBUG - 2022-07-01 11:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:26 --> Total execution time: 0.0482
DEBUG - 2022-07-01 11:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:37:29 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 11:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:36 --> Total execution time: 0.0552
DEBUG - 2022-07-01 11:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:37 --> Total execution time: 0.0829
DEBUG - 2022-07-01 11:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:40 --> Total execution time: 0.1065
DEBUG - 2022-07-01 11:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:47 --> Total execution time: 0.0530
DEBUG - 2022-07-01 11:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:07:51 --> Total execution time: 0.0485
DEBUG - 2022-07-01 11:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:08:08 --> Total execution time: 0.1104
DEBUG - 2022-07-01 11:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:08:15 --> Total execution time: 0.0479
DEBUG - 2022-07-01 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:08:26 --> Total execution time: 0.0819
DEBUG - 2022-07-01 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:08:30 --> Total execution time: 0.0841
DEBUG - 2022-07-01 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:08:31 --> Total execution time: 0.0913
DEBUG - 2022-07-01 11:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:38:32 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:08:32 --> Total execution time: 0.1153
DEBUG - 2022-07-01 11:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:09:06 --> Total execution time: 0.0608
DEBUG - 2022-07-01 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:39:08 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:09:15 --> Total execution time: 0.0466
DEBUG - 2022-07-01 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:39:20 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:09:20 --> Total execution time: 0.1109
DEBUG - 2022-07-01 11:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:39:39 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:09:39 --> Total execution time: 0.0630
DEBUG - 2022-07-01 11:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:09:52 --> Total execution time: 0.0770
DEBUG - 2022-07-01 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:10:02 --> Total execution time: 0.0926
DEBUG - 2022-07-01 11:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:10:09 --> Total execution time: 0.1037
DEBUG - 2022-07-01 11:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:10:20 --> Total execution time: 0.0524
DEBUG - 2022-07-01 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:10:27 --> Total execution time: 0.0493
DEBUG - 2022-07-01 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:10:38 --> Total execution time: 0.0649
DEBUG - 2022-07-01 11:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:10:51 --> Total execution time: 0.0493
DEBUG - 2022-07-01 11:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:11:01 --> Total execution time: 0.0548
DEBUG - 2022-07-01 11:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:41:16 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-01 11:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:11:23 --> Total execution time: 0.0498
DEBUG - 2022-07-01 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:11:24 --> Total execution time: 0.0492
DEBUG - 2022-07-01 11:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:11:26 --> Total execution time: 0.0676
DEBUG - 2022-07-01 11:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:11:39 --> Total execution time: 0.0512
DEBUG - 2022-07-01 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:12:07 --> Total execution time: 0.1122
DEBUG - 2022-07-01 11:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:12:08 --> Total execution time: 0.0485
DEBUG - 2022-07-01 11:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:12:16 --> Total execution time: 0.0523
DEBUG - 2022-07-01 11:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:12:24 --> Total execution time: 0.1433
DEBUG - 2022-07-01 11:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:25 --> Total execution time: 0.0451
DEBUG - 2022-07-01 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:42:34 --> Total execution time: 0.0527
DEBUG - 2022-07-01 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:12:39 --> Total execution time: 0.0598
DEBUG - 2022-07-01 11:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:12:47 --> Total execution time: 0.0730
DEBUG - 2022-07-01 11:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:13:00 --> Total execution time: 0.0613
DEBUG - 2022-07-01 11:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:02 --> Total execution time: 0.0794
DEBUG - 2022-07-01 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:11 --> Total execution time: 0.0467
DEBUG - 2022-07-01 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:43:14 --> Total execution time: 0.0449
DEBUG - 2022-07-01 11:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:13:16 --> Total execution time: 0.0689
DEBUG - 2022-07-01 11:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:49:28 --> 404 Page Not Found: Authorizephp/index
DEBUG - 2022-07-01 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:49:59 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 11:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:50:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:50:54 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 11:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:51:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:51:20 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:22:27 --> Total execution time: 0.1407
DEBUG - 2022-07-01 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:22:55 --> Total execution time: 0.0480
DEBUG - 2022-07-01 11:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:53:08 --> 404 Page Not Found: Wp-content/cache.php
DEBUG - 2022-07-01 11:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:23:12 --> Total execution time: 0.0388
DEBUG - 2022-07-01 11:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:53:18 --> 404 Page Not Found: Toolphp/index
DEBUG - 2022-07-01 11:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:19 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:23:19 --> Total execution time: 0.0506
DEBUG - 2022-07-01 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:23:20 --> Total execution time: 0.0450
DEBUG - 2022-07-01 11:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:23:24 --> Total execution time: 0.0327
DEBUG - 2022-07-01 11:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:27 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:23:27 --> Total execution time: 0.0526
DEBUG - 2022-07-01 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:23:34 --> Total execution time: 0.0449
DEBUG - 2022-07-01 11:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:53:58 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:23:58 --> Total execution time: 0.0347
DEBUG - 2022-07-01 11:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 11:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:24:03 --> Total execution time: 0.0626
DEBUG - 2022-07-01 11:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:24:11 --> Total execution time: 0.0722
DEBUG - 2022-07-01 11:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:24:18 --> Total execution time: 0.0796
DEBUG - 2022-07-01 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:54:22 --> 404 Page Not Found: Wp-admin/include.php
DEBUG - 2022-07-01 11:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:30 --> Total execution time: 0.1523
DEBUG - 2022-07-01 11:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:54 --> Total execution time: 0.0713
DEBUG - 2022-07-01 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:56:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:56:55 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 11:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:57 --> Total execution time: 0.0988
DEBUG - 2022-07-01 11:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:57:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:57:07 --> 404 Page Not Found: Category/world
DEBUG - 2022-07-01 11:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:27:15 --> Total execution time: 0.0467
DEBUG - 2022-07-01 11:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:57:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:57:33 --> 404 Page Not Found: Wp-admin/tool.php
DEBUG - 2022-07-01 11:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:58:02 --> 404 Page Not Found: Wp-content/app.php
DEBUG - 2022-07-01 11:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:58:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:58:16 --> 404 Page Not Found: Assets/global
DEBUG - 2022-07-01 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:59:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 11:59:42 --> 404 Page Not Found: Wp-blockupphp/index
DEBUG - 2022-07-01 11:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 11:59:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 11:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 11:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:29:48 --> Total execution time: 0.0383
DEBUG - 2022-07-01 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:30:03 --> Total execution time: 0.0774
DEBUG - 2022-07-01 12:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:00:22 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:30:22 --> Total execution time: 0.0432
DEBUG - 2022-07-01 12:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:02:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 12:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:05:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:05:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 12:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:35:29 --> Total execution time: 0.1589
DEBUG - 2022-07-01 12:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:06:34 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:07:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:07:18 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 12:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:10:47 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:42:21 --> Total execution time: 0.2269
DEBUG - 2022-07-01 12:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:42:24 --> Total execution time: 0.0730
DEBUG - 2022-07-01 12:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:42:28 --> Total execution time: 0.0539
DEBUG - 2022-07-01 12:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:05 --> Total execution time: 0.0557
DEBUG - 2022-07-01 12:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:08 --> Total execution time: 0.0507
DEBUG - 2022-07-01 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:24 --> Total execution time: 0.0631
DEBUG - 2022-07-01 12:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:48 --> Total execution time: 0.0591
DEBUG - 2022-07-01 12:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:48 --> Total execution time: 0.0280
DEBUG - 2022-07-01 12:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:50 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:50 --> Total execution time: 0.0347
DEBUG - 2022-07-01 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:53 --> Total execution time: 0.0346
DEBUG - 2022-07-01 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:53 --> Total execution time: 0.0344
DEBUG - 2022-07-01 12:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:54 --> Total execution time: 0.0450
DEBUG - 2022-07-01 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:55 --> Total execution time: 0.0251
DEBUG - 2022-07-01 12:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:48:03 --> Total execution time: 0.1323
DEBUG - 2022-07-01 12:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:18:36 --> 404 Page Not Found: Category/news
DEBUG - 2022-07-01 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:48:44 --> Total execution time: 0.1210
DEBUG - 2022-07-01 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:50:06 --> Total execution time: 0.0552
DEBUG - 2022-07-01 12:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:50:09 --> Total execution time: 0.0506
DEBUG - 2022-07-01 12:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:50:12 --> Total execution time: 0.0557
DEBUG - 2022-07-01 12:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:50:23 --> Total execution time: 0.0579
DEBUG - 2022-07-01 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:50:26 --> Total execution time: 0.0643
DEBUG - 2022-07-01 12:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:50:33 --> Total execution time: 0.0509
DEBUG - 2022-07-01 12:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:21:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:51:30 --> Total execution time: 0.0371
DEBUG - 2022-07-01 12:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:21:58 --> 404 Page Not Found: News/feed
DEBUG - 2022-07-01 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:52:13 --> Total execution time: 0.0503
DEBUG - 2022-07-01 12:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:22:18 --> Total execution time: 0.0466
DEBUG - 2022-07-01 12:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:22:20 --> Total execution time: 0.0762
DEBUG - 2022-07-01 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:22:20 --> Total execution time: 0.0585
DEBUG - 2022-07-01 12:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:22:38 --> Total execution time: 0.0450
DEBUG - 2022-07-01 12:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:23:23 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:53:23 --> Total execution time: 0.0459
DEBUG - 2022-07-01 12:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:53:27 --> Total execution time: 0.0393
DEBUG - 2022-07-01 12:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:53:38 --> Total execution time: 0.0583
DEBUG - 2022-07-01 12:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:53:45 --> Total execution time: 0.0533
DEBUG - 2022-07-01 12:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:53:55 --> Total execution time: 0.0518
DEBUG - 2022-07-01 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:24:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:54:26 --> Total execution time: 1.5075
DEBUG - 2022-07-01 12:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:54:26 --> Total execution time: 1.1450
DEBUG - 2022-07-01 12:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:54:26 --> Total execution time: 0.0471
DEBUG - 2022-07-01 12:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:54:43 --> Total execution time: 0.0523
DEBUG - 2022-07-01 12:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:55:30 --> Total execution time: 0.0649
DEBUG - 2022-07-01 12:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:55:32 --> Total execution time: 0.0463
DEBUG - 2022-07-01 12:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:55:34 --> Total execution time: 0.0509
DEBUG - 2022-07-01 12:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:55:37 --> Total execution time: 0.0507
DEBUG - 2022-07-01 12:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:25:38 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:55:38 --> Total execution time: 0.0487
DEBUG - 2022-07-01 12:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:56:47 --> Total execution time: 0.0707
DEBUG - 2022-07-01 12:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:57:02 --> Total execution time: 0.0306
DEBUG - 2022-07-01 12:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:27:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:57:03 --> Total execution time: 0.0408
DEBUG - 2022-07-01 12:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:27:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:57:37 --> Total execution time: 0.0474
DEBUG - 2022-07-01 12:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:57:57 --> Total execution time: 0.1244
DEBUG - 2022-07-01 12:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:00 --> Total execution time: 0.0595
DEBUG - 2022-07-01 12:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:11 --> Total execution time: 0.0536
DEBUG - 2022-07-01 12:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:28:49 --> 404 Page Not Found: Appphp/feed
DEBUG - 2022-07-01 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:00:43 --> Total execution time: 0.0534
DEBUG - 2022-07-01 12:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:00:46 --> Total execution time: 0.0618
DEBUG - 2022-07-01 12:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:00:54 --> Total execution time: 0.0488
DEBUG - 2022-07-01 12:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:31:26 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 12:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:03:55 --> Total execution time: 0.1115
DEBUG - 2022-07-01 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:34:55 --> 404 Page Not Found: Wp-includes/ID3
DEBUG - 2022-07-01 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:34:55 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:37:28 --> 404 Page Not Found: Blog/feed
DEBUG - 2022-07-01 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:08:52 --> Total execution time: 0.0997
DEBUG - 2022-07-01 12:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:13:14 --> Total execution time: 0.0846
DEBUG - 2022-07-01 12:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 12:43:17 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-01 12:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:14:23 --> Total execution time: 0.1417
DEBUG - 2022-07-01 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:14:43 --> Total execution time: 0.0621
DEBUG - 2022-07-01 12:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:14:54 --> Total execution time: 0.0551
DEBUG - 2022-07-01 12:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:05 --> Total execution time: 0.0547
DEBUG - 2022-07-01 12:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:05 --> Total execution time: 0.0644
DEBUG - 2022-07-01 12:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:05 --> Total execution time: 0.0582
DEBUG - 2022-07-01 12:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:05 --> Total execution time: 0.0745
DEBUG - 2022-07-01 12:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:08 --> Total execution time: 0.0530
DEBUG - 2022-07-01 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:09 --> Total execution time: 0.0522
DEBUG - 2022-07-01 12:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:12 --> Total execution time: 0.0802
DEBUG - 2022-07-01 12:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:24 --> Total execution time: 0.0510
DEBUG - 2022-07-01 12:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:24 --> Total execution time: 0.0540
DEBUG - 2022-07-01 12:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:26 --> Total execution time: 0.0655
DEBUG - 2022-07-01 12:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:30 --> Total execution time: 0.0577
DEBUG - 2022-07-01 12:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:42 --> Total execution time: 0.0463
DEBUG - 2022-07-01 12:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:49 --> Total execution time: 0.0498
DEBUG - 2022-07-01 12:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:05 --> Total execution time: 0.0478
DEBUG - 2022-07-01 12:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:14 --> Total execution time: 0.1213
DEBUG - 2022-07-01 12:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:26 --> Total execution time: 0.0444
DEBUG - 2022-07-01 12:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:39 --> Total execution time: 0.0445
DEBUG - 2022-07-01 12:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:51 --> Total execution time: 0.0454
DEBUG - 2022-07-01 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:00 --> Total execution time: 0.0617
DEBUG - 2022-07-01 12:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:04 --> Total execution time: 0.0611
DEBUG - 2022-07-01 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:09 --> Total execution time: 0.0676
DEBUG - 2022-07-01 12:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:22 --> Total execution time: 0.0564
DEBUG - 2022-07-01 12:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:23 --> Total execution time: 0.0561
DEBUG - 2022-07-01 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:25 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:25 --> Total execution time: 0.0446
DEBUG - 2022-07-01 12:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:32 --> Total execution time: 0.0486
DEBUG - 2022-07-01 12:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:32 --> Total execution time: 0.0656
DEBUG - 2022-07-01 12:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:32 --> Total execution time: 0.0872
DEBUG - 2022-07-01 12:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:17:36 --> Total execution time: 0.0506
DEBUG - 2022-07-01 12:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:48:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:18:02 --> Total execution time: 0.0327
DEBUG - 2022-07-01 12:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:22:19 --> Total execution time: 0.0594
DEBUG - 2022-07-01 12:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:25:12 --> Total execution time: 0.1954
DEBUG - 2022-07-01 12:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:25:23 --> Total execution time: 0.0507
DEBUG - 2022-07-01 12:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:25:45 --> Total execution time: 0.0315
DEBUG - 2022-07-01 12:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:26:38 --> Total execution time: 0.0540
DEBUG - 2022-07-01 12:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:26:44 --> Total execution time: 0.0523
DEBUG - 2022-07-01 12:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:59:18 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:29:18 --> Total execution time: 0.1414
DEBUG - 2022-07-01 12:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 12:59:45 --> No URI present. Default controller set.
DEBUG - 2022-07-01 12:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 12:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:29:45 --> Total execution time: 0.0570
DEBUG - 2022-07-01 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:30:02 --> Total execution time: 0.0419
DEBUG - 2022-07-01 13:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:31:36 --> Total execution time: 0.0389
DEBUG - 2022-07-01 13:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:31:38 --> Total execution time: 0.0471
DEBUG - 2022-07-01 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:32:44 --> Total execution time: 0.0541
DEBUG - 2022-07-01 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:10 --> Total execution time: 0.0496
DEBUG - 2022-07-01 13:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:07:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 13:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:37:35 --> Total execution time: 0.1025
DEBUG - 2022-07-01 13:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:37:43 --> Total execution time: 0.0510
DEBUG - 2022-07-01 13:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:07 --> Total execution time: 0.0386
DEBUG - 2022-07-01 13:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:13 --> Total execution time: 0.0964
DEBUG - 2022-07-01 13:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 13:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:14 --> Total execution time: 0.0421
DEBUG - 2022-07-01 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:39 --> Total execution time: 0.0806
DEBUG - 2022-07-01 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:40 --> Total execution time: 0.0501
DEBUG - 2022-07-01 13:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:42 --> Total execution time: 0.0516
DEBUG - 2022-07-01 13:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:43 --> Total execution time: 0.0586
DEBUG - 2022-07-01 13:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:45 --> Total execution time: 0.0437
DEBUG - 2022-07-01 13:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:49 --> Total execution time: 0.0550
DEBUG - 2022-07-01 13:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:39:11 --> Total execution time: 0.0452
DEBUG - 2022-07-01 13:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:39:17 --> Total execution time: 0.0468
DEBUG - 2022-07-01 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:39:33 --> Total execution time: 0.0829
DEBUG - 2022-07-01 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:39:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 13:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:39:34 --> Total execution time: 0.0499
DEBUG - 2022-07-01 13:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:39:54 --> Total execution time: 0.0530
DEBUG - 2022-07-01 13:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:39:56 --> Total execution time: 0.0511
DEBUG - 2022-07-01 13:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:04 --> Total execution time: 0.0511
DEBUG - 2022-07-01 13:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:07 --> Total execution time: 0.0444
DEBUG - 2022-07-01 13:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 13:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:14 --> Total execution time: 0.0505
DEBUG - 2022-07-01 13:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:17 --> Total execution time: 0.0486
DEBUG - 2022-07-01 13:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:28 --> Total execution time: 0.0584
DEBUG - 2022-07-01 13:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:31 --> Total execution time: 0.0674
DEBUG - 2022-07-01 13:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:33 --> Total execution time: 0.0595
DEBUG - 2022-07-01 13:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:35 --> Total execution time: 0.0434
DEBUG - 2022-07-01 13:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:39 --> Total execution time: 0.0584
DEBUG - 2022-07-01 13:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:40:54 --> Total execution time: 0.1395
DEBUG - 2022-07-01 13:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:42:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 13:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:42:18 --> Total execution time: 0.0969
DEBUG - 2022-07-01 13:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:42:36 --> Total execution time: 0.1132
DEBUG - 2022-07-01 13:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:43:03 --> Total execution time: 0.0828
DEBUG - 2022-07-01 13:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:43:18 --> Total execution time: 0.0697
DEBUG - 2022-07-01 13:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:13:59 --> No URI present. Default controller set.
DEBUG - 2022-07-01 13:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:43:59 --> Total execution time: 0.0340
DEBUG - 2022-07-01 13:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:44:11 --> Total execution time: 0.0514
DEBUG - 2022-07-01 13:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:44:27 --> Total execution time: 0.1256
DEBUG - 2022-07-01 13:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:45:34 --> Total execution time: 0.1224
DEBUG - 2022-07-01 13:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:15:42 --> No URI present. Default controller set.
DEBUG - 2022-07-01 13:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:45:42 --> Total execution time: 0.1281
DEBUG - 2022-07-01 13:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:45:50 --> Total execution time: 0.0615
DEBUG - 2022-07-01 13:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:46:04 --> Total execution time: 0.0534
DEBUG - 2022-07-01 13:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:46:07 --> Total execution time: 0.0592
DEBUG - 2022-07-01 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:46:19 --> Total execution time: 0.0468
DEBUG - 2022-07-01 13:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:46:29 --> Total execution time: 0.0723
DEBUG - 2022-07-01 13:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:17:52 --> 404 Page Not Found: Category/opinion
DEBUG - 2022-07-01 13:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:19:35 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-01 13:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:19:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:19:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 13:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:21:24 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 13:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:21:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:21:27 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 13:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:51:50 --> Total execution time: 0.0529
DEBUG - 2022-07-01 13:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:25:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:25:00 --> 404 Page Not Found: Category/lifestyle
DEBUG - 2022-07-01 13:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:57:00 --> Total execution time: 0.0511
DEBUG - 2022-07-01 13:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:29:26 --> No URI present. Default controller set.
DEBUG - 2022-07-01 13:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:59:26 --> Total execution time: 0.0886
DEBUG - 2022-07-01 13:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:59:31 --> Total execution time: 0.0549
DEBUG - 2022-07-01 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:59:36 --> Total execution time: 0.0303
DEBUG - 2022-07-01 13:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:59:37 --> Total execution time: 0.0433
DEBUG - 2022-07-01 13:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:59:37 --> Total execution time: 0.0315
DEBUG - 2022-07-01 13:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:34:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 13:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:34:51 --> 404 Page Not Found: Category/technology
DEBUG - 2022-07-01 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 13:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:43:30 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 13:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:46:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:46:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 13:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:48:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 13:48:19 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 13:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 13:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 13:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 14:11:40 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 14:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:27:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 14:27:58 --> 404 Page Not Found: Category/features
DEBUG - 2022-07-01 14:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 14:29:58 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 14:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:34:17 --> Total execution time: 0.0494
DEBUG - 2022-07-01 14:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:35:17 --> No URI present. Default controller set.
DEBUG - 2022-07-01 14:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 14:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 14:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 14:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 15:08:31 --> No URI present. Default controller set.
DEBUG - 2022-07-01 15:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 15:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 15:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 15:22:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 15:22:38 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 15:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 15:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 15:25:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 15:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 15:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 15:27:17 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 15:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 15:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 15:50:41 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:01:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:03:50 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 16:04:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 16:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:04:56 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:10:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 16:10:29 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-01 16:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:11:57 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:13:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:13:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 16:13:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 16:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:14:00 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:17:56 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:18:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:32 --> Total execution time: 0.0668
DEBUG - 2022-07-01 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:37 --> Total execution time: 0.0593
DEBUG - 2022-07-01 16:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:18:37 --> Total execution time: 0.1380
DEBUG - 2022-07-01 16:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:23 --> Total execution time: 0.0508
DEBUG - 2022-07-01 16:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:25 --> Total execution time: 0.0461
DEBUG - 2022-07-01 16:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:25 --> Total execution time: 0.0874
DEBUG - 2022-07-01 16:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:21:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:23:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:27:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:13 --> Total execution time: 0.0314
DEBUG - 2022-07-01 16:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:14 --> Total execution time: 0.0596
DEBUG - 2022-07-01 16:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:15 --> Total execution time: 0.1120
DEBUG - 2022-07-01 16:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:50 --> Total execution time: 0.0509
DEBUG - 2022-07-01 16:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:51 --> Total execution time: 0.0563
DEBUG - 2022-07-01 16:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:28:51 --> Total execution time: 0.1085
DEBUG - 2022-07-01 16:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:22 --> Total execution time: 0.0507
DEBUG - 2022-07-01 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:23 --> Total execution time: 0.0600
DEBUG - 2022-07-01 16:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:23 --> Total execution time: 0.0711
DEBUG - 2022-07-01 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:30:34 --> Total execution time: 0.0492
DEBUG - 2022-07-01 16:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:02 --> Total execution time: 0.0332
DEBUG - 2022-07-01 16:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:20 --> Total execution time: 0.0589
DEBUG - 2022-07-01 16:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:20 --> Total execution time: 0.0513
DEBUG - 2022-07-01 16:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 16:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 16:31:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 16:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:27 --> Total execution time: 0.0485
DEBUG - 2022-07-01 16:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:43 --> Total execution time: 0.0448
DEBUG - 2022-07-01 16:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:45 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:32:53 --> Total execution time: 0.0392
DEBUG - 2022-07-01 16:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:07 --> Total execution time: 0.0642
DEBUG - 2022-07-01 16:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:13 --> Total execution time: 0.0445
DEBUG - 2022-07-01 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:34 --> Total execution time: 0.0482
DEBUG - 2022-07-01 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:38 --> Total execution time: 0.0445
DEBUG - 2022-07-01 16:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:39 --> Total execution time: 0.0863
DEBUG - 2022-07-01 16:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:41 --> Total execution time: 0.0534
DEBUG - 2022-07-01 16:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:33:59 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:13 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:34:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 16:35:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 16:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:35:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:36:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:36:37 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:37:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:42:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:45:24 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:47:48 --> No URI present. Default controller set.
DEBUG - 2022-07-01 16:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 16:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 16:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 16:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:01:08 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 17:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:02:44 --> No URI present. Default controller set.
DEBUG - 2022-07-01 17:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 17:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:02:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 17:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 17:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:02:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 17:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:03:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:03:37 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 17:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:05:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 17:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:11:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 17:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 17:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:11:07 --> No URI present. Default controller set.
DEBUG - 2022-07-01 17:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 17:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:11:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:11:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 17:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:29:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 17:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:36:59 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 17:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:37:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:37:44 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 17:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:38:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 17:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 17:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 17:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:49:12 --> 404 Page Not Found: Course-category/development
DEBUG - 2022-07-01 17:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 17:49:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 17:49:30 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-01 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 18:40:13 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 18:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 18:42:41 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 18:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 18:44:42 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 18:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:55:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 18:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 18:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 18:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 18:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:06:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 19:06:13 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 19:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 19:06:16 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-01 19:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 19:08:13 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 19:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:21:50 --> No URI present. Default controller set.
DEBUG - 2022-07-01 19:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:30:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 19:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 19:51:30 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-01 19:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:58:39 --> No URI present. Default controller set.
DEBUG - 2022-07-01 19:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 19:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 19:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 19:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:15:02 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-01 20:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:17:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:17:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 20:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:20:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 20:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:22:24 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 20:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:23:59 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 20:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:23:59 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 20:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:01 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:02 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:03 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:04 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:04 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:05 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:05 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:07 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:07 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:07 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:08 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:10 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:10 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:10 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:11 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:14 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:17 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:20 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:21 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:22 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:22 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:23 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:24 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:25 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:25 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:26 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:27 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:28 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:28 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:29 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-07-01 20:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:30 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:31 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:31 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:33 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:34 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:35 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:37 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:37 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:38 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:38 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:39 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:40 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:40 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:41 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:42 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:43 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:43 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:43 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:46 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:46 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:47 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:49 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:49 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:49 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:49 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:52 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:52 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:55 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:55 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:55 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:58 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:58 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-07-01 20:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:24:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:24:58 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:01 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:01 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:01 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:03 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:04 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:04 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:06 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:07 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:09 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:10 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:10 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:13 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:25:16 --> UTF-8 Support Enabled
ERROR - 2022-07-01 20:25:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:16 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:22 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:22 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:24 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:25 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-01 20:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:27 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:28 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:31 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:34 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:25:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:25:37 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-01 20:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:40:02 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-01 20:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:46:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:46:16 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 20:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:52:42 --> No URI present. Default controller set.
DEBUG - 2022-07-01 20:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:54:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 20:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:54:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 20:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:54:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 20:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:54:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 20:54:41 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-01 20:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:57:52 --> No URI present. Default controller set.
DEBUG - 2022-07-01 20:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:57:55 --> No URI present. Default controller set.
DEBUG - 2022-07-01 20:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 20:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 20:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 20:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:08:31 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:08:54 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:09:58 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:17 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:30 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:36 --> Total execution time: 0.0521
DEBUG - 2022-07-01 21:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:43 --> Total execution time: 0.0531
DEBUG - 2022-07-01 21:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:10:43 --> Total execution time: 0.0736
DEBUG - 2022-07-01 21:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:11:07 --> Total execution time: 0.0477
DEBUG - 2022-07-01 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:11:09 --> Total execution time: 0.0564
DEBUG - 2022-07-01 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:11:09 --> Total execution time: 0.0586
DEBUG - 2022-07-01 21:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:13:53 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:14:17 --> Total execution time: 0.1157
DEBUG - 2022-07-01 21:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:14:18 --> Total execution time: 0.0535
DEBUG - 2022-07-01 21:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:14:19 --> Total execution time: 0.0496
DEBUG - 2022-07-01 21:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:14:32 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:17:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 21:24:02 --> 404 Page Not Found: Wp-content/hbhbrdryld.php
DEBUG - 2022-07-01 21:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:26:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:29 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:57 --> Total execution time: 0.0421
DEBUG - 2022-07-01 21:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:58 --> Total execution time: 0.0433
DEBUG - 2022-07-01 21:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:28:58 --> Total execution time: 0.0928
DEBUG - 2022-07-01 21:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:33 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:38 --> Total execution time: 0.0468
DEBUG - 2022-07-01 21:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:40 --> Total execution time: 0.0457
DEBUG - 2022-07-01 21:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:29:40 --> Total execution time: 0.1052
DEBUG - 2022-07-01 21:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:30:32 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:30:46 --> Total execution time: 0.0471
DEBUG - 2022-07-01 21:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:30:55 --> Total execution time: 0.0538
DEBUG - 2022-07-01 21:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:30:55 --> Total execution time: 0.0912
DEBUG - 2022-07-01 21:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:01 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:19 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:24 --> Total execution time: 0.0488
DEBUG - 2022-07-01 21:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:28 --> Total execution time: 0.0561
DEBUG - 2022-07-01 21:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:28 --> Total execution time: 0.0910
DEBUG - 2022-07-01 21:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:39 --> Total execution time: 0.0470
DEBUG - 2022-07-01 21:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:40 --> Total execution time: 0.0742
DEBUG - 2022-07-01 21:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:31:40 --> Total execution time: 0.1200
DEBUG - 2022-07-01 21:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:31:51 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:57 --> Total execution time: 0.0708
DEBUG - 2022-07-01 21:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:59 --> Total execution time: 0.0877
DEBUG - 2022-07-01 21:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:43:59 --> Total execution time: 0.1524
DEBUG - 2022-07-01 21:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:47:10 --> Total execution time: 0.0534
DEBUG - 2022-07-01 21:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:48:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:26 --> Total execution time: 0.0580
DEBUG - 2022-07-01 21:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:48:34 --> Total execution time: 0.0593
DEBUG - 2022-07-01 21:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:34 --> Total execution time: 0.0721
DEBUG - 2022-07-01 21:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:56 --> Total execution time: 0.0462
DEBUG - 2022-07-01 21:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:48:59 --> Total execution time: 0.0465
DEBUG - 2022-07-01 21:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:49:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:02 --> Total execution time: 0.0504
DEBUG - 2022-07-01 21:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:04 --> Total execution time: 0.0493
DEBUG - 2022-07-01 21:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:04 --> Total execution time: 0.0485
DEBUG - 2022-07-01 21:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:10 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:34 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:51:57 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:55:06 --> No URI present. Default controller set.
DEBUG - 2022-07-01 21:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 21:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 21:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 21:59:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 21:59:52 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 22:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:00:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 22:00:33 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-01 22:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:02:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 22:02:32 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 22:04:38 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 22:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:07:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 22:07:04 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-01 22:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:12:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:12:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:13:47 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:24:50 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:25:15 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:25:44 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 22:26:12 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-01 22:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:26:36 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 22:28:13 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-01 22:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:58:40 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:58:40 --> No URI present. Default controller set.
DEBUG - 2022-07-01 22:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 22:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 22:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 22:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:00:01 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:00:02 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:00:11 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:01:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:09:05 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 23:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:09:08 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:09:10 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 23:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:09:24 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 23:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:09:34 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:09:42 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-01 23:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:09:43 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:09:46 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:14:49 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:00 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:20:41 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:23:04 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:23:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:29:14 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:30:44 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:30:45 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:33:12 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:22 --> Total execution time: 0.0504
DEBUG - 2022-07-01 23:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:24 --> Total execution time: 0.0601
DEBUG - 2022-07-01 23:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:24 --> Total execution time: 0.1167
DEBUG - 2022-07-01 23:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:36 --> Total execution time: 0.0492
DEBUG - 2022-07-01 23:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:39 --> Total execution time: 0.0654
DEBUG - 2022-07-01 23:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:34:56 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:38:35 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:39:54 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-01 23:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:41:03 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:41:05 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:41:06 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:42:29 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-01 23:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:44:43 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-01 23:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:46:16 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:46:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:46:16 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-01 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:46:34 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:46:34 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:07 --> Total execution time: 0.0406
DEBUG - 2022-07-01 23:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:09 --> Total execution time: 0.0464
DEBUG - 2022-07-01 23:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:09 --> Total execution time: 0.0962
DEBUG - 2022-07-01 23:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:26 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-01 23:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-01 23:48:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-01 23:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:45 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:50:18 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:52:26 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:53:28 --> No URI present. Default controller set.
DEBUG - 2022-07-01 23:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-01 23:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-01 23:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-01 23:59:20 --> Encryption: Auto-configured driver 'openssl'.
