<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-28 05:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 05:38:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'gvprods_gvv3'@'localhost' (using password: YES) C:\xampp\htdocs\gopal\leadrsark\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-28 05:38:14 --> Unable to connect to the database
DEBUG - 2022-04-28 05:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 05:38:19 --> 404 Page Not Found: user//index
DEBUG - 2022-04-28 05:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:38:22 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 05:38:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'gvprods_gvv3'@'localhost' (using password: YES) C:\xampp\htdocs\gopal\leadrsark\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-04-28 05:38:22 --> Unable to connect to the database
DEBUG - 2022-04-28 05:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:39:37 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:09:39 --> Total execution time: 2.0956
DEBUG - 2022-04-28 05:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 05:39:53 --> Total execution time: 0.0558
DEBUG - 2022-04-28 05:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 05:39:53 --> Total execution time: 0.0626
DEBUG - 2022-04-28 05:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 05:39:53 --> Total execution time: 0.0731
DEBUG - 2022-04-28 05:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:39:55 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:09:55 --> Total execution time: 0.0544
DEBUG - 2022-04-28 05:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:09:59 --> Total execution time: 0.0574
DEBUG - 2022-04-28 05:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:10:23 --> Total execution time: 0.0551
DEBUG - 2022-04-28 05:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:10:25 --> Total execution time: 0.0498
DEBUG - 2022-04-28 05:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 05:40:31 --> Total execution time: 0.0877
DEBUG - 2022-04-28 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:10:35 --> Total execution time: 0.0566
DEBUG - 2022-04-28 05:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 05:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:11:32 --> Total execution time: 0.0538
DEBUG - 2022-04-28 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:41:43 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:11:43 --> Total execution time: 0.0534
DEBUG - 2022-04-28 05:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:42:21 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:12:22 --> Total execution time: 0.0495
DEBUG - 2022-04-28 05:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:42:31 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:12:31 --> Total execution time: 0.0500
DEBUG - 2022-04-28 05:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:45:41 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:15:41 --> Total execution time: 0.0550
DEBUG - 2022-04-28 05:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:16:28 --> Total execution time: 1.7143
DEBUG - 2022-04-28 05:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 05:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:17:57 --> Total execution time: 0.0675
DEBUG - 2022-04-28 05:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:18:02 --> Total execution time: 0.0701
DEBUG - 2022-04-28 05:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:19:26 --> Total execution time: 0.0665
DEBUG - 2022-04-28 05:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:49:28 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:19:28 --> Total execution time: 0.0706
DEBUG - 2022-04-28 05:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:51:27 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:21:27 --> Total execution time: 0.0556
DEBUG - 2022-04-28 05:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:51:52 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:21:53 --> Total execution time: 0.0567
DEBUG - 2022-04-28 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:52:26 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:22:26 --> Total execution time: 0.0537
DEBUG - 2022-04-28 05:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:53:08 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:23:08 --> Total execution time: 0.0520
DEBUG - 2022-04-28 05:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:53:26 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:23:26 --> Total execution time: 0.0557
DEBUG - 2022-04-28 05:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:56:16 --> No URI present. Default controller set.
DEBUG - 2022-04-28 05:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 05:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:26:16 --> Total execution time: 0.0590
DEBUG - 2022-04-28 05:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 05:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 05:59:51 --> 404 Page Not Found: Admin/Cron_Controller/index
DEBUG - 2022-04-28 06:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 06:00:00 --> 404 Page Not Found: Front/Cron_Controller
DEBUG - 2022-04-28 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:30:10 --> Total execution time: 0.0796
DEBUG - 2022-04-28 06:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:31:53 --> Total execution time: 0.0659
DEBUG - 2022-04-28 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:32:06 --> Total execution time: 0.0484
DEBUG - 2022-04-28 06:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:33:00 --> Total execution time: 0.0477
DEBUG - 2022-04-28 06:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:15:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 09:45:31 --> Severity: error --> Exception: Using $this when not in object context C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 63
DEBUG - 2022-04-28 06:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:45:50 --> Total execution time: 0.0821
DEBUG - 2022-04-28 06:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:46:09 --> Total execution time: 0.0687
DEBUG - 2022-04-28 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:46:41 --> Total execution time: 0.0523
DEBUG - 2022-04-28 06:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:46:53 --> Total execution time: 0.0563
DEBUG - 2022-04-28 06:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:47:35 --> Total execution time: 0.0596
DEBUG - 2022-04-28 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:47:36 --> Total execution time: 0.0599
DEBUG - 2022-04-28 06:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:49:22 --> Total execution time: 0.0604
DEBUG - 2022-04-28 06:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:49:24 --> Total execution time: 0.0519
DEBUG - 2022-04-28 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 09:49:42 --> Total execution time: 0.0615
DEBUG - 2022-04-28 06:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:33:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 10:03:55 --> Severity: Notice --> Undefined variable: parents C:\xampp\htdocs\gopal\leadrsark\application\controllers\User\Cron_Controller.php 17
DEBUG - 2022-04-28 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:35:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 10:05:22 --> Severity: Notice --> Undefined variable: user_max_package C:\xampp\htdocs\gopal\leadrsark\application\controllers\User\Cron_Controller.php 20
DEBUG - 2022-04-28 06:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 06:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 06:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 06:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 07:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:01:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:01:30 --> Severity: error --> Exception: syntax error, unexpected ''com_date_time'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\gopal\leadrsark\application\controllers\User\Cron_Controller.php 29
DEBUG - 2022-04-28 07:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:31:47 --> Total execution time: 0.1160
DEBUG - 2022-04-28 07:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:38:28 --> Total execution time: 0.0905
DEBUG - 2022-04-28 07:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:38:43 --> Total execution time: 0.0601
DEBUG - 2022-04-28 07:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:39:34 --> Total execution time: 0.0654
DEBUG - 2022-04-28 07:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:20:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 10:50:14 --> Severity: Notice --> Undefined property: Cron_Controller::$Wallets C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 58
ERROR - 2022-04-28 10:50:14 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 58
DEBUG - 2022-04-28 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:21:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 10:51:12 --> Severity: Notice --> Undefined property: Cron_Controller::$Wallets C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 58
ERROR - 2022-04-28 10:51:12 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 58
DEBUG - 2022-04-28 07:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:51:27 --> Total execution time: 0.0825
DEBUG - 2022-04-28 07:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 07:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:52:02 --> Total execution time: 0.0627
DEBUG - 2022-04-28 07:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:52:09 --> Total execution time: 0.3258
DEBUG - 2022-04-28 07:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:22:15 --> 404 Page Not Found: user/My-account/index
DEBUG - 2022-04-28 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:52:16 --> Total execution time: 0.0531
DEBUG - 2022-04-28 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:22:50 --> 404 Page Not Found: user/Leaderboard/index
DEBUG - 2022-04-28 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:52:53 --> Total execution time: 0.0540
DEBUG - 2022-04-28 07:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:53:31 --> Total execution time: 0.0675
DEBUG - 2022-04-28 07:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:53:46 --> Total execution time: 0.0539
DEBUG - 2022-04-28 07:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:53:50 --> Total execution time: 0.0573
DEBUG - 2022-04-28 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:54:41 --> Total execution time: 0.0585
DEBUG - 2022-04-28 07:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:56:45 --> Total execution time: 0.0727
DEBUG - 2022-04-28 07:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:56:53 --> Total execution time: 0.0648
DEBUG - 2022-04-28 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:27:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:27:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:27:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:27:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:27:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:27:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:27:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:27:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:27:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:57:54 --> Total execution time: 0.0587
DEBUG - 2022-04-28 07:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 10:58:28 --> Total execution time: 0.0554
DEBUG - 2022-04-28 07:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:28:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:28:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:28:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:28:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:28:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:28:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:28:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:00:09 --> Total execution time: 0.0632
DEBUG - 2022-04-28 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:30:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:30:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:30:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:30:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:30:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:30:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:30:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:30:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:30:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:00:28 --> Total execution time: 0.0708
DEBUG - 2022-04-28 07:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:00:36 --> Total execution time: 0.0840
DEBUG - 2022-04-28 07:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:00:39 --> Total execution time: 0.0592
DEBUG - 2022-04-28 07:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:00:57 --> Total execution time: 0.0613
DEBUG - 2022-04-28 07:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:01:11 --> Total execution time: 0.0520
DEBUG - 2022-04-28 07:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:01:19 --> Total execution time: 0.0743
DEBUG - 2022-04-28 07:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:02:00 --> Total execution time: 0.0792
DEBUG - 2022-04-28 07:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:02:40 --> Total execution time: 0.0554
DEBUG - 2022-04-28 07:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:03:06 --> Total execution time: 0.0557
DEBUG - 2022-04-28 07:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:03:08 --> Total execution time: 0.0531
DEBUG - 2022-04-28 07:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:09:06 --> Total execution time: 0.0766
DEBUG - 2022-04-28 07:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:09:15 --> Total execution time: 0.0955
DEBUG - 2022-04-28 07:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:09:36 --> Total execution time: 0.0593
DEBUG - 2022-04-28 07:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:09:42 --> Total execution time: 0.0968
DEBUG - 2022-04-28 07:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:10:02 --> Total execution time: 0.0611
DEBUG - 2022-04-28 07:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:10:12 --> Total execution time: 0.0859
DEBUG - 2022-04-28 07:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:10:32 --> Total execution time: 0.0841
DEBUG - 2022-04-28 07:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:10:38 --> Total execution time: 0.1448
DEBUG - 2022-04-28 07:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:10:43 --> Total execution time: 0.0723
DEBUG - 2022-04-28 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:10:48 --> Total execution time: 0.0658
DEBUG - 2022-04-28 07:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:10:54 --> Total execution time: 0.0598
DEBUG - 2022-04-28 07:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:11:10 --> Total execution time: 0.0673
DEBUG - 2022-04-28 07:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:11:21 --> Total execution time: 0.0944
DEBUG - 2022-04-28 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:11:30 --> Total execution time: 0.0835
DEBUG - 2022-04-28 07:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:12:29 --> Total execution time: 0.0699
DEBUG - 2022-04-28 07:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:12:37 --> Total execution time: 0.0492
DEBUG - 2022-04-28 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:12:45 --> Total execution time: 0.0647
DEBUG - 2022-04-28 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:13:04 --> Total execution time: 0.0926
DEBUG - 2022-04-28 07:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:13:10 --> Total execution time: 0.0782
DEBUG - 2022-04-28 07:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:13:30 --> Total execution time: 0.0761
DEBUG - 2022-04-28 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:43:47 --> UTF-8 Support Enabled
ERROR - 2022-04-28 07:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:43:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:43:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:14:04 --> Total execution time: 0.0617
DEBUG - 2022-04-28 07:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:44:04 --> UTF-8 Support Enabled
ERROR - 2022-04-28 07:44:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:44:04 --> UTF-8 Support Enabled
ERROR - 2022-04-28 07:44:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:44:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:44:05 --> UTF-8 Support Enabled
ERROR - 2022-04-28 07:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:44:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 07:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 07:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:15:35 --> Total execution time: 0.0669
DEBUG - 2022-04-28 07:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:15:42 --> Total execution time: 0.0698
DEBUG - 2022-04-28 07:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:16:03 --> Total execution time: 0.0724
DEBUG - 2022-04-28 07:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:16:26 --> Total execution time: 0.0864
DEBUG - 2022-04-28 07:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:16:48 --> Total execution time: 0.0674
DEBUG - 2022-04-28 07:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:17:27 --> Total execution time: 0.0796
DEBUG - 2022-04-28 07:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:17:53 --> Total execution time: 0.0628
DEBUG - 2022-04-28 07:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:55:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:25:03 --> Severity: error --> Exception: Too few arguments to function today_earning(), 1 passed in C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php on line 47 and exactly 2 expected C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 77
DEBUG - 2022-04-28 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:25:26 --> Total execution time: 0.0899
DEBUG - 2022-04-28 07:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:58:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:28:49 --> Severity: error --> Exception: syntax error, unexpected '$date_to' (T_VARIABLE) C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 65
DEBUG - 2022-04-28 07:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:58:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:28:57 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:28:57 --> Total execution time: 0.0743
DEBUG - 2022-04-28 07:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:59:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:29:23 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:29:23 --> Total execution time: 0.0531
DEBUG - 2022-04-28 07:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 07:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 07:59:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:29:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:29:45 --> Total execution time: 0.0826
DEBUG - 2022-04-28 08:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:00:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:30:06 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:30:06 --> Total execution time: 0.0631
DEBUG - 2022-04-28 08:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:00:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:30:21 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:30:21 --> Total execution time: 0.0569
DEBUG - 2022-04-28 08:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:00:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:30:36 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:30:36 --> Total execution time: 0.0949
DEBUG - 2022-04-28 08:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:00:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:30:50 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:30:50 --> Total execution time: 0.0570
DEBUG - 2022-04-28 08:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:00:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:30:51 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:30:51 --> Total execution time: 0.0551
DEBUG - 2022-04-28 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:01:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:31:15 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:31:15 --> Total execution time: 0.0965
DEBUG - 2022-04-28 08:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:01:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:31:28 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:31:28 --> Total execution time: 0.0765
DEBUG - 2022-04-28 08:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:31:34 --> Total execution time: 0.0570
DEBUG - 2022-04-28 08:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:01:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:31:39 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-account.php 63
DEBUG - 2022-04-28 11:31:39 --> Total execution time: 0.0806
DEBUG - 2022-04-28 08:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:32:34 --> Total execution time: 0.0680
DEBUG - 2022-04-28 08:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:32:44 --> Total execution time: 0.0508
DEBUG - 2022-04-28 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:33:04 --> Total execution time: 0.0770
DEBUG - 2022-04-28 08:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:33:20 --> Total execution time: 0.0553
DEBUG - 2022-04-28 08:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:33:28 --> Total execution time: 0.0646
DEBUG - 2022-04-28 08:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:04:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:34:51 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 105
ERROR - 2022-04-28 11:34:51 --> Severity: Notice --> Trying to get property 'db' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 105
ERROR - 2022-04-28 11:34:51 --> Severity: error --> Exception: Call to a member function select_sum() on null C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 105
DEBUG - 2022-04-28 08:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:05:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:35:08 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 105
ERROR - 2022-04-28 11:35:08 --> Severity: Notice --> Trying to get property 'db' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 105
ERROR - 2022-04-28 11:35:08 --> Severity: error --> Exception: Call to a member function select_sum() on null C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 105
DEBUG - 2022-04-28 08:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:35:18 --> Total execution time: 0.1532
DEBUG - 2022-04-28 08:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:35:21 --> Total execution time: 0.0580
DEBUG - 2022-04-28 08:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:37:13 --> Total execution time: 0.0628
DEBUG - 2022-04-28 08:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:38:25 --> Total execution time: 0.0684
DEBUG - 2022-04-28 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:11:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 08:11:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:11:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:11:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 08:11:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:11:23 --> UTF-8 Support Enabled
ERROR - 2022-04-28 08:11:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:11:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:11:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:42:16 --> Total execution time: 0.0744
DEBUG - 2022-04-28 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 08:12:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 08:12:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:42:34 --> Total execution time: 0.0517
DEBUG - 2022-04-28 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:35 --> UTF-8 Support Enabled
ERROR - 2022-04-28 08:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 08:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 08:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:12:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 08:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:42:45 --> Total execution time: 0.0565
DEBUG - 2022-04-28 08:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:42:55 --> Total execution time: 0.0555
DEBUG - 2022-04-28 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:43:42 --> Total execution time: 0.0581
DEBUG - 2022-04-28 08:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:43:50 --> Total execution time: 0.0832
DEBUG - 2022-04-28 08:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:43:55 --> Total execution time: 0.1064
DEBUG - 2022-04-28 08:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:44:20 --> Total execution time: 0.0519
DEBUG - 2022-04-28 08:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:44:48 --> Total execution time: 0.0483
DEBUG - 2022-04-28 08:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:44:53 --> Total execution time: 0.0555
DEBUG - 2022-04-28 08:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:45:06 --> Total execution time: 0.0724
DEBUG - 2022-04-28 08:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:45:20 --> Total execution time: 0.0630
DEBUG - 2022-04-28 08:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:45:32 --> Total execution time: 0.0917
DEBUG - 2022-04-28 08:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:45:39 --> Total execution time: 0.0500
DEBUG - 2022-04-28 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:46:00 --> Total execution time: 0.0711
DEBUG - 2022-04-28 08:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:46:44 --> Total execution time: 0.0509
DEBUG - 2022-04-28 08:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:46:50 --> Total execution time: 0.0618
DEBUG - 2022-04-28 08:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:47:12 --> Total execution time: 0.0530
DEBUG - 2022-04-28 08:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:47:32 --> Total execution time: 0.0969
DEBUG - 2022-04-28 08:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:47:39 --> Total execution time: 0.0630
DEBUG - 2022-04-28 08:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:47:51 --> Total execution time: 0.0612
DEBUG - 2022-04-28 08:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:48:41 --> Total execution time: 0.0653
DEBUG - 2022-04-28 08:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:48:46 --> Total execution time: 0.0784
DEBUG - 2022-04-28 08:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:48:52 --> Total execution time: 0.0783
DEBUG - 2022-04-28 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:50:28 --> Total execution time: 0.0637
DEBUG - 2022-04-28 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:50:49 --> Total execution time: 0.0802
DEBUG - 2022-04-28 08:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:51:34 --> Total execution time: 0.0598
DEBUG - 2022-04-28 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:53:32 --> Total execution time: 0.0614
DEBUG - 2022-04-28 08:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:54:07 --> Total execution time: 0.0565
DEBUG - 2022-04-28 08:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:54:09 --> Total execution time: 0.0578
DEBUG - 2022-04-28 08:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:54:25 --> Total execution time: 0.0551
DEBUG - 2022-04-28 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:25:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 11:55:24 --> Severity: error --> Exception: Call to a member function num_rows() on array C:\xampp\htdocs\gopal\leadrsark\application\helpers\two_tier_helper.php 7
DEBUG - 2022-04-28 08:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:55:30 --> Total execution time: 0.0584
DEBUG - 2022-04-28 08:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:55:45 --> Total execution time: 0.0542
DEBUG - 2022-04-28 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:55:53 --> Total execution time: 0.4121
DEBUG - 2022-04-28 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:56:15 --> Total execution time: 0.0787
DEBUG - 2022-04-28 08:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:56:31 --> Total execution time: 0.0740
DEBUG - 2022-04-28 08:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:56:37 --> Total execution time: 0.0495
DEBUG - 2022-04-28 08:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:56:42 --> Total execution time: 0.0770
DEBUG - 2022-04-28 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:57:55 --> Total execution time: 0.0888
DEBUG - 2022-04-28 08:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:58:05 --> Total execution time: 0.1228
DEBUG - 2022-04-28 08:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:58:36 --> Total execution time: 0.0691
DEBUG - 2022-04-28 08:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:58:42 --> Total execution time: 0.0644
DEBUG - 2022-04-28 08:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 11:58:52 --> Total execution time: 0.0894
DEBUG - 2022-04-28 08:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:00:41 --> Total execution time: 0.0569
DEBUG - 2022-04-28 08:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:37:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 12:07:39 --> Query error: Not unique table/alias: 'user_joins' - Invalid query: SELECT *
FROM `user_joins`
JOIN `user_joins` ON `user_logins`.`ul_id` = `user_joins`.`uj_parent_id`
WHERE `uj_child_id` = 5
DEBUG - 2022-04-28 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:07:56 --> Total execution time: 0.1039
DEBUG - 2022-04-28 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:08:04 --> Total execution time: 0.0873
DEBUG - 2022-04-28 08:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:08:14 --> Total execution time: 0.0571
DEBUG - 2022-04-28 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:08:28 --> Total execution time: 0.0592
DEBUG - 2022-04-28 08:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:43:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 12:13:47 --> Severity: error --> Exception: syntax error, unexpected 'strtotime' (T_STRING), expecting ')' C:\xampp\htdocs\gopal\leadrsark\application\views\User\affiliate-earnings.php 222
DEBUG - 2022-04-28 08:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:13:58 --> Total execution time: 0.0627
DEBUG - 2022-04-28 08:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:15:20 --> Total execution time: 0.0605
DEBUG - 2022-04-28 08:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:15:28 --> Total execution time: 0.0886
DEBUG - 2022-04-28 08:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:15:58 --> Total execution time: 0.0614
DEBUG - 2022-04-28 08:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:16:13 --> Total execution time: 0.1302
DEBUG - 2022-04-28 08:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:16:21 --> Total execution time: 0.0558
DEBUG - 2022-04-28 08:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:16:43 --> Total execution time: 0.0607
DEBUG - 2022-04-28 08:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:16:45 --> Total execution time: 0.0641
DEBUG - 2022-04-28 08:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:46:47 --> 404 Page Not Found: user/My-account/index
DEBUG - 2022-04-28 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:16:48 --> Total execution time: 0.0652
DEBUG - 2022-04-28 08:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:48:39 --> No URI present. Default controller set.
DEBUG - 2022-04-28 08:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:18:39 --> Total execution time: 0.2031
DEBUG - 2022-04-28 08:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:50:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 08:50:41 --> 404 Page Not Found: user/Support/index
DEBUG - 2022-04-28 08:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 08:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 08:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 12:20:43 --> Total execution time: 0.0835
DEBUG - 2022-04-28 14:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:37:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 14:37:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\leadrsark\application\core\DB_Controller.php 49
DEBUG - 2022-04-28 14:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:07:45 --> Total execution time: 0.1291
DEBUG - 2022-04-28 14:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:37:47 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:07:47 --> Total execution time: 0.1485
DEBUG - 2022-04-28 14:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:44:34 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:14:34 --> Total execution time: 0.0624
DEBUG - 2022-04-28 14:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:45:53 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:15:53 --> Total execution time: 0.0538
DEBUG - 2022-04-28 14:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:46:34 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:16:34 --> Total execution time: 0.0585
DEBUG - 2022-04-28 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:50:22 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:20:23 --> Total execution time: 0.6308
DEBUG - 2022-04-28 14:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:50:40 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:20:40 --> Total execution time: 0.0554
DEBUG - 2022-04-28 14:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:53:47 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:23:47 --> Total execution time: 0.1633
DEBUG - 2022-04-28 14:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:54:10 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:24:10 --> Total execution time: 0.0643
DEBUG - 2022-04-28 14:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:54:14 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:24:15 --> Total execution time: 0.0531
DEBUG - 2022-04-28 14:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:56:51 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:26:51 --> Total execution time: 0.0880
DEBUG - 2022-04-28 14:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:58:08 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:28:08 --> Total execution time: 0.0554
DEBUG - 2022-04-28 14:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:58:41 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:28:41 --> Total execution time: 0.0785
DEBUG - 2022-04-28 14:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 14:58:59 --> No URI present. Default controller set.
DEBUG - 2022-04-28 14:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 14:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:29:00 --> Total execution time: 0.0550
DEBUG - 2022-04-28 15:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:01:04 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:31:04 --> Total execution time: 0.0527
DEBUG - 2022-04-28 15:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:01:56 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:31:56 --> Total execution time: 0.0609
DEBUG - 2022-04-28 15:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:02:57 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:32:57 --> Total execution time: 0.0585
DEBUG - 2022-04-28 15:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:03:27 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:33:27 --> Total execution time: 0.0850
DEBUG - 2022-04-28 15:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:04:47 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:34:47 --> Total execution time: 0.0577
DEBUG - 2022-04-28 15:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:05:20 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:35:20 --> Total execution time: 0.1200
DEBUG - 2022-04-28 15:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:06:09 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:36:09 --> Total execution time: 0.0536
DEBUG - 2022-04-28 15:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:10:33 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:40:33 --> Total execution time: 0.0774
DEBUG - 2022-04-28 15:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:15:02 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:45:03 --> Total execution time: 0.0592
DEBUG - 2022-04-28 15:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:15:48 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:45:48 --> Total execution time: 0.0790
DEBUG - 2022-04-28 15:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:17:46 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:47:46 --> Total execution time: 0.0566
DEBUG - 2022-04-28 15:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:17:51 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:47:51 --> Total execution time: 0.0641
DEBUG - 2022-04-28 15:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:19:52 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:49:52 --> Total execution time: 0.0518
DEBUG - 2022-04-28 15:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:19:55 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:49:55 --> Total execution time: 0.0517
DEBUG - 2022-04-28 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:21:18 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:51:18 --> Total execution time: 0.0568
DEBUG - 2022-04-28 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:21:35 --> No URI present. Default controller set.
DEBUG - 2022-04-28 15:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:51:35 --> Total execution time: 0.0579
DEBUG - 2022-04-28 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:25:26 --> 404 Page Not Found: About-us/index
DEBUG - 2022-04-28 15:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:26:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:26:19 --> 404 Page Not Found: Welcome/Cron_Controller
DEBUG - 2022-04-28 15:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:56:37 --> Total execution time: 0.0637
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:58:33 --> Total execution time: 0.0558
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/css
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/css
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/css
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/js
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/css
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:28:33 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 18:59:48 --> Total execution time: 0.0728
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 15:29:48 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:00:11 --> Total execution time: 0.0581
DEBUG - 2022-04-28 15:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:00:35 --> Total execution time: 0.0543
DEBUG - 2022-04-28 15:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:00:41 --> Total execution time: 0.0597
DEBUG - 2022-04-28 15:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:01:29 --> Total execution time: 0.0686
DEBUG - 2022-04-28 15:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:01:54 --> Total execution time: 0.0598
DEBUG - 2022-04-28 15:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:02:20 --> Total execution time: 0.0573
DEBUG - 2022-04-28 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:02:54 --> Total execution time: 0.0498
DEBUG - 2022-04-28 15:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:02:55 --> Total execution time: 0.0734
DEBUG - 2022-04-28 15:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:03:04 --> Total execution time: 0.0690
DEBUG - 2022-04-28 15:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:03:54 --> Total execution time: 0.0763
DEBUG - 2022-04-28 15:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:05:43 --> Total execution time: 0.0748
DEBUG - 2022-04-28 15:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:06:21 --> Total execution time: 0.0620
DEBUG - 2022-04-28 15:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:01 --> Severity: Compile Error --> Cannot redeclare Welcome::about_us() C:\xampp\htdocs\gopal\leadrsark\application\controllers\Welcome.php 31
DEBUG - 2022-04-28 15:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:24 --> Severity: Compile Error --> Cannot redeclare Welcome::about_us() C:\xampp\htdocs\gopal\leadrsark\application\controllers\Welcome.php 31
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:25:35 --> Total execution time: 0.0561
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/css
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/css
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/js
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/css
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/js
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:55:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 15:55:35 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 15:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:27:19 --> Total execution time: 0.0559
DEBUG - 2022-04-28 15:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:29:28 --> Total execution time: 0.0490
DEBUG - 2022-04-28 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 15:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 15:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:29:55 --> Total execution time: 0.0557
DEBUG - 2022-04-28 16:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:31:41 --> Total execution time: 0.0646
DEBUG - 2022-04-28 16:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:33:04 --> Total execution time: 0.0518
DEBUG - 2022-04-28 16:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:42:30 --> Total execution time: 0.0763
DEBUG - 2022-04-28 16:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:43:01 --> Total execution time: 0.0499
DEBUG - 2022-04-28 16:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:13:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 19:43:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Contact_us C:\xampp\htdocs\gopal\leadrsark\system\core\Loader.php 348
DEBUG - 2022-04-28 16:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 16:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:44:11 --> Total execution time: 0.0728
DEBUG - 2022-04-28 16:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:44:34 --> Total execution time: 0.0522
DEBUG - 2022-04-28 16:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 16:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:44:45 --> Total execution time: 0.0496
DEBUG - 2022-04-28 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:45:04 --> Total execution time: 0.0596
DEBUG - 2022-04-28 16:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:15:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:15:23 --> 404 Page Not Found: Why-join-us/index
DEBUG - 2022-04-28 16:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:45:53 --> Total execution time: 0.0622
DEBUG - 2022-04-28 16:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:45:54 --> Total execution time: 0.0644
DEBUG - 2022-04-28 16:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:15:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:15:57 --> 404 Page Not Found: Faq/index
DEBUG - 2022-04-28 16:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:46:12 --> Total execution time: 0.0551
DEBUG - 2022-04-28 16:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:46:36 --> Total execution time: 0.0534
DEBUG - 2022-04-28 16:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 16:16:42 --> Total execution time: 0.0698
DEBUG - 2022-04-28 16:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 16:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:46:44 --> Total execution time: 0.1016
DEBUG - 2022-04-28 16:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:46:47 --> Total execution time: 0.0897
DEBUG - 2022-04-28 16:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:47:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-28 19:47:05 --> You did not select a file to upload.
DEBUG - 2022-04-28 19:47:05 --> You did not select a file to upload.
DEBUG - 2022-04-28 16:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:47:05 --> Total execution time: 0.0556
DEBUG - 2022-04-28 16:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:47:06 --> Total execution time: 0.0781
DEBUG - 2022-04-28 16:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:47:45 --> Total execution time: 0.0553
DEBUG - 2022-04-28 16:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:47:49 --> Total execution time: 0.0495
DEBUG - 2022-04-28 16:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:48:42 --> Total execution time: 0.0504
DEBUG - 2022-04-28 16:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:48:50 --> Total execution time: 0.0657
DEBUG - 2022-04-28 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:51:00 --> Total execution time: 0.1307
DEBUG - 2022-04-28 16:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:51:39 --> Total execution time: 0.0616
DEBUG - 2022-04-28 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 16:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:22:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 19:52:12 --> Severity: Notice --> Undefined variable: users C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\contact-list.php 85
ERROR - 2022-04-28 19:52:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\contact-list.php 85
DEBUG - 2022-04-28 19:52:12 --> Total execution time: 0.0576
DEBUG - 2022-04-28 16:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:52:28 --> Total execution time: 0.0705
DEBUG - 2022-04-28 16:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:00:58 --> Total execution time: 0.0571
DEBUG - 2022-04-28 16:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:01:55 --> Total execution time: 0.0613
DEBUG - 2022-04-28 16:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:32:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_name_as_bank_acc' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 202
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_bank_name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 206
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_account_no' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 210
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_ifsc' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 214
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_account_type' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 218
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_pan' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 227
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_bank_reg_mobile' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 231
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_bank_reg_email' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 235
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'bank_acc_related_to' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 240
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_uploaded_document' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 286
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_document_digits' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 288
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_uploaded_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 289
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 291
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 291
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 292
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 294
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 294
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 295
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 297
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 297
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 298
ERROR - 2022-04-28 20:02:01 --> Severity: Notice --> Trying to get property 'ukd_accepted_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 300
DEBUG - 2022-04-28 20:02:01 --> Total execution time: 0.1436
DEBUG - 2022-04-28 16:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:33:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'bank_acc_pan' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 233
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'bank_acc_bank_reg_mobile' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 237
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'bank_acc_bank_reg_email' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 241
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'bank_acc_related_to' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 246
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_uploaded_document' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 292
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_document_digits' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 294
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_uploaded_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 295
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 297
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 297
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 298
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 300
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 300
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 301
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 303
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 303
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 304
ERROR - 2022-04-28 20:03:32 --> Severity: Notice --> Trying to get property 'ukd_accepted_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 306
DEBUG - 2022-04-28 20:03:32 --> Total execution time: 0.0748
DEBUG - 2022-04-28 16:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:33:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'bank_acc_pan' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 234
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'bank_acc_bank_reg_mobile' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 238
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'bank_acc_bank_reg_email' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 242
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'bank_acc_related_to' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 247
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_uploaded_document' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 293
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_document_digits' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 295
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_uploaded_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 296
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 298
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 298
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 299
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 301
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 301
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 302
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 304
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 304
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 305
ERROR - 2022-04-28 20:03:56 --> Severity: Notice --> Trying to get property 'ukd_accepted_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 307
DEBUG - 2022-04-28 20:03:56 --> Total execution time: 0.0954
DEBUG - 2022-04-28 16:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 20:04:12 --> Severity: Notice --> Trying to get property 'bank_acc_pan' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 237
ERROR - 2022-04-28 20:04:12 --> Severity: Notice --> Trying to get property 'bank_acc_bank_reg_mobile' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 241
ERROR - 2022-04-28 20:04:12 --> Severity: Notice --> Trying to get property 'bank_acc_bank_reg_email' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 245
ERROR - 2022-04-28 20:04:12 --> Severity: Notice --> Trying to get property 'bank_acc_related_to' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 250
ERROR - 2022-04-28 20:04:12 --> Severity: Notice --> Trying to get property 'ukd_uploaded_document' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 296
ERROR - 2022-04-28 20:04:12 --> Severity: Notice --> Trying to get property 'ukd_document_digits' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 298
ERROR - 2022-04-28 20:04:12 --> Severity: Notice --> Trying to get property 'ukd_uploaded_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 299
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 301
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 301
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 302
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 304
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 304
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 305
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 307
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 307
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 308
ERROR - 2022-04-28 20:04:13 --> Severity: Notice --> Trying to get property 'ukd_accepted_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 310
DEBUG - 2022-04-28 20:04:13 --> Total execution time: 0.0940
DEBUG - 2022-04-28 16:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:35:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_uploaded_document' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 294
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_document_digits' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 296
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_uploaded_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 297
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 299
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 299
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 300
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 302
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 302
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 303
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_id' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 305
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 305
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 306
ERROR - 2022-04-28 20:05:35 --> Severity: Notice --> Trying to get property 'ukd_accepted_datetime' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\users\user_profile.php 308
DEBUG - 2022-04-28 20:05:35 --> Total execution time: 0.1023
DEBUG - 2022-04-28 16:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:06:49 --> Total execution time: 0.0661
DEBUG - 2022-04-28 16:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:07:51 --> Total execution time: 0.0858
DEBUG - 2022-04-28 16:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:08:08 --> Total execution time: 0.0783
DEBUG - 2022-04-28 16:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:08:10 --> Total execution time: 0.0996
DEBUG - 2022-04-28 16:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:08:14 --> Total execution time: 0.0592
DEBUG - 2022-04-28 16:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:09:25 --> Total execution time: 0.0750
DEBUG - 2022-04-28 16:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:09:43 --> Total execution time: 0.0614
DEBUG - 2022-04-28 16:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:40:04 --> No URI present. Default controller set.
DEBUG - 2022-04-28 16:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:10:05 --> Total execution time: 0.0695
DEBUG - 2022-04-28 16:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:10:06 --> Total execution time: 0.0551
DEBUG - 2022-04-28 16:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:10:09 --> Total execution time: 0.0492
DEBUG - 2022-04-28 16:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:10:19 --> Total execution time: 0.0537
DEBUG - 2022-04-28 16:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:11:48 --> Total execution time: 0.0638
DEBUG - 2022-04-28 16:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:11:50 --> Total execution time: 0.0534
DEBUG - 2022-04-28 16:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:41:51 --> No URI present. Default controller set.
DEBUG - 2022-04-28 16:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:11:51 --> Total execution time: 0.0768
DEBUG - 2022-04-28 16:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:12:08 --> Total execution time: 0.1006
DEBUG - 2022-04-28 16:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 16:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:12:15 --> Total execution time: 0.1251
DEBUG - 2022-04-28 16:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:42:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:42:24 --> 404 Page Not Found: user/Support/index
DEBUG - 2022-04-28 16:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:12:27 --> Total execution time: 0.0620
DEBUG - 2022-04-28 16:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:18:45 --> Total execution time: 0.0575
DEBUG - 2022-04-28 16:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:18:53 --> Total execution time: 0.0619
DEBUG - 2022-04-28 16:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:19:02 --> Total execution time: 0.0554
DEBUG - 2022-04-28 16:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:22:28 --> Total execution time: 0.0673
DEBUG - 2022-04-28 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:52:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:52:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 16:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:52:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:52:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:52:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:52:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 16:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:52:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 16:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:52:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 16:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:23:26 --> Total execution time: 0.0538
DEBUG - 2022-04-28 16:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:53:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 16:53:41 --> 404 Page Not Found: user/Direct-commssion/index
DEBUG - 2022-04-28 16:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 16:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 16:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:30:03 --> Total execution time: 0.0504
DEBUG - 2022-04-28 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:30:43 --> Total execution time: 0.0518
DEBUG - 2022-04-28 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:30:45 --> Total execution time: 0.0535
DEBUG - 2022-04-28 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:32:40 --> Total execution time: 0.0791
DEBUG - 2022-04-28 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:32:54 --> Total execution time: 0.0524
DEBUG - 2022-04-28 17:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:33:05 --> Total execution time: 0.0610
DEBUG - 2022-04-28 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:33:11 --> Total execution time: 0.0463
DEBUG - 2022-04-28 17:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:34:53 --> Total execution time: 0.0570
DEBUG - 2022-04-28 17:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:34:54 --> Total execution time: 0.0529
DEBUG - 2022-04-28 17:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 17:05:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 17:05:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 17:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 17:05:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-28 17:05:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 17:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 17:05:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 17:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:05:04 --> UTF-8 Support Enabled
ERROR - 2022-04-28 17:05:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 17:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 17:05:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 17:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 17:05:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-28 17:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:35:53 --> Total execution time: 0.0748
DEBUG - 2022-04-28 17:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:35:58 --> Total execution time: 0.0840
DEBUG - 2022-04-28 17:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:36:01 --> Total execution time: 0.0489
DEBUG - 2022-04-28 17:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:36:04 --> Total execution time: 0.0526
DEBUG - 2022-04-28 17:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:36:54 --> Total execution time: 0.0536
DEBUG - 2022-04-28 17:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:37:25 --> Total execution time: 0.0583
DEBUG - 2022-04-28 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:37:48 --> Total execution time: 0.0649
DEBUG - 2022-04-28 17:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:38:16 --> Total execution time: 0.0788
DEBUG - 2022-04-28 17:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:38:17 --> Total execution time: 0.0535
DEBUG - 2022-04-28 17:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:39:00 --> Total execution time: 0.0720
DEBUG - 2022-04-28 17:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:14:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 20:44:17 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 157
ERROR - 2022-04-28 20:44:17 --> Severity: Notice --> Trying to get property 'db' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 157
ERROR - 2022-04-28 20:44:17 --> Severity: error --> Exception: Call to a member function select() on null C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 157
DEBUG - 2022-04-28 17:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:44:27 --> Total execution time: 0.0949
DEBUG - 2022-04-28 17:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:46:41 --> Total execution time: 0.0534
DEBUG - 2022-04-28 17:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:46:47 --> Total execution time: 0.0519
DEBUG - 2022-04-28 17:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:47:20 --> Total execution time: 0.0556
DEBUG - 2022-04-28 17:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:47:23 --> Total execution time: 0.0522
DEBUG - 2022-04-28 17:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:47:33 --> Total execution time: 0.0511
DEBUG - 2022-04-28 17:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 20:52:21 --> Total execution time: 0.0528
DEBUG - 2022-04-28 18:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:31:54 --> Total execution time: 0.0600
DEBUG - 2022-04-28 18:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:06:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 21:36:24 --> Severity: Notice --> Trying to get property 'wt_date' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\withdrawal-history.php 52
ERROR - 2022-04-28 21:36:24 --> Severity: Notice --> Trying to get property 'wt_amount' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\withdrawal-history.php 53
ERROR - 2022-04-28 21:36:24 --> Severity: Notice --> Trying to get property 'wt_approve_date' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\withdrawal-history.php 54
ERROR - 2022-04-28 21:36:24 --> Severity: Notice --> Trying to get property 'wt_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\withdrawal-history.php 57
DEBUG - 2022-04-28 21:36:24 --> Total execution time: 0.0608
DEBUG - 2022-04-28 18:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:39:08 --> Total execution time: 0.0597
DEBUG - 2022-04-28 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:39:11 --> Total execution time: 0.0764
DEBUG - 2022-04-28 18:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:39:48 --> Total execution time: 0.0521
DEBUG - 2022-04-28 18:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:40:24 --> Total execution time: 0.0559
DEBUG - 2022-04-28 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:41:38 --> Total execution time: 0.0819
DEBUG - 2022-04-28 18:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:41:45 --> Total execution time: 0.0570
DEBUG - 2022-04-28 18:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:12:18 --> 404 Page Not Found: user/Leaderboard/index
DEBUG - 2022-04-28 18:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:42:20 --> Total execution time: 0.0542
DEBUG - 2022-04-28 18:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:51:28 --> Total execution time: 0.0686
DEBUG - 2022-04-28 18:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:51:32 --> Total execution time: 0.1108
DEBUG - 2022-04-28 18:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:51:43 --> Total execution time: 0.0706
DEBUG - 2022-04-28 18:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:21:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 21:51:44 --> Severity: Notice --> Trying to get property 'wt_approve_date' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 53
ERROR - 2022-04-28 21:51:44 --> Severity: Notice --> Trying to get property 'wt_amount' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 54
ERROR - 2022-04-28 21:51:44 --> Severity: Notice --> Trying to get property 'wt_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 57
ERROR - 2022-04-28 21:51:44 --> Severity: Notice --> Trying to get property 'wt_note' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 67
DEBUG - 2022-04-28 21:51:44 --> Total execution time: 0.0627
DEBUG - 2022-04-28 18:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:23:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 21:53:03 --> Severity: Notice --> Trying to get property 'wt_approve_date' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 55
ERROR - 2022-04-28 21:53:03 --> Severity: Notice --> Trying to get property 'wt_amount' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 60
ERROR - 2022-04-28 21:53:03 --> Severity: Notice --> Trying to get property 'wt_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 63
ERROR - 2022-04-28 21:53:03 --> Severity: Notice --> Trying to get property 'wt_note' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 73
DEBUG - 2022-04-28 21:53:03 --> Total execution time: 0.0754
DEBUG - 2022-04-28 18:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:23:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 21:53:28 --> Severity: Notice --> Trying to get property 'wt_approve_date' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 55
ERROR - 2022-04-28 21:53:28 --> Severity: Notice --> Trying to get property 'wt_amount' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 60
ERROR - 2022-04-28 21:53:28 --> Severity: Notice --> Trying to get property 'wt_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 63
ERROR - 2022-04-28 21:53:28 --> Severity: Notice --> Trying to get property 'wt_note' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 73
DEBUG - 2022-04-28 21:53:28 --> Total execution time: 0.1190
DEBUG - 2022-04-28 18:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:23:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 21:53:38 --> Severity: Notice --> Trying to get property 'wt_approve_date' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 55
ERROR - 2022-04-28 21:53:38 --> Severity: Notice --> Trying to get property 'wt_amount' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 60
ERROR - 2022-04-28 21:53:38 --> Severity: Notice --> Trying to get property 'wt_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 63
ERROR - 2022-04-28 21:53:38 --> Severity: Notice --> Trying to get property 'wt_note' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 73
DEBUG - 2022-04-28 21:53:38 --> Total execution time: 0.0994
DEBUG - 2022-04-28 18:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:23:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 21:53:58 --> Severity: Notice --> Trying to get property 'wt_approve_date' of non-object C:\xampp\htdocs\gopal\leadrsark\application\views\User\my_account\view-all-transaction.php 55
DEBUG - 2022-04-28 21:53:58 --> Total execution time: 0.0685
DEBUG - 2022-04-28 18:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:54:08 --> Total execution time: 0.0739
DEBUG - 2022-04-28 18:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:55:14 --> Total execution time: 0.0627
DEBUG - 2022-04-28 18:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:55:57 --> Total execution time: 0.0547
DEBUG - 2022-04-28 18:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:55:59 --> Total execution time: 0.0535
DEBUG - 2022-04-28 18:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:56:20 --> Total execution time: 0.0619
DEBUG - 2022-04-28 18:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:28:53 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 21:58:53 --> Total execution time: 0.1011
DEBUG - 2022-04-28 18:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:30:04 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:00:04 --> Total execution time: 0.0641
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:02:16 --> Total execution time: 0.0570
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:32:16 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-28 18:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:33:15 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:03:15 --> Total execution time: 0.0607
DEBUG - 2022-04-28 18:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:33:38 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:03:38 --> Total execution time: 0.0657
DEBUG - 2022-04-28 18:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:34:03 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:04:03 --> Total execution time: 0.0679
DEBUG - 2022-04-28 18:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:36:33 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:06:33 --> Total execution time: 0.0783
DEBUG - 2022-04-28 18:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:37:14 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:07:14 --> Total execution time: 0.0555
DEBUG - 2022-04-28 18:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:37:32 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:07:32 --> Total execution time: 0.0599
DEBUG - 2022-04-28 18:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:38:04 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:08:04 --> Total execution time: 0.0564
DEBUG - 2022-04-28 18:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:38:12 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:08:12 --> Total execution time: 0.0564
DEBUG - 2022-04-28 18:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:38:56 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:08:56 --> Total execution time: 0.0649
DEBUG - 2022-04-28 18:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:39:21 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:09:21 --> Total execution time: 0.0608
DEBUG - 2022-04-28 18:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:40:26 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:10:26 --> Total execution time: 0.0601
DEBUG - 2022-04-28 18:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:12:31 --> Total execution time: 0.0874
DEBUG - 2022-04-28 18:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:42:41 --> 404 Page Not Found: user/Support/index
DEBUG - 2022-04-28 18:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:43:54 --> Severity: Compile Error --> Cannot redeclare Dashboard_Controller::index() C:\xampp\htdocs\gopal\leadrsark\application\controllers\User\Dashboard_Controller.php 16
DEBUG - 2022-04-28 18:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:14:03 --> Total execution time: 0.0634
DEBUG - 2022-04-28 18:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:14:37 --> Total execution time: 0.0652
DEBUG - 2022-04-28 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:45:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-28 22:15:45 --> Severity: Warning --> Use of undefined constant EMAIL - assumed 'EMAIL' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\support.php 38
DEBUG - 2022-04-28 22:15:45 --> Total execution time: 0.0570
DEBUG - 2022-04-28 18:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:46:12 --> No URI present. Default controller set.
DEBUG - 2022-04-28 18:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:16:12 --> Total execution time: 0.0596
DEBUG - 2022-04-28 18:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:16:15 --> Total execution time: 0.0649
DEBUG - 2022-04-28 18:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:16:26 --> Total execution time: 0.0503
DEBUG - 2022-04-28 18:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:16:48 --> Total execution time: 0.1962
DEBUG - 2022-04-28 18:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:16:50 --> Total execution time: 0.0921
DEBUG - 2022-04-28 18:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:16:54 --> Total execution time: 0.0998
DEBUG - 2022-04-28 18:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:17:01 --> Total execution time: 0.0603
DEBUG - 2022-04-28 18:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:17:03 --> Total execution time: 0.0686
DEBUG - 2022-04-28 18:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:18:21 --> Total execution time: 0.0535
DEBUG - 2022-04-28 18:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:18:36 --> Total execution time: 0.0604
DEBUG - 2022-04-28 18:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:18:38 --> Total execution time: 0.0844
DEBUG - 2022-04-28 18:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:18:54 --> Total execution time: 0.0684
DEBUG - 2022-04-28 18:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:20:24 --> Total execution time: 0.1117
DEBUG - 2022-04-28 18:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:20:25 --> Total execution time: 0.0601
DEBUG - 2022-04-28 18:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:20:51 --> Total execution time: 0.0642
DEBUG - 2022-04-28 18:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:20:57 --> Total execution time: 0.0751
DEBUG - 2022-04-28 18:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:23:10 --> Total execution time: 0.0832
DEBUG - 2022-04-28 18:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:24:27 --> Total execution time: 0.0649
DEBUG - 2022-04-28 18:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:24:35 --> Total execution time: 0.0714
DEBUG - 2022-04-28 18:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:24:41 --> Total execution time: 0.0495
DEBUG - 2022-04-28 18:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:24:45 --> Total execution time: 0.0507
DEBUG - 2022-04-28 18:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:24:52 --> Total execution time: 0.0672
DEBUG - 2022-04-28 18:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:27:23 --> Total execution time: 0.0718
DEBUG - 2022-04-28 18:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-28 18:57:23 --> 404 Page Not Found: user/Assets/images
DEBUG - 2022-04-28 18:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 18:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 18:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:27:48 --> Total execution time: 0.0521
DEBUG - 2022-04-28 19:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:30:52 --> Total execution time: 0.0655
DEBUG - 2022-04-28 19:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:31:07 --> Total execution time: 0.0850
DEBUG - 2022-04-28 19:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:31:38 --> Total execution time: 0.0789
DEBUG - 2022-04-28 19:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:31:51 --> Total execution time: 0.0812
DEBUG - 2022-04-28 19:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:32:08 --> Total execution time: 0.0563
DEBUG - 2022-04-28 19:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:32:20 --> Total execution time: 0.0800
DEBUG - 2022-04-28 19:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:32:30 --> Total execution time: 0.0575
DEBUG - 2022-04-28 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:32:41 --> Total execution time: 0.0660
DEBUG - 2022-04-28 19:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:33:08 --> Total execution time: 0.0515
DEBUG - 2022-04-28 19:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:38:01 --> Total execution time: 0.0532
DEBUG - 2022-04-28 19:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:38:46 --> Total execution time: 0.0535
DEBUG - 2022-04-28 19:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:39:05 --> Total execution time: 0.0893
DEBUG - 2022-04-28 19:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:40:50 --> Total execution time: 0.0530
DEBUG - 2022-04-28 19:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 19:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:40:58 --> Total execution time: 0.0544
DEBUG - 2022-04-28 19:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 19:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 19:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:41:04 --> Total execution time: 0.0552
DEBUG - 2022-04-28 17:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:27:39 --> No URI present. Default controller set.
DEBUG - 2022-04-28 17:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 22:57:40 --> Total execution time: 0.8301
DEBUG - 2022-04-28 17:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:27:49 --> Total execution time: 0.0493
DEBUG - 2022-04-28 17:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:27:50 --> Total execution time: 0.0336
DEBUG - 2022-04-28 17:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:27:51 --> Total execution time: 0.0368
DEBUG - 2022-04-28 17:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:27:51 --> Total execution time: 0.0315
DEBUG - 2022-04-28 17:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:27:51 --> Total execution time: 0.0308
DEBUG - 2022-04-28 17:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:27:58 --> Total execution time: 0.0336
DEBUG - 2022-04-28 17:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:27:58 --> Total execution time: 0.0325
DEBUG - 2022-04-28 17:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:30:16 --> Total execution time: 0.8241
DEBUG - 2022-04-28 17:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:30:18 --> Total execution time: 0.0294
DEBUG - 2022-04-28 17:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:30:18 --> Total execution time: 0.0712
DEBUG - 2022-04-28 17:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:30:33 --> Total execution time: 0.0292
DEBUG - 2022-04-28 17:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:33:50 --> Total execution time: 0.8291
DEBUG - 2022-04-28 17:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:33:52 --> Total execution time: 0.0887
DEBUG - 2022-04-28 17:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:33:52 --> Total execution time: 0.0329
DEBUG - 2022-04-28 17:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-28 17:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-28 17:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-28 17:34:15 --> Total execution time: 0.8101
