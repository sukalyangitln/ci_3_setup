<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-07 13:53:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 13:53:24 --> No URI present. Default controller set.
DEBUG - 2023-01-07 13:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 13:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 13:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 18:23:24 --> Total execution time: 0.1869
DEBUG - 2023-01-07 13:53:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 13:53:24 --> No URI present. Default controller set.
DEBUG - 2023-01-07 13:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 13:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 13:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 18:23:25 --> Total execution time: 0.0830
DEBUG - 2023-01-07 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 13:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 13:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 13:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 18:25:00 --> Total execution time: 0.0539
DEBUG - 2023-01-07 13:55:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 13:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 13:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 13:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 18:25:19 --> Total execution time: 0.0533
DEBUG - 2023-01-07 14:41:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 14:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 14:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 14:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:11:06 --> Total execution time: 0.0540
DEBUG - 2023-01-07 14:43:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 14:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 14:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 14:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:13:30 --> Total execution time: 0.0644
DEBUG - 2023-01-07 14:43:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 14:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 14:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 14:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:13:32 --> Total execution time: 0.0870
DEBUG - 2023-01-07 14:43:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 14:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 14:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 14:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:13:45 --> Total execution time: 0.0679
DEBUG - 2023-01-07 14:43:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 14:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 14:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 14:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:13:47 --> Total execution time: 0.0789
DEBUG - 2023-01-07 15:03:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:33:17 --> Total execution time: 0.0804
DEBUG - 2023-01-07 15:03:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:33:20 --> Total execution time: 0.0579
DEBUG - 2023-01-07 15:09:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:39:16 --> Total execution time: 0.0629
DEBUG - 2023-01-07 15:09:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:39:24 --> Total execution time: 0.0707
DEBUG - 2023-01-07 15:09:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:39:27 --> Total execution time: 0.0445
DEBUG - 2023-01-07 15:09:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:39:27 --> Total execution time: 0.0487
DEBUG - 2023-01-07 15:09:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 15:09:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:39:32 --> Total execution time: 0.0481
DEBUG - 2023-01-07 15:09:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:39:39 --> Total execution time: 0.0542
DEBUG - 2023-01-07 15:09:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:39:55 --> Total execution time: 0.0520
DEBUG - 2023-01-07 15:09:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:39:58 --> Total execution time: 0.0929
DEBUG - 2023-01-07 15:10:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:40:03 --> Total execution time: 0.0745
DEBUG - 2023-01-07 15:24:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:54:40 --> Total execution time: 0.0725
DEBUG - 2023-01-07 15:24:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:54:42 --> Total execution time: 0.0811
DEBUG - 2023-01-07 15:24:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:54:44 --> Total execution time: 0.0875
DEBUG - 2023-01-07 15:24:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:54:45 --> Total execution time: 0.0807
DEBUG - 2023-01-07 15:24:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:54:46 --> Total execution time: 0.2638
DEBUG - 2023-01-07 15:24:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:54:46 --> Total execution time: 0.0862
DEBUG - 2023-01-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:24:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:24:55 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:24:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:24:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:24:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:54:58 --> Total execution time: 0.0931
DEBUG - 2023-01-07 15:25:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:55:00 --> Total execution time: 0.0903
DEBUG - 2023-01-07 15:25:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:55:53 --> Total execution time: 0.0614
DEBUG - 2023-01-07 15:25:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:25:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:25:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:25:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:25:53 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:25:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:25:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:25:54 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:25:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:55:56 --> Total execution time: 0.0812
DEBUG - 2023-01-07 15:26:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:56:05 --> Total execution time: 0.0804
DEBUG - 2023-01-07 15:26:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:56:33 --> Total execution time: 0.0995
DEBUG - 2023-01-07 15:26:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:26:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:26:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:26:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:26:34 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:26:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:26:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:26:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:26:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:56:35 --> Total execution time: 0.0987
DEBUG - 2023-01-07 15:26:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:56:36 --> Total execution time: 0.0933
DEBUG - 2023-01-07 15:26:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:56:38 --> Total execution time: 0.0857
DEBUG - 2023-01-07 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:56:43 --> Total execution time: 0.0887
DEBUG - 2023-01-07 15:26:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:56:56 --> Total execution time: 0.1132
DEBUG - 2023-01-07 15:28:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:18 --> Total execution time: 0.0684
DEBUG - 2023-01-07 15:28:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:28:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:28:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:28:18 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:28:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:28:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:28:18 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:28:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:19 --> Total execution time: 0.1337
DEBUG - 2023-01-07 15:28:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:20 --> Total execution time: 0.0884
DEBUG - 2023-01-07 15:28:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:21 --> Total execution time: 0.0933
DEBUG - 2023-01-07 15:28:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:21 --> Total execution time: 0.1269
DEBUG - 2023-01-07 15:28:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:22 --> Total execution time: 0.0914
DEBUG - 2023-01-07 15:28:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:23 --> Total execution time: 0.0830
DEBUG - 2023-01-07 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:24 --> Total execution time: 0.0925
DEBUG - 2023-01-07 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:24 --> Total execution time: 0.0989
DEBUG - 2023-01-07 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:25 --> Total execution time: 0.0588
DEBUG - 2023-01-07 15:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:28:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:28:26 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:28:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:28:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:28:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:27 --> Total execution time: 0.1085
DEBUG - 2023-01-07 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 19:58:27 --> Total execution time: 0.1033
DEBUG - 2023-01-07 15:35:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:21 --> Total execution time: 0.0664
DEBUG - 2023-01-07 15:35:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:25 --> Total execution time: 0.0851
DEBUG - 2023-01-07 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:26 --> Total execution time: 0.0761
DEBUG - 2023-01-07 15:35:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:28 --> Total execution time: 0.0543
DEBUG - 2023-01-07 15:35:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:30 --> Total execution time: 0.0843
DEBUG - 2023-01-07 15:35:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:34 --> Total execution time: 0.0927
DEBUG - 2023-01-07 15:35:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:35:37 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:35:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:35:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:35:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:35:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:35:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:41 --> Total execution time: 0.0688
DEBUG - 2023-01-07 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:35:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:35:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:35:42 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:35:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:35:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:35:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:35:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:46 --> Total execution time: 0.0884
DEBUG - 2023-01-07 15:35:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:05:49 --> Total execution time: 0.0962
DEBUG - 2023-01-07 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:07:08 --> Total execution time: 0.0712
DEBUG - 2023-01-07 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:37:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:37:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:37:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:37:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:08:09 --> Total execution time: 0.0716
DEBUG - 2023-01-07 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:09 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:38:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:08:19 --> Total execution time: 0.0991
DEBUG - 2023-01-07 15:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:08:21 --> Total execution time: 0.0666
DEBUG - 2023-01-07 15:38:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:22 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:38:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:08:34 --> Total execution time: 0.0915
DEBUG - 2023-01-07 15:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:08:42 --> Total execution time: 0.0818
DEBUG - 2023-01-07 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:08:44 --> Total execution time: 0.0780
DEBUG - 2023-01-07 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:44 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-07 15:38:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-07 15:38:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-07 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:08:46 --> Total execution time: 0.1013
DEBUG - 2023-01-07 15:38:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-07 15:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-07 15:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-07 15:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-07 20:08:48 --> Total execution time: 0.0799
