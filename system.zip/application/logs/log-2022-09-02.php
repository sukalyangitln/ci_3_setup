<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-09-02 00:00:44 --> Total execution time: 0.0592
DEBUG - 2022-09-02 00:05:28 --> Total execution time: 0.3675
DEBUG - 2022-09-02 00:13:10 --> Total execution time: 0.1346
DEBUG - 2022-09-02 00:14:03 --> Total execution time: 0.0965
DEBUG - 2022-09-02 00:16:21 --> Total execution time: 0.1120
DEBUG - 2022-09-02 00:18:44 --> Total execution time: 0.1143
DEBUG - 2022-09-02 00:22:52 --> Total execution time: 0.1653
DEBUG - 2022-09-02 00:27:59 --> Total execution time: 2.3488
DEBUG - 2022-09-02 00:29:25 --> Total execution time: 0.2454
DEBUG - 2022-09-02 00:30:02 --> Total execution time: 0.2268
DEBUG - 2022-09-02 00:38:38 --> Total execution time: 0.1438
DEBUG - 2022-09-02 01:04:57 --> Total execution time: 0.2906
DEBUG - 2022-09-02 01:26:02 --> Total execution time: 0.4091
DEBUG - 2022-09-02 01:26:04 --> Total execution time: 0.0912
DEBUG - 2022-09-02 01:26:19 --> Total execution time: 0.0987
DEBUG - 2022-09-02 01:27:12 --> Total execution time: 0.0946
DEBUG - 2022-09-02 01:30:02 --> Total execution time: 0.1616
DEBUG - 2022-09-02 01:34:45 --> Total execution time: 0.1158
DEBUG - 2022-09-02 02:14:45 --> Total execution time: 0.3354
DEBUG - 2022-09-02 02:30:18 --> Total execution time: 0.2040
DEBUG - 2022-09-02 02:38:27 --> Total execution time: 0.1227
DEBUG - 2022-09-02 02:54:46 --> Total execution time: 0.2611
DEBUG - 2022-09-02 02:57:18 --> Total execution time: 0.1010
DEBUG - 2022-09-02 03:23:46 --> Total execution time: 0.3218
DEBUG - 2022-09-02 03:30:02 --> Total execution time: 0.1329
DEBUG - 2022-09-02 03:39:08 --> Total execution time: 0.1399
DEBUG - 2022-09-02 04:18:21 --> Total execution time: 0.2801
DEBUG - 2022-09-02 04:18:23 --> Total execution time: 0.0999
DEBUG - 2022-09-02 04:18:31 --> Total execution time: 0.0985
DEBUG - 2022-09-02 04:19:07 --> Total execution time: 0.0975
DEBUG - 2022-09-02 04:20:19 --> Total execution time: 0.0917
DEBUG - 2022-09-02 04:20:57 --> Total execution time: 0.1608
DEBUG - 2022-09-02 04:21:03 --> Total execution time: 0.0998
DEBUG - 2022-09-02 04:21:11 --> Total execution time: 0.1941
DEBUG - 2022-09-02 04:21:28 --> Total execution time: 0.1095
DEBUG - 2022-09-02 04:30:03 --> Total execution time: 0.1726
DEBUG - 2022-09-02 04:34:27 --> Total execution time: 0.0987
DEBUG - 2022-09-02 04:34:43 --> Total execution time: 0.1043
DEBUG - 2022-09-02 04:34:51 --> Total execution time: 0.1120
DEBUG - 2022-09-02 04:35:02 --> Total execution time: 0.1131
DEBUG - 2022-09-02 04:35:07 --> Total execution time: 0.1748
DEBUG - 2022-09-02 04:35:38 --> Total execution time: 0.1044
DEBUG - 2022-09-02 04:35:38 --> Total execution time: 0.1026
DEBUG - 2022-09-02 04:35:42 --> Total execution time: 0.0976
DEBUG - 2022-09-02 04:36:04 --> Total execution time: 0.1239
DEBUG - 2022-09-02 04:36:15 --> Total execution time: 0.1010
DEBUG - 2022-09-02 04:36:18 --> Total execution time: 0.0977
DEBUG - 2022-09-02 04:36:18 --> Total execution time: 0.0992
DEBUG - 2022-09-02 04:36:35 --> Total execution time: 0.0917
DEBUG - 2022-09-02 04:42:19 --> Total execution time: 0.8878
DEBUG - 2022-09-02 04:50:36 --> Total execution time: 0.7942
DEBUG - 2022-09-02 05:30:03 --> Total execution time: 0.6394
DEBUG - 2022-09-02 05:35:57 --> Total execution time: 0.1239
DEBUG - 2022-09-02 05:38:01 --> Total execution time: 0.1018
DEBUG - 2022-09-02 05:40:23 --> Total execution time: 0.1157
DEBUG - 2022-09-02 05:40:42 --> Total execution time: 0.0640
DEBUG - 2022-09-02 05:41:53 --> Total execution time: 0.0862
DEBUG - 2022-09-02 06:30:03 --> Total execution time: 0.2841
DEBUG - 2022-09-02 06:33:39 --> Total execution time: 0.1168
DEBUG - 2022-09-02 06:33:45 --> Total execution time: 0.0601
DEBUG - 2022-09-02 06:35:29 --> Total execution time: 0.0760
DEBUG - 2022-09-02 06:44:50 --> Total execution time: 0.1368
DEBUG - 2022-09-02 06:44:54 --> Total execution time: 0.0937
DEBUG - 2022-09-02 06:46:53 --> Total execution time: 0.1163
DEBUG - 2022-09-02 06:48:22 --> Total execution time: 0.0646
DEBUG - 2022-09-02 06:51:37 --> Total execution time: 0.1335
DEBUG - 2022-09-02 06:52:17 --> Total execution time: 0.2824
DEBUG - 2022-09-02 06:53:50 --> Total execution time: 0.0748
DEBUG - 2022-09-02 06:54:28 --> Total execution time: 0.1170
DEBUG - 2022-09-02 06:54:49 --> Total execution time: 0.1385
DEBUG - 2022-09-02 06:54:59 --> Total execution time: 0.1696
DEBUG - 2022-09-02 06:55:02 --> Total execution time: 0.1189
DEBUG - 2022-09-02 06:55:11 --> Total execution time: 0.1018
DEBUG - 2022-09-02 06:55:29 --> Total execution time: 0.1135
DEBUG - 2022-09-02 06:55:52 --> Total execution time: 0.0964
DEBUG - 2022-09-02 07:09:52 --> Total execution time: 0.1084
DEBUG - 2022-09-02 07:10:00 --> Total execution time: 0.0921
DEBUG - 2022-09-02 07:10:08 --> Total execution time: 0.0915
DEBUG - 2022-09-02 07:10:12 --> Total execution time: 0.0872
DEBUG - 2022-09-02 07:10:28 --> Total execution time: 0.0961
DEBUG - 2022-09-02 07:10:39 --> Total execution time: 0.1304
DEBUG - 2022-09-02 07:10:44 --> Total execution time: 0.1136
DEBUG - 2022-09-02 07:10:50 --> Total execution time: 0.0938
DEBUG - 2022-09-02 07:10:53 --> Total execution time: 0.1292
DEBUG - 2022-09-02 07:11:05 --> Total execution time: 0.0983
DEBUG - 2022-09-02 07:12:45 --> Total execution time: 0.1029
DEBUG - 2022-09-02 07:13:43 --> Total execution time: 0.0699
DEBUG - 2022-09-02 07:14:30 --> Total execution time: 0.0956
DEBUG - 2022-09-02 07:14:30 --> Total execution time: 0.0587
DEBUG - 2022-09-02 07:14:46 --> Total execution time: 0.0884
DEBUG - 2022-09-02 07:14:48 --> Total execution time: 0.0904
DEBUG - 2022-09-02 07:14:52 --> Total execution time: 0.0958
DEBUG - 2022-09-02 07:16:55 --> Total execution time: 0.1120
DEBUG - 2022-09-02 07:17:13 --> Total execution time: 0.1265
DEBUG - 2022-09-02 07:17:28 --> Total execution time: 0.1098
DEBUG - 2022-09-02 07:17:39 --> Total execution time: 0.1143
DEBUG - 2022-09-02 07:17:52 --> Total execution time: 0.1170
DEBUG - 2022-09-02 07:17:53 --> Total execution time: 0.0918
DEBUG - 2022-09-02 07:18:03 --> Total execution time: 0.1491
DEBUG - 2022-09-02 07:18:11 --> Total execution time: 0.1136
DEBUG - 2022-09-02 07:18:32 --> Total execution time: 0.0982
DEBUG - 2022-09-02 07:18:35 --> Total execution time: 0.0977
DEBUG - 2022-09-02 07:18:40 --> Total execution time: 0.1027
DEBUG - 2022-09-02 07:20:52 --> Total execution time: 0.2615
DEBUG - 2022-09-02 07:22:55 --> Total execution time: 0.1637
DEBUG - 2022-09-02 07:24:13 --> Total execution time: 0.3052
DEBUG - 2022-09-02 07:24:21 --> Total execution time: 0.0971
DEBUG - 2022-09-02 07:30:03 --> Total execution time: 0.2392
DEBUG - 2022-09-02 07:33:43 --> Total execution time: 0.0979
DEBUG - 2022-09-02 07:33:58 --> Total execution time: 0.1077
DEBUG - 2022-09-02 07:34:07 --> Total execution time: 0.1042
DEBUG - 2022-09-02 07:34:08 --> Total execution time: 0.0983
DEBUG - 2022-09-02 07:34:15 --> Total execution time: 0.0960
DEBUG - 2022-09-02 07:34:16 --> Total execution time: 0.1262
DEBUG - 2022-09-02 07:34:36 --> Total execution time: 0.0591
DEBUG - 2022-09-02 07:34:53 --> Total execution time: 0.0971
DEBUG - 2022-09-02 07:35:01 --> Total execution time: 0.1269
DEBUG - 2022-09-02 07:35:12 --> Total execution time: 0.0865
DEBUG - 2022-09-02 07:35:26 --> Total execution time: 0.1116
DEBUG - 2022-09-02 07:35:30 --> Total execution time: 0.0873
DEBUG - 2022-09-02 07:35:45 --> Total execution time: 0.0912
DEBUG - 2022-09-02 07:35:59 --> Total execution time: 0.1078
DEBUG - 2022-09-02 07:36:08 --> Total execution time: 0.1105
DEBUG - 2022-09-02 07:36:13 --> Total execution time: 0.0984
DEBUG - 2022-09-02 07:36:31 --> Total execution time: 0.0956
DEBUG - 2022-09-02 07:36:46 --> Total execution time: 0.1031
DEBUG - 2022-09-02 07:38:06 --> Total execution time: 0.0594
DEBUG - 2022-09-02 07:38:16 --> Total execution time: 0.0578
DEBUG - 2022-09-02 07:38:25 --> Total execution time: 0.0957
DEBUG - 2022-09-02 07:38:32 --> Total execution time: 0.1059
DEBUG - 2022-09-02 07:38:33 --> Total execution time: 0.1017
DEBUG - 2022-09-02 07:38:33 --> Total execution time: 0.0974
DEBUG - 2022-09-02 07:38:41 --> Total execution time: 0.1003
DEBUG - 2022-09-02 07:38:59 --> Total execution time: 0.0929
DEBUG - 2022-09-02 07:39:18 --> Total execution time: 0.1064
DEBUG - 2022-09-02 07:39:47 --> Total execution time: 0.0656
DEBUG - 2022-09-02 07:45:48 --> Total execution time: 0.1637
DEBUG - 2022-09-02 07:52:30 --> Total execution time: 0.1513
DEBUG - 2022-09-02 08:01:54 --> Total execution time: 0.1940
DEBUG - 2022-09-02 08:03:24 --> Total execution time: 0.0684
DEBUG - 2022-09-02 08:05:28 --> Total execution time: 0.0659
DEBUG - 2022-09-02 08:05:31 --> Total execution time: 0.0716
DEBUG - 2022-09-02 08:05:38 --> Total execution time: 0.0742
DEBUG - 2022-09-02 08:05:41 --> Total execution time: 0.1212
DEBUG - 2022-09-02 08:05:45 --> Total execution time: 0.1615
DEBUG - 2022-09-02 08:06:00 --> Total execution time: 0.1079
DEBUG - 2022-09-02 08:06:01 --> Total execution time: 0.1269
DEBUG - 2022-09-02 08:06:05 --> Total execution time: 0.1058
DEBUG - 2022-09-02 08:06:10 --> Total execution time: 0.1084
DEBUG - 2022-09-02 08:06:13 --> Total execution time: 0.1001
DEBUG - 2022-09-02 08:06:27 --> Total execution time: 0.1051
DEBUG - 2022-09-02 08:06:32 --> Total execution time: 0.1006
DEBUG - 2022-09-02 08:11:33 --> Total execution time: 0.1448
DEBUG - 2022-09-02 08:11:34 --> Total execution time: 0.0664
DEBUG - 2022-09-02 08:11:38 --> Total execution time: 0.0634
DEBUG - 2022-09-02 08:11:44 --> Total execution time: 0.1047
DEBUG - 2022-09-02 08:11:51 --> Total execution time: 0.1558
DEBUG - 2022-09-02 08:12:33 --> Total execution time: 0.1683
DEBUG - 2022-09-02 08:17:33 --> Total execution time: 0.3379
DEBUG - 2022-09-02 08:17:36 --> Total execution time: 0.1744
DEBUG - 2022-09-02 08:18:25 --> Total execution time: 0.0934
DEBUG - 2022-09-02 08:21:39 --> Total execution time: 0.1032
DEBUG - 2022-09-02 08:22:14 --> Total execution time: 0.2621
DEBUG - 2022-09-02 08:22:24 --> Total execution time: 0.1073
DEBUG - 2022-09-02 08:22:38 --> Total execution time: 0.0946
DEBUG - 2022-09-02 08:30:03 --> Total execution time: 0.3600
DEBUG - 2022-09-02 08:30:26 --> Total execution time: 0.1449
DEBUG - 2022-09-02 08:30:36 --> Total execution time: 0.1161
DEBUG - 2022-09-02 08:30:43 --> Total execution time: 0.0919
DEBUG - 2022-09-02 08:30:51 --> Total execution time: 0.1174
DEBUG - 2022-09-02 08:30:55 --> Total execution time: 0.0998
DEBUG - 2022-09-02 08:31:00 --> Total execution time: 0.1076
DEBUG - 2022-09-02 08:31:05 --> Total execution time: 0.1065
DEBUG - 2022-09-02 08:31:13 --> Total execution time: 0.0974
DEBUG - 2022-09-02 08:36:04 --> Total execution time: 0.1399
DEBUG - 2022-09-02 08:36:42 --> Total execution time: 0.0741
DEBUG - 2022-09-02 08:37:09 --> Total execution time: 0.0933
DEBUG - 2022-09-02 08:37:20 --> Total execution time: 0.0912
DEBUG - 2022-09-02 08:37:39 --> Total execution time: 0.0973
DEBUG - 2022-09-02 08:38:50 --> Total execution time: 0.1023
DEBUG - 2022-09-02 08:38:59 --> Total execution time: 0.1117
DEBUG - 2022-09-02 08:39:31 --> Total execution time: 0.0855
DEBUG - 2022-09-02 08:39:38 --> Total execution time: 0.0909
DEBUG - 2022-09-02 08:39:42 --> Total execution time: 0.1024
DEBUG - 2022-09-02 08:39:46 --> Total execution time: 0.1445
DEBUG - 2022-09-02 08:42:38 --> Total execution time: 0.1215
DEBUG - 2022-09-02 08:42:46 --> Total execution time: 0.1263
DEBUG - 2022-09-02 08:43:00 --> Total execution time: 0.1026
DEBUG - 2022-09-02 08:43:13 --> Total execution time: 0.1400
DEBUG - 2022-09-02 08:43:25 --> Total execution time: 0.1357
DEBUG - 2022-09-02 08:43:36 --> Total execution time: 0.1248
DEBUG - 2022-09-02 08:43:37 --> Total execution time: 0.0965
DEBUG - 2022-09-02 08:43:47 --> Total execution time: 0.0631
DEBUG - 2022-09-02 08:43:57 --> Total execution time: 0.0621
DEBUG - 2022-09-02 08:44:05 --> Total execution time: 0.0609
DEBUG - 2022-09-02 08:44:21 --> Total execution time: 0.0954
DEBUG - 2022-09-02 08:45:13 --> Total execution time: 0.0622
DEBUG - 2022-09-02 08:45:15 --> Total execution time: 0.1200
DEBUG - 2022-09-02 08:45:20 --> Total execution time: 0.0963
DEBUG - 2022-09-02 08:45:30 --> Total execution time: 0.1017
DEBUG - 2022-09-02 08:45:40 --> Total execution time: 0.1004
DEBUG - 2022-09-02 08:45:46 --> Total execution time: 0.1027
DEBUG - 2022-09-02 08:45:52 --> Total execution time: 0.1255
DEBUG - 2022-09-02 08:45:56 --> Total execution time: 0.0939
DEBUG - 2022-09-02 08:46:41 --> Total execution time: 0.0991
DEBUG - 2022-09-02 08:46:58 --> Total execution time: 0.1110
DEBUG - 2022-09-02 08:47:09 --> Total execution time: 0.1059
DEBUG - 2022-09-02 08:47:17 --> Total execution time: 0.1124
DEBUG - 2022-09-02 08:47:18 --> Total execution time: 0.1141
DEBUG - 2022-09-02 08:47:26 --> Total execution time: 0.1084
DEBUG - 2022-09-02 08:47:29 --> Total execution time: 0.1033
DEBUG - 2022-09-02 08:47:32 --> Total execution time: 0.1018
DEBUG - 2022-09-02 08:47:46 --> Total execution time: 0.0921
DEBUG - 2022-09-02 08:47:57 --> Total execution time: 0.0582
DEBUG - 2022-09-02 08:48:05 --> Total execution time: 0.0673
DEBUG - 2022-09-02 08:48:23 --> Total execution time: 0.2631
DEBUG - 2022-09-02 08:48:31 --> Total execution time: 0.0678
DEBUG - 2022-09-02 08:52:00 --> Total execution time: 0.1664
DEBUG - 2022-09-02 08:53:32 --> Total execution time: 0.0628
DEBUG - 2022-09-02 08:53:34 --> Total execution time: 0.1106
DEBUG - 2022-09-02 08:53:41 --> Total execution time: 0.1020
DEBUG - 2022-09-02 08:53:42 --> Total execution time: 0.1179
DEBUG - 2022-09-02 08:53:46 --> Total execution time: 0.1107
DEBUG - 2022-09-02 08:53:48 --> Total execution time: 0.1088
DEBUG - 2022-09-02 08:53:50 --> Total execution time: 0.1016
DEBUG - 2022-09-02 08:53:53 --> Total execution time: 0.0925
DEBUG - 2022-09-02 08:53:55 --> Total execution time: 0.1277
DEBUG - 2022-09-02 08:55:26 --> Total execution time: 0.2735
DEBUG - 2022-09-02 08:55:30 --> Total execution time: 0.2659
DEBUG - 2022-09-02 08:55:53 --> Total execution time: 0.1125
DEBUG - 2022-09-02 08:56:00 --> Total execution time: 0.0869
DEBUG - 2022-09-02 09:00:43 --> Total execution time: 0.1837
DEBUG - 2022-09-02 09:02:24 --> Total execution time: 0.2804
DEBUG - 2022-09-02 09:02:25 --> Total execution time: 0.3413
DEBUG - 2022-09-02 09:02:26 --> Total execution time: 0.0928
DEBUG - 2022-09-02 09:02:28 --> Total execution time: 0.1076
DEBUG - 2022-09-02 09:05:27 --> Total execution time: 0.3649
DEBUG - 2022-09-02 09:05:27 --> Total execution time: 0.0988
DEBUG - 2022-09-02 09:05:39 --> Total execution time: 0.1199
DEBUG - 2022-09-02 09:05:43 --> Total execution time: 0.1082
DEBUG - 2022-09-02 09:06:05 --> Total execution time: 0.0991
DEBUG - 2022-09-02 09:07:08 --> Total execution time: 0.1030
DEBUG - 2022-09-02 09:11:22 --> Total execution time: 0.1137
DEBUG - 2022-09-02 09:12:19 --> Total execution time: 0.1023
DEBUG - 2022-09-02 09:12:23 --> Total execution time: 0.1019
DEBUG - 2022-09-02 09:12:47 --> Total execution time: 0.1089
DEBUG - 2022-09-02 09:12:55 --> Total execution time: 0.0630
DEBUG - 2022-09-02 09:13:00 --> Total execution time: 0.0879
DEBUG - 2022-09-02 09:13:20 --> Total execution time: 0.1212
DEBUG - 2022-09-02 09:13:25 --> Total execution time: 0.1012
DEBUG - 2022-09-02 09:13:33 --> Total execution time: 0.1341
DEBUG - 2022-09-02 09:14:04 --> Total execution time: 0.1237
DEBUG - 2022-09-02 09:14:11 --> Total execution time: 0.1088
DEBUG - 2022-09-02 09:14:14 --> Total execution time: 0.1018
DEBUG - 2022-09-02 09:14:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-02 09:14:34 --> Total execution time: 0.0955
DEBUG - 2022-09-02 09:14:43 --> Total execution time: 0.0958
DEBUG - 2022-09-02 09:15:00 --> Total execution time: 0.1217
DEBUG - 2022-09-02 09:15:07 --> Total execution time: 0.0963
DEBUG - 2022-09-02 09:15:29 --> Total execution time: 0.1580
DEBUG - 2022-09-02 09:16:38 --> Total execution time: 0.1020
DEBUG - 2022-09-02 09:16:55 --> Total execution time: 0.1062
DEBUG - 2022-09-02 09:17:01 --> Total execution time: 0.1018
DEBUG - 2022-09-02 09:20:38 --> Total execution time: 0.0641
DEBUG - 2022-09-02 09:20:39 --> Total execution time: 0.0684
DEBUG - 2022-09-02 09:20:43 --> Total execution time: 0.0529
DEBUG - 2022-09-02 09:21:15 --> Total execution time: 0.1110
DEBUG - 2022-09-02 09:21:31 --> Total execution time: 0.1328
DEBUG - 2022-09-02 09:21:41 --> Total execution time: 0.1034
DEBUG - 2022-09-02 09:21:51 --> Total execution time: 0.1427
DEBUG - 2022-09-02 09:21:55 --> Total execution time: 0.1015
DEBUG - 2022-09-02 09:22:07 --> Total execution time: 0.1523
DEBUG - 2022-09-02 09:22:23 --> Total execution time: 0.1370
DEBUG - 2022-09-02 09:22:31 --> Total execution time: 0.0964
DEBUG - 2022-09-02 09:25:17 --> Total execution time: 0.0954
DEBUG - 2022-09-02 09:25:58 --> Total execution time: 0.3237
DEBUG - 2022-09-02 09:26:45 --> Total execution time: 0.0672
DEBUG - 2022-09-02 09:27:17 --> Total execution time: 0.0584
DEBUG - 2022-09-02 09:27:27 --> Total execution time: 0.0910
DEBUG - 2022-09-02 09:27:43 --> Total execution time: 0.1481
DEBUG - 2022-09-02 09:28:14 --> Total execution time: 0.0910
DEBUG - 2022-09-02 09:28:22 --> Total execution time: 0.0657
DEBUG - 2022-09-02 09:29:42 --> Total execution time: 0.0634
DEBUG - 2022-09-02 09:29:48 --> Total execution time: 0.0698
DEBUG - 2022-09-02 09:29:58 --> Total execution time: 0.0946
DEBUG - 2022-09-02 09:30:02 --> Total execution time: 0.1209
DEBUG - 2022-09-02 09:30:02 --> Total execution time: 0.1391
DEBUG - 2022-09-02 09:30:10 --> Total execution time: 0.1360
DEBUG - 2022-09-02 09:30:18 --> Total execution time: 0.0944
DEBUG - 2022-09-02 09:31:04 --> Total execution time: 0.0971
DEBUG - 2022-09-02 09:31:08 --> Total execution time: 0.0603
DEBUG - 2022-09-02 09:31:18 --> Total execution time: 0.1130
DEBUG - 2022-09-02 09:31:22 --> Total execution time: 0.0984
DEBUG - 2022-09-02 09:31:27 --> Total execution time: 0.1058
DEBUG - 2022-09-02 09:31:39 --> Total execution time: 0.0961
DEBUG - 2022-09-02 09:32:12 --> Total execution time: 0.0931
DEBUG - 2022-09-02 09:32:40 --> Total execution time: 0.1225
DEBUG - 2022-09-02 09:32:45 --> Total execution time: 0.1074
DEBUG - 2022-09-02 09:33:09 --> Total execution time: 0.1025
DEBUG - 2022-09-02 09:33:51 --> Total execution time: 0.0924
DEBUG - 2022-09-02 09:34:24 --> Total execution time: 0.0597
DEBUG - 2022-09-02 09:35:12 --> Total execution time: 0.1054
DEBUG - 2022-09-02 09:35:20 --> Total execution time: 0.1316
DEBUG - 2022-09-02 09:35:31 --> Total execution time: 0.1395
DEBUG - 2022-09-02 09:36:01 --> Total execution time: 0.1064
DEBUG - 2022-09-02 09:36:19 --> Total execution time: 0.0998
DEBUG - 2022-09-02 09:36:40 --> Total execution time: 0.1061
DEBUG - 2022-09-02 09:36:57 --> Total execution time: 0.1070
DEBUG - 2022-09-02 09:37:09 --> Total execution time: 0.1018
DEBUG - 2022-09-02 09:37:31 --> Total execution time: 0.1693
DEBUG - 2022-09-02 09:37:34 --> Total execution time: 0.0706
DEBUG - 2022-09-02 09:37:56 --> Total execution time: 0.1009
DEBUG - 2022-09-02 09:38:18 --> Total execution time: 0.1067
DEBUG - 2022-09-02 09:38:43 --> Total execution time: 0.1130
DEBUG - 2022-09-02 09:38:55 --> Total execution time: 0.1058
DEBUG - 2022-09-02 09:39:16 --> Total execution time: 0.1062
DEBUG - 2022-09-02 09:54:21 --> Total execution time: 0.4589
DEBUG - 2022-09-02 09:54:22 --> Total execution time: 0.0793
DEBUG - 2022-09-02 09:54:33 --> Total execution time: 0.0884
DEBUG - 2022-09-02 09:54:46 --> Total execution time: 0.0987
DEBUG - 2022-09-02 09:55:04 --> Total execution time: 0.1179
DEBUG - 2022-09-02 09:55:14 --> Total execution time: 0.1238
DEBUG - 2022-09-02 09:55:17 --> Total execution time: 0.1539
DEBUG - 2022-09-02 09:55:28 --> Total execution time: 0.1744
DEBUG - 2022-09-02 09:55:28 --> Total execution time: 0.1800
DEBUG - 2022-09-02 09:55:28 --> Total execution time: 0.1336
DEBUG - 2022-09-02 09:55:29 --> Total execution time: 0.1320
DEBUG - 2022-09-02 09:55:29 --> Total execution time: 0.1248
DEBUG - 2022-09-02 09:55:29 --> Total execution time: 0.1329
DEBUG - 2022-09-02 09:55:30 --> Total execution time: 0.1256
DEBUG - 2022-09-02 09:55:35 --> Total execution time: 0.1566
DEBUG - 2022-09-02 09:55:49 --> Total execution time: 0.1264
DEBUG - 2022-09-02 09:55:50 --> Total execution time: 0.1319
DEBUG - 2022-09-02 10:01:27 --> Total execution time: 0.1315
DEBUG - 2022-09-02 10:01:28 --> Total execution time: 0.2497
DEBUG - 2022-09-02 10:01:32 --> Total execution time: 0.0983
DEBUG - 2022-09-02 10:01:42 --> Total execution time: 0.1319
DEBUG - 2022-09-02 10:01:52 --> Total execution time: 0.0991
DEBUG - 2022-09-02 10:05:34 --> Total execution time: 0.2578
DEBUG - 2022-09-02 10:06:07 --> Total execution time: 0.2512
DEBUG - 2022-09-02 10:06:08 --> Total execution time: 0.0938
DEBUG - 2022-09-02 10:06:08 --> Total execution time: 0.0950
DEBUG - 2022-09-02 10:06:29 --> Total execution time: 2.4917
DEBUG - 2022-09-02 10:07:32 --> Total execution time: 0.1074
DEBUG - 2022-09-02 10:08:23 --> Total execution time: 0.0787
DEBUG - 2022-09-02 10:08:24 --> Total execution time: 0.0652
DEBUG - 2022-09-02 10:08:45 --> Total execution time: 0.0773
DEBUG - 2022-09-02 10:08:56 --> Total execution time: 0.1027
DEBUG - 2022-09-02 10:08:57 --> Total execution time: 0.0726
DEBUG - 2022-09-02 10:09:00 --> Total execution time: 0.1366
DEBUG - 2022-09-02 10:09:06 --> Total execution time: 1.8703
DEBUG - 2022-09-02 10:09:09 --> Total execution time: 0.1445
DEBUG - 2022-09-02 10:09:16 --> Total execution time: 0.0958
DEBUG - 2022-09-02 10:09:20 --> Total execution time: 0.0965
DEBUG - 2022-09-02 10:09:21 --> Total execution time: 0.1207
DEBUG - 2022-09-02 10:09:23 --> Total execution time: 0.1080
DEBUG - 2022-09-02 10:09:27 --> Total execution time: 0.0561
DEBUG - 2022-09-02 10:09:30 --> Total execution time: 0.0907
DEBUG - 2022-09-02 10:09:33 --> Total execution time: 0.1226
DEBUG - 2022-09-02 10:09:33 --> Total execution time: 0.1285
DEBUG - 2022-09-02 10:09:42 --> Total execution time: 0.2530
DEBUG - 2022-09-02 10:09:59 --> Total execution time: 0.0627
DEBUG - 2022-09-02 10:10:09 --> Total execution time: 0.1045
DEBUG - 2022-09-02 10:10:17 --> Total execution time: 0.1133
DEBUG - 2022-09-02 10:10:24 --> Total execution time: 0.0936
DEBUG - 2022-09-02 10:10:24 --> Total execution time: 0.0969
DEBUG - 2022-09-02 10:10:34 --> Total execution time: 0.2450
DEBUG - 2022-09-02 10:10:35 --> Total execution time: 0.1247
DEBUG - 2022-09-02 10:10:46 --> Total execution time: 0.1012
DEBUG - 2022-09-02 10:10:52 --> Total execution time: 0.1261
DEBUG - 2022-09-02 10:11:05 --> Total execution time: 0.1025
DEBUG - 2022-09-02 10:11:10 --> Total execution time: 0.1272
DEBUG - 2022-09-02 10:11:23 --> Total execution time: 0.0968
DEBUG - 2022-09-02 10:11:39 --> Total execution time: 0.1013
DEBUG - 2022-09-02 10:12:16 --> Total execution time: 0.1089
DEBUG - 2022-09-02 10:12:42 --> Total execution time: 0.0928
DEBUG - 2022-09-02 10:13:22 --> Total execution time: 0.0778
DEBUG - 2022-09-02 10:13:25 --> Total execution time: 0.0698
DEBUG - 2022-09-02 10:14:10 --> Total execution time: 0.1127
DEBUG - 2022-09-02 10:14:34 --> Total execution time: 0.0937
DEBUG - 2022-09-02 10:14:52 --> Total execution time: 0.0997
DEBUG - 2022-09-02 10:14:54 --> Total execution time: 0.1396
DEBUG - 2022-09-02 10:15:27 --> Total execution time: 0.0659
DEBUG - 2022-09-02 10:15:56 --> Total execution time: 0.0958
DEBUG - 2022-09-02 10:17:01 --> Total execution time: 0.3054
DEBUG - 2022-09-02 10:17:01 --> Total execution time: 0.0988
DEBUG - 2022-09-02 10:17:08 --> Total execution time: 0.1087
DEBUG - 2022-09-02 10:17:49 --> Total execution time: 0.0657
DEBUG - 2022-09-02 10:17:50 --> Total execution time: 0.0545
DEBUG - 2022-09-02 10:17:57 --> Total execution time: 0.0583
DEBUG - 2022-09-02 10:18:30 --> Total execution time: 0.1069
DEBUG - 2022-09-02 10:18:31 --> Total execution time: 0.0919
DEBUG - 2022-09-02 10:18:31 --> Total execution time: 0.1583
DEBUG - 2022-09-02 10:18:31 --> Total execution time: 0.0926
DEBUG - 2022-09-02 10:18:31 --> Total execution time: 0.0941
DEBUG - 2022-09-02 10:18:31 --> Total execution time: 0.0913
DEBUG - 2022-09-02 10:18:32 --> Total execution time: 0.1041
DEBUG - 2022-09-02 10:18:32 --> Total execution time: 0.1000
DEBUG - 2022-09-02 10:18:33 --> Total execution time: 0.0942
DEBUG - 2022-09-02 10:18:33 --> Total execution time: 0.0960
DEBUG - 2022-09-02 10:18:33 --> Total execution time: 0.0970
DEBUG - 2022-09-02 10:18:34 --> Total execution time: 0.0970
DEBUG - 2022-09-02 10:18:34 --> Total execution time: 0.2011
DEBUG - 2022-09-02 10:18:34 --> Total execution time: 0.1363
DEBUG - 2022-09-02 10:18:34 --> Total execution time: 0.0957
DEBUG - 2022-09-02 10:18:34 --> Total execution time: 0.2162
DEBUG - 2022-09-02 10:18:39 --> Total execution time: 0.0937
DEBUG - 2022-09-02 10:18:47 --> Total execution time: 0.1308
DEBUG - 2022-09-02 10:18:47 --> Total execution time: 0.0945
DEBUG - 2022-09-02 10:18:48 --> Total execution time: 0.0997
DEBUG - 2022-09-02 10:18:48 --> Total execution time: 0.1033
DEBUG - 2022-09-02 10:18:48 --> Total execution time: 0.1373
DEBUG - 2022-09-02 10:18:48 --> Total execution time: 0.1538
DEBUG - 2022-09-02 10:18:49 --> Total execution time: 0.1030
DEBUG - 2022-09-02 10:18:58 --> Total execution time: 0.0918
DEBUG - 2022-09-02 10:19:02 --> Total execution time: 0.2472
DEBUG - 2022-09-02 10:19:11 --> Total execution time: 0.1023
DEBUG - 2022-09-02 10:19:12 --> Total execution time: 0.1017
DEBUG - 2022-09-02 10:19:26 --> Total execution time: 0.0967
DEBUG - 2022-09-02 10:19:31 --> Total execution time: 0.1290
DEBUG - 2022-09-02 10:19:35 --> Total execution time: 0.1031
DEBUG - 2022-09-02 10:19:45 --> Total execution time: 0.2520
DEBUG - 2022-09-02 10:19:47 --> Total execution time: 0.0968
DEBUG - 2022-09-02 10:19:53 --> Total execution time: 0.1023
DEBUG - 2022-09-02 10:19:55 --> Total execution time: 0.1211
DEBUG - 2022-09-02 10:20:03 --> Total execution time: 0.0994
DEBUG - 2022-09-02 10:20:07 --> Total execution time: 0.1473
DEBUG - 2022-09-02 10:20:09 --> Total execution time: 0.1494
DEBUG - 2022-09-02 10:20:12 --> Total execution time: 0.1096
DEBUG - 2022-09-02 10:20:12 --> Total execution time: 0.0956
DEBUG - 2022-09-02 10:20:14 --> Total execution time: 0.1121
DEBUG - 2022-09-02 10:21:05 --> Total execution time: 0.1038
DEBUG - 2022-09-02 10:21:10 --> Total execution time: 0.0614
DEBUG - 2022-09-02 10:21:14 --> Total execution time: 0.1041
DEBUG - 2022-09-02 10:21:15 --> Total execution time: 0.1172
DEBUG - 2022-09-02 10:22:48 --> Total execution time: 0.0977
DEBUG - 2022-09-02 10:22:58 --> Total execution time: 0.1045
DEBUG - 2022-09-02 10:25:35 --> Total execution time: 0.3264
DEBUG - 2022-09-02 10:25:52 --> Total execution time: 0.1505
DEBUG - 2022-09-02 10:26:56 --> Total execution time: 0.2069
DEBUG - 2022-09-02 10:28:06 --> Total execution time: 0.1049
DEBUG - 2022-09-02 10:28:22 --> Total execution time: 0.1313
DEBUG - 2022-09-02 10:28:39 --> Total execution time: 0.0766
DEBUG - 2022-09-02 10:28:40 --> Total execution time: 0.0849
DEBUG - 2022-09-02 10:28:46 --> Total execution time: 0.0622
DEBUG - 2022-09-02 10:28:54 --> Total execution time: 0.1160
DEBUG - 2022-09-02 10:29:10 --> Total execution time: 0.1075
DEBUG - 2022-09-02 10:29:14 --> Total execution time: 0.1374
DEBUG - 2022-09-02 10:29:20 --> Total execution time: 0.0989
DEBUG - 2022-09-02 10:29:27 --> Total execution time: 0.1071
DEBUG - 2022-09-02 10:29:34 --> Total execution time: 0.0633
DEBUG - 2022-09-02 10:29:52 --> Total execution time: 0.1041
DEBUG - 2022-09-02 00:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:30:00 --> Total execution time: 0.1121
DEBUG - 2022-09-02 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:30:02 --> Total execution time: 0.1210
DEBUG - 2022-09-02 00:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:30:10 --> Total execution time: 0.1306
DEBUG - 2022-09-02 00:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:30:17 --> Total execution time: 0.1023
DEBUG - 2022-09-02 00:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:30:22 --> Total execution time: 0.1013
DEBUG - 2022-09-02 00:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:30:26 --> Total execution time: 0.1566
DEBUG - 2022-09-02 00:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:30:49 --> Total execution time: 0.2962
DEBUG - 2022-09-02 00:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:31:43 --> Total execution time: 0.1249
DEBUG - 2022-09-02 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:31:50 --> Total execution time: 0.1300
DEBUG - 2022-09-02 00:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:31:59 --> Total execution time: 0.2528
DEBUG - 2022-09-02 00:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:02 --> Total execution time: 0.1460
DEBUG - 2022-09-02 00:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:07 --> Total execution time: 0.1449
DEBUG - 2022-09-02 00:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:11 --> Total execution time: 0.1064
DEBUG - 2022-09-02 00:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:13 --> Total execution time: 0.1332
DEBUG - 2022-09-02 00:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:17 --> Total execution time: 0.0929
DEBUG - 2022-09-02 00:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:21 --> Total execution time: 0.0995
DEBUG - 2022-09-02 00:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:25 --> Total execution time: 0.1236
DEBUG - 2022-09-02 00:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:25 --> Total execution time: 0.1218
DEBUG - 2022-09-02 00:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:39 --> Total execution time: 0.0994
DEBUG - 2022-09-02 00:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:32:45 --> Total execution time: 0.2103
DEBUG - 2022-09-02 00:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:03:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:33:00 --> Total execution time: 0.0688
DEBUG - 2022-09-02 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:33:02 --> Total execution time: 0.0913
DEBUG - 2022-09-02 00:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:03:18 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:33:18 --> Total execution time: 0.0972
DEBUG - 2022-09-02 00:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:03:30 --> Total execution time: 0.1189
DEBUG - 2022-09-02 00:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:03:32 --> Total execution time: 0.1006
DEBUG - 2022-09-02 00:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:03:32 --> Total execution time: 0.1154
DEBUG - 2022-09-02 00:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:34:17 --> Total execution time: 0.2876
DEBUG - 2022-09-02 00:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:34:20 --> Total execution time: 0.1044
DEBUG - 2022-09-02 00:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:35:33 --> Total execution time: 2.5425
DEBUG - 2022-09-02 00:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 00:05:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 00:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:35:56 --> Total execution time: 0.0947
DEBUG - 2022-09-02 00:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:36:13 --> Total execution time: 0.1002
DEBUG - 2022-09-02 00:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:36:15 --> Total execution time: 0.3002
DEBUG - 2022-09-02 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:36:36 --> Total execution time: 0.0977
DEBUG - 2022-09-02 00:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:36:51 --> Total execution time: 0.1133
DEBUG - 2022-09-02 00:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:36:55 --> Total execution time: 0.1140
DEBUG - 2022-09-02 00:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:37:03 --> Total execution time: 0.1294
DEBUG - 2022-09-02 00:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:37:10 --> Total execution time: 0.1312
DEBUG - 2022-09-02 00:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:37:54 --> Total execution time: 0.0939
DEBUG - 2022-09-02 00:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:39:38 --> Total execution time: 0.3184
DEBUG - 2022-09-02 00:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:40:51 --> Total execution time: 0.1314
DEBUG - 2022-09-02 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:41:03 --> Total execution time: 0.1073
DEBUG - 2022-09-02 00:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:11:12 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:41:12 --> Total execution time: 0.0766
DEBUG - 2022-09-02 00:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:11:13 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:41:13 --> Total execution time: 0.0574
DEBUG - 2022-09-02 00:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:41:33 --> Total execution time: 0.0750
DEBUG - 2022-09-02 00:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:41:58 --> Total execution time: 0.0977
DEBUG - 2022-09-02 00:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:02 --> Total execution time: 0.0619
DEBUG - 2022-09-02 00:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:17 --> Total execution time: 0.1289
DEBUG - 2022-09-02 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:18 --> Total execution time: 0.2833
DEBUG - 2022-09-02 00:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:28 --> Total execution time: 0.0915
DEBUG - 2022-09-02 00:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:29 --> Total execution time: 0.0949
DEBUG - 2022-09-02 00:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:36 --> Total execution time: 0.1067
DEBUG - 2022-09-02 00:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:42 --> Total execution time: 0.1097
DEBUG - 2022-09-02 00:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:44 --> Total execution time: 0.1043
DEBUG - 2022-09-02 00:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:51 --> Total execution time: 0.1378
DEBUG - 2022-09-02 00:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:52 --> Total execution time: 0.0964
DEBUG - 2022-09-02 00:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:54 --> Total execution time: 0.0934
DEBUG - 2022-09-02 00:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:42:57 --> Total execution time: 0.1133
DEBUG - 2022-09-02 00:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:13:04 --> Total execution time: 0.0931
DEBUG - 2022-09-02 00:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:13:06 --> Total execution time: 0.0933
DEBUG - 2022-09-02 00:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:13:06 --> Total execution time: 0.1212
DEBUG - 2022-09-02 00:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:43:48 --> Total execution time: 1.9020
DEBUG - 2022-09-02 00:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:13:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 00:13:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 00:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:15:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:45:59 --> Total execution time: 0.0649
DEBUG - 2022-09-02 00:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:16:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:46:01 --> Total execution time: 0.0893
DEBUG - 2022-09-02 00:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:16:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:46:46 --> Total execution time: 0.0644
DEBUG - 2022-09-02 00:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:17:05 --> Total execution time: 0.0838
DEBUG - 2022-09-02 00:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:17:07 --> Total execution time: 0.1002
DEBUG - 2022-09-02 00:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:17:08 --> Total execution time: 0.1107
DEBUG - 2022-09-02 00:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:47:14 --> Total execution time: 0.0924
DEBUG - 2022-09-02 00:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:22 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:47:22 --> Total execution time: 0.0802
DEBUG - 2022-09-02 00:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:47:22 --> Total execution time: 0.0995
DEBUG - 2022-09-02 00:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:47:31 --> Total execution time: 0.1069
DEBUG - 2022-09-02 00:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:47:39 --> Total execution time: 0.0943
DEBUG - 2022-09-02 00:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:47:59 --> Total execution time: 0.1033
DEBUG - 2022-09-02 00:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:18:36 --> Total execution time: 0.1120
DEBUG - 2022-09-02 00:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:48:48 --> Total execution time: 0.1048
DEBUG - 2022-09-02 00:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:48:56 --> Total execution time: 0.1292
DEBUG - 2022-09-02 00:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:49:01 --> Total execution time: 0.1341
DEBUG - 2022-09-02 00:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:49:04 --> Total execution time: 0.1177
DEBUG - 2022-09-02 00:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:19:06 --> Total execution time: 0.0966
DEBUG - 2022-09-02 00:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:19:07 --> Total execution time: 0.0932
DEBUG - 2022-09-02 00:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:19:08 --> Total execution time: 0.0960
DEBUG - 2022-09-02 00:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:49:19 --> Total execution time: 0.0965
DEBUG - 2022-09-02 00:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:19:27 --> Total execution time: 0.1284
DEBUG - 2022-09-02 00:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:20:10 --> Total execution time: 0.1042
DEBUG - 2022-09-02 00:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:50:20 --> Total execution time: 0.0727
DEBUG - 2022-09-02 00:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:20:37 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:50:37 --> Total execution time: 0.1012
DEBUG - 2022-09-02 00:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:50:41 --> Total execution time: 0.0902
DEBUG - 2022-09-02 00:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:50:47 --> Total execution time: 0.0896
DEBUG - 2022-09-02 00:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:50:52 --> Total execution time: 0.2580
DEBUG - 2022-09-02 00:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:21:08 --> Total execution time: 0.0932
DEBUG - 2022-09-02 00:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:21:19 --> Total execution time: 0.1100
DEBUG - 2022-09-02 00:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:21:20 --> Total execution time: 0.2253
DEBUG - 2022-09-02 00:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:51:26 --> Total execution time: 0.2466
DEBUG - 2022-09-02 00:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:51:33 --> Total execution time: 0.0980
DEBUG - 2022-09-02 00:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:51:38 --> Total execution time: 0.0972
DEBUG - 2022-09-02 00:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:51:46 --> Total execution time: 0.1366
DEBUG - 2022-09-02 00:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:52:00 --> Total execution time: 0.1023
DEBUG - 2022-09-02 00:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:52:01 --> Total execution time: 0.1526
DEBUG - 2022-09-02 00:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:52:12 --> Total execution time: 0.1101
DEBUG - 2022-09-02 00:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:52:18 --> Total execution time: 0.3017
DEBUG - 2022-09-02 00:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:52:25 --> Total execution time: 0.0956
DEBUG - 2022-09-02 00:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:22:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:52:26 --> Total execution time: 0.2464
DEBUG - 2022-09-02 00:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:22:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:52:27 --> Total execution time: 0.1075
DEBUG - 2022-09-02 00:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:53:53 --> Total execution time: 0.0947
DEBUG - 2022-09-02 00:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:54:04 --> Total execution time: 0.1058
DEBUG - 2022-09-02 00:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:22 --> Total execution time: 0.0899
DEBUG - 2022-09-02 00:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:24 --> Total execution time: 0.1112
DEBUG - 2022-09-02 00:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:25 --> Total execution time: 0.0893
DEBUG - 2022-09-02 00:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:54:40 --> Total execution time: 0.0879
DEBUG - 2022-09-02 00:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:48 --> Total execution time: 0.1135
DEBUG - 2022-09-02 00:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:50 --> Total execution time: 0.1177
DEBUG - 2022-09-02 00:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:24:51 --> Total execution time: 0.1023
DEBUG - 2022-09-02 00:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:55:05 --> Total execution time: 0.0968
DEBUG - 2022-09-02 00:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:56:09 --> Total execution time: 0.1227
DEBUG - 2022-09-02 00:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:56:13 --> Total execution time: 0.0949
DEBUG - 2022-09-02 00:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:56:32 --> Total execution time: 0.0945
DEBUG - 2022-09-02 00:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:26:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:56:55 --> Total execution time: 0.0628
DEBUG - 2022-09-02 00:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:05 --> Total execution time: 0.1112
DEBUG - 2022-09-02 00:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:07 --> Total execution time: 0.0937
DEBUG - 2022-09-02 00:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:08 --> Total execution time: 0.1441
DEBUG - 2022-09-02 00:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:34 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:57:34 --> Total execution time: 0.2512
DEBUG - 2022-09-02 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:57:37 --> Total execution time: 0.2481
DEBUG - 2022-09-02 00:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:37 --> Total execution time: 0.0943
DEBUG - 2022-09-02 00:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:40 --> Total execution time: 0.1004
DEBUG - 2022-09-02 00:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:57:45 --> Total execution time: 0.1450
DEBUG - 2022-09-02 00:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:47 --> Total execution time: 0.0878
DEBUG - 2022-09-02 00:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:57:47 --> Total execution time: 0.0970
DEBUG - 2022-09-02 00:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:49 --> Total execution time: 0.1147
DEBUG - 2022-09-02 00:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:27:49 --> Total execution time: 0.0869
DEBUG - 2022-09-02 00:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:57:54 --> Total execution time: 0.0960
DEBUG - 2022-09-02 00:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:28:00 --> Total execution time: 0.1035
DEBUG - 2022-09-02 00:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:28:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:58:02 --> Total execution time: 0.1775
DEBUG - 2022-09-02 00:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:58:03 --> Total execution time: 0.1194
DEBUG - 2022-09-02 00:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:58:22 --> Total execution time: 0.1014
DEBUG - 2022-09-02 00:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:58:25 --> Total execution time: 0.1188
DEBUG - 2022-09-02 00:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:58:44 --> Total execution time: 0.1627
DEBUG - 2022-09-02 00:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:58:51 --> Total execution time: 0.1001
DEBUG - 2022-09-02 00:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:59:08 --> Total execution time: 0.1251
DEBUG - 2022-09-02 00:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:29:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 00:29:16 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 00:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:59:32 --> Total execution time: 0.2818
DEBUG - 2022-09-02 00:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:30:41 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:00:41 --> Total execution time: 0.0654
DEBUG - 2022-09-02 00:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:00:48 --> Total execution time: 0.2901
DEBUG - 2022-09-02 00:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:00:53 --> Total execution time: 0.1018
DEBUG - 2022-09-02 00:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:30:54 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:00:54 --> Total execution time: 0.0774
DEBUG - 2022-09-02 00:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:01:07 --> Total execution time: 0.0639
DEBUG - 2022-09-02 00:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:31:07 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:01:07 --> Total execution time: 0.0755
DEBUG - 2022-09-02 00:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:01:21 --> Total execution time: 0.0964
DEBUG - 2022-09-02 00:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:02:04 --> Total execution time: 0.0999
DEBUG - 2022-09-02 00:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:02:12 --> Total execution time: 0.1090
DEBUG - 2022-09-02 00:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:02:13 --> Total execution time: 0.1097
DEBUG - 2022-09-02 00:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:02:26 --> Total execution time: 0.1339
DEBUG - 2022-09-02 00:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:02:41 --> Total execution time: 0.1489
DEBUG - 2022-09-02 00:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:04:56 --> Total execution time: 0.3690
DEBUG - 2022-09-02 00:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:04:57 --> Total execution time: 0.1190
DEBUG - 2022-09-02 00:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:05:08 --> Total execution time: 0.0985
DEBUG - 2022-09-02 00:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:08:12 --> Total execution time: 0.2669
DEBUG - 2022-09-02 00:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:08:33 --> Total execution time: 0.1092
DEBUG - 2022-09-02 00:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:09:17 --> Total execution time: 0.2931
DEBUG - 2022-09-02 00:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 00:41:49 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 00:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:42:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:12:59 --> Total execution time: 0.1309
DEBUG - 2022-09-02 00:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:13:14 --> Total execution time: 0.0648
DEBUG - 2022-09-02 00:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:13:46 --> Total execution time: 0.1026
DEBUG - 2022-09-02 00:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:14:21 --> Total execution time: 0.1085
DEBUG - 2022-09-02 00:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:15:50 --> Total execution time: 0.5742
DEBUG - 2022-09-02 00:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:45:52 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:15:53 --> Total execution time: 0.4325
DEBUG - 2022-09-02 00:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:15:59 --> Total execution time: 0.1330
DEBUG - 2022-09-02 00:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 00:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:16:06 --> Total execution time: 0.1487
DEBUG - 2022-09-02 00:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:16:12 --> Total execution time: 0.1833
DEBUG - 2022-09-02 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:16:33 --> Total execution time: 0.1698
DEBUG - 2022-09-02 00:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:16:34 --> Total execution time: 0.2950
DEBUG - 2022-09-02 00:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:16:52 --> Total execution time: 0.1022
DEBUG - 2022-09-02 00:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:17:05 --> Total execution time: 0.1296
DEBUG - 2022-09-02 00:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:49:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:19:29 --> Total execution time: 0.3256
DEBUG - 2022-09-02 00:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:51:09 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:21:09 --> Total execution time: 0.0633
DEBUG - 2022-09-02 00:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 00:51:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 00:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 00:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:21:29 --> Total execution time: 0.0746
DEBUG - 2022-09-02 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:30:02 --> Total execution time: 0.2134
DEBUG - 2022-09-02 01:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:32:11 --> Total execution time: 0.0737
DEBUG - 2022-09-02 01:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:51 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 01:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:51 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 01:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 01:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 01:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:53 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-09-02 01:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:53 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-02 01:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:53 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-09-02 01:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:55 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-09-02 01:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:56 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-02 01:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:56 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-09-02 01:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:57 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-02 01:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:02:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:02:58 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-02 01:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:05:09 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:35:09 --> Total execution time: 0.0711
DEBUG - 2022-09-02 01:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:37:16 --> Total execution time: 0.0684
DEBUG - 2022-09-02 01:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:13:45 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:43:45 --> Total execution time: 0.1424
DEBUG - 2022-09-02 01:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:13:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:43:46 --> Total execution time: 0.0650
DEBUG - 2022-09-02 01:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:14:29 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-02 01:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:44:38 --> Total execution time: 0.0615
DEBUG - 2022-09-02 01:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:45:42 --> Total execution time: 0.1093
DEBUG - 2022-09-02 01:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:45:54 --> Total execution time: 0.0663
DEBUG - 2022-09-02 01:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:45:55 --> Total execution time: 0.0945
DEBUG - 2022-09-02 01:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:16:04 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:46:04 --> Total execution time: 0.1157
DEBUG - 2022-09-02 01:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:19:07 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-02 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:53:20 --> Total execution time: 0.3870
DEBUG - 2022-09-02 01:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:54:37 --> Total execution time: 0.0711
DEBUG - 2022-09-02 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:00:43 --> Total execution time: 0.1081
DEBUG - 2022-09-02 01:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:31:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:01:44 --> Total execution time: 0.0720
DEBUG - 2022-09-02 01:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:01:52 --> Total execution time: 0.0688
DEBUG - 2022-09-02 01:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:04:16 --> Total execution time: 0.1053
DEBUG - 2022-09-02 01:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:34:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:04:27 --> Total execution time: 0.0777
DEBUG - 2022-09-02 01:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:04:30 --> Total execution time: 0.1289
DEBUG - 2022-09-02 01:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:04:30 --> Total execution time: 0.0996
DEBUG - 2022-09-02 01:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:04:35 --> Total execution time: 0.1013
DEBUG - 2022-09-02 01:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:04:43 --> Total execution time: 0.3093
DEBUG - 2022-09-02 01:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:04:53 --> Total execution time: 0.0921
DEBUG - 2022-09-02 01:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:05:08 --> Total execution time: 0.0990
DEBUG - 2022-09-02 01:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:35:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 01:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:09:31 --> Total execution time: 0.1142
DEBUG - 2022-09-02 01:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:14:50 --> Total execution time: 0.1363
DEBUG - 2022-09-02 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:15:00 --> Total execution time: 0.1350
DEBUG - 2022-09-02 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:15:09 --> Total execution time: 0.1317
DEBUG - 2022-09-02 01:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:15:15 --> Total execution time: 0.1055
DEBUG - 2022-09-02 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:15:21 --> Total execution time: 0.1033
DEBUG - 2022-09-02 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:15:22 --> Total execution time: 0.1221
DEBUG - 2022-09-02 01:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:28 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:15:28 --> Total execution time: 0.0668
DEBUG - 2022-09-02 01:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:45:41 --> Total execution time: 0.0869
DEBUG - 2022-09-02 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:15:42 --> Total execution time: 0.1371
DEBUG - 2022-09-02 01:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:45:43 --> Total execution time: 0.1317
DEBUG - 2022-09-02 01:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:45:44 --> Total execution time: 0.1006
DEBUG - 2022-09-02 01:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:15:46 --> Total execution time: 0.0901
DEBUG - 2022-09-02 01:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:46:00 --> Total execution time: 0.0973
DEBUG - 2022-09-02 01:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:49:33 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:19:33 --> Total execution time: 0.2113
DEBUG - 2022-09-02 01:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:21:07 --> Total execution time: 0.0958
DEBUG - 2022-09-02 01:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:23:29 --> Total execution time: 0.2826
DEBUG - 2022-09-02 01:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:53:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:23:36 --> Total execution time: 0.1306
DEBUG - 2022-09-02 01:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:23:43 --> Total execution time: 2.4115
DEBUG - 2022-09-02 01:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:53:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 01:53:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 01:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:54:02 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:24:02 --> Total execution time: 0.0981
DEBUG - 2022-09-02 01:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:24:07 --> Total execution time: 0.1044
DEBUG - 2022-09-02 01:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:54:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:24:16 --> Total execution time: 0.1099
DEBUG - 2022-09-02 01:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:54:29 --> Total execution time: 0.0990
DEBUG - 2022-09-02 01:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:54:31 --> Total execution time: 0.1250
DEBUG - 2022-09-02 01:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 01:54:31 --> Total execution time: 0.1156
DEBUG - 2022-09-02 01:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:56:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:26:46 --> Total execution time: 0.1328
DEBUG - 2022-09-02 01:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:57:34 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:27:34 --> Total execution time: 0.0640
DEBUG - 2022-09-02 01:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:57:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:27:36 --> Total execution time: 0.0782
DEBUG - 2022-09-02 01:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:28:38 --> Total execution time: 0.0655
DEBUG - 2022-09-02 01:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:58:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 01:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:28:49 --> Total execution time: 0.1014
DEBUG - 2022-09-02 01:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:29:37 --> Total execution time: 0.1005
DEBUG - 2022-09-02 01:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 01:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 01:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:29:51 --> Total execution time: 0.1014
DEBUG - 2022-09-02 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:30:03 --> Total execution time: 0.0813
DEBUG - 2022-09-02 02:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:30:41 --> Total execution time: 0.1038
DEBUG - 2022-09-02 02:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:32:36 --> Total execution time: 0.0915
DEBUG - 2022-09-02 02:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:38:16 --> Total execution time: 0.1798
DEBUG - 2022-09-02 02:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:10:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:40:10 --> Total execution time: 0.0795
DEBUG - 2022-09-02 02:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 02:12:41 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-02 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:14:42 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:44:43 --> Total execution time: 0.1848
DEBUG - 2022-09-02 02:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:14:49 --> Total execution time: 0.0968
DEBUG - 2022-09-02 02:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:14:50 --> Total execution time: 0.1309
DEBUG - 2022-09-02 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:14:51 --> Total execution time: 0.0936
DEBUG - 2022-09-02 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:15:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 02:15:17 --> 404 Page Not Found: Public/_ignition
DEBUG - 2022-09-02 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:15:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 02:15:20 --> 404 Page Not Found: _ignition/health-check
DEBUG - 2022-09-02 02:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:46:05 --> Total execution time: 2.6155
DEBUG - 2022-09-02 02:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 02:16:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 02:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:46:39 --> Total execution time: 0.1340
DEBUG - 2022-09-02 02:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:46:42 --> Total execution time: 0.2675
DEBUG - 2022-09-02 02:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:46:46 --> Total execution time: 0.1144
DEBUG - 2022-09-02 02:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:46:52 --> Total execution time: 0.1086
DEBUG - 2022-09-02 02:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:46:59 --> Total execution time: 0.1466
DEBUG - 2022-09-02 02:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:47:08 --> Total execution time: 0.1167
DEBUG - 2022-09-02 02:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:48:31 --> Total execution time: 0.0626
DEBUG - 2022-09-02 02:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:49:46 --> Total execution time: 0.0586
DEBUG - 2022-09-02 02:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:19:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:49:59 --> Total execution time: 0.0623
DEBUG - 2022-09-02 02:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:20:05 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:50:05 --> Total execution time: 0.0631
DEBUG - 2022-09-02 02:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:20:06 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:50:06 --> Total execution time: 0.0991
DEBUG - 2022-09-02 02:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:50:25 --> Total execution time: 0.0924
DEBUG - 2022-09-02 02:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:50:54 --> Total execution time: 0.1215
DEBUG - 2022-09-02 02:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:51:16 --> Total execution time: 0.1067
DEBUG - 2022-09-02 02:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:51:17 --> Total execution time: 0.1154
DEBUG - 2022-09-02 02:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:51:36 --> Total execution time: 0.1001
DEBUG - 2022-09-02 02:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:51:44 --> Total execution time: 0.1092
DEBUG - 2022-09-02 02:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:52:08 --> Total execution time: 0.1077
DEBUG - 2022-09-02 02:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:52:13 --> Total execution time: 0.2553
DEBUG - 2022-09-02 02:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:52:14 --> Total execution time: 0.1124
DEBUG - 2022-09-02 02:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:20 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:52:20 --> Total execution time: 0.0870
DEBUG - 2022-09-02 02:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:52:27 --> Total execution time: 0.0981
DEBUG - 2022-09-02 02:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:52:38 --> Total execution time: 0.1159
DEBUG - 2022-09-02 02:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:22:49 --> Total execution time: 0.0924
DEBUG - 2022-09-02 02:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:22:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:52:55 --> Total execution time: 0.0622
DEBUG - 2022-09-02 02:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:53:21 --> Total execution time: 0.0983
DEBUG - 2022-09-02 02:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:53:33 --> Total execution time: 0.1073
DEBUG - 2022-09-02 02:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:53:50 --> Total execution time: 0.1040
DEBUG - 2022-09-02 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:04 --> Total execution time: 0.2475
DEBUG - 2022-09-02 02:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:06 --> Total execution time: 0.0997
DEBUG - 2022-09-02 02:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:06 --> Total execution time: 0.1015
DEBUG - 2022-09-02 02:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:55:08 --> Total execution time: 0.0947
DEBUG - 2022-09-02 02:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:14 --> Total execution time: 0.0953
DEBUG - 2022-09-02 02:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:17 --> Total execution time: 0.1038
DEBUG - 2022-09-02 02:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:18 --> Total execution time: 0.1184
DEBUG - 2022-09-02 02:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:18 --> Total execution time: 0.0940
DEBUG - 2022-09-02 02:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:28 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:55:28 --> Total execution time: 0.0995
DEBUG - 2022-09-02 02:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:34 --> Total execution time: 0.1363
DEBUG - 2022-09-02 02:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:36 --> Total execution time: 0.1028
DEBUG - 2022-09-02 02:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:25:36 --> Total execution time: 0.0963
DEBUG - 2022-09-02 02:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:56:35 --> Total execution time: 1.9919
DEBUG - 2022-09-02 02:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:26:56 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:56:56 --> Total execution time: 0.0682
DEBUG - 2022-09-02 02:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:57:20 --> Total execution time: 0.0968
DEBUG - 2022-09-02 02:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:57:37 --> Total execution time: 0.0996
DEBUG - 2022-09-02 02:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:57:48 --> Total execution time: 0.1047
DEBUG - 2022-09-02 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:58:01 --> Total execution time: 0.0694
DEBUG - 2022-09-02 02:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:58:03 --> Total execution time: 0.1006
DEBUG - 2022-09-02 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:58:13 --> Total execution time: 0.0611
DEBUG - 2022-09-02 02:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:58:37 --> Total execution time: 0.1462
DEBUG - 2022-09-02 02:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:58:52 --> Total execution time: 0.0980
DEBUG - 2022-09-02 02:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:28:56 --> Total execution time: 0.2163
DEBUG - 2022-09-02 02:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:58:56 --> Total execution time: 0.0949
DEBUG - 2022-09-02 02:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:05 --> Total execution time: 0.1672
DEBUG - 2022-09-02 02:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:11 --> Total execution time: 0.1037
DEBUG - 2022-09-02 02:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:12 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:12 --> Total execution time: 0.0623
DEBUG - 2022-09-02 02:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:13 --> Total execution time: 0.0912
DEBUG - 2022-09-02 02:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:14 --> Total execution time: 0.0785
DEBUG - 2022-09-02 02:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:17 --> Total execution time: 0.0521
DEBUG - 2022-09-02 02:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:20 --> Total execution time: 0.1463
DEBUG - 2022-09-02 02:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:20 --> Total execution time: 0.1054
DEBUG - 2022-09-02 02:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:24 --> Total execution time: 0.1678
DEBUG - 2022-09-02 02:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:25 --> Total execution time: 0.0989
DEBUG - 2022-09-02 02:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:33 --> Total execution time: 0.1008
DEBUG - 2022-09-02 02:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:35 --> Total execution time: 0.1285
DEBUG - 2022-09-02 02:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:38 --> Total execution time: 0.1150
DEBUG - 2022-09-02 02:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:43 --> Total execution time: 0.1144
DEBUG - 2022-09-02 02:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:46 --> Total execution time: 0.1101
DEBUG - 2022-09-02 02:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:48 --> Total execution time: 0.1002
DEBUG - 2022-09-02 02:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:50 --> Total execution time: 0.1281
DEBUG - 2022-09-02 02:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:59:55 --> Total execution time: 0.0969
DEBUG - 2022-09-02 02:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:30:00 --> Total execution time: 0.1088
DEBUG - 2022-09-02 02:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:04 --> Total execution time: 0.1053
DEBUG - 2022-09-02 02:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:06 --> Total execution time: 1.8668
DEBUG - 2022-09-02 02:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:09 --> Total execution time: 0.1252
DEBUG - 2022-09-02 02:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:00:16 --> Total execution time: 0.1034
DEBUG - 2022-09-02 02:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:16 --> Total execution time: 0.2714
DEBUG - 2022-09-02 02:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:21 --> Total execution time: 0.0935
DEBUG - 2022-09-02 02:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:24 --> Total execution time: 0.0943
DEBUG - 2022-09-02 02:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:29 --> Total execution time: 0.1129
DEBUG - 2022-09-02 02:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:30 --> Total execution time: 0.1194
DEBUG - 2022-09-02 02:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:34 --> Total execution time: 0.1782
DEBUG - 2022-09-02 02:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:40 --> Total execution time: 0.1323
DEBUG - 2022-09-02 02:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:42 --> Total execution time: 0.0940
DEBUG - 2022-09-02 02:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:00:49 --> Total execution time: 0.1202
DEBUG - 2022-09-02 02:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:31:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:01:00 --> Total execution time: 0.0996
DEBUG - 2022-09-02 02:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:31:02 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:01:03 --> Total execution time: 0.1076
DEBUG - 2022-09-02 02:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:01:07 --> Total execution time: 0.0960
DEBUG - 2022-09-02 02:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:01:29 --> Total execution time: 0.1522
DEBUG - 2022-09-02 02:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:01:35 --> Total execution time: 0.1233
DEBUG - 2022-09-02 02:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:01 --> Total execution time: 0.1838
DEBUG - 2022-09-02 02:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:01 --> Total execution time: 0.1204
DEBUG - 2022-09-02 02:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:05 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:05 --> Total execution time: 0.1049
DEBUG - 2022-09-02 02:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:18 --> Total execution time: 0.1089
DEBUG - 2022-09-02 02:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:19 --> Total execution time: 0.1060
DEBUG - 2022-09-02 02:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:24 --> Total execution time: 0.1024
DEBUG - 2022-09-02 02:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:34 --> Total execution time: 0.1117
DEBUG - 2022-09-02 02:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:48 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:48 --> Total execution time: 0.0962
DEBUG - 2022-09-02 02:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:48 --> Total execution time: 0.1111
DEBUG - 2022-09-02 02:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:02:56 --> Total execution time: 0.1088
DEBUG - 2022-09-02 02:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:03:10 --> Total execution time: 0.1221
DEBUG - 2022-09-02 02:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:03:19 --> Total execution time: 0.2664
DEBUG - 2022-09-02 02:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:03:34 --> Total execution time: 0.1229
DEBUG - 2022-09-02 02:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:33:37 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:03:38 --> Total execution time: 0.1061
DEBUG - 2022-09-02 02:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:03:43 --> Total execution time: 0.1008
DEBUG - 2022-09-02 02:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:03:46 --> Total execution time: 2.2525
DEBUG - 2022-09-02 02:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:03:51 --> Total execution time: 0.1001
DEBUG - 2022-09-02 02:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:04:30 --> Total execution time: 0.2586
DEBUG - 2022-09-02 02:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:35:08 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:05:09 --> Total execution time: 0.2716
DEBUG - 2022-09-02 02:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:05:15 --> Total execution time: 0.0982
DEBUG - 2022-09-02 02:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:05:23 --> Total execution time: 0.1427
DEBUG - 2022-09-02 02:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:05:36 --> Total execution time: 0.1159
DEBUG - 2022-09-02 02:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:35:41 --> Total execution time: 0.1096
DEBUG - 2022-09-02 02:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:36:18 --> Total execution time: 0.1636
DEBUG - 2022-09-02 02:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:06:46 --> Total execution time: 0.0999
DEBUG - 2022-09-02 02:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:42:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:12:25 --> Total execution time: 0.0755
DEBUG - 2022-09-02 02:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:13:07 --> Total execution time: 0.2739
DEBUG - 2022-09-02 02:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:13:19 --> Total execution time: 0.1050
DEBUG - 2022-09-02 02:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:13:19 --> Total execution time: 0.1317
DEBUG - 2022-09-02 02:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:43:39 --> Total execution time: 0.1408
DEBUG - 2022-09-02 02:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:44:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:14:14 --> Total execution time: 0.0657
DEBUG - 2022-09-02 02:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:44:22 --> Total execution time: 0.1542
DEBUG - 2022-09-02 02:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:15:56 --> Total execution time: 1.9379
DEBUG - 2022-09-02 02:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:15:58 --> Total execution time: 0.1146
DEBUG - 2022-09-02 02:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:16:11 --> Total execution time: 0.1300
DEBUG - 2022-09-02 02:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:16:18 --> Total execution time: 0.1247
DEBUG - 2022-09-02 02:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:16:18 --> Total execution time: 0.1066
DEBUG - 2022-09-02 02:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 02:47:23 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 02:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:47:23 --> Total execution time: 0.1049
DEBUG - 2022-09-02 02:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:17:36 --> Total execution time: 0.0965
DEBUG - 2022-09-02 02:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:17:58 --> Total execution time: 1.8602
DEBUG - 2022-09-02 02:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:01 --> Total execution time: 0.0956
DEBUG - 2022-09-02 02:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:04 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:04 --> Total execution time: 0.1024
DEBUG - 2022-09-02 02:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:09 --> Total execution time: 0.0911
DEBUG - 2022-09-02 02:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:11 --> Total execution time: 0.1383
DEBUG - 2022-09-02 02:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:20 --> Total execution time: 0.1009
DEBUG - 2022-09-02 02:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:20 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:20 --> Total execution time: 0.0619
DEBUG - 2022-09-02 02:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:27 --> Total execution time: 0.1323
DEBUG - 2022-09-02 02:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:28 --> Total execution time: 0.1619
DEBUG - 2022-09-02 02:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:42 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:42 --> Total execution time: 0.0833
DEBUG - 2022-09-02 02:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:18:55 --> Total execution time: 0.0705
DEBUG - 2022-09-02 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:49:39 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:19:40 --> Total execution time: 0.1015
DEBUG - 2022-09-02 02:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:49:40 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:19:40 --> Total execution time: 0.0880
DEBUG - 2022-09-02 02:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:19:43 --> Total execution time: 0.0959
DEBUG - 2022-09-02 02:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:19:53 --> Total execution time: 0.0644
DEBUG - 2022-09-02 02:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:02 --> Total execution time: 0.1039
DEBUG - 2022-09-02 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:13 --> Total execution time: 0.1026
DEBUG - 2022-09-02 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:13 --> Total execution time: 0.0629
DEBUG - 2022-09-02 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:14 --> Total execution time: 0.0552
DEBUG - 2022-09-02 02:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:23 --> Total execution time: 0.0593
DEBUG - 2022-09-02 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:24 --> Total execution time: 0.0579
DEBUG - 2022-09-02 02:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:26 --> Total execution time: 0.1351
DEBUG - 2022-09-02 02:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:31 --> Total execution time: 0.0905
DEBUG - 2022-09-02 02:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:31 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:31 --> Total execution time: 0.1049
DEBUG - 2022-09-02 02:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:33 --> Total execution time: 0.0601
DEBUG - 2022-09-02 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:35 --> Total execution time: 0.0637
DEBUG - 2022-09-02 02:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:41 --> Total execution time: 0.0937
DEBUG - 2022-09-02 02:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:45 --> Total execution time: 0.1057
DEBUG - 2022-09-02 02:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:50:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:00 --> Total execution time: 0.1384
DEBUG - 2022-09-02 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:02 --> Total execution time: 0.1732
DEBUG - 2022-09-02 02:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:03 --> Total execution time: 0.1505
DEBUG - 2022-09-02 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:06 --> Total execution time: 0.0602
DEBUG - 2022-09-02 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:06 --> Total execution time: 0.0576
DEBUG - 2022-09-02 02:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:07 --> Total execution time: 0.0936
DEBUG - 2022-09-02 02:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:07 --> Total execution time: 0.0629
DEBUG - 2022-09-02 02:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:13 --> Total execution time: 0.1727
DEBUG - 2022-09-02 02:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:14 --> Total execution time: 0.1277
DEBUG - 2022-09-02 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:25 --> Total execution time: 0.0759
DEBUG - 2022-09-02 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:25 --> Total execution time: 0.1251
DEBUG - 2022-09-02 02:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:51:58 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:21:59 --> Total execution time: 0.1484
DEBUG - 2022-09-02 02:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:01 --> Total execution time: 0.3012
DEBUG - 2022-09-02 02:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:01 --> Total execution time: 0.2675
DEBUG - 2022-09-02 02:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:02 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:03 --> Total execution time: 0.2218
DEBUG - 2022-09-02 02:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:03 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:03 --> Total execution time: 0.1896
DEBUG - 2022-09-02 02:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:04 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:04 --> Total execution time: 0.1804
DEBUG - 2022-09-02 02:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:13 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:13 --> Total execution time: 0.1107
DEBUG - 2022-09-02 02:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:16 --> Total execution time: 0.1218
DEBUG - 2022-09-02 02:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:24 --> Total execution time: 0.0591
DEBUG - 2022-09-02 02:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:25 --> Total execution time: 0.1113
DEBUG - 2022-09-02 02:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:30 --> Total execution time: 0.1021
DEBUG - 2022-09-02 02:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:31 --> Total execution time: 0.1283
DEBUG - 2022-09-02 02:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:32 --> Total execution time: 0.0916
DEBUG - 2022-09-02 02:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:39 --> Total execution time: 0.1220
DEBUG - 2022-09-02 02:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:22:51 --> Total execution time: 0.1860
DEBUG - 2022-09-02 02:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:23:46 --> Total execution time: 0.0988
DEBUG - 2022-09-02 02:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:53:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:23:47 --> Total execution time: 0.0657
DEBUG - 2022-09-02 02:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:06 --> Total execution time: 0.0995
DEBUG - 2022-09-02 02:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:16 --> Total execution time: 0.2521
DEBUG - 2022-09-02 02:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:16 --> Total execution time: 0.0921
DEBUG - 2022-09-02 02:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:17 --> Total execution time: 0.0959
DEBUG - 2022-09-02 02:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:20 --> Total execution time: 0.1021
DEBUG - 2022-09-02 02:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:21 --> Total execution time: 0.0903
DEBUG - 2022-09-02 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:38 --> Total execution time: 0.1056
DEBUG - 2022-09-02 02:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:39 --> Total execution time: 0.1302
DEBUG - 2022-09-02 02:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:39 --> Total execution time: 0.0888
DEBUG - 2022-09-02 02:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:54 --> Total execution time: 0.1083
DEBUG - 2022-09-02 02:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:24:58 --> Total execution time: 0.0937
DEBUG - 2022-09-02 02:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:25:01 --> Total execution time: 0.1237
DEBUG - 2022-09-02 02:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:25:05 --> Total execution time: 0.1003
DEBUG - 2022-09-02 02:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:25:05 --> Total execution time: 0.1153
DEBUG - 2022-09-02 02:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:25:06 --> Total execution time: 0.0989
DEBUG - 2022-09-02 02:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:25:17 --> Total execution time: 0.1337
DEBUG - 2022-09-02 02:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:25:29 --> Total execution time: 0.1057
DEBUG - 2022-09-02 02:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:25:35 --> Total execution time: 0.1175
DEBUG - 2022-09-02 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:25:45 --> Total execution time: 0.1056
DEBUG - 2022-09-02 02:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:27:55 --> Total execution time: 0.1019
DEBUG - 2022-09-02 02:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:59:48 --> No URI present. Default controller set.
DEBUG - 2022-09-02 02:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:29:49 --> Total execution time: 0.2614
DEBUG - 2022-09-02 02:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:59:55 --> Total execution time: 0.0964
DEBUG - 2022-09-02 02:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:59:56 --> Total execution time: 0.0985
DEBUG - 2022-09-02 02:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:59:57 --> Total execution time: 0.2503
DEBUG - 2022-09-02 02:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:59:57 --> Total execution time: 0.1369
DEBUG - 2022-09-02 02:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:59:59 --> Total execution time: 0.1004
DEBUG - 2022-09-02 02:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 02:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 02:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 02:59:59 --> Total execution time: 0.0931
DEBUG - 2022-09-02 03:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:00:01 --> Total execution time: 0.2909
DEBUG - 2022-09-02 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:30:02 --> Total execution time: 0.1109
DEBUG - 2022-09-02 03:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:00:22 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:30:22 --> Total execution time: 0.2493
DEBUG - 2022-09-02 03:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:00:24 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:30:24 --> Total execution time: 0.0957
DEBUG - 2022-09-02 03:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:03:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:33:00 --> Total execution time: 0.2000
DEBUG - 2022-09-02 03:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:33:02 --> Total execution time: 0.1107
DEBUG - 2022-09-02 03:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:03:19 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:33:20 --> Total execution time: 0.1100
DEBUG - 2022-09-02 03:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:03:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:33:35 --> Total execution time: 0.0973
DEBUG - 2022-09-02 03:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:33:38 --> Total execution time: 0.0935
DEBUG - 2022-09-02 03:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:03:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:33:46 --> Total execution time: 0.0942
DEBUG - 2022-09-02 03:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:03:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:33:49 --> Total execution time: 0.1039
DEBUG - 2022-09-02 03:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:33:53 --> Total execution time: 0.0950
DEBUG - 2022-09-02 03:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:35:12 --> Total execution time: 0.2901
DEBUG - 2022-09-02 03:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:05:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:35:36 --> Total execution time: 0.0716
DEBUG - 2022-09-02 03:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:05:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:35:47 --> Total execution time: 0.0822
DEBUG - 2022-09-02 03:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:05:52 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:35:52 --> Total execution time: 0.0637
DEBUG - 2022-09-02 03:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:06:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:36:00 --> Total execution time: 0.0608
DEBUG - 2022-09-02 03:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 03:06:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 03:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:06:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:36:16 --> Total execution time: 0.0638
DEBUG - 2022-09-02 03:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:07:06 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:37:06 --> Total execution time: 0.0651
DEBUG - 2022-09-02 03:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:38:01 --> Total execution time: 0.2453
DEBUG - 2022-09-02 03:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:38:10 --> Total execution time: 0.1118
DEBUG - 2022-09-02 03:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:38:11 --> Total execution time: 0.0940
DEBUG - 2022-09-02 03:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:38:39 --> Total execution time: 0.1244
DEBUG - 2022-09-02 03:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:38:58 --> Total execution time: 0.0984
DEBUG - 2022-09-02 03:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 03:10:28 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 03:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:40 --> Total execution time: 0.0983
DEBUG - 2022-09-02 03:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:42 --> Total execution time: 0.1015
DEBUG - 2022-09-02 03:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:43 --> Total execution time: 0.0690
DEBUG - 2022-09-02 13:44:43 --> Total execution time: 0.0702
DEBUG - 2022-09-02 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:43 --> Total execution time: 0.0889
DEBUG - 2022-09-02 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:43 --> Total execution time: 0.0920
DEBUG - 2022-09-02 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:43 --> Total execution time: 0.0609
DEBUG - 2022-09-02 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:43 --> Total execution time: 0.0897
DEBUG - 2022-09-02 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:43 --> Total execution time: 0.0697
DEBUG - 2022-09-02 03:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:44 --> Total execution time: 0.0723
DEBUG - 2022-09-02 03:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:45 --> Total execution time: 0.0819
DEBUG - 2022-09-02 03:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:14:56 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:44:56 --> Total execution time: 0.0611
DEBUG - 2022-09-02 03:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:15:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:45:10 --> Total execution time: 0.0943
DEBUG - 2022-09-02 03:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:45:21 --> Total execution time: 0.0599
DEBUG - 2022-09-02 03:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:45:25 --> Total execution time: 0.1043
DEBUG - 2022-09-02 03:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:15:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:45:47 --> Total execution time: 0.0940
DEBUG - 2022-09-02 03:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:16:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:46:14 --> Total execution time: 0.0869
DEBUG - 2022-09-02 03:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:46:19 --> Total execution time: 0.1205
DEBUG - 2022-09-02 03:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:46:59 --> Total execution time: 0.0813
DEBUG - 2022-09-02 03:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:47:02 --> Total execution time: 0.1184
DEBUG - 2022-09-02 03:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:19 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:47:20 --> Total execution time: 0.2572
DEBUG - 2022-09-02 03:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:47:26 --> Total execution time: 0.1164
DEBUG - 2022-09-02 03:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:47:32 --> Total execution time: 0.1314
DEBUG - 2022-09-02 03:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:47:42 --> Total execution time: 0.0975
DEBUG - 2022-09-02 03:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:47:43 --> Total execution time: 0.0944
DEBUG - 2022-09-02 03:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:47:56 --> Total execution time: 0.0875
DEBUG - 2022-09-02 03:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:17:57 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:47:57 --> Total execution time: 0.1042
DEBUG - 2022-09-02 03:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:18:02 --> Total execution time: 0.0954
DEBUG - 2022-09-02 03:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:18:05 --> Total execution time: 0.0964
DEBUG - 2022-09-02 03:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:18:06 --> Total execution time: 0.0954
DEBUG - 2022-09-02 03:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:48:13 --> Total execution time: 0.1071
DEBUG - 2022-09-02 03:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:18:20 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:48:20 --> Total execution time: 0.0676
DEBUG - 2022-09-02 03:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:19:34 --> Total execution time: 0.0896
DEBUG - 2022-09-02 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:19:37 --> Total execution time: 0.0986
DEBUG - 2022-09-02 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:19:37 --> Total execution time: 0.0937
DEBUG - 2022-09-02 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:37 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:49:37 --> Total execution time: 0.0927
DEBUG - 2022-09-02 03:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:49:46 --> Total execution time: 0.0958
DEBUG - 2022-09-02 03:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:19:52 --> Total execution time: 0.1230
DEBUG - 2022-09-02 03:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:19:54 --> Total execution time: 0.0863
DEBUG - 2022-09-02 03:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:49:57 --> Total execution time: 0.1002
DEBUG - 2022-09-02 03:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:20:01 --> Total execution time: 0.0933
DEBUG - 2022-09-02 03:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:20:03 --> Total execution time: 0.0935
DEBUG - 2022-09-02 03:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:20:03 --> Total execution time: 0.1185
DEBUG - 2022-09-02 03:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:50:32 --> Total execution time: 0.0961
DEBUG - 2022-09-02 03:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:20:56 --> Total execution time: 0.1080
DEBUG - 2022-09-02 03:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:21:06 --> Total execution time: 0.1387
DEBUG - 2022-09-02 03:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:06 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:51:07 --> Total execution time: 0.0902
DEBUG - 2022-09-02 03:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:51:12 --> Total execution time: 0.0987
DEBUG - 2022-09-02 03:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:19 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:51:19 --> Total execution time: 0.0967
DEBUG - 2022-09-02 03:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:51:25 --> Total execution time: 0.1018
DEBUG - 2022-09-02 03:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:51:41 --> Total execution time: 0.1041
DEBUG - 2022-09-02 03:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:51:41 --> Total execution time: 0.1230
DEBUG - 2022-09-02 03:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:51:55 --> Total execution time: 0.1080
DEBUG - 2022-09-02 03:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:52:00 --> Total execution time: 0.1034
DEBUG - 2022-09-02 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:52:19 --> Total execution time: 0.1017
DEBUG - 2022-09-02 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:52:23 --> Total execution time: 0.1037
DEBUG - 2022-09-02 03:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:52:26 --> Total execution time: 0.2534
DEBUG - 2022-09-02 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:31 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:52:31 --> Total execution time: 0.0976
DEBUG - 2022-09-02 03:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:52:41 --> Total execution time: 0.0928
DEBUG - 2022-09-02 03:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:52:45 --> Total execution time: 0.0941
DEBUG - 2022-09-02 03:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:08 --> Total execution time: 0.1322
DEBUG - 2022-09-02 03:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:13 --> Total execution time: 0.1305
DEBUG - 2022-09-02 03:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:17 --> Total execution time: 0.1128
DEBUG - 2022-09-02 03:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:21 --> Total execution time: 0.0952
DEBUG - 2022-09-02 03:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:25 --> Total execution time: 0.0987
DEBUG - 2022-09-02 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:33 --> Total execution time: 0.1260
DEBUG - 2022-09-02 03:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:33 --> Total execution time: 0.1063
DEBUG - 2022-09-02 03:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:34 --> Total execution time: 0.0996
DEBUG - 2022-09-02 03:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:34 --> Total execution time: 0.1022
DEBUG - 2022-09-02 03:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:39 --> Total execution time: 0.0998
DEBUG - 2022-09-02 03:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:44 --> Total execution time: 0.1167
DEBUG - 2022-09-02 03:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:50 --> Total execution time: 0.1039
DEBUG - 2022-09-02 03:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-02 03:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:53:59 --> Total execution time: 0.1262
DEBUG - 2022-09-02 03:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:09 --> Total execution time: 0.0918
DEBUG - 2022-09-02 03:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-02 03:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:20 --> Total execution time: 0.1239
DEBUG - 2022-09-02 03:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:24 --> Total execution time: 0.1086
DEBUG - 2022-09-02 03:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:25 --> Total execution time: 0.1350
DEBUG - 2022-09-02 03:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:30 --> Total execution time: 0.2594
DEBUG - 2022-09-02 03:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:32 --> Total execution time: 0.1209
DEBUG - 2022-09-02 03:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:42 --> Total execution time: 0.1761
DEBUG - 2022-09-02 03:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:56 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:56 --> Total execution time: 0.0623
DEBUG - 2022-09-02 03:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:24:57 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:54:57 --> Total execution time: 0.0624
DEBUG - 2022-09-02 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:55:05 --> Total execution time: 0.0750
DEBUG - 2022-09-02 03:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:55:08 --> Total execution time: 0.0991
DEBUG - 2022-09-02 03:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:55:15 --> Total execution time: 0.0997
DEBUG - 2022-09-02 03:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:55:24 --> Total execution time: 0.1041
DEBUG - 2022-09-02 03:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:55:37 --> Total execution time: 0.1069
DEBUG - 2022-09-02 03:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:59:27 --> Total execution time: 0.1293
DEBUG - 2022-09-02 03:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:59:38 --> Total execution time: 0.0978
DEBUG - 2022-09-02 03:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:59:42 --> Total execution time: 0.1277
DEBUG - 2022-09-02 03:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:00:03 --> Total execution time: 0.1487
DEBUG - 2022-09-02 03:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:00:22 --> Total execution time: 0.1242
DEBUG - 2022-09-02 03:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:00:49 --> Total execution time: 0.0998
DEBUG - 2022-09-02 03:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:00:52 --> Total execution time: 0.0984
DEBUG - 2022-09-02 03:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:01:13 --> Total execution time: 0.1241
DEBUG - 2022-09-02 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:01:22 --> Total execution time: 0.1002
DEBUG - 2022-09-02 03:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:01:35 --> Total execution time: 0.1253
DEBUG - 2022-09-02 03:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:01:40 --> Total execution time: 0.0645
DEBUG - 2022-09-02 03:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:03:16 --> Total execution time: 0.0915
DEBUG - 2022-09-02 03:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:03:27 --> Total execution time: 0.0650
DEBUG - 2022-09-02 03:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:03:39 --> Total execution time: 0.1325
DEBUG - 2022-09-02 03:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:03:43 --> Total execution time: 0.0596
DEBUG - 2022-09-02 03:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:03:43 --> Total execution time: 0.0934
DEBUG - 2022-09-02 03:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:03:45 --> Total execution time: 0.1484
DEBUG - 2022-09-02 03:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:03:50 --> Total execution time: 0.0883
DEBUG - 2022-09-02 03:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:03:56 --> Total execution time: 0.1037
DEBUG - 2022-09-02 03:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:06 --> Total execution time: 0.1734
DEBUG - 2022-09-02 03:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:13 --> Total execution time: 0.1109
DEBUG - 2022-09-02 03:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:16 --> Total execution time: 0.1035
DEBUG - 2022-09-02 03:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:18 --> Total execution time: 0.0924
DEBUG - 2022-09-02 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:19 --> Total execution time: 0.1873
DEBUG - 2022-09-02 03:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:21 --> Total execution time: 0.1270
DEBUG - 2022-09-02 03:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:35 --> Total execution time: 0.0950
DEBUG - 2022-09-02 03:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:42 --> Total execution time: 0.0998
DEBUG - 2022-09-02 03:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:04:47 --> Total execution time: 0.1238
DEBUG - 2022-09-02 03:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:00 --> Total execution time: 0.0985
DEBUG - 2022-09-02 03:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:01 --> Total execution time: 0.1304
DEBUG - 2022-09-02 03:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:04 --> Total execution time: 0.1078
DEBUG - 2022-09-02 03:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:05 --> Total execution time: 0.1029
DEBUG - 2022-09-02 03:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:08 --> Total execution time: 0.1041
DEBUG - 2022-09-02 03:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:09 --> Total execution time: 0.1087
DEBUG - 2022-09-02 03:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:09 --> Total execution time: 0.0980
DEBUG - 2022-09-02 03:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:41 --> Total execution time: 0.1020
DEBUG - 2022-09-02 03:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:51 --> Total execution time: 0.1267
DEBUG - 2022-09-02 03:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:05:51 --> Total execution time: 0.1265
DEBUG - 2022-09-02 03:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:06:07 --> Total execution time: 0.1080
DEBUG - 2022-09-02 03:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:06:13 --> Total execution time: 0.0981
DEBUG - 2022-09-02 03:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:06:17 --> Total execution time: 0.1047
DEBUG - 2022-09-02 03:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:06:27 --> Total execution time: 0.1066
DEBUG - 2022-09-02 03:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:06:31 --> Total execution time: 0.1034
DEBUG - 2022-09-02 03:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:06:57 --> Total execution time: 0.1274
DEBUG - 2022-09-02 03:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:38:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:08:01 --> Total execution time: 0.1078
DEBUG - 2022-09-02 03:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:38:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:08:24 --> Total execution time: 0.2442
DEBUG - 2022-09-02 03:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:16:01 --> Total execution time: 0.3621
DEBUG - 2022-09-02 03:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:16:06 --> Total execution time: 0.1752
DEBUG - 2022-09-02 03:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:17:08 --> Total execution time: 0.0640
DEBUG - 2022-09-02 03:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:17:45 --> Total execution time: 0.1339
DEBUG - 2022-09-02 03:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:50:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:20:35 --> Total execution time: 0.1500
DEBUG - 2022-09-02 03:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:50:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:20:47 --> Total execution time: 0.0825
DEBUG - 2022-09-02 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:20:52 --> Total execution time: 0.1539
DEBUG - 2022-09-02 03:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:50:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:20:59 --> Total execution time: 0.0666
DEBUG - 2022-09-02 03:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:02 --> Total execution time: 0.1879
DEBUG - 2022-09-02 03:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:02 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:02 --> Total execution time: 0.0595
DEBUG - 2022-09-02 03:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:02 --> Total execution time: 0.0885
DEBUG - 2022-09-02 03:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:10 --> Total execution time: 0.0664
DEBUG - 2022-09-02 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:12 --> Total execution time: 0.1094
DEBUG - 2022-09-02 03:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:12 --> Total execution time: 0.0881
DEBUG - 2022-09-02 03:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:13 --> Total execution time: 0.1153
DEBUG - 2022-09-02 03:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:20 --> Total execution time: 0.0999
DEBUG - 2022-09-02 03:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:23 --> Total execution time: 0.1000
DEBUG - 2022-09-02 03:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:26 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:26 --> Total execution time: 0.1206
DEBUG - 2022-09-02 03:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:30 --> Total execution time: 0.1583
DEBUG - 2022-09-02 03:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:34 --> Total execution time: 0.1429
DEBUG - 2022-09-02 03:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:45 --> Total execution time: 0.1126
DEBUG - 2022-09-02 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:47 --> Total execution time: 0.1196
DEBUG - 2022-09-02 03:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:21:55 --> Total execution time: 0.1157
DEBUG - 2022-09-02 03:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:52:09 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:22:09 --> Total execution time: 0.0977
DEBUG - 2022-09-02 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:22:22 --> Total execution time: 0.3214
DEBUG - 2022-09-02 03:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:22:43 --> Total execution time: 0.1016
DEBUG - 2022-09-02 03:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:22:57 --> Total execution time: 0.1025
DEBUG - 2022-09-02 03:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:22:59 --> Total execution time: 0.1247
DEBUG - 2022-09-02 03:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:23:16 --> Total execution time: 0.1035
DEBUG - 2022-09-02 03:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:53:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 03:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:23:17 --> Total execution time: 0.1020
DEBUG - 2022-09-02 03:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:23:26 --> Total execution time: 0.1181
DEBUG - 2022-09-02 03:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:23:37 --> Total execution time: 0.1239
DEBUG - 2022-09-02 03:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:23:42 --> Total execution time: 0.2628
DEBUG - 2022-09-02 03:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:24:03 --> Total execution time: 0.1182
DEBUG - 2022-09-02 03:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:24:19 --> Total execution time: 0.1089
DEBUG - 2022-09-02 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:24:21 --> Total execution time: 0.1150
DEBUG - 2022-09-02 03:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:24:38 --> Total execution time: 0.1104
DEBUG - 2022-09-02 03:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:26:51 --> Total execution time: 0.1637
DEBUG - 2022-09-02 03:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:28:38 --> Total execution time: 0.2662
DEBUG - 2022-09-02 03:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:28:52 --> Total execution time: 0.1268
DEBUG - 2022-09-02 03:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:29:02 --> Total execution time: 0.0704
DEBUG - 2022-09-02 03:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 03:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:29:11 --> Total execution time: 0.1044
DEBUG - 2022-09-02 03:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:29:15 --> Total execution time: 0.0956
DEBUG - 2022-09-02 03:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:29:38 --> Total execution time: 0.1069
DEBUG - 2022-09-02 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:29:39 --> Total execution time: 0.1103
DEBUG - 2022-09-02 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:29:39 --> Total execution time: 0.1675
DEBUG - 2022-09-02 03:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:29:48 --> Total execution time: 0.0965
DEBUG - 2022-09-02 03:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 03:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 03:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:29:57 --> Total execution time: 0.1180
DEBUG - 2022-09-02 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:02 --> Total execution time: 0.1341
DEBUG - 2022-09-02 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:03 --> Total execution time: 0.1620
DEBUG - 2022-09-02 04:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:05 --> Total execution time: 0.1622
DEBUG - 2022-09-02 04:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:00:18 --> Total execution time: 0.0989
DEBUG - 2022-09-02 04:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:21 --> Total execution time: 0.1049
DEBUG - 2022-09-02 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:22 --> Total execution time: 0.1017
DEBUG - 2022-09-02 04:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:27 --> Total execution time: 0.1210
DEBUG - 2022-09-02 04:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:29 --> Total execution time: 0.1372
DEBUG - 2022-09-02 04:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:31 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:31 --> Total execution time: 0.2819
DEBUG - 2022-09-02 04:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:33 --> Total execution time: 0.1226
DEBUG - 2022-09-02 04:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:34 --> Total execution time: 0.1554
DEBUG - 2022-09-02 04:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:35 --> Total execution time: 0.1027
DEBUG - 2022-09-02 04:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:39 --> Total execution time: 0.1247
DEBUG - 2022-09-02 04:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:40 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:40 --> Total execution time: 0.0962
DEBUG - 2022-09-02 04:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:42 --> Total execution time: 0.2215
DEBUG - 2022-09-02 04:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:30:47 --> Total execution time: 0.1203
DEBUG - 2022-09-02 04:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:31:03 --> Total execution time: 0.0988
DEBUG - 2022-09-02 04:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:31:09 --> Total execution time: 0.1648
DEBUG - 2022-09-02 04:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:31:21 --> Total execution time: 0.1022
DEBUG - 2022-09-02 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:31:27 --> Total execution time: 0.1064
DEBUG - 2022-09-02 04:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:31:29 --> Total execution time: 0.1815
DEBUG - 2022-09-02 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:01:53 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:31:54 --> Total execution time: 0.2581
DEBUG - 2022-09-02 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:01:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:31:55 --> Total execution time: 0.1035
DEBUG - 2022-09-02 04:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:02 --> Total execution time: 0.0946
DEBUG - 2022-09-02 04:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:16 --> Total execution time: 0.1061
DEBUG - 2022-09-02 04:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:29 --> Total execution time: 0.0916
DEBUG - 2022-09-02 04:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:32 --> Total execution time: 0.0986
DEBUG - 2022-09-02 04:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:38 --> Total execution time: 0.1039
DEBUG - 2022-09-02 04:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:41 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:42 --> Total execution time: 0.1216
DEBUG - 2022-09-02 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:45 --> Total execution time: 0.0967
DEBUG - 2022-09-02 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:49 --> Total execution time: 0.0937
DEBUG - 2022-09-02 04:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:51 --> Total execution time: 0.1340
DEBUG - 2022-09-02 04:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:02:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:32:55 --> Total execution time: 0.1154
DEBUG - 2022-09-02 04:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:33:08 --> Total execution time: 0.0978
DEBUG - 2022-09-02 04:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:33:30 --> Total execution time: 0.1076
DEBUG - 2022-09-02 04:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:04:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:34:38 --> Total execution time: 0.1193
DEBUG - 2022-09-02 04:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:07 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:07 --> Total execution time: 0.0770
DEBUG - 2022-09-02 04:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:13 --> Total execution time: 0.0566
DEBUG - 2022-09-02 04:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:18 --> Total execution time: 0.1035
DEBUG - 2022-09-02 04:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:19 --> Total execution time: 0.0870
DEBUG - 2022-09-02 04:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:24 --> Total execution time: 0.1146
DEBUG - 2022-09-02 04:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:33 --> Total execution time: 0.1005
DEBUG - 2022-09-02 04:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:35 --> Total execution time: 0.1393
DEBUG - 2022-09-02 04:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:40 --> Total execution time: 0.1189
DEBUG - 2022-09-02 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:42 --> Total execution time: 0.0997
DEBUG - 2022-09-02 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:45 --> Total execution time: 0.1082
DEBUG - 2022-09-02 04:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:50 --> Total execution time: 0.0988
DEBUG - 2022-09-02 04:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:51 --> Total execution time: 0.1001
DEBUG - 2022-09-02 04:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:55 --> Total execution time: 0.0996
DEBUG - 2022-09-02 04:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:59 --> Total execution time: 0.1121
DEBUG - 2022-09-02 04:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:35:59 --> Total execution time: 0.1004
DEBUG - 2022-09-02 04:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:02 --> Total execution time: 0.1014
DEBUG - 2022-09-02 04:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:06 --> Total execution time: 0.0987
DEBUG - 2022-09-02 04:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:11 --> Total execution time: 0.1024
DEBUG - 2022-09-02 04:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:11 --> Total execution time: 0.0984
DEBUG - 2022-09-02 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:13 --> Total execution time: 0.0926
DEBUG - 2022-09-02 04:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:22 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:22 --> Total execution time: 0.0774
DEBUG - 2022-09-02 04:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:26 --> Total execution time: 0.1102
DEBUG - 2022-09-02 04:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:29 --> Total execution time: 0.0923
DEBUG - 2022-09-02 04:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:46 --> Total execution time: 0.1111
DEBUG - 2022-09-02 04:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:50 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:50 --> Total execution time: 0.0620
DEBUG - 2022-09-02 04:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:55 --> Total execution time: 0.1354
DEBUG - 2022-09-02 04:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:57 --> Total execution time: 0.1214
DEBUG - 2022-09-02 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:36:58 --> Total execution time: 0.0990
DEBUG - 2022-09-02 04:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:07 --> Total execution time: 0.1281
DEBUG - 2022-09-02 04:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:07 --> Total execution time: 0.1585
DEBUG - 2022-09-02 04:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:17 --> Total execution time: 0.1077
DEBUG - 2022-09-02 04:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:22 --> Total execution time: 0.1030
DEBUG - 2022-09-02 04:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:25 --> Total execution time: 0.0792
DEBUG - 2022-09-02 04:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:07:27 --> Total execution time: 0.0961
DEBUG - 2022-09-02 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:07:30 --> Total execution time: 0.1168
DEBUG - 2022-09-02 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:30 --> Total execution time: 0.1002
DEBUG - 2022-09-02 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:07:31 --> Total execution time: 0.0983
DEBUG - 2022-09-02 04:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:41 --> Total execution time: 0.1177
DEBUG - 2022-09-02 04:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:49 --> Total execution time: 0.1223
DEBUG - 2022-09-02 04:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:49 --> Total execution time: 0.1017
DEBUG - 2022-09-02 04:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:52 --> Total execution time: 0.1282
DEBUG - 2022-09-02 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:37:56 --> Total execution time: 0.1170
DEBUG - 2022-09-02 04:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:02 --> Total execution time: 0.0967
DEBUG - 2022-09-02 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:05 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:05 --> Total execution time: 0.0720
DEBUG - 2022-09-02 04:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:12 --> Total execution time: 0.0547
DEBUG - 2022-09-02 04:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:14 --> Total execution time: 0.1129
DEBUG - 2022-09-02 04:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:38:24 --> Total execution time: 2.4010
DEBUG - 2022-09-02 04:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:25 --> Total execution time: 0.0909
DEBUG - 2022-09-02 04:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:28 --> Total execution time: 0.1139
DEBUG - 2022-09-02 04:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 04:08:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 04:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:31 --> Total execution time: 0.1315
DEBUG - 2022-09-02 04:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:35 --> Total execution time: 0.1114
DEBUG - 2022-09-02 04:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:42 --> Total execution time: 0.1083
DEBUG - 2022-09-02 04:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:50 --> Total execution time: 0.1098
DEBUG - 2022-09-02 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:54 --> Total execution time: 0.1019
DEBUG - 2022-09-02 04:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:38:59 --> Total execution time: 0.1077
DEBUG - 2022-09-02 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:39:11 --> Total execution time: 0.0929
DEBUG - 2022-09-02 04:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:39:19 --> Total execution time: 0.0991
DEBUG - 2022-09-02 04:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:41:41 --> Total execution time: 0.1715
DEBUG - 2022-09-02 04:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:41:42 --> Total execution time: 0.1077
DEBUG - 2022-09-02 04:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:41:49 --> Total execution time: 0.0922
DEBUG - 2022-09-02 04:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:42:16 --> Total execution time: 0.0990
DEBUG - 2022-09-02 04:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:42:18 --> Total execution time: 0.0931
DEBUG - 2022-09-02 04:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:42:38 --> Total execution time: 0.0921
DEBUG - 2022-09-02 04:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:42:40 --> Total execution time: 0.1285
DEBUG - 2022-09-02 04:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:42:46 --> Total execution time: 0.1092
DEBUG - 2022-09-02 04:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:42:47 --> Total execution time: 0.0875
DEBUG - 2022-09-02 04:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:42:55 --> Total execution time: 0.0933
DEBUG - 2022-09-02 04:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:43:11 --> Total execution time: 0.0980
DEBUG - 2022-09-02 04:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:43:30 --> Total execution time: 0.0944
DEBUG - 2022-09-02 04:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:44:07 --> Total execution time: 0.0980
DEBUG - 2022-09-02 04:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:44:08 --> Total execution time: 0.1169
DEBUG - 2022-09-02 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:44:36 --> Total execution time: 0.1081
DEBUG - 2022-09-02 04:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:44:39 --> Total execution time: 0.1092
DEBUG - 2022-09-02 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:44:42 --> Total execution time: 0.1103
DEBUG - 2022-09-02 04:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:17 --> Total execution time: 0.1132
DEBUG - 2022-09-02 04:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:15:18 --> Total execution time: 0.0673
DEBUG - 2022-09-02 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:19 --> Total execution time: 0.1089
DEBUG - 2022-09-02 04:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:20 --> Total execution time: 0.0994
DEBUG - 2022-09-02 04:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:23 --> Total execution time: 0.1039
DEBUG - 2022-09-02 04:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:26 --> Total execution time: 0.1054
DEBUG - 2022-09-02 04:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:29 --> Total execution time: 0.2629
DEBUG - 2022-09-02 04:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:30 --> Total execution time: 0.1089
DEBUG - 2022-09-02 04:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:36 --> Total execution time: 0.0919
DEBUG - 2022-09-02 04:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:54 --> Total execution time: 0.0951
DEBUG - 2022-09-02 04:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:55 --> Total execution time: 0.1074
DEBUG - 2022-09-02 04:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:01 --> Total execution time: 0.1171
DEBUG - 2022-09-02 04:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:04 --> Total execution time: 0.0937
DEBUG - 2022-09-02 04:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:11 --> Total execution time: 0.1269
DEBUG - 2022-09-02 04:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:20 --> Total execution time: 0.1138
DEBUG - 2022-09-02 04:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:30 --> Total execution time: 0.1034
DEBUG - 2022-09-02 04:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:33 --> Total execution time: 0.0945
DEBUG - 2022-09-02 04:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:34 --> Total execution time: 0.1108
DEBUG - 2022-09-02 04:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:35 --> Total execution time: 0.1096
DEBUG - 2022-09-02 04:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:37 --> Total execution time: 0.1042
DEBUG - 2022-09-02 04:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:44 --> Total execution time: 0.2451
DEBUG - 2022-09-02 04:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:48 --> Total execution time: 0.0975
DEBUG - 2022-09-02 04:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:52 --> Total execution time: 0.1312
DEBUG - 2022-09-02 04:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:54 --> Total execution time: 0.1418
DEBUG - 2022-09-02 04:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:03 --> Total execution time: 0.1191
DEBUG - 2022-09-02 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:06 --> Total execution time: 0.1861
DEBUG - 2022-09-02 04:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:24 --> Total execution time: 0.0932
DEBUG - 2022-09-02 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:26 --> Total execution time: 0.1224
DEBUG - 2022-09-02 04:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:28 --> Total execution time: 0.1616
DEBUG - 2022-09-02 04:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:33 --> Total execution time: 0.0949
DEBUG - 2022-09-02 04:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:34 --> Total execution time: 0.1163
DEBUG - 2022-09-02 04:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:37 --> Total execution time: 0.1359
DEBUG - 2022-09-02 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:39 --> Total execution time: 0.1563
DEBUG - 2022-09-02 04:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:41 --> Total execution time: 0.1170
DEBUG - 2022-09-02 04:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:51 --> Total execution time: 0.0957
DEBUG - 2022-09-02 04:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:52 --> Total execution time: 0.1004
DEBUG - 2022-09-02 04:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:47:56 --> Total execution time: 0.1026
DEBUG - 2022-09-02 04:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:48:03 --> Total execution time: 0.0945
DEBUG - 2022-09-02 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:48:05 --> Total execution time: 0.2819
DEBUG - 2022-09-02 04:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:48:11 --> Total execution time: 0.1015
DEBUG - 2022-09-02 04:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:48:18 --> Total execution time: 0.1097
DEBUG - 2022-09-02 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:49:49 --> Total execution time: 0.1019
DEBUG - 2022-09-02 04:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:15 --> Total execution time: 0.1263
DEBUG - 2022-09-02 04:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:24 --> Total execution time: 0.0973
DEBUG - 2022-09-02 04:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:31 --> Total execution time: 0.0885
DEBUG - 2022-09-02 04:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:35 --> Total execution time: 0.0942
DEBUG - 2022-09-02 04:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:43 --> Total execution time: 0.2553
DEBUG - 2022-09-02 04:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:47 --> Total execution time: 0.0944
DEBUG - 2022-09-02 04:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:49 --> Total execution time: 0.0653
DEBUG - 2022-09-02 04:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:51 --> Total execution time: 0.0942
DEBUG - 2022-09-02 04:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:53 --> Total execution time: 0.0931
DEBUG - 2022-09-02 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:57 --> Total execution time: 0.1119
DEBUG - 2022-09-02 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:50:58 --> Total execution time: 0.0946
DEBUG - 2022-09-02 04:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:51:01 --> Total execution time: 0.0942
DEBUG - 2022-09-02 04:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:51:01 --> Total execution time: 0.0605
DEBUG - 2022-09-02 04:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:51:04 --> Total execution time: 0.0985
DEBUG - 2022-09-02 04:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:51:12 --> Total execution time: 0.1033
DEBUG - 2022-09-02 04:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:51:17 --> Total execution time: 0.1351
DEBUG - 2022-09-02 04:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:51:54 --> Total execution time: 0.1387
DEBUG - 2022-09-02 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:52:01 --> Total execution time: 0.1001
DEBUG - 2022-09-02 04:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:52:12 --> Total execution time: 0.0955
DEBUG - 2022-09-02 04:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:52:19 --> Total execution time: 0.1012
DEBUG - 2022-09-02 04:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:53:08 --> Total execution time: 0.0956
DEBUG - 2022-09-02 04:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:53:33 --> Total execution time: 0.0932
DEBUG - 2022-09-02 04:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:53:39 --> Total execution time: 0.1026
DEBUG - 2022-09-02 04:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:53:47 --> Total execution time: 0.1058
DEBUG - 2022-09-02 04:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:53:49 --> Total execution time: 0.0996
DEBUG - 2022-09-02 04:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:54:01 --> Total execution time: 0.1507
DEBUG - 2022-09-02 04:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 04:24:18 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 04:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:55:21 --> Total execution time: 0.1700
DEBUG - 2022-09-02 04:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:55:21 --> Total execution time: 0.2553
DEBUG - 2022-09-02 04:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:55:28 --> Total execution time: 0.1808
DEBUG - 2022-09-02 04:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:55:44 --> Total execution time: 0.1446
DEBUG - 2022-09-02 04:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:55:56 --> Total execution time: 0.1282
DEBUG - 2022-09-02 04:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:56:13 --> Total execution time: 0.1473
DEBUG - 2022-09-02 04:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 04:26:15 --> 404 Page Not Found: Checkout-2/index
DEBUG - 2022-09-02 04:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:57:00 --> Total execution time: 0.1634
DEBUG - 2022-09-02 04:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:57:51 --> Total execution time: 0.1222
DEBUG - 2022-09-02 04:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:57:51 --> Total execution time: 0.1226
DEBUG - 2022-09-02 04:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:57:53 --> Total execution time: 0.1392
DEBUG - 2022-09-02 04:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:57:55 --> Total execution time: 0.0994
DEBUG - 2022-09-02 04:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:57:57 --> Total execution time: 0.1044
DEBUG - 2022-09-02 04:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:27:57 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:57:57 --> Total execution time: 0.1012
DEBUG - 2022-09-02 04:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:57:59 --> Total execution time: 0.1188
DEBUG - 2022-09-02 04:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:05:33 --> Total execution time: 0.2638
DEBUG - 2022-09-02 04:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:05:45 --> Total execution time: 0.0938
DEBUG - 2022-09-02 04:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:05:55 --> Total execution time: 0.1383
DEBUG - 2022-09-02 04:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 04:36:16 --> 404 Page Not Found: Refund/index
DEBUG - 2022-09-02 04:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 04:36:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 04:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:06:18 --> Total execution time: 0.1004
DEBUG - 2022-09-02 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:06:25 --> Total execution time: 0.1010
DEBUG - 2022-09-02 04:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:06:47 --> Total execution time: 0.0996
DEBUG - 2022-09-02 04:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:06:52 --> Total execution time: 0.1001
DEBUG - 2022-09-02 04:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:06:58 --> Total execution time: 0.0870
DEBUG - 2022-09-02 04:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:14 --> Total execution time: 0.0972
DEBUG - 2022-09-02 04:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:20 --> Total execution time: 0.2489
DEBUG - 2022-09-02 04:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:25 --> Total execution time: 0.1098
DEBUG - 2022-09-02 04:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:28 --> Total execution time: 0.0915
DEBUG - 2022-09-02 04:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:28 --> Total execution time: 0.1101
DEBUG - 2022-09-02 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:32 --> Total execution time: 0.1095
DEBUG - 2022-09-02 04:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:33 --> Total execution time: 0.0973
DEBUG - 2022-09-02 04:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:39 --> Total execution time: 0.0942
DEBUG - 2022-09-02 04:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:07:49 --> Total execution time: 0.2293
DEBUG - 2022-09-02 04:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:08:37 --> Total execution time: 0.0986
DEBUG - 2022-09-02 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:08:39 --> Total execution time: 0.1095
DEBUG - 2022-09-02 04:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:08:41 --> Total execution time: 0.0962
DEBUG - 2022-09-02 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:08:43 --> Total execution time: 0.0994
DEBUG - 2022-09-02 04:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:09:22 --> Total execution time: 0.1132
DEBUG - 2022-09-02 04:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:10:03 --> Total execution time: 0.1357
DEBUG - 2022-09-02 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:10:06 --> Total execution time: 0.0933
DEBUG - 2022-09-02 04:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:11:17 --> Total execution time: 0.1043
DEBUG - 2022-09-02 04:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:11:20 --> Total execution time: 0.0964
DEBUG - 2022-09-02 04:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:11:27 --> Total execution time: 0.0927
DEBUG - 2022-09-02 04:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:41:33 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:11:33 --> Total execution time: 0.2850
DEBUG - 2022-09-02 04:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:11:43 --> Total execution time: 0.0925
DEBUG - 2022-09-02 04:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:41:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:11:47 --> Total execution time: 0.0911
DEBUG - 2022-09-02 04:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:11:55 --> Total execution time: 0.0953
DEBUG - 2022-09-02 04:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:12:09 --> Total execution time: 0.1252
DEBUG - 2022-09-02 04:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:12:17 --> Total execution time: 0.0997
DEBUG - 2022-09-02 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:12:28 --> Total execution time: 0.1044
DEBUG - 2022-09-02 04:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:12:38 --> Total execution time: 0.1037
DEBUG - 2022-09-02 04:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:42:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:12:55 --> Total execution time: 0.2762
DEBUG - 2022-09-02 04:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:12:56 --> Total execution time: 0.1133
DEBUG - 2022-09-02 04:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:14:25 --> Total execution time: 0.1135
DEBUG - 2022-09-02 04:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:14:35 --> Total execution time: 0.1026
DEBUG - 2022-09-02 04:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:14:54 --> Total execution time: 0.1869
DEBUG - 2022-09-02 04:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:15:03 --> Total execution time: 0.1061
DEBUG - 2022-09-02 04:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:45:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:15:36 --> Total execution time: 0.0852
DEBUG - 2022-09-02 04:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:15:46 --> Total execution time: 0.0639
DEBUG - 2022-09-02 04:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:45:51 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:15:51 --> Total execution time: 0.2479
DEBUG - 2022-09-02 04:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:15:55 --> Total execution time: 0.1403
DEBUG - 2022-09-02 04:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:16:10 --> Total execution time: 0.1144
DEBUG - 2022-09-02 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:15 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:15 --> Total execution time: 0.2711
DEBUG - 2022-09-02 04:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:21 --> Total execution time: 0.1801
DEBUG - 2022-09-02 04:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:21 --> Total execution time: 0.1019
DEBUG - 2022-09-02 04:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:23 --> Total execution time: 0.0604
DEBUG - 2022-09-02 04:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:26 --> Total execution time: 0.1041
DEBUG - 2022-09-02 04:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:27 --> Total execution time: 0.0979
DEBUG - 2022-09-02 04:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:28 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:29 --> Total execution time: 0.1810
DEBUG - 2022-09-02 04:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:29 --> Total execution time: 0.1015
DEBUG - 2022-09-02 04:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:33 --> Total execution time: 0.1266
DEBUG - 2022-09-02 04:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:36 --> Total execution time: 0.0931
DEBUG - 2022-09-02 04:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:40 --> Total execution time: 0.1618
DEBUG - 2022-09-02 04:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:42 --> Total execution time: 0.1205
DEBUG - 2022-09-02 04:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:46 --> Total execution time: 0.0980
DEBUG - 2022-09-02 04:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:48 --> Total execution time: 0.1038
DEBUG - 2022-09-02 04:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:50 --> Total execution time: 0.1139
DEBUG - 2022-09-02 04:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:17:55 --> Total execution time: 0.0954
DEBUG - 2022-09-02 04:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:18:22 --> Total execution time: 0.0940
DEBUG - 2022-09-02 04:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:18:31 --> Total execution time: 0.1070
DEBUG - 2022-09-02 04:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:18:38 --> Total execution time: 0.1129
DEBUG - 2022-09-02 04:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:18:59 --> Total execution time: 0.0968
DEBUG - 2022-09-02 04:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:19:06 --> Total execution time: 0.0987
DEBUG - 2022-09-02 04:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:19:16 --> Total execution time: 0.1100
DEBUG - 2022-09-02 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:19:20 --> Total execution time: 0.1122
DEBUG - 2022-09-02 04:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:19:29 --> Total execution time: 0.1736
DEBUG - 2022-09-02 04:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:19:39 --> Total execution time: 0.1429
DEBUG - 2022-09-02 04:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:21:34 --> Total execution time: 0.0937
DEBUG - 2022-09-02 04:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:22:09 --> Total execution time: 0.3081
DEBUG - 2022-09-02 04:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:22:40 --> Total execution time: 0.1477
DEBUG - 2022-09-02 04:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:22:52 --> Total execution time: 0.1290
DEBUG - 2022-09-02 04:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:23:05 --> Total execution time: 0.1098
DEBUG - 2022-09-02 04:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:23:19 --> Total execution time: 0.3134
DEBUG - 2022-09-02 04:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:23:25 --> Total execution time: 0.1284
DEBUG - 2022-09-02 04:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:23:25 --> Total execution time: 0.1010
DEBUG - 2022-09-02 04:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:23:35 --> Total execution time: 0.0983
DEBUG - 2022-09-02 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:23:42 --> Total execution time: 0.1074
DEBUG - 2022-09-02 04:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:23:51 --> Total execution time: 0.1060
DEBUG - 2022-09-02 04:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:23:58 --> Total execution time: 0.1298
DEBUG - 2022-09-02 04:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:58:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:28:47 --> Total execution time: 0.1618
DEBUG - 2022-09-02 04:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:59:08 --> No URI present. Default controller set.
DEBUG - 2022-09-02 04:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:29:08 --> Total execution time: 0.1038
DEBUG - 2022-09-02 04:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:29:10 --> Total execution time: 0.0975
DEBUG - 2022-09-02 04:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 04:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:29:21 --> Total execution time: 0.1364
DEBUG - 2022-09-02 04:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 04:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 04:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:29:29 --> Total execution time: 0.1165
DEBUG - 2022-09-02 05:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:30:02 --> Total execution time: 0.0784
DEBUG - 2022-09-02 05:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:31:44 --> Total execution time: 0.3024
DEBUG - 2022-09-02 05:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:31:52 --> Total execution time: 0.1409
DEBUG - 2022-09-02 05:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:31:58 --> Total execution time: 0.2293
DEBUG - 2022-09-02 05:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:32:25 --> Total execution time: 0.1319
DEBUG - 2022-09-02 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:32:28 --> Total execution time: 0.0995
DEBUG - 2022-09-02 05:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:32:34 --> Total execution time: 0.2628
DEBUG - 2022-09-02 05:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:32:54 --> Total execution time: 0.1026
DEBUG - 2022-09-02 05:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:32:57 --> Total execution time: 0.1003
DEBUG - 2022-09-02 05:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:32:59 --> Total execution time: 0.2870
DEBUG - 2022-09-02 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:33:20 --> Total execution time: 0.0998
DEBUG - 2022-09-02 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:03:48 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:33:48 --> Total execution time: 0.0626
DEBUG - 2022-09-02 05:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:03:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:33:49 --> Total execution time: 0.0607
DEBUG - 2022-09-02 05:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:04:15 --> Total execution time: 0.0918
DEBUG - 2022-09-02 05:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:04:17 --> Total execution time: 0.1030
DEBUG - 2022-09-02 05:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:04:17 --> Total execution time: 0.1317
DEBUG - 2022-09-02 05:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:05:10 --> Total execution time: 0.1064
DEBUG - 2022-09-02 05:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:05:43 --> Total execution time: 0.1194
DEBUG - 2022-09-02 05:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:36:00 --> Total execution time: 0.1325
DEBUG - 2022-09-02 05:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:36:13 --> Total execution time: 0.1299
DEBUG - 2022-09-02 05:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:36:21 --> Total execution time: 0.1435
DEBUG - 2022-09-02 05:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:36:39 --> Total execution time: 0.1340
DEBUG - 2022-09-02 05:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:36:46 --> Total execution time: 0.1477
DEBUG - 2022-09-02 05:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:37:07 --> Total execution time: 2.5841
DEBUG - 2022-09-02 05:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:37:08 --> Total execution time: 0.0904
DEBUG - 2022-09-02 05:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:37:16 --> Total execution time: 0.1049
DEBUG - 2022-09-02 05:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:37:38 --> Total execution time: 0.0994
DEBUG - 2022-09-02 05:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:37:42 --> Total execution time: 0.1062
DEBUG - 2022-09-02 05:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:37:53 --> Total execution time: 0.0973
DEBUG - 2022-09-02 05:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:37:57 --> Total execution time: 0.1351
DEBUG - 2022-09-02 05:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:38:01 --> Total execution time: 0.3206
DEBUG - 2022-09-02 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:08:26 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:38:26 --> Total execution time: 0.1725
DEBUG - 2022-09-02 05:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:38:48 --> Total execution time: 1.7765
DEBUG - 2022-09-02 05:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:08:53 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:38:53 --> Total execution time: 0.0733
DEBUG - 2022-09-02 05:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:08:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 05:08:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 05:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:12 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:12 --> Total execution time: 0.1216
DEBUG - 2022-09-02 05:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:23 --> Total execution time: 2.0695
DEBUG - 2022-09-02 05:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:35 --> Total execution time: 0.1137
DEBUG - 2022-09-02 05:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:37 --> Total execution time: 0.1223
DEBUG - 2022-09-02 05:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:42 --> Total execution time: 0.1065
DEBUG - 2022-09-02 05:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:48 --> Total execution time: 0.0974
DEBUG - 2022-09-02 05:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:54 --> Total execution time: 0.1013
DEBUG - 2022-09-02 05:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:55 --> Total execution time: 0.1065
DEBUG - 2022-09-02 05:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 05:12:41 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 05:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:44:40 --> Total execution time: 0.1192
DEBUG - 2022-09-02 05:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:16:44 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:46:44 --> Total execution time: 0.1506
DEBUG - 2022-09-02 05:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:47:04 --> Total execution time: 0.2565
DEBUG - 2022-09-02 05:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:18:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:48:15 --> Total execution time: 0.0623
DEBUG - 2022-09-02 05:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:19:54 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:49:54 --> Total execution time: 0.0721
DEBUG - 2022-09-02 05:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:24:39 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:54:40 --> Total execution time: 0.3393
DEBUG - 2022-09-02 05:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:56:16 --> Total execution time: 0.3022
DEBUG - 2022-09-02 05:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:56:24 --> Total execution time: 0.1712
DEBUG - 2022-09-02 05:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:56:28 --> Total execution time: 0.1250
DEBUG - 2022-09-02 05:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:30:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:00:44 --> Total execution time: 0.1329
DEBUG - 2022-09-02 05:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:01:17 --> Total execution time: 0.1037
DEBUG - 2022-09-02 05:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:01:31 --> Total execution time: 0.1009
DEBUG - 2022-09-02 05:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:02:48 --> Total execution time: 0.0991
DEBUG - 2022-09-02 05:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:03:54 --> Total execution time: 0.1067
DEBUG - 2022-09-02 05:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:04:02 --> Total execution time: 0.1049
DEBUG - 2022-09-02 05:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:04:03 --> Total execution time: 0.1378
DEBUG - 2022-09-02 05:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:04:10 --> Total execution time: 0.1052
DEBUG - 2022-09-02 05:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:05:03 --> Total execution time: 0.1233
DEBUG - 2022-09-02 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:36:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:06:47 --> Total execution time: 0.1099
DEBUG - 2022-09-02 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:36:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:06:47 --> Total execution time: 0.0592
DEBUG - 2022-09-02 05:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:06:59 --> Total execution time: 0.1044
DEBUG - 2022-09-02 05:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:07:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-02 05:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:07:04 --> Total execution time: 0.1004
DEBUG - 2022-09-02 05:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:08:00 --> Total execution time: 0.1032
DEBUG - 2022-09-02 05:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:08:34 --> Total execution time: 0.1087
DEBUG - 2022-09-02 05:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:08:36 --> Total execution time: 0.1047
DEBUG - 2022-09-02 05:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:08:46 --> Total execution time: 0.2160
DEBUG - 2022-09-02 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:08:50 --> Total execution time: 0.1023
DEBUG - 2022-09-02 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:38:53 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:08:53 --> Total execution time: 0.0618
DEBUG - 2022-09-02 05:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:08:57 --> Total execution time: 0.0942
DEBUG - 2022-09-02 05:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:09:01 --> Total execution time: 0.0995
DEBUG - 2022-09-02 05:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:09:05 --> Total execution time: 0.0927
DEBUG - 2022-09-02 05:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:09:38 --> Total execution time: 0.1098
DEBUG - 2022-09-02 05:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:39:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:09:43 --> Total execution time: 0.1175
DEBUG - 2022-09-02 05:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:09:57 --> Total execution time: 0.1133
DEBUG - 2022-09-02 05:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:05 --> Total execution time: 0.0965
DEBUG - 2022-09-02 05:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:06 --> Total execution time: 0.0909
DEBUG - 2022-09-02 05:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:07 --> Total execution time: 0.0881
DEBUG - 2022-09-02 05:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:08 --> Total execution time: 0.0872
DEBUG - 2022-09-02 05:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:10 --> Total execution time: 0.0955
DEBUG - 2022-09-02 05:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:12 --> Total execution time: 0.0715
DEBUG - 2022-09-02 05:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:18 --> Total execution time: 0.1090
DEBUG - 2022-09-02 05:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:33 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:33 --> Total execution time: 0.1160
DEBUG - 2022-09-02 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:34 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:34 --> Total execution time: 0.1041
DEBUG - 2022-09-02 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:35 --> Total execution time: 0.1059
DEBUG - 2022-09-02 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:35 --> Total execution time: 0.0915
DEBUG - 2022-09-02 05:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:36 --> Total execution time: 0.0914
DEBUG - 2022-09-02 05:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:37 --> Total execution time: 0.0929
DEBUG - 2022-09-02 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:10:50 --> Total execution time: 0.0949
DEBUG - 2022-09-02 05:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:11:05 --> Total execution time: 0.1052
DEBUG - 2022-09-02 05:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:20 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:11:20 --> Total execution time: 0.0642
DEBUG - 2022-09-02 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:11:21 --> Total execution time: 0.1267
DEBUG - 2022-09-02 05:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 05:41:26 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 05:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:11:31 --> Total execution time: 0.1213
DEBUG - 2022-09-02 05:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:11:34 --> Total execution time: 0.1065
DEBUG - 2022-09-02 05:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:11:38 --> Total execution time: 0.1071
DEBUG - 2022-09-02 05:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:12:04 --> Total execution time: 0.1017
DEBUG - 2022-09-02 05:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:12:50 --> Total execution time: 0.0984
DEBUG - 2022-09-02 05:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:44:41 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:14:41 --> Total execution time: 0.0745
DEBUG - 2022-09-02 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 16:14:46 --> Total execution time: 0.3176
DEBUG - 2022-09-02 05:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:44:47 --> Total execution time: 0.1053
DEBUG - 2022-09-02 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:44:48 --> Total execution time: 0.1021
DEBUG - 2022-09-02 05:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:44:48 --> Total execution time: 0.1013
DEBUG - 2022-09-02 05:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:45:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:15:29 --> Total execution time: 0.0711
DEBUG - 2022-09-02 05:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:16:32 --> Total execution time: 2.1637
DEBUG - 2022-09-02 05:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:46:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 05:46:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 05:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:16:53 --> Total execution time: 0.1158
DEBUG - 2022-09-02 05:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:16:57 --> Total execution time: 0.1348
DEBUG - 2022-09-02 05:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:17:00 --> Total execution time: 0.1282
DEBUG - 2022-09-02 05:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:17:07 --> Total execution time: 0.1398
DEBUG - 2022-09-02 05:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:47:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 05:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:17:14 --> Total execution time: 0.1015
DEBUG - 2022-09-02 05:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:17:21 --> Total execution time: 1.9405
DEBUG - 2022-09-02 05:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:47:40 --> Total execution time: 0.1006
DEBUG - 2022-09-02 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:48:09 --> Total execution time: 0.1019
DEBUG - 2022-09-02 05:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:48:55 --> Total execution time: 0.1033
DEBUG - 2022-09-02 05:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:48:55 --> Total execution time: 0.2308
DEBUG - 2022-09-02 05:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:19:00 --> Total execution time: 0.1126
DEBUG - 2022-09-02 05:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:19:02 --> Total execution time: 0.2686
DEBUG - 2022-09-02 05:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:19:14 --> Total execution time: 0.0989
DEBUG - 2022-09-02 05:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:19:21 --> Total execution time: 0.1682
DEBUG - 2022-09-02 05:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:19:23 --> Total execution time: 0.0594
DEBUG - 2022-09-02 05:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:19:25 --> Total execution time: 0.0673
DEBUG - 2022-09-02 05:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:19:28 --> Total execution time: 0.1180
DEBUG - 2022-09-02 05:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:20:00 --> Total execution time: 1.9520
DEBUG - 2022-09-02 05:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:21:23 --> Total execution time: 0.2734
DEBUG - 2022-09-02 05:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 05:52:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 05:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:22:18 --> Total execution time: 0.0986
DEBUG - 2022-09-02 05:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:23:48 --> Total execution time: 0.1004
DEBUG - 2022-09-02 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:23:53 --> Total execution time: 0.1149
DEBUG - 2022-09-02 05:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 05:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 05:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 05:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:26:08 --> Total execution time: 0.1094
DEBUG - 2022-09-02 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:30:03 --> Total execution time: 0.2466
DEBUG - 2022-09-02 06:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:01:25 --> Total execution time: 0.0980
DEBUG - 2022-09-02 06:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:33:38 --> Total execution time: 0.1549
DEBUG - 2022-09-02 06:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:33:51 --> Total execution time: 0.1051
DEBUG - 2022-09-02 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:34:01 --> Total execution time: 0.1398
DEBUG - 2022-09-02 06:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:34:14 --> Total execution time: 0.1549
DEBUG - 2022-09-02 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:34:15 --> Total execution time: 0.0556
DEBUG - 2022-09-02 06:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:34:35 --> Total execution time: 0.0985
DEBUG - 2022-09-02 06:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:34:38 --> Total execution time: 0.1452
DEBUG - 2022-09-02 06:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:06:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:36:16 --> Total execution time: 0.0664
DEBUG - 2022-09-02 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:36:47 --> Total execution time: 0.1034
DEBUG - 2022-09-02 06:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:37:41 --> Total execution time: 0.0684
DEBUG - 2022-09-02 06:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:07:45 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:37:45 --> Total execution time: 0.0621
DEBUG - 2022-09-02 06:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:10:28 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:40:28 --> Total execution time: 0.0933
DEBUG - 2022-09-02 06:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:40:41 --> Total execution time: 0.0853
DEBUG - 2022-09-02 06:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:40:53 --> Total execution time: 0.1343
DEBUG - 2022-09-02 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:40:59 --> Total execution time: 0.0973
DEBUG - 2022-09-02 06:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:41:07 --> Total execution time: 0.1036
DEBUG - 2022-09-02 06:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:41:15 --> Total execution time: 0.0990
DEBUG - 2022-09-02 06:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:41:18 --> Total execution time: 0.1054
DEBUG - 2022-09-02 06:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:11:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:41:27 --> Total execution time: 0.0654
DEBUG - 2022-09-02 06:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:41:29 --> Total execution time: 0.1350
DEBUG - 2022-09-02 06:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:41:36 --> Total execution time: 0.1095
DEBUG - 2022-09-02 06:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:11:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:41:49 --> Total execution time: 0.0981
DEBUG - 2022-09-02 06:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:42:00 --> Total execution time: 0.1280
DEBUG - 2022-09-02 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:42:06 --> Total execution time: 0.0989
DEBUG - 2022-09-02 06:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:42:13 --> Total execution time: 0.1646
DEBUG - 2022-09-02 06:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:12:43 --> 404 Page Not Found: Wp-json/wp
DEBUG - 2022-09-02 06:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:42:52 --> Total execution time: 0.1002
DEBUG - 2022-09-02 06:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:42:56 --> Total execution time: 0.1132
DEBUG - 2022-09-02 06:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:13:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:13:00 --> 404 Page Not Found: Wp/wp-json
DEBUG - 2022-09-02 06:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:43:01 --> Total execution time: 0.1298
DEBUG - 2022-09-02 06:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:13:02 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:43:02 --> Total execution time: 0.1043
DEBUG - 2022-09-02 06:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:43:04 --> Total execution time: 0.0596
DEBUG - 2022-09-02 06:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:13:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:13:19 --> 404 Page Not Found: Wordpress/wp-json
DEBUG - 2022-09-02 06:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:44:01 --> Total execution time: 0.1132
DEBUG - 2022-09-02 06:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:14:02 --> 404 Page Not Found: Old/wp-json
DEBUG - 2022-09-02 06:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:14:20 --> 404 Page Not Found: New/wp-json
DEBUG - 2022-09-02 06:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:44:25 --> Total execution time: 0.1003
DEBUG - 2022-09-02 06:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:14:36 --> 404 Page Not Found: Blog/wp-json
DEBUG - 2022-09-02 06:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:44:45 --> Total execution time: 0.1343
DEBUG - 2022-09-02 06:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:44:45 --> Total execution time: 0.1001
DEBUG - 2022-09-02 06:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:44:52 --> Total execution time: 0.1094
DEBUG - 2022-09-02 06:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:15:09 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:45:09 --> Total execution time: 0.0963
DEBUG - 2022-09-02 06:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:45:15 --> Total execution time: 0.0915
DEBUG - 2022-09-02 06:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:45:23 --> Total execution time: 0.1568
DEBUG - 2022-09-02 06:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:15:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:45:38 --> Total execution time: 0.0753
DEBUG - 2022-09-02 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:15:39 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:45:39 --> Total execution time: 0.0844
DEBUG - 2022-09-02 06:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:46:06 --> Total execution time: 0.1072
DEBUG - 2022-09-02 06:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:17:04 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:47:04 --> Total execution time: 0.0765
DEBUG - 2022-09-02 06:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:17:07 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:47:07 --> Total execution time: 0.0557
DEBUG - 2022-09-02 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:17:42 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:47:42 --> Total execution time: 0.0717
DEBUG - 2022-09-02 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:17:42 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:47:42 --> Total execution time: 0.0794
DEBUG - 2022-09-02 06:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:17:44 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:47:44 --> Total execution time: 0.0615
DEBUG - 2022-09-02 06:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:17:49 --> Total execution time: 0.1074
DEBUG - 2022-09-02 06:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:18:02 --> Total execution time: 0.1790
DEBUG - 2022-09-02 06:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:18:18 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:48:18 --> Total execution time: 0.0624
DEBUG - 2022-09-02 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:19:48 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:49:48 --> Total execution time: 0.0743
DEBUG - 2022-09-02 06:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:49:56 --> Total execution time: 0.1447
DEBUG - 2022-09-02 06:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:50:52 --> Total execution time: 0.1466
DEBUG - 2022-09-02 06:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:51:13 --> Total execution time: 0.1147
DEBUG - 2022-09-02 06:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:51:27 --> Total execution time: 0.1058
DEBUG - 2022-09-02 06:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:51:29 --> Total execution time: 0.1629
DEBUG - 2022-09-02 06:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:52:42 --> Total execution time: 0.0684
DEBUG - 2022-09-02 06:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:22:51 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:52:51 --> Total execution time: 0.0922
DEBUG - 2022-09-02 06:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:53:57 --> Total execution time: 0.1583
DEBUG - 2022-09-02 06:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:54:30 --> Total execution time: 0.1137
DEBUG - 2022-09-02 06:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:54:34 --> Total execution time: 0.1289
DEBUG - 2022-09-02 06:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:54:36 --> Total execution time: 0.2787
DEBUG - 2022-09-02 06:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:55:53 --> Total execution time: 0.2770
DEBUG - 2022-09-02 06:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:27:05 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 06:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:27:09 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:57:09 --> Total execution time: 0.0664
DEBUG - 2022-09-02 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:57:42 --> Total execution time: 0.1153
DEBUG - 2022-09-02 06:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:57:56 --> Total execution time: 0.1107
DEBUG - 2022-09-02 06:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:00:52 --> Total execution time: 0.1730
DEBUG - 2022-09-02 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:00:59 --> Total execution time: 0.2576
DEBUG - 2022-09-02 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:01:00 --> Total execution time: 0.1136
DEBUG - 2022-09-02 06:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:01:14 --> Total execution time: 0.1026
DEBUG - 2022-09-02 06:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:01:22 --> Total execution time: 0.1172
DEBUG - 2022-09-02 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:02:10 --> Total execution time: 0.0991
DEBUG - 2022-09-02 06:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:02:24 --> Total execution time: 0.1390
DEBUG - 2022-09-02 06:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:03:22 --> Total execution time: 0.1310
DEBUG - 2022-09-02 06:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:03:30 --> Total execution time: 0.1022
DEBUG - 2022-09-02 06:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:04:05 --> Total execution time: 0.2651
DEBUG - 2022-09-02 06:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:05:04 --> Total execution time: 0.1045
DEBUG - 2022-09-02 06:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:05:18 --> Total execution time: 0.3458
DEBUG - 2022-09-02 06:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:05:22 --> Total execution time: 0.1739
DEBUG - 2022-09-02 06:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:06:12 --> Total execution time: 0.1000
DEBUG - 2022-09-02 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:06:27 --> Total execution time: 0.1016
DEBUG - 2022-09-02 06:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:06:40 --> Total execution time: 0.0983
DEBUG - 2022-09-02 06:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:07:04 --> Total execution time: 0.2676
DEBUG - 2022-09-02 06:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:07:26 --> Total execution time: 0.1016
DEBUG - 2022-09-02 06:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:07:50 --> Total execution time: 0.1062
DEBUG - 2022-09-02 06:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:08:01 --> Total execution time: 0.1369
DEBUG - 2022-09-02 06:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:08:48 --> Total execution time: 0.1117
DEBUG - 2022-09-02 06:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:08:54 --> Total execution time: 0.1085
DEBUG - 2022-09-02 06:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:09:06 --> Total execution time: 0.1216
DEBUG - 2022-09-02 06:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:09:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-02 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:09:11 --> Total execution time: 0.1286
DEBUG - 2022-09-02 06:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:09:31 --> Total execution time: 0.1300
DEBUG - 2022-09-02 06:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:09:41 --> Total execution time: 0.1321
DEBUG - 2022-09-02 06:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:09:56 --> Total execution time: 0.1084
DEBUG - 2022-09-02 06:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:10:00 --> Total execution time: 0.0996
DEBUG - 2022-09-02 06:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:42:20 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:12:20 --> Total execution time: 0.1415
DEBUG - 2022-09-02 06:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:42:44 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:12:44 --> Total execution time: 0.0734
DEBUG - 2022-09-02 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:12:48 --> Total execution time: 0.2712
DEBUG - 2022-09-02 06:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:12:57 --> Total execution time: 0.1052
DEBUG - 2022-09-02 06:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:00 --> Total execution time: 0.0933
DEBUG - 2022-09-02 06:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:00 --> Total execution time: 0.1387
DEBUG - 2022-09-02 06:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:13 --> Total execution time: 0.0971
DEBUG - 2022-09-02 06:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:19 --> Total execution time: 0.1442
DEBUG - 2022-09-02 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:21 --> Total execution time: 0.1041
DEBUG - 2022-09-02 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:26 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:26 --> Total execution time: 0.0662
DEBUG - 2022-09-02 06:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:31 --> Total execution time: 0.1478
DEBUG - 2022-09-02 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:34 --> Total execution time: 0.0697
DEBUG - 2022-09-02 06:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:13:46 --> Total execution time: 0.2326
DEBUG - 2022-09-02 06:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:14:28 --> Total execution time: 0.2681
DEBUG - 2022-09-02 06:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:14:28 --> Total execution time: 0.2870
DEBUG - 2022-09-02 06:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:14:33 --> Total execution time: 0.1595
DEBUG - 2022-09-02 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:14:41 --> Total execution time: 0.0955
DEBUG - 2022-09-02 06:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:14:44 --> Total execution time: 0.0917
DEBUG - 2022-09-02 06:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:15:16 --> Total execution time: 0.1599
DEBUG - 2022-09-02 06:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:45:19 --> UTF-8 Support Enabled
ERROR - 2022-09-02 06:45:19 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-09-02 06:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:45:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 06:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 06:45:19 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-09-02 06:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:15:20 --> Total execution time: 0.1251
DEBUG - 2022-09-02 06:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:17:07 --> Total execution time: 0.2645
DEBUG - 2022-09-02 06:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:20:26 --> Total execution time: 0.1361
DEBUG - 2022-09-02 06:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:09 --> Total execution time: 0.3204
DEBUG - 2022-09-02 06:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:11 --> Total execution time: 0.1284
DEBUG - 2022-09-02 06:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:14 --> Total execution time: 0.1826
DEBUG - 2022-09-02 06:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:17 --> Total execution time: 0.1450
DEBUG - 2022-09-02 06:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:20 --> Total execution time: 0.1159
DEBUG - 2022-09-02 06:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:23 --> Total execution time: 0.1226
DEBUG - 2022-09-02 06:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:26 --> Total execution time: 0.1740
DEBUG - 2022-09-02 06:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:29 --> Total execution time: 0.1298
DEBUG - 2022-09-02 06:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:32 --> Total execution time: 0.0976
DEBUG - 2022-09-02 06:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:34 --> Total execution time: 0.1059
DEBUG - 2022-09-02 06:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:37 --> Total execution time: 0.1334
DEBUG - 2022-09-02 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:39 --> Total execution time: 0.1053
DEBUG - 2022-09-02 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:40 --> Total execution time: 0.1454
DEBUG - 2022-09-02 06:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:40 --> Total execution time: 0.1899
DEBUG - 2022-09-02 06:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:40 --> Total execution time: 0.2131
DEBUG - 2022-09-02 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 17:24:42 --> Total execution time: 0.1541
DEBUG - 2022-09-02 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:42 --> Total execution time: 0.2533
DEBUG - 2022-09-02 06:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:43 --> Total execution time: 0.3034
DEBUG - 2022-09-02 06:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 17:24:43 --> Total execution time: 0.1826
DEBUG - 2022-09-02 06:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:43 --> Total execution time: 0.1573
DEBUG - 2022-09-02 06:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:51 --> Total execution time: 0.1214
DEBUG - 2022-09-02 06:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:54 --> Total execution time: 0.0997
DEBUG - 2022-09-02 06:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:57 --> Total execution time: 0.1043
DEBUG - 2022-09-02 06:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:58 --> Total execution time: 0.0907
DEBUG - 2022-09-02 06:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:24:59 --> Total execution time: 0.0990
DEBUG - 2022-09-02 06:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:25:06 --> Total execution time: 0.0685
DEBUG - 2022-09-02 06:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 06:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:25:21 --> Total execution time: 0.0994
DEBUG - 2022-09-02 06:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:25:31 --> Total execution time: 0.1090
DEBUG - 2022-09-02 06:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:25:47 --> Total execution time: 0.1073
DEBUG - 2022-09-02 06:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:56:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 06:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:26:00 --> Total execution time: 0.1107
DEBUG - 2022-09-02 06:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:26:02 --> Total execution time: 0.0900
DEBUG - 2022-09-02 06:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:27:26 --> Total execution time: 0.0959
DEBUG - 2022-09-02 06:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:28:35 --> Total execution time: 0.0609
DEBUG - 2022-09-02 06:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 06:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 06:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:29:58 --> Total execution time: 0.2892
DEBUG - 2022-09-02 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:30:02 --> Total execution time: 0.0632
DEBUG - 2022-09-02 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:30:09 --> Total execution time: 0.0886
DEBUG - 2022-09-02 07:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:34:12 --> Total execution time: 0.1647
DEBUG - 2022-09-02 07:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:09:20 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:39:20 --> Total execution time: 0.1512
DEBUG - 2022-09-02 07:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:39:32 --> Total execution time: 0.0647
DEBUG - 2022-09-02 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:39:46 --> Total execution time: 0.1181
DEBUG - 2022-09-02 07:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:39:58 --> Total execution time: 0.1303
DEBUG - 2022-09-02 07:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:40:01 --> Total execution time: 0.0568
DEBUG - 2022-09-02 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:40:05 --> Total execution time: 0.0959
DEBUG - 2022-09-02 07:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:10:54 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:40:54 --> Total execution time: 0.0790
DEBUG - 2022-09-02 07:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:10:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:40:55 --> Total execution time: 0.0662
DEBUG - 2022-09-02 07:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:41:05 --> Total execution time: 0.0582
DEBUG - 2022-09-02 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:41:18 --> Total execution time: 0.0964
DEBUG - 2022-09-02 07:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:41:26 --> Total execution time: 0.1082
DEBUG - 2022-09-02 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:41:46 --> Total execution time: 0.1076
DEBUG - 2022-09-02 07:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:41:48 --> Total execution time: 0.0976
DEBUG - 2022-09-02 07:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:11:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:41:49 --> Total execution time: 0.0780
DEBUG - 2022-09-02 07:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:41:54 --> Total execution time: 0.0590
DEBUG - 2022-09-02 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:42:35 --> Total execution time: 0.0931
DEBUG - 2022-09-02 07:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:42:36 --> Total execution time: 0.0974
DEBUG - 2022-09-02 07:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:42:37 --> Total execution time: 0.0988
DEBUG - 2022-09-02 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:42:49 --> Total execution time: 0.1052
DEBUG - 2022-09-02 07:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:42:51 --> Total execution time: 0.0983
DEBUG - 2022-09-02 07:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:42:57 --> Total execution time: 0.1308
DEBUG - 2022-09-02 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:43:08 --> Total execution time: 0.1450
DEBUG - 2022-09-02 07:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:46:55 --> Total execution time: 0.1611
DEBUG - 2022-09-02 07:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:47:02 --> Total execution time: 0.2599
DEBUG - 2022-09-02 07:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:47:02 --> Total execution time: 0.0907
DEBUG - 2022-09-02 07:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:47:12 --> Total execution time: 0.1428
DEBUG - 2022-09-02 07:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:47:49 --> Total execution time: 0.1111
DEBUG - 2022-09-02 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:47:57 --> Total execution time: 0.0978
DEBUG - 2022-09-02 07:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:17:59 --> Total execution time: 0.0928
DEBUG - 2022-09-02 07:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:18:13 --> Total execution time: 0.0947
DEBUG - 2022-09-02 07:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:18:30 --> Total execution time: 0.0919
DEBUG - 2022-09-02 07:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:18:36 --> Total execution time: 0.1328
DEBUG - 2022-09-02 07:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:18:42 --> Total execution time: 0.0953
DEBUG - 2022-09-02 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:21:58 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:21:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 17:51:59 --> Total execution time: 0.3303
DEBUG - 2022-09-02 07:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:51:59 --> Total execution time: 0.0916
DEBUG - 2022-09-02 07:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:52:03 --> Total execution time: 0.0561
DEBUG - 2022-09-02 07:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:52:03 --> Total execution time: 0.1011
DEBUG - 2022-09-02 07:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:52:25 --> Total execution time: 0.0956
DEBUG - 2022-09-02 07:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:52:32 --> Total execution time: 0.1553
DEBUG - 2022-09-02 07:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:52:38 --> Total execution time: 0.1349
DEBUG - 2022-09-02 07:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:52:46 --> Total execution time: 0.0951
DEBUG - 2022-09-02 07:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:54:45 --> Total execution time: 0.1069
DEBUG - 2022-09-02 07:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:55:26 --> Total execution time: 0.0809
DEBUG - 2022-09-02 07:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:25:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:55:27 --> Total execution time: 0.0652
DEBUG - 2022-09-02 07:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:25:39 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:55:39 --> Total execution time: 0.0951
DEBUG - 2022-09-02 07:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:55:45 --> Total execution time: 0.1047
DEBUG - 2022-09-02 07:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:55:55 --> Total execution time: 0.0999
DEBUG - 2022-09-02 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:56:02 --> Total execution time: 0.1646
DEBUG - 2022-09-02 07:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:56:12 --> Total execution time: 0.1096
DEBUG - 2022-09-02 07:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:56:13 --> Total execution time: 0.0929
DEBUG - 2022-09-02 07:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:56:39 --> Total execution time: 0.1029
DEBUG - 2022-09-02 07:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:56:54 --> Total execution time: 0.1001
DEBUG - 2022-09-02 07:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:57:01 --> Total execution time: 0.1167
DEBUG - 2022-09-02 07:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:57:05 --> Total execution time: 0.0994
DEBUG - 2022-09-02 07:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:57:15 --> Total execution time: 0.1030
DEBUG - 2022-09-02 07:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:27:26 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:57:26 --> Total execution time: 0.1045
DEBUG - 2022-09-02 07:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:27:50 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:57:50 --> Total execution time: 0.0702
DEBUG - 2022-09-02 07:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:57:56 --> Total execution time: 0.1243
DEBUG - 2022-09-02 07:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:08 --> Total execution time: 0.1042
DEBUG - 2022-09-02 07:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:18 --> Total execution time: 0.0532
DEBUG - 2022-09-02 07:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-02 07:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:24 --> Total execution time: 0.1074
DEBUG - 2022-09-02 07:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:35 --> Total execution time: 0.0635
DEBUG - 2022-09-02 07:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:28:42 --> Total execution time: 0.0904
DEBUG - 2022-09-02 07:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:28:44 --> Total execution time: 0.0910
DEBUG - 2022-09-02 07:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:28:45 --> Total execution time: 0.0892
DEBUG - 2022-09-02 07:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:47 --> Total execution time: 0.0873
DEBUG - 2022-09-02 07:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:49 --> Total execution time: 0.0991
DEBUG - 2022-09-02 07:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:54 --> Total execution time: 0.1224
DEBUG - 2022-09-02 07:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:56 --> Total execution time: 0.0965
DEBUG - 2022-09-02 07:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:56 --> Total execution time: 0.4017
DEBUG - 2022-09-02 07:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:56 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:58:57 --> Total execution time: 0.0909
DEBUG - 2022-09-02 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:00 --> Total execution time: 0.1040
DEBUG - 2022-09-02 07:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:04 --> Total execution time: 0.0933
DEBUG - 2022-09-02 07:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:04 --> Total execution time: 0.1042
DEBUG - 2022-09-02 07:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:13 --> Total execution time: 0.1124
DEBUG - 2022-09-02 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:19 --> Total execution time: 0.1261
DEBUG - 2022-09-02 07:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:23 --> Total execution time: 0.1051
DEBUG - 2022-09-02 07:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:34 --> Total execution time: 0.1065
DEBUG - 2022-09-02 07:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:46 --> Total execution time: 0.1164
DEBUG - 2022-09-02 07:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:59:50 --> Total execution time: 0.1010
DEBUG - 2022-09-02 07:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:00:05 --> Total execution time: 0.1654
DEBUG - 2022-09-02 07:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:31:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 07:31:47 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:03:35 --> Total execution time: 0.1249
DEBUG - 2022-09-02 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:06:44 --> Total execution time: 0.1683
DEBUG - 2022-09-02 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:38:04 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:08:04 --> Total execution time: 0.0692
DEBUG - 2022-09-02 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:11:01 --> Total execution time: 0.1272
DEBUG - 2022-09-02 07:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:11:03 --> Total execution time: 0.0587
DEBUG - 2022-09-02 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:44:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 07:44:20 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:44:31 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:14:31 --> Total execution time: 0.2926
DEBUG - 2022-09-02 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:45:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:15:38 --> Total execution time: 0.0821
DEBUG - 2022-09-02 07:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:46:34 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:16:34 --> Total execution time: 0.0724
DEBUG - 2022-09-02 07:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:46:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:16:36 --> Total execution time: 0.0747
DEBUG - 2022-09-02 07:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:16:40 --> Total execution time: 0.0610
DEBUG - 2022-09-02 07:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:16:47 --> Total execution time: 0.1380
DEBUG - 2022-09-02 07:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:46:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:16:50 --> Total execution time: 0.0768
DEBUG - 2022-09-02 07:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:16:55 --> Total execution time: 0.1740
DEBUG - 2022-09-02 07:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:17:11 --> Total execution time: 0.2614
DEBUG - 2022-09-02 07:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:47:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 07:47:56 --> 404 Page Not Found: Product/deluxe-membership
DEBUG - 2022-09-02 07:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:02 --> Total execution time: 0.1378
DEBUG - 2022-09-02 07:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:09 --> Total execution time: 0.1088
DEBUG - 2022-09-02 07:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:13 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:13 --> Total execution time: 0.0982
DEBUG - 2022-09-02 07:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:17 --> Total execution time: 0.1053
DEBUG - 2022-09-02 07:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:22 --> Total execution time: 2.3946
DEBUG - 2022-09-02 07:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:31 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:31 --> Total execution time: 0.1102
DEBUG - 2022-09-02 07:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 07:48:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 07:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:32 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:33 --> Total execution time: 0.0971
DEBUG - 2022-09-02 07:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:41 --> Total execution time: 0.1043
DEBUG - 2022-09-02 07:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:42 --> Total execution time: 0.1067
DEBUG - 2022-09-02 07:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:48 --> Total execution time: 0.1058
DEBUG - 2022-09-02 07:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:18:55 --> Total execution time: 0.1142
DEBUG - 2022-09-02 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:19:26 --> Total execution time: 0.1026
DEBUG - 2022-09-02 07:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:19:31 --> Total execution time: 0.0930
DEBUG - 2022-09-02 07:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:50:04 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:20:04 --> Total execution time: 0.1011
DEBUG - 2022-09-02 07:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:50:11 --> Total execution time: 0.0944
DEBUG - 2022-09-02 07:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:50:13 --> Total execution time: 0.0996
DEBUG - 2022-09-02 07:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:50:13 --> Total execution time: 0.0879
DEBUG - 2022-09-02 07:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:21:11 --> Total execution time: 1.8062
DEBUG - 2022-09-02 07:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:21:30 --> Total execution time: 0.1762
DEBUG - 2022-09-02 07:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:21:46 --> Total execution time: 0.0979
DEBUG - 2022-09-02 07:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:22:04 --> Total execution time: 0.1018
DEBUG - 2022-09-02 07:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:22:08 --> Total execution time: 0.0955
DEBUG - 2022-09-02 07:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:22:19 --> Total execution time: 0.2586
DEBUG - 2022-09-02 07:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:22:25 --> Total execution time: 0.0979
DEBUG - 2022-09-02 07:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:22:25 --> Total execution time: 0.1095
DEBUG - 2022-09-02 07:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:22:47 --> Total execution time: 0.1331
DEBUG - 2022-09-02 07:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:51 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:22:51 --> Total execution time: 0.0792
DEBUG - 2022-09-02 07:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:22:56 --> Total execution time: 0.0901
DEBUG - 2022-09-02 07:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 07:53:04 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 07:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 07:53:05 --> 404 Page Not Found: Asset-manifestjson/index
DEBUG - 2022-09-02 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:23:12 --> Total execution time: 0.1170
DEBUG - 2022-09-02 07:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:24:31 --> Total execution time: 0.0928
DEBUG - 2022-09-02 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:24:44 --> Total execution time: 0.0583
DEBUG - 2022-09-02 07:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:24:45 --> Total execution time: 0.1550
DEBUG - 2022-09-02 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:24:54 --> Total execution time: 0.1201
DEBUG - 2022-09-02 07:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:25:06 --> Total execution time: 0.1553
DEBUG - 2022-09-02 07:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:25:34 --> Total execution time: 0.0964
DEBUG - 2022-09-02 07:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:25:42 --> Total execution time: 0.1113
DEBUG - 2022-09-02 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:25:57 --> Total execution time: 0.1010
DEBUG - 2022-09-02 07:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:25:58 --> Total execution time: 0.1104
DEBUG - 2022-09-02 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:56:02 --> No URI present. Default controller set.
DEBUG - 2022-09-02 07:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:26:02 --> Total execution time: 0.0666
DEBUG - 2022-09-02 07:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:26:05 --> Total execution time: 0.1028
DEBUG - 2022-09-02 07:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:26:06 --> Total execution time: 0.1000
DEBUG - 2022-09-02 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:26:32 --> Total execution time: 0.0607
DEBUG - 2022-09-02 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 07:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:27:43 --> Total execution time: 0.0962
DEBUG - 2022-09-02 07:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:27:56 --> Total execution time: 0.1057
DEBUG - 2022-09-02 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 07:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 07:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:28:13 --> Total execution time: 0.1782
DEBUG - 2022-09-02 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:30:02 --> Total execution time: 0.1110
DEBUG - 2022-09-02 08:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:31:22 --> Total execution time: 0.2496
DEBUG - 2022-09-02 08:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:32:24 --> Total execution time: 0.2642
DEBUG - 2022-09-02 08:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:04:11 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:34:11 --> Total execution time: 0.0740
DEBUG - 2022-09-02 08:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 08:04:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:04:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:34:17 --> Total execution time: 0.0951
DEBUG - 2022-09-02 08:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:09:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:39:35 --> Total execution time: 0.1428
DEBUG - 2022-09-02 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:09:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:39:55 --> Total execution time: 0.0621
DEBUG - 2022-09-02 08:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:40:06 --> Total execution time: 0.0969
DEBUG - 2022-09-02 08:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:40:19 --> Total execution time: 0.0921
DEBUG - 2022-09-02 08:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:41:04 --> Total execution time: 0.1038
DEBUG - 2022-09-02 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:41:29 --> Total execution time: 0.1058
DEBUG - 2022-09-02 08:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:41:34 --> Total execution time: 0.0949
DEBUG - 2022-09-02 08:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:41:45 --> Total execution time: 0.1031
DEBUG - 2022-09-02 08:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:41:47 --> Total execution time: 0.1031
DEBUG - 2022-09-02 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:43:00 --> Total execution time: 0.0976
DEBUG - 2022-09-02 08:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:43:29 --> Total execution time: 0.0930
DEBUG - 2022-09-02 08:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:43:31 --> Total execution time: 0.0965
DEBUG - 2022-09-02 08:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:43:51 --> Total execution time: 0.1085
DEBUG - 2022-09-02 08:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 08:14:09 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 08:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:14:09 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:44:09 --> Total execution time: 0.0598
DEBUG - 2022-09-02 08:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:44:49 --> Total execution time: 0.0893
DEBUG - 2022-09-02 08:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:44:59 --> Total execution time: 0.0872
DEBUG - 2022-09-02 08:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:45:04 --> Total execution time: 0.0932
DEBUG - 2022-09-02 08:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:45:05 --> Total execution time: 0.0862
DEBUG - 2022-09-02 08:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:15:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:45:21 --> Total execution time: 0.1016
DEBUG - 2022-09-02 08:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:45:41 --> Total execution time: 0.0910
DEBUG - 2022-09-02 08:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:45:49 --> Total execution time: 0.0903
DEBUG - 2022-09-02 08:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:15:51 --> Total execution time: 0.1076
DEBUG - 2022-09-02 08:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:16:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:46:14 --> Total execution time: 0.0780
DEBUG - 2022-09-02 08:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:46:56 --> Total execution time: 0.0967
DEBUG - 2022-09-02 08:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:47:00 --> Total execution time: 0.1067
DEBUG - 2022-09-02 08:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:47:02 --> Total execution time: 0.0963
DEBUG - 2022-09-02 08:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:47:18 --> Total execution time: 0.0950
DEBUG - 2022-09-02 08:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:47:19 --> Total execution time: 0.0998
DEBUG - 2022-09-02 08:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:17:19 --> Total execution time: 0.1594
DEBUG - 2022-09-02 08:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:47:32 --> Total execution time: 0.1226
DEBUG - 2022-09-02 08:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:47:41 --> Total execution time: 0.1378
DEBUG - 2022-09-02 08:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:47:46 --> Total execution time: 0.1220
DEBUG - 2022-09-02 08:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:47:54 --> Total execution time: 0.1458
DEBUG - 2022-09-02 08:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:48:32 --> Total execution time: 0.1011
DEBUG - 2022-09-02 08:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:18:54 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:48:54 --> Total execution time: 0.0979
DEBUG - 2022-09-02 08:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:14 --> Total execution time: 0.1429
DEBUG - 2022-09-02 08:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:47 --> Total execution time: 0.1072
DEBUG - 2022-09-02 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:48 --> Total execution time: 0.0976
DEBUG - 2022-09-02 08:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:51 --> Total execution time: 0.0972
DEBUG - 2022-09-02 08:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:51 --> Total execution time: 0.2947
DEBUG - 2022-09-02 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:56 --> Total execution time: 0.1021
DEBUG - 2022-09-02 08:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:58 --> Total execution time: 0.0884
DEBUG - 2022-09-02 08:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:20:03 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:03 --> Total execution time: 0.0962
DEBUG - 2022-09-02 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:04 --> Total execution time: 0.1371
DEBUG - 2022-09-02 08:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:20:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:17 --> Total execution time: 0.1070
DEBUG - 2022-09-02 08:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:28 --> Total execution time: 0.1028
DEBUG - 2022-09-02 08:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:29 --> Total execution time: 0.0975
DEBUG - 2022-09-02 08:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:33 --> Total execution time: 0.1052
DEBUG - 2022-09-02 08:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:38 --> Total execution time: 2.1114
DEBUG - 2022-09-02 08:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 08:20:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 08:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:21:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:51:00 --> Total execution time: 0.1012
DEBUG - 2022-09-02 08:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:51:04 --> Total execution time: 0.1141
DEBUG - 2022-09-02 08:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:21:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:51:16 --> Total execution time: 0.0686
DEBUG - 2022-09-02 08:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:28:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:58:17 --> Total execution time: 0.1363
DEBUG - 2022-09-02 08:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:28:18 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:58:18 --> Total execution time: 0.0927
DEBUG - 2022-09-02 08:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:58:21 --> Total execution time: 0.0630
DEBUG - 2022-09-02 08:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:28:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:58:27 --> Total execution time: 0.0631
DEBUG - 2022-09-02 08:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:28:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:58:35 --> Total execution time: 0.0928
DEBUG - 2022-09-02 08:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:58:35 --> Total execution time: 0.1035
DEBUG - 2022-09-02 08:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:59:01 --> Total execution time: 0.0616
DEBUG - 2022-09-02 08:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:59:12 --> Total execution time: 0.0961
DEBUG - 2022-09-02 08:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:59:19 --> Total execution time: 0.1104
DEBUG - 2022-09-02 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:59:24 --> Total execution time: 0.0994
DEBUG - 2022-09-02 08:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:59:36 --> Total execution time: 0.0949
DEBUG - 2022-09-02 08:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:05:30 --> Total execution time: 0.1292
DEBUG - 2022-09-02 08:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:06:03 --> Total execution time: 0.1152
DEBUG - 2022-09-02 08:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:06:46 --> Total execution time: 0.1100
DEBUG - 2022-09-02 08:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:06:55 --> Total execution time: 0.1419
DEBUG - 2022-09-02 08:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:07:12 --> Total execution time: 0.0988
DEBUG - 2022-09-02 08:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:07:15 --> Total execution time: 0.0672
DEBUG - 2022-09-02 08:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:07:20 --> Total execution time: 0.0982
DEBUG - 2022-09-02 08:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:07:24 --> Total execution time: 0.1230
DEBUG - 2022-09-02 08:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:07:39 --> Total execution time: 0.0970
DEBUG - 2022-09-02 08:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:07:55 --> Total execution time: 0.1107
DEBUG - 2022-09-02 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:08:18 --> Total execution time: 0.1064
DEBUG - 2022-09-02 08:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:08:33 --> Total execution time: 0.0979
DEBUG - 2022-09-02 08:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:08:40 --> Total execution time: 0.1003
DEBUG - 2022-09-02 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:08:46 --> Total execution time: 0.1213
DEBUG - 2022-09-02 08:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:08:55 --> Total execution time: 0.1023
DEBUG - 2022-09-02 08:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:09:15 --> Total execution time: 0.1046
DEBUG - 2022-09-02 08:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:02 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:02 --> Total execution time: 0.1600
DEBUG - 2022-09-02 08:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:13 --> Total execution time: 0.1055
DEBUG - 2022-09-02 08:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:21 --> Total execution time: 0.1042
DEBUG - 2022-09-02 08:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:36 --> Total execution time: 0.1581
DEBUG - 2022-09-02 08:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:43 --> Total execution time: 0.0975
DEBUG - 2022-09-02 08:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:45 --> Total execution time: 0.0947
DEBUG - 2022-09-02 08:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:45 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:45 --> Total execution time: 0.1448
DEBUG - 2022-09-02 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:47 --> Total execution time: 0.1096
DEBUG - 2022-09-02 08:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:45:54 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:54 --> Total execution time: 0.0571
DEBUG - 2022-09-02 08:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:46:42 --> No URI present. Default controller set.
DEBUG - 2022-09-02 08:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:16:42 --> Total execution time: 0.0614
DEBUG - 2022-09-02 08:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:16:50 --> Total execution time: 0.3150
DEBUG - 2022-09-02 08:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:18:14 --> Total execution time: 0.0771
DEBUG - 2022-09-02 08:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 08:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 08:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 08:54:25 --> Total execution time: 0.3743
DEBUG - 2022-09-02 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:30:02 --> Total execution time: 0.1366
DEBUG - 2022-09-02 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:31:00 --> Total execution time: 0.2583
DEBUG - 2022-09-02 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:03:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:33:36 --> Total execution time: 0.1188
DEBUG - 2022-09-02 09:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:07 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:36:07 --> Total execution time: 0.1165
DEBUG - 2022-09-02 09:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:08 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:36:08 --> Total execution time: 0.0618
DEBUG - 2022-09-02 09:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:36:12 --> Total execution time: 0.0603
DEBUG - 2022-09-02 09:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:36:16 --> Total execution time: 0.0718
DEBUG - 2022-09-02 09:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:24 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:36:24 --> Total execution time: 0.0944
DEBUG - 2022-09-02 09:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:06:34 --> Total execution time: 0.1014
DEBUG - 2022-09-02 09:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 09:06:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 09:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:06:37 --> Total execution time: 0.1243
DEBUG - 2022-09-02 09:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:06:37 --> Total execution time: 0.1000
DEBUG - 2022-09-02 09:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:06:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:36:59 --> Total execution time: 0.0969
DEBUG - 2022-09-02 09:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:40:00 --> Total execution time: 0.1377
DEBUG - 2022-09-02 09:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:40:19 --> Total execution time: 0.0584
DEBUG - 2022-09-02 09:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:10:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:40:35 --> Total execution time: 0.2593
DEBUG - 2022-09-02 09:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:10:43 --> Total execution time: 0.1010
DEBUG - 2022-09-02 09:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:10:45 --> Total execution time: 0.0921
DEBUG - 2022-09-02 09:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:10:45 --> Total execution time: 0.0989
DEBUG - 2022-09-02 09:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:40:57 --> Total execution time: 0.0608
DEBUG - 2022-09-02 09:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:11:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:41:00 --> Total execution time: 0.0970
DEBUG - 2022-09-02 09:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:42:13 --> Total execution time: 0.2614
DEBUG - 2022-09-02 09:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:42:22 --> Total execution time: 0.1140
DEBUG - 2022-09-02 09:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:42:22 --> Total execution time: 0.1091
DEBUG - 2022-09-02 09:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:42:29 --> Total execution time: 0.1233
DEBUG - 2022-09-02 09:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:13:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:43:25 --> Total execution time: 0.0689
DEBUG - 2022-09-02 09:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:13:30 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:43:30 --> Total execution time: 0.1211
DEBUG - 2022-09-02 09:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:14:00 --> Total execution time: 0.0966
DEBUG - 2022-09-02 09:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:14:02 --> Total execution time: 0.0954
DEBUG - 2022-09-02 09:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:14:03 --> Total execution time: 0.0866
DEBUG - 2022-09-02 09:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:46:14 --> Total execution time: 2.3119
DEBUG - 2022-09-02 09:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:16:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 09:16:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 09:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:18:54 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:48:54 --> Total execution time: 0.1364
DEBUG - 2022-09-02 09:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:48:57 --> Total execution time: 0.0623
DEBUG - 2022-09-02 09:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:18:57 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:48:57 --> Total execution time: 0.0648
DEBUG - 2022-09-02 09:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:19:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:49:17 --> Total execution time: 0.0967
DEBUG - 2022-09-02 09:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:49:20 --> Total execution time: 0.1002
DEBUG - 2022-09-02 09:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:49:48 --> Total execution time: 0.0920
DEBUG - 2022-09-02 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:50:19 --> Total execution time: 0.1204
DEBUG - 2022-09-02 09:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:03 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:03 --> Total execution time: 0.0801
DEBUG - 2022-09-02 09:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:06 --> Total execution time: 0.0926
DEBUG - 2022-09-02 09:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:14 --> Total execution time: 1.8846
DEBUG - 2022-09-02 09:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:31 --> Total execution time: 0.1053
DEBUG - 2022-09-02 09:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:40 --> Total execution time: 1.8383
DEBUG - 2022-09-02 09:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:55 --> Total execution time: 1.7801
DEBUG - 2022-09-02 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:58 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:59 --> Total execution time: 0.2505
DEBUG - 2022-09-02 09:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:21:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:59 --> Total execution time: 0.1032
DEBUG - 2022-09-02 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:22:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:55 --> Total execution time: 0.0707
DEBUG - 2022-09-02 09:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:13 --> Total execution time: 0.0585
DEBUG - 2022-09-02 09:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:24 --> Total execution time: 0.1022
DEBUG - 2022-09-02 09:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:28 --> Total execution time: 0.1301
DEBUG - 2022-09-02 09:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:35 --> Total execution time: 0.2793
DEBUG - 2022-09-02 09:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:37 --> Total execution time: 0.0999
DEBUG - 2022-09-02 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:48 --> Total execution time: 0.1001
DEBUG - 2022-09-02 09:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:51 --> Total execution time: 0.1166
DEBUG - 2022-09-02 09:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:57 --> Total execution time: 0.1142
DEBUG - 2022-09-02 09:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:58 --> Total execution time: 0.1157
DEBUG - 2022-09-02 09:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:00 --> Total execution time: 0.0742
DEBUG - 2022-09-02 09:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:01 --> Total execution time: 0.1743
DEBUG - 2022-09-02 09:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:02 --> Total execution time: 0.1531
DEBUG - 2022-09-02 09:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:02 --> Total execution time: 0.1084
DEBUG - 2022-09-02 09:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:06 --> Total execution time: 0.0964
DEBUG - 2022-09-02 09:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:09 --> Total execution time: 0.0965
DEBUG - 2022-09-02 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:10 --> Total execution time: 0.1041
DEBUG - 2022-09-02 09:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:12 --> Total execution time: 0.1017
DEBUG - 2022-09-02 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:21 --> Total execution time: 0.0997
DEBUG - 2022-09-02 09:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:28 --> Total execution time: 0.0976
DEBUG - 2022-09-02 09:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:32 --> Total execution time: 0.0966
DEBUG - 2022-09-02 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:35 --> Total execution time: 0.1003
DEBUG - 2022-09-02 09:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:39 --> Total execution time: 0.1530
DEBUG - 2022-09-02 09:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:39 --> Total execution time: 0.1071
DEBUG - 2022-09-02 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:44 --> Total execution time: 0.0995
DEBUG - 2022-09-02 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:49 --> Total execution time: 0.0943
DEBUG - 2022-09-02 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:50 --> Total execution time: 0.1019
DEBUG - 2022-09-02 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:55:00 --> Total execution time: 0.1309
DEBUG - 2022-09-02 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:25:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:55:01 --> Total execution time: 0.1079
DEBUG - 2022-09-02 09:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:25:11 --> Total execution time: 0.1239
DEBUG - 2022-09-02 09:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:25:13 --> Total execution time: 0.0986
DEBUG - 2022-09-02 09:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:25:13 --> Total execution time: 0.0863
DEBUG - 2022-09-02 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:55:23 --> Total execution time: 0.1271
DEBUG - 2022-09-02 09:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:55:26 --> Total execution time: 0.1094
DEBUG - 2022-09-02 09:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:55:56 --> Total execution time: 0.1301
DEBUG - 2022-09-02 09:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:56:00 --> Total execution time: 0.0650
DEBUG - 2022-09-02 09:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:56:04 --> Total execution time: 0.1064
DEBUG - 2022-09-02 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:56:12 --> Total execution time: 0.0997
DEBUG - 2022-09-02 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:56:22 --> Total execution time: 0.1344
DEBUG - 2022-09-02 09:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:56:58 --> Total execution time: 1.7417
DEBUG - 2022-09-02 09:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 09:27:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 09:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:27:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:57:49 --> Total execution time: 0.1082
DEBUG - 2022-09-02 09:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:28:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:58:10 --> Total execution time: 0.2512
DEBUG - 2022-09-02 09:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:28:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:58:36 --> Total execution time: 0.1206
DEBUG - 2022-09-02 09:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:59:11 --> Total execution time: 1.8668
DEBUG - 2022-09-02 09:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:59:43 --> Total execution time: 1.7506
DEBUG - 2022-09-02 09:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:59:45 --> Total execution time: 2.2277
DEBUG - 2022-09-02 09:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:30:31 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:32 --> Total execution time: 0.0976
DEBUG - 2022-09-02 09:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:30:34 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:30:34 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:34 --> Total execution time: 0.0620
DEBUG - 2022-09-02 09:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:34 --> Total execution time: 0.0613
DEBUG - 2022-09-02 09:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:40 --> Total execution time: 0.0933
DEBUG - 2022-09-02 09:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:30:53 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:53 --> Total execution time: 0.1175
DEBUG - 2022-09-02 09:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:31:07 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:01:07 --> Total execution time: 0.0956
DEBUG - 2022-09-02 09:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:31:14 --> Total execution time: 0.0921
DEBUG - 2022-09-02 09:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:31:17 --> Total execution time: 0.1015
DEBUG - 2022-09-02 09:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:31:17 --> Total execution time: 0.1006
DEBUG - 2022-09-02 09:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:32:11 --> Total execution time: 0.0934
DEBUG - 2022-09-02 09:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:32:14 --> Total execution time: 0.0925
DEBUG - 2022-09-02 09:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:32:14 --> Total execution time: 0.0902
DEBUG - 2022-09-02 09:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:32:27 --> Total execution time: 0.1229
DEBUG - 2022-09-02 09:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:32:30 --> Total execution time: 0.1030
DEBUG - 2022-09-02 09:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:32:30 --> Total execution time: 0.0963
DEBUG - 2022-09-02 09:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:02:33 --> Total execution time: 0.1321
DEBUG - 2022-09-02 09:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:01 --> Total execution time: 0.1006
DEBUG - 2022-09-02 09:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:09 --> Total execution time: 0.1158
DEBUG - 2022-09-02 09:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:22 --> Total execution time: 0.1197
DEBUG - 2022-09-02 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:28 --> Total execution time: 0.0881
DEBUG - 2022-09-02 09:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:31 --> Total execution time: 0.1113
DEBUG - 2022-09-02 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:35 --> Total execution time: 0.0977
DEBUG - 2022-09-02 09:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:42 --> Total execution time: 0.1112
DEBUG - 2022-09-02 20:03:42 --> Total execution time: 0.1528
DEBUG - 2022-09-02 09:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:43 --> Total execution time: 0.0944
DEBUG - 2022-09-02 09:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:47 --> Total execution time: 0.0970
DEBUG - 2022-09-02 09:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:52 --> Total execution time: 0.1123
DEBUG - 2022-09-02 09:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:03:59 --> Total execution time: 0.1159
DEBUG - 2022-09-02 09:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:10 --> Total execution time: 0.0895
DEBUG - 2022-09-02 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:31 --> Total execution time: 0.1071
DEBUG - 2022-09-02 09:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:41 --> Total execution time: 0.0994
DEBUG - 2022-09-02 09:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:15 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:15 --> Total execution time: 0.3214
DEBUG - 2022-09-02 09:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:27 --> Total execution time: 0.0974
DEBUG - 2022-09-02 09:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:39:27 --> Total execution time: 0.0962
DEBUG - 2022-09-02 09:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:39:29 --> Total execution time: 0.1181
DEBUG - 2022-09-02 09:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:39:29 --> Total execution time: 0.1050
DEBUG - 2022-09-02 09:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:31 --> Total execution time: 0.1052
DEBUG - 2022-09-02 09:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:39 --> Total execution time: 0.1114
DEBUG - 2022-09-02 09:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:45 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:45 --> Total execution time: 0.0978
DEBUG - 2022-09-02 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:39:57 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:57 --> Total execution time: 0.0982
DEBUG - 2022-09-02 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:40:05 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:10:05 --> Total execution time: 0.0613
DEBUG - 2022-09-02 09:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:10:15 --> Total execution time: 0.0923
DEBUG - 2022-09-02 09:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:40:18 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:10:18 --> Total execution time: 0.0973
DEBUG - 2022-09-02 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:40:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:10:29 --> Total execution time: 0.2533
DEBUG - 2022-09-02 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:40:42 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:10:43 --> Total execution time: 0.1128
DEBUG - 2022-09-02 09:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:41:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:11:10 --> Total execution time: 0.0950
DEBUG - 2022-09-02 09:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:11:25 --> Total execution time: 0.0978
DEBUG - 2022-09-02 09:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:41:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:11:27 --> Total execution time: 0.0959
DEBUG - 2022-09-02 09:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:11:39 --> Total execution time: 0.1099
DEBUG - 2022-09-02 09:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:11:43 --> Total execution time: 0.0950
DEBUG - 2022-09-02 09:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:11:48 --> Total execution time: 0.1692
DEBUG - 2022-09-02 09:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:02 --> Total execution time: 0.1595
DEBUG - 2022-09-02 09:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:05 --> Total execution time: 0.1328
DEBUG - 2022-09-02 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:10 --> Total execution time: 0.1031
DEBUG - 2022-09-02 09:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:12 --> Total execution time: 0.1009
DEBUG - 2022-09-02 09:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:21 --> Total execution time: 0.1247
DEBUG - 2022-09-02 09:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:31 --> Total execution time: 0.0997
DEBUG - 2022-09-02 09:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:36 --> Total execution time: 0.1307
DEBUG - 2022-09-02 09:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:42 --> Total execution time: 0.1044
DEBUG - 2022-09-02 09:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:42:56 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:12:56 --> Total execution time: 0.0936
DEBUG - 2022-09-02 09:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:13:18 --> Total execution time: 0.1217
DEBUG - 2022-09-02 09:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:13:29 --> Total execution time: 0.1020
DEBUG - 2022-09-02 09:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:13:31 --> Total execution time: 0.0973
DEBUG - 2022-09-02 09:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:43:50 --> Total execution time: 0.0987
DEBUG - 2022-09-02 09:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:13:57 --> Total execution time: 0.0948
DEBUG - 2022-09-02 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:14:09 --> Total execution time: 0.1395
DEBUG - 2022-09-02 09:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:14:11 --> Total execution time: 0.1993
DEBUG - 2022-09-02 09:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:14:18 --> Total execution time: 0.6575
DEBUG - 2022-09-02 09:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:54 --> Total execution time: 0.1002
DEBUG - 2022-09-02 09:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:34 --> Total execution time: 0.3376
DEBUG - 2022-09-02 09:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:39 --> Total execution time: 0.0993
DEBUG - 2022-09-02 09:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:43 --> Total execution time: 0.1102
DEBUG - 2022-09-02 09:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:47 --> Total execution time: 0.1058
DEBUG - 2022-09-02 09:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:47 --> Total execution time: 0.1100
DEBUG - 2022-09-02 09:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:49 --> Total execution time: 0.0976
DEBUG - 2022-09-02 09:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:50 --> Total execution time: 0.0986
DEBUG - 2022-09-02 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:54 --> Total execution time: 0.0959
DEBUG - 2022-09-02 09:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:57 --> Total execution time: 0.1044
DEBUG - 2022-09-02 09:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:23:05 --> Total execution time: 0.1060
DEBUG - 2022-09-02 09:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:23:12 --> Total execution time: 0.1002
DEBUG - 2022-09-02 09:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:23:18 --> Total execution time: 0.1072
DEBUG - 2022-09-02 09:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:23:26 --> Total execution time: 0.0965
DEBUG - 2022-09-02 09:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:23:33 --> Total execution time: 0.0951
DEBUG - 2022-09-02 09:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 09:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:23:43 --> Total execution time: 0.0915
DEBUG - 2022-09-02 09:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:55:15 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:25:15 --> Total execution time: 0.1017
DEBUG - 2022-09-02 09:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:28:31 --> Total execution time: 0.3457
DEBUG - 2022-09-02 09:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:28:32 --> Total execution time: 0.1296
DEBUG - 2022-09-02 09:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:58:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:28:43 --> Total execution time: 0.0890
DEBUG - 2022-09-02 09:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:28:51 --> Total execution time: 0.0979
DEBUG - 2022-09-02 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 09:59:12 --> No URI present. Default controller set.
DEBUG - 2022-09-02 09:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 09:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:29:12 --> Total execution time: 0.0622
DEBUG - 2022-09-02 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:30:02 --> Total execution time: 0.0881
DEBUG - 2022-09-02 10:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:01:45 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:31:45 --> Total execution time: 0.1036
DEBUG - 2022-09-02 10:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:01:54 --> Total execution time: 0.1122
DEBUG - 2022-09-02 10:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:01:57 --> Total execution time: 0.1036
DEBUG - 2022-09-02 10:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:01:57 --> Total execution time: 0.1453
DEBUG - 2022-09-02 10:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:33:01 --> Total execution time: 7.6524
DEBUG - 2022-09-02 10:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:03:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 10:03:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 10:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:37:10 --> Total execution time: 2.0229
DEBUG - 2022-09-02 10:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 10:08:21 --> 404 Page Not Found: My-account/index
DEBUG - 2022-09-02 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:42:25 --> Total execution time: 0.3438
DEBUG - 2022-09-02 10:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:42:28 --> Total execution time: 0.1391
DEBUG - 2022-09-02 10:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:42:59 --> Total execution time: 0.1156
DEBUG - 2022-09-02 10:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:43:07 --> Total execution time: 0.1013
DEBUG - 2022-09-02 10:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:43:22 --> Total execution time: 0.0981
DEBUG - 2022-09-02 10:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:43:29 --> Total execution time: 0.0934
DEBUG - 2022-09-02 10:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:43:40 --> Total execution time: 0.2447
DEBUG - 2022-09-02 10:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:43:45 --> Total execution time: 0.0980
DEBUG - 2022-09-02 10:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:14:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:44:10 --> Total execution time: 0.0706
DEBUG - 2022-09-02 10:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:44:16 --> Total execution time: 0.0939
DEBUG - 2022-09-02 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:44:33 --> Total execution time: 0.1031
DEBUG - 2022-09-02 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:44:41 --> Total execution time: 0.1263
DEBUG - 2022-09-02 10:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:19:07 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:49:07 --> Total execution time: 0.1339
DEBUG - 2022-09-02 10:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:19:08 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:49:08 --> Total execution time: 0.0815
DEBUG - 2022-09-02 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:20:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:50:10 --> Total execution time: 0.1022
DEBUG - 2022-09-02 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:20:33 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:50:33 --> Total execution time: 0.1345
DEBUG - 2022-09-02 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:50:36 --> Total execution time: 0.0706
DEBUG - 2022-09-02 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:50:56 --> Total execution time: 0.1036
DEBUG - 2022-09-02 10:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:51:02 --> Total execution time: 0.1791
DEBUG - 2022-09-02 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:51:06 --> Total execution time: 0.1252
DEBUG - 2022-09-02 10:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:51:15 --> Total execution time: 0.1473
DEBUG - 2022-09-02 10:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:51:23 --> Total execution time: 0.1023
DEBUG - 2022-09-02 10:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:23:59 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:53:59 --> Total execution time: 0.1692
DEBUG - 2022-09-02 10:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:24:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:01 --> Total execution time: 0.1063
DEBUG - 2022-09-02 10:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:03 --> Total execution time: 0.1038
DEBUG - 2022-09-02 10:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:36 --> Total execution time: 0.1026
DEBUG - 2022-09-02 10:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:42 --> Total execution time: 0.1492
DEBUG - 2022-09-02 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:56 --> Total execution time: 0.1922
DEBUG - 2022-09-02 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:55:16 --> Total execution time: 0.0608
DEBUG - 2022-09-02 10:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:55:34 --> Total execution time: 0.1005
DEBUG - 2022-09-02 10:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 10:26:41 --> 404 Page Not Found: Reselling-course/index
DEBUG - 2022-09-02 10:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:00:29 --> Total execution time: 0.0925
DEBUG - 2022-09-02 10:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:30:44 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:00:44 --> Total execution time: 0.0693
DEBUG - 2022-09-02 10:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:01:03 --> Total execution time: 0.1014
DEBUG - 2022-09-02 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:01:15 --> Total execution time: 0.1209
DEBUG - 2022-09-02 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:01:33 --> Total execution time: 0.2778
DEBUG - 2022-09-02 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:01:37 --> Total execution time: 0.1073
DEBUG - 2022-09-02 10:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:31:37 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:01:37 --> Total execution time: 0.0607
DEBUG - 2022-09-02 10:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:31:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:01:38 --> Total execution time: 0.0646
DEBUG - 2022-09-02 10:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:33:05 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:03:05 --> Total execution time: 0.0627
DEBUG - 2022-09-02 10:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:33:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:03:24 --> Total execution time: 0.2521
DEBUG - 2022-09-02 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:33:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:03:25 --> Total execution time: 0.1085
DEBUG - 2022-09-02 10:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:03:33 --> Total execution time: 0.1013
DEBUG - 2022-09-02 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:03:38 --> Total execution time: 0.1290
DEBUG - 2022-09-02 10:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:03:48 --> Total execution time: 0.1494
DEBUG - 2022-09-02 10:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:04:03 --> Total execution time: 0.1187
DEBUG - 2022-09-02 10:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:04:20 --> Total execution time: 0.1059
DEBUG - 2022-09-02 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:04:25 --> Total execution time: 0.1351
DEBUG - 2022-09-02 10:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:04:32 --> Total execution time: 0.0997
DEBUG - 2022-09-02 10:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:36:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:06:47 --> Total execution time: 0.1620
DEBUG - 2022-09-02 10:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:37:40 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:07:40 --> Total execution time: 0.0617
DEBUG - 2022-09-02 10:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:37:48 --> Total execution time: 0.0630
DEBUG - 2022-09-02 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:37:50 --> Total execution time: 0.0973
DEBUG - 2022-09-02 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:37:50 --> Total execution time: 0.1158
DEBUG - 2022-09-02 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:38:33 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:08:33 --> Total execution time: 0.2434
DEBUG - 2022-09-02 10:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:08:48 --> Total execution time: 0.0927
DEBUG - 2022-09-02 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:39:41 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:09:41 --> Total execution time: 0.0984
DEBUG - 2022-09-02 10:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:11:28 --> Total execution time: 0.2626
DEBUG - 2022-09-02 10:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:11:47 --> Total execution time: 0.1042
DEBUG - 2022-09-02 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:11:48 --> Total execution time: 0.1004
DEBUG - 2022-09-02 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:42:18 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:18 --> Total execution time: 0.0623
DEBUG - 2022-09-02 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:42:19 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:19 --> Total execution time: 0.0611
DEBUG - 2022-09-02 10:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:24 --> Total execution time: 0.1061
DEBUG - 2022-09-02 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:42:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:25 --> Total execution time: 0.0680
DEBUG - 2022-09-02 10:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:29 --> Total execution time: 0.1103
DEBUG - 2022-09-02 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:31 --> Total execution time: 0.0662
DEBUG - 2022-09-02 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:13:11 --> Total execution time: 0.1031
DEBUG - 2022-09-02 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:13:12 --> Total execution time: 0.0735
DEBUG - 2022-09-02 10:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:13:26 --> Total execution time: 0.0975
DEBUG - 2022-09-02 10:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:13:30 --> Total execution time: 0.0983
DEBUG - 2022-09-02 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:13:37 --> Total execution time: 0.1262
DEBUG - 2022-09-02 10:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:13:41 --> Total execution time: 0.1068
DEBUG - 2022-09-02 10:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:13:47 --> Total execution time: 0.1274
DEBUG - 2022-09-02 10:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:44:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:14:01 --> Total execution time: 0.0648
DEBUG - 2022-09-02 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:14:07 --> Total execution time: 0.1122
DEBUG - 2022-09-02 10:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:44:49 --> Total execution time: 0.0956
DEBUG - 2022-09-02 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:14:51 --> Total execution time: 0.0586
DEBUG - 2022-09-02 10:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:03 --> Total execution time: 0.0929
DEBUG - 2022-09-02 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:14 --> Total execution time: 0.1117
DEBUG - 2022-09-02 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:22 --> Total execution time: 0.1083
DEBUG - 2022-09-02 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:23 --> Total execution time: 0.1003
DEBUG - 2022-09-02 10:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:26 --> Total execution time: 0.1321
DEBUG - 2022-09-02 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:33 --> Total execution time: 0.1042
DEBUG - 2022-09-02 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:35 --> Total execution time: 0.0974
DEBUG - 2022-09-02 10:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:40 --> Total execution time: 0.0994
DEBUG - 2022-09-02 10:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:40 --> Total execution time: 0.0937
DEBUG - 2022-09-02 10:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:45 --> Total execution time: 0.1010
DEBUG - 2022-09-02 10:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:48 --> Total execution time: 0.0992
DEBUG - 2022-09-02 10:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:15:54 --> Total execution time: 0.0958
DEBUG - 2022-09-02 10:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:48:42 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:18:42 --> Total execution time: 0.3201
DEBUG - 2022-09-02 10:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:48:43 --> Total execution time: 0.0955
DEBUG - 2022-09-02 10:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:48:48 --> Total execution time: 0.1002
DEBUG - 2022-09-02 10:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:48:48 --> Total execution time: 0.0912
DEBUG - 2022-09-02 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:19:12 --> Total execution time: 0.0604
DEBUG - 2022-09-02 10:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:19:53 --> Total execution time: 2.3257
DEBUG - 2022-09-02 10:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 10:49:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 10:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:22:05 --> Total execution time: 0.2997
DEBUG - 2022-09-02 10:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:22:48 --> Total execution time: 1.8584
DEBUG - 2022-09-02 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:23:12 --> Total execution time: 0.0996
DEBUG - 2022-09-02 10:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:53:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:23:27 --> Total execution time: 0.1004
DEBUG - 2022-09-02 10:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:23:33 --> Total execution time: 0.1188
DEBUG - 2022-09-02 10:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:23:50 --> Total execution time: 0.2500
DEBUG - 2022-09-02 10:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:24:12 --> Total execution time: 0.0972
DEBUG - 2022-09-02 10:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:54:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:24:30 --> Total execution time: 0.2428
DEBUG - 2022-09-02 10:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:26:14 --> Total execution time: 0.0987
DEBUG - 2022-09-02 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:26:22 --> Total execution time: 0.2616
DEBUG - 2022-09-02 10:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:26:26 --> Total execution time: 0.1044
DEBUG - 2022-09-02 10:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 10:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:26:35 --> Total execution time: 0.0958
DEBUG - 2022-09-02 10:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:26:54 --> Total execution time: 0.0935
DEBUG - 2022-09-02 10:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:57:53 --> No URI present. Default controller set.
DEBUG - 2022-09-02 10:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:27:53 --> Total execution time: 0.0697
DEBUG - 2022-09-02 10:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 10:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 10:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:29:36 --> Total execution time: 0.0947
DEBUG - 2022-09-02 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:30:02 --> Total execution time: 0.0645
DEBUG - 2022-09-02 11:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:30:51 --> Total execution time: 0.2546
DEBUG - 2022-09-02 11:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:32:33 --> Total execution time: 0.2502
DEBUG - 2022-09-02 11:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:32:43 --> Total execution time: 0.0985
DEBUG - 2022-09-02 11:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:32:46 --> Total execution time: 0.1008
DEBUG - 2022-09-02 11:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:32:54 --> Total execution time: 0.1046
DEBUG - 2022-09-02 11:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:33:11 --> Total execution time: 0.0996
DEBUG - 2022-09-02 11:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:07:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:37:00 --> Total execution time: 0.1351
DEBUG - 2022-09-02 11:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:37:56 --> Total execution time: 0.0895
DEBUG - 2022-09-02 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:08:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:38:00 --> Total execution time: 0.0565
DEBUG - 2022-09-02 11:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:38:05 --> Total execution time: 0.0860
DEBUG - 2022-09-02 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:38:32 --> Total execution time: 0.0584
DEBUG - 2022-09-02 11:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:08:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:38:36 --> Total execution time: 0.0644
DEBUG - 2022-09-02 11:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:08:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:38:38 --> Total execution time: 0.0614
DEBUG - 2022-09-02 11:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:39:03 --> Total execution time: 0.1108
DEBUG - 2022-09-02 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:39:41 --> Total execution time: 0.0993
DEBUG - 2022-09-02 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:39:41 --> Total execution time: 0.2147
DEBUG - 2022-09-02 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:11:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 11:11:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 11:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:11:07 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:41:07 --> Total execution time: 0.0622
DEBUG - 2022-09-02 11:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:11:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 11:11:07 --> 404 Page Not Found: Test_404_page/index
DEBUG - 2022-09-02 11:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:11:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:41:21 --> Total execution time: 0.0953
DEBUG - 2022-09-02 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:41:54 --> Total execution time: 0.2508
DEBUG - 2022-09-02 11:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:12:08 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:42:09 --> Total execution time: 0.1210
DEBUG - 2022-09-02 11:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:42:11 --> Total execution time: 0.0975
DEBUG - 2022-09-02 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:42:20 --> Total execution time: 0.1321
DEBUG - 2022-09-02 11:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:42:30 --> Total execution time: 0.1982
DEBUG - 2022-09-02 11:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:43:21 --> Total execution time: 0.0597
DEBUG - 2022-09-02 11:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:43:32 --> Total execution time: 0.0985
DEBUG - 2022-09-02 11:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:43:37 --> Total execution time: 0.1363
DEBUG - 2022-09-02 11:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:48:54 --> Total execution time: 0.3632
DEBUG - 2022-09-02 11:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:50:12 --> Total execution time: 0.1008
DEBUG - 2022-09-02 11:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:20:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:50:26 --> Total execution time: 0.1011
DEBUG - 2022-09-02 11:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:50:32 --> Total execution time: 0.0952
DEBUG - 2022-09-02 11:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:50:37 --> Total execution time: 0.1052
DEBUG - 2022-09-02 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:51:19 --> Total execution time: 0.1245
DEBUG - 2022-09-02 11:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:22:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:52:25 --> Total execution time: 0.0617
DEBUG - 2022-09-02 11:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:22:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:52:35 --> Total execution time: 0.0629
DEBUG - 2022-09-02 11:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:22:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:52:36 --> Total execution time: 0.0628
DEBUG - 2022-09-02 11:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:52:40 --> Total execution time: 0.0605
DEBUG - 2022-09-02 11:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:53:06 --> Total execution time: 0.1165
DEBUG - 2022-09-02 11:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:53:38 --> Total execution time: 0.1258
DEBUG - 2022-09-02 11:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:25:57 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:55:57 --> Total execution time: 0.1312
DEBUG - 2022-09-02 11:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:56:03 --> Total execution time: 0.0597
DEBUG - 2022-09-02 11:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:56:50 --> Total execution time: 0.1005
DEBUG - 2022-09-02 11:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:03 --> Total execution time: 0.1284
DEBUG - 2022-09-02 11:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:15 --> Total execution time: 0.0951
DEBUG - 2022-09-02 11:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:31 --> Total execution time: 0.1038
DEBUG - 2022-09-02 11:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 11:27:35 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-02 11:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:36 --> Total execution time: 0.1197
DEBUG - 2022-09-02 11:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:45 --> Total execution time: 0.1058
DEBUG - 2022-09-02 11:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:58:18 --> Total execution time: 0.1218
DEBUG - 2022-09-02 11:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:29:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:38 --> Total execution time: 0.0701
DEBUG - 2022-09-02 11:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:42 --> Total execution time: 0.0825
DEBUG - 2022-09-02 11:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:00:05 --> Total execution time: 0.1259
DEBUG - 2022-09-02 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:00:29 --> Total execution time: 0.1032
DEBUG - 2022-09-02 11:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:31:12 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:01:12 --> Total execution time: 0.0674
DEBUG - 2022-09-02 11:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:02:33 --> Total execution time: 0.0597
DEBUG - 2022-09-02 11:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:02:37 --> Total execution time: 0.0640
DEBUG - 2022-09-02 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:16 --> Total execution time: 0.0953
DEBUG - 2022-09-02 11:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:27 --> Total execution time: 0.0986
DEBUG - 2022-09-02 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:30 --> Total execution time: 0.0645
DEBUG - 2022-09-02 11:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:33 --> Total execution time: 0.1006
DEBUG - 2022-09-02 11:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:40 --> Total execution time: 0.1053
DEBUG - 2022-09-02 11:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:44 --> Total execution time: 0.1161
DEBUG - 2022-09-02 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:16 --> Total execution time: 0.0955
DEBUG - 2022-09-02 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:43:30 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:13:30 --> Total execution time: 0.3057
DEBUG - 2022-09-02 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:14:32 --> Total execution time: 0.1185
DEBUG - 2022-09-02 11:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:16:22 --> Total execution time: 0.0696
DEBUG - 2022-09-02 11:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:16:44 --> Total execution time: 0.1202
DEBUG - 2022-09-02 11:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:16:50 --> Total execution time: 0.1268
DEBUG - 2022-09-02 11:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:10 --> Total execution time: 0.0975
DEBUG - 2022-09-02 11:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:16 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:16 --> Total execution time: 0.0660
DEBUG - 2022-09-02 11:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:17 --> Total execution time: 0.0564
DEBUG - 2022-09-02 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:28 --> Total execution time: 0.0868
DEBUG - 2022-09-02 11:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:35 --> Total execution time: 0.0925
DEBUG - 2022-09-02 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:36 --> Total execution time: 0.0860
DEBUG - 2022-09-02 11:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:43 --> Total execution time: 0.0899
DEBUG - 2022-09-02 11:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:45 --> Total execution time: 0.1053
DEBUG - 2022-09-02 11:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:47:45 --> Total execution time: 0.1099
DEBUG - 2022-09-02 11:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:46 --> Total execution time: 0.1022
DEBUG - 2022-09-02 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:51 --> Total execution time: 0.0858
DEBUG - 2022-09-02 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:00 --> Total execution time: 0.0935
DEBUG - 2022-09-02 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:05 --> Total execution time: 0.0930
DEBUG - 2022-09-02 11:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:06 --> Total execution time: 0.1145
DEBUG - 2022-09-02 11:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:08 --> Total execution time: 0.0918
DEBUG - 2022-09-02 11:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:10 --> Total execution time: 0.2512
DEBUG - 2022-09-02 11:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:13 --> Total execution time: 0.1064
DEBUG - 2022-09-02 11:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:19 --> Total execution time: 0.1019
DEBUG - 2022-09-02 11:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:41 --> Total execution time: 0.0914
DEBUG - 2022-09-02 11:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:43 --> Total execution time: 0.1048
DEBUG - 2022-09-02 11:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:36 --> Total execution time: 0.0975
DEBUG - 2022-09-02 11:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:49:37 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:37 --> Total execution time: 0.2498
DEBUG - 2022-09-02 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:49:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:38 --> Total execution time: 0.0641
DEBUG - 2022-09-02 11:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:43 --> Total execution time: 0.1044
DEBUG - 2022-09-02 11:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:55 --> Total execution time: 0.0588
DEBUG - 2022-09-02 11:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:20:05 --> Total execution time: 0.0975
DEBUG - 2022-09-02 11:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:20:14 --> Total execution time: 0.1293
DEBUG - 2022-09-02 11:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:20:28 --> Total execution time: 0.0989
DEBUG - 2022-09-02 11:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:30 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:20:30 --> Total execution time: 0.1081
DEBUG - 2022-09-02 11:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:20:31 --> Total execution time: 0.0931
DEBUG - 2022-09-02 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:20:33 --> Total execution time: 0.0857
DEBUG - 2022-09-02 11:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:20:50 --> Total execution time: 2.4455
DEBUG - 2022-09-02 11:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:21:41 --> Total execution time: 0.1039
DEBUG - 2022-09-02 11:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:21:52 --> Total execution time: 0.1287
DEBUG - 2022-09-02 11:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:21:55 --> Total execution time: 0.2490
DEBUG - 2022-09-02 11:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:21:57 --> Total execution time: 0.1016
DEBUG - 2022-09-02 11:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:21:58 --> Total execution time: 0.1004
DEBUG - 2022-09-02 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 11:52:10 --> 404 Page Not Found: Login/index
DEBUG - 2022-09-02 11:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 11:52:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 11:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:19 --> Total execution time: 0.1021
DEBUG - 2022-09-02 11:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:23 --> Total execution time: 0.1180
DEBUG - 2022-09-02 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:27 --> Total execution time: 0.2431
DEBUG - 2022-09-02 11:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:31 --> Total execution time: 0.1358
DEBUG - 2022-09-02 11:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:36 --> Total execution time: 0.1570
DEBUG - 2022-09-02 11:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:36 --> Total execution time: 0.0927
DEBUG - 2022-09-02 11:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:42 --> Total execution time: 0.1214
DEBUG - 2022-09-02 11:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:43 --> Total execution time: 0.0990
DEBUG - 2022-09-02 11:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-02 11:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:22:59 --> Total execution time: 0.1027
DEBUG - 2022-09-02 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:23:20 --> Total execution time: 0.1070
DEBUG - 2022-09-02 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:23:26 --> Total execution time: 0.1194
DEBUG - 2022-09-02 11:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:24:04 --> Total execution time: 0.1159
DEBUG - 2022-09-02 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:55:03 --> Total execution time: 0.1065
DEBUG - 2022-09-02 11:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:55:06 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:25:06 --> Total execution time: 0.0931
DEBUG - 2022-09-02 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:55:08 --> Total execution time: 0.1456
DEBUG - 2022-09-02 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:55:17 --> Total execution time: 0.1071
DEBUG - 2022-09-02 11:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:26:05 --> Total execution time: 0.1077
DEBUG - 2022-09-02 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:26:27 --> Total execution time: 0.0973
DEBUG - 2022-09-02 11:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:26:31 --> Total execution time: 0.0922
DEBUG - 2022-09-02 11:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:26:38 --> Total execution time: 0.1358
DEBUG - 2022-09-02 11:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:27:00 --> Total execution time: 0.1269
DEBUG - 2022-09-02 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:27:10 --> Total execution time: 0.1015
DEBUG - 2022-09-02 11:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:27:41 --> Total execution time: 0.2494
DEBUG - 2022-09-02 11:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:28:00 --> Total execution time: 0.1058
DEBUG - 2022-09-02 11:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:28:06 --> Total execution time: 0.0960
DEBUG - 2022-09-02 11:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:28:15 --> Total execution time: 0.2590
DEBUG - 2022-09-02 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:28:23 --> Total execution time: 0.0943
DEBUG - 2022-09-02 11:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:28:34 --> Total execution time: 0.1492
DEBUG - 2022-09-02 11:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:28:39 --> Total execution time: 0.0953
DEBUG - 2022-09-02 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:28:53 --> Total execution time: 0.0996
DEBUG - 2022-09-02 11:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:29:05 --> Total execution time: 0.1038
DEBUG - 2022-09-02 11:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:29:10 --> Total execution time: 0.0980
DEBUG - 2022-09-02 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:59:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:29:47 --> Total execution time: 0.0622
DEBUG - 2022-09-02 11:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 11:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 11:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:29:48 --> Total execution time: 0.0980
DEBUG - 2022-09-02 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:30:03 --> Total execution time: 0.1065
DEBUG - 2022-09-02 12:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:30:30 --> Total execution time: 0.0959
DEBUG - 2022-09-02 12:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:30:41 --> Total execution time: 0.0979
DEBUG - 2022-09-02 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:31:13 --> Total execution time: 0.0927
DEBUG - 2022-09-02 12:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:01:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:31:47 --> Total execution time: 0.0605
DEBUG - 2022-09-02 12:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:32:57 --> Total execution time: 0.0931
DEBUG - 2022-09-02 12:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:34:33 --> Total execution time: 0.0984
DEBUG - 2022-09-02 12:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:04:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:34:49 --> Total execution time: 0.0817
DEBUG - 2022-09-02 12:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:34:54 --> Total execution time: 0.0651
DEBUG - 2022-09-02 12:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:35:17 --> Total execution time: 0.1020
DEBUG - 2022-09-02 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:35:27 --> Total execution time: 0.1108
DEBUG - 2022-09-02 12:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:36:15 --> Total execution time: 0.1196
DEBUG - 2022-09-02 12:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:36:16 --> Total execution time: 0.1340
DEBUG - 2022-09-02 12:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:36:23 --> Total execution time: 0.1322
DEBUG - 2022-09-02 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:36:23 --> Total execution time: 0.3081
DEBUG - 2022-09-02 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:37:14 --> Total execution time: 0.1195
DEBUG - 2022-09-02 12:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:37:32 --> Total execution time: 0.1235
DEBUG - 2022-09-02 12:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:01 --> Total execution time: 0.2820
DEBUG - 2022-09-02 12:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:01 --> Total execution time: 0.1248
DEBUG - 2022-09-02 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:08:08 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:08 --> Total execution time: 0.1075
DEBUG - 2022-09-02 12:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:08:32 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:32 --> Total execution time: 0.1394
DEBUG - 2022-09-02 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:39:20 --> Total execution time: 0.1045
DEBUG - 2022-09-02 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:39:38 --> Total execution time: 0.1150
DEBUG - 2022-09-02 12:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:09:39 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:39:39 --> Total execution time: 0.1045
DEBUG - 2022-09-02 12:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:10:11 --> Total execution time: 0.0968
DEBUG - 2022-09-02 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:10:23 --> Total execution time: 0.0982
DEBUG - 2022-09-02 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:10:23 --> Total execution time: 0.1037
DEBUG - 2022-09-02 12:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:40:24 --> Total execution time: 0.0939
DEBUG - 2022-09-02 12:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:10:41 --> Total execution time: 0.1134
DEBUG - 2022-09-02 12:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:12:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 12:12:26 --> 404 Page Not Found: Lessons/why-personal-brading-is-so-important
DEBUG - 2022-09-02 12:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:15:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:45:00 --> Total execution time: 0.1588
DEBUG - 2022-09-02 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:16:00 --> Total execution time: 0.1202
DEBUG - 2022-09-02 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:16:00 --> Total execution time: 0.1017
DEBUG - 2022-09-02 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:16:00 --> Total execution time: 0.0986
DEBUG - 2022-09-02 12:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:46:29 --> Total execution time: 0.1121
DEBUG - 2022-09-02 12:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:46:58 --> Total execution time: 0.0954
DEBUG - 2022-09-02 12:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:47:12 --> Total execution time: 0.0988
DEBUG - 2022-09-02 12:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:47:21 --> Total execution time: 0.0953
DEBUG - 2022-09-02 12:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:47:41 --> Total execution time: 0.2692
DEBUG - 2022-09-02 12:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:47:52 --> Total execution time: 0.0990
DEBUG - 2022-09-02 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:20:44 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:50:44 --> Total execution time: 0.1500
DEBUG - 2022-09-02 12:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:54:40 --> Total execution time: 0.1679
DEBUG - 2022-09-02 12:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:55:52 --> Total execution time: 0.0632
DEBUG - 2022-09-02 12:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:59:51 --> Total execution time: 0.1049
DEBUG - 2022-09-02 12:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:00:27 --> Total execution time: 0.0975
DEBUG - 2022-09-02 12:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:02:38 --> Total execution time: 0.1457
DEBUG - 2022-09-02 12:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:03:15 --> Total execution time: 0.1010
DEBUG - 2022-09-02 12:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:03:25 --> Total execution time: 0.1234
DEBUG - 2022-09-02 12:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:34:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:04:17 --> Total execution time: 0.0651
DEBUG - 2022-09-02 12:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:34:53 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:04:53 --> Total execution time: 0.0627
DEBUG - 2022-09-02 12:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:35:19 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:05:19 --> Total execution time: 0.0819
DEBUG - 2022-09-02 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:05:37 --> Total execution time: 0.0670
DEBUG - 2022-09-02 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:05:48 --> Total execution time: 0.0982
DEBUG - 2022-09-02 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:06:03 --> Total execution time: 0.1473
DEBUG - 2022-09-02 12:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:07:44 --> Total execution time: 0.3120
DEBUG - 2022-09-02 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:08:55 --> Total execution time: 0.1198
DEBUG - 2022-09-02 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:09:00 --> Total execution time: 0.1668
DEBUG - 2022-09-02 12:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:39:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:09:17 --> Total execution time: 0.0839
DEBUG - 2022-09-02 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:09:39 --> Total execution time: 0.2094
DEBUG - 2022-09-02 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:10:21 --> Total execution time: 0.1730
DEBUG - 2022-09-02 12:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:12:53 --> Total execution time: 0.1081
DEBUG - 2022-09-02 12:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:14:44 --> Total execution time: 0.0978
DEBUG - 2022-09-02 12:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:14:51 --> Total execution time: 0.1129
DEBUG - 2022-09-02 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:14:55 --> Total execution time: 0.1179
DEBUG - 2022-09-02 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:14:59 --> Total execution time: 0.1148
DEBUG - 2022-09-02 12:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:15:24 --> Total execution time: 0.0977
DEBUG - 2022-09-02 12:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 12:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:52:28 --> No URI present. Default controller set.
DEBUG - 2022-09-02 12:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:22:28 --> Total execution time: 0.2630
DEBUG - 2022-09-02 12:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:25:55 --> Total execution time: 0.1164
DEBUG - 2022-09-02 12:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 12:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 12:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:28:41 --> Total execution time: 0.2997
DEBUG - 2022-09-02 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:30:03 --> Total execution time: 0.0761
DEBUG - 2022-09-02 13:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:00:40 --> No URI present. Default controller set.
DEBUG - 2022-09-02 13:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:30:40 --> Total execution time: 0.2552
DEBUG - 2022-09-02 13:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:05:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 13:05:28 --> 404 Page Not Found: Affiliate-login/index
DEBUG - 2022-09-02 13:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:42:55 --> Total execution time: 0.1379
DEBUG - 2022-09-02 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:19:40 --> No URI present. Default controller set.
DEBUG - 2022-09-02 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:49:40 --> Total execution time: 0.1379
DEBUG - 2022-09-02 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:49:56 --> Total execution time: 0.2789
DEBUG - 2022-09-02 13:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:08 --> Total execution time: 0.0642
DEBUG - 2022-09-02 13:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:10 --> Total execution time: 0.1267
DEBUG - 2022-09-02 13:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:11 --> Total execution time: 0.0952
DEBUG - 2022-09-02 13:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:50:22 --> Total execution time: 0.0965
DEBUG - 2022-09-02 13:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:50:33 --> Total execution time: 0.1602
DEBUG - 2022-09-02 13:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:50:55 --> Total execution time: 0.1096
DEBUG - 2022-09-02 13:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:50:56 --> Total execution time: 0.1083
DEBUG - 2022-09-02 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:51:03 --> Total execution time: 0.1146
DEBUG - 2022-09-02 13:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:21:09 --> No URI present. Default controller set.
DEBUG - 2022-09-02 13:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:51:09 --> Total execution time: 0.0630
DEBUG - 2022-09-02 13:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:51:38 --> Total execution time: 0.0993
DEBUG - 2022-09-02 13:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:51:50 --> Total execution time: 0.1066
DEBUG - 2022-09-02 13:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:52:09 --> Total execution time: 0.0653
DEBUG - 2022-09-02 13:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:23:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 13:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:53:43 --> Total execution time: 0.0740
DEBUG - 2022-09-02 13:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:27:58 --> No URI present. Default controller set.
DEBUG - 2022-09-02 13:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:57:58 --> Total execution time: 0.1349
DEBUG - 2022-09-02 13:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:32:19 --> No URI present. Default controller set.
DEBUG - 2022-09-02 13:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 13:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 13:50:28 --> No URI present. Default controller set.
DEBUG - 2022-09-02 13:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 13:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:12:58 --> Total execution time: 0.0983
DEBUG - 2022-09-02 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:13:03 --> Total execution time: 0.0636
DEBUG - 2022-09-02 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:13:04 --> Total execution time: 0.0599
DEBUG - 2022-09-02 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:13:04 --> Total execution time: 0.0888
DEBUG - 2022-09-02 14:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:23:56 --> No URI present. Default controller set.
DEBUG - 2022-09-02 14:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:45:44 --> No URI present. Default controller set.
DEBUG - 2022-09-02 14:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:11 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-09-02 14:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:11 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-09-02 14:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:22 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:24 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-09-02 14:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:24 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-09-02 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:24 --> 404 Page Not Found: Well-known/gpc.json
DEBUG - 2022-09-02 14:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:24 --> 404 Page Not Found: Well-known/resource-that-should-not-exist-whose-status-code-should-not-be-200
DEBUG - 2022-09-02 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:24 --> 404 Page Not Found: Well-known/security.txt
DEBUG - 2022-09-02 14:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:46:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 14:46:25 --> 404 Page Not Found: Well-known/change-password
DEBUG - 2022-09-02 14:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:47:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 14:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 14:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 14:48:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 14:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 14:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:15:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 15:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:24:58 --> No URI present. Default controller set.
DEBUG - 2022-09-02 15:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:39:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 15:39:53 --> 404 Page Not Found: Wp-commentinphp/index
DEBUG - 2022-09-02 15:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:40:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 15:40:20 --> 404 Page Not Found: Wp-commentinphp/index
DEBUG - 2022-09-02 15:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 15:49:46 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 15:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:49:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 15:49:50 --> 404 Page Not Found: Why-join-us/esalestrix.in
DEBUG - 2022-09-02 15:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:57:00 --> Total execution time: 0.1387
DEBUG - 2022-09-02 15:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 15:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 15:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:57:13 --> Total execution time: 0.1244
DEBUG - 2022-09-02 15:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 15:57:13 --> Total execution time: 0.2228
DEBUG - 2022-09-02 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 16:02:27 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-02 16:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:02:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 16:02:30 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 16:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:02:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 16:02:31 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-02 16:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:05:12 --> No URI present. Default controller set.
DEBUG - 2022-09-02 16:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 16:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:14:30 --> No URI present. Default controller set.
DEBUG - 2022-09-02 16:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 16:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:20:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 16:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 16:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:20:48 --> No URI present. Default controller set.
DEBUG - 2022-09-02 16:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 16:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 16:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 16:30:34 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-09-02 16:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 16:54:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 16:54:33 --> 404 Page Not Found: Home-3/esalestrix.in
DEBUG - 2022-09-02 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 17:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 17:10:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 17:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 17:10:48 --> No URI present. Default controller set.
DEBUG - 2022-09-02 17:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 17:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 17:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 17:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 17:35:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 17:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 17:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 17:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 17:38:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 17:38:55 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 17:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 17:38:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 17:38:58 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-02 17:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 17:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 17:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:00:53 --> No URI present. Default controller set.
DEBUG - 2022-09-02 18:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:32:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 18:32:31 --> 404 Page Not Found: Learning-friendship-and-fun-for-everyone/index
DEBUG - 2022-09-02 18:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:32:32 --> No URI present. Default controller set.
DEBUG - 2022-09-02 18:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:39:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 18:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:40:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 18:40:10 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 18:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 18:40:17 --> 404 Page Not Found: Refund/index
DEBUG - 2022-09-02 18:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:33 --> No URI present. Default controller set.
DEBUG - 2022-09-02 18:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:42 --> No URI present. Default controller set.
DEBUG - 2022-09-02 18:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 18:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 18:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 18:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:06:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 19:06:14 --> 404 Page Not Found: Importance-of-research-seminar/index
DEBUG - 2022-09-02 19:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:13:45 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:15:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:19:18 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:20:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 19:20:25 --> 404 Page Not Found: Importance-of-research-seminar/index
DEBUG - 2022-09-02 19:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:23:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:25:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:29:29 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:32:19 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:34:37 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:37:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 19:37:13 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 19:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:31 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:54:51 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:55:26 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:58:34 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:58:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:58:48 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:58:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 19:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 19:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 19:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 19:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:00:15 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:24 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:25 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:04:48 --> Total execution time: 0.0874
DEBUG - 2022-09-02 20:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:05:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:05:28 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:06:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:06:50 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:09:27 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:14:52 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:14:54 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:16:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:17:29 --> Total execution time: 0.0961
DEBUG - 2022-09-02 20:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:17:33 --> Total execution time: 0.1072
DEBUG - 2022-09-02 20:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:17:34 --> Total execution time: 0.1044
DEBUG - 2022-09-02 20:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:19:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 20:19:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 20:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:26:10 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:27:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 20:27:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 20:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 20:27:07 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 20:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 20:27:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-02 20:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:34:34 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:51:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:57:04 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 20:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 20:59:41 --> No URI present. Default controller set.
DEBUG - 2022-09-02 20:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 20:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:08:17 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:47 --> Total execution time: 0.1052
DEBUG - 2022-09-02 21:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:50 --> Total execution time: 0.0922
DEBUG - 2022-09-02 21:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:12:51 --> Total execution time: 0.1270
DEBUG - 2022-09-02 21:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:26:55 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:32:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:32:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:32:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:38:07 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:39:35 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:42:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:46:04 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:56:43 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:57:47 --> No URI present. Default controller set.
DEBUG - 2022-09-02 21:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 21:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 21:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 21:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:07:38 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:08:01 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:13:10 --> Total execution time: 0.1037
DEBUG - 2022-09-02 22:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:13:18 --> Total execution time: 0.1406
DEBUG - 2022-09-02 22:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:29:36 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:38:00 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:38:18 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:41:05 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:41:06 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:49:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 22:49:55 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-02 22:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 22:50:08 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-02 22:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 22:50:11 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-09-02 22:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:52:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:53:00 --> Total execution time: 0.1054
DEBUG - 2022-09-02 22:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:53:15 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:53:28 --> Total execution time: 0.1152
DEBUG - 2022-09-02 22:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:53:33 --> Total execution time: 0.1009
DEBUG - 2022-09-02 22:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:53:33 --> Total execution time: 0.0921
DEBUG - 2022-09-02 22:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 22:54:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:55:15 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:55:28 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:55:49 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:31 --> Total execution time: 0.1015
DEBUG - 2022-09-02 22:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:33 --> Total execution time: 0.0972
DEBUG - 2022-09-02 22:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:56:34 --> Total execution time: 0.0957
DEBUG - 2022-09-02 22:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:58:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 22:58:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 22:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:59:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 22:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 22:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 22:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 22:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:12:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:14:51 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:22:23 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:24:37 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:46 --> Total execution time: 0.1103
DEBUG - 2022-09-02 23:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:48 --> Total execution time: 0.0884
DEBUG - 2022-09-02 23:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:24:49 --> Total execution time: 0.1005
DEBUG - 2022-09-02 23:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 23:26:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 23:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:27:21 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:34:14 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:40:08 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:48 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:44:59 --> Total execution time: 0.0979
DEBUG - 2022-09-02 23:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:45:01 --> Total execution time: 0.1037
DEBUG - 2022-09-02 23:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:45:01 --> Total execution time: 0.2191
DEBUG - 2022-09-02 23:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-02 23:46:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-02 23:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:20 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:51:18 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:53:58 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:58:46 --> No URI present. Default controller set.
DEBUG - 2022-09-02 23:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-02 23:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-02 23:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-02 23:59:33 --> Encryption: Auto-configured driver 'openssl'.
