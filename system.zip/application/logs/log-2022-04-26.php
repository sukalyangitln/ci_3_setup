<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-26 00:26:09 --> Total execution time: 0.1957
DEBUG - 2022-04-26 00:26:23 --> Total execution time: 0.2273
DEBUG - 2022-04-26 00:31:53 --> Total execution time: 0.1227
DEBUG - 2022-04-26 00:32:48 --> Total execution time: 0.0918
DEBUG - 2022-04-26 00:35:10 --> Total execution time: 0.0922
DEBUG - 2022-04-26 00:36:05 --> Total execution time: 0.0990
DEBUG - 2022-04-26 00:36:41 --> Total execution time: 0.1360
DEBUG - 2022-04-26 00:37:32 --> Total execution time: 0.1223
DEBUG - 2022-04-26 00:37:45 --> Total execution time: 0.1403
DEBUG - 2022-04-26 00:38:31 --> Total execution time: 0.0997
DEBUG - 2022-04-26 00:38:49 --> Total execution time: 0.1418
DEBUG - 2022-04-26 00:39:43 --> Total execution time: 0.1120
DEBUG - 2022-04-26 00:41:34 --> Total execution time: 0.0960
DEBUG - 2022-04-26 00:41:53 --> Total execution time: 0.1310
DEBUG - 2022-04-26 00:43:09 --> Total execution time: 0.1260
DEBUG - 2022-04-26 00:44:05 --> Total execution time: 0.1003
DEBUG - 2022-04-26 00:44:07 --> Total execution time: 0.0977
DEBUG - 2022-04-26 00:44:11 --> Total execution time: 0.0900
DEBUG - 2022-04-26 00:44:15 --> Total execution time: 0.1051
DEBUG - 2022-04-26 00:44:28 --> Total execution time: 0.0895
DEBUG - 2022-04-26 00:46:44 --> Total execution time: 0.0835
DEBUG - 2022-04-26 00:47:19 --> Total execution time: 0.1021
DEBUG - 2022-04-26 00:47:21 --> Total execution time: 0.0941
DEBUG - 2022-04-26 00:47:40 --> Total execution time: 0.1238
DEBUG - 2022-04-26 00:47:41 --> Total execution time: 0.0918
DEBUG - 2022-04-26 00:47:57 --> Total execution time: 0.1076
DEBUG - 2022-04-26 00:47:58 --> Total execution time: 0.0952
DEBUG - 2022-04-26 00:48:47 --> Total execution time: 0.1104
DEBUG - 2022-04-26 00:50:31 --> Total execution time: 0.1107
DEBUG - 2022-04-26 00:50:44 --> Total execution time: 0.0880
DEBUG - 2022-04-26 00:52:57 --> Total execution time: 0.0931
DEBUG - 2022-04-26 00:53:30 --> Total execution time: 0.1104
DEBUG - 2022-04-26 00:54:23 --> Total execution time: 0.0944
DEBUG - 2022-04-26 00:55:01 --> Total execution time: 0.1565
DEBUG - 2022-04-26 00:55:15 --> Total execution time: 0.0915
DEBUG - 2022-04-26 00:55:49 --> Total execution time: 0.1069
DEBUG - 2022-04-26 00:56:18 --> Total execution time: 0.1097
DEBUG - 2022-04-26 00:57:20 --> Total execution time: 0.0939
DEBUG - 2022-04-26 00:57:37 --> Total execution time: 0.1082
DEBUG - 2022-04-26 00:58:25 --> Total execution time: 0.0946
DEBUG - 2022-04-26 01:00:02 --> Total execution time: 0.1318
DEBUG - 2022-04-26 01:01:13 --> Total execution time: 0.0985
DEBUG - 2022-04-26 01:02:39 --> Total execution time: 0.1042
DEBUG - 2022-04-26 01:02:49 --> Total execution time: 0.1023
DEBUG - 2022-04-26 01:03:57 --> Total execution time: 0.1194
DEBUG - 2022-04-26 01:05:01 --> Total execution time: 0.1164
DEBUG - 2022-04-26 01:05:20 --> Total execution time: 0.1271
DEBUG - 2022-04-26 01:05:55 --> Total execution time: 0.1233
DEBUG - 2022-04-26 01:06:10 --> Total execution time: 0.1187
DEBUG - 2022-04-26 01:06:49 --> Total execution time: 0.1294
DEBUG - 2022-04-26 01:07:21 --> Total execution time: 0.2363
DEBUG - 2022-04-26 01:08:08 --> Total execution time: 0.1271
DEBUG - 2022-04-26 01:08:14 --> Total execution time: 0.1598
DEBUG - 2022-04-26 01:08:15 --> Total execution time: 0.0873
ERROR - 2022-04-26 01:10:22 --> Severity: error --> Exception: Call to undefined function get_userdata() C:\xampp\htdocs\leadsark\application\views\User\inc\header.php 2
ERROR - 2022-04-26 01:11:12 --> Query error: Table 'leadsark.users_login' doesn't exist - Invalid query: SELECT *
FROM `users_login`
WHERE `ul_id` = '8'
DEBUG - 2022-04-26 01:11:52 --> Total execution time: 0.0972
DEBUG - 2022-04-26 02:03:09 --> Total execution time: 1.3654
DEBUG - 2022-04-26 02:03:17 --> Total execution time: 0.1401
DEBUG - 2022-04-26 02:07:00 --> Total execution time: 0.1983
DEBUG - 2022-04-26 02:31:30 --> Total execution time: 0.1513
DEBUG - 2022-04-26 02:31:37 --> Total execution time: 0.0988
DEBUG - 2022-04-26 02:33:23 --> Total execution time: 0.1169
DEBUG - 2022-04-26 02:33:40 --> Total execution time: 0.0969
DEBUG - 2022-04-26 02:33:44 --> Total execution time: 0.1879
DEBUG - 2022-04-26 02:35:03 --> Total execution time: 0.1237
DEBUG - 2022-04-26 02:36:46 --> Total execution time: 0.1356
DEBUG - 2022-04-26 02:36:59 --> Total execution time: 0.1113
DEBUG - 2022-04-26 02:37:18 --> Total execution time: 0.1301
DEBUG - 2022-04-26 02:37:53 --> Total execution time: 0.1189
DEBUG - 2022-04-26 02:43:03 --> Total execution time: 0.1276
DEBUG - 2022-04-26 02:43:49 --> Total execution time: 0.1254
DEBUG - 2022-04-26 02:44:07 --> Total execution time: 0.1289
DEBUG - 2022-04-26 02:44:28 --> Total execution time: 0.1170
DEBUG - 2022-04-26 02:45:20 --> Total execution time: 0.0907
DEBUG - 2022-04-26 02:45:35 --> Total execution time: 0.1002
DEBUG - 2022-04-26 02:45:44 --> Total execution time: 0.1250
DEBUG - 2022-04-26 02:46:32 --> Total execution time: 0.2143
DEBUG - 2022-04-26 02:46:43 --> Total execution time: 0.1198
DEBUG - 2022-04-26 02:46:59 --> Total execution time: 0.1264
DEBUG - 2022-04-26 02:47:16 --> Total execution time: 0.1255
DEBUG - 2022-04-26 02:47:26 --> Total execution time: 0.1021
DEBUG - 2022-04-26 02:48:15 --> Total execution time: 0.1242
DEBUG - 2022-04-26 02:48:22 --> Total execution time: 0.1106
DEBUG - 2022-04-26 02:48:59 --> Total execution time: 0.0999
DEBUG - 2022-04-26 02:49:00 --> Total execution time: 0.0942
DEBUG - 2022-04-26 02:49:02 --> Total execution time: 0.1051
DEBUG - 2022-04-26 02:49:33 --> Total execution time: 0.1006
DEBUG - 2022-04-26 02:49:53 --> Total execution time: 0.1377
DEBUG - 2022-04-26 02:50:22 --> Total execution time: 0.1330
DEBUG - 2022-04-26 02:50:39 --> Total execution time: 0.2410
DEBUG - 2022-04-26 02:51:22 --> Total execution time: 0.1092
DEBUG - 2022-04-26 02:51:55 --> Total execution time: 0.1200
DEBUG - 2022-04-26 02:53:15 --> Total execution time: 0.1181
DEBUG - 2022-04-26 02:53:26 --> Total execution time: 0.0968
DEBUG - 2022-04-26 02:55:52 --> Total execution time: 0.1163
DEBUG - 2022-04-26 02:56:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 02:56:01 --> Total execution time: 0.1057
DEBUG - 2022-04-26 02:56:04 --> Total execution time: 0.1008
DEBUG - 2022-04-26 03:01:35 --> Total execution time: 0.2006
DEBUG - 2022-04-26 03:01:47 --> Total execution time: 0.1187
DEBUG - 2022-04-26 03:01:54 --> Total execution time: 0.1332
DEBUG - 2022-04-26 03:02:09 --> Total execution time: 0.1827
DEBUG - 2022-04-26 03:03:01 --> Total execution time: 0.1163
DEBUG - 2022-04-26 03:03:13 --> Total execution time: 0.1665
DEBUG - 2022-04-26 03:03:45 --> Total execution time: 0.1289
DEBUG - 2022-04-26 03:04:03 --> Total execution time: 0.1263
DEBUG - 2022-04-26 03:04:40 --> Total execution time: 0.0948
DEBUG - 2022-04-26 03:04:59 --> Total execution time: 0.1154
DEBUG - 2022-04-26 03:06:14 --> Total execution time: 0.1089
DEBUG - 2022-04-26 03:06:38 --> Total execution time: 0.1682
DEBUG - 2022-04-26 03:07:35 --> Total execution time: 0.1200
DEBUG - 2022-04-26 03:08:53 --> Total execution time: 0.1206
DEBUG - 2022-04-26 03:11:14 --> Total execution time: 0.1339
DEBUG - 2022-04-26 03:11:26 --> Total execution time: 0.1181
DEBUG - 2022-04-26 03:11:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 03:11:54 --> Total execution time: 0.1510
DEBUG - 2022-04-26 03:11:57 --> Total execution time: 0.0979
DEBUG - 2022-04-26 03:12:53 --> Total execution time: 0.1171
DEBUG - 2022-04-26 03:15:52 --> Total execution time: 0.1717
DEBUG - 2022-04-26 03:16:11 --> Total execution time: 0.1186
DEBUG - 2022-04-26 03:16:14 --> Total execution time: 0.2233
DEBUG - 2022-04-26 03:16:26 --> Total execution time: 0.1403
DEBUG - 2022-04-26 03:16:57 --> Total execution time: 0.1965
DEBUG - 2022-04-26 03:16:59 --> Total execution time: 0.1955
DEBUG - 2022-04-26 03:18:24 --> Total execution time: 0.1289
DEBUG - 2022-04-26 03:18:49 --> Total execution time: 0.1453
DEBUG - 2022-04-26 03:19:44 --> Total execution time: 0.1925
DEBUG - 2022-04-26 03:19:57 --> Total execution time: 0.2266
DEBUG - 2022-04-26 03:20:10 --> Total execution time: 0.1377
DEBUG - 2022-04-26 03:22:30 --> Total execution time: 0.1263
DEBUG - 2022-04-26 03:23:41 --> Total execution time: 0.1233
DEBUG - 2022-04-26 03:26:10 --> Total execution time: 0.1169
DEBUG - 2022-04-26 03:26:29 --> Total execution time: 0.1894
DEBUG - 2022-04-26 03:26:32 --> Total execution time: 0.0804
DEBUG - 2022-04-26 03:29:22 --> Total execution time: 0.1343
DEBUG - 2022-04-26 03:29:28 --> Total execution time: 0.0807
DEBUG - 2022-04-26 00:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:30:11 --> Total execution time: 0.2653
DEBUG - 2022-04-26 00:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:00:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:00:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:00:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:00:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:00:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:00:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:00:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:00:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:00:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 00:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 00:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:31:00 --> Total execution time: 0.1582
DEBUG - 2022-04-26 00:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:01:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:01:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:31:11 --> Total execution time: 0.1389
DEBUG - 2022-04-26 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:01:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:01:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:31:14 --> Total execution time: 0.0873
DEBUG - 2022-04-26 00:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:35:46 --> Total execution time: 0.2328
DEBUG - 2022-04-26 00:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:05:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:05:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:05:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:05:47 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:05:47 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:35:53 --> Total execution time: 0.0858
DEBUG - 2022-04-26 00:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:36:06 --> Total execution time: 0.1430
DEBUG - 2022-04-26 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:06:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:07 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:06:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:06:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:36:23 --> Total execution time: 0.1504
DEBUG - 2022-04-26 00:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:24 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:06:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:24 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:36:44 --> Total execution time: 0.1517
DEBUG - 2022-04-26 00:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:06:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:45 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:06:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:36:50 --> Total execution time: 0.0824
DEBUG - 2022-04-26 00:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:36:53 --> Total execution time: 0.1211
DEBUG - 2022-04-26 00:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:37:06 --> Total execution time: 0.1741
DEBUG - 2022-04-26 00:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:37:12 --> Total execution time: 0.0806
DEBUG - 2022-04-26 00:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:38:14 --> Total execution time: 0.1121
DEBUG - 2022-04-26 00:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:38:44 --> Total execution time: 0.1126
DEBUG - 2022-04-26 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:08:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:08:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:08:47 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:08:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:08:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:08:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:08:47 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:08:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:08:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:08:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:39:41 --> Total execution time: 0.1152
DEBUG - 2022-04-26 00:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:09:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:09:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:09:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:09:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:09:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:39:47 --> Total execution time: 0.0966
DEBUG - 2022-04-26 00:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:39:50 --> Total execution time: 0.1195
DEBUG - 2022-04-26 00:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:40:03 --> Total execution time: 0.1144
DEBUG - 2022-04-26 00:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:40:18 --> Total execution time: 0.1812
DEBUG - 2022-04-26 00:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:40:24 --> Total execution time: 0.0902
DEBUG - 2022-04-26 00:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:40:27 --> Total execution time: 0.0983
DEBUG - 2022-04-26 00:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:40:31 --> Total execution time: 0.1052
DEBUG - 2022-04-26 00:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:40:46 --> Total execution time: 0.1621
DEBUG - 2022-04-26 00:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:42:08 --> Total execution time: 0.1543
DEBUG - 2022-04-26 00:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:42:12 --> Total execution time: 0.0820
DEBUG - 2022-04-26 00:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:43:37 --> Total execution time: 0.1193
DEBUG - 2022-04-26 00:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:43:42 --> Total execution time: 0.0887
DEBUG - 2022-04-26 00:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:43:46 --> Total execution time: 0.1087
DEBUG - 2022-04-26 00:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:43:51 --> Total execution time: 0.0941
DEBUG - 2022-04-26 00:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:43:57 --> Total execution time: 0.1222
DEBUG - 2022-04-26 00:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:19:12 --> Total execution time: 0.2660
DEBUG - 2022-04-26 00:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:19:36 --> Total execution time: 0.1369
DEBUG - 2022-04-26 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:19:43 --> Total execution time: 0.0885
DEBUG - 2022-04-26 00:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:19:49 --> Total execution time: 0.1143
DEBUG - 2022-04-26 00:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:19:53 --> Total execution time: 0.1256
DEBUG - 2022-04-26 00:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:50:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:50:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:50:04 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:50:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:50:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:50:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:50:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 00:50:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:50:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:20:59 --> Total execution time: 0.1362
DEBUG - 2022-04-26 00:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:51:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:51:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:51:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:51:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:51:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:51:00 --> UTF-8 Support Enabled
ERROR - 2022-04-26 00:51:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:51:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:51:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:51:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 00:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:21:05 --> Total execution time: 0.1153
DEBUG - 2022-04-26 00:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:21:08 --> Total execution time: 0.1742
DEBUG - 2022-04-26 00:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:22:11 --> Total execution time: 0.1205
DEBUG - 2022-04-26 00:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:23:24 --> Total execution time: 0.2057
DEBUG - 2022-04-26 00:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:53:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:53:28 --> 404 Page Not Found: user/Edit-profile/index
DEBUG - 2022-04-26 00:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:23:38 --> Total execution time: 0.1414
DEBUG - 2022-04-26 00:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:23:46 --> Total execution time: 0.1275
DEBUG - 2022-04-26 00:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:53:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 00:53:48 --> 404 Page Not Found: User/Country_state_city/update_profile_basic_info
DEBUG - 2022-04-26 00:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 00:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 00:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:24:00 --> Total execution time: 0.1050
DEBUG - 2022-04-26 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:31:17 --> Total execution time: 0.1044
DEBUG - 2022-04-26 01:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:31:48 --> Total execution time: 0.1312
DEBUG - 2022-04-26 01:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:32:46 --> Total execution time: 0.1115
DEBUG - 2022-04-26 01:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:32:49 --> Total execution time: 0.1364
DEBUG - 2022-04-26 01:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:32:54 --> Total execution time: 0.1254
DEBUG - 2022-04-26 01:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:33:30 --> Total execution time: 0.1144
DEBUG - 2022-04-26 01:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:33:53 --> Total execution time: 0.0944
DEBUG - 2022-04-26 01:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:33:57 --> Total execution time: 0.0975
DEBUG - 2022-04-26 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:34:00 --> Total execution time: 0.1500
DEBUG - 2022-04-26 01:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:34:08 --> Total execution time: 0.1235
DEBUG - 2022-04-26 01:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:35:09 --> Total execution time: 0.1060
DEBUG - 2022-04-26 01:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:36:40 --> Total execution time: 0.1188
DEBUG - 2022-04-26 01:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:36:47 --> Total execution time: 0.1129
DEBUG - 2022-04-26 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:36:56 --> Total execution time: 0.1204
DEBUG - 2022-04-26 01:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:37:18 --> Total execution time: 0.1171
DEBUG - 2022-04-26 01:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:37:35 --> Total execution time: 0.1332
DEBUG - 2022-04-26 01:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:38:48 --> Total execution time: 0.1586
DEBUG - 2022-04-26 01:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:39:51 --> Total execution time: 0.1111
DEBUG - 2022-04-26 01:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:43:36 --> Total execution time: 0.1207
DEBUG - 2022-04-26 01:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:44:07 --> Total execution time: 0.1246
DEBUG - 2022-04-26 01:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:48:37 --> Total execution time: 0.1539
DEBUG - 2022-04-26 01:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:49:24 --> Total execution time: 0.1813
DEBUG - 2022-04-26 01:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:49:53 --> Total execution time: 0.2058
DEBUG - 2022-04-26 01:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:50:30 --> Total execution time: 0.1848
DEBUG - 2022-04-26 01:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:50:50 --> Total execution time: 0.1769
DEBUG - 2022-04-26 01:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:51:29 --> Total execution time: 0.1891
DEBUG - 2022-04-26 01:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:43 --> Total execution time: 0.1526
DEBUG - 2022-04-26 01:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:48 --> Total execution time: 0.1751
DEBUG - 2022-04-26 01:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:52 --> Total execution time: 0.1866
DEBUG - 2022-04-26 01:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:55 --> Total execution time: 0.1698
DEBUG - 2022-04-26 01:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:59 --> Total execution time: 0.1675
DEBUG - 2022-04-26 01:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:08 --> Total execution time: 0.1851
DEBUG - 2022-04-26 01:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:28 --> Total execution time: 0.1752
DEBUG - 2022-04-26 01:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:34 --> Total execution time: 0.0968
DEBUG - 2022-04-26 01:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:47 --> Total execution time: 0.1347
DEBUG - 2022-04-26 01:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:24:49 --> 404 Page Not Found: User/Profile_Controller/edit_bank_detail
DEBUG - 2022-04-26 01:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:03 --> Total execution time: 0.1150
DEBUG - 2022-04-26 01:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:10 --> Total execution time: 0.1167
DEBUG - 2022-04-26 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:46 --> Total execution time: 0.0950
DEBUG - 2022-04-26 01:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:01 --> Total execution time: 0.2276
DEBUG - 2022-04-26 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 01:27:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 01:27:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 01:27:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:22 --> Total execution time: 0.1454
DEBUG - 2022-04-26 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 01:27:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:23 --> UTF-8 Support Enabled
ERROR - 2022-04-26 01:27:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 01:27:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:27:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 01:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:31 --> Total execution time: 0.1273
DEBUG - 2022-04-26 01:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:40 --> Total execution time: 0.1421
DEBUG - 2022-04-26 01:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:58:21 --> Total execution time: 0.1095
DEBUG - 2022-04-26 01:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 01:28:23 --> 404 Page Not Found: user/Edit-bank-details/index
DEBUG - 2022-04-26 01:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:58:55 --> Total execution time: 0.1150
DEBUG - 2022-04-26 01:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:00:29 --> Total execution time: 0.1245
DEBUG - 2022-04-26 01:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:00:44 --> Total execution time: 0.1201
DEBUG - 2022-04-26 01:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:00:50 --> Total execution time: 0.1289
DEBUG - 2022-04-26 01:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:01:02 --> Total execution time: 0.2547
DEBUG - 2022-04-26 01:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:02:26 --> Total execution time: 0.1456
DEBUG - 2022-04-26 01:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:02:39 --> Total execution time: 0.1126
DEBUG - 2022-04-26 01:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:02:59 --> Total execution time: 0.1417
DEBUG - 2022-04-26 01:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:03:33 --> Total execution time: 0.1354
DEBUG - 2022-04-26 01:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:05:15 --> Total execution time: 0.1228
DEBUG - 2022-04-26 01:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:07:01 --> Total execution time: 0.1971
DEBUG - 2022-04-26 01:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:07:23 --> Total execution time: 0.1030
DEBUG - 2022-04-26 01:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:07:53 --> Total execution time: 0.1489
DEBUG - 2022-04-26 01:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 01:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:07:55 --> Total execution time: 0.0977
DEBUG - 2022-04-26 01:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:07:59 --> Total execution time: 0.0921
DEBUG - 2022-04-26 01:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 01:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 01:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 05:08:03 --> Total execution time: 0.0836
DEBUG - 2022-04-26 03:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:06:41 --> Total execution time: 0.0964
DEBUG - 2022-04-26 03:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:06:46 --> Total execution time: 0.2010
DEBUG - 2022-04-26 03:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:06:48 --> Total execution time: 0.2102
DEBUG - 2022-04-26 03:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:36:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 07:06:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-26 03:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:06:57 --> Total execution time: 0.1286
DEBUG - 2022-04-26 03:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:08:49 --> Total execution time: 0.1335
DEBUG - 2022-04-26 03:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:08:55 --> Total execution time: 0.1040
DEBUG - 2022-04-26 03:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:09:01 --> Total execution time: 0.1121
DEBUG - 2022-04-26 03:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:09:06 --> Total execution time: 0.1063
DEBUG - 2022-04-26 03:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:10:20 --> Total execution time: 0.1636
DEBUG - 2022-04-26 03:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:10:30 --> Total execution time: 0.1186
DEBUG - 2022-04-26 03:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:10:48 --> Total execution time: 0.1135
DEBUG - 2022-04-26 03:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:10:56 --> Total execution time: 0.1136
DEBUG - 2022-04-26 03:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:11:32 --> Total execution time: 0.1464
DEBUG - 2022-04-26 03:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:11:38 --> Total execution time: 0.1429
DEBUG - 2022-04-26 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:11:49 --> Total execution time: 0.1255
DEBUG - 2022-04-26 03:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:12:09 --> Total execution time: 0.1214
DEBUG - 2022-04-26 03:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:44:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 07:14:31 --> Query error: Not unique table/alias: 'user_logins' - Invalid query: SELECT *
FROM `user_joins`
LEFT JOIN `user_logins` ON `user_logins`.`ul_id` = `user_joins`.`uj_child_id`
LEFT JOIN `user_logins` ON `user_logins`.`ul_id` = `user_joins`.`uj_parent_id`
WHERE `user_joins`.`uj_parent_id` = '1'
DEBUG - 2022-04-26 03:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:44:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 07:14:43 --> Query error: Not unique table/alias: 'user_logins' - Invalid query: SELECT *
FROM `user_joins`
LEFT JOIN `user_logins` ON `user_logins`.`ul_id` = `user_joins`.`uj_child_id`
LEFT JOIN `user_logins` ON `user_logins`.`ul_id` = `user_joins`.`uj_parent_id`
WHERE `user_joins`.`uj_parent_id` = '1'
DEBUG - 2022-04-26 03:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 03:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:17:31 --> Total execution time: 0.0967
DEBUG - 2022-04-26 03:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:18:54 --> Total execution time: 0.1161
DEBUG - 2022-04-26 03:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:19:10 --> Total execution time: 0.1125
DEBUG - 2022-04-26 03:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:19:35 --> Total execution time: 0.6944
DEBUG - 2022-04-26 03:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:19:39 --> Total execution time: 0.3051
DEBUG - 2022-04-26 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:21:16 --> Total execution time: 0.1488
DEBUG - 2022-04-26 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:30:14 --> Total execution time: 0.1251
DEBUG - 2022-04-26 04:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:30:28 --> Total execution time: 0.0931
DEBUG - 2022-04-26 04:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:30:32 --> Total execution time: 0.0892
DEBUG - 2022-04-26 04:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:30:52 --> Total execution time: 0.1152
DEBUG - 2022-04-26 04:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:30:54 --> Total execution time: 0.1050
DEBUG - 2022-04-26 04:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:31:21 --> Total execution time: 0.1006
DEBUG - 2022-04-26 04:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:31:23 --> Total execution time: 0.0936
DEBUG - 2022-04-26 04:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:31:39 --> Total execution time: 0.1020
DEBUG - 2022-04-26 04:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:31:43 --> Total execution time: 0.0956
DEBUG - 2022-04-26 04:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:26:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 07:56:18 --> Severity: error --> Exception: Call to undefined function Get_Level_Childs_checking() C:\xampp\htdocs\leadsark\application\controllers\User\Referrals_Controller.php 22
DEBUG - 2022-04-26 04:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:47:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 08:17:37 --> Severity: error --> Exception: Call to undefined method User_tire_team_model::menu_get_join_users() C:\xampp\htdocs\leadsark\application\helpers\two_tier_helper.php 15
DEBUG - 2022-04-26 04:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:18:42 --> Total execution time: 0.1304
DEBUG - 2022-04-26 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:18:53 --> Total execution time: 0.1002
DEBUG - 2022-04-26 04:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:19:13 --> Total execution time: 0.1406
DEBUG - 2022-04-26 04:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:20:29 --> Total execution time: 0.0899
DEBUG - 2022-04-26 04:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:20:32 --> Total execution time: 0.1386
DEBUG - 2022-04-26 04:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:20:34 --> Total execution time: 0.1067
DEBUG - 2022-04-26 04:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:20:45 --> Total execution time: 0.0967
DEBUG - 2022-04-26 04:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:20:47 --> Total execution time: 0.1339
DEBUG - 2022-04-26 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:50:49 --> Total execution time: 0.1705
DEBUG - 2022-04-26 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:50:49 --> Total execution time: 0.1214
DEBUG - 2022-04-26 04:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:51:15 --> Total execution time: 0.2285
DEBUG - 2022-04-26 04:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:51:18 --> Total execution time: 0.1646
DEBUG - 2022-04-26 04:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:21:29 --> Total execution time: 0.1277
DEBUG - 2022-04-26 04:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:22:09 --> Total execution time: 0.0925
DEBUG - 2022-04-26 04:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:22:13 --> Total execution time: 0.1448
DEBUG - 2022-04-26 04:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:15 --> Total execution time: 0.1303
DEBUG - 2022-04-26 04:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:15 --> Total execution time: 0.1479
DEBUG - 2022-04-26 04:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:31 --> Total execution time: 0.1280
DEBUG - 2022-04-26 04:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:32 --> Total execution time: 0.1582
DEBUG - 2022-04-26 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:22:41 --> Total execution time: 0.1090
DEBUG - 2022-04-26 04:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:22:44 --> Total execution time: 0.1368
DEBUG - 2022-04-26 04:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:22:45 --> Total execution time: 0.1166
DEBUG - 2022-04-26 04:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:52 --> Total execution time: 0.1460
DEBUG - 2022-04-26 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:52:53 --> Total execution time: 0.1492
DEBUG - 2022-04-26 04:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:11 --> Total execution time: 0.1397
DEBUG - 2022-04-26 04:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:11 --> Total execution time: 0.1259
DEBUG - 2022-04-26 04:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:23:20 --> Total execution time: 0.1294
DEBUG - 2022-04-26 04:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:23:25 --> Total execution time: 0.0924
DEBUG - 2022-04-26 04:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:23:26 --> Total execution time: 0.1206
DEBUG - 2022-04-26 04:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 08:23:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-26 04:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:23:36 --> Total execution time: 0.1235
DEBUG - 2022-04-26 04:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:23:41 --> Total execution time: 0.0981
DEBUG - 2022-04-26 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:23:42 --> Total execution time: 0.1223
DEBUG - 2022-04-26 04:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:46 --> Total execution time: 0.1372
DEBUG - 2022-04-26 04:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:53:47 --> Total execution time: 0.1364
DEBUG - 2022-04-26 04:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:04 --> Total execution time: 0.1217
DEBUG - 2022-04-26 04:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:05 --> Total execution time: 0.1395
DEBUG - 2022-04-26 04:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:24:12 --> Total execution time: 0.1248
DEBUG - 2022-04-26 04:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:24:15 --> Total execution time: 0.0859
DEBUG - 2022-04-26 04:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:24:19 --> Total execution time: 0.1289
DEBUG - 2022-04-26 04:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:25 --> Total execution time: 0.1333
DEBUG - 2022-04-26 04:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:26 --> Total execution time: 0.1325
DEBUG - 2022-04-26 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:41 --> Total execution time: 0.1207
DEBUG - 2022-04-26 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:41 --> Total execution time: 0.1108
DEBUG - 2022-04-26 04:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:24:49 --> Total execution time: 0.1235
DEBUG - 2022-04-26 04:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:24:52 --> Total execution time: 0.1016
DEBUG - 2022-04-26 04:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:24:53 --> Total execution time: 0.1343
DEBUG - 2022-04-26 04:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 08:24:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-26 04:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:24:59 --> Total execution time: 0.1247
DEBUG - 2022-04-26 04:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:25:03 --> Total execution time: 0.0989
DEBUG - 2022-04-26 04:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:25:05 --> Total execution time: 0.1162
DEBUG - 2022-04-26 04:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:07 --> Total execution time: 0.1287
DEBUG - 2022-04-26 04:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:09 --> Total execution time: 0.1028
DEBUG - 2022-04-26 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:30 --> Total execution time: 0.1261
DEBUG - 2022-04-26 04:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:31 --> Total execution time: 0.1201
DEBUG - 2022-04-26 04:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:25:38 --> Total execution time: 0.1324
DEBUG - 2022-04-26 04:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:25:41 --> Total execution time: 0.1023
DEBUG - 2022-04-26 04:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:25:44 --> Total execution time: 0.1400
DEBUG - 2022-04-26 04:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 08:25:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-26 04:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:25:48 --> Total execution time: 0.1286
DEBUG - 2022-04-26 04:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:25:50 --> Total execution time: 0.1110
DEBUG - 2022-04-26 04:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:27:11 --> Total execution time: 0.0880
DEBUG - 2022-04-26 04:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:27:13 --> Total execution time: 0.1117
DEBUG - 2022-04-26 04:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 08:27:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-26 04:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:27:18 --> Total execution time: 0.1307
DEBUG - 2022-04-26 04:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:27:24 --> Total execution time: 0.0923
DEBUG - 2022-04-26 04:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:27:25 --> Total execution time: 0.1190
DEBUG - 2022-04-26 04:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:29 --> Total execution time: 0.1254
DEBUG - 2022-04-26 04:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:29 --> Total execution time: 0.1141
DEBUG - 2022-04-26 04:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:43 --> Total execution time: 0.1176
DEBUG - 2022-04-26 04:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:44 --> Total execution time: 0.1848
DEBUG - 2022-04-26 04:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:27:52 --> Total execution time: 0.1155
DEBUG - 2022-04-26 04:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 04:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:27:54 --> Total execution time: 0.0946
DEBUG - 2022-04-26 04:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:27:55 --> Total execution time: 0.1149
DEBUG - 2022-04-26 04:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:57:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 08:27:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-26 04:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:28:00 --> Total execution time: 0.1491
DEBUG - 2022-04-26 04:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:28:02 --> Total execution time: 0.1024
DEBUG - 2022-04-26 04:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:28:25 --> Total execution time: 0.1125
DEBUG - 2022-04-26 05:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:30:11 --> Total execution time: 0.1086
DEBUG - 2022-04-26 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:33:20 --> Total execution time: 0.1041
DEBUG - 2022-04-26 05:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:33:35 --> Total execution time: 0.1481
DEBUG - 2022-04-26 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:33:41 --> Total execution time: 0.1191
DEBUG - 2022-04-26 05:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:33:49 --> Total execution time: 0.1173
DEBUG - 2022-04-26 05:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:06 --> Total execution time: 0.1196
DEBUG - 2022-04-26 05:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:15 --> Total execution time: 0.1281
DEBUG - 2022-04-26 05:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:17 --> Total execution time: 0.1020
DEBUG - 2022-04-26 05:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:24 --> Total execution time: 0.1383
DEBUG - 2022-04-26 05:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:29 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-04-26 08:34:29 --> Severity: Warning --> unlink(assets/user_thumbnail/default.jpg): No such file or directory C:\xampp\htdocs\leadsark\application\controllers\User\Profile_Controller.php 161
DEBUG - 2022-04-26 05:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:30 --> Total execution time: 0.1084
DEBUG - 2022-04-26 05:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:32 --> Total execution time: 0.1126
DEBUG - 2022-04-26 05:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:39 --> Total execution time: 0.1212
DEBUG - 2022-04-26 05:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:44 --> Total execution time: 0.0887
DEBUG - 2022-04-26 05:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:48 --> Total execution time: 0.0848
DEBUG - 2022-04-26 05:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:34:50 --> Total execution time: 0.1459
DEBUG - 2022-04-26 05:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:37:02 --> Total execution time: 0.1216
DEBUG - 2022-04-26 05:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:37:16 --> Total execution time: 0.1610
DEBUG - 2022-04-26 05:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:38:21 --> Total execution time: 0.1287
DEBUG - 2022-04-26 05:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:38:37 --> Total execution time: 0.1263
DEBUG - 2022-04-26 05:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:08:17 --> Total execution time: 0.4355
DEBUG - 2022-04-26 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:12:45 --> Total execution time: 0.4666
DEBUG - 2022-04-26 05:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:14:41 --> Total execution time: 0.1324
DEBUG - 2022-04-26 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:47:45 --> Total execution time: 0.1970
DEBUG - 2022-04-26 06:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:47:58 --> Total execution time: 0.1344
DEBUG - 2022-04-26 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:48:01 --> Total execution time: 0.1054
DEBUG - 2022-04-26 06:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:48:08 --> Total execution time: 0.1834
DEBUG - 2022-04-26 06:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:48:11 --> Total execution time: 0.0978
DEBUG - 2022-04-26 06:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:48:42 --> Total execution time: 0.1338
DEBUG - 2022-04-26 06:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:49:18 --> Total execution time: 0.1159
DEBUG - 2022-04-26 06:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:50:00 --> Total execution time: 0.1217
DEBUG - 2022-04-26 06:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:50:06 --> Total execution time: 0.1141
DEBUG - 2022-04-26 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:50:32 --> Total execution time: 0.1490
DEBUG - 2022-04-26 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:50:37 --> Total execution time: 0.1402
DEBUG - 2022-04-26 06:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:52:14 --> Total execution time: 0.0978
DEBUG - 2022-04-26 06:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:53:08 --> Total execution time: 0.1273
DEBUG - 2022-04-26 06:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:53:36 --> Total execution time: 0.1050
DEBUG - 2022-04-26 06:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:53:53 --> Total execution time: 0.1152
DEBUG - 2022-04-26 06:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:54:13 --> Total execution time: 0.1467
DEBUG - 2022-04-26 06:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:54:28 --> Total execution time: 0.1333
DEBUG - 2022-04-26 06:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:54:41 --> Total execution time: 0.1114
DEBUG - 2022-04-26 06:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:54:59 --> Total execution time: 0.1173
DEBUG - 2022-04-26 06:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:55:57 --> Total execution time: 0.1263
DEBUG - 2022-04-26 06:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:57:34 --> Total execution time: 0.1288
DEBUG - 2022-04-26 06:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:57:55 --> Total execution time: 0.1100
DEBUG - 2022-04-26 06:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:59:38 --> Total execution time: 0.1116
DEBUG - 2022-04-26 06:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:02:03 --> Total execution time: 0.1247
DEBUG - 2022-04-26 06:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:03:34 --> Total execution time: 0.0988
DEBUG - 2022-04-26 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:03:59 --> Total execution time: 0.1036
DEBUG - 2022-04-26 06:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:04:10 --> Total execution time: 0.1574
DEBUG - 2022-04-26 06:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:04:28 --> Total execution time: 0.1025
DEBUG - 2022-04-26 06:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:05:47 --> Total execution time: 0.1138
DEBUG - 2022-04-26 06:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:05:50 --> Total execution time: 0.1356
DEBUG - 2022-04-26 06:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:05:54 --> Total execution time: 0.1015
DEBUG - 2022-04-26 06:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:07:10 --> Total execution time: 0.0962
DEBUG - 2022-04-26 06:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:09:28 --> Total execution time: 0.1401
DEBUG - 2022-04-26 06:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:09:30 --> Total execution time: 0.1133
DEBUG - 2022-04-26 06:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:11:05 --> Total execution time: 0.1123
DEBUG - 2022-04-26 06:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:11:44 --> Total execution time: 0.1113
DEBUG - 2022-04-26 06:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:11:48 --> Total execution time: 0.0971
DEBUG - 2022-04-26 06:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:11:50 --> Total execution time: 0.0963
DEBUG - 2022-04-26 06:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:11:56 --> Total execution time: 0.1026
DEBUG - 2022-04-26 06:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:45:10 --> Total execution time: 0.1632
DEBUG - 2022-04-26 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:45:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 10:15:14 --> Query error: Table 'leadsark.rents' doesn't exist - Invalid query: SELECT SUM(`rent_amount_paid`) AS `rent_amount_paid`
FROM `rents`
WHERE YEAR(rent_date) = '2022'
DEBUG - 2022-04-26 06:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:45:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 10:15:41 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\leadsark\application\views\Admin\dashboard.php 40
ERROR - 2022-04-26 10:15:41 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\leadsark\application\views\Admin\dashboard.php 63
ERROR - 2022-04-26 10:15:41 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\leadsark\application\views\Admin\dashboard.php 81
ERROR - 2022-04-26 10:15:41 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\leadsark\application\views\Admin\dashboard.php 99
DEBUG - 2022-04-26 10:15:41 --> Total execution time: 0.2609
DEBUG - 2022-04-26 06:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:15:47 --> Total execution time: 0.1750
DEBUG - 2022-04-26 06:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:17:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 06:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:17:29 --> Total execution time: 0.0891
DEBUG - 2022-04-26 06:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:47:38 --> No URI present. Default controller set.
DEBUG - 2022-04-26 06:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:17:41 --> Total execution time: 0.0972
DEBUG - 2022-04-26 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:18:24 --> Total execution time: 0.1237
DEBUG - 2022-04-26 06:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 10:18:37 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\leadsark\application\views\Admin\dashboard.php 40
ERROR - 2022-04-26 10:18:37 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\leadsark\application\views\Admin\dashboard.php 63
ERROR - 2022-04-26 10:18:37 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\leadsark\application\views\Admin\dashboard.php 81
ERROR - 2022-04-26 10:18:37 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\leadsark\application\views\Admin\dashboard.php 99
DEBUG - 2022-04-26 10:18:37 --> Total execution time: 0.0910
DEBUG - 2022-04-26 06:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:18:39 --> Total execution time: 0.1219
DEBUG - 2022-04-26 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:18:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 10:18:55 --> You did not select a file to upload.
DEBUG - 2022-04-26 10:18:55 --> You did not select a file to upload.
DEBUG - 2022-04-26 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:18:55 --> Total execution time: 0.1073
DEBUG - 2022-04-26 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:18:58 --> Total execution time: 0.0925
DEBUG - 2022-04-26 06:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:19:36 --> Total execution time: 0.1140
DEBUG - 2022-04-26 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:19:44 --> Total execution time: 0.1042
DEBUG - 2022-04-26 06:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:19:45 --> Total execution time: 0.1435
DEBUG - 2022-04-26 06:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:49:47 --> Total execution time: 0.1224
DEBUG - 2022-04-26 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:49:48 --> Total execution time: 0.1358
DEBUG - 2022-04-26 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:50:06 --> Total execution time: 0.1305
DEBUG - 2022-04-26 06:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:50:07 --> Total execution time: 0.1162
DEBUG - 2022-04-26 06:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:50:23 --> Total execution time: 0.1181
DEBUG - 2022-04-26 06:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:50:24 --> Total execution time: 0.1370
DEBUG - 2022-04-26 06:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:20:35 --> Total execution time: 0.1209
DEBUG - 2022-04-26 06:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:22:05 --> Total execution time: 0.0974
DEBUG - 2022-04-26 06:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:23:54 --> Total execution time: 0.1305
DEBUG - 2022-04-26 06:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:25:08 --> Total execution time: 0.0972
DEBUG - 2022-04-26 06:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:55:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-04-26 06:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 06:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:25:14 --> Total execution time: 0.0952
DEBUG - 2022-04-26 06:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:25:15 --> Total execution time: 0.1316
DEBUG - 2022-04-26 06:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 10:25:27 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\controllers\User\Auth\UserAuth.php 47
DEBUG - 2022-04-26 06:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:25:28 --> Total execution time: 0.1416
DEBUG - 2022-04-26 06:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:55:28 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-04-26 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:55:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 06:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:55:32 --> UTF-8 Support Enabled
ERROR - 2022-04-26 06:55:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 06:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:55:45 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-04-26 06:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:26:06 --> Total execution time: 0.1233
DEBUG - 2022-04-26 06:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:56:07 --> UTF-8 Support Enabled
ERROR - 2022-04-26 06:56:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:26:45 --> Total execution time: 0.1504
DEBUG - 2022-04-26 06:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 06:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 06:56:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 07:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 07:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:03:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 10:33:22 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\esalestrix\application\views\Admin\dashboard.php 40
ERROR - 2022-04-26 10:33:22 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\esalestrix\application\views\Admin\dashboard.php 63
ERROR - 2022-04-26 10:33:22 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\esalestrix\application\views\Admin\dashboard.php 81
ERROR - 2022-04-26 10:33:22 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\esalestrix\application\views\Admin\dashboard.php 99
DEBUG - 2022-04-26 10:33:22 --> Total execution time: 0.0872
DEBUG - 2022-04-26 07:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:43:56 --> Total execution time: 0.1594
DEBUG - 2022-04-26 07:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:45:56 --> Total execution time: 0.1335
DEBUG - 2022-04-26 07:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:46:52 --> Total execution time: 0.1629
DEBUG - 2022-04-26 07:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:50:05 --> Total execution time: 0.1994
DEBUG - 2022-04-26 07:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:50:06 --> Total execution time: 0.0982
DEBUG - 2022-04-26 07:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:50:39 --> Total execution time: 0.0941
DEBUG - 2022-04-26 07:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:51:20 --> Total execution time: 0.1090
DEBUG - 2022-04-26 07:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:51:39 --> Total execution time: 0.0948
DEBUG - 2022-04-26 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:52:11 --> Total execution time: 0.0991
DEBUG - 2022-04-26 07:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:55:55 --> Total execution time: 0.1162
DEBUG - 2022-04-26 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:56:38 --> Total execution time: 0.1248
DEBUG - 2022-04-26 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:56:47 --> Total execution time: 0.1609
DEBUG - 2022-04-26 07:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:56:55 --> Total execution time: 0.0888
DEBUG - 2022-04-26 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:59:30 --> Total execution time: 0.1088
DEBUG - 2022-04-26 07:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:59:32 --> Total execution time: 0.0915
DEBUG - 2022-04-26 07:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 10:59:35 --> Total execution time: 0.0927
DEBUG - 2022-04-26 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:02:25 --> Total execution time: 0.1323
DEBUG - 2022-04-26 07:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:03:08 --> Total execution time: 0.0870
DEBUG - 2022-04-26 07:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:03:22 --> Total execution time: 0.0897
DEBUG - 2022-04-26 07:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:05:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 11:05:48 --> Total execution time: 0.1065
DEBUG - 2022-04-26 07:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:08:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 11:08:04 --> Total execution time: 0.1210
DEBUG - 2022-04-26 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:08:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 11:08:29 --> Total execution time: 0.1086
DEBUG - 2022-04-26 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:08:40 --> Total execution time: 0.0879
DEBUG - 2022-04-26 07:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:08:41 --> Total execution time: 0.1003
DEBUG - 2022-04-26 07:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:09:31 --> Total execution time: 0.1208
DEBUG - 2022-04-26 07:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:13:21 --> Total execution time: 0.1283
DEBUG - 2022-04-26 07:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:14:07 --> Total execution time: 0.1050
DEBUG - 2022-04-26 07:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:14:28 --> Total execution time: 0.0887
DEBUG - 2022-04-26 07:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:15:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 11:15:02 --> Total execution time: 0.1055
DEBUG - 2022-04-26 07:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:15:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:15:18 --> Total execution time: 0.1059
DEBUG - 2022-04-26 07:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:16:37 --> Total execution time: 0.1018
DEBUG - 2022-04-26 07:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:46:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 07:46:42 --> 404 Page Not Found: admin/Course-list/index
DEBUG - 2022-04-26 07:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:18:55 --> Total execution time: 0.1246
DEBUG - 2022-04-26 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:21:55 --> Total execution time: 0.0938
DEBUG - 2022-04-26 07:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:22:27 --> Total execution time: 0.1462
DEBUG - 2022-04-26 07:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:23:39 --> Total execution time: 0.1235
DEBUG - 2022-04-26 07:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:25:29 --> Total execution time: 0.1007
DEBUG - 2022-04-26 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 07:56:24 --> 404 Page Not Found: admin/Course-media/index
DEBUG - 2022-04-26 07:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:58:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 11:28:14 --> Severity: Notice --> Undefined variable: all_course C:\xampp\htdocs\esalestrix\application\views\Admin\course\course_media.php 54
ERROR - 2022-04-26 11:28:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\esalestrix\application\views\Admin\course\course_media.php 54
DEBUG - 2022-04-26 11:28:14 --> Total execution time: 0.0960
DEBUG - 2022-04-26 07:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:28:24 --> Total execution time: 0.1254
DEBUG - 2022-04-26 07:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:28:30 --> Total execution time: 0.1310
DEBUG - 2022-04-26 07:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:29:45 --> Total execution time: 0.0960
DEBUG - 2022-04-26 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:30:03 --> Total execution time: 0.1285
DEBUG - 2022-04-26 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:30:10 --> Total execution time: 0.1080
DEBUG - 2022-04-26 08:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:30:23 --> Total execution time: 0.1306
DEBUG - 2022-04-26 08:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:31:57 --> Total execution time: 0.1467
DEBUG - 2022-04-26 08:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:32:14 --> Total execution time: 0.1592
DEBUG - 2022-04-26 08:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:34:19 --> Total execution time: 0.1143
DEBUG - 2022-04-26 08:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:34:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 11:34:23 --> You have not specified any allowed file types.
DEBUG - 2022-04-26 11:34:23 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-04-26 08:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:34:23 --> Total execution time: 0.0976
DEBUG - 2022-04-26 08:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:35:01 --> Total execution time: 0.1015
DEBUG - 2022-04-26 08:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:35:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 11:35:05 --> Total execution time: 0.1287
DEBUG - 2022-04-26 08:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:36:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 11:36:24 --> Total execution time: 0.1177
DEBUG - 2022-04-26 08:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:37:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 08:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:37:36 --> Total execution time: 0.1899
DEBUG - 2022-04-26 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:39:06 --> Total execution time: 0.1018
DEBUG - 2022-04-26 08:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:40:25 --> Total execution time: 0.1256
DEBUG - 2022-04-26 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:55:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:55:42 --> Total execution time: 0.0973
DEBUG - 2022-04-26 08:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:57:23 --> Total execution time: 0.1578
DEBUG - 2022-04-26 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:57:44 --> Total execution time: 0.1488
DEBUG - 2022-04-26 08:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:57:53 --> Total execution time: 0.1403
DEBUG - 2022-04-26 08:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:58:18 --> Total execution time: 0.1608
DEBUG - 2022-04-26 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:28:22 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:28:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:28:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:28:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:28:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:28:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:28:22 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:28:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:28:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:28:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:28:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:59:07 --> Total execution time: 0.0995
DEBUG - 2022-04-26 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:29:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:29:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:29:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:29:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:29:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:29:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:29:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:29:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:01:26 --> Total execution time: 0.1323
DEBUG - 2022-04-26 08:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:02:44 --> Total execution time: 0.1441
DEBUG - 2022-04-26 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:04:09 --> Total execution time: 0.1343
DEBUG - 2022-04-26 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:34:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:34:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:34:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:34:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:34:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:34:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:34:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:34:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:34:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:06:09 --> Total execution time: 0.2635
DEBUG - 2022-04-26 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:36:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:06:15 --> Total execution time: 0.0985
DEBUG - 2022-04-26 08:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:08:27 --> Total execution time: 0.1769
DEBUG - 2022-04-26 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:38:28 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:08:33 --> Total execution time: 0.1009
DEBUG - 2022-04-26 08:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:08:35 --> Total execution time: 0.0991
DEBUG - 2022-04-26 08:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:38:35 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:38:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 12:08:46 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `files` SET `file_id` = 'screenshot (31).png2141'
WHERE `file_id` = '1'
DEBUG - 2022-04-26 08:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:38:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 12:08:54 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `files` SET `file_id` = 'screenshot (31).png2141'
WHERE `file_id` = '1'
DEBUG - 2022-04-26 08:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:09:49 --> Total execution time: 0.0952
DEBUG - 2022-04-26 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:39:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:39:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:09:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 08:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:09:55 --> Total execution time: 0.0895
DEBUG - 2022-04-26 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:39:56 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:39:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:39:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:10:00 --> Total execution time: 0.1021
DEBUG - 2022-04-26 08:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:01 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 08:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:10:08 --> Total execution time: 0.1340
DEBUG - 2022-04-26 08:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:10:11 --> Total execution time: 0.1226
DEBUG - 2022-04-26 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:12 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:12 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:40:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:10:15 --> Total execution time: 0.0966
DEBUG - 2022-04-26 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:10:17 --> Total execution time: 0.1005
DEBUG - 2022-04-26 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:17 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:10:53 --> Total execution time: 0.0971
DEBUG - 2022-04-26 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:40:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:40:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:11:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:11:00 --> Total execution time: 0.1132
DEBUG - 2022-04-26 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:11:04 --> Total execution time: 0.0924
DEBUG - 2022-04-26 08:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:11:05 --> Total execution time: 0.0947
DEBUG - 2022-04-26 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:41:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:41:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:41:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:11:49 --> Total execution time: 0.4233
DEBUG - 2022-04-26 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:12:12 --> Total execution time: 0.4398
DEBUG - 2022-04-26 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:13:30 --> Total execution time: 0.1658
DEBUG - 2022-04-26 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:13:55 --> Total execution time: 0.1241
DEBUG - 2022-04-26 08:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:14:11 --> Total execution time: 0.1474
DEBUG - 2022-04-26 08:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:14:40 --> Total execution time: 0.1247
DEBUG - 2022-04-26 08:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:14:44 --> Total execution time: 0.1257
DEBUG - 2022-04-26 08:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:14:47 --> Total execution time: 0.0903
DEBUG - 2022-04-26 08:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:15:21 --> Total execution time: 0.1734
DEBUG - 2022-04-26 08:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:15:40 --> Total execution time: 0.1349
DEBUG - 2022-04-26 08:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:16:05 --> Total execution time: 0.1435
DEBUG - 2022-04-26 08:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:16:17 --> Total execution time: 0.1414
DEBUG - 2022-04-26 08:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:16:40 --> Total execution time: 0.1365
DEBUG - 2022-04-26 08:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:16:42 --> Total execution time: 0.0977
DEBUG - 2022-04-26 08:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:16:51 --> Total execution time: 0.0933
DEBUG - 2022-04-26 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:17:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:17:11 --> Total execution time: 0.0963
DEBUG - 2022-04-26 08:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:17:32 --> Total execution time: 0.0976
DEBUG - 2022-04-26 08:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:18:57 --> Total execution time: 0.1635
DEBUG - 2022-04-26 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:20:12 --> Total execution time: 0.1360
DEBUG - 2022-04-26 08:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:20:48 --> Total execution time: 0.1345
DEBUG - 2022-04-26 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:50:57 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:50:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:50:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:50:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:50:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:50:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:50:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:50:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:50:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:23:00 --> Total execution time: 0.1935
DEBUG - 2022-04-26 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:53:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:53:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:23:54 --> Total execution time: 0.1616
DEBUG - 2022-04-26 08:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:53:55 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:53:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:53:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:53:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:24:58 --> Total execution time: 0.1283
DEBUG - 2022-04-26 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:54:59 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:54:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:54:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 08:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:54:59 --> UTF-8 Support Enabled
ERROR - 2022-04-26 08:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:54:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 08:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:25:33 --> Total execution time: 0.1652
DEBUG - 2022-04-26 08:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:25:52 --> Total execution time: 0.1297
DEBUG - 2022-04-26 08:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:26:09 --> Total execution time: 0.1422
DEBUG - 2022-04-26 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:26:44 --> Total execution time: 0.1502
DEBUG - 2022-04-26 08:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:26:58 --> Total execution time: 0.1332
DEBUG - 2022-04-26 08:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:27:53 --> Total execution time: 0.1292
DEBUG - 2022-04-26 08:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:57:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:57:56 --> 404 Page Not Found: Edit-product/test
DEBUG - 2022-04-26 08:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 08:59:03 --> 404 Page Not Found: Edit-product/test
DEBUG - 2022-04-26 08:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:29:06 --> Total execution time: 0.1096
DEBUG - 2022-04-26 08:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:29:07 --> Total execution time: 0.1272
DEBUG - 2022-04-26 08:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:29:10 --> Total execution time: 0.1328
DEBUG - 2022-04-26 08:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 08:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 08:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:29:46 --> Total execution time: 0.1196
DEBUG - 2022-04-26 09:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:30:16 --> Total execution time: 0.1665
DEBUG - 2022-04-26 09:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:30:23 --> Total execution time: 0.1815
DEBUG - 2022-04-26 09:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:30:25 --> Total execution time: 0.0865
DEBUG - 2022-04-26 09:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:30:28 --> Total execution time: 0.1294
DEBUG - 2022-04-26 09:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:31:55 --> Total execution time: 0.0915
DEBUG - 2022-04-26 09:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:32:17 --> Total execution time: 0.1289
DEBUG - 2022-04-26 09:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:33:32 --> Total execution time: 0.1032
DEBUG - 2022-04-26 09:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:03:35 --> UTF-8 Support Enabled
ERROR - 2022-04-26 09:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:03:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 09:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:03:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:03:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:03:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 09:03:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:35:26 --> Total execution time: 0.1510
DEBUG - 2022-04-26 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:05:27 --> UTF-8 Support Enabled
ERROR - 2022-04-26 09:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:05:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 09:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:27 --> UTF-8 Support Enabled
ERROR - 2022-04-26 09:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:05:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:05:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:05:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 09:05:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:05:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:35:42 --> Total execution time: 0.1674
DEBUG - 2022-04-26 09:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:35:54 --> Total execution time: 0.1319
DEBUG - 2022-04-26 09:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:36:27 --> Total execution time: 0.0971
DEBUG - 2022-04-26 09:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:08:31 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\esalestrix\application\controllers\Admin\Course_crud_controller.php 84
DEBUG - 2022-04-26 09:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:38:41 --> Total execution time: 0.1342
DEBUG - 2022-04-26 09:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:08:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 12:38:45 --> Severity: Notice --> Undefined variable: InsertData C:\xampp\htdocs\esalestrix\application\controllers\Admin\Course_crud_controller.php 97
DEBUG - 2022-04-26 09:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:38:56 --> Total execution time: 0.0996
DEBUG - 2022-04-26 09:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:39:46 --> Total execution time: 0.0876
DEBUG - 2022-04-26 09:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:39:49 --> Total execution time: 0.1043
DEBUG - 2022-04-26 09:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:39:51 --> Total execution time: 0.0840
DEBUG - 2022-04-26 09:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:39:54 --> Total execution time: 0.1086
DEBUG - 2022-04-26 09:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:40:20 --> Total execution time: 0.0839
DEBUG - 2022-04-26 09:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:40:49 --> Total execution time: 0.1543
DEBUG - 2022-04-26 09:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:41:17 --> Total execution time: 0.1457
DEBUG - 2022-04-26 09:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:41:21 --> Total execution time: 0.0812
DEBUG - 2022-04-26 09:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:41:36 --> Total execution time: 0.0857
DEBUG - 2022-04-26 09:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:41:43 --> Total execution time: 0.0848
DEBUG - 2022-04-26 09:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:41:46 --> Total execution time: 0.0935
DEBUG - 2022-04-26 09:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:43:43 --> Total execution time: 0.1790
DEBUG - 2022-04-26 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:44:37 --> Total execution time: 0.1019
DEBUG - 2022-04-26 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:14:37 --> 404 Page Not Found: admin/Edit-product/assets
DEBUG - 2022-04-26 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:14:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 09:14:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:14:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:14:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:14:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:14:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 09:14:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:14:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:45:08 --> Total execution time: 0.1358
DEBUG - 2022-04-26 09:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:15:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 09:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:15:09 --> UTF-8 Support Enabled
ERROR - 2022-04-26 09:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:15:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 09:15:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:15:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:15:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:15:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:15:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 09:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:46:06 --> Total execution time: 0.1137
DEBUG - 2022-04-26 09:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:46:51 --> Total execution time: 0.1093
DEBUG - 2022-04-26 09:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:48:29 --> Total execution time: 0.1251
DEBUG - 2022-04-26 09:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:48:53 --> Total execution time: 0.1551
DEBUG - 2022-04-26 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:52:48 --> Total execution time: 0.1336
DEBUG - 2022-04-26 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:52:55 --> Total execution time: 0.1014
DEBUG - 2022-04-26 09:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:55:21 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-04-26 12:55:21 --> Severity: error --> Exception: Call to undefined function unlick() C:\xampp\htdocs\esalestrix\application\controllers\Admin\Course_crud_controller.php 189
DEBUG - 2022-04-26 09:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:55:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 12:55:31 --> Total execution time: 0.1094
DEBUG - 2022-04-26 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:57:57 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-04-26 12:57:57 --> Severity: Warning --> unlink(assets/course_feature_images/1iiucxyvz11650951918.png): No such file or directory C:\xampp\htdocs\esalestrix\application\controllers\Admin\Course_crud_controller.php 189
DEBUG - 2022-04-26 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:57:57 --> Total execution time: 0.0883
DEBUG - 2022-04-26 09:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:58:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 09:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:58:06 --> Total execution time: 0.1017
DEBUG - 2022-04-26 09:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:58:10 --> Total execution time: 0.0994
DEBUG - 2022-04-26 09:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 12:58:13 --> Total execution time: 0.0943
DEBUG - 2022-04-26 09:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:00:23 --> Total execution time: 0.1307
DEBUG - 2022-04-26 09:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:30:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:30:26 --> 404 Page Not Found: Delete-course/sukalyan-kayal
DEBUG - 2022-04-26 09:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:00:36 --> Total execution time: 0.1442
DEBUG - 2022-04-26 09:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:00:38 --> Total execution time: 0.0930
DEBUG - 2022-04-26 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:30:41 --> 404 Page Not Found: admin/Delete-course/sukalyan-kayal
DEBUG - 2022-04-26 09:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:02:29 --> Total execution time: 0.1323
DEBUG - 2022-04-26 09:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:02:39 --> Total execution time: 0.1634
DEBUG - 2022-04-26 09:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:03:10 --> Total execution time: 0.1462
DEBUG - 2022-04-26 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:03:17 --> Total execution time: 0.1093
DEBUG - 2022-04-26 18:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 18:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 18:38:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 18:38:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\core\DB_Controller.php 28
DEBUG - 2022-04-26 18:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 18:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 18:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 18:38:38 --> Total execution time: 0.1727
DEBUG - 2022-04-26 18:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 18:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 18:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 18:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 18:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 18:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:09:07 --> Total execution time: 0.1613
DEBUG - 2022-04-26 18:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 18:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 18:39:15 --> 404 Page Not Found: Admin-client-list/index
DEBUG - 2022-04-26 18:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 18:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 18:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:09:16 --> Total execution time: 0.0916
DEBUG - 2022-04-26 18:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 18:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 18:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:10:05 --> Total execution time: 0.1454
DEBUG - 2022-04-26 19:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:11:47 --> Total execution time: 0.3066
DEBUG - 2022-04-26 19:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:11:50 --> Total execution time: 0.0870
DEBUG - 2022-04-26 19:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:12:33 --> Total execution time: 0.0968
DEBUG - 2022-04-26 19:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 19:42:34 --> 404 Page Not Found: admin/User-list/index
DEBUG - 2022-04-26 19:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:46:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 23:16:47 --> Severity: Notice --> Undefined property: User_crud_controller::$User_logins C:\xampp\htdocs\esalestrix\application\controllers\Admin\User_crud_controller.php 9
ERROR - 2022-04-26 23:16:47 --> Severity: error --> Exception: Call to a member function get() on null C:\xampp\htdocs\esalestrix\application\controllers\Admin\User_crud_controller.php 9
DEBUG - 2022-04-26 19:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:16:54 --> Total execution time: 0.1607
DEBUG - 2022-04-26 19:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:17:35 --> Total execution time: 0.1367
DEBUG - 2022-04-26 19:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:17:45 --> Total execution time: 0.1285
DEBUG - 2022-04-26 19:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:18:12 --> Total execution time: 0.1326
DEBUG - 2022-04-26 19:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:21:34 --> Total execution time: 0.1451
DEBUG - 2022-04-26 19:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:22:02 --> Total execution time: 0.0979
DEBUG - 2022-04-26 19:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:22:06 --> Total execution time: 0.0996
DEBUG - 2022-04-26 19:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:22:44 --> Total execution time: 0.1446
DEBUG - 2022-04-26 19:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:23:08 --> Total execution time: 0.1481
DEBUG - 2022-04-26 19:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:25:00 --> Total execution time: 0.3940
DEBUG - 2022-04-26 19:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:25:08 --> Total execution time: 0.2878
DEBUG - 2022-04-26 19:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:25:26 --> Total execution time: 0.2853
DEBUG - 2022-04-26 19:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 19:55:34 --> 404 Page Not Found: admin/User-profile/ESALESTRIX1
DEBUG - 2022-04-26 19:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:26:46 --> Total execution time: 0.1454
DEBUG - 2022-04-26 19:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:26:49 --> Total execution time: 0.1394
DEBUG - 2022-04-26 19:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:26:52 --> Total execution time: 0.0948
DEBUG - 2022-04-26 19:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 19:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 19:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:29:33 --> Total execution time: 0.0997
DEBUG - 2022-04-26 20:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:31:23 --> Total execution time: 0.1640
DEBUG - 2022-04-26 20:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:32:01 --> Total execution time: 0.1569
DEBUG - 2022-04-26 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:02:33 --> UTF-8 Support Enabled
ERROR - 2022-04-26 20:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:02:33 --> UTF-8 Support Enabled
ERROR - 2022-04-26 20:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:02:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:33:21 --> Total execution time: 0.1466
DEBUG - 2022-04-26 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:03:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:03:22 --> UTF-8 Support Enabled
ERROR - 2022-04-26 20:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:03:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:03:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:03:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:34:33 --> Total execution time: 0.1438
DEBUG - 2022-04-26 20:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:34:56 --> Total execution time: 0.1043
DEBUG - 2022-04-26 20:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:35:08 --> Total execution time: 0.0992
DEBUG - 2022-04-26 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:08:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:08:37 --> Severity: error --> Exception: syntax error, unexpected ''BankDetails'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\esalestrix\application\controllers\Admin\User_crud_controller.php 25
DEBUG - 2022-04-26 20:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:08:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 23:38:46 --> Severity: Notice --> Undefined property: User_crud_controller::$Bank_accounts C:\xampp\htdocs\esalestrix\application\controllers\Admin\User_crud_controller.php 20
ERROR - 2022-04-26 23:38:46 --> Severity: error --> Exception: Call to a member function get() on null C:\xampp\htdocs\esalestrix\application\controllers\Admin\User_crud_controller.php 20
DEBUG - 2022-04-26 20:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:39:00 --> Total execution time: 0.1398
DEBUG - 2022-04-26 20:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:39:22 --> Total execution time: 0.1405
DEBUG - 2022-04-26 20:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:39:54 --> Total execution time: 0.1589
DEBUG - 2022-04-26 20:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:40:03 --> Total execution time: 0.1597
DEBUG - 2022-04-26 20:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:42:42 --> Total execution time: 0.1011
DEBUG - 2022-04-26 20:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:12:43 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-26 20:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:42:50 --> Total execution time: 0.1386
DEBUG - 2022-04-26 20:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:12:51 --> 404 Page Not Found: Images/small
DEBUG - 2022-04-26 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:12:55 --> UTF-8 Support Enabled
ERROR - 2022-04-26 20:12:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:12:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:12:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:12:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:12:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:12:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:12:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:12:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:13:02 --> 404 Page Not Found: Images/small
DEBUG - 2022-04-26 20:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:13:07 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-26 20:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:43:37 --> Total execution time: 0.1059
DEBUG - 2022-04-26 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:13:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:13:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:13:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:13:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:13:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:13:38 --> UTF-8 Support Enabled
ERROR - 2022-04-26 20:13:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:13:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:13:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:30:35 --> UTF-8 Support Enabled
ERROR - 2022-04-26 20:30:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:30:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:30:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:30:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:30:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 20:30:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 20:30:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 20:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 20:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 20:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:23:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:23:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:23:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:23:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:23:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:23:48 --> UTF-8 Support Enabled
ERROR - 2022-04-26 22:23:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:23:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:23:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:24:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:24:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 22:24:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:24:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:24:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:24:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 22:24:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:24:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:24:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:24:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:51 --> UTF-8 Support Enabled
ERROR - 2022-04-26 22:27:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 22:27:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:52 --> UTF-8 Support Enabled
ERROR - 2022-04-26 22:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 22:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 22:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:56 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 22:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 22:27:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:27:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 22:27:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:28:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:28:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 22:28:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 22:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:28:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 22:28:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\esalestrix\application\core\DB_Controller.php 52
DEBUG - 2022-04-26 22:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 22:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 22:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 22:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 23:03:16 --> 404 Page Not Found: user/Pan-kyc/index
DEBUG - 2022-04-26 23:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:40:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 23:40:54 --> Severity: error --> Exception: syntax error, unexpected ''PAN_Kyc'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\esalestrix\application\controllers\Admin\User_crud_controller.php 33
DEBUG - 2022-04-26 23:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 23:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 23:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 23:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:24:42 --> No URI present. Default controller set.
DEBUG - 2022-04-26 11:24:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:24:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/gvprods/public_html/v1/gvv3/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-04-26 11:24:42 --> Unable to connect to the database
ERROR - 2022-04-26 11:24:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-26 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:24:43 --> No URI present. Default controller set.
DEBUG - 2022-04-26 11:24:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:24:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: NO) /home/gvprods/public_html/v1/gvv3/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-04-26 11:24:43 --> Unable to connect to the database
ERROR - 2022-04-26 11:24:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-26 11:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:25:30 --> No URI present. Default controller set.
DEBUG - 2022-04-26 11:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:55:37 --> Total execution time: 0.0280
DEBUG - 2022-04-26 11:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:55:43 --> Total execution time: 0.0283
DEBUG - 2022-04-26 11:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:25:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-26 16:55:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/controllers/User/Auth/UserAuth.php 47
ERROR - 2022-04-26 16:55:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-04-26 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:56:38 --> Total execution time: 0.0296
DEBUG - 2022-04-26 11:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:57:02 --> Total execution time: 0.0330
DEBUG - 2022-04-26 11:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:57:03 --> Total execution time: 0.0275
DEBUG - 2022-04-26 11:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:57:09 --> Total execution time: 0.0305
DEBUG - 2022-04-26 11:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:57:17 --> Total execution time: 0.0270
DEBUG - 2022-04-26 11:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:57:18 --> Total execution time: 0.0296
DEBUG - 2022-04-26 11:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 16:57:27 --> Total execution time: 0.0335
DEBUG - 2022-04-26 11:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 17:04:30 --> Total execution time: 0.7892
DEBUG - 2022-04-26 11:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:34:41 --> 404 Page Not Found: R/login
DEBUG - 2022-04-26 11:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:34:42 --> 404 Page Not Found: Login/index
DEBUG - 2022-04-26 11:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:34:44 --> 404 Page Not Found: Admlogin/index
DEBUG - 2022-04-26 11:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:34:44 --> 404 Page Not Found: Adlogin/index
DEBUG - 2022-04-26 11:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:34:45 --> 404 Page Not Found: Admilogin/index
DEBUG - 2022-04-26 11:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:34:45 --> 404 Page Not Found: Adminlogin/index
DEBUG - 2022-04-26 11:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:34:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:34:46 --> 404 Page Not Found: Admin/login
DEBUG - 2022-04-26 11:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:35:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:35:14 --> 404 Page Not Found: Admin/login
DEBUG - 2022-04-26 11:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:35:25 --> Total execution time: 0.0275
DEBUG - 2022-04-26 11:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 11:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 11:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 11:36:16 --> 404 Page Not Found: Admi/index
DEBUG - 2022-04-26 11:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 11:36:16 --> Total execution time: 0.0754
DEBUG - 2022-04-26 13:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:35:14 --> Total execution time: 1.2851
DEBUG - 2022-04-26 13:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:35:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 13:35:27 --> 404 Page Not Found: User/index
DEBUG - 2022-04-26 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:35:39 --> Total execution time: 0.0301
DEBUG - 2022-04-26 13:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:35:42 --> No URI present. Default controller set.
DEBUG - 2022-04-26 13:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:05:54 --> Total execution time: 0.1862
DEBUG - 2022-04-26 13:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:05:57 --> Total execution time: 0.0297
DEBUG - 2022-04-26 13:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:07:24 --> Total execution time: 0.7740
DEBUG - 2022-04-26 13:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:07:32 --> Total execution time: 0.0273
DEBUG - 2022-04-26 13:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:22:31 --> Total execution time: 0.0277
DEBUG - 2022-04-26 13:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:22:32 --> Total execution time: 0.0297
DEBUG - 2022-04-26 13:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:52:37 --> Total execution time: 0.0289
DEBUG - 2022-04-26 13:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 13:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:22:39 --> Total execution time: 0.0832
DEBUG - 2022-04-26 13:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:23:03 --> Total execution time: 0.0601
DEBUG - 2022-04-26 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 13:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 13:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 19:23:08 --> Total execution time: 0.0322
DEBUG - 2022-04-26 15:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:30:21 --> Total execution time: 1.2853
DEBUG - 2022-04-26 15:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:38:09 --> Total execution time: 0.8909
DEBUG - 2022-04-26 15:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:10 --> 404 Page Not Found: Assets/frontend
DEBUG - 2022-04-26 15:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:38:13 --> Total execution time: 0.0312
DEBUG - 2022-04-26 15:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:14 --> 404 Page Not Found: Assets/frontend
DEBUG - 2022-04-26 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:08:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:08:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:38:41 --> Total execution time: 0.8172
DEBUG - 2022-04-26 15:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:42 --> 404 Page Not Found: Assets/frontend
DEBUG - 2022-04-26 15:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:43 --> UTF-8 Support Enabled
ERROR - 2022-04-26 15:08:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:08:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:08:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:38:59 --> Total execution time: 0.8262
DEBUG - 2022-04-26 15:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:09:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:09:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:09:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:42:27 --> Total execution time: 0.8211
DEBUG - 2022-04-26 15:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:12:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:12:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:12:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:12:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:12:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:12:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:12:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:12:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:12:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:43:22 --> Total execution time: 0.7781
DEBUG - 2022-04-26 15:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:13:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:14:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:14:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:14:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:14:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:14:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:45:07 --> Total execution time: 0.9419
DEBUG - 2022-04-26 15:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:46:31 --> Total execution time: 1.0392
DEBUG - 2022-04-26 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:16:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:16:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:16:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:16:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:16:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:16:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:16:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:16:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:16:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:50:08 --> Total execution time: 0.8822
DEBUG - 2022-04-26 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:20:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:20:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:20:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:20:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:20:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:20:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:20:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:20:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:20:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:52:14 --> Total execution time: 1.0393
DEBUG - 2022-04-26 15:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:22:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:22:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:22:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:22:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:22:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:22:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:22:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:22:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:53:37 --> Total execution time: 0.8242
DEBUG - 2022-04-26 15:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:23:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:23:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:23:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:23:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:23:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:23:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:23:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:23:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:53:59 --> Total execution time: 0.6322
DEBUG - 2022-04-26 15:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:54:19 --> Total execution time: 0.0289
DEBUG - 2022-04-26 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:24:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:55:12 --> Total execution time: 0.6342
DEBUG - 2022-04-26 15:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:25:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:25:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:25:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:25:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:25:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:25:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:25:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:25:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:57:12 --> Total execution time: 1.0192
DEBUG - 2022-04-26 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:27:14 --> UTF-8 Support Enabled
ERROR - 2022-04-26 15:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:27:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:27:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 20:57:16 --> Total execution time: 0.5798
DEBUG - 2022-04-26 15:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:00:24 --> Total execution time: 0.9802
DEBUG - 2022-04-26 15:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:30:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:30:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:30:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:30:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:30:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:30:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:30:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:30:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:02:09 --> Total execution time: 0.9301
DEBUG - 2022-04-26 15:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:32:12 --> UTF-8 Support Enabled
ERROR - 2022-04-26 15:32:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:32:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:32:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:32:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:32:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:04:40 --> Total execution time: 0.8442
DEBUG - 2022-04-26 15:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:05:04 --> Total execution time: 0.0297
DEBUG - 2022-04-26 15:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:05:37 --> Total execution time: 0.0485
DEBUG - 2022-04-26 15:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:05:42 --> Total execution time: 0.0301
DEBUG - 2022-04-26 15:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:06:17 --> Total execution time: 0.0439
DEBUG - 2022-04-26 15:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:36:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:36:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:36:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-26 15:36:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:36:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:36:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:36:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 15:36:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-26 15:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:07:23 --> Total execution time: 0.8451
DEBUG - 2022-04-26 15:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:07:38 --> Total execution time: 0.0367
DEBUG - 2022-04-26 15:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 15:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 15:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-26 21:07:41 --> Total execution time: 0.0310
