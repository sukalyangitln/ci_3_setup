<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-29 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:51:31 --> No URI present. Default controller set.
DEBUG - 2021-12-29 13:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:51:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-29 18:21:31 --> Severity: error --> Exception: Unable to locate the model you have specified: User_logins C:\xampp\htdocs\gopal\dishapradaanfoundation\system\core\Loader.php 348
DEBUG - 2021-12-29 13:52:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-29 13:52:17 --> 404 Page Not Found: User/index
DEBUG - 2021-12-29 13:52:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 13:52:23 --> Total execution time: 0.0729
DEBUG - 2021-12-29 13:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 13:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 13:52:26 --> Total execution time: 0.0487
DEBUG - 2021-12-29 13:52:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 13:52:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:22:57 --> Total execution time: 0.0513
DEBUG - 2021-12-29 13:53:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:23:19 --> Total execution time: 0.0561
DEBUG - 2021-12-29 13:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:23:25 --> Total execution time: 0.0558
DEBUG - 2021-12-29 14:00:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:30:53 --> Total execution time: 0.0764
DEBUG - 2021-12-29 14:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:30:56 --> Total execution time: 0.0507
DEBUG - 2021-12-29 14:00:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:30:59 --> Total execution time: 0.0648
DEBUG - 2021-12-29 14:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:31:08 --> Total execution time: 0.0585
DEBUG - 2021-12-29 14:01:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:31:16 --> Total execution time: 0.0849
DEBUG - 2021-12-29 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:31:21 --> Total execution time: 0.0508
DEBUG - 2021-12-29 14:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:32:01 --> Total execution time: 0.0547
DEBUG - 2021-12-29 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:32:34 --> Total execution time: 0.1013
DEBUG - 2021-12-29 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:03:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-29 14:03:54 --> 404 Page Not Found: Admin-payment-list/index
DEBUG - 2021-12-29 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:03:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-29 14:03:56 --> 404 Page Not Found: Admin-payment-list/index
DEBUG - 2021-12-29 14:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:34:01 --> Total execution time: 0.0929
DEBUG - 2021-12-29 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:37:23 --> Total execution time: 0.0791
DEBUG - 2021-12-29 14:07:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:37:51 --> Total execution time: 0.0515
DEBUG - 2021-12-29 14:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:38:51 --> Total execution time: 0.0497
DEBUG - 2021-12-29 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:39:57 --> Total execution time: 0.0811
DEBUG - 2021-12-29 14:10:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:40:24 --> Total execution time: 0.0787
DEBUG - 2021-12-29 14:10:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:40:38 --> Total execution time: 0.0566
DEBUG - 2021-12-29 14:10:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:40:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:10:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:40:43 --> Total execution time: 0.0509
DEBUG - 2021-12-29 14:10:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:40:45 --> Total execution time: 0.0506
DEBUG - 2021-12-29 14:10:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:10:50 --> No URI present. Default controller set.
DEBUG - 2021-12-29 14:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:10:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-29 18:40:50 --> Severity: error --> Exception: Unable to locate the model you have specified: User_logins C:\xampp\htdocs\gopal\dishapradaanfoundation\system\core\Loader.php 348
DEBUG - 2021-12-29 14:11:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:11:23 --> No URI present. Default controller set.
DEBUG - 2021-12-29 14:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:11:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-29 18:41:23 --> Severity: error --> Exception: Unable to locate the model you have specified: User_logins C:\xampp\htdocs\gopal\dishapradaanfoundation\system\core\Loader.php 348
DEBUG - 2021-12-29 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:11:30 --> No URI present. Default controller set.
DEBUG - 2021-12-29 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 14:12:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:12:06 --> No URI present. Default controller set.
DEBUG - 2021-12-29 14:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:42:06 --> Total execution time: 0.0671
DEBUG - 2021-12-29 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:13:28 --> No URI present. Default controller set.
DEBUG - 2021-12-29 14:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:13:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-29 18:43:28 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\dishapradaanfoundation\application\views\Front\index.php 4
ERROR - 2021-12-29 18:43:28 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\dishapradaanfoundation\application\views\Front\index.php 34
DEBUG - 2021-12-29 18:43:28 --> Total execution time: 0.0533
DEBUG - 2021-12-29 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:13:28 --> No URI present. Default controller set.
DEBUG - 2021-12-29 14:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:13:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-29 18:43:28 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\dishapradaanfoundation\application\views\Front\index.php 4
ERROR - 2021-12-29 18:43:28 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\dishapradaanfoundation\application\views\Front\index.php 34
DEBUG - 2021-12-29 18:43:28 --> Total execution time: 0.0507
DEBUG - 2021-12-29 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:14:26 --> No URI present. Default controller set.
DEBUG - 2021-12-29 14:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:44:26 --> Total execution time: 0.0510
DEBUG - 2021-12-29 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:14:26 --> No URI present. Default controller set.
DEBUG - 2021-12-29 14:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:44:26 --> Total execution time: 0.0637
DEBUG - 2021-12-29 14:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:48:18 --> Total execution time: 0.0725
DEBUG - 2021-12-29 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:48:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 18:48:54 --> You did not select a file to upload.
DEBUG - 2021-12-29 18:48:54 --> You did not select a file to upload.
DEBUG - 2021-12-29 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:48:54 --> Total execution time: 0.0530
DEBUG - 2021-12-29 18:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:02:06 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:32:06 --> Total execution time: 0.2309
DEBUG - 2021-12-29 18:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:02:06 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:32:06 --> Total execution time: 0.0492
DEBUG - 2021-12-29 18:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:02:11 --> Total execution time: 0.0661
DEBUG - 2021-12-29 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:32:15 --> Total execution time: 0.0534
DEBUG - 2021-12-29 18:05:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:05:50 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:35:50 --> Total execution time: 0.0674
DEBUG - 2021-12-29 18:05:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:05:50 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:35:50 --> Total execution time: 0.0526
DEBUG - 2021-12-29 18:05:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 18:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:35:58 --> Total execution time: 0.0469
DEBUG - 2021-12-29 18:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:10:00 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:40:00 --> Total execution time: 0.0738
DEBUG - 2021-12-29 18:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:10:00 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:40:00 --> Total execution time: 0.0623
DEBUG - 2021-12-29 18:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:11:28 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:41:28 --> Total execution time: 0.0561
DEBUG - 2021-12-29 18:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:11:28 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:41:28 --> Total execution time: 0.0706
DEBUG - 2021-12-29 18:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:11:31 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:41:31 --> Total execution time: 0.0454
DEBUG - 2021-12-29 18:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:11:31 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:41:31 --> Total execution time: 0.0669
DEBUG - 2021-12-29 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:11:38 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:41:38 --> Total execution time: 0.0457
DEBUG - 2021-12-29 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:11:38 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:41:38 --> Total execution time: 0.0541
DEBUG - 2021-12-29 18:12:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:12:34 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:42:35 --> Total execution time: 0.0542
DEBUG - 2021-12-29 18:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:12:35 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:42:35 --> Total execution time: 0.0551
DEBUG - 2021-12-29 18:13:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:13:00 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:43:00 --> Total execution time: 0.0486
DEBUG - 2021-12-29 18:13:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:13:00 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:43:00 --> Total execution time: 0.0603
DEBUG - 2021-12-29 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:43:40 --> Total execution time: 0.0679
DEBUG - 2021-12-29 18:13:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:43:43 --> Total execution time: 0.0504
DEBUG - 2021-12-29 18:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:14:53 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:44:53 --> Total execution time: 0.0555
DEBUG - 2021-12-29 18:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:14:53 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:44:53 --> Total execution time: 0.0664
DEBUG - 2021-12-29 18:16:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:16:47 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:46:47 --> Total execution time: 0.6116
DEBUG - 2021-12-29 18:17:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:17:12 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:47:12 --> Total execution time: 0.0491
DEBUG - 2021-12-29 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:17:55 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:47:55 --> Total execution time: 0.0484
DEBUG - 2021-12-29 18:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:18:06 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:48:06 --> Total execution time: 0.0756
DEBUG - 2021-12-29 18:18:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:18:13 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:48:13 --> Total execution time: 0.0732
DEBUG - 2021-12-29 18:18:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:18:27 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:48:27 --> Total execution time: 0.0554
DEBUG - 2021-12-29 18:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:18:37 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:48:37 --> Total execution time: 0.0761
DEBUG - 2021-12-29 18:18:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:18:44 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:48:44 --> Total execution time: 0.0678
DEBUG - 2021-12-29 18:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:20:07 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:50:07 --> Total execution time: 0.0476
DEBUG - 2021-12-29 18:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:20:35 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:50:35 --> Total execution time: 0.1006
DEBUG - 2021-12-29 18:20:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:20:47 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:50:47 --> Total execution time: 0.0764
DEBUG - 2021-12-29 18:21:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:21:02 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:51:02 --> Total execution time: 0.0469
DEBUG - 2021-12-29 18:21:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:21:21 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:51:21 --> Total execution time: 0.0532
DEBUG - 2021-12-29 18:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:21:36 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:51:36 --> Total execution time: 0.0732
DEBUG - 2021-12-29 18:21:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:21:41 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:51:41 --> Total execution time: 0.0643
DEBUG - 2021-12-29 18:21:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:21:48 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:51:48 --> Total execution time: 0.0590
DEBUG - 2021-12-29 18:21:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:21:56 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:51:57 --> Total execution time: 0.1076
DEBUG - 2021-12-29 18:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:22:06 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:52:06 --> Total execution time: 0.0693
DEBUG - 2021-12-29 18:22:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:22:29 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:52:29 --> Total execution time: 0.0777
DEBUG - 2021-12-29 18:22:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:22:48 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:52:48 --> Total execution time: 0.0646
DEBUG - 2021-12-29 18:23:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:23:44 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:53:44 --> Total execution time: 0.0706
DEBUG - 2021-12-29 18:23:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:23:56 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:53:56 --> Total execution time: 0.0670
DEBUG - 2021-12-29 18:24:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:24:16 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:54:16 --> Total execution time: 0.0675
DEBUG - 2021-12-29 18:24:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:24:59 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:54:59 --> Total execution time: 0.0500
DEBUG - 2021-12-29 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:27:13 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:57:13 --> Total execution time: 0.0524
DEBUG - 2021-12-29 18:27:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:27:37 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:57:37 --> Total execution time: 0.0648
DEBUG - 2021-12-29 18:28:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:28:04 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:58:04 --> Total execution time: 0.0498
DEBUG - 2021-12-29 18:28:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:28:13 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:58:13 --> Total execution time: 0.0583
DEBUG - 2021-12-29 18:28:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:28:22 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:58:22 --> Total execution time: 0.0768
DEBUG - 2021-12-29 18:29:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:29:09 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 22:59:09 --> Total execution time: 0.0847
DEBUG - 2021-12-29 18:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:30:41 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:00:41 --> Total execution time: 0.0482
DEBUG - 2021-12-29 18:31:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:31:04 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:01:04 --> Total execution time: 0.0733
DEBUG - 2021-12-29 18:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:33:42 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:03:43 --> Total execution time: 0.0660
DEBUG - 2021-12-29 18:44:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:44:24 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:14:24 --> Total execution time: 0.0558
DEBUG - 2021-12-29 18:53:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:53:56 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:23:56 --> Total execution time: 0.0603
DEBUG - 2021-12-29 18:54:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:54:43 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:24:43 --> Total execution time: 0.0509
DEBUG - 2021-12-29 18:54:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:24:58 --> Total execution time: 0.1315
DEBUG - 2021-12-29 18:55:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:25:00 --> Total execution time: 0.0531
DEBUG - 2021-12-29 18:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:55:38 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:25:39 --> Total execution time: 0.0495
DEBUG - 2021-12-29 18:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:56:43 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:26:43 --> Total execution time: 0.0519
DEBUG - 2021-12-29 18:57:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:57:12 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:27:12 --> Total execution time: 0.0731
DEBUG - 2021-12-29 18:57:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:57:39 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:27:39 --> Total execution time: 0.0728
DEBUG - 2021-12-29 18:57:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:57:54 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:27:54 --> Total execution time: 0.0497
DEBUG - 2021-12-29 18:58:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:58:16 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:28:16 --> Total execution time: 0.0808
DEBUG - 2021-12-29 18:58:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:58:33 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:28:33 --> Total execution time: 0.0486
DEBUG - 2021-12-29 18:59:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:59:05 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:29:05 --> Total execution time: 0.0613
DEBUG - 2021-12-29 18:59:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 18:59:15 --> No URI present. Default controller set.
DEBUG - 2021-12-29 18:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 18:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:29:15 --> Total execution time: 0.0589
DEBUG - 2021-12-29 19:01:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 19:01:21 --> No URI present. Default controller set.
DEBUG - 2021-12-29 19:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 19:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:31:21 --> Total execution time: 0.0672
DEBUG - 2021-12-29 19:01:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 19:01:33 --> No URI present. Default controller set.
DEBUG - 2021-12-29 19:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 19:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:31:34 --> Total execution time: 0.0633
DEBUG - 2021-12-29 19:01:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 19:01:39 --> No URI present. Default controller set.
DEBUG - 2021-12-29 19:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 19:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:31:39 --> Total execution time: 0.0844
DEBUG - 2021-12-29 19:01:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 19:01:58 --> No URI present. Default controller set.
DEBUG - 2021-12-29 19:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 19:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:31:58 --> Total execution time: 0.0710
DEBUG - 2021-12-29 19:02:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 19:02:02 --> No URI present. Default controller set.
DEBUG - 2021-12-29 19:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 19:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:32:02 --> Total execution time: 0.0850
DEBUG - 2021-12-29 19:07:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 19:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 19:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-29 23:37:26 --> Total execution time: 0.0930
