<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-24 11:11:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-24 11:11:54 --> No URI present. Default controller set.
DEBUG - 2023-01-24 11:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-24 11:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-24 11:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-24 15:41:54 --> Total execution time: 0.0763
DEBUG - 2023-01-24 11:11:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-24 11:11:55 --> No URI present. Default controller set.
DEBUG - 2023-01-24 11:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-24 11:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-24 11:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-24 15:41:55 --> Total execution time: 0.0462
DEBUG - 2023-01-24 11:11:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-24 11:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-24 11:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-24 11:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-24 15:41:58 --> Total execution time: 0.0677
DEBUG - 2023-01-24 11:12:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-24 11:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-24 11:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-24 11:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-24 15:42:34 --> Total execution time: 0.0510
DEBUG - 2023-01-24 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-24 11:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-24 11:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-24 11:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-24 15:42:36 --> Total execution time: 0.0406
DEBUG - 2023-01-24 11:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-24 11:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-24 11:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-24 11:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-24 15:42:41 --> Total execution time: 0.0557
DEBUG - 2023-01-24 11:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-24 11:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-24 11:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-24 11:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-24 16:09:40 --> Total execution time: 0.7936
