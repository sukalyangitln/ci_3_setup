<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-05 00:04:01 --> Total execution time: 0.1277
DEBUG - 2022-07-05 00:09:09 --> Total execution time: 0.1051
DEBUG - 2022-07-05 00:09:15 --> Total execution time: 0.0581
DEBUG - 2022-07-05 00:09:18 --> Total execution time: 0.0734
DEBUG - 2022-07-05 00:09:22 --> Total execution time: 0.0798
DEBUG - 2022-07-05 00:09:24 --> Total execution time: 0.0536
DEBUG - 2022-07-05 00:12:36 --> Total execution time: 0.0840
DEBUG - 2022-07-05 00:12:37 --> Total execution time: 0.0470
DEBUG - 2022-07-05 00:18:40 --> Total execution time: 0.0957
DEBUG - 2022-07-05 00:25:05 --> Total execution time: 0.1834
DEBUG - 2022-07-05 00:30:02 --> Total execution time: 0.1443
DEBUG - 2022-07-05 00:40:31 --> Total execution time: 0.1450
DEBUG - 2022-07-05 00:40:44 --> Total execution time: 0.0523
DEBUG - 2022-07-05 00:41:09 --> Total execution time: 0.0503
DEBUG - 2022-07-05 00:41:48 --> Total execution time: 0.0605
DEBUG - 2022-07-05 00:42:08 --> Total execution time: 0.0561
DEBUG - 2022-07-05 00:42:19 --> Total execution time: 0.0537
DEBUG - 2022-07-05 00:57:14 --> Total execution time: 0.2109
DEBUG - 2022-07-05 01:09:38 --> Total execution time: 0.0983
DEBUG - 2022-07-05 01:09:44 --> Total execution time: 0.0374
DEBUG - 2022-07-05 01:10:05 --> Total execution time: 0.0706
DEBUG - 2022-07-05 01:11:16 --> Total execution time: 0.0562
DEBUG - 2022-07-05 01:11:23 --> Total execution time: 0.0515
DEBUG - 2022-07-05 01:11:35 --> Total execution time: 0.0566
DEBUG - 2022-07-05 01:11:44 --> Total execution time: 0.0685
DEBUG - 2022-07-05 01:12:43 --> Total execution time: 0.0721
DEBUG - 2022-07-05 01:12:51 --> Total execution time: 0.0583
DEBUG - 2022-07-05 01:12:59 --> Total execution time: 0.0633
DEBUG - 2022-07-05 01:14:21 --> Total execution time: 0.0672
DEBUG - 2022-07-05 01:14:44 --> Total execution time: 0.0849
DEBUG - 2022-07-05 01:18:45 --> Total execution time: 0.2143
DEBUG - 2022-07-05 01:20:56 --> Total execution time: 0.0826
DEBUG - 2022-07-05 01:26:28 --> Total execution time: 0.0761
DEBUG - 2022-07-05 01:26:30 --> Total execution time: 0.0359
DEBUG - 2022-07-05 01:30:02 --> Total execution time: 0.1382
DEBUG - 2022-07-05 02:00:14 --> Total execution time: 0.1334
DEBUG - 2022-07-05 02:00:14 --> Total execution time: 0.0299
DEBUG - 2022-07-05 02:05:44 --> Total execution time: 0.0970
DEBUG - 2022-07-05 02:16:22 --> Total execution time: 0.1093
DEBUG - 2022-07-05 02:16:27 --> Total execution time: 0.0535
DEBUG - 2022-07-05 02:16:44 --> Total execution time: 0.0466
DEBUG - 2022-07-05 02:17:04 --> Total execution time: 0.0621
DEBUG - 2022-07-05 02:17:09 --> Total execution time: 0.0837
DEBUG - 2022-07-05 02:17:11 --> Total execution time: 0.0905
DEBUG - 2022-07-05 02:25:29 --> Total execution time: 0.0825
DEBUG - 2022-07-05 02:25:31 --> Total execution time: 0.0505
DEBUG - 2022-07-05 02:30:03 --> Total execution time: 0.1298
DEBUG - 2022-07-05 03:01:28 --> Total execution time: 0.2397
DEBUG - 2022-07-05 03:01:36 --> Total execution time: 0.1891
DEBUG - 2022-07-05 03:01:48 --> Total execution time: 0.0740
DEBUG - 2022-07-05 03:02:44 --> Total execution time: 0.0493
DEBUG - 2022-07-05 03:02:50 --> Total execution time: 0.0543
DEBUG - 2022-07-05 03:03:05 --> Total execution time: 0.0644
DEBUG - 2022-07-05 03:03:14 --> Total execution time: 0.0583
DEBUG - 2022-07-05 03:03:20 --> Total execution time: 0.0517
DEBUG - 2022-07-05 03:09:40 --> Total execution time: 0.0450
DEBUG - 2022-07-05 03:11:32 --> Total execution time: 0.0613
DEBUG - 2022-07-05 03:18:22 --> Total execution time: 0.1335
DEBUG - 2022-07-05 03:30:03 --> Total execution time: 0.1581
DEBUG - 2022-07-05 03:33:31 --> Total execution time: 0.0915
DEBUG - 2022-07-05 03:33:37 --> Total execution time: 0.0354
DEBUG - 2022-07-05 03:44:33 --> Total execution time: 0.1098
DEBUG - 2022-07-05 03:44:34 --> Total execution time: 0.0343
DEBUG - 2022-07-05 03:57:32 --> Total execution time: 0.0903
DEBUG - 2022-07-05 03:57:32 --> Total execution time: 0.0369
DEBUG - 2022-07-05 04:06:36 --> Total execution time: 0.0964
DEBUG - 2022-07-05 04:06:37 --> Total execution time: 0.0345
DEBUG - 2022-07-05 04:14:09 --> Total execution time: 0.1039
DEBUG - 2022-07-05 04:14:11 --> Total execution time: 0.0458
DEBUG - 2022-07-05 04:15:11 --> Total execution time: 0.0357
DEBUG - 2022-07-05 04:15:13 --> Total execution time: 0.0378
DEBUG - 2022-07-05 04:30:03 --> Total execution time: 0.1014
DEBUG - 2022-07-05 04:30:42 --> Total execution time: 0.0428
DEBUG - 2022-07-05 04:34:06 --> Total execution time: 0.0854
DEBUG - 2022-07-05 04:34:18 --> Total execution time: 0.0545
DEBUG - 2022-07-05 04:34:22 --> Total execution time: 0.0750
DEBUG - 2022-07-05 04:39:58 --> Total execution time: 0.0798
DEBUG - 2022-07-05 04:40:00 --> Total execution time: 0.0533
DEBUG - 2022-07-05 05:30:02 --> Total execution time: 0.2397
DEBUG - 2022-07-05 05:52:33 --> Total execution time: 0.1294
DEBUG - 2022-07-05 05:52:35 --> Total execution time: 0.0357
DEBUG - 2022-07-05 05:53:04 --> Total execution time: 0.0497
DEBUG - 2022-07-05 05:54:09 --> Total execution time: 0.0384
DEBUG - 2022-07-05 05:55:06 --> Total execution time: 0.0363
DEBUG - 2022-07-05 06:02:44 --> Total execution time: 0.1128
DEBUG - 2022-07-05 06:12:27 --> Total execution time: 0.1391
DEBUG - 2022-07-05 06:13:13 --> Total execution time: 0.0531
DEBUG - 2022-07-05 06:23:18 --> Total execution time: 0.0912
DEBUG - 2022-07-05 06:26:44 --> Total execution time: 0.0530
DEBUG - 2022-07-05 06:26:49 --> Total execution time: 0.0779
DEBUG - 2022-07-05 06:26:54 --> Total execution time: 0.0994
DEBUG - 2022-07-05 06:27:07 --> Total execution time: 0.0862
DEBUG - 2022-07-05 06:27:21 --> Total execution time: 0.0785
DEBUG - 2022-07-05 06:30:02 --> Total execution time: 0.0904
DEBUG - 2022-07-05 06:30:24 --> Total execution time: 0.0386
DEBUG - 2022-07-05 06:31:18 --> Total execution time: 0.0343
DEBUG - 2022-07-05 06:53:23 --> Total execution time: 0.1726
DEBUG - 2022-07-05 06:53:24 --> Total execution time: 0.0508
DEBUG - 2022-07-05 07:29:34 --> Total execution time: 0.0673
DEBUG - 2022-07-05 07:30:02 --> Total execution time: 0.1437
DEBUG - 2022-07-05 07:30:02 --> Total execution time: 0.1061
DEBUG - 2022-07-05 07:30:19 --> Total execution time: 0.0537
DEBUG - 2022-07-05 07:30:40 --> Total execution time: 0.0742
DEBUG - 2022-07-05 07:30:42 --> Total execution time: 0.0672
DEBUG - 2022-07-05 07:30:49 --> Total execution time: 0.0774
DEBUG - 2022-07-05 07:30:57 --> Total execution time: 0.0799
DEBUG - 2022-07-05 07:31:16 --> Total execution time: 0.0569
DEBUG - 2022-07-05 07:31:52 --> Total execution time: 0.0562
DEBUG - 2022-07-05 07:32:26 --> Total execution time: 0.0419
DEBUG - 2022-07-05 07:34:13 --> Total execution time: 0.0498
DEBUG - 2022-07-05 07:35:03 --> Total execution time: 0.1526
DEBUG - 2022-07-05 07:35:19 --> Total execution time: 0.0479
DEBUG - 2022-07-05 07:42:04 --> Total execution time: 0.1248
DEBUG - 2022-07-05 07:43:41 --> Total execution time: 0.0449
DEBUG - 2022-07-05 07:43:42 --> Total execution time: 0.0368
DEBUG - 2022-07-05 07:44:04 --> Total execution time: 0.0388
DEBUG - 2022-07-05 07:44:45 --> Total execution time: 0.0354
DEBUG - 2022-07-05 07:45:32 --> Total execution time: 0.0710
DEBUG - 2022-07-05 07:45:45 --> Total execution time: 0.0472
DEBUG - 2022-07-05 07:46:03 --> Total execution time: 0.0841
DEBUG - 2022-07-05 07:46:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 07:46:04 --> Total execution time: 0.0937
DEBUG - 2022-07-05 07:46:48 --> Total execution time: 0.0839
DEBUG - 2022-07-05 07:47:23 --> Total execution time: 0.0800
DEBUG - 2022-07-05 07:47:47 --> Total execution time: 0.1281
DEBUG - 2022-07-05 07:48:04 --> Total execution time: 0.0590
DEBUG - 2022-07-05 07:48:12 --> Total execution time: 0.0830
DEBUG - 2022-07-05 07:48:22 --> Total execution time: 0.0638
DEBUG - 2022-07-05 07:48:33 --> Total execution time: 0.1137
DEBUG - 2022-07-05 07:49:17 --> Total execution time: 0.0516
DEBUG - 2022-07-05 07:50:08 --> Total execution time: 1.7736
DEBUG - 2022-07-05 07:50:47 --> Total execution time: 1.5396
DEBUG - 2022-07-05 07:51:06 --> Total execution time: 1.5928
DEBUG - 2022-07-05 07:52:01 --> Total execution time: 1.5224
DEBUG - 2022-07-05 07:57:33 --> Total execution time: 1.7059
DEBUG - 2022-07-05 07:58:33 --> Total execution time: 0.0482
DEBUG - 2022-07-05 07:58:37 --> Total execution time: 0.0378
DEBUG - 2022-07-05 07:58:40 --> Total execution time: 1.5755
DEBUG - 2022-07-05 07:58:44 --> Total execution time: 0.0625
DEBUG - 2022-07-05 07:58:48 --> Total execution time: 0.1459
DEBUG - 2022-07-05 07:58:53 --> Total execution time: 0.0612
DEBUG - 2022-07-05 07:58:53 --> Total execution time: 0.0593
DEBUG - 2022-07-05 07:59:07 --> Total execution time: 0.0549
DEBUG - 2022-07-05 07:59:09 --> Total execution time: 0.0473
DEBUG - 2022-07-05 07:59:14 --> Total execution time: 0.0535
DEBUG - 2022-07-05 07:59:26 --> Total execution time: 0.0570
DEBUG - 2022-07-05 07:59:33 --> Total execution time: 0.0493
DEBUG - 2022-07-05 07:59:46 --> Total execution time: 0.0519
DEBUG - 2022-07-05 08:01:12 --> Total execution time: 0.0405
DEBUG - 2022-07-05 08:02:15 --> Total execution time: 0.0592
DEBUG - 2022-07-05 08:02:35 --> Total execution time: 0.0580
DEBUG - 2022-07-05 08:02:49 --> Total execution time: 0.0579
DEBUG - 2022-07-05 08:02:59 --> Total execution time: 0.0537
DEBUG - 2022-07-05 08:03:08 --> Total execution time: 0.0612
DEBUG - 2022-07-05 08:03:15 --> Total execution time: 0.0784
DEBUG - 2022-07-05 08:03:23 --> Total execution time: 0.0549
DEBUG - 2022-07-05 08:03:23 --> Total execution time: 0.0517
DEBUG - 2022-07-05 08:03:33 --> Total execution time: 0.0840
DEBUG - 2022-07-05 08:03:40 --> Total execution time: 0.0544
DEBUG - 2022-07-05 08:03:47 --> Total execution time: 0.0461
DEBUG - 2022-07-05 08:03:48 --> Total execution time: 0.0477
DEBUG - 2022-07-05 08:03:54 --> Total execution time: 0.0486
DEBUG - 2022-07-05 08:03:58 --> Total execution time: 0.0588
DEBUG - 2022-07-05 08:04:02 --> Total execution time: 0.0938
DEBUG - 2022-07-05 08:04:05 --> Total execution time: 0.0577
DEBUG - 2022-07-05 08:04:16 --> Total execution time: 0.0495
DEBUG - 2022-07-05 08:04:18 --> Total execution time: 0.0602
DEBUG - 2022-07-05 08:04:18 --> Total execution time: 0.0346
DEBUG - 2022-07-05 08:04:27 --> Total execution time: 0.0717
DEBUG - 2022-07-05 08:07:36 --> Total execution time: 0.1136
DEBUG - 2022-07-05 08:07:36 --> Total execution time: 0.0388
DEBUG - 2022-07-05 08:07:49 --> Total execution time: 0.0500
DEBUG - 2022-07-05 08:08:15 --> Total execution time: 0.0576
DEBUG - 2022-07-05 08:08:20 --> Total execution time: 0.0584
DEBUG - 2022-07-05 08:08:23 --> Total execution time: 0.0646
DEBUG - 2022-07-05 08:08:35 --> Total execution time: 0.0502
DEBUG - 2022-07-05 08:09:40 --> Total execution time: 0.0436
DEBUG - 2022-07-05 08:11:50 --> Total execution time: 0.1887
DEBUG - 2022-07-05 08:11:55 --> Total execution time: 0.0452
DEBUG - 2022-07-05 08:14:08 --> Total execution time: 0.0496
DEBUG - 2022-07-05 08:14:24 --> Total execution time: 0.0479
DEBUG - 2022-07-05 08:14:36 --> Total execution time: 0.0473
DEBUG - 2022-07-05 08:14:43 --> Total execution time: 0.0537
DEBUG - 2022-07-05 08:15:57 --> Total execution time: 0.0549
DEBUG - 2022-07-05 08:16:05 --> Total execution time: 0.0656
DEBUG - 2022-07-05 08:19:43 --> Total execution time: 0.0783
DEBUG - 2022-07-05 08:19:59 --> Total execution time: 0.0330
DEBUG - 2022-07-05 08:20:05 --> Total execution time: 0.0642
DEBUG - 2022-07-05 08:20:13 --> Total execution time: 0.1335
DEBUG - 2022-07-05 08:20:37 --> Total execution time: 0.0776
DEBUG - 2022-07-05 08:20:43 --> Total execution time: 0.0766
DEBUG - 2022-07-05 08:24:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 08:24:25 --> Total execution time: 0.0831
DEBUG - 2022-07-05 08:24:33 --> Total execution time: 0.0839
DEBUG - 2022-07-05 08:25:09 --> Total execution time: 0.1493
DEBUG - 2022-07-05 08:25:13 --> Total execution time: 0.0804
DEBUG - 2022-07-05 08:30:02 --> Total execution time: 0.1137
DEBUG - 2022-07-05 08:36:07 --> Total execution time: 0.0675
DEBUG - 2022-07-05 08:38:09 --> Total execution time: 0.1527
DEBUG - 2022-07-05 08:40:01 --> Total execution time: 0.0623
DEBUG - 2022-07-05 08:40:59 --> Total execution time: 0.0443
DEBUG - 2022-07-05 08:41:27 --> Total execution time: 0.0587
DEBUG - 2022-07-05 08:41:32 --> Total execution time: 0.0655
DEBUG - 2022-07-05 08:41:35 --> Total execution time: 0.0777
DEBUG - 2022-07-05 08:44:45 --> Total execution time: 0.0477
DEBUG - 2022-07-05 08:45:22 --> Total execution time: 0.0521
DEBUG - 2022-07-05 08:45:29 --> Total execution time: 0.0567
DEBUG - 2022-07-05 08:45:34 --> Total execution time: 0.0467
DEBUG - 2022-07-05 08:45:36 --> Total execution time: 0.0476
DEBUG - 2022-07-05 08:45:40 --> Total execution time: 0.0497
DEBUG - 2022-07-05 08:45:41 --> Total execution time: 0.0467
DEBUG - 2022-07-05 08:45:56 --> Total execution time: 0.0388
DEBUG - 2022-07-05 08:45:57 --> Total execution time: 0.0362
DEBUG - 2022-07-05 08:46:03 --> Total execution time: 0.0570
DEBUG - 2022-07-05 08:46:07 --> Total execution time: 0.0594
DEBUG - 2022-07-05 08:46:16 --> Total execution time: 0.0510
DEBUG - 2022-07-05 08:46:18 --> Total execution time: 0.0790
DEBUG - 2022-07-05 08:46:24 --> Total execution time: 0.0834
DEBUG - 2022-07-05 08:46:28 --> Total execution time: 0.0532
DEBUG - 2022-07-05 08:46:33 --> Total execution time: 0.0701
DEBUG - 2022-07-05 08:46:35 --> Total execution time: 0.0642
DEBUG - 2022-07-05 08:46:37 --> Total execution time: 0.0491
DEBUG - 2022-07-05 08:46:44 --> Total execution time: 0.0542
DEBUG - 2022-07-05 08:49:02 --> Total execution time: 0.0534
DEBUG - 2022-07-05 08:52:18 --> Total execution time: 0.0559
DEBUG - 2022-07-05 08:52:30 --> Total execution time: 0.0566
DEBUG - 2022-07-05 08:52:47 --> Total execution time: 0.0839
DEBUG - 2022-07-05 08:55:14 --> Total execution time: 0.0409
DEBUG - 2022-07-05 08:55:18 --> Total execution time: 0.0517
DEBUG - 2022-07-05 08:55:29 --> Total execution time: 0.0473
DEBUG - 2022-07-05 08:55:40 --> Total execution time: 0.0735
DEBUG - 2022-07-05 08:57:42 --> Total execution time: 0.0456
DEBUG - 2022-07-05 09:03:37 --> Total execution time: 0.1667
DEBUG - 2022-07-05 09:03:42 --> Total execution time: 0.1238
DEBUG - 2022-07-05 09:05:23 --> Total execution time: 0.0347
DEBUG - 2022-07-05 09:06:13 --> Total execution time: 0.0418
DEBUG - 2022-07-05 09:06:14 --> Total execution time: 0.0290
DEBUG - 2022-07-05 09:06:23 --> Total execution time: 0.0469
DEBUG - 2022-07-05 09:06:25 --> Total execution time: 0.0545
DEBUG - 2022-07-05 09:06:35 --> Total execution time: 0.0510
DEBUG - 2022-07-05 09:06:35 --> Total execution time: 0.0321
DEBUG - 2022-07-05 09:06:37 --> Total execution time: 0.0541
DEBUG - 2022-07-05 09:07:00 --> Total execution time: 0.0566
DEBUG - 2022-07-05 09:07:05 --> Total execution time: 0.0766
DEBUG - 2022-07-05 09:07:05 --> Total execution time: 0.0592
DEBUG - 2022-07-05 09:07:10 --> Total execution time: 0.1074
DEBUG - 2022-07-05 09:07:18 --> Total execution time: 0.0743
DEBUG - 2022-07-05 09:07:21 --> Total execution time: 0.0578
DEBUG - 2022-07-05 09:07:30 --> Total execution time: 0.0577
DEBUG - 2022-07-05 09:07:52 --> Total execution time: 0.0567
DEBUG - 2022-07-05 09:07:53 --> Total execution time: 0.0440
DEBUG - 2022-07-05 09:13:01 --> Total execution time: 0.0680
DEBUG - 2022-07-05 09:13:05 --> Total execution time: 0.0525
DEBUG - 2022-07-05 09:13:15 --> Total execution time: 0.0486
DEBUG - 2022-07-05 09:13:21 --> Total execution time: 0.0601
DEBUG - 2022-07-05 09:13:26 --> Total execution time: 0.0734
DEBUG - 2022-07-05 09:14:13 --> Total execution time: 0.0768
DEBUG - 2022-07-05 09:14:15 --> Total execution time: 0.0573
DEBUG - 2022-07-05 09:14:43 --> Total execution time: 0.0683
DEBUG - 2022-07-05 09:15:13 --> Total execution time: 0.0893
DEBUG - 2022-07-05 09:15:18 --> Total execution time: 0.0534
DEBUG - 2022-07-05 09:15:52 --> Total execution time: 0.0806
DEBUG - 2022-07-05 09:15:56 --> Total execution time: 0.0350
DEBUG - 2022-07-05 09:16:02 --> Total execution time: 0.2242
DEBUG - 2022-07-05 09:16:34 --> Total execution time: 0.0574
DEBUG - 2022-07-05 09:16:56 --> Total execution time: 0.0593
DEBUG - 2022-07-05 09:17:17 --> Total execution time: 0.0668
DEBUG - 2022-07-05 09:17:25 --> Total execution time: 0.0621
DEBUG - 2022-07-05 09:17:36 --> Total execution time: 0.0862
DEBUG - 2022-07-05 09:17:37 --> Total execution time: 0.0518
DEBUG - 2022-07-05 09:17:44 --> Total execution time: 0.0568
DEBUG - 2022-07-05 09:19:44 --> Total execution time: 0.0590
DEBUG - 2022-07-05 09:20:33 --> Total execution time: 0.0588
DEBUG - 2022-07-05 09:21:33 --> Total execution time: 0.1286
DEBUG - 2022-07-05 09:23:50 --> Total execution time: 0.0436
DEBUG - 2022-07-05 09:25:30 --> Total execution time: 0.1080
DEBUG - 2022-07-05 09:26:14 --> Total execution time: 0.0693
DEBUG - 2022-07-05 09:26:55 --> Total execution time: 0.1324
DEBUG - 2022-07-05 09:26:58 --> Total execution time: 0.0948
DEBUG - 2022-07-05 09:27:26 --> Total execution time: 0.0771
DEBUG - 2022-07-05 09:28:03 --> Total execution time: 0.0647
DEBUG - 2022-07-05 09:29:08 --> Total execution time: 0.0433
DEBUG - 2022-07-05 09:30:02 --> Total execution time: 0.0792
DEBUG - 2022-07-05 09:30:04 --> Total execution time: 0.0873
DEBUG - 2022-07-05 09:30:11 --> Total execution time: 0.1714
DEBUG - 2022-07-05 09:30:34 --> Total execution time: 0.0403
DEBUG - 2022-07-05 09:31:29 --> Total execution time: 0.0483
DEBUG - 2022-07-05 09:32:03 --> Total execution time: 0.0655
DEBUG - 2022-07-05 09:32:06 --> Total execution time: 1.5196
DEBUG - 2022-07-05 09:32:49 --> Total execution time: 0.1897
DEBUG - 2022-07-05 09:32:52 --> Total execution time: 0.0435
DEBUG - 2022-07-05 09:32:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:32:55 --> Total execution time: 0.0658
DEBUG - 2022-07-05 09:32:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:32:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:32:56 --> Total execution time: 0.2159
DEBUG - 2022-07-05 09:33:10 --> Total execution time: 0.0523
DEBUG - 2022-07-05 09:33:19 --> Total execution time: 0.0643
DEBUG - 2022-07-05 09:33:20 --> Total execution time: 0.0522
DEBUG - 2022-07-05 09:33:32 --> Total execution time: 0.0692
DEBUG - 2022-07-05 09:33:34 --> Total execution time: 0.0674
DEBUG - 2022-07-05 09:33:42 --> Total execution time: 0.0727
DEBUG - 2022-07-05 09:34:09 --> Total execution time: 0.0617
DEBUG - 2022-07-05 09:34:14 --> Total execution time: 0.0769
DEBUG - 2022-07-05 09:34:18 --> Total execution time: 0.0560
DEBUG - 2022-07-05 09:34:19 --> Total execution time: 0.0643
DEBUG - 2022-07-05 09:34:24 --> Total execution time: 0.0810
DEBUG - 2022-07-05 09:34:30 --> Total execution time: 0.0542
DEBUG - 2022-07-05 09:34:37 --> Total execution time: 0.0764
DEBUG - 2022-07-05 09:34:42 --> Total execution time: 0.1400
DEBUG - 2022-07-05 09:34:51 --> Total execution time: 0.1068
DEBUG - 2022-07-05 09:34:51 --> Total execution time: 0.1088
DEBUG - 2022-07-05 09:35:06 --> Total execution time: 0.1078
DEBUG - 2022-07-05 09:35:13 --> Total execution time: 0.1430
DEBUG - 2022-07-05 09:35:24 --> Total execution time: 0.0905
DEBUG - 2022-07-05 09:35:27 --> Total execution time: 0.0747
DEBUG - 2022-07-05 09:35:30 --> Total execution time: 0.0476
DEBUG - 2022-07-05 09:36:26 --> Total execution time: 0.0380
DEBUG - 2022-07-05 09:38:12 --> Total execution time: 0.0602
DEBUG - 2022-07-05 09:40:19 --> Total execution time: 0.0653
DEBUG - 2022-07-05 09:41:23 --> Total execution time: 0.0383
DEBUG - 2022-07-05 09:41:33 --> Total execution time: 0.0600
DEBUG - 2022-07-05 09:41:48 --> Total execution time: 0.0494
DEBUG - 2022-07-05 09:42:06 --> Total execution time: 0.0550
DEBUG - 2022-07-05 09:42:26 --> Total execution time: 0.0582
DEBUG - 2022-07-05 09:42:34 --> Total execution time: 0.0532
DEBUG - 2022-07-05 09:42:54 --> Total execution time: 0.0814
DEBUG - 2022-07-05 09:42:54 --> Total execution time: 0.0937
DEBUG - 2022-07-05 09:43:02 --> Total execution time: 0.0583
DEBUG - 2022-07-05 09:43:03 --> Total execution time: 0.0614
DEBUG - 2022-07-05 09:43:04 --> Total execution time: 0.0589
DEBUG - 2022-07-05 09:43:05 --> Total execution time: 0.0623
DEBUG - 2022-07-05 09:43:15 --> Total execution time: 0.0926
DEBUG - 2022-07-05 09:43:46 --> Total execution time: 0.0700
DEBUG - 2022-07-05 09:45:06 --> Total execution time: 0.0371
DEBUG - 2022-07-05 09:45:52 --> Total execution time: 0.0512
DEBUG - 2022-07-05 09:46:46 --> Total execution time: 0.1293
DEBUG - 2022-07-05 09:46:52 --> Total execution time: 0.0591
DEBUG - 2022-07-05 09:49:21 --> Total execution time: 0.1749
DEBUG - 2022-07-05 09:50:03 --> Total execution time: 0.0505
DEBUG - 2022-07-05 09:52:01 --> Total execution time: 0.2970
DEBUG - 2022-07-05 09:52:14 --> Total execution time: 0.0734
DEBUG - 2022-07-05 09:52:46 --> Total execution time: 0.0467
DEBUG - 2022-07-05 09:54:20 --> Total execution time: 0.0497
DEBUG - 2022-07-05 09:55:07 --> Total execution time: 0.0505
DEBUG - 2022-07-05 10:06:40 --> Total execution time: 0.0584
DEBUG - 2022-07-05 10:09:56 --> Total execution time: 0.1178
DEBUG - 2022-07-05 10:10:09 --> Total execution time: 0.0533
DEBUG - 2022-07-05 10:10:39 --> Total execution time: 0.0638
DEBUG - 2022-07-05 10:20:36 --> Total execution time: 0.3149
DEBUG - 2022-07-05 10:20:36 --> Total execution time: 0.0550
DEBUG - 2022-07-05 10:20:52 --> Total execution time: 0.0472
DEBUG - 2022-07-05 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:30:03 --> Total execution time: 0.3994
DEBUG - 2022-07-05 00:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 00:07:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 00:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:10:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 00:10:12 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 00:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 00:12:15 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 00:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:43:51 --> Total execution time: 0.0799
DEBUG - 2022-07-05 00:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:43:56 --> Total execution time: 0.0493
DEBUG - 2022-07-05 00:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:44:18 --> Total execution time: 0.0965
DEBUG - 2022-07-05 00:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:44:29 --> Total execution time: 0.0877
DEBUG - 2022-07-05 00:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:44:33 --> Total execution time: 0.0579
DEBUG - 2022-07-05 00:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:44:54 --> Total execution time: 0.0816
DEBUG - 2022-07-05 00:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:45:14 --> Total execution time: 0.0573
DEBUG - 2022-07-05 00:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:45:34 --> Total execution time: 0.0583
DEBUG - 2022-07-05 00:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:16:19 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:46:19 --> Total execution time: 0.0418
DEBUG - 2022-07-05 00:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:16:19 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:46:19 --> Total execution time: 0.0364
DEBUG - 2022-07-05 00:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:46:27 --> Total execution time: 0.0543
DEBUG - 2022-07-05 00:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:46:43 --> Total execution time: 0.0546
DEBUG - 2022-07-05 00:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:46:50 --> Total execution time: 0.0437
DEBUG - 2022-07-05 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:47:19 --> Total execution time: 0.0459
DEBUG - 2022-07-05 00:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:47:26 --> Total execution time: 0.1116
DEBUG - 2022-07-05 00:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:47:33 --> Total execution time: 0.0486
DEBUG - 2022-07-05 00:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:47:40 --> Total execution time: 0.0558
DEBUG - 2022-07-05 00:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:47:40 --> Total execution time: 0.0399
DEBUG - 2022-07-05 00:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:47:46 --> Total execution time: 0.0520
DEBUG - 2022-07-05 00:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:47:59 --> Total execution time: 0.0362
DEBUG - 2022-07-05 00:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:47:59 --> Total execution time: 0.0517
DEBUG - 2022-07-05 00:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:48:22 --> Total execution time: 0.0651
DEBUG - 2022-07-05 00:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:18:34 --> Total execution time: 0.0539
DEBUG - 2022-07-05 00:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:48:43 --> Total execution time: 0.0697
DEBUG - 2022-07-05 00:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:48:48 --> Total execution time: 0.0768
DEBUG - 2022-07-05 00:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:48:57 --> Total execution time: 0.0695
DEBUG - 2022-07-05 00:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:49:04 --> Total execution time: 0.0952
DEBUG - 2022-07-05 00:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:49:22 --> Total execution time: 0.1490
DEBUG - 2022-07-05 00:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:49:49 --> Total execution time: 0.1055
DEBUG - 2022-07-05 00:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:49:53 --> Total execution time: 0.0712
DEBUG - 2022-07-05 00:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:50:05 --> Total execution time: 0.0990
DEBUG - 2022-07-05 00:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:50:29 --> Total execution time: 0.0828
DEBUG - 2022-07-05 00:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:50:39 --> Total execution time: 0.0807
DEBUG - 2022-07-05 00:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:19 --> Total execution time: 0.0482
DEBUG - 2022-07-05 00:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:22 --> Total execution time: 0.0609
DEBUG - 2022-07-05 00:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:46 --> Total execution time: 0.1273
DEBUG - 2022-07-05 00:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:46 --> Total execution time: 0.0644
DEBUG - 2022-07-05 00:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:48 --> Total execution time: 0.0448
DEBUG - 2022-07-05 00:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:48 --> Total execution time: 0.0884
DEBUG - 2022-07-05 00:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:49 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:49 --> Total execution time: 0.0539
DEBUG - 2022-07-05 00:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:50 --> Total execution time: 0.0608
DEBUG - 2022-07-05 00:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:51 --> Total execution time: 0.1821
DEBUG - 2022-07-05 00:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:51:54 --> Total execution time: 0.0946
DEBUG - 2022-07-05 00:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:54:23 --> Total execution time: 0.1149
DEBUG - 2022-07-05 00:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:32:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:02:54 --> Total execution time: 0.1322
DEBUG - 2022-07-05 00:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:03:00 --> Total execution time: 0.0411
DEBUG - 2022-07-05 00:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:33:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:03:09 --> Total execution time: 0.0405
DEBUG - 2022-07-05 00:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:03:12 --> Total execution time: 0.0378
DEBUG - 2022-07-05 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:03:30 --> Total execution time: 0.0885
DEBUG - 2022-07-05 00:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:03:40 --> Total execution time: 0.0621
DEBUG - 2022-07-05 00:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:33:44 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:03:44 --> Total execution time: 0.0393
DEBUG - 2022-07-05 00:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:04:07 --> Total execution time: 0.0683
DEBUG - 2022-07-05 00:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:04:08 --> Total execution time: 0.0677
DEBUG - 2022-07-05 00:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:04:17 --> Total execution time: 0.0524
DEBUG - 2022-07-05 00:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:04:26 --> Total execution time: 0.0845
DEBUG - 2022-07-05 00:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:04:33 --> Total execution time: 0.0842
DEBUG - 2022-07-05 00:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 00:34:55 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 00:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:05:30 --> Total execution time: 0.0618
DEBUG - 2022-07-05 00:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:35:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:05:42 --> Total execution time: 0.0446
DEBUG - 2022-07-05 00:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:05:51 --> Total execution time: 0.0575
DEBUG - 2022-07-05 00:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:06:03 --> Total execution time: 0.0814
DEBUG - 2022-07-05 00:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:06:32 --> Total execution time: 0.1811
DEBUG - 2022-07-05 00:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:36:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:06:50 --> Total execution time: 0.0701
DEBUG - 2022-07-05 00:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:36:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:06:57 --> Total execution time: 0.0360
DEBUG - 2022-07-05 00:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:17:27 --> Total execution time: 0.1384
DEBUG - 2022-07-05 00:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:47:39 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:17:40 --> Total execution time: 0.0690
DEBUG - 2022-07-05 00:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:47:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:17:40 --> Total execution time: 0.0394
DEBUG - 2022-07-05 00:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:17:44 --> Total execution time: 0.0314
DEBUG - 2022-07-05 00:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:17:59 --> Total execution time: 0.0530
DEBUG - 2022-07-05 00:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:18:08 --> Total execution time: 0.0499
DEBUG - 2022-07-05 00:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:18:16 --> Total execution time: 0.2086
DEBUG - 2022-07-05 00:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:18:20 --> Total execution time: 0.0479
DEBUG - 2022-07-05 00:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:18:25 --> Total execution time: 0.0801
DEBUG - 2022-07-05 00:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:18:29 --> Total execution time: 0.1002
DEBUG - 2022-07-05 00:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:19:14 --> Total execution time: 0.0583
DEBUG - 2022-07-05 00:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:19:32 --> Total execution time: 0.0504
DEBUG - 2022-07-05 00:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:20:01 --> Total execution time: 0.0346
DEBUG - 2022-07-05 00:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:20:03 --> Total execution time: 0.0461
DEBUG - 2022-07-05 00:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:23:49 --> Total execution time: 0.2244
DEBUG - 2022-07-05 00:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:23:54 --> Total execution time: 0.0888
DEBUG - 2022-07-05 00:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:25:10 --> Total execution time: 0.0332
DEBUG - 2022-07-05 00:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:26:41 --> Total execution time: 0.1390
DEBUG - 2022-07-05 00:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:26:48 --> Total execution time: 0.0423
DEBUG - 2022-07-05 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:26:49 --> Total execution time: 0.0636
DEBUG - 2022-07-05 00:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:49 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:26:49 --> Total execution time: 0.0866
DEBUG - 2022-07-05 00:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:26:52 --> Total execution time: 0.0593
DEBUG - 2022-07-05 00:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:26:53 --> Total execution time: 0.0418
DEBUG - 2022-07-05 00:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:26:56 --> Total execution time: 0.0802
DEBUG - 2022-07-05 00:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:26:59 --> Total execution time: 0.0668
DEBUG - 2022-07-05 00:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:27:03 --> Total execution time: 0.2881
DEBUG - 2022-07-05 00:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:27:10 --> Total execution time: 0.0813
DEBUG - 2022-07-05 00:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:27:13 --> Total execution time: 0.0669
DEBUG - 2022-07-05 00:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:57:19 --> No URI present. Default controller set.
DEBUG - 2022-07-05 00:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:27:19 --> Total execution time: 0.0367
DEBUG - 2022-07-05 00:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:58:05 --> Total execution time: 0.0511
DEBUG - 2022-07-05 00:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 00:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 00:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:58:07 --> Total execution time: 0.0900
DEBUG - 2022-07-05 00:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 00:58:07 --> Total execution time: 0.1390
DEBUG - 2022-07-05 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:30:02 --> Total execution time: 0.0542
DEBUG - 2022-07-05 01:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:30:09 --> Total execution time: 0.1151
DEBUG - 2022-07-05 01:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:30:24 --> Total execution time: 0.0656
DEBUG - 2022-07-05 01:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:30:36 --> Total execution time: 0.0900
DEBUG - 2022-07-05 01:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:30:47 --> Total execution time: 0.0909
DEBUG - 2022-07-05 01:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:30:54 --> Total execution time: 0.0728
DEBUG - 2022-07-05 01:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:30:56 --> Total execution time: 0.0876
DEBUG - 2022-07-05 01:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:01:01 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:31:01 --> Total execution time: 0.1202
DEBUG - 2022-07-05 01:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:01:11 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:31:11 --> Total execution time: 0.0749
DEBUG - 2022-07-05 01:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:31:31 --> Total execution time: 1.6393
DEBUG - 2022-07-05 01:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:01:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 01:01:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 01:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:02:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 01:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:32:10 --> Total execution time: 1.4802
DEBUG - 2022-07-05 01:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:02:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 01:02:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 01:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:03:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:33:13 --> Total execution time: 0.0706
DEBUG - 2022-07-05 01:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:33:27 --> Total execution time: 1.5777
DEBUG - 2022-07-05 01:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:33:38 --> Total execution time: 0.1162
DEBUG - 2022-07-05 01:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:33:39 --> Total execution time: 0.0481
DEBUG - 2022-07-05 01:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:14 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:35:14 --> Total execution time: 0.0487
DEBUG - 2022-07-05 01:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:35:30 --> Total execution time: 0.0491
DEBUG - 2022-07-05 01:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:35:40 --> Total execution time: 0.0783
DEBUG - 2022-07-05 01:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:35:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 01:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:35:44 --> Total execution time: 0.0518
DEBUG - 2022-07-05 01:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:35:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 11:35:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 11:35:46 --> Total execution time: 0.1896
DEBUG - 2022-07-05 01:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:35:47 --> Total execution time: 0.0507
DEBUG - 2022-07-05 01:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:35:51 --> Total execution time: 0.0586
DEBUG - 2022-07-05 01:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:36:34 --> Total execution time: 0.0564
DEBUG - 2022-07-05 01:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:36:48 --> Total execution time: 0.0611
DEBUG - 2022-07-05 01:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:07:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:37:20 --> Total execution time: 0.0444
DEBUG - 2022-07-05 01:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:37:30 --> Total execution time: 0.0631
DEBUG - 2022-07-05 01:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:37:39 --> Total execution time: 0.0578
DEBUG - 2022-07-05 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:37:40 --> Total execution time: 0.0623
DEBUG - 2022-07-05 01:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:37:44 --> Total execution time: 0.0801
DEBUG - 2022-07-05 01:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:37:47 --> Total execution time: 0.0933
DEBUG - 2022-07-05 01:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:37:53 --> Total execution time: 0.0485
DEBUG - 2022-07-05 01:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:38:01 --> Total execution time: 0.0527
DEBUG - 2022-07-05 01:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:38:16 --> Total execution time: 0.0620
DEBUG - 2022-07-05 01:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:38:22 --> Total execution time: 0.0699
DEBUG - 2022-07-05 01:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:39:33 --> Total execution time: 0.0611
DEBUG - 2022-07-05 01:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:40:48 --> Total execution time: 0.0570
DEBUG - 2022-07-05 01:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:40:51 --> Total execution time: 0.0781
DEBUG - 2022-07-05 01:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:40:59 --> Total execution time: 0.0504
DEBUG - 2022-07-05 01:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:41:01 --> Total execution time: 0.0512
DEBUG - 2022-07-05 01:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:41:18 --> Total execution time: 0.1475
DEBUG - 2022-07-05 01:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:42:48 --> Total execution time: 0.1098
DEBUG - 2022-07-05 01:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:43:07 --> Total execution time: 0.0645
DEBUG - 2022-07-05 01:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:43:10 --> Total execution time: 0.0625
DEBUG - 2022-07-05 01:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:43:16 --> Total execution time: 0.0568
DEBUG - 2022-07-05 01:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:43:24 --> Total execution time: 0.0581
DEBUG - 2022-07-05 01:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:43:42 --> Total execution time: 0.0727
DEBUG - 2022-07-05 01:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:43:53 --> Total execution time: 0.0495
DEBUG - 2022-07-05 01:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:45:20 --> Total execution time: 0.0569
DEBUG - 2022-07-05 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:45:27 --> Total execution time: 0.0977
DEBUG - 2022-07-05 01:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:45:41 --> Total execution time: 0.0734
DEBUG - 2022-07-05 01:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:45:45 --> Total execution time: 0.1307
DEBUG - 2022-07-05 01:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:45:49 --> Total execution time: 0.0618
DEBUG - 2022-07-05 01:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:45:53 --> Total execution time: 0.0518
DEBUG - 2022-07-05 01:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:45:59 --> Total execution time: 0.0663
DEBUG - 2022-07-05 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:46:32 --> Total execution time: 0.0669
DEBUG - 2022-07-05 01:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:46:37 --> Total execution time: 0.1233
DEBUG - 2022-07-05 01:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:46:41 --> Total execution time: 0.0828
DEBUG - 2022-07-05 01:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:47:08 --> Total execution time: 0.0505
DEBUG - 2022-07-05 01:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:47:36 --> Total execution time: 0.0517
DEBUG - 2022-07-05 01:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:17 --> Total execution time: 0.0843
DEBUG - 2022-07-05 01:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:28 --> Total execution time: 0.0569
DEBUG - 2022-07-05 01:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:34 --> Total execution time: 0.0719
DEBUG - 2022-07-05 01:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:38 --> Total execution time: 0.0614
DEBUG - 2022-07-05 01:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:44 --> Total execution time: 0.0319
DEBUG - 2022-07-05 01:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:51 --> Total execution time: 0.0523
DEBUG - 2022-07-05 01:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:55 --> Total execution time: 0.0417
DEBUG - 2022-07-05 01:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:56 --> Total execution time: 0.0428
DEBUG - 2022-07-05 01:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:48:59 --> Total execution time: 0.0505
DEBUG - 2022-07-05 01:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:49:04 --> Total execution time: 0.0483
DEBUG - 2022-07-05 01:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:49:17 --> Total execution time: 0.1312
DEBUG - 2022-07-05 01:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:49:19 --> Total execution time: 0.0454
DEBUG - 2022-07-05 01:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:49:19 --> Total execution time: 0.0676
DEBUG - 2022-07-05 01:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:19:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:49:21 --> Total execution time: 0.1207
DEBUG - 2022-07-05 01:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:49:27 --> Total execution time: 0.0824
DEBUG - 2022-07-05 01:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:49:37 --> Total execution time: 0.0626
DEBUG - 2022-07-05 01:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:20:33 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:50:33 --> Total execution time: 0.0358
DEBUG - 2022-07-05 01:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:50:34 --> Total execution time: 0.0559
DEBUG - 2022-07-05 01:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:50:38 --> Total execution time: 0.0585
DEBUG - 2022-07-05 01:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:21:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:51:38 --> Total execution time: 0.0493
DEBUG - 2022-07-05 01:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:52:12 --> Total execution time: 0.1309
DEBUG - 2022-07-05 01:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:22:12 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:52:12 --> Total execution time: 0.1202
DEBUG - 2022-07-05 01:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:22:14 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:52:15 --> Total execution time: 0.1510
DEBUG - 2022-07-05 01:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:52:18 --> Total execution time: 0.1066
DEBUG - 2022-07-05 01:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:52:28 --> Total execution time: 0.0915
DEBUG - 2022-07-05 01:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:52:45 --> Total execution time: 0.1069
DEBUG - 2022-07-05 01:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:52:56 --> Total execution time: 0.0754
DEBUG - 2022-07-05 01:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:53:24 --> Total execution time: 0.0381
DEBUG - 2022-07-05 01:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:53:33 --> Total execution time: 0.0532
DEBUG - 2022-07-05 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:54:05 --> Total execution time: 0.1514
DEBUG - 2022-07-05 01:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:54:15 --> Total execution time: 0.0470
DEBUG - 2022-07-05 01:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:24:21 --> Total execution time: 0.0504
DEBUG - 2022-07-05 01:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:24:23 --> Total execution time: 0.0605
DEBUG - 2022-07-05 01:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:24:23 --> Total execution time: 0.1280
DEBUG - 2022-07-05 01:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:54:29 --> Total execution time: 0.0409
DEBUG - 2022-07-05 01:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:54:38 --> Total execution time: 0.0434
DEBUG - 2022-07-05 01:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:54:43 --> Total execution time: 0.0610
DEBUG - 2022-07-05 01:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:54:49 --> Total execution time: 0.0865
DEBUG - 2022-07-05 01:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:54:57 --> Total execution time: 0.0631
DEBUG - 2022-07-05 01:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:54:59 --> Total execution time: 0.0587
DEBUG - 2022-07-05 01:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:55:02 --> Total execution time: 0.0836
DEBUG - 2022-07-05 01:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:55:06 --> Total execution time: 0.0902
DEBUG - 2022-07-05 01:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:55:09 --> Total execution time: 0.0568
DEBUG - 2022-07-05 01:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:25:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 01:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:55:22 --> Total execution time: 1.5243
DEBUG - 2022-07-05 01:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 01:25:25 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 01:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:55:41 --> Total execution time: 0.0808
DEBUG - 2022-07-05 01:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:55:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 01:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:55:55 --> Total execution time: 0.0579
DEBUG - 2022-07-05 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:55:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 11:55:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 11:55:56 --> Total execution time: 0.2149
DEBUG - 2022-07-05 01:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:56:10 --> Total execution time: 0.0563
DEBUG - 2022-07-05 01:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:56:23 --> Total execution time: 0.0559
DEBUG - 2022-07-05 01:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:56:31 --> Total execution time: 0.0677
DEBUG - 2022-07-05 01:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:56:51 --> Total execution time: 0.0596
DEBUG - 2022-07-05 01:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:56:51 --> Total execution time: 0.0498
DEBUG - 2022-07-05 01:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:56:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 01:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:56:52 --> Total execution time: 0.0645
DEBUG - 2022-07-05 01:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:56:55 --> Total execution time: 0.0711
DEBUG - 2022-07-05 01:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:57:41 --> Total execution time: 0.0432
DEBUG - 2022-07-05 01:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:28:14 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:58:14 --> Total execution time: 0.1301
DEBUG - 2022-07-05 01:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:28:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:58:15 --> Total execution time: 0.0592
DEBUG - 2022-07-05 01:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:58:18 --> Total execution time: 0.0486
DEBUG - 2022-07-05 01:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:58:32 --> Total execution time: 0.0508
DEBUG - 2022-07-05 01:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:58:37 --> Total execution time: 0.0764
DEBUG - 2022-07-05 01:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:58:46 --> Total execution time: 0.0535
DEBUG - 2022-07-05 01:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:00:41 --> Total execution time: 0.1642
DEBUG - 2022-07-05 01:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:00:46 --> Total execution time: 0.0543
DEBUG - 2022-07-05 01:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:00:48 --> Total execution time: 0.0713
DEBUG - 2022-07-05 01:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:01:24 --> Total execution time: 0.0527
DEBUG - 2022-07-05 01:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:01:34 --> Total execution time: 0.1431
DEBUG - 2022-07-05 01:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:01:38 --> Total execution time: 0.0666
DEBUG - 2022-07-05 01:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:01:45 --> Total execution time: 0.0821
DEBUG - 2022-07-05 01:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:01:48 --> Total execution time: 0.0688
DEBUG - 2022-07-05 01:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:00 --> Total execution time: 0.0519
DEBUG - 2022-07-05 01:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:09 --> Total execution time: 0.1902
DEBUG - 2022-07-05 01:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:30 --> Total execution time: 0.0716
DEBUG - 2022-07-05 01:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:38 --> Total execution time: 0.0478
DEBUG - 2022-07-05 01:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:49 --> Total execution time: 0.0491
DEBUG - 2022-07-05 01:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:56 --> Total execution time: 0.0529
DEBUG - 2022-07-05 01:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 01:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:57 --> Total execution time: 0.0502
DEBUG - 2022-07-05 01:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:04:31 --> Total execution time: 0.0520
DEBUG - 2022-07-05 01:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:04:35 --> Total execution time: 0.0502
DEBUG - 2022-07-05 01:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:05:09 --> Total execution time: 0.0505
DEBUG - 2022-07-05 01:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:05:50 --> Total execution time: 0.0528
DEBUG - 2022-07-05 01:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:10:09 --> Total execution time: 0.0677
DEBUG - 2022-07-05 01:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:10:16 --> Total execution time: 0.0607
DEBUG - 2022-07-05 01:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:10:17 --> Total execution time: 0.0829
DEBUG - 2022-07-05 01:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:10:28 --> Total execution time: 0.1092
DEBUG - 2022-07-05 01:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:10:45 --> Total execution time: 0.0782
DEBUG - 2022-07-05 01:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:11:03 --> Total execution time: 0.0657
DEBUG - 2022-07-05 01:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:11:11 --> Total execution time: 0.1408
DEBUG - 2022-07-05 01:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:11:12 --> Total execution time: 0.0519
DEBUG - 2022-07-05 01:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:11:23 --> Total execution time: 0.0598
DEBUG - 2022-07-05 01:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:11:28 --> Total execution time: 0.0620
DEBUG - 2022-07-05 01:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:11:48 --> Total execution time: 0.0602
DEBUG - 2022-07-05 01:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:11:50 --> Total execution time: 0.0538
DEBUG - 2022-07-05 01:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:12:04 --> Total execution time: 0.0579
DEBUG - 2022-07-05 01:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:12:09 --> Total execution time: 0.0823
DEBUG - 2022-07-05 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:12:54 --> Total execution time: 0.1887
DEBUG - 2022-07-05 01:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:12:59 --> Total execution time: 0.0512
DEBUG - 2022-07-05 01:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:13:13 --> Total execution time: 0.1000
DEBUG - 2022-07-05 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:13:18 --> Total execution time: 0.1092
DEBUG - 2022-07-05 01:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:45:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 01:45:25 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 01:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:15:39 --> Total execution time: 0.1455
DEBUG - 2022-07-05 01:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:17:04 --> Total execution time: 0.0904
DEBUG - 2022-07-05 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 01:47:52 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 01:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:18:05 --> Total execution time: 0.0880
DEBUG - 2022-07-05 01:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:49:34 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:19:34 --> Total execution time: 0.0668
DEBUG - 2022-07-05 01:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:49:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 01:49:50 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 01:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:49:58 --> Total execution time: 0.0525
DEBUG - 2022-07-05 01:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:50:32 --> Total execution time: 0.0815
DEBUG - 2022-07-05 01:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:50:32 --> Total execution time: 0.1037
DEBUG - 2022-07-05 01:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:21:07 --> Total execution time: 0.0850
DEBUG - 2022-07-05 01:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:52:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 01:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:22:06 --> Total execution time: 1.5933
DEBUG - 2022-07-05 01:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 01:52:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 01:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:23:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 01:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:23:04 --> Total execution time: 0.0835
DEBUG - 2022-07-05 01:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:23:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 12:23:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 12:23:06 --> Total execution time: 0.2250
DEBUG - 2022-07-05 01:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:53:26 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:23:26 --> Total execution time: 0.0472
DEBUG - 2022-07-05 01:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:54:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:24:15 --> Total execution time: 0.0387
DEBUG - 2022-07-05 01:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:54:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:24:16 --> Total execution time: 0.0396
DEBUG - 2022-07-05 01:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:24:20 --> Total execution time: 0.0460
DEBUG - 2022-07-05 01:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:24:39 --> Total execution time: 0.0498
DEBUG - 2022-07-05 01:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:25:25 --> Total execution time: 0.0550
DEBUG - 2022-07-05 01:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:55:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 01:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:25:37 --> Total execution time: 0.0347
DEBUG - 2022-07-05 01:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:25:43 --> Total execution time: 0.0561
DEBUG - 2022-07-05 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:25:58 --> Total execution time: 0.0591
DEBUG - 2022-07-05 01:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:02 --> Total execution time: 0.0700
DEBUG - 2022-07-05 01:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:02 --> Total execution time: 0.0719
DEBUG - 2022-07-05 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:05 --> Total execution time: 0.0633
DEBUG - 2022-07-05 01:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:13 --> Total execution time: 0.0751
DEBUG - 2022-07-05 01:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:25 --> Total execution time: 0.0571
DEBUG - 2022-07-05 01:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:31 --> Total execution time: 0.1620
DEBUG - 2022-07-05 01:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:32 --> Total execution time: 0.0549
DEBUG - 2022-07-05 01:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:58 --> Total execution time: 0.0599
DEBUG - 2022-07-05 01:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:09 --> Total execution time: 0.0661
DEBUG - 2022-07-05 01:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:13 --> Total execution time: 0.0605
DEBUG - 2022-07-05 01:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:30 --> Total execution time: 0.0724
DEBUG - 2022-07-05 01:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:42 --> Total execution time: 0.0865
DEBUG - 2022-07-05 01:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:50 --> Total execution time: 0.0512
DEBUG - 2022-07-05 01:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:28:06 --> Total execution time: 0.0552
DEBUG - 2022-07-05 01:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:28:19 --> Total execution time: 0.0645
DEBUG - 2022-07-05 01:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:28:46 --> Total execution time: 0.0581
DEBUG - 2022-07-05 01:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:28:57 --> Total execution time: 0.0614
DEBUG - 2022-07-05 01:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:02 --> Total execution time: 0.0585
DEBUG - 2022-07-05 01:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:08 --> Total execution time: 0.1773
DEBUG - 2022-07-05 01:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:18 --> Total execution time: 0.1264
DEBUG - 2022-07-05 01:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:52 --> Total execution time: 0.1188
DEBUG - 2022-07-05 01:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:55 --> Total execution time: 0.0501
DEBUG - 2022-07-05 01:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:57 --> Total execution time: 0.0440
DEBUG - 2022-07-05 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:58 --> Total execution time: 0.0485
DEBUG - 2022-07-05 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:58 --> Total execution time: 0.0622
DEBUG - 2022-07-05 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:58 --> Total execution time: 0.0512
DEBUG - 2022-07-05 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:58 --> Total execution time: 0.0494
DEBUG - 2022-07-05 01:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:59 --> Total execution time: 0.0669
DEBUG - 2022-07-05 01:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:59 --> Total execution time: 0.0634
DEBUG - 2022-07-05 01:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 01:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 01:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 01:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:00:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:30:00 --> Total execution time: 0.1135
DEBUG - 2022-07-05 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:30:02 --> Total execution time: 0.0666
DEBUG - 2022-07-05 02:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:01:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:31:00 --> Total execution time: 0.0376
DEBUG - 2022-07-05 02:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:31:07 --> Total execution time: 0.0336
DEBUG - 2022-07-05 02:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:31:14 --> Total execution time: 0.0684
DEBUG - 2022-07-05 02:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:31:28 --> Total execution time: 0.0564
DEBUG - 2022-07-05 02:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:31:35 --> Total execution time: 0.0543
DEBUG - 2022-07-05 02:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:02:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:32:56 --> Total execution time: 0.0552
DEBUG - 2022-07-05 02:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:33:42 --> Total execution time: 0.0494
DEBUG - 2022-07-05 02:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:34:34 --> Total execution time: 0.0501
DEBUG - 2022-07-05 02:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:34:44 --> Total execution time: 0.0491
DEBUG - 2022-07-05 02:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:35:36 --> Total execution time: 0.0483
DEBUG - 2022-07-05 02:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:05:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:35:43 --> Total execution time: 0.1984
DEBUG - 2022-07-05 02:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:36:14 --> Total execution time: 0.0464
DEBUG - 2022-07-05 02:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:30 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:36:30 --> Total execution time: 0.0419
DEBUG - 2022-07-05 02:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:36:33 --> Total execution time: 0.0616
DEBUG - 2022-07-05 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:36:36 --> Total execution time: 0.0490
DEBUG - 2022-07-05 02:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:36:54 --> Total execution time: 0.0597
DEBUG - 2022-07-05 02:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:36:58 --> Total execution time: 0.0589
DEBUG - 2022-07-05 02:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:36:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 02:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:00 --> Total execution time: 0.0566
DEBUG - 2022-07-05 02:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:37 --> Total execution time: 0.0579
DEBUG - 2022-07-05 02:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:50 --> Total execution time: 0.0640
DEBUG - 2022-07-05 02:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:56 --> Total execution time: 0.0905
DEBUG - 2022-07-05 02:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:38:12 --> Total execution time: 0.1005
DEBUG - 2022-07-05 02:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:38:19 --> Total execution time: 0.0668
DEBUG - 2022-07-05 02:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:08:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 02:08:24 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-05 02:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:38:50 --> Total execution time: 0.0483
DEBUG - 2022-07-05 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:38:55 --> Total execution time: 0.0819
DEBUG - 2022-07-05 02:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:38:57 --> Total execution time: 0.0564
DEBUG - 2022-07-05 02:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:39:05 --> Total execution time: 0.0869
DEBUG - 2022-07-05 02:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:39:24 --> Total execution time: 0.0555
DEBUG - 2022-07-05 02:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:09:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:39:58 --> Total execution time: 0.1278
DEBUG - 2022-07-05 02:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:40:06 --> Total execution time: 0.0499
DEBUG - 2022-07-05 02:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:14 --> Total execution time: 0.0766
DEBUG - 2022-07-05 02:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 02:12:45 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 02:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:19:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:49:47 --> Total execution time: 0.2031
DEBUG - 2022-07-05 02:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:50:03 --> Total execution time: 0.0898
DEBUG - 2022-07-05 02:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:50:14 --> Total execution time: 0.0630
DEBUG - 2022-07-05 02:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:50:22 --> Total execution time: 0.1603
DEBUG - 2022-07-05 02:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:50:24 --> Total execution time: 0.0871
DEBUG - 2022-07-05 02:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:50:28 --> Total execution time: 0.0491
DEBUG - 2022-07-05 02:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:50:44 --> Total execution time: 0.0555
DEBUG - 2022-07-05 02:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:50:50 --> Total execution time: 0.0630
DEBUG - 2022-07-05 02:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:50:57 --> Total execution time: 0.0608
DEBUG - 2022-07-05 02:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:51:08 --> Total execution time: 0.0702
DEBUG - 2022-07-05 02:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:21:49 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:51:49 --> Total execution time: 0.1323
DEBUG - 2022-07-05 02:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:51:58 --> Total execution time: 0.0576
DEBUG - 2022-07-05 02:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:51:59 --> Total execution time: 0.0504
DEBUG - 2022-07-05 02:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:27 --> Total execution time: 0.0608
DEBUG - 2022-07-05 02:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:31 --> Total execution time: 0.0582
DEBUG - 2022-07-05 02:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:37 --> Total execution time: 0.0493
DEBUG - 2022-07-05 02:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:43 --> Total execution time: 0.0444
DEBUG - 2022-07-05 02:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:45 --> Total execution time: 0.0612
DEBUG - 2022-07-05 02:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:46 --> Total execution time: 0.0465
DEBUG - 2022-07-05 02:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 02:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:47 --> Total execution time: 0.0446
DEBUG - 2022-07-05 02:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:52:51 --> Total execution time: 0.0485
DEBUG - 2022-07-05 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:53:43 --> Total execution time: 0.0481
DEBUG - 2022-07-05 02:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:55:02 --> Total execution time: 0.0513
DEBUG - 2022-07-05 02:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:55:10 --> Total execution time: 0.1326
DEBUG - 2022-07-05 02:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:55:12 --> Total execution time: 0.0619
DEBUG - 2022-07-05 02:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:55:24 --> Total execution time: 0.0565
DEBUG - 2022-07-05 02:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:56:57 --> Total execution time: 0.0598
DEBUG - 2022-07-05 02:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:10 --> Total execution time: 0.0649
DEBUG - 2022-07-05 02:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:15 --> Total execution time: 0.0888
DEBUG - 2022-07-05 02:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:17 --> Total execution time: 0.0521
DEBUG - 2022-07-05 02:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:22 --> Total execution time: 0.0554
DEBUG - 2022-07-05 02:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:30 --> Total execution time: 0.0825
DEBUG - 2022-07-05 02:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:30 --> Total execution time: 0.0614
DEBUG - 2022-07-05 02:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:34 --> Total execution time: 0.0639
DEBUG - 2022-07-05 02:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:39 --> Total execution time: 0.0577
DEBUG - 2022-07-05 02:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:44 --> Total execution time: 0.0527
DEBUG - 2022-07-05 02:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:48 --> Total execution time: 0.0893
DEBUG - 2022-07-05 02:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:50 --> Total execution time: 0.0513
DEBUG - 2022-07-05 02:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:54 --> Total execution time: 0.0614
DEBUG - 2022-07-05 02:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:57:59 --> Total execution time: 0.0542
DEBUG - 2022-07-05 02:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:58:03 --> Total execution time: 0.0992
DEBUG - 2022-07-05 02:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:29:33 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:59:33 --> Total execution time: 0.1227
DEBUG - 2022-07-05 02:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:29:39 --> Total execution time: 0.0558
DEBUG - 2022-07-05 02:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:59:40 --> Total execution time: 0.0553
DEBUG - 2022-07-05 02:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:29:41 --> Total execution time: 0.0547
DEBUG - 2022-07-05 02:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:29:41 --> Total execution time: 0.0581
DEBUG - 2022-07-05 02:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:29:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:59:56 --> Total execution time: 0.0528
DEBUG - 2022-07-05 02:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:00:01 --> Total execution time: 0.0493
DEBUG - 2022-07-05 02:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:00:33 --> Total execution time: 0.0562
DEBUG - 2022-07-05 02:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:00:36 --> Total execution time: 0.0787
DEBUG - 2022-07-05 02:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:00:50 --> Total execution time: 0.1510
DEBUG - 2022-07-05 02:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:01:00 --> Total execution time: 0.0615
DEBUG - 2022-07-05 02:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:01:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 02:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:01:01 --> Total execution time: 0.0864
DEBUG - 2022-07-05 02:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:02:30 --> Total execution time: 0.0683
DEBUG - 2022-07-05 02:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:02:31 --> Total execution time: 0.0557
DEBUG - 2022-07-05 02:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:04:47 --> Total execution time: 0.1369
DEBUG - 2022-07-05 02:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:08:27 --> Total execution time: 0.1949
DEBUG - 2022-07-05 02:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:08:34 --> Total execution time: 0.0552
DEBUG - 2022-07-05 02:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:08:47 --> Total execution time: 0.0431
DEBUG - 2022-07-05 02:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:09:21 --> Total execution time: 0.0354
DEBUG - 2022-07-05 02:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:09:28 --> Total execution time: 0.0563
DEBUG - 2022-07-05 02:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:09:40 --> Total execution time: 0.0544
DEBUG - 2022-07-05 02:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:40:05 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:10:05 --> Total execution time: 0.0799
DEBUG - 2022-07-05 02:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:10:09 --> Total execution time: 0.0574
DEBUG - 2022-07-05 02:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:10:22 --> Total execution time: 0.0622
DEBUG - 2022-07-05 02:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:10:32 --> Total execution time: 0.0474
DEBUG - 2022-07-05 02:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:41:03 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:11:03 --> Total execution time: 0.0357
DEBUG - 2022-07-05 02:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:11:09 --> Total execution time: 0.0381
DEBUG - 2022-07-05 02:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:11:30 --> Total execution time: 0.0902
DEBUG - 2022-07-05 02:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:11:46 --> Total execution time: 0.0882
DEBUG - 2022-07-05 02:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:12:07 --> Total execution time: 0.1150
DEBUG - 2022-07-05 02:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:12:45 --> Total execution time: 0.0600
DEBUG - 2022-07-05 02:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:42:51 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:12:51 --> Total execution time: 0.0373
DEBUG - 2022-07-05 02:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:12:57 --> Total execution time: 0.0526
DEBUG - 2022-07-05 02:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:12:58 --> Total execution time: 0.0624
DEBUG - 2022-07-05 02:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:12:59 --> Total execution time: 0.0817
DEBUG - 2022-07-05 02:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:43:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:13:43 --> Total execution time: 0.0349
DEBUG - 2022-07-05 02:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:43:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:13:52 --> Total execution time: 0.0544
DEBUG - 2022-07-05 02:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:13:55 --> Total execution time: 0.0426
DEBUG - 2022-07-05 02:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:14:04 --> Total execution time: 0.0554
DEBUG - 2022-07-05 02:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:14:11 --> Total execution time: 0.0977
DEBUG - 2022-07-05 02:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:45:34 --> Total execution time: 0.0402
DEBUG - 2022-07-05 02:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:45:36 --> Total execution time: 0.0552
DEBUG - 2022-07-05 02:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:45:36 --> Total execution time: 0.1085
DEBUG - 2022-07-05 02:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:15:43 --> Total execution time: 0.0574
DEBUG - 2022-07-05 02:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:16:20 --> Total execution time: 0.0814
DEBUG - 2022-07-05 02:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:46:29 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:16:29 --> Total execution time: 0.0417
DEBUG - 2022-07-05 02:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:46:32 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:16:32 --> Total execution time: 0.0368
DEBUG - 2022-07-05 02:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:16:42 --> Total execution time: 0.0500
DEBUG - 2022-07-05 02:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:46:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:16:50 --> Total execution time: 0.0515
DEBUG - 2022-07-05 02:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:17:34 --> Total execution time: 0.0486
DEBUG - 2022-07-05 02:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:17:43 --> Total execution time: 0.1358
DEBUG - 2022-07-05 02:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:17:47 --> Total execution time: 0.0689
DEBUG - 2022-07-05 02:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:17:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 02:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:17:48 --> Total execution time: 0.0527
DEBUG - 2022-07-05 02:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:17:50 --> Total execution time: 0.0495
DEBUG - 2022-07-05 02:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:47:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 02:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:17:54 --> Total execution time: 1.6327
DEBUG - 2022-07-05 02:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 02:47:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 02:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:18:22 --> Total execution time: 0.0511
DEBUG - 2022-07-05 02:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:18:35 --> Total execution time: 0.0638
DEBUG - 2022-07-05 02:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:50:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:20:40 --> Total execution time: 0.1143
DEBUG - 2022-07-05 02:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:20:46 --> Total execution time: 0.1359
DEBUG - 2022-07-05 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:21:06 --> Total execution time: 0.0581
DEBUG - 2022-07-05 02:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:22:29 --> Total execution time: 1.6399
DEBUG - 2022-07-05 02:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:22:35 --> Total execution time: 0.0587
DEBUG - 2022-07-05 02:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:23:11 --> Total execution time: 0.0694
DEBUG - 2022-07-05 02:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:56:53 --> Total execution time: 0.1490
DEBUG - 2022-07-05 02:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:26:56 --> Total execution time: 0.0496
DEBUG - 2022-07-05 02:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:56:57 --> Total execution time: 0.1331
DEBUG - 2022-07-05 02:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:26:59 --> Total execution time: 0.0559
DEBUG - 2022-07-05 02:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:27:05 --> Total execution time: 0.0664
DEBUG - 2022-07-05 02:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:27:17 --> Total execution time: 0.1035
DEBUG - 2022-07-05 02:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:27:20 --> Total execution time: 0.0725
DEBUG - 2022-07-05 02:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:27:21 --> Total execution time: 0.0827
DEBUG - 2022-07-05 02:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:27:23 --> Total execution time: 0.0902
DEBUG - 2022-07-05 02:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:57:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 02:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:27:38 --> Total execution time: 0.0422
DEBUG - 2022-07-05 02:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:28:01 --> Total execution time: 0.0563
DEBUG - 2022-07-05 02:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:28:08 --> Total execution time: 0.0433
DEBUG - 2022-07-05 02:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:28:34 --> Total execution time: 0.1773
DEBUG - 2022-07-05 02:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:28:38 --> Total execution time: 0.0736
DEBUG - 2022-07-05 02:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:28:40 --> Total execution time: 0.0677
DEBUG - 2022-07-05 02:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 02:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 02:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 02:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:29:55 --> Total execution time: 0.0804
DEBUG - 2022-07-05 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:30:02 --> Total execution time: 0.1153
DEBUG - 2022-07-05 03:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:30:17 --> Total execution time: 0.0900
DEBUG - 2022-07-05 03:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:30:23 --> Total execution time: 0.0520
DEBUG - 2022-07-05 03:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:30:42 --> Total execution time: 0.0327
DEBUG - 2022-07-05 03:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:33:36 --> Total execution time: 0.1228
DEBUG - 2022-07-05 03:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:33:37 --> Total execution time: 0.0651
DEBUG - 2022-07-05 03:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:04:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:34:00 --> Total execution time: 0.0394
DEBUG - 2022-07-05 03:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:04:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:04:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 03:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:35:37 --> Total execution time: 0.0529
DEBUG - 2022-07-05 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:05:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:35:42 --> Total execution time: 0.0420
DEBUG - 2022-07-05 03:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:36:05 --> Total execution time: 0.0605
DEBUG - 2022-07-05 03:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:06:08 --> Total execution time: 0.0887
DEBUG - 2022-07-05 03:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:37:32 --> Total execution time: 0.1503
DEBUG - 2022-07-05 03:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:37:44 --> Total execution time: 0.0699
DEBUG - 2022-07-05 03:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:37:49 --> Total execution time: 0.0587
DEBUG - 2022-07-05 03:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:07:53 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:37:53 --> Total execution time: 0.0452
DEBUG - 2022-07-05 03:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:07:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 03:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:38:12 --> Total execution time: 0.0576
DEBUG - 2022-07-05 03:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:38:26 --> Total execution time: 0.0728
DEBUG - 2022-07-05 03:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:38:38 --> Total execution time: 0.0662
DEBUG - 2022-07-05 03:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:38:42 --> Total execution time: 0.0555
DEBUG - 2022-07-05 03:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:38:52 --> Total execution time: 0.0601
DEBUG - 2022-07-05 03:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:38:54 --> Total execution time: 0.2647
DEBUG - 2022-07-05 03:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:38:55 --> Total execution time: 0.0629
DEBUG - 2022-07-05 03:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:39:02 --> Total execution time: 0.0609
DEBUG - 2022-07-05 03:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:09:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:39:20 --> Total execution time: 0.0367
DEBUG - 2022-07-05 03:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:40:12 --> Total execution time: 0.1133
DEBUG - 2022-07-05 03:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:41:25 --> Total execution time: 0.0653
DEBUG - 2022-07-05 03:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:41:33 --> Total execution time: 0.0827
DEBUG - 2022-07-05 03:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:45:28 --> Total execution time: 0.2146
DEBUG - 2022-07-05 03:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:45:35 --> Total execution time: 0.0754
DEBUG - 2022-07-05 03:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:46:20 --> Total execution time: 0.0446
DEBUG - 2022-07-05 03:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:46:28 --> Total execution time: 0.0654
DEBUG - 2022-07-05 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:46:41 --> Total execution time: 0.0599
DEBUG - 2022-07-05 03:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:46:50 --> Total execution time: 0.1034
DEBUG - 2022-07-05 03:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:46:57 --> Total execution time: 0.0656
DEBUG - 2022-07-05 03:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:48:23 --> Total execution time: 0.0730
DEBUG - 2022-07-05 03:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:23:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:23:36 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 03:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:26:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:26:06 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 03:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:28:12 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 03:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:30:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:09 --> Total execution time: 0.1815
DEBUG - 2022-07-05 03:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:33:05 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:03:06 --> Total execution time: 0.1096
DEBUG - 2022-07-05 03:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:33:39 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:03:39 --> Total execution time: 0.0388
DEBUG - 2022-07-05 03:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:35:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:05:58 --> Total execution time: 0.1063
DEBUG - 2022-07-05 03:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:37:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:07:38 --> Total execution time: 0.0361
DEBUG - 2022-07-05 03:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:40:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:40:07 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-05 03:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:40:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:10:41 --> Total execution time: 0.0914
DEBUG - 2022-07-05 03:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:40:52 --> Total execution time: 0.0569
DEBUG - 2022-07-05 03:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:40:54 --> Total execution time: 0.0798
DEBUG - 2022-07-05 03:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:40:54 --> Total execution time: 0.1579
DEBUG - 2022-07-05 03:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:41:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 03:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:11:55 --> Total execution time: 1.6513
DEBUG - 2022-07-05 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:41:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 03:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:42:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:12:52 --> Total execution time: 0.0511
DEBUG - 2022-07-05 03:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:12:55 --> Total execution time: 0.0583
DEBUG - 2022-07-05 03:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:13:16 --> Total execution time: 0.0704
DEBUG - 2022-07-05 03:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:13:27 --> Total execution time: 0.0737
DEBUG - 2022-07-05 03:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:13:32 --> Total execution time: 0.0629
DEBUG - 2022-07-05 03:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:13:44 --> Total execution time: 0.1100
DEBUG - 2022-07-05 03:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:44:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:44:21 --> 404 Page Not Found: Terms/index
DEBUG - 2022-07-05 03:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:14:32 --> Total execution time: 0.0871
DEBUG - 2022-07-05 03:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:14:34 --> Total execution time: 0.0634
DEBUG - 2022-07-05 03:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:15:36 --> Total execution time: 0.0674
DEBUG - 2022-07-05 03:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:15:43 --> Total execution time: 0.0726
DEBUG - 2022-07-05 03:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:15:55 --> Total execution time: 0.1103
DEBUG - 2022-07-05 03:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:46:00 --> Total execution time: 0.0634
DEBUG - 2022-07-05 03:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:05 --> Total execution time: 0.0518
DEBUG - 2022-07-05 03:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:10 --> Total execution time: 0.0802
DEBUG - 2022-07-05 03:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:11 --> Total execution time: 0.0895
DEBUG - 2022-07-05 03:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:31 --> Total execution time: 0.0514
DEBUG - 2022-07-05 03:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:33 --> Total execution time: 0.0523
DEBUG - 2022-07-05 03:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:41 --> Total execution time: 0.0601
DEBUG - 2022-07-05 03:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 03:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:43 --> Total execution time: 0.0511
DEBUG - 2022-07-05 03:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 14:16:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 14:16:45 --> Total execution time: 0.1860
DEBUG - 2022-07-05 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:17:03 --> Total execution time: 0.0512
DEBUG - 2022-07-05 03:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:17:04 --> Total execution time: 0.0601
DEBUG - 2022-07-05 03:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:17:13 --> Total execution time: 0.0489
DEBUG - 2022-07-05 03:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:17:27 --> Total execution time: 0.0682
DEBUG - 2022-07-05 03:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:17:35 --> Total execution time: 0.0630
DEBUG - 2022-07-05 03:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:50:04 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:20:04 --> Total execution time: 0.1067
DEBUG - 2022-07-05 03:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:50:39 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:20:39 --> Total execution time: 0.0444
DEBUG - 2022-07-05 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:51:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:21:38 --> Total execution time: 0.0341
DEBUG - 2022-07-05 03:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:21:38 --> Total execution time: 0.0353
DEBUG - 2022-07-05 03:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 03:51:40 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:51:48 --> Total execution time: 0.0504
DEBUG - 2022-07-05 03:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:51:50 --> Total execution time: 0.0544
DEBUG - 2022-07-05 03:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:51:50 --> Total execution time: 0.1187
DEBUG - 2022-07-05 03:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:22 --> Total execution time: 0.0620
DEBUG - 2022-07-05 03:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:24 --> Total execution time: 0.0535
DEBUG - 2022-07-05 03:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:24 --> Total execution time: 0.0832
DEBUG - 2022-07-05 03:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:22:45 --> Total execution time: 0.0673
DEBUG - 2022-07-05 03:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:53 --> Total execution time: 0.0430
DEBUG - 2022-07-05 03:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:22:53 --> Total execution time: 0.0864
DEBUG - 2022-07-05 03:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:54 --> Total execution time: 0.0479
DEBUG - 2022-07-05 03:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:52:54 --> Total execution time: 0.1001
DEBUG - 2022-07-05 03:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:24:29 --> Total execution time: 0.0378
DEBUG - 2022-07-05 03:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:58:31 --> No URI present. Default controller set.
DEBUG - 2022-07-05 03:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:28:31 --> Total execution time: 0.2824
DEBUG - 2022-07-05 03:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 03:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:29:11 --> Total execution time: 0.0541
DEBUG - 2022-07-05 03:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 03:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 03:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:29:51 --> Total execution time: 0.0655
DEBUG - 2022-07-05 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:30:02 --> Total execution time: 0.0685
DEBUG - 2022-07-05 04:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:30:10 --> Total execution time: 0.1694
DEBUG - 2022-07-05 04:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:30:18 --> Total execution time: 0.1015
DEBUG - 2022-07-05 04:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:05:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:35:00 --> Total execution time: 0.1897
DEBUG - 2022-07-05 04:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:35:06 --> Total execution time: 0.0540
DEBUG - 2022-07-05 04:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:35:31 --> Total execution time: 0.0984
DEBUG - 2022-07-05 04:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:35:44 --> Total execution time: 0.0737
DEBUG - 2022-07-05 04:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:35:46 --> Total execution time: 0.0718
DEBUG - 2022-07-05 04:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:35:54 --> Total execution time: 0.0580
DEBUG - 2022-07-05 04:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:36:53 --> Total execution time: 0.0507
DEBUG - 2022-07-05 04:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:37:03 --> Total execution time: 0.0495
DEBUG - 2022-07-05 04:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:37:57 --> Total execution time: 0.0525
DEBUG - 2022-07-05 04:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:38:00 --> Total execution time: 0.0522
DEBUG - 2022-07-05 04:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:38:10 --> Total execution time: 0.0498
DEBUG - 2022-07-05 04:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:10:06 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:40:06 --> Total execution time: 0.0448
DEBUG - 2022-07-05 04:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:10:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 04:10:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:11:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:41:07 --> Total execution time: 0.0426
DEBUG - 2022-07-05 04:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:41:44 --> Total execution time: 0.1232
DEBUG - 2022-07-05 04:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:12:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:42:55 --> Total execution time: 0.0396
DEBUG - 2022-07-05 04:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 04:12:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 04:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:43:03 --> Total execution time: 0.0721
DEBUG - 2022-07-05 04:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:43:29 --> Total execution time: 0.0595
DEBUG - 2022-07-05 04:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:15:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:45:37 --> Total execution time: 0.1375
DEBUG - 2022-07-05 04:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 04:16:05 --> 404 Page Not Found: My-account/index
DEBUG - 2022-07-05 04:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:16:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:46:40 --> Total execution time: 0.1492
DEBUG - 2022-07-05 04:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:17:01 --> Total execution time: 0.0838
DEBUG - 2022-07-05 04:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:17:04 --> Total execution time: 0.0541
DEBUG - 2022-07-05 04:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:17:05 --> Total execution time: 0.1034
DEBUG - 2022-07-05 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:47:27 --> Total execution time: 0.0587
DEBUG - 2022-07-05 04:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:20:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:50:56 --> Total execution time: 0.1114
DEBUG - 2022-07-05 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:20:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:01 --> Total execution time: 1.5449
DEBUG - 2022-07-05 04:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:05 --> Total execution time: 0.0785
DEBUG - 2022-07-05 04:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:15 --> Total execution time: 0.0628
DEBUG - 2022-07-05 04:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:23 --> Total execution time: 0.0836
DEBUG - 2022-07-05 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:40 --> Total execution time: 0.0474
DEBUG - 2022-07-05 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:41 --> Total execution time: 0.0634
DEBUG - 2022-07-05 04:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:44 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:44 --> Total execution time: 0.0504
DEBUG - 2022-07-05 04:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:46 --> Total execution time: 0.1040
DEBUG - 2022-07-05 04:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:49 --> Total execution time: 0.0499
DEBUG - 2022-07-05 04:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 04:21:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:56 --> Total execution time: 0.0551
DEBUG - 2022-07-05 04:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:51:59 --> Total execution time: 0.0729
DEBUG - 2022-07-05 04:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:52:08 --> Total execution time: 0.0568
DEBUG - 2022-07-05 04:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:52:10 --> Total execution time: 0.0570
DEBUG - 2022-07-05 04:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:52:13 --> Total execution time: 0.0664
DEBUG - 2022-07-05 04:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:52:15 --> Total execution time: 0.0462
DEBUG - 2022-07-05 04:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:52:19 --> Total execution time: 0.0746
DEBUG - 2022-07-05 04:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:52:26 --> Total execution time: 0.0599
DEBUG - 2022-07-05 04:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:53:53 --> Total execution time: 1.8133
DEBUG - 2022-07-05 04:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:23:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:53:57 --> Total execution time: 0.1262
DEBUG - 2022-07-05 04:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:57:12 --> Total execution time: 0.1594
DEBUG - 2022-07-05 04:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:57:16 --> Total execution time: 0.0606
DEBUG - 2022-07-05 04:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:57:23 --> Total execution time: 0.0515
DEBUG - 2022-07-05 04:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:57:48 --> Total execution time: 0.0727
DEBUG - 2022-07-05 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:29:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:59:54 --> Total execution time: 0.0392
DEBUG - 2022-07-05 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:29:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:59:54 --> Total execution time: 0.0352
DEBUG - 2022-07-05 04:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:30:10 --> Total execution time: 0.0498
DEBUG - 2022-07-05 04:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:30:15 --> Total execution time: 0.0624
DEBUG - 2022-07-05 04:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:30:15 --> Total execution time: 0.0823
DEBUG - 2022-07-05 04:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:24 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:00:24 --> Total execution time: 0.0666
DEBUG - 2022-07-05 04:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:00:28 --> Total execution time: 0.0632
DEBUG - 2022-07-05 04:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:00:48 --> Total execution time: 0.0508
DEBUG - 2022-07-05 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:00:58 --> Total execution time: 0.0747
DEBUG - 2022-07-05 04:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:01:00 --> Total execution time: 0.1307
DEBUG - 2022-07-05 04:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:01:13 --> Total execution time: 0.0715
DEBUG - 2022-07-05 04:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:01:34 --> Total execution time: 0.0759
DEBUG - 2022-07-05 04:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:01:39 --> Total execution time: 0.0857
DEBUG - 2022-07-05 04:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:01:45 --> Total execution time: 0.0781
DEBUG - 2022-07-05 04:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:01:52 --> Total execution time: 0.0533
DEBUG - 2022-07-05 04:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:01:55 --> Total execution time: 0.0758
DEBUG - 2022-07-05 04:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:01:56 --> Total execution time: 0.0745
DEBUG - 2022-07-05 04:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:02:01 --> Total execution time: 0.0641
DEBUG - 2022-07-05 04:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:02:03 --> Total execution time: 0.0525
DEBUG - 2022-07-05 04:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:02:05 --> Total execution time: 0.0938
DEBUG - 2022-07-05 04:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:32:08 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:02:08 --> Total execution time: 0.0706
DEBUG - 2022-07-05 04:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:03:21 --> Total execution time: 0.0344
DEBUG - 2022-07-05 04:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:34:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:04:15 --> Total execution time: 0.1394
DEBUG - 2022-07-05 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:05:10 --> Total execution time: 0.0594
DEBUG - 2022-07-05 04:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:05:18 --> Total execution time: 0.0476
DEBUG - 2022-07-05 04:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:05:30 --> Total execution time: 0.0565
DEBUG - 2022-07-05 04:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:05:49 --> Total execution time: 0.0499
DEBUG - 2022-07-05 04:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:05:55 --> Total execution time: 0.0610
DEBUG - 2022-07-05 04:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:05:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 04:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:05:57 --> Total execution time: 0.0722
DEBUG - 2022-07-05 04:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:10 --> Total execution time: 0.0517
DEBUG - 2022-07-05 04:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:13 --> Total execution time: 0.0362
DEBUG - 2022-07-05 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:26 --> Total execution time: 0.0603
DEBUG - 2022-07-05 04:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:31 --> Total execution time: 0.0760
DEBUG - 2022-07-05 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:33 --> Total execution time: 0.0592
DEBUG - 2022-07-05 04:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:40 --> Total execution time: 0.0650
DEBUG - 2022-07-05 04:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:44 --> Total execution time: 0.0605
DEBUG - 2022-07-05 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:45 --> Total execution time: 0.0503
DEBUG - 2022-07-05 04:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:47 --> Total execution time: 0.0482
DEBUG - 2022-07-05 04:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:48 --> Total execution time: 0.0608
DEBUG - 2022-07-05 04:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:50 --> Total execution time: 0.0660
DEBUG - 2022-07-05 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:06:57 --> Total execution time: 0.0531
DEBUG - 2022-07-05 04:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:02 --> Total execution time: 0.0590
DEBUG - 2022-07-05 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:04 --> Total execution time: 0.0835
DEBUG - 2022-07-05 04:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:09 --> Total execution time: 0.0518
DEBUG - 2022-07-05 04:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 04:37:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 04:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 04:37:22 --> 404 Page Not Found: Product/premium-membership
DEBUG - 2022-07-05 04:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:27 --> Total execution time: 0.0484
DEBUG - 2022-07-05 04:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:34 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:34 --> Total execution time: 0.0424
DEBUG - 2022-07-05 04:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:36 --> Total execution time: 0.0533
DEBUG - 2022-07-05 04:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:37 --> Total execution time: 0.0636
DEBUG - 2022-07-05 04:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:37 --> Total execution time: 0.0840
DEBUG - 2022-07-05 04:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:40 --> Total execution time: 0.0577
DEBUG - 2022-07-05 04:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:37:45 --> Total execution time: 0.0333
DEBUG - 2022-07-05 04:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:37:49 --> Total execution time: 0.0526
DEBUG - 2022-07-05 04:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:37:50 --> Total execution time: 0.0607
DEBUG - 2022-07-05 04:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:07:59 --> Total execution time: 0.0485
DEBUG - 2022-07-05 04:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:08:26 --> Total execution time: 0.0497
DEBUG - 2022-07-05 04:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:08:29 --> Total execution time: 0.0556
DEBUG - 2022-07-05 04:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:08:32 --> Total execution time: 0.0501
DEBUG - 2022-07-05 04:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:08:34 --> Total execution time: 0.0589
DEBUG - 2022-07-05 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:08:40 --> Total execution time: 0.0533
DEBUG - 2022-07-05 04:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:08:49 --> Total execution time: 0.0496
DEBUG - 2022-07-05 04:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:08:56 --> Total execution time: 0.0497
DEBUG - 2022-07-05 04:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:09:04 --> Total execution time: 0.0564
DEBUG - 2022-07-05 04:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:09:11 --> Total execution time: 0.0535
DEBUG - 2022-07-05 04:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:09:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 04:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:09:12 --> Total execution time: 0.0484
DEBUG - 2022-07-05 04:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:09:38 --> Total execution time: 0.0539
DEBUG - 2022-07-05 04:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:09:38 --> Total execution time: 0.0517
DEBUG - 2022-07-05 04:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:09:52 --> Total execution time: 0.0626
DEBUG - 2022-07-05 04:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:09:54 --> Total execution time: 0.0523
DEBUG - 2022-07-05 04:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:11:09 --> Total execution time: 0.0791
DEBUG - 2022-07-05 04:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:12:23 --> Total execution time: 0.1286
DEBUG - 2022-07-05 04:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:12:50 --> Total execution time: 0.0317
DEBUG - 2022-07-05 04:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:13:00 --> Total execution time: 0.0513
DEBUG - 2022-07-05 04:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:13:01 --> Total execution time: 0.0699
DEBUG - 2022-07-05 04:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:13:08 --> Total execution time: 0.0615
DEBUG - 2022-07-05 04:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:13:10 --> Total execution time: 0.0799
DEBUG - 2022-07-05 04:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:13:23 --> Total execution time: 0.0534
DEBUG - 2022-07-05 04:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:13:50 --> Total execution time: 0.1341
DEBUG - 2022-07-05 04:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:13:55 --> Total execution time: 0.0496
DEBUG - 2022-07-05 04:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:14:26 --> Total execution time: 0.0492
DEBUG - 2022-07-05 04:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:44:28 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:14:28 --> Total execution time: 0.0674
DEBUG - 2022-07-05 04:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:14:32 --> Total execution time: 0.0481
DEBUG - 2022-07-05 04:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:14:34 --> Total execution time: 0.0655
DEBUG - 2022-07-05 04:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:14:36 --> Total execution time: 0.0533
DEBUG - 2022-07-05 04:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:15:25 --> Total execution time: 0.0699
DEBUG - 2022-07-05 04:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:16:23 --> Total execution time: 0.0616
DEBUG - 2022-07-05 04:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:17:16 --> Total execution time: 0.0406
DEBUG - 2022-07-05 04:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:17:16 --> Total execution time: 0.0358
DEBUG - 2022-07-05 04:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:17:20 --> Total execution time: 0.0349
DEBUG - 2022-07-05 04:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:17:26 --> Total execution time: 0.0607
DEBUG - 2022-07-05 04:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:17:29 --> Total execution time: 0.0947
DEBUG - 2022-07-05 04:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:30 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:17:30 --> Total execution time: 0.0444
DEBUG - 2022-07-05 04:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:17:33 --> Total execution time: 0.0783
DEBUG - 2022-07-05 04:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:17:54 --> Total execution time: 0.0557
DEBUG - 2022-07-05 04:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:47:59 --> Total execution time: 0.0539
DEBUG - 2022-07-05 04:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:48:00 --> Total execution time: 0.0545
DEBUG - 2022-07-05 04:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:48:00 --> Total execution time: 0.1239
DEBUG - 2022-07-05 04:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:49:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 04:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:19:37 --> Total execution time: 1.5647
DEBUG - 2022-07-05 04:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:49:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 04:49:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 04:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:19:56 --> Total execution time: 0.1365
DEBUG - 2022-07-05 04:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:20:48 --> Total execution time: 1.6132
DEBUG - 2022-07-05 04:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 04:50:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 04:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:23:18 --> Total execution time: 0.0532
DEBUG - 2022-07-05 04:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:23:34 --> Total execution time: 0.0618
DEBUG - 2022-07-05 04:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:23:45 --> Total execution time: 0.0485
DEBUG - 2022-07-05 04:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:23:54 --> Total execution time: 0.0604
DEBUG - 2022-07-05 04:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:23:56 --> Total execution time: 0.0531
DEBUG - 2022-07-05 04:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:23:56 --> Total execution time: 0.0549
DEBUG - 2022-07-05 04:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:25:14 --> Total execution time: 0.0671
DEBUG - 2022-07-05 04:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:25:19 --> Total execution time: 0.0658
DEBUG - 2022-07-05 04:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:25:27 --> Total execution time: 0.0544
DEBUG - 2022-07-05 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:25:30 --> Total execution time: 0.0944
DEBUG - 2022-07-05 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:25:42 --> Total execution time: 0.0622
DEBUG - 2022-07-05 04:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:25:51 --> Total execution time: 0.0497
DEBUG - 2022-07-05 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:25:51 --> Total execution time: 0.0760
DEBUG - 2022-07-05 04:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:26:25 --> Total execution time: 0.0660
DEBUG - 2022-07-05 04:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:56:36 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:26:36 --> Total execution time: 0.0521
DEBUG - 2022-07-05 04:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:56:46 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:26:46 --> Total execution time: 0.0819
DEBUG - 2022-07-05 04:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:26:51 --> Total execution time: 0.0531
DEBUG - 2022-07-05 04:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:27:13 --> Total execution time: 0.0591
DEBUG - 2022-07-05 04:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:27:18 --> Total execution time: 0.0564
DEBUG - 2022-07-05 04:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:57:35 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:27:35 --> Total execution time: 0.0521
DEBUG - 2022-07-05 04:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:57:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:27:50 --> Total execution time: 0.0577
DEBUG - 2022-07-05 04:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:22 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:28:22 --> Total execution time: 0.0414
DEBUG - 2022-07-05 04:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:58:28 --> Total execution time: 0.1328
DEBUG - 2022-07-05 04:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:58:30 --> Total execution time: 0.0823
DEBUG - 2022-07-05 04:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:58:30 --> Total execution time: 0.1192
DEBUG - 2022-07-05 04:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:28:46 --> Total execution time: 0.0806
DEBUG - 2022-07-05 04:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:58:49 --> Total execution time: 0.0563
DEBUG - 2022-07-05 04:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 04:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:28:50 --> Total execution time: 0.0449
DEBUG - 2022-07-05 04:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:58:50 --> Total execution time: 0.0664
DEBUG - 2022-07-05 04:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:58:50 --> Total execution time: 0.0800
DEBUG - 2022-07-05 04:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:28:59 --> Total execution time: 0.0486
DEBUG - 2022-07-05 04:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:29:03 --> Total execution time: 0.0635
DEBUG - 2022-07-05 04:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:29:03 --> Total execution time: 0.0476
DEBUG - 2022-07-05 04:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:29:09 --> Total execution time: 0.0562
DEBUG - 2022-07-05 04:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:29:15 --> Total execution time: 0.0813
DEBUG - 2022-07-05 04:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 04:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 04:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 04:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:00:00 --> Total execution time: 0.0585
DEBUG - 2022-07-05 05:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:00:01 --> Total execution time: 0.0575
DEBUG - 2022-07-05 05:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:00:01 --> Total execution time: 0.1096
DEBUG - 2022-07-05 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:30:02 --> Total execution time: 0.0627
DEBUG - 2022-07-05 05:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:00:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:30:07 --> Total execution time: 0.1277
DEBUG - 2022-07-05 05:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:00:30 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:30:30 --> Total execution time: 0.0531
DEBUG - 2022-07-05 05:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:30:43 --> Total execution time: 0.0478
DEBUG - 2022-07-05 05:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:01:19 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:31:19 --> Total execution time: 0.0551
DEBUG - 2022-07-05 05:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:31:25 --> Total execution time: 0.0488
DEBUG - 2022-07-05 05:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 05:02:21 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 05:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:32:30 --> Total execution time: 0.0435
DEBUG - 2022-07-05 05:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:02:35 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:32:35 --> Total execution time: 0.0639
DEBUG - 2022-07-05 05:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:33:12 --> Total execution time: 0.0577
DEBUG - 2022-07-05 05:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:04:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 05:04:52 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 05:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:36:16 --> Total execution time: 0.0669
DEBUG - 2022-07-05 05:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:36:21 --> Total execution time: 0.0487
DEBUG - 2022-07-05 05:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:36:34 --> Total execution time: 0.0642
DEBUG - 2022-07-05 05:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:36:40 --> Total execution time: 0.1024
DEBUG - 2022-07-05 05:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:36:49 --> Total execution time: 0.0536
DEBUG - 2022-07-05 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:36:52 --> Total execution time: 0.0694
DEBUG - 2022-07-05 05:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:36:54 --> Total execution time: 0.0589
DEBUG - 2022-07-05 05:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:06:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 05:06:55 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 05:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:07:02 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:37:02 --> Total execution time: 0.0369
DEBUG - 2022-07-05 05:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:07:02 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:37:02 --> Total execution time: 0.0419
DEBUG - 2022-07-05 05:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:37:45 --> Total execution time: 0.0326
DEBUG - 2022-07-05 05:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:37:51 --> Total execution time: 0.1307
DEBUG - 2022-07-05 05:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:37:53 --> Total execution time: 0.0508
DEBUG - 2022-07-05 05:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:37:54 --> Total execution time: 0.0333
DEBUG - 2022-07-05 05:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:37:55 --> Total execution time: 0.0324
DEBUG - 2022-07-05 05:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:07:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:37:57 --> Total execution time: 0.0340
DEBUG - 2022-07-05 05:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:09:04 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:39:04 --> Total execution time: 0.0513
DEBUG - 2022-07-05 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:09:46 --> Total execution time: 0.0580
DEBUG - 2022-07-05 05:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:09:47 --> Total execution time: 0.0560
DEBUG - 2022-07-05 05:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:09:47 --> Total execution time: 0.1043
DEBUG - 2022-07-05 05:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:10:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:40:16 --> Total execution time: 0.0531
DEBUG - 2022-07-05 05:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:40:27 --> Total execution time: 0.0515
DEBUG - 2022-07-05 05:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:40:44 --> Total execution time: 0.0514
DEBUG - 2022-07-05 05:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:10:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:40:51 --> Total execution time: 1.4959
DEBUG - 2022-07-05 05:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:10:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 05:10:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 05:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:41:19 --> Total execution time: 0.0504
DEBUG - 2022-07-05 05:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:41:23 --> Total execution time: 0.0595
DEBUG - 2022-07-05 05:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:41:25 --> Total execution time: 0.0568
DEBUG - 2022-07-05 05:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:41:32 --> Total execution time: 0.0467
DEBUG - 2022-07-05 05:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:41:42 --> Total execution time: 0.0524
DEBUG - 2022-07-05 05:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:41:54 --> Total execution time: 0.0675
DEBUG - 2022-07-05 05:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:42:03 --> Total execution time: 0.0534
DEBUG - 2022-07-05 05:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:42:13 --> Total execution time: 0.1300
DEBUG - 2022-07-05 05:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:42:19 --> Total execution time: 0.0537
DEBUG - 2022-07-05 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:42:19 --> Total execution time: 0.0718
DEBUG - 2022-07-05 05:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:42:27 --> Total execution time: 0.0807
DEBUG - 2022-07-05 05:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:42:27 --> Total execution time: 0.0506
DEBUG - 2022-07-05 05:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:42:33 --> Total execution time: 0.0696
DEBUG - 2022-07-05 05:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:35 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:42:35 --> Total execution time: 0.0560
DEBUG - 2022-07-05 05:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:12:44 --> Total execution time: 0.0538
DEBUG - 2022-07-05 05:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:12:47 --> Total execution time: 0.0763
DEBUG - 2022-07-05 05:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:12:47 --> Total execution time: 0.0810
DEBUG - 2022-07-05 05:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:13:28 --> Total execution time: 0.0570
DEBUG - 2022-07-05 05:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:13:29 --> Total execution time: 0.0891
DEBUG - 2022-07-05 05:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:13:29 --> Total execution time: 0.1179
DEBUG - 2022-07-05 05:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:43:42 --> Total execution time: 0.0473
DEBUG - 2022-07-05 05:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:01 --> Total execution time: 0.0493
DEBUG - 2022-07-05 05:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:02 --> Total execution time: 0.0698
DEBUG - 2022-07-05 05:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:02 --> Total execution time: 0.1002
DEBUG - 2022-07-05 05:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:26 --> Total execution time: 0.0529
DEBUG - 2022-07-05 05:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:27 --> Total execution time: 0.0649
DEBUG - 2022-07-05 05:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:27 --> Total execution time: 0.1260
DEBUG - 2022-07-05 05:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:44:27 --> Total execution time: 0.0721
DEBUG - 2022-07-05 05:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:32 --> Total execution time: 0.0536
DEBUG - 2022-07-05 05:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:33 --> Total execution time: 0.0456
DEBUG - 2022-07-05 05:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:33 --> Total execution time: 0.0544
DEBUG - 2022-07-05 05:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:33 --> Total execution time: 0.0510
DEBUG - 2022-07-05 05:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:34 --> Total execution time: 0.0509
DEBUG - 2022-07-05 05:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:34 --> Total execution time: 0.1205
DEBUG - 2022-07-05 05:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:44:41 --> Total execution time: 0.0765
DEBUG - 2022-07-05 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:42 --> Total execution time: 0.0572
DEBUG - 2022-07-05 05:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:43 --> Total execution time: 0.0862
DEBUG - 2022-07-05 05:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:14:43 --> Total execution time: 0.0966
DEBUG - 2022-07-05 05:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:44:47 --> Total execution time: 0.0369
DEBUG - 2022-07-05 05:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:44:47 --> Total execution time: 0.0343
DEBUG - 2022-07-05 05:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:44:55 --> Total execution time: 0.0823
DEBUG - 2022-07-05 05:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:45:00 --> Total execution time: 0.1176
DEBUG - 2022-07-05 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 05:15:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 05:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:45:20 --> Total execution time: 0.0452
DEBUG - 2022-07-05 05:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:15:27 --> Total execution time: 0.0535
DEBUG - 2022-07-05 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:15:36 --> Total execution time: 0.0540
DEBUG - 2022-07-05 05:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:15:36 --> Total execution time: 0.0821
DEBUG - 2022-07-05 05:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:45:41 --> Total execution time: 0.0467
DEBUG - 2022-07-05 05:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:45:46 --> Total execution time: 0.0333
DEBUG - 2022-07-05 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:03 --> Total execution time: 0.0712
DEBUG - 2022-07-05 05:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:05 --> Total execution time: 0.0386
DEBUG - 2022-07-05 05:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:06 --> Total execution time: 0.0551
DEBUG - 2022-07-05 05:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:07 --> Total execution time: 0.0545
DEBUG - 2022-07-05 05:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:07 --> Total execution time: 0.1235
DEBUG - 2022-07-05 05:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:23 --> Total execution time: 0.0685
DEBUG - 2022-07-05 05:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:25 --> Total execution time: 0.0373
DEBUG - 2022-07-05 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:36 --> Total execution time: 0.1022
DEBUG - 2022-07-05 05:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:37 --> Total execution time: 0.0349
DEBUG - 2022-07-05 05:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:37 --> Total execution time: 0.0745
DEBUG - 2022-07-05 05:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:38 --> Total execution time: 0.0501
DEBUG - 2022-07-05 05:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:39 --> Total execution time: 0.0534
DEBUG - 2022-07-05 05:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:39 --> Total execution time: 0.1044
DEBUG - 2022-07-05 05:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:40 --> Total execution time: 0.0369
DEBUG - 2022-07-05 05:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:54 --> Total execution time: 0.0364
DEBUG - 2022-07-05 05:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:46:56 --> Total execution time: 0.0553
DEBUG - 2022-07-05 05:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:02 --> Total execution time: 0.0955
DEBUG - 2022-07-05 05:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:05 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:06 --> Total execution time: 0.0611
DEBUG - 2022-07-05 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:13 --> Total execution time: 0.0671
DEBUG - 2022-07-05 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:15 --> Total execution time: 0.2042
DEBUG - 2022-07-05 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:15 --> Total execution time: 0.0739
DEBUG - 2022-07-05 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:15 --> Total execution time: 0.0881
DEBUG - 2022-07-05 05:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:17 --> Total execution time: 0.0490
DEBUG - 2022-07-05 05:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:19 --> Total execution time: 0.0534
DEBUG - 2022-07-05 05:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:22 --> Total execution time: 0.0767
DEBUG - 2022-07-05 05:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:23 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:23 --> Total execution time: 0.0349
DEBUG - 2022-07-05 05:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:25 --> Total execution time: 0.0649
DEBUG - 2022-07-05 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:27 --> Total execution time: 0.0808
DEBUG - 2022-07-05 05:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:29 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:29 --> Total execution time: 0.0531
DEBUG - 2022-07-05 05:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:30 --> Total execution time: 0.1015
DEBUG - 2022-07-05 05:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:47:33 --> Total execution time: 0.0630
DEBUG - 2022-07-05 05:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:01 --> Total execution time: 0.0529
DEBUG - 2022-07-05 05:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:09 --> Total execution time: 0.0591
DEBUG - 2022-07-05 05:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:10 --> Total execution time: 0.0583
DEBUG - 2022-07-05 05:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:12 --> Total execution time: 0.0530
DEBUG - 2022-07-05 05:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:15 --> Total execution time: 0.0502
DEBUG - 2022-07-05 05:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:16 --> Total execution time: 0.0471
DEBUG - 2022-07-05 05:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:16 --> Total execution time: 0.0807
DEBUG - 2022-07-05 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:16 --> Total execution time: 0.0613
DEBUG - 2022-07-05 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:16 --> Total execution time: 0.0613
DEBUG - 2022-07-05 05:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:17 --> Total execution time: 0.0753
DEBUG - 2022-07-05 05:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:17 --> Total execution time: 0.0503
DEBUG - 2022-07-05 05:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:48:20 --> Total execution time: 0.0527
DEBUG - 2022-07-05 05:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:22 --> Total execution time: 0.0400
DEBUG - 2022-07-05 05:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:23 --> Total execution time: 0.0395
DEBUG - 2022-07-05 05:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:23 --> Total execution time: 0.0373
DEBUG - 2022-07-05 05:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:25 --> Total execution time: 0.0647
DEBUG - 2022-07-05 05:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:18:25 --> Total execution time: 0.0521
DEBUG - 2022-07-05 05:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:49:08 --> Total execution time: 0.0744
DEBUG - 2022-07-05 05:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:49:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:49:09 --> Total execution time: 0.0480
DEBUG - 2022-07-05 05:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:50:44 --> Total execution time: 0.0534
DEBUG - 2022-07-05 05:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:20:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:50:49 --> Total execution time: 0.1304
DEBUG - 2022-07-05 05:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:50:49 --> Total execution time: 0.0605
DEBUG - 2022-07-05 05:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:50:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:50:50 --> Total execution time: 0.0525
DEBUG - 2022-07-05 05:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:02 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:02 --> Total execution time: 0.0549
DEBUG - 2022-07-05 05:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:06 --> Total execution time: 0.0825
DEBUG - 2022-07-05 05:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:09 --> Total execution time: 0.0485
DEBUG - 2022-07-05 05:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:10 --> Total execution time: 0.0750
DEBUG - 2022-07-05 05:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:12 --> Total execution time: 0.0520
DEBUG - 2022-07-05 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:14 --> Total execution time: 0.0622
DEBUG - 2022-07-05 05:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:14 --> Total execution time: 0.1102
DEBUG - 2022-07-05 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:14 --> Total execution time: 0.0654
DEBUG - 2022-07-05 05:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:16 --> Total execution time: 0.0503
DEBUG - 2022-07-05 05:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:18 --> Total execution time: 0.0497
DEBUG - 2022-07-05 05:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:21 --> Total execution time: 0.0550
DEBUG - 2022-07-05 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:25 --> Total execution time: 0.0592
DEBUG - 2022-07-05 05:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:28 --> Total execution time: 0.0534
DEBUG - 2022-07-05 05:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:35 --> Total execution time: 0.0600
DEBUG - 2022-07-05 05:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:41 --> Total execution time: 0.0521
DEBUG - 2022-07-05 05:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:43 --> Total execution time: 0.0627
DEBUG - 2022-07-05 05:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:43 --> Total execution time: 0.0996
DEBUG - 2022-07-05 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:45 --> Total execution time: 0.0541
DEBUG - 2022-07-05 05:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:46 --> Total execution time: 0.0570
DEBUG - 2022-07-05 05:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:50 --> Total execution time: 0.0515
DEBUG - 2022-07-05 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:54 --> Total execution time: 0.0647
DEBUG - 2022-07-05 05:21:54 --> Total execution time: 0.1145
DEBUG - 2022-07-05 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:57 --> Total execution time: 0.0504
DEBUG - 2022-07-05 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:51:57 --> Total execution time: 0.0577
DEBUG - 2022-07-05 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:52:01 --> Total execution time: 0.0884
DEBUG - 2022-07-05 05:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:52:05 --> Total execution time: 0.1047
DEBUG - 2022-07-05 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:52:09 --> Total execution time: 0.0624
DEBUG - 2022-07-05 05:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:52:16 --> Total execution time: 0.0593
DEBUG - 2022-07-05 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:22:34 --> Total execution time: 0.0754
DEBUG - 2022-07-05 05:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:52:45 --> Total execution time: 0.0569
DEBUG - 2022-07-05 05:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:52:53 --> Total execution time: 0.1230
DEBUG - 2022-07-05 05:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:52:56 --> Total execution time: 0.0544
DEBUG - 2022-07-05 05:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:00 --> Total execution time: 0.0541
DEBUG - 2022-07-05 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:05 --> Total execution time: 0.1332
DEBUG - 2022-07-05 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:05 --> Total execution time: 0.0752
DEBUG - 2022-07-05 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:05 --> Total execution time: 0.0544
DEBUG - 2022-07-05 05:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:07 --> Total execution time: 0.0507
DEBUG - 2022-07-05 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:12 --> Total execution time: 0.0858
DEBUG - 2022-07-05 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:15 --> Total execution time: 0.0608
DEBUG - 2022-07-05 05:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:17 --> Total execution time: 0.0776
DEBUG - 2022-07-05 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:20 --> Total execution time: 0.0837
DEBUG - 2022-07-05 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:23:24 --> Total execution time: 0.0894
DEBUG - 2022-07-05 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:25 --> Total execution time: 0.0522
DEBUG - 2022-07-05 05:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:28 --> Total execution time: 0.0874
DEBUG - 2022-07-05 05:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:32 --> Total execution time: 0.0839
DEBUG - 2022-07-05 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:34 --> Total execution time: 0.0545
DEBUG - 2022-07-05 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:35 --> Total execution time: 0.0689
DEBUG - 2022-07-05 05:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:35 --> Total execution time: 0.0570
DEBUG - 2022-07-05 05:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:38 --> Total execution time: 0.0626
DEBUG - 2022-07-05 05:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:23:45 --> Total execution time: 0.0476
DEBUG - 2022-07-05 05:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:48 --> Total execution time: 0.0578
DEBUG - 2022-07-05 05:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:23:52 --> Total execution time: 0.0486
DEBUG - 2022-07-05 05:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:55 --> Total execution time: 0.0755
DEBUG - 2022-07-05 05:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:55 --> Total execution time: 0.0781
DEBUG - 2022-07-05 05:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:55 --> Total execution time: 0.0621
DEBUG - 2022-07-05 05:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:53:59 --> Total execution time: 0.0572
DEBUG - 2022-07-05 05:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:24:00 --> Total execution time: 0.0578
DEBUG - 2022-07-05 05:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:54:17 --> Total execution time: 0.0534
DEBUG - 2022-07-05 05:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:24:19 --> Total execution time: 0.0854
DEBUG - 2022-07-05 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:54:24 --> Total execution time: 0.0603
DEBUG - 2022-07-05 05:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:54:27 --> Total execution time: 0.0536
DEBUG - 2022-07-05 05:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:54:28 --> Total execution time: 0.0488
DEBUG - 2022-07-05 05:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:54:33 --> Total execution time: 0.0830
DEBUG - 2022-07-05 05:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:54:48 --> Total execution time: 0.0733
DEBUG - 2022-07-05 05:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:24:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:54:49 --> Total execution time: 0.1327
DEBUG - 2022-07-05 05:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:25:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:55:00 --> Total execution time: 0.1293
DEBUG - 2022-07-05 05:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:55:06 --> Total execution time: 0.0492
DEBUG - 2022-07-05 05:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:55:20 --> Total execution time: 0.0699
DEBUG - 2022-07-05 05:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:55:27 --> Total execution time: 0.0704
DEBUG - 2022-07-05 05:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:55:33 --> Total execution time: 0.0629
DEBUG - 2022-07-05 05:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:55:46 --> Total execution time: 0.0522
DEBUG - 2022-07-05 05:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:25:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:55:47 --> Total execution time: 0.0424
DEBUG - 2022-07-05 05:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:06 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:56:06 --> Total execution time: 0.0611
DEBUG - 2022-07-05 05:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:26:23 --> Total execution time: 0.0530
DEBUG - 2022-07-05 05:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:26:25 --> Total execution time: 0.0521
DEBUG - 2022-07-05 05:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:26:25 --> Total execution time: 0.1075
DEBUG - 2022-07-05 05:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:29 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:56:29 --> Total execution time: 0.0503
DEBUG - 2022-07-05 05:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:56:31 --> Total execution time: 0.0529
DEBUG - 2022-07-05 05:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:56:42 --> Total execution time: 0.0503
DEBUG - 2022-07-05 05:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:45 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:56:45 --> Total execution time: 0.0718
DEBUG - 2022-07-05 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:56:54 --> Total execution time: 0.0530
DEBUG - 2022-07-05 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:56:55 --> Total execution time: 0.0985
DEBUG - 2022-07-05 05:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:57:04 --> Total execution time: 0.0562
DEBUG - 2022-07-05 05:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:57:20 --> Total execution time: 0.0501
DEBUG - 2022-07-05 05:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:57:33 --> Total execution time: 0.0552
DEBUG - 2022-07-05 05:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:57:42 --> Total execution time: 0.1489
DEBUG - 2022-07-05 05:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:57:43 --> Total execution time: 0.0707
DEBUG - 2022-07-05 05:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:57:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:57:44 --> Total execution time: 0.0836
DEBUG - 2022-07-05 05:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:58:17 --> Total execution time: 0.0635
DEBUG - 2022-07-05 05:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:58:33 --> Total execution time: 0.0739
DEBUG - 2022-07-05 05:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:58:40 --> Total execution time: 0.0829
DEBUG - 2022-07-05 05:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:58:53 --> Total execution time: 0.0507
DEBUG - 2022-07-05 05:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:58:56 --> Total execution time: 0.0586
DEBUG - 2022-07-05 05:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:07 --> Total execution time: 0.0966
DEBUG - 2022-07-05 05:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:10 --> Total execution time: 0.0542
DEBUG - 2022-07-05 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:21 --> Total execution time: 0.0553
DEBUG - 2022-07-05 05:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:29 --> Total execution time: 0.0329
DEBUG - 2022-07-05 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:32 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:32 --> Total execution time: 0.0627
DEBUG - 2022-07-05 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:32 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:32 --> Total execution time: 0.0559
DEBUG - 2022-07-05 05:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:49 --> Total execution time: 0.0507
DEBUG - 2022-07-05 05:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:55 --> Total execution time: 0.0493
DEBUG - 2022-07-05 05:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:29:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:59:59 --> Total execution time: 0.0562
DEBUG - 2022-07-05 05:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:00:02 --> Total execution time: 0.1608
DEBUG - 2022-07-05 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:00:11 --> Total execution time: 0.0630
DEBUG - 2022-07-05 05:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:12 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:00:12 --> Total execution time: 0.0608
DEBUG - 2022-07-05 05:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 05:30:15 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 05:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:00:23 --> Total execution time: 0.0491
DEBUG - 2022-07-05 05:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:00:53 --> Total execution time: 0.0489
DEBUG - 2022-07-05 05:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:00:57 --> Total execution time: 0.0578
DEBUG - 2022-07-05 05:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:06 --> Total execution time: 0.0546
DEBUG - 2022-07-05 05:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:07 --> Total execution time: 0.0726
DEBUG - 2022-07-05 05:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:13 --> Total execution time: 0.1602
DEBUG - 2022-07-05 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:15 --> Total execution time: 0.1363
DEBUG - 2022-07-05 05:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:15 --> Total execution time: 0.0840
DEBUG - 2022-07-05 05:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:15 --> Total execution time: 0.0924
DEBUG - 2022-07-05 05:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:15 --> Total execution time: 0.0681
DEBUG - 2022-07-05 05:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:16 --> Total execution time: 0.0518
DEBUG - 2022-07-05 05:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:16 --> Total execution time: 0.0636
DEBUG - 2022-07-05 05:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:31 --> Total execution time: 0.0974
DEBUG - 2022-07-05 05:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:47 --> Total execution time: 0.0728
DEBUG - 2022-07-05 05:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:49 --> Total execution time: 0.0881
DEBUG - 2022-07-05 05:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:01:54 --> Total execution time: 0.0925
DEBUG - 2022-07-05 05:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:02:02 --> Total execution time: 0.0534
DEBUG - 2022-07-05 05:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:02:02 --> Total execution time: 0.0841
DEBUG - 2022-07-05 05:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:02:04 --> Total execution time: 0.0834
DEBUG - 2022-07-05 05:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:02:19 --> Total execution time: 0.0946
DEBUG - 2022-07-05 05:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:02:24 --> Total execution time: 0.0536
DEBUG - 2022-07-05 05:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:02:52 --> Total execution time: 0.0378
DEBUG - 2022-07-05 05:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:03:13 --> Total execution time: 0.1194
DEBUG - 2022-07-05 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:03:17 --> Total execution time: 0.0611
DEBUG - 2022-07-05 05:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:03:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:03:18 --> Total execution time: 0.0489
DEBUG - 2022-07-05 05:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:03:42 --> Total execution time: 0.0862
DEBUG - 2022-07-05 05:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:04:22 --> Total execution time: 0.0954
DEBUG - 2022-07-05 05:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:04:37 --> Total execution time: 0.0596
DEBUG - 2022-07-05 05:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:35:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:05:40 --> Total execution time: 0.0509
DEBUG - 2022-07-05 05:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:35:49 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:05:49 --> Total execution time: 0.0428
DEBUG - 2022-07-05 05:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:35:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:06:00 --> Total execution time: 0.1399
DEBUG - 2022-07-05 05:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:36:06 --> Total execution time: 0.0615
DEBUG - 2022-07-05 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:36:07 --> Total execution time: 0.0618
DEBUG - 2022-07-05 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:36:07 --> Total execution time: 0.0810
DEBUG - 2022-07-05 05:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:06:25 --> Total execution time: 0.0617
DEBUG - 2022-07-05 05:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:36:27 --> Total execution time: 0.0585
DEBUG - 2022-07-05 05:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:06:28 --> Total execution time: 0.0285
DEBUG - 2022-07-05 05:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:35 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:06:35 --> Total execution time: 0.0684
DEBUG - 2022-07-05 05:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:06:37 --> Total execution time: 0.0632
DEBUG - 2022-07-05 05:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:06:40 --> Total execution time: 0.0531
DEBUG - 2022-07-05 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:36:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:06:47 --> Total execution time: 0.0582
DEBUG - 2022-07-05 05:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:37:00 --> Total execution time: 0.0531
DEBUG - 2022-07-05 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:37:01 --> Total execution time: 0.0678
DEBUG - 2022-07-05 05:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:37:01 --> Total execution time: 0.1082
DEBUG - 2022-07-05 05:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:37:04 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:07:04 --> Total execution time: 0.0589
DEBUG - 2022-07-05 05:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:07:19 --> Total execution time: 0.0499
DEBUG - 2022-07-05 05:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:37:39 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:07:39 --> Total execution time: 0.0828
DEBUG - 2022-07-05 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:07:44 --> Total execution time: 0.0821
DEBUG - 2022-07-05 05:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:37:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:07:56 --> Total execution time: 0.1165
DEBUG - 2022-07-05 05:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:05 --> Total execution time: 0.0790
DEBUG - 2022-07-05 05:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:06 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:06 --> Total execution time: 0.1707
DEBUG - 2022-07-05 05:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:13 --> Total execution time: 0.0912
DEBUG - 2022-07-05 05:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:15 --> Total execution time: 0.0639
DEBUG - 2022-07-05 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:16 --> Total execution time: 0.0480
DEBUG - 2022-07-05 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:17 --> Total execution time: 0.0785
DEBUG - 2022-07-05 05:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:21 --> Total execution time: 0.0501
DEBUG - 2022-07-05 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:27 --> Total execution time: 0.0946
DEBUG - 2022-07-05 05:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:29 --> Total execution time: 0.0453
DEBUG - 2022-07-05 05:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:34 --> Total execution time: 0.0574
DEBUG - 2022-07-05 05:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 05:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:08:35 --> Total execution time: 0.0762
DEBUG - 2022-07-05 05:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:09:06 --> Total execution time: 0.1215
DEBUG - 2022-07-05 05:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:09:37 --> Total execution time: 0.0554
DEBUG - 2022-07-05 05:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:09:47 --> Total execution time: 0.0516
DEBUG - 2022-07-05 05:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:10:46 --> Total execution time: 0.0594
DEBUG - 2022-07-05 05:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:40:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:10:56 --> Total execution time: 0.0565
DEBUG - 2022-07-05 05:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:46:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:16:13 --> Total execution time: 0.1471
DEBUG - 2022-07-05 05:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:16:20 --> Total execution time: 0.0357
DEBUG - 2022-07-05 05:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:16:53 --> Total execution time: 0.0533
DEBUG - 2022-07-05 05:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:48:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:18:09 --> Total execution time: 0.0529
DEBUG - 2022-07-05 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:18:13 --> Total execution time: 0.1352
DEBUG - 2022-07-05 05:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:49:21 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:19:21 --> Total execution time: 0.0481
DEBUG - 2022-07-05 05:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:49:45 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:19:45 --> Total execution time: 0.0726
DEBUG - 2022-07-05 05:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:19:48 --> Total execution time: 0.0686
DEBUG - 2022-07-05 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:07 --> Total execution time: 0.0633
DEBUG - 2022-07-05 05:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:08 --> Total execution time: 0.0665
DEBUG - 2022-07-05 05:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:19 --> Total execution time: 0.1485
DEBUG - 2022-07-05 05:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:22 --> Total execution time: 0.0532
DEBUG - 2022-07-05 05:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:27 --> Total execution time: 0.0500
DEBUG - 2022-07-05 05:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:28 --> Total execution time: 0.0575
DEBUG - 2022-07-05 05:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:32 --> Total execution time: 0.0537
DEBUG - 2022-07-05 05:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:33 --> Total execution time: 0.0564
DEBUG - 2022-07-05 05:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:34 --> Total execution time: 0.0593
DEBUG - 2022-07-05 05:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:35 --> Total execution time: 0.0520
DEBUG - 2022-07-05 05:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:20:54 --> Total execution time: 0.0510
DEBUG - 2022-07-05 05:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:05 --> Total execution time: 0.0894
DEBUG - 2022-07-05 05:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:29 --> Total execution time: 0.0669
DEBUG - 2022-07-05 05:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:37 --> Total execution time: 0.0687
DEBUG - 2022-07-05 05:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:38 --> Total execution time: 0.0535
DEBUG - 2022-07-05 05:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:55 --> Total execution time: 0.0520
DEBUG - 2022-07-05 05:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:59 --> Total execution time: 0.0772
DEBUG - 2022-07-05 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:22:26 --> Total execution time: 0.1027
DEBUG - 2022-07-05 05:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:22:42 --> Total execution time: 0.0609
DEBUG - 2022-07-05 05:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:22:51 --> Total execution time: 0.0711
DEBUG - 2022-07-05 05:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:22:54 --> Total execution time: 0.0739
DEBUG - 2022-07-05 05:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:23:31 --> Total execution time: 0.0709
DEBUG - 2022-07-05 05:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:33 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:23:33 --> Total execution time: 0.0445
DEBUG - 2022-07-05 05:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:23:34 --> Total execution time: 0.0723
DEBUG - 2022-07-05 05:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:23:38 --> Total execution time: 0.0470
DEBUG - 2022-07-05 05:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:23:38 --> Total execution time: 0.0577
DEBUG - 2022-07-05 05:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:23:45 --> Total execution time: 0.0610
DEBUG - 2022-07-05 05:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:23:53 --> Total execution time: 0.0635
DEBUG - 2022-07-05 05:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:23:59 --> Total execution time: 0.1227
DEBUG - 2022-07-05 05:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:25:58 --> Total execution time: 0.0763
DEBUG - 2022-07-05 05:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:26:07 --> Total execution time: 0.0743
DEBUG - 2022-07-05 05:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:26:12 --> Total execution time: 0.0961
DEBUG - 2022-07-05 05:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:26:28 --> Total execution time: 0.0560
DEBUG - 2022-07-05 05:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:27:04 --> Total execution time: 0.1422
DEBUG - 2022-07-05 05:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:27:06 --> Total execution time: 0.0718
DEBUG - 2022-07-05 05:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:27:09 --> Total execution time: 0.0713
DEBUG - 2022-07-05 05:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:27:16 --> Total execution time: 0.0565
DEBUG - 2022-07-05 05:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:27:20 --> Total execution time: 0.0873
DEBUG - 2022-07-05 05:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:22 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:27:22 --> Total execution time: 0.0542
DEBUG - 2022-07-05 05:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:27:33 --> Total execution time: 1.5157
DEBUG - 2022-07-05 05:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 05:57:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 05:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:57:55 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:27:55 --> Total execution time: 0.1329
DEBUG - 2022-07-05 05:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:58:02 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:28:02 --> Total execution time: 0.0609
DEBUG - 2022-07-05 05:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:28:05 --> Total execution time: 0.0699
DEBUG - 2022-07-05 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:58:12 --> No URI present. Default controller set.
DEBUG - 2022-07-05 05:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:28:12 --> Total execution time: 0.0944
DEBUG - 2022-07-05 05:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:28:17 --> Total execution time: 0.1154
DEBUG - 2022-07-05 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:28:18 --> Total execution time: 0.1359
DEBUG - 2022-07-05 05:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:28:19 --> Total execution time: 0.0738
DEBUG - 2022-07-05 05:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:29:15 --> Total execution time: 0.0757
DEBUG - 2022-07-05 05:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:29:23 --> Total execution time: 0.0853
DEBUG - 2022-07-05 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 05:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:29:25 --> Total execution time: 0.0688
DEBUG - 2022-07-05 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 05:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 05:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:29:30 --> Total execution time: 0.0954
DEBUG - 2022-07-05 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:30:02 --> Total execution time: 0.0683
DEBUG - 2022-07-05 06:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:24 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:30:24 --> Total execution time: 0.0370
DEBUG - 2022-07-05 06:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:30:32 --> Total execution time: 0.1235
DEBUG - 2022-07-05 06:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:30:33 --> Total execution time: 0.0613
DEBUG - 2022-07-05 06:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:30:36 --> Total execution time: 0.0585
DEBUG - 2022-07-05 06:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:30:39 --> Total execution time: 0.0726
DEBUG - 2022-07-05 06:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:30:49 --> Total execution time: 0.0537
DEBUG - 2022-07-05 06:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:30:50 --> Total execution time: 0.0804
DEBUG - 2022-07-05 06:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:01 --> Total execution time: 0.0484
DEBUG - 2022-07-05 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:03 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:03 --> Total execution time: 0.0433
DEBUG - 2022-07-05 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:03 --> Total execution time: 0.0485
DEBUG - 2022-07-05 06:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:05 --> Total execution time: 0.0572
DEBUG - 2022-07-05 06:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:06 --> Total execution time: 0.0346
DEBUG - 2022-07-05 06:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:07 --> Total execution time: 0.0497
DEBUG - 2022-07-05 06:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:08 --> Total execution time: 0.0480
DEBUG - 2022-07-05 06:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:08 --> Total execution time: 0.0516
DEBUG - 2022-07-05 06:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:10 --> Total execution time: 0.1423
DEBUG - 2022-07-05 06:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:12 --> Total execution time: 0.0543
DEBUG - 2022-07-05 06:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:15 --> Total execution time: 0.0581
DEBUG - 2022-07-05 06:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:17 --> Total execution time: 0.0721
DEBUG - 2022-07-05 06:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:17 --> Total execution time: 0.0759
DEBUG - 2022-07-05 06:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:23 --> Total execution time: 0.1615
DEBUG - 2022-07-05 06:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:28 --> Total execution time: 0.0412
DEBUG - 2022-07-05 06:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:43 --> Total execution time: 0.0486
DEBUG - 2022-07-05 06:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:01:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:31:52 --> Total execution time: 0.1764
DEBUG - 2022-07-05 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:32:02 --> Total execution time: 0.0620
DEBUG - 2022-07-05 06:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:02:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:32:09 --> Total execution time: 0.0807
DEBUG - 2022-07-05 06:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:32:20 --> Total execution time: 0.0883
DEBUG - 2022-07-05 06:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:32:31 --> Total execution time: 0.1982
DEBUG - 2022-07-05 06:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:32:36 --> Total execution time: 0.0617
DEBUG - 2022-07-05 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:32:40 --> Total execution time: 0.0714
DEBUG - 2022-07-05 06:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:01 --> Total execution time: 0.0835
DEBUG - 2022-07-05 06:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:02 --> Total execution time: 0.0748
DEBUG - 2022-07-05 06:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:06 --> Total execution time: 0.1639
DEBUG - 2022-07-05 16:33:07 --> Total execution time: 1.6759
DEBUG - 2022-07-05 06:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:07 --> Total execution time: 0.0906
DEBUG - 2022-07-05 06:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:09 --> Total execution time: 0.0996
DEBUG - 2022-07-05 06:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:11 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:12 --> Total execution time: 0.0867
DEBUG - 2022-07-05 06:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:12 --> Total execution time: 0.0956
DEBUG - 2022-07-05 06:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:14 --> Total execution time: 0.0413
DEBUG - 2022-07-05 06:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 06:03:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 06:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:16 --> Total execution time: 0.0941
DEBUG - 2022-07-05 06:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:20 --> Total execution time: 0.1186
DEBUG - 2022-07-05 06:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:22 --> Total execution time: 0.0614
DEBUG - 2022-07-05 06:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:26 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:26 --> Total execution time: 0.0682
DEBUG - 2022-07-05 06:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:03:39 --> Total execution time: 0.0615
DEBUG - 2022-07-05 06:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:42 --> Total execution time: 0.0665
DEBUG - 2022-07-05 06:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:33:59 --> Total execution time: 0.0670
DEBUG - 2022-07-05 06:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:34:15 --> Total execution time: 0.0658
DEBUG - 2022-07-05 06:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:34:25 --> Total execution time: 0.0491
DEBUG - 2022-07-05 06:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:34:27 --> Total execution time: 0.1171
DEBUG - 2022-07-05 06:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:34:37 --> Total execution time: 0.0523
DEBUG - 2022-07-05 06:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:34:45 --> Total execution time: 0.0744
DEBUG - 2022-07-05 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:34:59 --> Total execution time: 0.0527
DEBUG - 2022-07-05 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:35:00 --> Total execution time: 0.0891
DEBUG - 2022-07-05 06:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:35:05 --> Total execution time: 0.0748
DEBUG - 2022-07-05 06:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:35:24 --> Total execution time: 0.0531
DEBUG - 2022-07-05 06:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:35:27 --> Total execution time: 0.0547
DEBUG - 2022-07-05 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:35:37 --> Total execution time: 0.0716
DEBUG - 2022-07-05 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:35:47 --> Total execution time: 0.0412
DEBUG - 2022-07-05 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 06:05:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:35:48 --> Total execution time: 0.0335
DEBUG - 2022-07-05 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:35:49 --> Total execution time: 0.0764
DEBUG - 2022-07-05 06:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 06:05:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 06:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:00 --> Total execution time: 0.0515
DEBUG - 2022-07-05 06:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:03 --> Total execution time: 0.0479
DEBUG - 2022-07-05 06:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:06 --> Total execution time: 0.0506
DEBUG - 2022-07-05 06:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:18 --> Total execution time: 0.0617
DEBUG - 2022-07-05 06:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:28 --> Total execution time: 0.0604
DEBUG - 2022-07-05 06:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:31 --> Total execution time: 0.1777
DEBUG - 2022-07-05 06:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:40 --> Total execution time: 0.0349
DEBUG - 2022-07-05 06:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:45 --> Total execution time: 0.0590
DEBUG - 2022-07-05 06:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:36:57 --> Total execution time: 0.0628
DEBUG - 2022-07-05 06:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:17 --> Total execution time: 0.0810
DEBUG - 2022-07-05 06:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:20 --> Total execution time: 0.0511
DEBUG - 2022-07-05 06:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:22 --> Total execution time: 0.0545
DEBUG - 2022-07-05 06:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:25 --> Total execution time: 0.0687
DEBUG - 2022-07-05 06:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:27 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:27 --> Total execution time: 0.0523
DEBUG - 2022-07-05 06:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:29 --> Total execution time: 0.0477
DEBUG - 2022-07-05 06:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:33 --> Total execution time: 0.0886
DEBUG - 2022-07-05 06:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:42 --> Total execution time: 0.0616
DEBUG - 2022-07-05 06:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:46 --> Total execution time: 0.0573
DEBUG - 2022-07-05 06:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:46 --> Total execution time: 0.0503
DEBUG - 2022-07-05 06:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:48 --> Total execution time: 0.0587
DEBUG - 2022-07-05 06:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:52 --> Total execution time: 0.0465
DEBUG - 2022-07-05 06:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:52 --> Total execution time: 0.0987
DEBUG - 2022-07-05 06:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:53 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:53 --> Total execution time: 0.0785
DEBUG - 2022-07-05 06:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:37:54 --> Total execution time: 0.0563
DEBUG - 2022-07-05 06:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:01 --> Total execution time: 0.1099
DEBUG - 2022-07-05 06:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:11 --> Total execution time: 0.0470
DEBUG - 2022-07-05 06:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:15 --> Total execution time: 0.0642
DEBUG - 2022-07-05 06:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:16 --> Total execution time: 0.0485
DEBUG - 2022-07-05 06:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:19 --> Total execution time: 0.0464
DEBUG - 2022-07-05 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:19 --> Total execution time: 0.1296
DEBUG - 2022-07-05 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:19 --> Total execution time: 0.0571
DEBUG - 2022-07-05 06:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:21 --> Total execution time: 0.0624
DEBUG - 2022-07-05 06:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:22 --> Total execution time: 0.0748
DEBUG - 2022-07-05 06:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:22 --> Total execution time: 0.0464
DEBUG - 2022-07-05 06:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:35 --> Total execution time: 0.0683
DEBUG - 2022-07-05 06:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:36 --> Total execution time: 0.0665
DEBUG - 2022-07-05 06:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:37 --> Total execution time: 0.0612
DEBUG - 2022-07-05 06:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:38 --> Total execution time: 0.0704
DEBUG - 2022-07-05 06:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:50 --> Total execution time: 0.1196
DEBUG - 2022-07-05 06:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:51 --> Total execution time: 0.0724
DEBUG - 2022-07-05 06:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:56 --> Total execution time: 0.0618
DEBUG - 2022-07-05 06:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:38:56 --> Total execution time: 0.0543
DEBUG - 2022-07-05 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:06 --> Total execution time: 0.0752
DEBUG - 2022-07-05 06:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:10 --> Total execution time: 0.1455
DEBUG - 2022-07-05 06:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:12 --> Total execution time: 0.0583
DEBUG - 2022-07-05 06:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:12 --> Total execution time: 0.0572
DEBUG - 2022-07-05 06:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:12 --> Total execution time: 0.0528
DEBUG - 2022-07-05 06:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:17 --> Total execution time: 0.0501
DEBUG - 2022-07-05 06:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:09:20 --> Total execution time: 0.0564
DEBUG - 2022-07-05 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:21 --> Total execution time: 0.0601
DEBUG - 2022-07-05 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:22 --> Total execution time: 0.0666
DEBUG - 2022-07-05 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:22 --> Total execution time: 0.0593
DEBUG - 2022-07-05 06:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:24 --> Total execution time: 0.0789
DEBUG - 2022-07-05 06:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:24 --> Total execution time: 0.0612
DEBUG - 2022-07-05 06:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:26 --> Total execution time: 0.0506
DEBUG - 2022-07-05 06:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:31 --> Total execution time: 0.0690
DEBUG - 2022-07-05 06:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:32 --> Total execution time: 0.0764
DEBUG - 2022-07-05 06:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:38 --> Total execution time: 0.0541
DEBUG - 2022-07-05 06:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:38 --> Total execution time: 0.0569
DEBUG - 2022-07-05 06:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:40 --> Total execution time: 0.0650
DEBUG - 2022-07-05 06:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:42 --> Total execution time: 0.0533
DEBUG - 2022-07-05 06:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:49 --> Total execution time: 0.0644
DEBUG - 2022-07-05 06:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:52 --> Total execution time: 0.0659
DEBUG - 2022-07-05 06:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:54 --> Total execution time: 0.0680
DEBUG - 2022-07-05 06:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:56 --> Total execution time: 0.0520
DEBUG - 2022-07-05 06:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:39:58 --> Total execution time: 0.0622
DEBUG - 2022-07-05 06:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:03 --> Total execution time: 0.0976
DEBUG - 2022-07-05 06:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:06 --> Total execution time: 0.0716
DEBUG - 2022-07-05 06:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:08 --> Total execution time: 0.1127
DEBUG - 2022-07-05 06:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:17 --> Total execution time: 0.0561
DEBUG - 2022-07-05 06:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:18 --> Total execution time: 0.0584
DEBUG - 2022-07-05 06:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:19 --> Total execution time: 0.1288
DEBUG - 2022-07-05 06:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:20 --> Total execution time: 0.1209
DEBUG - 2022-07-05 06:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:25 --> Total execution time: 0.0561
DEBUG - 2022-07-05 06:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:26 --> Total execution time: 0.0775
DEBUG - 2022-07-05 06:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:10:27 --> Total execution time: 0.0542
DEBUG - 2022-07-05 06:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:30 --> Total execution time: 0.0713
DEBUG - 2022-07-05 06:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:32 --> Total execution time: 0.0584
DEBUG - 2022-07-05 06:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:56 --> Total execution time: 0.0559
DEBUG - 2022-07-05 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:59 --> Total execution time: 0.0366
DEBUG - 2022-07-05 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:40:59 --> Total execution time: 0.0525
DEBUG - 2022-07-05 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:10:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 06:10:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 06:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:11:02 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:41:02 --> Total execution time: 0.0484
DEBUG - 2022-07-05 06:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:41:02 --> Total execution time: 0.0551
DEBUG - 2022-07-05 06:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:41:15 --> Total execution time: 0.0552
DEBUG - 2022-07-05 06:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:41:27 --> Total execution time: 0.1772
DEBUG - 2022-07-05 06:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:41:52 --> Total execution time: 0.0564
DEBUG - 2022-07-05 06:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:41:55 --> Total execution time: 0.0548
DEBUG - 2022-07-05 06:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:43:32 --> Total execution time: 0.0662
DEBUG - 2022-07-05 06:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:43:43 --> Total execution time: 0.0844
DEBUG - 2022-07-05 06:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:43:44 --> Total execution time: 0.0771
DEBUG - 2022-07-05 06:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:43:45 --> Total execution time: 0.0745
DEBUG - 2022-07-05 06:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:43:46 --> Total execution time: 0.0451
DEBUG - 2022-07-05 06:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:43:47 --> Total execution time: 0.0451
DEBUG - 2022-07-05 06:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:43:52 --> Total execution time: 0.0555
DEBUG - 2022-07-05 06:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:45:10 --> Total execution time: 0.1302
DEBUG - 2022-07-05 06:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:45:15 --> Total execution time: 0.0601
DEBUG - 2022-07-05 06:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:50:37 --> Total execution time: 0.1967
DEBUG - 2022-07-05 06:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:50:43 --> Total execution time: 0.0835
DEBUG - 2022-07-05 06:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:50:50 --> Total execution time: 0.0829
DEBUG - 2022-07-05 06:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:50:55 --> Total execution time: 0.0572
DEBUG - 2022-07-05 06:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:51:01 --> Total execution time: 0.0918
DEBUG - 2022-07-05 06:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:51:28 --> Total execution time: 0.0769
DEBUG - 2022-07-05 06:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:54:03 --> Total execution time: 0.0463
DEBUG - 2022-07-05 06:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:24:46 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:54:46 --> Total execution time: 0.0591
DEBUG - 2022-07-05 06:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:25:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:55:15 --> Total execution time: 0.0442
DEBUG - 2022-07-05 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:27:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:57:40 --> Total execution time: 0.0400
DEBUG - 2022-07-05 06:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:57:43 --> Total execution time: 0.0429
DEBUG - 2022-07-05 06:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:57:58 --> Total execution time: 0.0483
DEBUG - 2022-07-05 06:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:58:01 --> Total execution time: 0.0593
DEBUG - 2022-07-05 06:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:58:09 --> Total execution time: 0.0633
DEBUG - 2022-07-05 06:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:58:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:58:10 --> Total execution time: 0.0453
DEBUG - 2022-07-05 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:59:16 --> Total execution time: 0.0564
DEBUG - 2022-07-05 06:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:29:25 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:59:25 --> Total execution time: 0.0379
DEBUG - 2022-07-05 06:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:59:36 --> Total execution time: 0.0356
DEBUG - 2022-07-05 06:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:59:37 --> Total execution time: 0.0590
DEBUG - 2022-07-05 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:00:23 --> Total execution time: 0.0601
DEBUG - 2022-07-05 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:00:39 --> Total execution time: 0.0597
DEBUG - 2022-07-05 06:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:00:54 --> Total execution time: 0.0658
DEBUG - 2022-07-05 06:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:03 --> Total execution time: 0.0591
DEBUG - 2022-07-05 06:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:34 --> Total execution time: 0.1344
DEBUG - 2022-07-05 06:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:40 --> Total execution time: 0.0641
DEBUG - 2022-07-05 06:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:42 --> Total execution time: 0.1372
DEBUG - 2022-07-05 06:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:43 --> Total execution time: 0.0392
DEBUG - 2022-07-05 06:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:49 --> Total execution time: 0.0543
DEBUG - 2022-07-05 06:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:50 --> Total execution time: 0.0525
DEBUG - 2022-07-05 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:51 --> Total execution time: 0.0337
DEBUG - 2022-07-05 06:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:01:58 --> Total execution time: 0.0573
DEBUG - 2022-07-05 06:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:02:00 --> Total execution time: 0.0581
DEBUG - 2022-07-05 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:02:10 --> Total execution time: 0.0720
DEBUG - 2022-07-05 06:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:02:10 --> Total execution time: 0.0483
DEBUG - 2022-07-05 06:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:02:19 --> Total execution time: 0.0871
DEBUG - 2022-07-05 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:02:45 --> Total execution time: 0.0850
DEBUG - 2022-07-05 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:02:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 06:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:02:46 --> Total execution time: 0.0679
DEBUG - 2022-07-05 06:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:03:07 --> Total execution time: 0.0534
DEBUG - 2022-07-05 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:03:10 --> Total execution time: 0.0623
DEBUG - 2022-07-05 06:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:33:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:03:40 --> Total execution time: 0.0466
DEBUG - 2022-07-05 06:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:34:08 --> Total execution time: 0.0598
DEBUG - 2022-07-05 06:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:34:10 --> Total execution time: 0.0574
DEBUG - 2022-07-05 06:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:34:10 --> Total execution time: 0.1302
DEBUG - 2022-07-05 06:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:36:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:06:07 --> Total execution time: 0.1672
DEBUG - 2022-07-05 06:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:06:11 --> Total execution time: 0.0829
DEBUG - 2022-07-05 06:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:36:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:06:58 --> Total execution time: 0.1366
DEBUG - 2022-07-05 06:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:07:04 --> Total execution time: 0.0546
DEBUG - 2022-07-05 06:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:07:18 --> Total execution time: 0.0548
DEBUG - 2022-07-05 06:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:07:25 --> Total execution time: 0.0512
DEBUG - 2022-07-05 06:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:07:29 --> Total execution time: 0.0553
DEBUG - 2022-07-05 06:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:29 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:07:29 --> Total execution time: 0.0604
DEBUG - 2022-07-05 06:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:07:29 --> Total execution time: 0.0458
DEBUG - 2022-07-05 06:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:07:43 --> Total execution time: 0.0657
DEBUG - 2022-07-05 06:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:37:59 --> Total execution time: 0.0507
DEBUG - 2022-07-05 06:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:37:59 --> Total execution time: 0.0454
DEBUG - 2022-07-05 06:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:38:01 --> Total execution time: 0.0513
DEBUG - 2022-07-05 06:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:38:01 --> Total execution time: 0.1098
DEBUG - 2022-07-05 06:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:38:21 --> Total execution time: 0.0499
DEBUG - 2022-07-05 06:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:39:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 06:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:09:30 --> Total execution time: 1.5768
DEBUG - 2022-07-05 06:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 06:39:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:10:57 --> Total execution time: 0.0815
DEBUG - 2022-07-05 06:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:11:23 --> Total execution time: 0.1345
DEBUG - 2022-07-05 06:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:11:37 --> Total execution time: 0.0488
DEBUG - 2022-07-05 06:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:11:46 --> Total execution time: 0.0658
DEBUG - 2022-07-05 06:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:11:47 --> Total execution time: 0.0517
DEBUG - 2022-07-05 06:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:11:56 --> Total execution time: 0.0762
DEBUG - 2022-07-05 06:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:11:56 --> Total execution time: 0.0542
DEBUG - 2022-07-05 06:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:11:58 --> Total execution time: 0.0862
DEBUG - 2022-07-05 06:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:11:59 --> Total execution time: 0.0738
DEBUG - 2022-07-05 06:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:12:04 --> Total execution time: 0.0738
DEBUG - 2022-07-05 06:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 06:42:05 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 06:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:12:09 --> Total execution time: 0.0536
DEBUG - 2022-07-05 06:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:14:36 --> Total execution time: 0.1458
DEBUG - 2022-07-05 06:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:44:36 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:14:36 --> Total execution time: 0.0447
DEBUG - 2022-07-05 06:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 06:44:38 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 06:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:44:47 --> Total execution time: 0.0779
DEBUG - 2022-07-05 06:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:14:51 --> Total execution time: 0.0680
DEBUG - 2022-07-05 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:14:53 --> Total execution time: 0.0610
DEBUG - 2022-07-05 06:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:45:08 --> Total execution time: 0.1103
DEBUG - 2022-07-05 06:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:15:29 --> Total execution time: 0.1352
DEBUG - 2022-07-05 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:15:43 --> Total execution time: 0.0672
DEBUG - 2022-07-05 06:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:15:50 --> Total execution time: 0.0477
DEBUG - 2022-07-05 06:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 06:46:45 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 06:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:47:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:17:40 --> Total execution time: 0.1289
DEBUG - 2022-07-05 06:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:48:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:18:09 --> Total execution time: 0.0763
DEBUG - 2022-07-05 06:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:19:55 --> Total execution time: 0.0899
DEBUG - 2022-07-05 06:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:20:31 --> Total execution time: 0.0819
DEBUG - 2022-07-05 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:50:39 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:20:39 --> Total execution time: 0.0488
DEBUG - 2022-07-05 06:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:20:56 --> Total execution time: 0.0509
DEBUG - 2022-07-05 06:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:21:03 --> Total execution time: 0.0556
DEBUG - 2022-07-05 06:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:21:08 --> Total execution time: 0.0520
DEBUG - 2022-07-05 06:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:51:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:21:43 --> Total execution time: 0.0588
DEBUG - 2022-07-05 06:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:21:43 --> Total execution time: 0.0467
DEBUG - 2022-07-05 06:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:21:49 --> Total execution time: 0.0956
DEBUG - 2022-07-05 06:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:51:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:21:50 --> Total execution time: 0.0580
DEBUG - 2022-07-05 06:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:21:59 --> Total execution time: 0.0518
DEBUG - 2022-07-05 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:22:30 --> Total execution time: 0.0875
DEBUG - 2022-07-05 06:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:52:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:22:41 --> Total execution time: 0.1266
DEBUG - 2022-07-05 06:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:53:24 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:23:24 --> Total execution time: 0.0564
DEBUG - 2022-07-05 06:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:53:40 --> Total execution time: 0.0552
DEBUG - 2022-07-05 06:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:53:41 --> Total execution time: 0.0702
DEBUG - 2022-07-05 06:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:53:41 --> Total execution time: 0.1400
DEBUG - 2022-07-05 06:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:01 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:01 --> Total execution time: 0.0518
DEBUG - 2022-07-05 06:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:07 --> Total execution time: 0.0504
DEBUG - 2022-07-05 06:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:10 --> Total execution time: 0.0399
DEBUG - 2022-07-05 06:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:11 --> Total execution time: 0.0757
DEBUG - 2022-07-05 06:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:13 --> Total execution time: 0.0333
DEBUG - 2022-07-05 06:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:27 --> Total execution time: 0.0536
DEBUG - 2022-07-05 06:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:30 --> Total execution time: 0.0864
DEBUG - 2022-07-05 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:39 --> Total execution time: 0.0583
DEBUG - 2022-07-05 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:42 --> Total execution time: 0.0821
DEBUG - 2022-07-05 06:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:46 --> Total execution time: 0.0713
DEBUG - 2022-07-05 06:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 06:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:49 --> Total execution time: 0.0753
DEBUG - 2022-07-05 06:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:24:50 --> Total execution time: 0.0608
DEBUG - 2022-07-05 06:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:25:02 --> Total execution time: 0.0685
DEBUG - 2022-07-05 06:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:25:02 --> Total execution time: 0.1066
DEBUG - 2022-07-05 06:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:25:06 --> Total execution time: 0.1204
DEBUG - 2022-07-05 06:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:25:10 --> Total execution time: 0.0599
DEBUG - 2022-07-05 06:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:25:22 --> Total execution time: 0.1084
DEBUG - 2022-07-05 06:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:55:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 06:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:25:37 --> Total execution time: 0.0661
DEBUG - 2022-07-05 06:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:27:38 --> Total execution time: 0.0520
DEBUG - 2022-07-05 06:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 06:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 06:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:29:45 --> Total execution time: 0.1550
DEBUG - 2022-07-05 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:30:03 --> Total execution time: 0.0481
DEBUG - 2022-07-05 07:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:30:07 --> Total execution time: 0.1763
DEBUG - 2022-07-05 07:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:00:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:30:15 --> Total execution time: 0.0709
DEBUG - 2022-07-05 07:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:32:40 --> Total execution time: 0.0575
DEBUG - 2022-07-05 07:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:02:45 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:32:46 --> Total execution time: 0.1313
DEBUG - 2022-07-05 07:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:33:38 --> Total execution time: 0.0429
DEBUG - 2022-07-05 07:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:04:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:34:40 --> Total execution time: 0.1283
DEBUG - 2022-07-05 07:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:34:41 --> Total execution time: 0.1244
DEBUG - 2022-07-05 07:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:34:46 --> Total execution time: 0.0583
DEBUG - 2022-07-05 07:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:34:50 --> Total execution time: 0.0737
DEBUG - 2022-07-05 07:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:35:02 --> Total execution time: 0.0693
DEBUG - 2022-07-05 07:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:35:07 --> Total execution time: 0.0890
DEBUG - 2022-07-05 07:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:05:53 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:35:53 --> Total execution time: 0.0436
DEBUG - 2022-07-05 07:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:05:53 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:35:53 --> Total execution time: 0.0367
DEBUG - 2022-07-05 07:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:05:55 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:35:56 --> Total execution time: 0.0386
DEBUG - 2022-07-05 07:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:05:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:35:56 --> Total execution time: 0.0512
DEBUG - 2022-07-05 07:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:35:57 --> Total execution time: 0.0364
DEBUG - 2022-07-05 07:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:35:58 --> Total execution time: 0.0383
DEBUG - 2022-07-05 07:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:37:37 --> Total execution time: 0.1315
DEBUG - 2022-07-05 07:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:37:46 --> Total execution time: 0.0582
DEBUG - 2022-07-05 07:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:39:01 --> Total execution time: 0.1273
DEBUG - 2022-07-05 07:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:09:19 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:39:19 --> Total execution time: 0.0408
DEBUG - 2022-07-05 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:09:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:39:41 --> Total execution time: 0.0346
DEBUG - 2022-07-05 07:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:09:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:39:42 --> Total execution time: 0.0370
DEBUG - 2022-07-05 07:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:10:31 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 07:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:10:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:40:57 --> Total execution time: 0.0382
DEBUG - 2022-07-05 07:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:41:07 --> Total execution time: 0.0558
DEBUG - 2022-07-05 07:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:41:14 --> Total execution time: 0.0366
DEBUG - 2022-07-05 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:11:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:41:20 --> Total execution time: 0.0604
DEBUG - 2022-07-05 07:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:41:27 --> Total execution time: 0.0509
DEBUG - 2022-07-05 07:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:11:39 --> Total execution time: 0.0646
DEBUG - 2022-07-05 07:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:11:41 --> Total execution time: 0.0610
DEBUG - 2022-07-05 07:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:11:41 --> Total execution time: 0.1089
DEBUG - 2022-07-05 07:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:11:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:41:52 --> Total execution time: 0.0637
DEBUG - 2022-07-05 07:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:42:23 --> Total execution time: 0.0648
DEBUG - 2022-07-05 07:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:42:28 --> Total execution time: 0.0619
DEBUG - 2022-07-05 07:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:42:43 --> Total execution time: 0.0584
DEBUG - 2022-07-05 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:13:01 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:43:01 --> Total execution time: 0.1688
DEBUG - 2022-07-05 07:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:43:06 --> Total execution time: 0.0661
DEBUG - 2022-07-05 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:43:07 --> Total execution time: 0.0612
DEBUG - 2022-07-05 07:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:43:52 --> Total execution time: 0.0542
DEBUG - 2022-07-05 07:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:44:03 --> Total execution time: 0.0631
DEBUG - 2022-07-05 07:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:44:17 --> Total execution time: 0.0817
DEBUG - 2022-07-05 07:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:44:59 --> Total execution time: 0.0374
DEBUG - 2022-07-05 07:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:45:00 --> Total execution time: 0.0832
DEBUG - 2022-07-05 07:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:45:31 --> Total execution time: 0.0881
DEBUG - 2022-07-05 07:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:45:33 --> Total execution time: 0.0487
DEBUG - 2022-07-05 07:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:45:45 --> Total execution time: 0.1204
DEBUG - 2022-07-05 07:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:16:45 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:46:45 --> Total execution time: 0.0458
DEBUG - 2022-07-05 07:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:17:21 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:47:21 --> Total execution time: 0.0352
DEBUG - 2022-07-05 07:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:47:32 --> Total execution time: 0.0319
DEBUG - 2022-07-05 07:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:17:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:47:38 --> Total execution time: 0.0345
DEBUG - 2022-07-05 07:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:47:44 --> Total execution time: 0.0507
DEBUG - 2022-07-05 07:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:47:48 --> Total execution time: 0.0636
DEBUG - 2022-07-05 07:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:47:53 --> Total execution time: 0.0599
DEBUG - 2022-07-05 07:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:07 --> Total execution time: 0.0533
DEBUG - 2022-07-05 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:14 --> Total execution time: 0.0376
DEBUG - 2022-07-05 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:14 --> Total execution time: 0.0346
DEBUG - 2022-07-05 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:21 --> Total execution time: 0.0878
DEBUG - 2022-07-05 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:21 --> Total execution time: 0.0542
DEBUG - 2022-07-05 07:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:26 --> Total execution time: 0.0764
DEBUG - 2022-07-05 07:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:27 --> Total execution time: 0.0540
DEBUG - 2022-07-05 07:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:30 --> Total execution time: 0.0530
DEBUG - 2022-07-05 07:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:41 --> Total execution time: 0.0909
DEBUG - 2022-07-05 07:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:48 --> Total execution time: 0.1028
DEBUG - 2022-07-05 07:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:51 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:51 --> Total execution time: 0.0459
DEBUG - 2022-07-05 07:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:48:51 --> Total execution time: 0.0490
DEBUG - 2022-07-05 07:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:49:22 --> Total execution time: 0.0643
DEBUG - 2022-07-05 07:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:49:41 --> Total execution time: 0.0525
DEBUG - 2022-07-05 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:19:46 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:49:46 --> Total execution time: 0.0367
DEBUG - 2022-07-05 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:49:47 --> Total execution time: 0.1152
DEBUG - 2022-07-05 07:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:02 --> Total execution time: 0.0852
DEBUG - 2022-07-05 07:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:08 --> Total execution time: 0.0828
DEBUG - 2022-07-05 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:21 --> Total execution time: 0.1172
DEBUG - 2022-07-05 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:21 --> Total execution time: 0.0591
DEBUG - 2022-07-05 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:22 --> Total execution time: 0.1162
DEBUG - 2022-07-05 07:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:35 --> Total execution time: 0.0852
DEBUG - 2022-07-05 07:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:48 --> Total execution time: 0.0540
DEBUG - 2022-07-05 07:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:49 --> Total execution time: 0.0593
DEBUG - 2022-07-05 07:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:50:49 --> Total execution time: 0.0504
DEBUG - 2022-07-05 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:21:55 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:51:55 --> Total execution time: 0.0491
DEBUG - 2022-07-05 07:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:21:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:51:56 --> Total execution time: 0.0348
DEBUG - 2022-07-05 07:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:52:00 --> Total execution time: 0.0315
DEBUG - 2022-07-05 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:52:23 --> Total execution time: 0.0473
DEBUG - 2022-07-05 07:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:53:00 --> Total execution time: 0.0647
DEBUG - 2022-07-05 07:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:23:23 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:53:23 --> Total execution time: 0.1238
DEBUG - 2022-07-05 07:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:53:29 --> Total execution time: 0.1207
DEBUG - 2022-07-05 07:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:54:33 --> Total execution time: 0.0531
DEBUG - 2022-07-05 07:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:27:03 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:57:03 --> Total execution time: 0.2090
DEBUG - 2022-07-05 07:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:57:08 --> Total execution time: 0.0697
DEBUG - 2022-07-05 07:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:57:23 --> Total execution time: 0.0593
DEBUG - 2022-07-05 07:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:57:26 --> Total execution time: 0.0571
DEBUG - 2022-07-05 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:00:08 --> Total execution time: 0.0827
DEBUG - 2022-07-05 07:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:00:10 --> Total execution time: 0.0649
DEBUG - 2022-07-05 07:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:00:36 --> Total execution time: 0.1292
DEBUG - 2022-07-05 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:00:41 --> Total execution time: 0.0571
DEBUG - 2022-07-05 07:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:01:59 --> Total execution time: 0.0674
DEBUG - 2022-07-05 07:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:02:00 --> Total execution time: 0.0940
DEBUG - 2022-07-05 07:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:32:12 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:02:12 --> Total execution time: 0.1490
DEBUG - 2022-07-05 07:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:02:16 --> Total execution time: 0.0617
DEBUG - 2022-07-05 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:02:17 --> Total execution time: 0.0607
DEBUG - 2022-07-05 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:02:23 --> Total execution time: 0.0662
DEBUG - 2022-07-05 07:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:05:43 --> Total execution time: 0.1811
DEBUG - 2022-07-05 07:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:35:44 --> Total execution time: 0.0550
DEBUG - 2022-07-05 07:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:05:45 --> Total execution time: 0.0675
DEBUG - 2022-07-05 07:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:05:49 --> Total execution time: 0.0578
DEBUG - 2022-07-05 07:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:36:10 --> Total execution time: 0.0674
DEBUG - 2022-07-05 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:36:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:06:42 --> Total execution time: 0.0564
DEBUG - 2022-07-05 07:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:36:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:06:42 --> Total execution time: 0.0726
DEBUG - 2022-07-05 07:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:06:44 --> Total execution time: 0.0381
DEBUG - 2022-07-05 07:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:06:57 --> Total execution time: 0.0652
DEBUG - 2022-07-05 07:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:07:04 --> Total execution time: 0.0545
DEBUG - 2022-07-05 07:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:30 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:07:30 --> Total execution time: 0.0365
DEBUG - 2022-07-05 07:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:07:39 --> Total execution time: 0.0566
DEBUG - 2022-07-05 07:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:07:44 --> Total execution time: 0.0496
DEBUG - 2022-07-05 07:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:07:46 --> Total execution time: 0.0441
DEBUG - 2022-07-05 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:07:49 --> Total execution time: 0.0780
DEBUG - 2022-07-05 07:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:07:57 --> Total execution time: 0.0516
DEBUG - 2022-07-05 07:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:08:16 --> Total execution time: 0.0529
DEBUG - 2022-07-05 07:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:08:19 --> Total execution time: 0.0842
DEBUG - 2022-07-05 07:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:08:21 --> Total execution time: 0.0956
DEBUG - 2022-07-05 07:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:08:45 --> Total execution time: 0.0718
DEBUG - 2022-07-05 07:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:08:52 --> Total execution time: 0.1320
DEBUG - 2022-07-05 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:08:57 --> Total execution time: 0.0566
DEBUG - 2022-07-05 18:08:57 --> Total execution time: 0.1313
DEBUG - 2022-07-05 07:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:09:07 --> Total execution time: 0.0853
DEBUG - 2022-07-05 07:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:09:10 --> Total execution time: 0.1081
DEBUG - 2022-07-05 07:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:09:25 --> Total execution time: 0.0549
DEBUG - 2022-07-05 07:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:40:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:10:13 --> Total execution time: 0.0357
DEBUG - 2022-07-05 07:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:40:25 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:10:25 --> Total execution time: 0.0466
DEBUG - 2022-07-05 07:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:10:37 --> Total execution time: 0.1392
DEBUG - 2022-07-05 07:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:10:54 --> Total execution time: 0.0484
DEBUG - 2022-07-05 07:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:10:58 --> Total execution time: 0.0476
DEBUG - 2022-07-05 07:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:11:22 --> Total execution time: 0.0534
DEBUG - 2022-07-05 07:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:11:29 --> Total execution time: 0.0522
DEBUG - 2022-07-05 07:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:11:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:11:30 --> Total execution time: 0.0571
DEBUG - 2022-07-05 07:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:11:37 --> Total execution time: 0.0822
DEBUG - 2022-07-05 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:11:55 --> Total execution time: 0.0751
DEBUG - 2022-07-05 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:12:26 --> Total execution time: 0.0890
DEBUG - 2022-07-05 07:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:12:40 --> Total execution time: 0.0636
DEBUG - 2022-07-05 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:12:45 --> Total execution time: 0.0510
DEBUG - 2022-07-05 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:42:49 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:12:49 --> Total execution time: 0.0498
DEBUG - 2022-07-05 07:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:12:51 --> Total execution time: 0.0815
DEBUG - 2022-07-05 07:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:42:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:12:54 --> Total execution time: 0.0499
DEBUG - 2022-07-05 07:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:13:06 --> Total execution time: 0.0636
DEBUG - 2022-07-05 07:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:13:15 --> Total execution time: 0.0750
DEBUG - 2022-07-05 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:14:09 --> Total execution time: 0.0522
DEBUG - 2022-07-05 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:14:42 --> Total execution time: 0.0643
DEBUG - 2022-07-05 07:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:14:56 --> Total execution time: 0.0535
DEBUG - 2022-07-05 07:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:15:11 --> Total execution time: 0.0576
DEBUG - 2022-07-05 07:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:15:16 --> Total execution time: 0.0485
DEBUG - 2022-07-05 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:15:41 --> Total execution time: 0.0627
DEBUG - 2022-07-05 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:15:47 --> Total execution time: 0.0505
DEBUG - 2022-07-05 07:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:15:53 --> Total execution time: 0.0520
DEBUG - 2022-07-05 07:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:15:58 --> Total execution time: 0.0635
DEBUG - 2022-07-05 07:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:45:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:15:59 --> Total execution time: 0.0494
DEBUG - 2022-07-05 07:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:16:01 --> Total execution time: 0.0507
DEBUG - 2022-07-05 07:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:16:04 --> Total execution time: 0.0620
DEBUG - 2022-07-05 07:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:46:06 --> Total execution time: 0.0476
DEBUG - 2022-07-05 07:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:16:07 --> Total execution time: 0.0458
DEBUG - 2022-07-05 07:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:46:08 --> Total execution time: 0.0500
DEBUG - 2022-07-05 07:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:46:08 --> Total execution time: 0.0780
DEBUG - 2022-07-05 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:16:43 --> Total execution time: 0.0508
DEBUG - 2022-07-05 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:46:56 --> Total execution time: 0.0487
DEBUG - 2022-07-05 07:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:46:58 --> Total execution time: 0.0476
DEBUG - 2022-07-05 07:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:46:58 --> Total execution time: 0.0988
DEBUG - 2022-07-05 07:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:47:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 07:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:17:27 --> Total execution time: 1.5925
DEBUG - 2022-07-05 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 07:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:32 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-05 07:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:32 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-05 07:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:33 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-05 07:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:33 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-05 07:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:34 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-05 07:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:34 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-05 07:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:35 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-07-05 07:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:47:37 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-05 07:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:17:43 --> Total execution time: 0.0508
DEBUG - 2022-07-05 07:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:17:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 07:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:17:56 --> Total execution time: 0.0778
DEBUG - 2022-07-05 07:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:17:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 18:17:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 18:17:58 --> Total execution time: 0.2024
DEBUG - 2022-07-05 07:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:18:00 --> Total execution time: 0.0632
DEBUG - 2022-07-05 07:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:18:08 --> Total execution time: 0.0952
DEBUG - 2022-07-05 07:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:18:13 --> Total execution time: 0.0581
DEBUG - 2022-07-05 07:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:18:16 --> Total execution time: 0.0817
DEBUG - 2022-07-05 07:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:18:18 --> Total execution time: 0.0621
DEBUG - 2022-07-05 07:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:18:24 --> Total execution time: 0.0520
DEBUG - 2022-07-05 07:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:49:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:19:15 --> Total execution time: 0.1373
DEBUG - 2022-07-05 07:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:19:27 --> Total execution time: 0.0338
DEBUG - 2022-07-05 07:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:19:32 --> Total execution time: 0.0515
DEBUG - 2022-07-05 07:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:19:41 --> Total execution time: 0.0571
DEBUG - 2022-07-05 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:19:48 --> Total execution time: 0.0629
DEBUG - 2022-07-05 07:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:20:33 --> Total execution time: 0.0655
DEBUG - 2022-07-05 07:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:51:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:21:13 --> Total execution time: 0.1506
DEBUG - 2022-07-05 07:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:21:54 --> Total execution time: 0.0494
DEBUG - 2022-07-05 07:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:51:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:21:59 --> Total execution time: 0.0653
DEBUG - 2022-07-05 07:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:51:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:21:59 --> Total execution time: 0.0511
DEBUG - 2022-07-05 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:22:00 --> Total execution time: 0.0626
DEBUG - 2022-07-05 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:22:11 --> Total execution time: 0.0787
DEBUG - 2022-07-05 07:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:22:32 --> Total execution time: 0.1264
DEBUG - 2022-07-05 07:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:22:59 --> Total execution time: 0.0526
DEBUG - 2022-07-05 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:23:01 --> Total execution time: 1.6028
DEBUG - 2022-07-05 07:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:53:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 07:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 07:53:04 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:23:36 --> Total execution time: 0.0481
DEBUG - 2022-07-05 07:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:23:50 --> Total execution time: 0.0708
DEBUG - 2022-07-05 07:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:23:52 --> Total execution time: 0.0511
DEBUG - 2022-07-05 07:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:23:58 --> Total execution time: 0.0698
DEBUG - 2022-07-05 07:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:53:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:23:58 --> Total execution time: 0.1465
DEBUG - 2022-07-05 07:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:24:02 --> Total execution time: 0.1248
DEBUG - 2022-07-05 07:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:24:08 --> Total execution time: 0.0599
DEBUG - 2022-07-05 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:24:20 --> Total execution time: 0.0598
DEBUG - 2022-07-05 07:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:24:31 --> Total execution time: 0.0558
DEBUG - 2022-07-05 07:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:24:38 --> Total execution time: 0.0701
DEBUG - 2022-07-05 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:24:42 --> Total execution time: 0.0585
DEBUG - 2022-07-05 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:44 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:24:44 --> Total execution time: 0.0575
DEBUG - 2022-07-05 07:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:54:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:24:57 --> Total execution time: 0.0555
DEBUG - 2022-07-05 07:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:55:36 --> No URI present. Default controller set.
DEBUG - 2022-07-05 07:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:25:36 --> Total execution time: 0.0525
DEBUG - 2022-07-05 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:56:01 --> Total execution time: 0.0488
DEBUG - 2022-07-05 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:56:02 --> Total execution time: 0.0662
DEBUG - 2022-07-05 07:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:56:02 --> Total execution time: 0.1039
DEBUG - 2022-07-05 07:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:26:17 --> Total execution time: 0.1180
DEBUG - 2022-07-05 07:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 07:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:26:31 --> Total execution time: 0.0523
DEBUG - 2022-07-05 07:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:26:37 --> Total execution time: 0.3117
DEBUG - 2022-07-05 07:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 07:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 07:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:29:28 --> Total execution time: 0.2232
DEBUG - 2022-07-05 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:30:02 --> Total execution time: 0.0639
DEBUG - 2022-07-05 08:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:01:25 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:31:25 --> Total execution time: 0.1246
DEBUG - 2022-07-05 08:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:31:50 --> Total execution time: 0.0876
DEBUG - 2022-07-05 08:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:31:56 --> Total execution time: 0.0658
DEBUG - 2022-07-05 08:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:32:08 --> Total execution time: 0.0813
DEBUG - 2022-07-05 08:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:02:28 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:32:28 --> Total execution time: 0.0542
DEBUG - 2022-07-05 08:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:32:43 --> Total execution time: 0.0490
DEBUG - 2022-07-05 08:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:32:53 --> Total execution time: 0.0832
DEBUG - 2022-07-05 08:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:33:08 --> Total execution time: 0.1501
DEBUG - 2022-07-05 08:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:03:11 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:33:11 --> Total execution time: 0.0344
DEBUG - 2022-07-05 08:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:33:45 --> Total execution time: 0.0668
DEBUG - 2022-07-05 08:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:03:46 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:33:46 --> Total execution time: 0.0549
DEBUG - 2022-07-05 08:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:33:56 --> Total execution time: 0.1280
DEBUG - 2022-07-05 08:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:34:08 --> Total execution time: 0.0681
DEBUG - 2022-07-05 08:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:34:24 --> Total execution time: 0.1243
DEBUG - 2022-07-05 08:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:34:27 --> Total execution time: 0.0586
DEBUG - 2022-07-05 08:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:34:29 --> Total execution time: 0.0609
DEBUG - 2022-07-05 08:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:34:37 --> Total execution time: 0.0591
DEBUG - 2022-07-05 08:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:34:51 --> Total execution time: 0.0511
DEBUG - 2022-07-05 08:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:05 --> Total execution time: 0.0515
DEBUG - 2022-07-05 08:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:09 --> Total execution time: 0.0561
DEBUG - 2022-07-05 08:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:22 --> Total execution time: 0.0483
DEBUG - 2022-07-05 08:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:35 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:35 --> Total execution time: 0.0399
DEBUG - 2022-07-05 08:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:38 --> Total execution time: 0.0441
DEBUG - 2022-07-05 08:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:39 --> Total execution time: 0.0349
DEBUG - 2022-07-05 08:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:46 --> Total execution time: 0.0619
DEBUG - 2022-07-05 08:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:53 --> Total execution time: 0.0698
DEBUG - 2022-07-05 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:56 --> Total execution time: 0.0634
DEBUG - 2022-07-05 08:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:03 --> Total execution time: 0.0732
DEBUG - 2022-07-05 08:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:06:18 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:18 --> Total execution time: 0.0380
DEBUG - 2022-07-05 08:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:08:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:38:40 --> Total execution time: 0.1473
DEBUG - 2022-07-05 08:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:38:44 --> Total execution time: 0.0474
DEBUG - 2022-07-05 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:38:45 --> Total execution time: 0.1521
DEBUG - 2022-07-05 08:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:08:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:08:48 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-05 08:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:08:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:08:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:39:00 --> Total execution time: 0.0469
DEBUG - 2022-07-05 08:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:09:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:09:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 08:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:39:34 --> Total execution time: 0.0505
DEBUG - 2022-07-05 08:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:10:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:40:48 --> Total execution time: 0.1630
DEBUG - 2022-07-05 08:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:11:32 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:41:33 --> Total execution time: 0.1505
DEBUG - 2022-07-05 08:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:41:40 --> Total execution time: 0.0640
DEBUG - 2022-07-05 08:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:41:44 --> Total execution time: 0.0797
DEBUG - 2022-07-05 08:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:41:47 --> Total execution time: 0.0703
DEBUG - 2022-07-05 08:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:41:55 --> Total execution time: 0.0944
DEBUG - 2022-07-05 08:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:12:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:42:20 --> Total execution time: 0.0661
DEBUG - 2022-07-05 08:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:42:24 --> Total execution time: 0.0396
DEBUG - 2022-07-05 08:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:42:46 --> Total execution time: 0.0607
DEBUG - 2022-07-05 08:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:42:50 --> Total execution time: 0.0599
DEBUG - 2022-07-05 08:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:42:57 --> Total execution time: 0.0598
DEBUG - 2022-07-05 08:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:43:06 --> Total execution time: 0.0574
DEBUG - 2022-07-05 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:43:57 --> Total execution time: 0.0738
DEBUG - 2022-07-05 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:15:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:45:10 --> Total execution time: 0.0706
DEBUG - 2022-07-05 08:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:45:16 --> Total execution time: 0.0568
DEBUG - 2022-07-05 08:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:45:23 --> Total execution time: 0.0541
DEBUG - 2022-07-05 08:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:45:26 --> Total execution time: 0.0636
DEBUG - 2022-07-05 08:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:45:34 --> Total execution time: 0.0547
DEBUG - 2022-07-05 08:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:46:54 --> Total execution time: 0.1271
DEBUG - 2022-07-05 08:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:46:58 --> Total execution time: 0.0559
DEBUG - 2022-07-05 08:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:50:53 --> Total execution time: 0.0610
DEBUG - 2022-07-05 08:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:51:27 --> Total execution time: 0.0563
DEBUG - 2022-07-05 08:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:23:01 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 08:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:54:12 --> Total execution time: 0.0494
DEBUG - 2022-07-05 08:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:55:07 --> Total execution time: 0.0682
DEBUG - 2022-07-05 08:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:55:07 --> Total execution time: 0.0730
DEBUG - 2022-07-05 08:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:55:10 --> Total execution time: 0.0562
DEBUG - 2022-07-05 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:55:14 --> Total execution time: 0.0586
DEBUG - 2022-07-05 08:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:19 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:55:19 --> Total execution time: 0.0396
DEBUG - 2022-07-05 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:55:25 --> Total execution time: 0.0506
DEBUG - 2022-07-05 08:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:25:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:25:33 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 08:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:56:14 --> Total execution time: 0.0360
DEBUG - 2022-07-05 08:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:56:30 --> Total execution time: 0.0516
DEBUG - 2022-07-05 08:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:57:09 --> Total execution time: 0.1249
DEBUG - 2022-07-05 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:57:16 --> Total execution time: 0.0504
DEBUG - 2022-07-05 08:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:57:18 --> Total execution time: 0.0571
DEBUG - 2022-07-05 08:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:57:22 --> Total execution time: 0.0601
DEBUG - 2022-07-05 08:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:57:29 --> Total execution time: 0.0432
DEBUG - 2022-07-05 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:27:42 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:44 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:57:44 --> Total execution time: 0.1217
DEBUG - 2022-07-05 08:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:57:50 --> Total execution time: 0.0528
DEBUG - 2022-07-05 08:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:58:01 --> Total execution time: 0.0845
DEBUG - 2022-07-05 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:58:07 --> Total execution time: 0.0861
DEBUG - 2022-07-05 08:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:58:14 --> Total execution time: 0.0883
DEBUG - 2022-07-05 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:59:24 --> Total execution time: 0.0494
DEBUG - 2022-07-05 08:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:05:52 --> Total execution time: 0.1256
DEBUG - 2022-07-05 08:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:12:07 --> Total execution time: 0.1256
DEBUG - 2022-07-05 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:12:12 --> Total execution time: 0.0367
DEBUG - 2022-07-05 08:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:12:24 --> Total execution time: 0.0744
DEBUG - 2022-07-05 08:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:12:36 --> Total execution time: 0.0583
DEBUG - 2022-07-05 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:42:38 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:42:38 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:12:44 --> Total execution time: 0.0872
DEBUG - 2022-07-05 08:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:02 --> Total execution time: 0.0561
DEBUG - 2022-07-05 08:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:12 --> Total execution time: 0.0461
DEBUG - 2022-07-05 08:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:24 --> Total execution time: 0.0761
DEBUG - 2022-07-05 08:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:27 --> Total execution time: 0.0482
DEBUG - 2022-07-05 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:30 --> Total execution time: 0.0523
DEBUG - 2022-07-05 08:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:13:32 --> Total execution time: 0.0714
DEBUG - 2022-07-05 08:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:13:38 --> Total execution time: 0.0894
DEBUG - 2022-07-05 08:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:13:54 --> Total execution time: 0.0788
DEBUG - 2022-07-05 08:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:44:06 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:14:06 --> Total execution time: 0.0364
DEBUG - 2022-07-05 08:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:14:17 --> Total execution time: 0.0732
DEBUG - 2022-07-05 08:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:14:18 --> Total execution time: 0.0332
DEBUG - 2022-07-05 08:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:14:30 --> Total execution time: 0.0752
DEBUG - 2022-07-05 08:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:14:42 --> Total execution time: 0.0865
DEBUG - 2022-07-05 08:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:15:28 --> Total execution time: 0.0775
DEBUG - 2022-07-05 08:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:15:30 --> Total execution time: 0.0959
DEBUG - 2022-07-05 08:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:15:43 --> Total execution time: 0.0573
DEBUG - 2022-07-05 08:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:45:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-05 08:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:16:05 --> Total execution time: 0.0548
DEBUG - 2022-07-05 08:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:17:00 --> Total execution time: 0.0662
DEBUG - 2022-07-05 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:17:11 --> Total execution time: 0.0555
DEBUG - 2022-07-05 08:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:24 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:17:24 --> Total execution time: 0.0404
DEBUG - 2022-07-05 08:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:17:24 --> Total execution time: 0.0523
DEBUG - 2022-07-05 08:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:17:29 --> Total execution time: 0.1295
DEBUG - 2022-07-05 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:47:56 --> Total execution time: 0.0488
DEBUG - 2022-07-05 08:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:17:57 --> Total execution time: 0.0541
DEBUG - 2022-07-05 08:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:47:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:47:59 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 08:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:18:09 --> Total execution time: 0.0450
DEBUG - 2022-07-05 08:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:18:14 --> Total execution time: 0.0671
DEBUG - 2022-07-05 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:18:15 --> Total execution time: 0.0887
DEBUG - 2022-07-05 08:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:18:40 --> Total execution time: 0.1475
DEBUG - 2022-07-05 08:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:18:48 --> Total execution time: 0.0425
DEBUG - 2022-07-05 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:19:02 --> Total execution time: 0.0518
DEBUG - 2022-07-05 08:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:20:03 --> Total execution time: 0.0784
DEBUG - 2022-07-05 08:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:20:10 --> Total execution time: 0.0684
DEBUG - 2022-07-05 08:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:20:15 --> Total execution time: 0.1070
DEBUG - 2022-07-05 08:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:50:24 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:20:25 --> Total execution time: 0.1209
DEBUG - 2022-07-05 08:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:21:10 --> Total execution time: 0.0571
DEBUG - 2022-07-05 08:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:21:15 --> Total execution time: 0.0530
DEBUG - 2022-07-05 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:21:19 --> Total execution time: 0.0538
DEBUG - 2022-07-05 08:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:51:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:51:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:23:57 --> Total execution time: 0.0555
DEBUG - 2022-07-05 08:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:24:02 --> Total execution time: 0.0427
DEBUG - 2022-07-05 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:54:21 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:24:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:24:21 --> Total execution time: 0.1137
DEBUG - 2022-07-05 08:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:54:31 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:24:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:24:31 --> Total execution time: 0.0976
DEBUG - 2022-07-05 08:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:54:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 08:54:31 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-05 08:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 08:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:24:46 --> Total execution time: 0.0520
DEBUG - 2022-07-05 08:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:24:50 --> Total execution time: 0.0531
DEBUG - 2022-07-05 08:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:56:17 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:26:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:26:17 --> Total execution time: 0.1831
DEBUG - 2022-07-05 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:57:01 --> No URI present. Default controller set.
DEBUG - 2022-07-05 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:27:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:27:01 --> Total execution time: 0.1822
DEBUG - 2022-07-05 08:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:28:26 --> Total execution time: 0.0711
DEBUG - 2022-07-05 08:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:29:42 --> Total execution time: 0.1465
DEBUG - 2022-07-05 08:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 08:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 08:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:29:53 --> Total execution time: 0.0599
DEBUG - 2022-07-05 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:30:02 --> Total execution time: 0.1265
DEBUG - 2022-07-05 09:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:30:46 --> Total execution time: 0.0374
DEBUG - 2022-07-05 09:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:31:34 --> Total execution time: 0.0589
DEBUG - 2022-07-05 09:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:31:41 --> Total execution time: 0.0688
DEBUG - 2022-07-05 09:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:11 --> Total execution time: 0.0479
DEBUG - 2022-07-05 09:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:19 --> Total execution time: 0.0517
DEBUG - 2022-07-05 09:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:23 --> Total execution time: 0.1537
DEBUG - 2022-07-05 09:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:42 --> Total execution time: 0.0511
DEBUG - 2022-07-05 09:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:49 --> Total execution time: 0.1251
DEBUG - 2022-07-05 09:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:50 --> Total execution time: 0.0738
DEBUG - 2022-07-05 09:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:50 --> Total execution time: 0.0522
DEBUG - 2022-07-05 09:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:52 --> Total execution time: 0.4618
DEBUG - 2022-07-05 09:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:53 --> Total execution time: 0.0552
DEBUG - 2022-07-05 09:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:01 --> Total execution time: 0.0596
DEBUG - 2022-07-05 09:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:06 --> Total execution time: 0.0518
DEBUG - 2022-07-05 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:10 --> Total execution time: 0.0575
DEBUG - 2022-07-05 09:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:15 --> Total execution time: 0.0536
DEBUG - 2022-07-05 09:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:18 --> Total execution time: 0.0510
DEBUG - 2022-07-05 09:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:20 --> Total execution time: 0.1291
DEBUG - 2022-07-05 09:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:41 --> Total execution time: 0.0525
DEBUG - 2022-07-05 09:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:49 --> Total execution time: 0.0733
DEBUG - 2022-07-05 09:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:52 --> Total execution time: 0.0550
DEBUG - 2022-07-05 09:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:59 --> Total execution time: 0.0552
DEBUG - 2022-07-05 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:06:05 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:36:05 --> Total execution time: 0.1053
DEBUG - 2022-07-05 09:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:06:14 --> Total execution time: 0.0523
DEBUG - 2022-07-05 09:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:06:15 --> Total execution time: 0.0521
DEBUG - 2022-07-05 09:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:06:15 --> Total execution time: 0.1067
DEBUG - 2022-07-05 09:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:37:06 --> Total execution time: 0.1732
DEBUG - 2022-07-05 09:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:37:09 --> Total execution time: 0.0559
DEBUG - 2022-07-05 09:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:37:19 --> Total execution time: 0.0655
DEBUG - 2022-07-05 09:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:37:23 --> Total execution time: 0.0617
DEBUG - 2022-07-05 09:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:37:36 --> Total execution time: 0.0675
DEBUG - 2022-07-05 09:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:37:52 --> Total execution time: 0.0703
DEBUG - 2022-07-05 09:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:38:03 --> Total execution time: 0.0554
DEBUG - 2022-07-05 09:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:11:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:41:26 --> Total execution time: 1.8922
DEBUG - 2022-07-05 09:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 09:11:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 09:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:11:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:41:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:41:37 --> Total execution time: 0.1721
DEBUG - 2022-07-05 09:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:10 --> Total execution time: 0.0361
DEBUG - 2022-07-05 09:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:27 --> Total execution time: 0.0532
DEBUG - 2022-07-05 09:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:31 --> Total execution time: 0.0318
DEBUG - 2022-07-05 09:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:32 --> Total execution time: 0.0540
DEBUG - 2022-07-05 09:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:33 --> Total execution time: 0.0490
DEBUG - 2022-07-05 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:34 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:42:34 --> Total execution time: 0.0936
DEBUG - 2022-07-05 09:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:43 --> Total execution time: 0.0542
DEBUG - 2022-07-05 09:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:55 --> Total execution time: 0.0507
DEBUG - 2022-07-05 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:42:57 --> Total execution time: 0.0625
DEBUG - 2022-07-05 09:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:03 --> Total execution time: 0.0475
DEBUG - 2022-07-05 09:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:09 --> Total execution time: 0.0479
DEBUG - 2022-07-05 09:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:17 --> Total execution time: 0.0695
DEBUG - 2022-07-05 09:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:23 --> Total execution time: 0.0407
DEBUG - 2022-07-05 09:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:42 --> Total execution time: 0.0475
DEBUG - 2022-07-05 09:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:50 --> Total execution time: 0.0640
DEBUG - 2022-07-05 09:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:58 --> Total execution time: 0.0686
DEBUG - 2022-07-05 09:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:58 --> Total execution time: 0.0479
DEBUG - 2022-07-05 09:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:43:59 --> Total execution time: 0.0418
DEBUG - 2022-07-05 09:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:14:18 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:44:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:44:18 --> Total execution time: 0.0871
DEBUG - 2022-07-05 09:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:44:25 --> Total execution time: 0.0482
DEBUG - 2022-07-05 09:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:44:31 --> Total execution time: 0.0494
DEBUG - 2022-07-05 09:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:44:35 --> Total execution time: 0.0542
DEBUG - 2022-07-05 09:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:17:17 --> Total execution time: 0.0505
DEBUG - 2022-07-05 09:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:47:23 --> Total execution time: 0.0508
DEBUG - 2022-07-05 09:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:47:35 --> Total execution time: 0.0538
DEBUG - 2022-07-05 09:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:47:35 --> Total execution time: 0.0715
DEBUG - 2022-07-05 09:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:47:37 --> Total execution time: 0.0799
DEBUG - 2022-07-05 09:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:17:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:47:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:47:54 --> Total execution time: 0.0950
DEBUG - 2022-07-05 09:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:18:21 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:48:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:48:21 --> Total execution time: 0.1983
DEBUG - 2022-07-05 09:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:03 --> Total execution time: 0.0668
DEBUG - 2022-07-05 09:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:04 --> Total execution time: 0.0620
DEBUG - 2022-07-05 09:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:15 --> Total execution time: 0.0729
DEBUG - 2022-07-05 09:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:17 --> Total execution time: 0.0465
DEBUG - 2022-07-05 09:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:18 --> Total execution time: 0.0303
DEBUG - 2022-07-05 09:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:18 --> Total execution time: 0.0313
DEBUG - 2022-07-05 09:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:22 --> Total execution time: 0.0432
DEBUG - 2022-07-05 09:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:28 --> Total execution time: 0.0440
DEBUG - 2022-07-05 09:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:44 --> Total execution time: 0.0420
DEBUG - 2022-07-05 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:49:59 --> Total execution time: 0.0489
DEBUG - 2022-07-05 09:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:50:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:50:19 --> Total execution time: 0.0542
DEBUG - 2022-07-05 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:50:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:50:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:50:20 --> Total execution time: 0.1753
DEBUG - 2022-07-05 09:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:50:35 --> Total execution time: 0.0577
DEBUG - 2022-07-05 09:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:51:18 --> Total execution time: 0.0537
DEBUG - 2022-07-05 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:52:44 --> Total execution time: 0.1444
DEBUG - 2022-07-05 09:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:52:45 --> Total execution time: 0.0815
DEBUG - 2022-07-05 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:52:53 --> Total execution time: 0.0771
DEBUG - 2022-07-05 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:52:53 --> Total execution time: 0.0836
DEBUG - 2022-07-05 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:52:53 --> Total execution time: 0.0823
DEBUG - 2022-07-05 09:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:52:54 --> Total execution time: 0.0912
DEBUG - 2022-07-05 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:52:55 --> Total execution time: 0.0982
DEBUG - 2022-07-05 09:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:52:58 --> Total execution time: 0.0771
DEBUG - 2022-07-05 09:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:53:03 --> Total execution time: 0.6659
DEBUG - 2022-07-05 09:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:53:55 --> Total execution time: 0.6352
DEBUG - 2022-07-05 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:10 --> Total execution time: 0.0362
DEBUG - 2022-07-05 09:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:26 --> Total execution time: 0.0727
DEBUG - 2022-07-05 09:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:27 --> Total execution time: 0.0710
DEBUG - 2022-07-05 09:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:30 --> Total execution time: 0.0868
DEBUG - 2022-07-05 09:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:38 --> Total execution time: 0.0487
DEBUG - 2022-07-05 09:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:44 --> Total execution time: 0.0719
DEBUG - 2022-07-05 09:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:45 --> Total execution time: 0.0734
DEBUG - 2022-07-05 09:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:49 --> Total execution time: 0.0510
DEBUG - 2022-07-05 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:59 --> Total execution time: 0.0509
DEBUG - 2022-07-05 09:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:02 --> Total execution time: 0.0687
DEBUG - 2022-07-05 09:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:03 --> Total execution time: 0.0746
DEBUG - 2022-07-05 09:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:27 --> Total execution time: 0.0517
DEBUG - 2022-07-05 09:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:28 --> Total execution time: 0.0537
DEBUG - 2022-07-05 09:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:33 --> Total execution time: 0.0525
DEBUG - 2022-07-05 09:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 09:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:41 --> Total execution time: 0.0496
DEBUG - 2022-07-05 09:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:55:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 19:55:42 --> Total execution time: 0.1885
DEBUG - 2022-07-05 09:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:55:49 --> Total execution time: 0.0622
DEBUG - 2022-07-05 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:27:44 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:57:44 --> Total execution time: 0.0420
DEBUG - 2022-07-05 09:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:58:17 --> Total execution time: 0.0494
DEBUG - 2022-07-05 09:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:28:49 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:58:49 --> Total execution time: 0.0464
DEBUG - 2022-07-05 09:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:28:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:58:57 --> Total execution time: 0.0342
DEBUG - 2022-07-05 09:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:28:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:58:59 --> Total execution time: 0.0595
DEBUG - 2022-07-05 09:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:28:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:58:59 --> Total execution time: 0.0341
DEBUG - 2022-07-05 09:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:59:04 --> Total execution time: 0.0326
DEBUG - 2022-07-05 09:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:59:13 --> Total execution time: 0.0545
DEBUG - 2022-07-05 09:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:59:18 --> Total execution time: 0.1269
DEBUG - 2022-07-05 09:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:59:34 --> Total execution time: 0.0868
DEBUG - 2022-07-05 09:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:59:35 --> Total execution time: 0.0616
DEBUG - 2022-07-05 09:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:59:46 --> Total execution time: 0.0683
DEBUG - 2022-07-05 09:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:00:00 --> Total execution time: 0.1178
DEBUG - 2022-07-05 09:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:00:05 --> Total execution time: 0.0642
DEBUG - 2022-07-05 09:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:00:48 --> Total execution time: 0.0603
DEBUG - 2022-07-05 09:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:00:55 --> Total execution time: 0.0467
DEBUG - 2022-07-05 09:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 09:31:02 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-05 09:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 09:33:00 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-05 09:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:03:46 --> Total execution time: 0.0340
DEBUG - 2022-07-05 09:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:03:47 --> Total execution time: 0.0412
DEBUG - 2022-07-05 09:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:34:18 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:04:18 --> Total execution time: 0.1365
DEBUG - 2022-07-05 09:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:34:24 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:04:24 --> Total execution time: 0.0353
DEBUG - 2022-07-05 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:04:28 --> Total execution time: 0.0483
DEBUG - 2022-07-05 09:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:37:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:07:50 --> Total execution time: 0.1084
DEBUG - 2022-07-05 09:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:37:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:07:50 --> Total execution time: 0.0322
DEBUG - 2022-07-05 09:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:37:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:07:57 --> Total execution time: 0.0412
DEBUG - 2022-07-05 09:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:08:02 --> Total execution time: 0.0672
DEBUG - 2022-07-05 09:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:08:26 --> Total execution time: 0.0523
DEBUG - 2022-07-05 09:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:38:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:08:47 --> Total execution time: 0.0509
DEBUG - 2022-07-05 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:08:54 --> Total execution time: 0.0520
DEBUG - 2022-07-05 09:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:39:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:09:07 --> Total execution time: 0.0685
DEBUG - 2022-07-05 09:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:09:10 --> Total execution time: 0.0516
DEBUG - 2022-07-05 09:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:39:20 --> Total execution time: 0.0575
DEBUG - 2022-07-05 09:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:39:21 --> Total execution time: 0.0622
DEBUG - 2022-07-05 09:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:39:21 --> Total execution time: 0.1247
DEBUG - 2022-07-05 09:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:09:43 --> Total execution time: 0.0576
DEBUG - 2022-07-05 09:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:41:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 09:41:18 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-05 09:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:12:04 --> Total execution time: 0.0342
DEBUG - 2022-07-05 09:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:12:05 --> Total execution time: 0.0478
DEBUG - 2022-07-05 09:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:13:33 --> Total execution time: 0.0334
DEBUG - 2022-07-05 09:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:44:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:14:13 --> Total execution time: 0.0449
DEBUG - 2022-07-05 09:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:14:17 --> Total execution time: 0.0479
DEBUG - 2022-07-05 09:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:14:34 --> Total execution time: 0.0499
DEBUG - 2022-07-05 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:14:50 --> Total execution time: 0.0745
DEBUG - 2022-07-05 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:14:50 --> Total execution time: 0.0550
DEBUG - 2022-07-05 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:14:50 --> Total execution time: 0.0580
DEBUG - 2022-07-05 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:44:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 09:44:51 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-05 09:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:15:06 --> Total execution time: 0.0687
DEBUG - 2022-07-05 09:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:15:37 --> Total execution time: 0.0493
DEBUG - 2022-07-05 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:19:55 --> Total execution time: 0.0567
DEBUG - 2022-07-05 09:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 09:50:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:21:24 --> Total execution time: 0.1294
DEBUG - 2022-07-05 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:54:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:24:43 --> Total execution time: 0.2186
DEBUG - 2022-07-05 09:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:24:49 --> Total execution time: 0.0332
DEBUG - 2022-07-05 09:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:24:57 --> Total execution time: 0.0582
DEBUG - 2022-07-05 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:25:00 --> Total execution time: 0.0791
DEBUG - 2022-07-05 09:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:25:03 --> Total execution time: 0.0598
DEBUG - 2022-07-05 09:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:55:12 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:25:12 --> Total execution time: 0.0507
DEBUG - 2022-07-05 09:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:25:14 --> Total execution time: 0.0487
DEBUG - 2022-07-05 09:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:25:30 --> Total execution time: 0.0507
DEBUG - 2022-07-05 09:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:25:39 --> Total execution time: 0.0909
DEBUG - 2022-07-05 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:26:58 --> Total execution time: 0.0326
DEBUG - 2022-07-05 09:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:57:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 09:57:13 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-05 09:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:27:27 --> Total execution time: 0.0473
DEBUG - 2022-07-05 09:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:12 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:28:12 --> Total execution time: 0.0543
DEBUG - 2022-07-05 09:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:28:15 --> Total execution time: 0.0343
DEBUG - 2022-07-05 09:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:28:16 --> Total execution time: 0.0483
DEBUG - 2022-07-05 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:17 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:28:17 --> Total execution time: 0.0371
DEBUG - 2022-07-05 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:28:17 --> Total execution time: 0.0507
DEBUG - 2022-07-05 09:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:28:33 --> Total execution time: 0.0702
DEBUG - 2022-07-05 09:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:28:51 --> Total execution time: 0.0466
DEBUG - 2022-07-05 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:28:59 --> Total execution time: 0.0592
DEBUG - 2022-07-05 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:02 --> No URI present. Default controller set.
DEBUG - 2022-07-05 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:29:02 --> Total execution time: 0.0488
DEBUG - 2022-07-05 09:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:29:03 --> Total execution time: 0.0484
DEBUG - 2022-07-05 09:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:29:11 --> Total execution time: 0.1285
DEBUG - 2022-07-05 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:29:19 --> Total execution time: 0.0629
DEBUG - 2022-07-05 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 09:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:29:25 --> Total execution time: 0.0547
DEBUG - 2022-07-05 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:29:43 --> Total execution time: 0.0598
DEBUG - 2022-07-05 09:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:29:46 --> Total execution time: 0.0649
DEBUG - 2022-07-05 09:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 09:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:29:57 --> Total execution time: 0.0504
DEBUG - 2022-07-05 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:30:02 --> Total execution time: 0.0571
DEBUG - 2022-07-05 10:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:31:14 --> Total execution time: 0.0398
DEBUG - 2022-07-05 10:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:02:06 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:32:06 --> Total execution time: 0.0351
DEBUG - 2022-07-05 10:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:02:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:32:15 --> Total execution time: 0.0497
DEBUG - 2022-07-05 10:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:32:50 --> Total execution time: 0.0558
DEBUG - 2022-07-05 10:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:03:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 10:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:33:31 --> Total execution time: 0.0351
DEBUG - 2022-07-05 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:33:38 --> Total execution time: 0.0603
DEBUG - 2022-07-05 10:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:33:45 --> Total execution time: 0.0836
DEBUG - 2022-07-05 10:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:33:47 --> Total execution time: 0.0419
DEBUG - 2022-07-05 10:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:51 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:33:51 --> Total execution time: 0.0348
DEBUG - 2022-07-05 10:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:33:55 --> Total execution time: 0.0546
DEBUG - 2022-07-05 10:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:33:58 --> Total execution time: 0.0543
DEBUG - 2022-07-05 10:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:34:06 --> Total execution time: 0.0631
DEBUG - 2022-07-05 10:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:04:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:34:42 --> Total execution time: 0.0564
DEBUG - 2022-07-05 10:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:04:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:34:43 --> Total execution time: 0.0281
DEBUG - 2022-07-05 10:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:35:15 --> Total execution time: 0.0553
DEBUG - 2022-07-05 10:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:35:16 --> Total execution time: 0.0485
DEBUG - 2022-07-05 10:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:35:16 --> Total execution time: 0.0591
DEBUG - 2022-07-05 10:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:35:17 --> Total execution time: 0.0504
DEBUG - 2022-07-05 10:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:05:26 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 10:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:45 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:35:45 --> Total execution time: 0.0495
DEBUG - 2022-07-05 10:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:05:45 --> Total execution time: 0.0290
DEBUG - 2022-07-05 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:05:48 --> Total execution time: 0.0523
DEBUG - 2022-07-05 10:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:05:48 --> Total execution time: 0.1111
DEBUG - 2022-07-05 10:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:35:55 --> Total execution time: 0.0509
DEBUG - 2022-07-05 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:06:17 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:36:17 --> Total execution time: 0.0501
DEBUG - 2022-07-05 10:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:06:42 --> Total execution time: 0.0537
DEBUG - 2022-07-05 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:06:44 --> Total execution time: 0.0534
DEBUG - 2022-07-05 10:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:06:44 --> Total execution time: 0.0942
DEBUG - 2022-07-05 10:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:06:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 10:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:36:58 --> Total execution time: 1.8533
DEBUG - 2022-07-05 10:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:07:02 --> Total execution time: 0.0511
DEBUG - 2022-07-05 10:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:07:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 10:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:07:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 10:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:37:51 --> Total execution time: 1.4710
DEBUG - 2022-07-05 10:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:07:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 10:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:38:01 --> Total execution time: 0.0515
DEBUG - 2022-07-05 10:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:08:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:08:04 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 10:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:40:01 --> Total execution time: 0.0976
DEBUG - 2022-07-05 10:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:10:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:10:14 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 10:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:40:18 --> Total execution time: 0.0849
DEBUG - 2022-07-05 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:10:32 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:40:32 --> Total execution time: 0.0582
DEBUG - 2022-07-05 10:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:11:34 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:41:34 --> Total execution time: 0.0397
DEBUG - 2022-07-05 10:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:11:35 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:41:35 --> Total execution time: 0.0354
DEBUG - 2022-07-05 10:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:41:39 --> Total execution time: 0.1227
DEBUG - 2022-07-05 10:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:41:50 --> Total execution time: 0.0557
DEBUG - 2022-07-05 10:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:42:09 --> Total execution time: 0.0598
DEBUG - 2022-07-05 10:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:42:22 --> Total execution time: 0.0596
DEBUG - 2022-07-05 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:42:50 --> Total execution time: 0.0536
DEBUG - 2022-07-05 10:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:43:22 --> Total execution time: 0.0527
DEBUG - 2022-07-05 10:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:13:28 --> Total execution time: 0.0751
DEBUG - 2022-07-05 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:13:37 --> Total execution time: 0.0729
DEBUG - 2022-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:43:54 --> Total execution time: 0.0489
DEBUG - 2022-07-05 10:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:43:55 --> Total execution time: 0.0856
DEBUG - 2022-07-05 10:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:44:10 --> Total execution time: 0.0518
DEBUG - 2022-07-05 10:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:44:20 --> Total execution time: 0.0552
DEBUG - 2022-07-05 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:44:32 --> Total execution time: 0.0583
DEBUG - 2022-07-05 10:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:44:44 --> Total execution time: 0.0956
DEBUG - 2022-07-05 10:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:46:51 --> Total execution time: 0.1750
DEBUG - 2022-07-05 10:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:47:17 --> Total execution time: 0.0558
DEBUG - 2022-07-05 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:47:28 --> Total execution time: 0.1285
DEBUG - 2022-07-05 10:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:47:57 --> Total execution time: 0.0757
DEBUG - 2022-07-05 10:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:48:32 --> Total execution time: 0.0935
DEBUG - 2022-07-05 10:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:48:45 --> Total execution time: 0.0568
DEBUG - 2022-07-05 10:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:48:58 --> Total execution time: 0.0572
DEBUG - 2022-07-05 10:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:04 --> Total execution time: 0.0573
DEBUG - 2022-07-05 10:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:24 --> Total execution time: 0.0850
DEBUG - 2022-07-05 10:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:29 --> Total execution time: 0.0849
DEBUG - 2022-07-05 10:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:36 --> Total execution time: 0.0688
DEBUG - 2022-07-05 10:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:45 --> Total execution time: 0.0516
DEBUG - 2022-07-05 10:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:50 --> Total execution time: 0.0668
DEBUG - 2022-07-05 10:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:19:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:58 --> Total execution time: 0.1221
DEBUG - 2022-07-05 10:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:20:01 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:01 --> Total execution time: 0.0756
DEBUG - 2022-07-05 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:10 --> Total execution time: 0.0364
DEBUG - 2022-07-05 10:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:25 --> Total execution time: 0.0535
DEBUG - 2022-07-05 10:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:38 --> Total execution time: 0.0646
DEBUG - 2022-07-05 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:47 --> Total execution time: 0.0854
DEBUG - 2022-07-05 10:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:03 --> Total execution time: 0.0615
DEBUG - 2022-07-05 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:17 --> Total execution time: 0.0526
DEBUG - 2022-07-05 10:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:19 --> Total execution time: 0.0911
DEBUG - 2022-07-05 10:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:20 --> Total execution time: 0.0699
DEBUG - 2022-07-05 10:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:21 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:21 --> Total execution time: 0.0355
DEBUG - 2022-07-05 10:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:31 --> Total execution time: 0.0322
DEBUG - 2022-07-05 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:40 --> Total execution time: 0.0591
DEBUG - 2022-07-05 10:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:44 --> Total execution time: 0.0710
DEBUG - 2022-07-05 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:57 --> Total execution time: 0.0891
DEBUG - 2022-07-05 10:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:52:05 --> Total execution time: 0.0835
DEBUG - 2022-07-05 10:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:52:28 --> Total execution time: 0.0732
DEBUG - 2022-07-05 10:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:52:47 --> Total execution time: 0.0805
DEBUG - 2022-07-05 10:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:52:49 --> Total execution time: 0.0521
DEBUG - 2022-07-05 10:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:52:53 --> Total execution time: 0.0511
DEBUG - 2022-07-05 10:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:22:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:52:56 --> Total execution time: 0.0527
DEBUG - 2022-07-05 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:52:57 --> Total execution time: 0.0689
DEBUG - 2022-07-05 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:23:19 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:53:19 --> Total execution time: 0.0350
DEBUG - 2022-07-05 10:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:53:39 --> Total execution time: 0.1547
DEBUG - 2022-07-05 10:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:53:40 --> Total execution time: 0.0478
DEBUG - 2022-07-05 10:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:53:57 --> Total execution time: 0.0514
DEBUG - 2022-07-05 10:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:54:02 --> Total execution time: 0.0949
DEBUG - 2022-07-05 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:54:21 --> Total execution time: 0.0323
DEBUG - 2022-07-05 10:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:54:31 --> Total execution time: 0.0772
DEBUG - 2022-07-05 10:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:54:36 --> Total execution time: 0.0577
DEBUG - 2022-07-05 10:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:54:50 --> Total execution time: 0.0450
DEBUG - 2022-07-05 10:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:55:16 --> Total execution time: 0.0533
DEBUG - 2022-07-05 10:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:55:20 --> Total execution time: 0.1033
DEBUG - 2022-07-05 10:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:55:30 --> Total execution time: 0.0539
DEBUG - 2022-07-05 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:28:22 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:58:23 --> Total execution time: 0.0687
DEBUG - 2022-07-05 10:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:59:00 --> Total execution time: 0.1328
DEBUG - 2022-07-05 10:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:29:18 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:59:18 --> Total execution time: 0.0549
DEBUG - 2022-07-05 10:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:59:20 --> Total execution time: 0.0555
DEBUG - 2022-07-05 10:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:59:25 --> Total execution time: 0.0498
DEBUG - 2022-07-05 10:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:59:29 --> Total execution time: 0.0496
DEBUG - 2022-07-05 10:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:03 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 10:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:04 --> 404 Page Not Found: Humanstxt/index
DEBUG - 2022-07-05 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:05 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-05 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:00:06 --> Total execution time: 0.0520
DEBUG - 2022-07-05 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:06 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:00:06 --> Total execution time: 0.0349
DEBUG - 2022-07-05 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:00:16 --> Total execution time: 0.0586
DEBUG - 2022-07-05 10:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:00:20 --> Total execution time: 0.0665
DEBUG - 2022-07-05 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:00:26 --> Total execution time: 0.0506
DEBUG - 2022-07-05 10:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:37 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 10:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:37 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-05 10:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:37 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-05 10:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:41 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-07-05 10:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:44 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-05 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:45 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-05 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-05 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-05 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:46 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:47 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-05 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:47 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:47 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-05 10:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:48 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 10:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:30:48 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-05 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:31:53 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:01:53 --> Total execution time: 0.1443
DEBUG - 2022-07-05 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:02:00 --> Total execution time: 0.0550
DEBUG - 2022-07-05 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:02:02 --> Total execution time: 0.0572
DEBUG - 2022-07-05 10:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:02:04 --> Total execution time: 0.0557
DEBUG - 2022-07-05 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:34:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:34:25 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 10:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:04:49 --> Total execution time: 0.1970
DEBUG - 2022-07-05 10:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:04:56 --> Total execution time: 0.1117
DEBUG - 2022-07-05 10:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:05:06 --> Total execution time: 0.0514
DEBUG - 2022-07-05 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:05:07 --> Total execution time: 0.0570
DEBUG - 2022-07-05 10:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:05:24 --> Total execution time: 0.0869
DEBUG - 2022-07-05 10:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:37:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 10:37:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 10:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:38:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:08:47 --> Total execution time: 0.0762
DEBUG - 2022-07-05 10:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:38:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:08:48 --> Total execution time: 0.0414
DEBUG - 2022-07-05 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:11:47 --> Total execution time: 0.0459
DEBUG - 2022-07-05 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:11:53 --> Total execution time: 0.0474
DEBUG - 2022-07-05 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:11:59 --> Total execution time: 0.0575
DEBUG - 2022-07-05 10:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:12:22 --> Total execution time: 0.0897
DEBUG - 2022-07-05 10:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:12:27 --> Total execution time: 0.0861
DEBUG - 2022-07-05 10:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:13:03 --> Total execution time: 0.1266
DEBUG - 2022-07-05 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:43:44 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:13:44 --> Total execution time: 0.0372
DEBUG - 2022-07-05 10:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:13:56 --> Total execution time: 0.0471
DEBUG - 2022-07-05 10:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:14:23 --> Total execution time: 0.0608
DEBUG - 2022-07-05 10:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:14:33 --> Total execution time: 0.0635
DEBUG - 2022-07-05 10:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:14:42 --> Total execution time: 0.0579
DEBUG - 2022-07-05 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:15:06 --> Total execution time: 0.0470
DEBUG - 2022-07-05 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:16:27 --> Total execution time: 0.0330
DEBUG - 2022-07-05 10:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:18:21 --> Total execution time: 0.0469
DEBUG - 2022-07-05 10:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:49:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:19:09 --> Total execution time: 0.0375
DEBUG - 2022-07-05 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:19:13 --> Total execution time: 0.0399
DEBUG - 2022-07-05 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:20:00 --> Total execution time: 0.0492
DEBUG - 2022-07-05 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:20:39 --> Total execution time: 0.0477
DEBUG - 2022-07-05 10:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:50:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:20:42 --> Total execution time: 0.0353
DEBUG - 2022-07-05 10:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:50:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:20:58 --> Total execution time: 0.0352
DEBUG - 2022-07-05 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:51:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:21:54 --> Total execution time: 0.0355
DEBUG - 2022-07-05 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:51:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:21:55 --> Total execution time: 0.0381
DEBUG - 2022-07-05 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:52:30 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:22:30 --> Total execution time: 0.0363
DEBUG - 2022-07-05 10:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:22:34 --> Total execution time: 0.0698
DEBUG - 2022-07-05 10:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:23:08 --> Total execution time: 0.0815
DEBUG - 2022-07-05 10:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:53:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:23:37 --> Total execution time: 0.0592
DEBUG - 2022-07-05 10:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:23:41 --> Total execution time: 0.0514
DEBUG - 2022-07-05 10:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:23:54 --> Total execution time: 0.0620
DEBUG - 2022-07-05 10:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:24:04 --> Total execution time: 0.0651
DEBUG - 2022-07-05 10:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:55:23 --> Total execution time: 0.0603
DEBUG - 2022-07-05 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:55:33 --> Total execution time: 0.0943
DEBUG - 2022-07-05 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:45 --> Total execution time: 0.1338
DEBUG - 2022-07-05 10:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:52 --> Total execution time: 0.0582
DEBUG - 2022-07-05 10:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:26:00 --> Total execution time: 0.0643
DEBUG - 2022-07-05 10:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:56:01 --> Total execution time: 0.0529
DEBUG - 2022-07-05 10:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:56:06 --> Total execution time: 0.0681
DEBUG - 2022-07-05 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:57:07 --> Total execution time: 0.0536
DEBUG - 2022-07-05 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:57:15 --> Total execution time: 0.0736
DEBUG - 2022-07-05 10:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:27:57 --> Total execution time: 0.0815
DEBUG - 2022-07-05 10:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:28:09 --> Total execution time: 0.0869
DEBUG - 2022-07-05 10:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:08 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:08 --> Total execution time: 0.0454
DEBUG - 2022-07-05 10:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:19 --> Total execution time: 0.0517
DEBUG - 2022-07-05 10:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:29 --> Total execution time: 0.0672
DEBUG - 2022-07-05 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:41 --> Total execution time: 0.0658
DEBUG - 2022-07-05 10:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:45 --> Total execution time: 0.0845
DEBUG - 2022-07-05 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:52 --> Total execution time: 0.0996
DEBUG - 2022-07-05 10:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:55 --> Total execution time: 0.0524
DEBUG - 2022-07-05 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:58 --> Total execution time: 0.0808
DEBUG - 2022-07-05 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 10:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:58 --> Total execution time: 0.1263
DEBUG - 2022-07-05 10:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 10:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 10:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:29:59 --> Total execution time: 0.0718
DEBUG - 2022-07-05 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:01 --> Total execution time: 0.0653
DEBUG - 2022-07-05 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:02 --> Total execution time: 0.0489
DEBUG - 2022-07-05 11:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:05 --> Total execution time: 0.1148
DEBUG - 2022-07-05 11:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:06 --> Total execution time: 0.1219
DEBUG - 2022-07-05 11:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:09 --> Total execution time: 0.0825
DEBUG - 2022-07-05 11:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:16 --> Total execution time: 0.0550
DEBUG - 2022-07-05 11:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:17 --> Total execution time: 0.0603
DEBUG - 2022-07-05 11:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:20 --> Total execution time: 0.0755
DEBUG - 2022-07-05 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:25 --> Total execution time: 0.0526
DEBUG - 2022-07-05 11:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:36 --> Total execution time: 0.0843
DEBUG - 2022-07-05 11:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:38 --> Total execution time: 0.0670
DEBUG - 2022-07-05 11:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:41 --> Total execution time: 0.0572
DEBUG - 2022-07-05 11:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:50 --> Total execution time: 0.0598
DEBUG - 2022-07-05 11:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:51 --> Total execution time: 0.0448
DEBUG - 2022-07-05 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:54 --> Total execution time: 0.0548
DEBUG - 2022-07-05 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:54 --> Total execution time: 0.0866
DEBUG - 2022-07-05 11:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:30:59 --> Total execution time: 0.0721
DEBUG - 2022-07-05 11:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:02 --> Total execution time: 0.1029
DEBUG - 2022-07-05 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:08 --> Total execution time: 0.0546
DEBUG - 2022-07-05 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:11 --> Total execution time: 0.0650
DEBUG - 2022-07-05 11:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:16 --> Total execution time: 0.0539
DEBUG - 2022-07-05 11:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:17 --> Total execution time: 0.0819
DEBUG - 2022-07-05 11:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:24 --> Total execution time: 0.0826
DEBUG - 2022-07-05 11:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:26 --> Total execution time: 0.0660
DEBUG - 2022-07-05 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:27 --> Total execution time: 0.0520
DEBUG - 2022-07-05 11:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:28 --> Total execution time: 0.0612
DEBUG - 2022-07-05 11:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:31 --> Total execution time: 0.0372
DEBUG - 2022-07-05 11:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:31 --> Total execution time: 0.0569
DEBUG - 2022-07-05 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:32 --> Total execution time: 0.0518
DEBUG - 2022-07-05 11:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:31:34 --> Total execution time: 0.1036
DEBUG - 2022-07-05 11:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:32:05 --> Total execution time: 0.0535
DEBUG - 2022-07-05 11:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:32:38 --> Total execution time: 0.0502
DEBUG - 2022-07-05 11:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:32:44 --> Total execution time: 0.0406
DEBUG - 2022-07-05 11:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:33:36 --> Total execution time: 0.0783
DEBUG - 2022-07-05 11:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:33:48 --> Total execution time: 0.0484
DEBUG - 2022-07-05 11:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:33:49 --> Total execution time: 0.0579
DEBUG - 2022-07-05 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:03:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:33:56 --> Total execution time: 0.0372
DEBUG - 2022-07-05 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:03:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:33:57 --> Total execution time: 0.0394
DEBUG - 2022-07-05 11:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:34:11 --> Total execution time: 0.0470
DEBUG - 2022-07-05 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:34:13 --> Total execution time: 0.0343
DEBUG - 2022-07-05 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:04:31 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:34:31 --> Total execution time: 0.1356
DEBUG - 2022-07-05 11:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:34:38 --> Total execution time: 0.0513
DEBUG - 2022-07-05 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:34:53 --> Total execution time: 0.0577
DEBUG - 2022-07-05 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:34:59 --> Total execution time: 0.0564
DEBUG - 2022-07-05 11:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:35:08 --> Total execution time: 0.0596
DEBUG - 2022-07-05 11:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:35:09 --> Total execution time: 0.0577
DEBUG - 2022-07-05 11:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:35:35 --> Total execution time: 0.0486
DEBUG - 2022-07-05 11:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:05:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:35:38 --> Total execution time: 0.1195
DEBUG - 2022-07-05 11:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:05:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:35:43 --> Total execution time: 0.0513
DEBUG - 2022-07-05 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:05:52 --> Total execution time: 0.0633
DEBUG - 2022-07-05 11:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:36:21 --> Total execution time: 0.0504
DEBUG - 2022-07-05 11:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:06:47 --> Total execution time: 0.0579
DEBUG - 2022-07-05 11:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:06:47 --> Total execution time: 0.1192
DEBUG - 2022-07-05 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:07:28 --> Total execution time: 0.0506
DEBUG - 2022-07-05 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:07:34 --> Total execution time: 0.0508
DEBUG - 2022-07-05 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:08:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 11:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:21 --> Total execution time: 1.9623
DEBUG - 2022-07-05 11:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:08:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 11:08:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 11:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:26 --> Total execution time: 0.0580
DEBUG - 2022-07-05 11:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:36 --> Total execution time: 0.1514
DEBUG - 2022-07-05 11:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:10:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:41 --> Total execution time: 0.0365
DEBUG - 2022-07-05 11:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:45 --> Total execution time: 0.0366
DEBUG - 2022-07-05 11:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:51 --> Total execution time: 0.0568
DEBUG - 2022-07-05 11:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:57 --> Total execution time: 0.0749
DEBUG - 2022-07-05 11:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:41:01 --> Total execution time: 0.0980
DEBUG - 2022-07-05 11:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:41:02 --> Total execution time: 0.0835
DEBUG - 2022-07-05 11:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:46 --> Total execution time: 0.0420
DEBUG - 2022-07-05 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:59 --> Total execution time: 0.1506
DEBUG - 2022-07-05 11:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:13:54 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:43:54 --> Total execution time: 0.1261
DEBUG - 2022-07-05 11:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:23 --> Total execution time: 0.0457
DEBUG - 2022-07-05 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:37 --> Total execution time: 0.0521
DEBUG - 2022-07-05 11:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:57 --> Total execution time: 0.0627
DEBUG - 2022-07-05 11:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:00 --> Total execution time: 0.0565
DEBUG - 2022-07-05 11:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:03 --> Total execution time: 0.0918
DEBUG - 2022-07-05 11:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:07 --> Total execution time: 0.0577
DEBUG - 2022-07-05 11:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:13 --> Total execution time: 0.0741
DEBUG - 2022-07-05 11:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:29 --> Total execution time: 0.0657
DEBUG - 2022-07-05 11:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:42 --> Total execution time: 0.0494
DEBUG - 2022-07-05 11:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:06 --> Total execution time: 0.0530
DEBUG - 2022-07-05 11:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:12 --> Total execution time: 0.0522
DEBUG - 2022-07-05 11:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:22 --> Total execution time: 0.0595
DEBUG - 2022-07-05 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:24 --> Total execution time: 0.0604
DEBUG - 2022-07-05 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:29 --> Total execution time: 0.0526
DEBUG - 2022-07-05 11:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:48:01 --> Total execution time: 0.0691
DEBUG - 2022-07-05 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:19:27 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:49:27 --> Total execution time: 0.1197
DEBUG - 2022-07-05 11:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:49:55 --> Total execution time: 0.0585
DEBUG - 2022-07-05 11:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:00 --> Total execution time: 0.0574
DEBUG - 2022-07-05 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:08 --> Total execution time: 0.0562
DEBUG - 2022-07-05 11:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:21 --> Total execution time: 0.0529
DEBUG - 2022-07-05 11:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:16 --> Total execution time: 0.1236
DEBUG - 2022-07-05 11:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:23 --> Total execution time: 0.0712
DEBUG - 2022-07-05 11:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:26 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:26 --> Total execution time: 0.0346
DEBUG - 2022-07-05 11:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:26 --> Total execution time: 0.0606
DEBUG - 2022-07-05 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:31 --> Total execution time: 0.0536
DEBUG - 2022-07-05 11:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:37 --> Total execution time: 0.0533
DEBUG - 2022-07-05 11:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:42 --> Total execution time: 0.0560
DEBUG - 2022-07-05 11:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:44 --> Total execution time: 0.1284
DEBUG - 2022-07-05 11:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:48 --> Total execution time: 0.0921
DEBUG - 2022-07-05 11:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:50 --> Total execution time: 0.0691
DEBUG - 2022-07-05 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:50 --> Total execution time: 0.0279
DEBUG - 2022-07-05 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:53 --> Total execution time: 0.1042
DEBUG - 2022-07-05 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:20 --> Total execution time: 0.0698
DEBUG - 2022-07-05 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:22 --> Total execution time: 0.0714
DEBUG - 2022-07-05 11:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:22 --> Total execution time: 0.0514
DEBUG - 2022-07-05 11:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:28 --> Total execution time: 0.0589
DEBUG - 2022-07-05 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:31 --> Total execution time: 0.0512
DEBUG - 2022-07-05 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:39 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:39 --> Total execution time: 0.0712
DEBUG - 2022-07-05 11:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:47 --> Total execution time: 0.0581
DEBUG - 2022-07-05 11:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 11:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:55 --> Total execution time: 0.0542
DEBUG - 2022-07-05 11:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:52:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 21:52:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 21:52:56 --> Total execution time: 0.2293
DEBUG - 2022-07-05 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:11 --> Total execution time: 0.0514
DEBUG - 2022-07-05 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:54:46 --> Total execution time: 0.0611
DEBUG - 2022-07-05 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:54:49 --> Total execution time: 0.1254
DEBUG - 2022-07-05 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:57:52 --> Total execution time: 0.2343
DEBUG - 2022-07-05 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:58:48 --> Total execution time: 0.0563
DEBUG - 2022-07-05 11:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:54 --> Total execution time: 0.0385
DEBUG - 2022-07-05 11:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:03:01 --> Total execution time: 0.2981
DEBUG - 2022-07-05 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:34:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:04:58 --> Total execution time: 0.0422
DEBUG - 2022-07-05 11:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:36:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:09 --> Total execution time: 0.0722
DEBUG - 2022-07-05 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:14 --> Total execution time: 0.0389
DEBUG - 2022-07-05 11:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:19 --> Total execution time: 0.0741
DEBUG - 2022-07-05 11:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:25 --> Total execution time: 0.0546
DEBUG - 2022-07-05 11:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 11:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:26 --> Total execution time: 0.0522
DEBUG - 2022-07-05 11:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:35 --> Total execution time: 0.0614
DEBUG - 2022-07-05 11:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:09:28 --> Total execution time: 0.1486
DEBUG - 2022-07-05 11:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:39:29 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:09:29 --> Total execution time: 0.0495
DEBUG - 2022-07-05 11:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:39:38 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:09:38 --> Total execution time: 0.0359
DEBUG - 2022-07-05 11:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:40:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:10:16 --> Total execution time: 0.0357
DEBUG - 2022-07-05 11:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:11:30 --> Total execution time: 0.0588
DEBUG - 2022-07-05 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:42:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:12:13 --> Total execution time: 0.0367
DEBUG - 2022-07-05 11:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:12:18 --> Total execution time: 0.0369
DEBUG - 2022-07-05 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:12:34 --> Total execution time: 0.1159
DEBUG - 2022-07-05 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:12:40 --> Total execution time: 0.0681
DEBUG - 2022-07-05 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:12:51 --> Total execution time: 0.1195
DEBUG - 2022-07-05 11:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:13:01 --> Total execution time: 0.0829
DEBUG - 2022-07-05 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:13:11 --> Total execution time: 0.1302
DEBUG - 2022-07-05 11:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 11:48:39 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 11:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:19:26 --> Total execution time: 0.1267
DEBUG - 2022-07-05 11:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:19:57 --> Total execution time: 0.1683
DEBUG - 2022-07-05 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:20:01 --> Total execution time: 0.1087
DEBUG - 2022-07-05 11:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:20:03 --> Total execution time: 0.0788
DEBUG - 2022-07-05 11:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:20:24 --> Total execution time: 0.0698
DEBUG - 2022-07-05 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:20:26 --> Total execution time: 0.0668
DEBUG - 2022-07-05 11:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:20:39 --> Total execution time: 0.0947
DEBUG - 2022-07-05 11:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:20:43 --> Total execution time: 0.0775
DEBUG - 2022-07-05 11:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:20:54 --> Total execution time: 0.0968
DEBUG - 2022-07-05 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:20:57 --> Total execution time: 0.0936
DEBUG - 2022-07-05 11:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:08 --> Total execution time: 0.0571
DEBUG - 2022-07-05 11:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 11:51:12 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 11:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:17 --> Total execution time: 0.0643
DEBUG - 2022-07-05 11:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:28 --> Total execution time: 0.0689
DEBUG - 2022-07-05 11:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:33 --> Total execution time: 0.0694
DEBUG - 2022-07-05 11:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:44 --> Total execution time: 0.0739
DEBUG - 2022-07-05 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:48 --> Total execution time: 0.0493
DEBUG - 2022-07-05 11:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:51 --> Total execution time: 0.0705
DEBUG - 2022-07-05 11:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:54 --> Total execution time: 0.0759
DEBUG - 2022-07-05 11:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:57 --> Total execution time: 0.0748
DEBUG - 2022-07-05 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:21:59 --> Total execution time: 0.0572
DEBUG - 2022-07-05 11:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:22:00 --> Total execution time: 0.0964
DEBUG - 2022-07-05 11:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:22:09 --> Total execution time: 0.0821
DEBUG - 2022-07-05 11:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:22:16 --> Total execution time: 0.0759
DEBUG - 2022-07-05 11:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:22:21 --> Total execution time: 0.0537
DEBUG - 2022-07-05 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:22:25 --> Total execution time: 0.0882
DEBUG - 2022-07-05 11:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:22:34 --> Total execution time: 0.0512
DEBUG - 2022-07-05 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 11:53:17 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:23:57 --> Total execution time: 0.0333
DEBUG - 2022-07-05 11:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 11:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:23:59 --> Total execution time: 0.0479
DEBUG - 2022-07-05 11:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:54:32 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:24:32 --> Total execution time: 0.0423
DEBUG - 2022-07-05 11:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:24:50 --> Total execution time: 0.1365
DEBUG - 2022-07-05 11:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:55:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 11:55:44 --> 404 Page Not Found: Home2/index
DEBUG - 2022-07-05 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:27:16 --> Total execution time: 0.1273
DEBUG - 2022-07-05 11:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:27:26 --> Total execution time: 0.0661
DEBUG - 2022-07-05 11:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:27:30 --> Total execution time: 0.0490
DEBUG - 2022-07-05 11:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:57:39 --> No URI present. Default controller set.
DEBUG - 2022-07-05 11:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:27:39 --> Total execution time: 0.0443
DEBUG - 2022-07-05 11:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:59:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 11:59:02 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-05 11:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:29:52 --> Total execution time: 0.1381
DEBUG - 2022-07-05 11:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 11:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 11:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:29:57 --> Total execution time: 0.0490
DEBUG - 2022-07-05 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:30:03 --> Total execution time: 0.0506
DEBUG - 2022-07-05 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:30:04 --> Total execution time: 0.0635
DEBUG - 2022-07-05 12:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:00:40 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:30:40 --> Total execution time: 0.0350
DEBUG - 2022-07-05 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:00 --> Total execution time: 0.0485
DEBUG - 2022-07-05 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:13 --> Total execution time: 0.0611
DEBUG - 2022-07-05 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:20 --> Total execution time: 0.0521
DEBUG - 2022-07-05 12:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:23 --> Total execution time: 0.0509
DEBUG - 2022-07-05 12:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:24 --> Total execution time: 0.0416
DEBUG - 2022-07-05 12:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:33 --> Total execution time: 0.0480
DEBUG - 2022-07-05 12:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:51 --> Total execution time: 0.0575
DEBUG - 2022-07-05 12:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:58 --> Total execution time: 0.0840
DEBUG - 2022-07-05 12:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:02:29 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:32:29 --> Total execution time: 0.0584
DEBUG - 2022-07-05 12:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:32:39 --> Total execution time: 1.9824
DEBUG - 2022-07-05 12:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:02:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 12:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:02:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:32:52 --> Total execution time: 0.0510
DEBUG - 2022-07-05 12:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:29 --> Total execution time: 0.0363
DEBUG - 2022-07-05 12:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:31 --> Total execution time: 0.0577
DEBUG - 2022-07-05 12:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:03:31 --> Total execution time: 0.1012
DEBUG - 2022-07-05 12:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:34:03 --> Total execution time: 0.0638
DEBUG - 2022-07-05 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:34:04 --> Total execution time: 0.0328
DEBUG - 2022-07-05 12:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:34:19 --> Total execution time: 0.0482
DEBUG - 2022-07-05 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:07:55 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:37:56 --> Total execution time: 0.1915
DEBUG - 2022-07-05 12:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:07:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:37:58 --> Total execution time: 0.0649
DEBUG - 2022-07-05 12:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:01 --> Total execution time: 0.0976
DEBUG - 2022-07-05 12:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:03 --> Total execution time: 0.0649
DEBUG - 2022-07-05 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:08 --> Total execution time: 0.0527
DEBUG - 2022-07-05 12:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:09 --> Total execution time: 0.0524
DEBUG - 2022-07-05 12:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:12 --> Total execution time: 0.0791
DEBUG - 2022-07-05 12:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:18 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:19 --> Total execution time: 0.0389
DEBUG - 2022-07-05 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:23 --> Total execution time: 0.0591
DEBUG - 2022-07-05 12:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:31 --> Total execution time: 0.1575
DEBUG - 2022-07-05 12:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:42 --> Total execution time: 0.1286
DEBUG - 2022-07-05 12:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:50 --> Total execution time: 0.0790
DEBUG - 2022-07-05 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:58 --> Total execution time: 0.1381
DEBUG - 2022-07-05 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:08:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:38:58 --> Total execution time: 0.0401
DEBUG - 2022-07-05 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:10 --> Total execution time: 0.0363
DEBUG - 2022-07-05 12:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:15 --> Total execution time: 0.0595
DEBUG - 2022-07-05 12:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:15 --> Total execution time: 0.1224
DEBUG - 2022-07-05 12:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:18 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:18 --> Total execution time: 0.0570
DEBUG - 2022-07-05 12:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-05 12:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:19 --> Total execution time: 0.0709
DEBUG - 2022-07-05 12:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:20 --> Total execution time: 0.0831
DEBUG - 2022-07-05 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:28 --> Total execution time: 0.0634
DEBUG - 2022-07-05 12:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:31 --> Total execution time: 0.0547
DEBUG - 2022-07-05 12:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:33 --> Total execution time: 0.0512
DEBUG - 2022-07-05 12:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:34 --> Total execution time: 0.0590
DEBUG - 2022-07-05 12:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:34 --> Total execution time: 0.0523
DEBUG - 2022-07-05 12:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:34 --> Total execution time: 0.0914
DEBUG - 2022-07-05 12:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:35 --> Total execution time: 0.0753
DEBUG - 2022-07-05 12:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:36 --> Total execution time: 0.0542
DEBUG - 2022-07-05 12:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:09:38 --> Total execution time: 0.0573
DEBUG - 2022-07-05 12:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:44 --> Total execution time: 0.0639
DEBUG - 2022-07-05 12:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:09:48 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:39:48 --> Total execution time: 0.0575
DEBUG - 2022-07-05 12:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:10:01 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:40:01 --> Total execution time: 0.0551
DEBUG - 2022-07-05 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:40:08 --> Total execution time: 0.0592
DEBUG - 2022-07-05 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:40:25 --> Total execution time: 0.0486
DEBUG - 2022-07-05 12:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:10:35 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:40:35 --> Total execution time: 0.0590
DEBUG - 2022-07-05 12:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:40:47 --> Total execution time: 0.0480
DEBUG - 2022-07-05 12:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:10:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:40:50 --> Total execution time: 0.0824
DEBUG - 2022-07-05 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:10:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:40:52 --> Total execution time: 0.0536
DEBUG - 2022-07-05 12:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:41:07 --> Total execution time: 0.0548
DEBUG - 2022-07-05 12:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:11:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:41:07 --> Total execution time: 0.0435
DEBUG - 2022-07-05 12:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:43:54 --> Total execution time: 0.1322
DEBUG - 2022-07-05 12:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:13 --> Total execution time: 0.1308
DEBUG - 2022-07-05 12:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:17 --> Total execution time: 0.0478
DEBUG - 2022-07-05 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:25 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:25 --> Total execution time: 0.0506
DEBUG - 2022-07-05 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:48 --> Total execution time: 0.0677
DEBUG - 2022-07-05 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:48 --> Total execution time: 0.0573
DEBUG - 2022-07-05 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:48 --> Total execution time: 0.0675
DEBUG - 2022-07-05 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:48 --> Total execution time: 0.0668
DEBUG - 2022-07-05 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:48 --> Total execution time: 0.1954
DEBUG - 2022-07-05 12:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:48 --> Total execution time: 0.0727
DEBUG - 2022-07-05 12:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:49 --> Total execution time: 0.0611
DEBUG - 2022-07-05 12:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:49 --> Total execution time: 0.0661
DEBUG - 2022-07-05 12:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:55 --> Total execution time: 0.0573
DEBUG - 2022-07-05 12:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:16:03 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:46:03 --> Total execution time: 0.0358
DEBUG - 2022-07-05 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:16:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:46:10 --> Total execution time: 0.0579
DEBUG - 2022-07-05 12:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:46:29 --> Total execution time: 0.0501
DEBUG - 2022-07-05 12:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:16:44 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:46:44 --> Total execution time: 0.0352
DEBUG - 2022-07-05 12:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:16:44 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:46:44 --> Total execution time: 0.0521
DEBUG - 2022-07-05 12:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:17:01 --> Total execution time: 0.0878
DEBUG - 2022-07-05 12:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:17:07 --> Total execution time: 0.0542
DEBUG - 2022-07-05 12:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:17:07 --> Total execution time: 0.1396
DEBUG - 2022-07-05 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:17:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:47:13 --> Total execution time: 0.0659
DEBUG - 2022-07-05 12:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:17:32 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:18:45 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:48:45 --> Total execution time: 0.0690
DEBUG - 2022-07-05 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:18:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:48:47 --> Total execution time: 0.0439
DEBUG - 2022-07-05 12:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:48:49 --> Total execution time: 0.0457
DEBUG - 2022-07-05 12:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:21:21 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:51:21 --> Total execution time: 0.1059
DEBUG - 2022-07-05 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:56:58 --> Total execution time: 0.0640
DEBUG - 2022-07-05 12:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:57:21 --> Total execution time: 0.0512
DEBUG - 2022-07-05 12:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:27:21 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:57:21 --> Total execution time: 0.0368
DEBUG - 2022-07-05 12:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:27:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:27:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 12:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:26 --> Total execution time: 0.0523
DEBUG - 2022-07-05 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:27 --> Total execution time: 0.0583
DEBUG - 2022-07-05 12:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:27:27 --> Total execution time: 0.0974
DEBUG - 2022-07-05 12:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:16 --> Total execution time: 0.0474
DEBUG - 2022-07-05 12:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:28:46 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:46 --> Total execution time: 0.0600
DEBUG - 2022-07-05 12:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:59:01 --> Total execution time: 0.1303
DEBUG - 2022-07-05 12:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:59:54 --> Total execution time: 0.0725
DEBUG - 2022-07-05 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:29:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:59:59 --> Total execution time: 0.0424
DEBUG - 2022-07-05 12:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:00:11 --> Total execution time: 0.0771
DEBUG - 2022-07-05 12:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:30:24 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:00:24 --> Total execution time: 0.0388
DEBUG - 2022-07-05 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:30:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 12:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:00:49 --> Total execution time: 0.0595
DEBUG - 2022-07-05 12:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:01:18 --> Total execution time: 0.0539
DEBUG - 2022-07-05 12:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:01:22 --> Total execution time: 0.0556
DEBUG - 2022-07-05 12:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:01:29 --> Total execution time: 0.0610
DEBUG - 2022-07-05 12:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:01:46 --> Total execution time: 0.0553
DEBUG - 2022-07-05 12:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:01:54 --> Total execution time: 0.0551
DEBUG - 2022-07-05 12:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:55 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:01:55 --> Total execution time: 0.0347
DEBUG - 2022-07-05 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:56 --> 404 Page Not Found: Panelstxt/index
DEBUG - 2022-07-05 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:56 --> 404 Page Not Found: Wp-includes/upload_index.php
DEBUG - 2022-07-05 12:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:57 --> 404 Page Not Found: Upload_indexphp/index
DEBUG - 2022-07-05 12:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:57 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 12:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:57 --> 404 Page Not Found: Th3_alphaphp/index
DEBUG - 2022-07-05 12:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:57 --> 404 Page Not Found: Wp-includes/th3_alpha.php
DEBUG - 2022-07-05 12:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:58 --> 404 Page Not Found: Vphp/index
DEBUG - 2022-07-05 12:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:58 --> 404 Page Not Found: Class-wp-registroyphp/index
DEBUG - 2022-07-05 12:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:58 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 12:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:31:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:31:58 --> 404 Page Not Found: Wp-content/class-wp-type-registroy.php
DEBUG - 2022-07-05 12:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:05:17 --> Total execution time: 0.1978
DEBUG - 2022-07-05 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:05:25 --> Total execution time: 0.0636
DEBUG - 2022-07-05 12:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:05:31 --> Total execution time: 0.0708
DEBUG - 2022-07-05 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:05:41 --> Total execution time: 0.0507
DEBUG - 2022-07-05 12:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:06:52 --> Total execution time: 0.0608
DEBUG - 2022-07-05 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:36:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:06:57 --> Total execution time: 0.0401
DEBUG - 2022-07-05 12:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:03 --> Total execution time: 0.0766
DEBUG - 2022-07-05 12:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:09 --> Total execution time: 0.0343
DEBUG - 2022-07-05 12:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:16 --> Total execution time: 0.0513
DEBUG - 2022-07-05 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:25 --> Total execution time: 0.0458
DEBUG - 2022-07-05 12:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:28 --> Total execution time: 0.0482
DEBUG - 2022-07-05 12:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:37:37 --> Total execution time: 0.0468
DEBUG - 2022-07-05 12:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:38 --> Total execution time: 0.0734
DEBUG - 2022-07-05 12:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:52 --> Total execution time: 0.0709
DEBUG - 2022-07-05 12:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:14 --> Total execution time: 0.0533
DEBUG - 2022-07-05 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:22 --> Total execution time: 0.0592
DEBUG - 2022-07-05 12:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:47 --> Total execution time: 0.0568
DEBUG - 2022-07-05 12:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:09:13 --> Total execution time: 0.0583
DEBUG - 2022-07-05 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:09:24 --> Total execution time: 0.0544
DEBUG - 2022-07-05 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:09:40 --> Total execution time: 0.0525
DEBUG - 2022-07-05 12:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:09:51 --> Total execution time: 0.1304
DEBUG - 2022-07-05 12:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:10:28 --> Total execution time: 0.0537
DEBUG - 2022-07-05 12:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:10:45 --> Total execution time: 0.0550
DEBUG - 2022-07-05 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:03 --> Total execution time: 0.0514
DEBUG - 2022-07-05 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:08 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:08 --> Total execution time: 0.0387
DEBUG - 2022-07-05 12:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:08 --> Total execution time: 0.0874
DEBUG - 2022-07-05 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:14 --> Total execution time: 0.0536
DEBUG - 2022-07-05 12:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:17 --> Total execution time: 0.0385
DEBUG - 2022-07-05 12:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:18 --> Total execution time: 0.1048
DEBUG - 2022-07-05 12:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:21 --> Total execution time: 0.1143
DEBUG - 2022-07-05 12:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:23 --> Total execution time: 0.0739
DEBUG - 2022-07-05 12:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:23 --> Total execution time: 0.1114
DEBUG - 2022-07-05 12:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:29 --> Total execution time: 0.0809
DEBUG - 2022-07-05 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:30 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:30 --> Total execution time: 0.0548
DEBUG - 2022-07-05 12:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:38 --> Total execution time: 0.0893
DEBUG - 2022-07-05 12:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:44 --> Total execution time: 0.0764
DEBUG - 2022-07-05 12:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 12:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:45 --> Total execution time: 0.0502
DEBUG - 2022-07-05 12:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:50 --> Total execution time: 0.0505
DEBUG - 2022-07-05 12:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:55 --> Total execution time: 0.0534
DEBUG - 2022-07-05 12:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:01 --> Total execution time: 0.0594
DEBUG - 2022-07-05 12:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:03 --> Total execution time: 0.0534
DEBUG - 2022-07-05 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:05 --> Total execution time: 0.1424
DEBUG - 2022-07-05 12:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:05 --> Total execution time: 0.0677
DEBUG - 2022-07-05 12:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:09 --> Total execution time: 0.0653
DEBUG - 2022-07-05 12:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:10 --> Total execution time: 0.1264
DEBUG - 2022-07-05 12:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:14 --> Total execution time: 0.0635
DEBUG - 2022-07-05 12:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:19 --> Total execution time: 0.0752
DEBUG - 2022-07-05 12:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:24 --> Total execution time: 0.0647
DEBUG - 2022-07-05 12:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:27 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:27 --> Total execution time: 0.0515
DEBUG - 2022-07-05 12:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:29 --> Total execution time: 0.0466
DEBUG - 2022-07-05 12:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:12:35 --> Total execution time: 0.0779
DEBUG - 2022-07-05 12:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:43:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 12:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:49:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 12:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:19:20 --> Total execution time: 0.1092
DEBUG - 2022-07-05 12:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:23:18 --> Total execution time: 0.1929
DEBUG - 2022-07-05 12:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 12:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:23:26 --> Total execution time: 0.0623
DEBUG - 2022-07-05 12:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 12:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 12:56:44 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-05 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:30:02 --> Total execution time: 0.1421
DEBUG - 2022-07-05 13:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:31:27 --> Total execution time: 0.0525
DEBUG - 2022-07-05 13:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:33:02 --> Total execution time: 0.0512
DEBUG - 2022-07-05 13:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:33:57 --> Total execution time: 0.1785
DEBUG - 2022-07-05 13:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:34:05 --> Total execution time: 0.0872
DEBUG - 2022-07-05 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:08:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 13:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:38:15 --> Total execution time: 0.1161
DEBUG - 2022-07-05 13:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:08:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 13:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:38:16 --> Total execution time: 0.0483
DEBUG - 2022-07-05 13:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:08:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 13:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:38:52 --> Total execution time: 0.0350
DEBUG - 2022-07-05 13:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:58:03 --> Total execution time: 0.3101
DEBUG - 2022-07-05 13:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:58:36 --> Total execution time: 0.0890
DEBUG - 2022-07-05 13:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:58:59 --> Total execution time: 0.1083
DEBUG - 2022-07-05 13:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:59:19 --> Total execution time: 0.0580
DEBUG - 2022-07-05 13:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:59:24 --> Total execution time: 0.0835
DEBUG - 2022-07-05 13:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:30:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 13:30:42 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 13:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 13:33:17 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 13:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:33:17 --> No URI present. Default controller set.
DEBUG - 2022-07-05 13:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 13:35:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 13:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:40:49 --> No URI present. Default controller set.
DEBUG - 2022-07-05 13:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 13:49:37 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-05 13:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:58:42 --> Total execution time: 0.0485
DEBUG - 2022-07-05 13:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 13:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 13:59:24 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 13:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 13:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 13:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:00:03 --> No URI present. Default controller set.
DEBUG - 2022-07-05 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:09:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 14:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:58:32 --> No URI present. Default controller set.
DEBUG - 2022-07-05 14:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 14:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 14:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 14:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 15:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 15:16:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 15:16:28 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 15:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 15:19:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 15:19:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 15:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 15:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 15:20:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 15:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 15:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 15:20:23 --> 404 Page Not Found: Quizzes/quiz-2
DEBUG - 2022-07-05 15:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 15:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 15:21:46 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 15:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 15:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 15:47:00 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 16:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 16:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 16:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 16:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 16:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 16:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 16:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 16:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 16:59:26 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 17:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 17:02:00 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 17:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 17:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 17:04:11 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 17:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 17:04:11 --> No URI present. Default controller set.
DEBUG - 2022-07-05 17:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 17:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 17:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 17:04:18 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 17:04:20 --> No URI present. Default controller set.
DEBUG - 2022-07-05 17:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 17:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 17:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 17:04:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 17:04:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 17:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 17:28:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 17:28:41 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:28:55 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:28:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:28:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 18:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:28:57 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 18:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:28:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:28:59 --> 404 Page Not Found: Panelstxt/index
DEBUG - 2022-07-05 18:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:00 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 18:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:02 --> 404 Page Not Found: Wp-includes/upload_index.php
DEBUG - 2022-07-05 18:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:04 --> 404 Page Not Found: Upload_indexphp/index
DEBUG - 2022-07-05 18:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:06 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 18:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:08 --> 404 Page Not Found: Th3_alphaphp/index
DEBUG - 2022-07-05 18:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:10 --> 404 Page Not Found: Wp-includes/th3_alpha.php
DEBUG - 2022-07-05 18:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:11 --> 404 Page Not Found: Vphp/index
DEBUG - 2022-07-05 18:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:12 --> 404 Page Not Found: Class-wp-registroyphp/index
DEBUG - 2022-07-05 18:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:14 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 18:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:29:15 --> 404 Page Not Found: Wp-content/class-wp-type-registroy.php
DEBUG - 2022-07-05 18:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:30:45 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:30:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 18:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:35:15 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-05 18:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:35:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:35:15 --> 404 Page Not Found: ALFA_DATA/alfacgiapi
DEBUG - 2022-07-05 18:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:35:15 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-07-05 18:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:35:15 --> 404 Page Not Found: Alfacgiapi/perl.alfa
DEBUG - 2022-07-05 18:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:35:16 --> 404 Page Not Found: Iyihvsmiphp/index
DEBUG - 2022-07-05 18:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:36:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 18:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:37:35 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:37:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 18:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:38:33 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:38:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:38:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 18:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:40:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:40:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:43:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 18:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:44:19 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:44:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 18:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:45:10 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 18:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:45:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:45:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:45:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 18:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:46:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:46:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 18:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:48:57 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:49:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:50:51 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-05 18:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:51:03 --> Total execution time: 0.0498
DEBUG - 2022-07-05 18:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:52:14 --> No URI present. Default controller set.
DEBUG - 2022-07-05 18:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 18:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 18:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 18:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 18:52:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:06:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 19:06:15 --> 404 Page Not Found: S_nephp/index
DEBUG - 2022-07-05 19:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 19:08:25 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 19:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:28:21 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:30:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:38:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:38:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 19:39:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 19:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 19:39:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 19:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:12 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:26 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:51:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:51:01 --> No URI present. Default controller set.
DEBUG - 2022-07-05 19:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:51:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 19:51:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 19:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 19:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 19:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 19:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:03:05 --> No URI present. Default controller set.
DEBUG - 2022-07-05 20:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:18:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 20:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:18:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:18:26 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 20:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:19:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 20:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:19:18 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 20:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:19:21 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-05 20:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:20:48 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:22:51 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 20:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:26:35 --> 404 Page Not Found: Apple-app-site-association/index
DEBUG - 2022-07-05 20:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:26:35 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-07-05 20:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:26:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:26:36 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 20:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:36:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 20:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:36:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 20:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:36:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 20:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 20:45:46 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 20:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:48:09 --> No URI present. Default controller set.
DEBUG - 2022-07-05 20:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:23 --> No URI present. Default controller set.
DEBUG - 2022-07-05 20:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 20:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 20:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 20:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:02:33 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:02:34 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 21:02:40 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-05 21:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 21:02:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 21:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:06:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:06:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:22:11 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:23:58 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:44 --> Total execution time: 0.0794
DEBUG - 2022-07-05 21:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:37:30 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:37:42 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:43:14 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:44:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:44:46 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:44:50 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:45 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:50:24 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:26 --> Total execution time: 0.0486
DEBUG - 2022-07-05 21:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:28 --> Total execution time: 0.0832
DEBUG - 2022-07-05 21:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:28 --> Total execution time: 0.1274
DEBUG - 2022-07-05 21:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:33 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:34 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 21:55:39 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 21:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:56:51 --> No URI present. Default controller set.
DEBUG - 2022-07-05 21:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 21:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 21:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 21:56:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 21:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 21:58:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 21:58:04 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 22:00:12 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 22:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:00:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:02:23 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:05:32 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:07:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:07:17 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:10:26 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:10:27 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:07 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:30 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:18:25 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:19:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 22:19:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 22:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 22:23:05 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-05 22:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:31:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:31:41 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:32:15 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:33:39 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:44:31 --> Total execution time: 0.1040
DEBUG - 2022-07-05 22:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:47:25 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:47:51 --> Total execution time: 0.0480
DEBUG - 2022-07-05 22:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:47:56 --> Total execution time: 0.0477
DEBUG - 2022-07-05 22:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:47:56 --> Total execution time: 0.0962
DEBUG - 2022-07-05 22:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:48:36 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:49:09 --> Total execution time: 0.0483
DEBUG - 2022-07-05 22:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:49:16 --> Total execution time: 0.0591
DEBUG - 2022-07-05 22:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:49:16 --> Total execution time: 0.1333
DEBUG - 2022-07-05 22:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:49:43 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:52:06 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:53:37 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:55:13 --> No URI present. Default controller set.
DEBUG - 2022-07-05 22:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 22:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 22:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 22:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:02:40 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-07-05 23:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:02:46 --> 404 Page Not Found: Wp-loadphp/index
DEBUG - 2022-07-05 23:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:20:31 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:12 --> Total execution time: 0.0364
DEBUG - 2022-07-05 23:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:14 --> Total execution time: 0.0745
DEBUG - 2022-07-05 23:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:14 --> Total execution time: 0.1098
DEBUG - 2022-07-05 23:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:23 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:25:00 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:26:46 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:26:47 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:14 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:26 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:53 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:29:59 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:30:08 --> 404 Page Not Found: Category/sports
DEBUG - 2022-07-05 23:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:35:15 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-05 23:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:35:16 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:36:30 --> Total execution time: 0.0610
DEBUG - 2022-07-05 23:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:37:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:37:40 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-05 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:38:08 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:38:10 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:39:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:39:41 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-05 23:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:44:04 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-07-05 23:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:44:57 --> 404 Page Not Found: C9Aa4php/index
DEBUG - 2022-07-05 23:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:45:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:45:42 --> 404 Page Not Found: Wp-plainphp/index
DEBUG - 2022-07-05 23:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:46:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:46:22 --> 404 Page Not Found: C9Aa4php/index
DEBUG - 2022-07-05 23:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:46:56 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:46:57 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 23:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:47:20 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-05 23:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:47:36 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:47:38 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-05 23:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:47:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-05 23:47:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-05 23:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:47:52 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:55:53 --> No URI present. Default controller set.
DEBUG - 2022-07-05 23:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-05 23:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-05 23:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-05 23:56:37 --> Encryption: Auto-configured driver 'openssl'.
