<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-20 00:00:09 --> Total execution time: 0.0428
DEBUG - 2022-06-20 00:10:24 --> Total execution time: 0.1260
DEBUG - 2022-06-20 00:15:10 --> Total execution time: 0.1134
DEBUG - 2022-06-20 00:21:50 --> Total execution time: 0.1642
DEBUG - 2022-06-20 00:21:52 --> Total execution time: 0.1051
DEBUG - 2022-06-20 00:30:03 --> Total execution time: 0.2253
DEBUG - 2022-06-20 00:34:33 --> Total execution time: 0.1202
DEBUG - 2022-06-20 00:36:32 --> Total execution time: 0.0425
DEBUG - 2022-06-20 00:37:12 --> Total execution time: 0.0307
DEBUG - 2022-06-20 00:38:38 --> Total execution time: 0.0334
DEBUG - 2022-06-20 00:38:58 --> Total execution time: 0.0437
DEBUG - 2022-06-20 00:39:03 --> Total execution time: 0.0414
DEBUG - 2022-06-20 00:39:05 --> Total execution time: 0.0315
DEBUG - 2022-06-20 00:39:05 --> Total execution time: 0.0466
DEBUG - 2022-06-20 00:39:06 --> Total execution time: 0.0736
DEBUG - 2022-06-20 00:39:08 --> Total execution time: 0.0382
DEBUG - 2022-06-20 00:39:20 --> Total execution time: 0.0341
DEBUG - 2022-06-20 00:39:30 --> Total execution time: 0.0429
DEBUG - 2022-06-20 00:40:31 --> Total execution time: 0.0324
DEBUG - 2022-06-20 00:40:31 --> Total execution time: 0.0324
DEBUG - 2022-06-20 00:49:58 --> Total execution time: 0.1974
DEBUG - 2022-06-20 01:30:03 --> Total execution time: 0.3278
DEBUG - 2022-06-20 01:37:50 --> Total execution time: 0.1864
DEBUG - 2022-06-20 01:47:44 --> Total execution time: 0.1144
DEBUG - 2022-06-20 01:48:04 --> Total execution time: 0.0428
DEBUG - 2022-06-20 01:49:57 --> Total execution time: 0.0461
DEBUG - 2022-06-20 01:50:00 --> Total execution time: 0.0431
DEBUG - 2022-06-20 01:50:00 --> Total execution time: 0.0506
DEBUG - 2022-06-20 01:50:00 --> Total execution time: 0.0502
DEBUG - 2022-06-20 01:56:35 --> Total execution time: 0.0717
DEBUG - 2022-06-20 02:12:43 --> Total execution time: 0.0672
DEBUG - 2022-06-20 02:30:02 --> Total execution time: 0.2275
DEBUG - 2022-06-20 02:45:26 --> Total execution time: 0.1260
DEBUG - 2022-06-20 02:50:26 --> Total execution time: 0.0411
DEBUG - 2022-06-20 02:50:33 --> Total execution time: 0.0721
DEBUG - 2022-06-20 02:50:38 --> Total execution time: 0.0823
DEBUG - 2022-06-20 02:50:42 --> Total execution time: 0.0571
DEBUG - 2022-06-20 02:50:51 --> Total execution time: 0.0421
DEBUG - 2022-06-20 02:51:15 --> Total execution time: 0.0416
DEBUG - 2022-06-20 02:51:18 --> Total execution time: 0.1310
DEBUG - 2022-06-20 02:51:22 --> Total execution time: 0.0457
DEBUG - 2022-06-20 02:51:25 --> Total execution time: 0.0592
DEBUG - 2022-06-20 02:51:27 --> Total execution time: 0.0533
DEBUG - 2022-06-20 02:51:35 --> Total execution time: 0.0546
DEBUG - 2022-06-20 02:52:09 --> Total execution time: 0.0589
DEBUG - 2022-06-20 02:52:26 --> Total execution time: 0.0425
DEBUG - 2022-06-20 03:00:15 --> Total execution time: 0.0952
DEBUG - 2022-06-20 03:02:47 --> Total execution time: 0.1662
DEBUG - 2022-06-20 03:04:40 --> Total execution time: 0.0422
DEBUG - 2022-06-20 03:07:51 --> Total execution time: 0.0945
DEBUG - 2022-06-20 03:18:46 --> Total execution time: 0.1998
DEBUG - 2022-06-20 03:18:46 --> Total execution time: 0.2094
DEBUG - 2022-06-20 03:18:48 --> Total execution time: 0.0564
DEBUG - 2022-06-20 03:30:03 --> Total execution time: 0.1549
DEBUG - 2022-06-20 03:31:11 --> Total execution time: 0.1218
DEBUG - 2022-06-20 03:35:39 --> Total execution time: 0.0815
DEBUG - 2022-06-20 03:47:45 --> Total execution time: 0.0929
DEBUG - 2022-06-20 03:47:45 --> Total execution time: 0.0309
DEBUG - 2022-06-20 03:55:26 --> Total execution time: 0.0861
DEBUG - 2022-06-20 03:55:28 --> Total execution time: 0.0407
DEBUG - 2022-06-20 03:55:29 --> Total execution time: 0.0447
DEBUG - 2022-06-20 04:00:26 --> Total execution time: 0.0423
DEBUG - 2022-06-20 04:24:26 --> Total execution time: 0.1241
DEBUG - 2022-06-20 04:30:02 --> Total execution time: 0.1776
DEBUG - 2022-06-20 05:09:26 --> Total execution time: 0.1736
DEBUG - 2022-06-20 05:09:26 --> Total execution time: 0.0347
DEBUG - 2022-06-20 05:09:45 --> Total execution time: 0.0304
DEBUG - 2022-06-20 05:10:06 --> Total execution time: 0.0558
DEBUG - 2022-06-20 05:10:25 --> Total execution time: 0.0518
DEBUG - 2022-06-20 05:11:04 --> Total execution time: 0.0332
DEBUG - 2022-06-20 05:11:19 --> Total execution time: 0.0332
DEBUG - 2022-06-20 05:12:15 --> Total execution time: 0.0479
DEBUG - 2022-06-20 05:12:16 --> Total execution time: 0.0434
DEBUG - 2022-06-20 05:12:25 --> Total execution time: 0.0326
DEBUG - 2022-06-20 05:12:36 --> Total execution time: 0.0388
DEBUG - 2022-06-20 05:13:01 --> Total execution time: 0.0439
DEBUG - 2022-06-20 05:13:14 --> Total execution time: 0.0645
DEBUG - 2022-06-20 05:13:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 05:13:15 --> Total execution time: 0.0418
DEBUG - 2022-06-20 05:13:55 --> Total execution time: 0.0405
DEBUG - 2022-06-20 05:13:56 --> Total execution time: 0.0844
DEBUG - 2022-06-20 05:14:28 --> Total execution time: 0.0871
DEBUG - 2022-06-20 05:14:46 --> Total execution time: 0.0603
DEBUG - 2022-06-20 05:14:48 --> Total execution time: 0.0427
DEBUG - 2022-06-20 05:30:03 --> Total execution time: 0.2136
DEBUG - 2022-06-20 05:43:58 --> Total execution time: 0.1023
DEBUG - 2022-06-20 05:46:00 --> Total execution time: 0.0577
DEBUG - 2022-06-20 05:46:01 --> Total execution time: 0.0472
DEBUG - 2022-06-20 05:47:41 --> Total execution time: 0.0280
DEBUG - 2022-06-20 05:52:57 --> Total execution time: 0.0797
DEBUG - 2022-06-20 06:04:22 --> Total execution time: 0.1236
DEBUG - 2022-06-20 06:04:26 --> Total execution time: 0.0336
DEBUG - 2022-06-20 06:04:35 --> Total execution time: 0.0703
DEBUG - 2022-06-20 06:07:03 --> Total execution time: 0.0872
DEBUG - 2022-06-20 06:07:09 --> Total execution time: 0.0324
DEBUG - 2022-06-20 06:07:14 --> Total execution time: 0.0478
DEBUG - 2022-06-20 06:09:01 --> Total execution time: 0.0413
DEBUG - 2022-06-20 06:11:34 --> Total execution time: 0.0397
DEBUG - 2022-06-20 06:14:05 --> Total execution time: 0.0907
DEBUG - 2022-06-20 06:14:14 --> Total execution time: 0.0400
DEBUG - 2022-06-20 06:14:39 --> Total execution time: 0.0758
DEBUG - 2022-06-20 06:14:45 --> Total execution time: 0.0427
DEBUG - 2022-06-20 06:14:49 --> Total execution time: 0.0581
DEBUG - 2022-06-20 06:15:25 --> Total execution time: 0.0318
DEBUG - 2022-06-20 06:15:31 --> Total execution time: 0.0400
DEBUG - 2022-06-20 06:15:34 --> Total execution time: 0.0559
DEBUG - 2022-06-20 06:15:37 --> Total execution time: 0.0390
DEBUG - 2022-06-20 06:15:56 --> Total execution time: 0.0533
DEBUG - 2022-06-20 06:16:10 --> Total execution time: 0.0490
DEBUG - 2022-06-20 06:16:13 --> Total execution time: 0.0643
DEBUG - 2022-06-20 06:16:43 --> Total execution time: 0.0344
DEBUG - 2022-06-20 06:17:19 --> Total execution time: 0.0330
DEBUG - 2022-06-20 06:22:56 --> Total execution time: 0.0980
DEBUG - 2022-06-20 06:29:53 --> Total execution time: 0.1358
DEBUG - 2022-06-20 06:30:02 --> Total execution time: 0.0558
DEBUG - 2022-06-20 06:37:12 --> Total execution time: 0.0905
DEBUG - 2022-06-20 06:37:16 --> Total execution time: 0.0419
DEBUG - 2022-06-20 06:42:21 --> Total execution time: 0.1260
DEBUG - 2022-06-20 06:42:22 --> Total execution time: 0.0403
DEBUG - 2022-06-20 06:42:24 --> Total execution time: 0.0413
DEBUG - 2022-06-20 06:43:44 --> Total execution time: 0.0519
DEBUG - 2022-06-20 06:43:52 --> Total execution time: 0.0409
DEBUG - 2022-06-20 06:44:03 --> Total execution time: 0.0299
DEBUG - 2022-06-20 06:44:06 --> Total execution time: 0.0484
DEBUG - 2022-06-20 06:44:08 --> Total execution time: 0.0387
DEBUG - 2022-06-20 06:44:15 --> Total execution time: 0.0640
DEBUG - 2022-06-20 06:44:18 --> Total execution time: 0.0965
DEBUG - 2022-06-20 06:44:27 --> Total execution time: 0.0431
DEBUG - 2022-06-20 06:44:27 --> Total execution time: 0.0333
DEBUG - 2022-06-20 06:44:34 --> Total execution time: 0.0462
DEBUG - 2022-06-20 06:44:37 --> Total execution time: 0.0489
DEBUG - 2022-06-20 06:44:49 --> Total execution time: 0.0299
DEBUG - 2022-06-20 06:44:49 --> Total execution time: 0.0396
DEBUG - 2022-06-20 06:54:27 --> Total execution time: 0.1963
DEBUG - 2022-06-20 06:57:33 --> Total execution time: 0.0409
DEBUG - 2022-06-20 07:02:04 --> Total execution time: 0.1055
DEBUG - 2022-06-20 07:02:06 --> Total execution time: 0.0413
DEBUG - 2022-06-20 07:02:16 --> Total execution time: 0.0329
DEBUG - 2022-06-20 07:02:32 --> Total execution time: 0.0617
DEBUG - 2022-06-20 07:02:47 --> Total execution time: 0.0494
DEBUG - 2022-06-20 07:03:23 --> Total execution time: 0.0444
DEBUG - 2022-06-20 07:03:38 --> Total execution time: 0.0513
DEBUG - 2022-06-20 07:03:43 --> Total execution time: 0.0475
DEBUG - 2022-06-20 07:03:57 --> Total execution time: 0.0418
DEBUG - 2022-06-20 07:04:01 --> Total execution time: 0.0438
DEBUG - 2022-06-20 07:04:07 --> Total execution time: 0.0745
DEBUG - 2022-06-20 07:04:11 --> Total execution time: 0.0756
DEBUG - 2022-06-20 07:04:19 --> Total execution time: 0.0900
DEBUG - 2022-06-20 07:04:32 --> Total execution time: 0.0412
DEBUG - 2022-06-20 07:04:51 --> Total execution time: 1.9067
DEBUG - 2022-06-20 07:05:20 --> Total execution time: 0.0729
DEBUG - 2022-06-20 07:05:37 --> Total execution time: 0.0438
DEBUG - 2022-06-20 07:05:44 --> Total execution time: 0.0633
DEBUG - 2022-06-20 07:05:56 --> Total execution time: 0.0394
DEBUG - 2022-06-20 07:06:04 --> Total execution time: 0.0414
DEBUG - 2022-06-20 07:06:11 --> Total execution time: 0.0407
DEBUG - 2022-06-20 07:06:25 --> Total execution time: 0.0457
DEBUG - 2022-06-20 07:06:54 --> Total execution time: 0.0483
DEBUG - 2022-06-20 07:07:34 --> Total execution time: 0.1017
DEBUG - 2022-06-20 07:07:41 --> Total execution time: 0.0934
DEBUG - 2022-06-20 07:08:09 --> Total execution time: 0.0411
DEBUG - 2022-06-20 07:08:13 --> Total execution time: 0.0405
DEBUG - 2022-06-20 07:16:14 --> Total execution time: 0.0485
DEBUG - 2022-06-20 07:16:21 --> Total execution time: 0.0507
DEBUG - 2022-06-20 07:16:32 --> Total execution time: 0.0686
DEBUG - 2022-06-20 07:17:04 --> Total execution time: 0.0470
DEBUG - 2022-06-20 07:17:22 --> Total execution time: 0.0558
DEBUG - 2022-06-20 07:17:40 --> Total execution time: 1.4623
DEBUG - 2022-06-20 07:17:57 --> Total execution time: 0.0427
DEBUG - 2022-06-20 07:18:54 --> Total execution time: 0.0317
DEBUG - 2022-06-20 07:19:47 --> Total execution time: 0.0305
DEBUG - 2022-06-20 07:20:00 --> Total execution time: 0.0405
DEBUG - 2022-06-20 07:20:08 --> Total execution time: 0.0452
DEBUG - 2022-06-20 07:20:11 --> Total execution time: 0.0731
DEBUG - 2022-06-20 07:20:13 --> Total execution time: 0.0499
DEBUG - 2022-06-20 07:20:13 --> Total execution time: 0.0461
DEBUG - 2022-06-20 07:20:18 --> Total execution time: 0.0391
DEBUG - 2022-06-20 07:20:33 --> Total execution time: 0.0461
DEBUG - 2022-06-20 07:20:40 --> Total execution time: 0.0305
DEBUG - 2022-06-20 07:20:41 --> Total execution time: 0.0343
DEBUG - 2022-06-20 07:20:46 --> Total execution time: 0.0428
DEBUG - 2022-06-20 07:20:49 --> Total execution time: 0.0324
DEBUG - 2022-06-20 07:21:11 --> Total execution time: 0.0422
DEBUG - 2022-06-20 07:21:19 --> Total execution time: 0.0633
DEBUG - 2022-06-20 07:21:28 --> Total execution time: 0.0475
DEBUG - 2022-06-20 07:21:32 --> Total execution time: 0.0489
DEBUG - 2022-06-20 07:22:00 --> Total execution time: 0.0358
DEBUG - 2022-06-20 07:22:01 --> Total execution time: 0.0308
DEBUG - 2022-06-20 07:23:05 --> Total execution time: 0.0302
DEBUG - 2022-06-20 07:25:05 --> Total execution time: 0.0323
DEBUG - 2022-06-20 07:25:19 --> Total execution time: 0.0467
DEBUG - 2022-06-20 07:26:33 --> Total execution time: 0.0524
DEBUG - 2022-06-20 07:27:27 --> Total execution time: 0.0344
DEBUG - 2022-06-20 07:27:28 --> Total execution time: 0.0445
DEBUG - 2022-06-20 07:28:12 --> Total execution time: 1.8536
DEBUG - 2022-06-20 07:28:29 --> Total execution time: 0.0500
DEBUG - 2022-06-20 07:28:36 --> Total execution time: 0.0558
DEBUG - 2022-06-20 07:30:04 --> Total execution time: 0.0333
DEBUG - 2022-06-20 07:30:07 --> Total execution time: 0.0426
DEBUG - 2022-06-20 07:30:15 --> Total execution time: 0.1143
DEBUG - 2022-06-20 07:30:15 --> Total execution time: 0.0615
DEBUG - 2022-06-20 07:30:18 --> Total execution time: 0.0476
DEBUG - 2022-06-20 07:30:22 --> Total execution time: 0.0496
DEBUG - 2022-06-20 07:30:25 --> Total execution time: 0.0456
DEBUG - 2022-06-20 07:30:33 --> Total execution time: 0.0402
DEBUG - 2022-06-20 07:31:32 --> Total execution time: 0.0481
DEBUG - 2022-06-20 07:31:35 --> Total execution time: 0.0503
DEBUG - 2022-06-20 07:35:12 --> Total execution time: 0.0835
DEBUG - 2022-06-20 07:48:05 --> Total execution time: 0.0877
DEBUG - 2022-06-20 07:48:05 --> Total execution time: 0.0325
DEBUG - 2022-06-20 07:48:11 --> Total execution time: 0.0487
DEBUG - 2022-06-20 07:48:16 --> Total execution time: 0.0339
DEBUG - 2022-06-20 07:48:28 --> Total execution time: 0.0664
DEBUG - 2022-06-20 07:48:34 --> Total execution time: 0.0500
DEBUG - 2022-06-20 07:49:44 --> Total execution time: 0.0517
DEBUG - 2022-06-20 07:50:46 --> Total execution time: 0.0489
DEBUG - 2022-06-20 07:50:51 --> Total execution time: 0.0502
DEBUG - 2022-06-20 07:50:55 --> Total execution time: 0.0614
DEBUG - 2022-06-20 07:51:23 --> Total execution time: 0.0440
DEBUG - 2022-06-20 07:51:24 --> Total execution time: 0.0639
DEBUG - 2022-06-20 07:51:25 --> Total execution time: 0.0457
DEBUG - 2022-06-20 07:51:25 --> Total execution time: 0.0448
DEBUG - 2022-06-20 07:51:25 --> Total execution time: 0.0404
DEBUG - 2022-06-20 07:51:26 --> Total execution time: 0.0379
DEBUG - 2022-06-20 07:51:26 --> Total execution time: 0.0461
DEBUG - 2022-06-20 07:51:27 --> Total execution time: 0.0356
DEBUG - 2022-06-20 07:52:42 --> Total execution time: 0.0395
DEBUG - 2022-06-20 07:53:04 --> Total execution time: 0.0402
DEBUG - 2022-06-20 07:53:55 --> Total execution time: 0.0417
DEBUG - 2022-06-20 07:53:56 --> Total execution time: 0.0325
DEBUG - 2022-06-20 07:54:36 --> Total execution time: 0.0302
DEBUG - 2022-06-20 07:55:40 --> Total execution time: 0.1193
DEBUG - 2022-06-20 07:55:45 --> Total execution time: 0.0421
DEBUG - 2022-06-20 07:56:35 --> Total execution time: 0.0447
DEBUG - 2022-06-20 07:56:40 --> Total execution time: 0.0388
DEBUG - 2022-06-20 07:57:22 --> Total execution time: 0.0450
DEBUG - 2022-06-20 07:59:33 --> Total execution time: 1.9929
DEBUG - 2022-06-20 08:01:34 --> Total execution time: 0.0389
DEBUG - 2022-06-20 08:01:47 --> Total execution time: 0.0427
DEBUG - 2022-06-20 08:06:03 --> Total execution time: 0.0881
DEBUG - 2022-06-20 08:07:40 --> Total execution time: 0.0479
DEBUG - 2022-06-20 08:10:43 --> Total execution time: 0.0981
DEBUG - 2022-06-20 08:11:34 --> Total execution time: 0.1192
DEBUG - 2022-06-20 08:17:43 --> Total execution time: 0.1583
DEBUG - 2022-06-20 08:26:16 --> Total execution time: 0.1093
DEBUG - 2022-06-20 08:26:27 --> Total execution time: 0.0466
DEBUG - 2022-06-20 08:30:02 --> Total execution time: 0.1324
DEBUG - 2022-06-20 08:30:46 --> Total execution time: 0.0435
DEBUG - 2022-06-20 08:31:16 --> Total execution time: 0.0288
DEBUG - 2022-06-20 08:31:18 --> Total execution time: 0.0612
DEBUG - 2022-06-20 08:31:20 --> Total execution time: 0.0415
DEBUG - 2022-06-20 08:31:22 --> Total execution time: 0.0520
DEBUG - 2022-06-20 08:31:38 --> Total execution time: 0.0386
DEBUG - 2022-06-20 08:31:41 --> Total execution time: 0.0394
DEBUG - 2022-06-20 08:33:21 --> Total execution time: 0.0336
DEBUG - 2022-06-20 08:33:34 --> Total execution time: 0.0403
DEBUG - 2022-06-20 08:33:43 --> Total execution time: 0.0584
DEBUG - 2022-06-20 08:35:26 --> Total execution time: 0.0885
DEBUG - 2022-06-20 08:35:46 --> Total execution time: 0.0340
DEBUG - 2022-06-20 08:35:59 --> Total execution time: 0.0379
DEBUG - 2022-06-20 08:36:21 --> Total execution time: 0.0362
DEBUG - 2022-06-20 08:37:27 --> Total execution time: 0.1477
DEBUG - 2022-06-20 08:47:52 --> Total execution time: 0.1121
DEBUG - 2022-06-20 08:48:08 --> Total execution time: 0.0359
DEBUG - 2022-06-20 08:56:00 --> Total execution time: 0.1137
DEBUG - 2022-06-20 09:03:31 --> Total execution time: 0.0994
DEBUG - 2022-06-20 09:03:41 --> Total execution time: 0.0455
DEBUG - 2022-06-20 09:09:45 --> Total execution time: 0.0450
DEBUG - 2022-06-20 09:09:57 --> Total execution time: 0.0717
DEBUG - 2022-06-20 09:09:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 09:09:58 --> Total execution time: 0.0542
DEBUG - 2022-06-20 09:10:52 --> Total execution time: 0.0403
DEBUG - 2022-06-20 09:11:00 --> Total execution time: 0.0431
DEBUG - 2022-06-20 09:11:20 --> Total execution time: 0.0529
DEBUG - 2022-06-20 09:11:27 --> Total execution time: 0.0954
DEBUG - 2022-06-20 09:11:35 --> Total execution time: 0.0882
DEBUG - 2022-06-20 09:11:38 --> Total execution time: 0.0656
DEBUG - 2022-06-20 09:11:43 --> Total execution time: 0.0401
DEBUG - 2022-06-20 09:11:47 --> Total execution time: 0.0481
DEBUG - 2022-06-20 09:11:52 --> Total execution time: 0.0679
DEBUG - 2022-06-20 09:11:53 --> Total execution time: 0.0420
DEBUG - 2022-06-20 09:11:56 --> Total execution time: 0.0462
DEBUG - 2022-06-20 09:12:00 --> Total execution time: 0.0520
DEBUG - 2022-06-20 09:12:08 --> Total execution time: 0.0446
DEBUG - 2022-06-20 09:12:13 --> Total execution time: 0.0457
DEBUG - 2022-06-20 09:12:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 09:12:14 --> Total execution time: 0.0482
DEBUG - 2022-06-20 09:13:05 --> Total execution time: 0.0511
DEBUG - 2022-06-20 09:13:08 --> Total execution time: 0.0428
DEBUG - 2022-06-20 09:13:36 --> Total execution time: 0.0440
DEBUG - 2022-06-20 09:14:31 --> Total execution time: 0.0405
DEBUG - 2022-06-20 09:14:43 --> Total execution time: 0.0413
DEBUG - 2022-06-20 09:14:46 --> Total execution time: 0.0369
DEBUG - 2022-06-20 09:15:16 --> Total execution time: 0.0403
DEBUG - 2022-06-20 09:15:24 --> Total execution time: 0.0342
DEBUG - 2022-06-20 09:17:50 --> Total execution time: 0.0606
DEBUG - 2022-06-20 09:17:58 --> Total execution time: 0.0610
DEBUG - 2022-06-20 09:18:01 --> Total execution time: 0.0501
DEBUG - 2022-06-20 09:18:38 --> Total execution time: 0.0454
DEBUG - 2022-06-20 09:21:36 --> Total execution time: 0.0920
DEBUG - 2022-06-20 09:21:38 --> Total execution time: 0.0412
DEBUG - 2022-06-20 09:21:39 --> Total execution time: 0.0391
DEBUG - 2022-06-20 09:21:46 --> Total execution time: 0.0511
DEBUG - 2022-06-20 09:26:25 --> Total execution time: 0.1425
DEBUG - 2022-06-20 09:28:33 --> Total execution time: 0.0873
DEBUG - 2022-06-20 09:29:48 --> Total execution time: 0.0317
DEBUG - 2022-06-20 09:30:02 --> Total execution time: 0.0664
DEBUG - 2022-06-20 09:31:23 --> Total execution time: 0.0617
DEBUG - 2022-06-20 09:31:50 --> Total execution time: 0.0422
DEBUG - 2022-06-20 09:32:09 --> Total execution time: 0.0375
DEBUG - 2022-06-20 09:32:19 --> Total execution time: 0.0750
DEBUG - 2022-06-20 09:32:27 --> Total execution time: 0.0733
DEBUG - 2022-06-20 09:32:45 --> Total execution time: 0.0557
DEBUG - 2022-06-20 09:32:51 --> Total execution time: 0.0694
DEBUG - 2022-06-20 09:33:01 --> Total execution time: 0.1055
DEBUG - 2022-06-20 09:33:42 --> Total execution time: 0.0950
DEBUG - 2022-06-20 09:33:44 --> Total execution time: 0.0682
DEBUG - 2022-06-20 09:33:54 --> Total execution time: 0.0485
DEBUG - 2022-06-20 09:33:58 --> Total execution time: 0.0452
DEBUG - 2022-06-20 09:34:03 --> Total execution time: 0.0547
DEBUG - 2022-06-20 09:34:37 --> Total execution time: 0.0453
DEBUG - 2022-06-20 09:34:54 --> Total execution time: 0.0309
DEBUG - 2022-06-20 09:34:59 --> Total execution time: 0.0314
DEBUG - 2022-06-20 09:35:13 --> Total execution time: 0.0673
DEBUG - 2022-06-20 09:35:23 --> Total execution time: 0.0480
DEBUG - 2022-06-20 09:35:27 --> Total execution time: 0.0444
DEBUG - 2022-06-20 09:37:17 --> Total execution time: 0.0504
DEBUG - 2022-06-20 09:37:18 --> Total execution time: 0.0422
DEBUG - 2022-06-20 09:38:49 --> Total execution time: 0.0355
DEBUG - 2022-06-20 09:38:50 --> Total execution time: 0.0279
DEBUG - 2022-06-20 09:38:54 --> Total execution time: 0.0275
DEBUG - 2022-06-20 09:39:00 --> Total execution time: 0.0382
DEBUG - 2022-06-20 09:39:16 --> Total execution time: 0.0949
DEBUG - 2022-06-20 09:39:23 --> Total execution time: 0.0535
DEBUG - 2022-06-20 09:40:26 --> Total execution time: 0.0675
DEBUG - 2022-06-20 09:40:55 --> Total execution time: 0.0443
DEBUG - 2022-06-20 09:42:12 --> Total execution time: 0.0375
DEBUG - 2022-06-20 09:44:05 --> Total execution time: 0.0441
DEBUG - 2022-06-20 09:44:07 --> Total execution time: 0.0450
DEBUG - 2022-06-20 09:44:40 --> Total execution time: 0.0406
DEBUG - 2022-06-20 09:45:51 --> Total execution time: 0.0440
DEBUG - 2022-06-20 09:45:59 --> Total execution time: 0.0426
DEBUG - 2022-06-20 09:47:02 --> Total execution time: 0.1030
DEBUG - 2022-06-20 09:47:05 --> Total execution time: 0.0453
DEBUG - 2022-06-20 09:47:09 --> Total execution time: 0.0572
DEBUG - 2022-06-20 09:47:18 --> Total execution time: 0.0418
DEBUG - 2022-06-20 09:47:27 --> Total execution time: 0.0397
DEBUG - 2022-06-20 09:50:08 --> Total execution time: 0.1176
DEBUG - 2022-06-20 09:50:11 --> Total execution time: 0.0342
DEBUG - 2022-06-20 09:50:16 --> Total execution time: 0.0442
DEBUG - 2022-06-20 09:50:23 --> Total execution time: 0.1054
DEBUG - 2022-06-20 09:50:48 --> Total execution time: 0.0515
DEBUG - 2022-06-20 09:53:03 --> Total execution time: 0.1553
DEBUG - 2022-06-20 09:53:36 --> Total execution time: 0.0752
DEBUG - 2022-06-20 09:53:40 --> Total execution time: 0.0494
DEBUG - 2022-06-20 09:53:44 --> Total execution time: 0.0410
DEBUG - 2022-06-20 09:54:08 --> Total execution time: 0.0437
DEBUG - 2022-06-20 09:54:19 --> Total execution time: 0.0517
DEBUG - 2022-06-20 09:54:22 --> Total execution time: 0.0436
DEBUG - 2022-06-20 09:54:30 --> Total execution time: 0.0921
DEBUG - 2022-06-20 09:56:25 --> Total execution time: 0.1213
DEBUG - 2022-06-20 09:56:33 --> Total execution time: 0.0604
DEBUG - 2022-06-20 09:56:50 --> Total execution time: 0.0504
DEBUG - 2022-06-20 09:57:22 --> Total execution time: 0.0559
DEBUG - 2022-06-20 09:59:55 --> Total execution time: 0.0810
DEBUG - 2022-06-20 10:00:00 --> Total execution time: 0.0402
DEBUG - 2022-06-20 10:00:35 --> Total execution time: 0.0332
DEBUG - 2022-06-20 10:00:36 --> Total execution time: 0.0350
DEBUG - 2022-06-20 10:00:41 --> Total execution time: 0.0321
DEBUG - 2022-06-20 10:00:52 --> Total execution time: 0.0398
DEBUG - 2022-06-20 10:01:09 --> Total execution time: 0.0403
DEBUG - 2022-06-20 10:01:23 --> Total execution time: 0.0428
DEBUG - 2022-06-20 10:01:29 --> Total execution time: 0.0394
DEBUG - 2022-06-20 10:01:48 --> Total execution time: 0.0683
DEBUG - 2022-06-20 10:02:04 --> Total execution time: 0.0543
DEBUG - 2022-06-20 10:02:09 --> Total execution time: 0.0506
DEBUG - 2022-06-20 10:02:10 --> Total execution time: 0.0463
DEBUG - 2022-06-20 10:02:14 --> Total execution time: 0.0423
DEBUG - 2022-06-20 10:02:14 --> Total execution time: 0.0632
DEBUG - 2022-06-20 10:02:18 --> Total execution time: 0.0795
DEBUG - 2022-06-20 10:02:30 --> Total execution time: 0.0746
DEBUG - 2022-06-20 10:03:13 --> Total execution time: 0.0537
DEBUG - 2022-06-20 10:03:34 --> Total execution time: 0.0400
DEBUG - 2022-06-20 10:03:52 --> Total execution time: 0.0529
DEBUG - 2022-06-20 10:04:00 --> Total execution time: 0.0540
DEBUG - 2022-06-20 10:04:18 --> Total execution time: 0.0453
DEBUG - 2022-06-20 10:04:27 --> Total execution time: 0.0476
DEBUG - 2022-06-20 10:05:46 --> Total execution time: 0.0416
DEBUG - 2022-06-20 10:06:48 --> Total execution time: 0.0626
DEBUG - 2022-06-20 10:08:30 --> Total execution time: 0.0624
DEBUG - 2022-06-20 10:10:54 --> Total execution time: 0.1841
DEBUG - 2022-06-20 10:11:02 --> Total execution time: 0.0484
DEBUG - 2022-06-20 10:11:07 --> Total execution time: 0.0559
DEBUG - 2022-06-20 10:11:10 --> Total execution time: 0.0744
DEBUG - 2022-06-20 10:11:21 --> Total execution time: 0.0666
DEBUG - 2022-06-20 10:12:44 --> Total execution time: 0.0539
DEBUG - 2022-06-20 10:13:49 --> Total execution time: 0.0372
DEBUG - 2022-06-20 10:13:56 --> Total execution time: 0.0500
DEBUG - 2022-06-20 10:14:07 --> Total execution time: 0.1003
DEBUG - 2022-06-20 10:14:24 --> Total execution time: 0.0398
DEBUG - 2022-06-20 10:14:31 --> Total execution time: 0.0360
DEBUG - 2022-06-20 10:14:34 --> Total execution time: 0.0728
DEBUG - 2022-06-20 10:15:17 --> Total execution time: 0.0402
DEBUG - 2022-06-20 10:16:38 --> Total execution time: 1.9040
DEBUG - 2022-06-20 10:18:32 --> Total execution time: 0.3539
DEBUG - 2022-06-20 10:18:35 --> Total execution time: 0.0799
DEBUG - 2022-06-20 10:19:31 --> Total execution time: 0.0434
DEBUG - 2022-06-20 10:19:39 --> Total execution time: 0.0595
DEBUG - 2022-06-20 10:19:44 --> Total execution time: 0.0320
DEBUG - 2022-06-20 10:20:21 --> Total execution time: 0.0605
DEBUG - 2022-06-20 10:20:26 --> Total execution time: 0.0611
DEBUG - 2022-06-20 10:20:27 --> Total execution time: 0.2185
DEBUG - 2022-06-20 10:20:32 --> Total execution time: 0.0637
DEBUG - 2022-06-20 10:20:45 --> Total execution time: 0.0471
DEBUG - 2022-06-20 10:20:50 --> Total execution time: 0.0669
DEBUG - 2022-06-20 10:21:04 --> Total execution time: 0.0462
DEBUG - 2022-06-20 10:21:07 --> Total execution time: 0.0566
DEBUG - 2022-06-20 10:21:08 --> Total execution time: 0.0565
DEBUG - 2022-06-20 10:21:14 --> Total execution time: 0.0315
DEBUG - 2022-06-20 10:21:14 --> Total execution time: 0.0634
DEBUG - 2022-06-20 10:21:19 --> Total execution time: 0.0649
DEBUG - 2022-06-20 10:22:09 --> Total execution time: 0.0482
DEBUG - 2022-06-20 10:22:23 --> Total execution time: 0.0302
DEBUG - 2022-06-20 10:22:38 --> Total execution time: 0.0707
DEBUG - 2022-06-20 10:22:55 --> Total execution time: 0.0812
DEBUG - 2022-06-20 10:22:55 --> Total execution time: 0.1290
DEBUG - 2022-06-20 10:23:13 --> Total execution time: 1.7123
DEBUG - 2022-06-20 10:25:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:25:09 --> Total execution time: 0.0469
DEBUG - 2022-06-20 10:25:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:25:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:25:10 --> Total execution time: 0.2158
DEBUG - 2022-06-20 10:25:52 --> Total execution time: 0.0543
DEBUG - 2022-06-20 10:25:56 --> Total execution time: 0.0472
DEBUG - 2022-06-20 10:26:07 --> Total execution time: 0.0421
DEBUG - 2022-06-20 10:26:14 --> Total execution time: 0.0467
DEBUG - 2022-06-20 10:26:18 --> Total execution time: 0.0735
DEBUG - 2022-06-20 10:26:29 --> Total execution time: 0.0959
DEBUG - 2022-06-20 10:26:32 --> Total execution time: 0.0435
DEBUG - 2022-06-20 10:26:32 --> Total execution time: 0.0979
DEBUG - 2022-06-20 10:27:00 --> Total execution time: 0.0449
DEBUG - 2022-06-20 10:27:09 --> Total execution time: 0.1223
DEBUG - 2022-06-20 10:27:31 --> Total execution time: 0.0535
DEBUG - 2022-06-20 10:28:20 --> Total execution time: 0.0991
DEBUG - 2022-06-20 10:28:24 --> Total execution time: 0.0891
DEBUG - 2022-06-20 10:28:38 --> Total execution time: 0.0444
DEBUG - 2022-06-20 10:28:40 --> Total execution time: 0.0333
DEBUG - 2022-06-20 10:28:58 --> Total execution time: 0.0643
DEBUG - 2022-06-20 10:29:06 --> Total execution time: 0.0696
DEBUG - 2022-06-20 10:29:24 --> Total execution time: 0.0440
DEBUG - 2022-06-20 10:29:27 --> Total execution time: 0.0412
DEBUG - 2022-06-20 10:29:30 --> Total execution time: 0.0397
DEBUG - 2022-06-20 00:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:30:00 --> Total execution time: 0.0484
DEBUG - 2022-06-20 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:30:02 --> Total execution time: 0.0462
DEBUG - 2022-06-20 00:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:30:15 --> Total execution time: 0.0844
DEBUG - 2022-06-20 00:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:30:17 --> Total execution time: 0.1158
DEBUG - 2022-06-20 00:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:30:41 --> Total execution time: 0.0904
DEBUG - 2022-06-20 00:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:31:03 --> Total execution time: 0.0611
DEBUG - 2022-06-20 00:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:31:05 --> Total execution time: 0.0692
DEBUG - 2022-06-20 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:31:51 --> Total execution time: 0.0586
DEBUG - 2022-06-20 00:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:32:53 --> Total execution time: 0.0444
DEBUG - 2022-06-20 00:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:32:55 --> Total execution time: 0.0423
DEBUG - 2022-06-20 00:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:32:57 --> Total execution time: 0.0573
DEBUG - 2022-06-20 00:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:03:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:33:31 --> Total execution time: 0.0406
DEBUG - 2022-06-20 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:33:39 --> Total execution time: 0.0454
DEBUG - 2022-06-20 00:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:34:11 --> Total execution time: 0.0466
DEBUG - 2022-06-20 00:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:04:41 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:34:41 --> Total execution time: 0.0309
DEBUG - 2022-06-20 00:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:34:46 --> Total execution time: 0.0578
DEBUG - 2022-06-20 00:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:34:47 --> Total execution time: 0.0338
DEBUG - 2022-06-20 00:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:15 --> Total execution time: 0.0483
DEBUG - 2022-06-20 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:20 --> Total execution time: 0.0385
DEBUG - 2022-06-20 00:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:25 --> Total execution time: 0.0391
DEBUG - 2022-06-20 00:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:27 --> Total execution time: 0.0692
DEBUG - 2022-06-20 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:28 --> Total execution time: 0.0520
DEBUG - 2022-06-20 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:28 --> Total execution time: 0.0541
DEBUG - 2022-06-20 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:28 --> Total execution time: 0.0566
DEBUG - 2022-06-20 00:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:41 --> Total execution time: 0.0440
DEBUG - 2022-06-20 00:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:49 --> Total execution time: 0.1304
DEBUG - 2022-06-20 00:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:56 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:56 --> Total execution time: 0.0300
DEBUG - 2022-06-20 00:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:56 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:56 --> Total execution time: 0.0251
DEBUG - 2022-06-20 00:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:58 --> Total execution time: 0.0958
DEBUG - 2022-06-20 00:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:01 --> Total execution time: 0.0482
DEBUG - 2022-06-20 00:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:08 --> Total execution time: 0.0671
DEBUG - 2022-06-20 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:13 --> Total execution time: 0.0724
DEBUG - 2022-06-20 10:36:13 --> Total execution time: 0.0854
DEBUG - 2022-06-20 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:14 --> Total execution time: 0.0425
DEBUG - 2022-06-20 00:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:17 --> Total execution time: 0.0655
DEBUG - 2022-06-20 00:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:39 --> Total execution time: 0.0966
DEBUG - 2022-06-20 00:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:40 --> Total execution time: 0.1867
DEBUG - 2022-06-20 00:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:48 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:48 --> Total execution time: 0.0413
DEBUG - 2022-06-20 00:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:50 --> Total execution time: 0.0733
DEBUG - 2022-06-20 00:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:55 --> Total execution time: 0.1119
DEBUG - 2022-06-20 00:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:57 --> Total execution time: 0.0524
DEBUG - 2022-06-20 00:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:37:15 --> Total execution time: 0.0530
DEBUG - 2022-06-20 00:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:37:20 --> Total execution time: 0.0638
DEBUG - 2022-06-20 00:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:37:21 --> Total execution time: 0.0387
DEBUG - 2022-06-20 00:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:37:32 --> Total execution time: 0.0744
DEBUG - 2022-06-20 00:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:37:34 --> Total execution time: 0.0721
DEBUG - 2022-06-20 00:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:07:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:37:52 --> Total execution time: 0.0427
DEBUG - 2022-06-20 00:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:02 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:02 --> Total execution time: 0.0310
DEBUG - 2022-06-20 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:17 --> Total execution time: 0.0951
DEBUG - 2022-06-20 10:38:17 --> Total execution time: 0.1090
DEBUG - 2022-06-20 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:17 --> Total execution time: 0.0348
DEBUG - 2022-06-20 00:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:08:23 --> Total execution time: 0.0431
DEBUG - 2022-06-20 00:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:08:24 --> Total execution time: 0.0434
DEBUG - 2022-06-20 00:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:08:24 --> Total execution time: 0.0939
DEBUG - 2022-06-20 00:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:27 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:27 --> Total execution time: 0.0509
DEBUG - 2022-06-20 00:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:37 --> Total execution time: 0.0441
DEBUG - 2022-06-20 00:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:43 --> Total execution time: 0.0596
DEBUG - 2022-06-20 00:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:45 --> Total execution time: 0.0557
DEBUG - 2022-06-20 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:46 --> Total execution time: 0.0567
DEBUG - 2022-06-20 00:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:50 --> Total execution time: 0.0471
DEBUG - 2022-06-20 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:51 --> Total execution time: 0.0478
DEBUG - 2022-06-20 00:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:58 --> Total execution time: 1.9356
DEBUG - 2022-06-20 00:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 00:09:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 00:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:14 --> Total execution time: 0.0564
DEBUG - 2022-06-20 00:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 00:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:28 --> Total execution time: 0.0610
DEBUG - 2022-06-20 00:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:39:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:39:29 --> Total execution time: 0.1866
DEBUG - 2022-06-20 00:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:33 --> Total execution time: 0.0423
DEBUG - 2022-06-20 00:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:38 --> Total execution time: 0.0660
DEBUG - 2022-06-20 00:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:44 --> Total execution time: 0.1910
DEBUG - 2022-06-20 00:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:50 --> Total execution time: 0.1291
DEBUG - 2022-06-20 00:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:53 --> Total execution time: 0.0664
DEBUG - 2022-06-20 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:02 --> Total execution time: 0.0519
DEBUG - 2022-06-20 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:04 --> Total execution time: 0.0565
DEBUG - 2022-06-20 00:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:06 --> Total execution time: 0.0333
DEBUG - 2022-06-20 00:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:26 --> Total execution time: 0.0368
DEBUG - 2022-06-20 00:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:38 --> Total execution time: 0.0386
DEBUG - 2022-06-20 00:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:48 --> Total execution time: 0.1043
DEBUG - 2022-06-20 00:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:55 --> Total execution time: 0.0531
DEBUG - 2022-06-20 00:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:10:57 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:57 --> Total execution time: 0.1049
DEBUG - 2022-06-20 00:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:01 --> Total execution time: 0.0366
DEBUG - 2022-06-20 00:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:08 --> Total execution time: 0.0504
DEBUG - 2022-06-20 00:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:09 --> Total execution time: 0.0393
DEBUG - 2022-06-20 00:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:10 --> Total execution time: 0.0458
DEBUG - 2022-06-20 00:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:11 --> Total execution time: 0.0585
DEBUG - 2022-06-20 00:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:11 --> Total execution time: 0.1002
DEBUG - 2022-06-20 00:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:29 --> Total execution time: 0.0478
DEBUG - 2022-06-20 00:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:36 --> Total execution time: 0.0637
DEBUG - 2022-06-20 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:46 --> Total execution time: 0.0642
DEBUG - 2022-06-20 00:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:49 --> Total execution time: 0.0681
DEBUG - 2022-06-20 00:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:42:00 --> Total execution time: 0.0668
DEBUG - 2022-06-20 00:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:42:04 --> Total execution time: 0.0451
DEBUG - 2022-06-20 00:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:42:09 --> Total execution time: 0.0601
DEBUG - 2022-06-20 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:42:18 --> Total execution time: 0.0549
DEBUG - 2022-06-20 00:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:18 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:42:18 --> Total execution time: 0.0496
DEBUG - 2022-06-20 00:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:42:25 --> Total execution time: 0.0454
DEBUG - 2022-06-20 00:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:42:31 --> Total execution time: 0.0547
DEBUG - 2022-06-20 00:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:12:46 --> Total execution time: 0.0288
DEBUG - 2022-06-20 00:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:12:47 --> Total execution time: 0.0557
DEBUG - 2022-06-20 00:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:12:47 --> Total execution time: 0.0839
DEBUG - 2022-06-20 00:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:12:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:42:50 --> Total execution time: 0.0495
DEBUG - 2022-06-20 00:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:43:21 --> Total execution time: 0.0577
DEBUG - 2022-06-20 00:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:44:17 --> Total execution time: 0.1542
DEBUG - 2022-06-20 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:44:19 --> Total execution time: 0.0412
DEBUG - 2022-06-20 00:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:44:33 --> Total execution time: 0.0504
DEBUG - 2022-06-20 00:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:44:40 --> Total execution time: 0.2600
DEBUG - 2022-06-20 00:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 00:18:31 --> 404 Page Not Found: Previewphp/index
DEBUG - 2022-06-20 00:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:21:33 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:51:33 --> Total execution time: 0.1981
DEBUG - 2022-06-20 00:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:22:06 --> Total execution time: 0.0737
DEBUG - 2022-06-20 00:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:22:10 --> Total execution time: 0.0774
DEBUG - 2022-06-20 00:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:22:10 --> Total execution time: 0.1214
DEBUG - 2022-06-20 00:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:53:14 --> Total execution time: 0.0494
DEBUG - 2022-06-20 00:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:53:27 --> Total execution time: 0.0676
DEBUG - 2022-06-20 00:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:53:36 --> Total execution time: 0.0793
DEBUG - 2022-06-20 00:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:55:16 --> Total execution time: 0.0502
DEBUG - 2022-06-20 00:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:55:19 --> Total execution time: 0.0570
DEBUG - 2022-06-20 00:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:55:23 --> Total execution time: 0.0510
DEBUG - 2022-06-20 00:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:55:32 --> Total execution time: 0.0635
DEBUG - 2022-06-20 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:56:47 --> Total execution time: 0.0615
DEBUG - 2022-06-20 00:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:56:54 --> Total execution time: 0.0655
DEBUG - 2022-06-20 00:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:57:02 --> Total execution time: 0.0548
DEBUG - 2022-06-20 00:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:57:11 --> Total execution time: 0.0463
DEBUG - 2022-06-20 00:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:57:18 --> Total execution time: 0.0813
DEBUG - 2022-06-20 00:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:28:59 --> Total execution time: 0.1242
DEBUG - 2022-06-20 00:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:29:01 --> Total execution time: 0.3661
DEBUG - 2022-06-20 00:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:29:01 --> Total execution time: 0.2550
DEBUG - 2022-06-20 00:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:33:32 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:03:33 --> Total execution time: 0.1850
DEBUG - 2022-06-20 00:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:03:59 --> Total execution time: 0.0377
DEBUG - 2022-06-20 00:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:34:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:04:00 --> Total execution time: 0.0399
DEBUG - 2022-06-20 00:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:04:10 --> Total execution time: 0.0502
DEBUG - 2022-06-20 00:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:04:43 --> Total execution time: 0.0476
DEBUG - 2022-06-20 00:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:05:02 --> Total execution time: 0.0469
DEBUG - 2022-06-20 00:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:05:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 00:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:05:03 --> Total execution time: 0.0380
DEBUG - 2022-06-20 00:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:07:40 --> Total execution time: 0.0904
DEBUG - 2022-06-20 00:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:07:43 --> Total execution time: 0.0396
DEBUG - 2022-06-20 00:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:07:46 --> Total execution time: 0.0493
DEBUG - 2022-06-20 00:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:07:47 --> Total execution time: 0.0444
DEBUG - 2022-06-20 00:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:07:47 --> Total execution time: 0.0512
DEBUG - 2022-06-20 00:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:49 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:07:49 --> Total execution time: 0.0454
DEBUG - 2022-06-20 00:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:07:49 --> Total execution time: 0.0436
DEBUG - 2022-06-20 00:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:07:58 --> Total execution time: 0.0728
DEBUG - 2022-06-20 00:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:00 --> Total execution time: 0.0682
DEBUG - 2022-06-20 00:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:06 --> Total execution time: 0.0545
DEBUG - 2022-06-20 00:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:07 --> Total execution time: 0.1443
DEBUG - 2022-06-20 00:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:17 --> Total execution time: 0.0503
DEBUG - 2022-06-20 00:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:20 --> Total execution time: 0.0578
DEBUG - 2022-06-20 00:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:22 --> Total execution time: 0.0609
DEBUG - 2022-06-20 00:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:22 --> Total execution time: 0.1219
DEBUG - 2022-06-20 00:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:27 --> Total execution time: 0.0728
DEBUG - 2022-06-20 00:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:30 --> Total execution time: 0.0537
DEBUG - 2022-06-20 00:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:32 --> Total execution time: 0.0540
DEBUG - 2022-06-20 00:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:37 --> Total execution time: 0.0581
DEBUG - 2022-06-20 00:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:38:47 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:08:47 --> Total execution time: 0.0594
DEBUG - 2022-06-20 00:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:09:01 --> Total execution time: 0.0978
DEBUG - 2022-06-20 00:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:09:17 --> Total execution time: 0.4530
DEBUG - 2022-06-20 00:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:09:26 --> Total execution time: 0.1400
DEBUG - 2022-06-20 00:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:09:37 --> Total execution time: 0.0532
DEBUG - 2022-06-20 00:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:09:47 --> Total execution time: 0.0441
DEBUG - 2022-06-20 00:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:09:48 --> Total execution time: 0.0937
DEBUG - 2022-06-20 00:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:09:52 --> Total execution time: 0.0683
DEBUG - 2022-06-20 00:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:01 --> Total execution time: 0.0430
DEBUG - 2022-06-20 00:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:10 --> Total execution time: 0.0876
DEBUG - 2022-06-20 00:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:40:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:16 --> Total execution time: 0.0516
DEBUG - 2022-06-20 00:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:19 --> Total execution time: 0.0424
DEBUG - 2022-06-20 00:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:39 --> Total execution time: 0.0747
DEBUG - 2022-06-20 00:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:44 --> Total execution time: 0.0615
DEBUG - 2022-06-20 00:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:53 --> Total execution time: 0.0651
DEBUG - 2022-06-20 00:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:11:24 --> Total execution time: 0.0404
DEBUG - 2022-06-20 00:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:11:26 --> Total execution time: 0.0763
DEBUG - 2022-06-20 00:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:11:50 --> Total execution time: 0.0455
DEBUG - 2022-06-20 00:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:41:51 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:11:51 --> Total execution time: 0.0632
DEBUG - 2022-06-20 00:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:11:56 --> Total execution time: 0.1031
DEBUG - 2022-06-20 00:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:12:32 --> Total execution time: 0.1239
DEBUG - 2022-06-20 00:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:12:39 --> Total execution time: 0.0621
DEBUG - 2022-06-20 00:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:12:42 --> Total execution time: 0.0620
DEBUG - 2022-06-20 00:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 00:42:45 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-20 00:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:43:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 00:43:25 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 00:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:32 --> Total execution time: 0.0630
DEBUG - 2022-06-20 00:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:39 --> Total execution time: 0.0667
DEBUG - 2022-06-20 00:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:45:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 00:45:48 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 00:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 00:47:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 00:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:48:44 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:18:44 --> Total execution time: 0.0846
DEBUG - 2022-06-20 00:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:18:57 --> Total execution time: 0.0506
DEBUG - 2022-06-20 00:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:10 --> Total execution time: 0.1348
DEBUG - 2022-06-20 00:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:17 --> Total execution time: 0.0400
DEBUG - 2022-06-20 00:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:35 --> Total execution time: 0.0992
DEBUG - 2022-06-20 00:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:48 --> Total execution time: 0.0506
DEBUG - 2022-06-20 00:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:56 --> Total execution time: 0.0815
DEBUG - 2022-06-20 00:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:59 --> Total execution time: 0.0559
DEBUG - 2022-06-20 00:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:20:04 --> Total execution time: 0.0638
DEBUG - 2022-06-20 00:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:52:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 00:52:19 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-20 00:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:53:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:23:16 --> Total execution time: 0.1847
DEBUG - 2022-06-20 11:23:16 --> Total execution time: 0.1726
DEBUG - 2022-06-20 00:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:23:48 --> Total execution time: 0.0420
DEBUG - 2022-06-20 00:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:55:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:25:46 --> Total execution time: 0.0511
DEBUG - 2022-06-20 00:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:27:29 --> Total execution time: 0.0375
DEBUG - 2022-06-20 00:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 00:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:28:02 --> Total execution time: 0.0736
DEBUG - 2022-06-20 00:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:58:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 00:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:28:17 --> Total execution time: 0.0327
DEBUG - 2022-06-20 00:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:28:28 --> Total execution time: 0.1011
DEBUG - 2022-06-20 00:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:28:36 --> Total execution time: 0.1169
DEBUG - 2022-06-20 00:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:28:44 --> Total execution time: 0.0641
DEBUG - 2022-06-20 00:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 00:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 00:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:28:48 --> Total execution time: 0.0502
DEBUG - 2022-06-20 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:30:02 --> Total execution time: 0.1124
DEBUG - 2022-06-20 01:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:00:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:30:20 --> Total execution time: 0.0709
DEBUG - 2022-06-20 01:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:00:58 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:30:58 --> Total execution time: 0.0431
DEBUG - 2022-06-20 01:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:31:04 --> Total execution time: 0.0598
DEBUG - 2022-06-20 01:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:31:06 --> Total execution time: 0.0478
DEBUG - 2022-06-20 01:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:31:13 --> Total execution time: 0.0460
DEBUG - 2022-06-20 01:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:01:15 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:31:15 --> Total execution time: 0.0911
DEBUG - 2022-06-20 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:01:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:31:16 --> Total execution time: 0.0305
DEBUG - 2022-06-20 01:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:01:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 01:01:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 01:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:31:25 --> Total execution time: 0.0587
DEBUG - 2022-06-20 01:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:32:11 --> Total execution time: 0.0546
DEBUG - 2022-06-20 01:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:02:32 --> Total execution time: 0.0533
DEBUG - 2022-06-20 01:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:32:47 --> Total execution time: 0.0723
DEBUG - 2022-06-20 01:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:33:27 --> Total execution time: 0.0585
DEBUG - 2022-06-20 01:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:33:34 --> Total execution time: 0.1179
DEBUG - 2022-06-20 01:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:33:39 --> Total execution time: 0.1248
DEBUG - 2022-06-20 01:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:33:44 --> Total execution time: 0.0624
DEBUG - 2022-06-20 01:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:33:47 --> Total execution time: 0.0483
DEBUG - 2022-06-20 01:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:33:52 --> Total execution time: 0.0817
DEBUG - 2022-06-20 01:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:34:13 --> Total execution time: 0.0491
DEBUG - 2022-06-20 01:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:06:32 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:36:33 --> Total execution time: 0.2251
DEBUG - 2022-06-20 01:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:38:37 --> Total execution time: 0.0581
DEBUG - 2022-06-20 01:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 01:10:08 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 01:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:40:45 --> Total execution time: 0.0429
DEBUG - 2022-06-20 01:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:12:12 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:42:12 --> Total execution time: 0.0369
DEBUG - 2022-06-20 01:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:42:31 --> Total execution time: 0.0583
DEBUG - 2022-06-20 01:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:13:05 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:43:05 --> Total execution time: 0.0463
DEBUG - 2022-06-20 01:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:43:35 --> Total execution time: 0.1036
DEBUG - 2022-06-20 01:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:43:36 --> Total execution time: 0.1016
DEBUG - 2022-06-20 01:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:43:43 --> Total execution time: 0.1297
DEBUG - 2022-06-20 01:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:44:01 --> Total execution time: 0.0584
DEBUG - 2022-06-20 01:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:44:29 --> Total execution time: 0.0492
DEBUG - 2022-06-20 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:45:00 --> Total execution time: 0.0889
DEBUG - 2022-06-20 01:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:45:05 --> Total execution time: 0.0974
DEBUG - 2022-06-20 01:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:45:24 --> Total execution time: 0.0683
DEBUG - 2022-06-20 01:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:46:09 --> Total execution time: 0.0468
DEBUG - 2022-06-20 01:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:46:17 --> Total execution time: 0.0437
DEBUG - 2022-06-20 01:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:50:27 --> Total execution time: 0.0595
DEBUG - 2022-06-20 01:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:51:10 --> Total execution time: 0.0497
DEBUG - 2022-06-20 01:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:22:33 --> Total execution time: 0.0645
DEBUG - 2022-06-20 01:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:22:47 --> Total execution time: 0.0901
DEBUG - 2022-06-20 01:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:23:33 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:53:33 --> Total execution time: 0.0470
DEBUG - 2022-06-20 01:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:23:40 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:53:41 --> Total execution time: 0.0554
DEBUG - 2022-06-20 01:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:24:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:54:09 --> Total execution time: 0.0920
DEBUG - 2022-06-20 01:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:55:06 --> Total execution time: 0.0726
DEBUG - 2022-06-20 01:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:55:20 --> Total execution time: 0.0845
DEBUG - 2022-06-20 01:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:56:56 --> Total execution time: 0.0649
DEBUG - 2022-06-20 01:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:58:37 --> Total execution time: 0.0721
DEBUG - 2022-06-20 01:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:28:41 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:58:42 --> Total execution time: 0.0362
DEBUG - 2022-06-20 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:58:54 --> Total execution time: 0.0783
DEBUG - 2022-06-20 01:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:29:01 --> Total execution time: 0.0497
DEBUG - 2022-06-20 01:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:29:02 --> Total execution time: 0.0611
DEBUG - 2022-06-20 01:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:29:02 --> Total execution time: 0.1023
DEBUG - 2022-06-20 01:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:08 --> Total execution time: 0.0436
DEBUG - 2022-06-20 01:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:15 --> Total execution time: 0.0634
DEBUG - 2022-06-20 01:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:19 --> Total execution time: 0.0496
DEBUG - 2022-06-20 01:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:29 --> Total execution time: 0.0564
DEBUG - 2022-06-20 01:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:36 --> Total execution time: 0.0771
DEBUG - 2022-06-20 01:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:43 --> Total execution time: 0.0470
DEBUG - 2022-06-20 01:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:49 --> Total execution time: 0.0489
DEBUG - 2022-06-20 01:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:53 --> Total execution time: 0.0653
DEBUG - 2022-06-20 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:55 --> Total execution time: 0.0873
DEBUG - 2022-06-20 01:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:59:58 --> Total execution time: 0.0746
DEBUG - 2022-06-20 01:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:00:02 --> Total execution time: 0.0696
DEBUG - 2022-06-20 01:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:00:05 --> Total execution time: 0.0591
DEBUG - 2022-06-20 01:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:00:14 --> Total execution time: 0.0525
DEBUG - 2022-06-20 01:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:00:30 --> Total execution time: 0.0832
DEBUG - 2022-06-20 01:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:01:14 --> Total execution time: 0.0541
DEBUG - 2022-06-20 01:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:01:30 --> Total execution time: 0.0484
DEBUG - 2022-06-20 01:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:01:53 --> Total execution time: 0.0585
DEBUG - 2022-06-20 01:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:02:17 --> Total execution time: 0.1358
DEBUG - 2022-06-20 01:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:02:25 --> Total execution time: 0.1518
DEBUG - 2022-06-20 01:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:32:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:02:26 --> Total execution time: 0.0476
DEBUG - 2022-06-20 01:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:33:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:03:16 --> Total execution time: 0.0372
DEBUG - 2022-06-20 01:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:03:18 --> Total execution time: 0.0442
DEBUG - 2022-06-20 01:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:03:19 --> Total execution time: 0.0446
DEBUG - 2022-06-20 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:21 --> Total execution time: 0.0483
DEBUG - 2022-06-20 01:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:28 --> Total execution time: 0.0480
DEBUG - 2022-06-20 01:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:34 --> Total execution time: 0.0437
DEBUG - 2022-06-20 01:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:36 --> Total execution time: 0.0707
DEBUG - 2022-06-20 01:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:39 --> Total execution time: 0.0523
DEBUG - 2022-06-20 01:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:41 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:41 --> Total execution time: 0.0573
DEBUG - 2022-06-20 01:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:46 --> Total execution time: 0.0477
DEBUG - 2022-06-20 01:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:50 --> Total execution time: 0.0433
DEBUG - 2022-06-20 01:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:04:56 --> Total execution time: 0.0482
DEBUG - 2022-06-20 01:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:05:01 --> Total execution time: 0.0969
DEBUG - 2022-06-20 01:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:05:42 --> Total execution time: 0.0708
DEBUG - 2022-06-20 01:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:05:47 --> Total execution time: 0.0905
DEBUG - 2022-06-20 01:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:05:56 --> Total execution time: 0.0454
DEBUG - 2022-06-20 01:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:05:58 --> Total execution time: 0.0593
DEBUG - 2022-06-20 01:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:05:59 --> Total execution time: 0.0692
DEBUG - 2022-06-20 01:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:06:01 --> Total execution time: 0.0507
DEBUG - 2022-06-20 01:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:06:19 --> Total execution time: 0.0462
DEBUG - 2022-06-20 01:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:06:24 --> Total execution time: 0.0615
DEBUG - 2022-06-20 01:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:06:32 --> Total execution time: 0.1160
DEBUG - 2022-06-20 01:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:06:50 --> Total execution time: 0.0531
DEBUG - 2022-06-20 01:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:07 --> Total execution time: 0.0644
DEBUG - 2022-06-20 01:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:13 --> Total execution time: 0.0549
DEBUG - 2022-06-20 01:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:15 --> Total execution time: 0.0665
DEBUG - 2022-06-20 01:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:20 --> Total execution time: 0.0549
DEBUG - 2022-06-20 01:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:24 --> Total execution time: 0.0626
DEBUG - 2022-06-20 01:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:30 --> Total execution time: 0.0724
DEBUG - 2022-06-20 01:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:32 --> Total execution time: 0.0618
DEBUG - 2022-06-20 01:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:42 --> Total execution time: 0.0586
DEBUG - 2022-06-20 01:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:45 --> Total execution time: 0.0517
DEBUG - 2022-06-20 01:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:49 --> Total execution time: 0.0464
DEBUG - 2022-06-20 01:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:52 --> Total execution time: 0.0585
DEBUG - 2022-06-20 01:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:57 --> Total execution time: 0.0722
DEBUG - 2022-06-20 01:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:07:59 --> Total execution time: 0.0512
DEBUG - 2022-06-20 01:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:08:02 --> Total execution time: 0.0957
DEBUG - 2022-06-20 01:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:08:04 --> Total execution time: 0.0498
DEBUG - 2022-06-20 01:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:08:08 --> Total execution time: 0.0837
DEBUG - 2022-06-20 01:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:08:15 --> Total execution time: 0.0574
DEBUG - 2022-06-20 01:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:08:19 --> Total execution time: 0.0629
DEBUG - 2022-06-20 01:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:08:23 --> Total execution time: 0.0646
DEBUG - 2022-06-20 01:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:08:34 --> Total execution time: 0.0903
DEBUG - 2022-06-20 01:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:08:40 --> Total execution time: 0.0477
DEBUG - 2022-06-20 01:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:09:01 --> Total execution time: 0.1148
DEBUG - 2022-06-20 01:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:09:04 --> Total execution time: 0.2492
DEBUG - 2022-06-20 01:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:39:05 --> No URI present. Default controller set.
DEBUG - 2022-06-20 01:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:09:05 --> Total execution time: 0.1561
DEBUG - 2022-06-20 01:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:14:22 --> Total execution time: 0.2078
DEBUG - 2022-06-20 01:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:18:32 --> Total execution time: 0.2932
DEBUG - 2022-06-20 01:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:19:04 --> Total execution time: 0.0856
DEBUG - 2022-06-20 01:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:19:08 --> Total execution time: 0.0571
DEBUG - 2022-06-20 01:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:21:35 --> Total execution time: 0.0488
DEBUG - 2022-06-20 01:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:21:39 --> Total execution time: 0.0541
DEBUG - 2022-06-20 01:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:21:45 --> Total execution time: 0.0476
DEBUG - 2022-06-20 01:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:21:48 --> Total execution time: 0.0712
DEBUG - 2022-06-20 01:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:21:50 --> Total execution time: 0.0708
DEBUG - 2022-06-20 01:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:23:03 --> Total execution time: 0.0487
DEBUG - 2022-06-20 01:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:24:48 --> Total execution time: 0.0450
DEBUG - 2022-06-20 01:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 01:56:02 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 01:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:26:02 --> Total execution time: 0.0582
DEBUG - 2022-06-20 01:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:17 --> Total execution time: 0.1703
DEBUG - 2022-06-20 01:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:46 --> Total execution time: 0.0376
DEBUG - 2022-06-20 01:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:51 --> Total execution time: 0.0550
DEBUG - 2022-06-20 01:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 01:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 01:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 01:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:59 --> Total execution time: 0.0666
DEBUG - 2022-06-20 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:30:03 --> Total execution time: 0.1462
DEBUG - 2022-06-20 02:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:33:42 --> Total execution time: 0.4517
DEBUG - 2022-06-20 02:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:34:22 --> Total execution time: 0.0571
DEBUG - 2022-06-20 02:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:05:44 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:35:44 --> Total execution time: 0.0385
DEBUG - 2022-06-20 02:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:05:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:35:50 --> Total execution time: 0.0579
DEBUG - 2022-06-20 02:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:38:51 --> Total execution time: 0.1530
DEBUG - 2022-06-20 02:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:39:15 --> Total execution time: 0.0672
DEBUG - 2022-06-20 02:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:39:59 --> Total execution time: 0.0584
DEBUG - 2022-06-20 02:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:40:05 --> Total execution time: 0.0740
DEBUG - 2022-06-20 02:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:40:15 --> Total execution time: 0.2572
DEBUG - 2022-06-20 02:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:40:52 --> Total execution time: 0.0432
DEBUG - 2022-06-20 02:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:42:05 --> Total execution time: 0.0527
DEBUG - 2022-06-20 02:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:42:14 --> Total execution time: 0.0696
DEBUG - 2022-06-20 02:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:42:20 --> Total execution time: 0.0714
DEBUG - 2022-06-20 02:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:42:29 --> Total execution time: 0.0506
DEBUG - 2022-06-20 02:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 02:13:33 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-20 02:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:15:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 02:15:05 --> 404 Page Not Found: Category/academics
DEBUG - 2022-06-20 02:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:18:11 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:48:11 --> Total execution time: 0.0880
DEBUG - 2022-06-20 02:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:48:19 --> Total execution time: 0.0657
DEBUG - 2022-06-20 02:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:21:03 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:51:03 --> Total execution time: 0.0367
DEBUG - 2022-06-20 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:51:19 --> Total execution time: 0.0811
DEBUG - 2022-06-20 02:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:52:03 --> Total execution time: 0.0551
DEBUG - 2022-06-20 02:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:52:11 --> Total execution time: 0.0551
DEBUG - 2022-06-20 02:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:52:16 --> Total execution time: 0.0561
DEBUG - 2022-06-20 02:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:24:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 02:24:12 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 02:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:54:38 --> Total execution time: 0.0455
DEBUG - 2022-06-20 02:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:54:44 --> Total execution time: 0.0469
DEBUG - 2022-06-20 02:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:54:49 --> Total execution time: 0.0897
DEBUG - 2022-06-20 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:54:58 --> Total execution time: 0.0416
DEBUG - 2022-06-20 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:55:04 --> Total execution time: 0.0519
DEBUG - 2022-06-20 02:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:55:27 --> Total execution time: 0.0452
DEBUG - 2022-06-20 02:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:55:34 --> Total execution time: 0.0486
DEBUG - 2022-06-20 02:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:55:40 --> Total execution time: 0.0755
DEBUG - 2022-06-20 02:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:56:07 --> Total execution time: 0.0565
DEBUG - 2022-06-20 02:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:56:14 --> Total execution time: 0.0372
DEBUG - 2022-06-20 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 02:26:42 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 02:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:57:52 --> Total execution time: 0.0381
DEBUG - 2022-06-20 02:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:27:56 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:57:56 --> Total execution time: 0.0514
DEBUG - 2022-06-20 02:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:03 --> Total execution time: 0.0648
DEBUG - 2022-06-20 02:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:08 --> Total execution time: 0.0479
DEBUG - 2022-06-20 02:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:17 --> Total execution time: 0.0495
DEBUG - 2022-06-20 02:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:20 --> Total execution time: 0.0639
DEBUG - 2022-06-20 02:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:20 --> Total execution time: 0.0467
DEBUG - 2022-06-20 02:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:37 --> Total execution time: 0.0418
DEBUG - 2022-06-20 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:40 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:40 --> Total execution time: 0.0365
DEBUG - 2022-06-20 02:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:42 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:42 --> Total execution time: 0.0992
DEBUG - 2022-06-20 02:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 02:28:46 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 02:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:58:47 --> Total execution time: 0.0443
DEBUG - 2022-06-20 02:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:59:02 --> Total execution time: 0.0619
DEBUG - 2022-06-20 02:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:59:06 --> Total execution time: 0.0863
DEBUG - 2022-06-20 02:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:59:26 --> Total execution time: 0.0808
DEBUG - 2022-06-20 02:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:29:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 02:29:34 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 02:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:59:45 --> Total execution time: 0.0532
DEBUG - 2022-06-20 02:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:59:49 --> Total execution time: 0.0842
DEBUG - 2022-06-20 02:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:59:53 --> Total execution time: 0.0846
DEBUG - 2022-06-20 02:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:30:44 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:00:44 --> Total execution time: 0.0313
DEBUG - 2022-06-20 02:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:30:51 --> Total execution time: 0.0444
DEBUG - 2022-06-20 02:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:30:52 --> Total execution time: 0.0404
DEBUG - 2022-06-20 02:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:30:53 --> Total execution time: 0.0562
DEBUG - 2022-06-20 02:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:30:53 --> Total execution time: 0.0866
DEBUG - 2022-06-20 02:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:30:55 --> Total execution time: 0.0487
DEBUG - 2022-06-20 02:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:31:00 --> Total execution time: 0.0613
DEBUG - 2022-06-20 02:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:32:14 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:02:14 --> Total execution time: 0.1073
DEBUG - 2022-06-20 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:35:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:05:47 --> Total execution time: 0.4885
DEBUG - 2022-06-20 02:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:05:52 --> Total execution time: 0.1492
DEBUG - 2022-06-20 02:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:00 --> Total execution time: 0.0859
DEBUG - 2022-06-20 02:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:10 --> Total execution time: 0.2694
DEBUG - 2022-06-20 02:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:17 --> Total execution time: 0.1440
DEBUG - 2022-06-20 02:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:32 --> Total execution time: 0.0630
DEBUG - 2022-06-20 02:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:39 --> Total execution time: 0.0772
DEBUG - 2022-06-20 02:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:42 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:42 --> Total execution time: 0.1837
DEBUG - 2022-06-20 02:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:43 --> Total execution time: 0.0842
DEBUG - 2022-06-20 02:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:51 --> Total execution time: 0.1080
DEBUG - 2022-06-20 02:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:06:54 --> Total execution time: 0.0762
DEBUG - 2022-06-20 02:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:08 --> Total execution time: 0.0737
DEBUG - 2022-06-20 02:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:12 --> Total execution time: 0.0586
DEBUG - 2022-06-20 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:20 --> Total execution time: 0.0589
DEBUG - 2022-06-20 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:20 --> Total execution time: 0.0454
DEBUG - 2022-06-20 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:28 --> Total execution time: 0.0596
DEBUG - 2022-06-20 02:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:33 --> Total execution time: 0.0459
DEBUG - 2022-06-20 02:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:33 --> Total execution time: 0.0695
DEBUG - 2022-06-20 02:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:34 --> Total execution time: 0.0640
DEBUG - 2022-06-20 02:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:36 --> Total execution time: 0.0488
DEBUG - 2022-06-20 02:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:40 --> Total execution time: 0.0489
DEBUG - 2022-06-20 02:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:43 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:07:43 --> Total execution time: 0.0714
DEBUG - 2022-06-20 02:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:37:47 --> Total execution time: 0.0440
DEBUG - 2022-06-20 02:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:37:48 --> Total execution time: 0.0481
DEBUG - 2022-06-20 02:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:37:49 --> Total execution time: 0.0431
DEBUG - 2022-06-20 02:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:08:04 --> Total execution time: 0.0414
DEBUG - 2022-06-20 02:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:08:09 --> Total execution time: 0.0746
DEBUG - 2022-06-20 02:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:08:20 --> Total execution time: 0.0638
DEBUG - 2022-06-20 02:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:40:10 --> Total execution time: 0.0462
DEBUG - 2022-06-20 02:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:40:11 --> Total execution time: 0.0637
DEBUG - 2022-06-20 02:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:40:12 --> Total execution time: 0.0555
DEBUG - 2022-06-20 02:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:40:13 --> Total execution time: 0.0432
DEBUG - 2022-06-20 02:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:29 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:10:29 --> Total execution time: 0.0418
DEBUG - 2022-06-20 02:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:10:32 --> Total execution time: 0.1509
DEBUG - 2022-06-20 02:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:10:37 --> Total execution time: 0.0793
DEBUG - 2022-06-20 02:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:40:54 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:10:54 --> Total execution time: 0.0361
DEBUG - 2022-06-20 02:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:41:00 --> Total execution time: 0.0455
DEBUG - 2022-06-20 02:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:41:02 --> Total execution time: 0.0590
DEBUG - 2022-06-20 02:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:41:02 --> Total execution time: 0.1107
DEBUG - 2022-06-20 02:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:41:04 --> Total execution time: 0.0633
DEBUG - 2022-06-20 02:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:41:05 --> Total execution time: 0.0702
DEBUG - 2022-06-20 02:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:41:06 --> Total execution time: 0.0632
DEBUG - 2022-06-20 02:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:12:20 --> Total execution time: 0.1070
DEBUG - 2022-06-20 02:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:12:21 --> Total execution time: 0.0574
DEBUG - 2022-06-20 02:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:12:22 --> Total execution time: 0.0544
DEBUG - 2022-06-20 02:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:42:25 --> Total execution time: 0.0870
DEBUG - 2022-06-20 02:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:12:26 --> Total execution time: 0.0565
DEBUG - 2022-06-20 02:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:42:26 --> Total execution time: 0.0698
DEBUG - 2022-06-20 02:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:42:27 --> Total execution time: 0.0466
DEBUG - 2022-06-20 02:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:12:31 --> Total execution time: 0.0581
DEBUG - 2022-06-20 02:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:12:35 --> Total execution time: 0.0487
DEBUG - 2022-06-20 02:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:12:41 --> Total execution time: 0.0512
DEBUG - 2022-06-20 02:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:12:53 --> Total execution time: 0.0451
DEBUG - 2022-06-20 02:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:13:04 --> Total execution time: 0.0673
DEBUG - 2022-06-20 02:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:13:08 --> Total execution time: 0.0354
DEBUG - 2022-06-20 02:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:13:11 --> Total execution time: 0.0708
DEBUG - 2022-06-20 02:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:13:20 --> Total execution time: 0.0838
DEBUG - 2022-06-20 02:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:13:28 --> Total execution time: 0.0442
DEBUG - 2022-06-20 02:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:14:00 --> Total execution time: 0.0346
DEBUG - 2022-06-20 02:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:15:48 --> Total execution time: 0.1481
DEBUG - 2022-06-20 02:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:15:53 --> Total execution time: 0.0424
DEBUG - 2022-06-20 02:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:02 --> Total execution time: 0.0752
DEBUG - 2022-06-20 02:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:05 --> Total execution time: 0.0490
DEBUG - 2022-06-20 02:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:08 --> Total execution time: 0.0494
DEBUG - 2022-06-20 02:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:15 --> Total execution time: 0.0636
DEBUG - 2022-06-20 02:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:16 --> Total execution time: 0.0458
DEBUG - 2022-06-20 02:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:27 --> Total execution time: 0.0436
DEBUG - 2022-06-20 02:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:34 --> Total execution time: 0.0461
DEBUG - 2022-06-20 02:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:38 --> Total execution time: 0.0595
DEBUG - 2022-06-20 02:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:40 --> Total execution time: 0.0470
DEBUG - 2022-06-20 02:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:44 --> Total execution time: 0.0691
DEBUG - 2022-06-20 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:16:49 --> Total execution time: 0.0407
DEBUG - 2022-06-20 02:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:17:00 --> Total execution time: 0.0442
DEBUG - 2022-06-20 02:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:17:16 --> Total execution time: 0.0434
DEBUG - 2022-06-20 02:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:17:25 --> Total execution time: 0.0470
DEBUG - 2022-06-20 02:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:17:33 --> Total execution time: 0.0734
DEBUG - 2022-06-20 02:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:17:41 --> Total execution time: 0.0447
DEBUG - 2022-06-20 02:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:17:56 --> Total execution time: 0.0410
DEBUG - 2022-06-20 02:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:18:07 --> Total execution time: 0.0406
DEBUG - 2022-06-20 02:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:13 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:13 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:18:13 --> Total execution time: 0.0536
DEBUG - 2022-06-20 02:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:18:13 --> Total execution time: 0.0542
DEBUG - 2022-06-20 02:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:18:16 --> Total execution time: 0.0444
DEBUG - 2022-06-20 02:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:18 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:18:18 --> Total execution time: 0.0557
DEBUG - 2022-06-20 02:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:18:25 --> Total execution time: 0.0458
DEBUG - 2022-06-20 02:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:18:33 --> Total execution time: 0.0432
DEBUG - 2022-06-20 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:47 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:18:47 --> Total execution time: 0.0384
DEBUG - 2022-06-20 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:48:47 --> Total execution time: 0.0610
DEBUG - 2022-06-20 02:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:48:49 --> Total execution time: 0.0552
DEBUG - 2022-06-20 02:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:48:49 --> Total execution time: 0.0953
DEBUG - 2022-06-20 02:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:48:52 --> Total execution time: 0.0435
DEBUG - 2022-06-20 02:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:48:53 --> Total execution time: 0.0612
DEBUG - 2022-06-20 02:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:48:53 --> Total execution time: 0.1189
DEBUG - 2022-06-20 02:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:48:57 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:18:57 --> Total execution time: 0.0511
DEBUG - 2022-06-20 02:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:11 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:20:11 --> Total execution time: 0.1178
DEBUG - 2022-06-20 02:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:50:13 --> Total execution time: 0.0480
DEBUG - 2022-06-20 02:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:50:14 --> Total execution time: 0.0561
DEBUG - 2022-06-20 02:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:50:14 --> Total execution time: 0.0431
DEBUG - 2022-06-20 02:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:18 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:20:18 --> Total execution time: 0.0443
DEBUG - 2022-06-20 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:20:23 --> Total execution time: 0.0394
DEBUG - 2022-06-20 02:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:20:30 --> Total execution time: 0.0533
DEBUG - 2022-06-20 02:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:20:51 --> Total execution time: 0.0717
DEBUG - 2022-06-20 02:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:50:53 --> Total execution time: 0.0326
DEBUG - 2022-06-20 02:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:50:54 --> Total execution time: 0.0710
DEBUG - 2022-06-20 02:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:50:54 --> Total execution time: 0.0812
DEBUG - 2022-06-20 02:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:04 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:21:04 --> Total execution time: 0.0770
DEBUG - 2022-06-20 02:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:21:07 --> Total execution time: 0.0420
DEBUG - 2022-06-20 02:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:21:16 --> Total execution time: 0.1140
DEBUG - 2022-06-20 02:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:27 --> Total execution time: 0.0410
DEBUG - 2022-06-20 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:28 --> Total execution time: 0.0437
DEBUG - 2022-06-20 02:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:28 --> Total execution time: 0.0798
DEBUG - 2022-06-20 02:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:31 --> Total execution time: 0.0410
DEBUG - 2022-06-20 02:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:32 --> Total execution time: 0.0399
DEBUG - 2022-06-20 02:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:51:32 --> Total execution time: 0.0472
DEBUG - 2022-06-20 02:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:52:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 02:52:09 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 02:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:52:15 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:22:15 --> Total execution time: 0.0957
DEBUG - 2022-06-20 02:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:52:44 --> Total execution time: 0.0518
DEBUG - 2022-06-20 02:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:52:46 --> Total execution time: 0.0637
DEBUG - 2022-06-20 02:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:52:46 --> Total execution time: 0.0891
DEBUG - 2022-06-20 02:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:22:56 --> Total execution time: 0.0453
DEBUG - 2022-06-20 02:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:22:58 --> Total execution time: 0.0993
DEBUG - 2022-06-20 02:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:53:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 02:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:23:18 --> Total execution time: 1.9082
DEBUG - 2022-06-20 02:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:25:04 --> Total execution time: 0.0470
DEBUG - 2022-06-20 02:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:25:13 --> Total execution time: 0.0500
DEBUG - 2022-06-20 02:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:25:29 --> Total execution time: 0.0726
DEBUG - 2022-06-20 02:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:27:30 --> Total execution time: 0.0939
DEBUG - 2022-06-20 02:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:27:33 --> Total execution time: 0.0421
DEBUG - 2022-06-20 02:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:27:42 --> Total execution time: 0.0477
DEBUG - 2022-06-20 02:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:27:44 --> Total execution time: 0.0638
DEBUG - 2022-06-20 02:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:27:53 --> Total execution time: 0.0752
DEBUG - 2022-06-20 02:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:28:02 --> Total execution time: 0.1027
DEBUG - 2022-06-20 02:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:58:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:28:09 --> Total execution time: 0.0509
DEBUG - 2022-06-20 02:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:28:32 --> Total execution time: 0.0552
DEBUG - 2022-06-20 02:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:58:35 --> Total execution time: 0.0579
DEBUG - 2022-06-20 02:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:58:36 --> Total execution time: 0.0559
DEBUG - 2022-06-20 02:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 02:58:36 --> Total execution time: 0.0432
DEBUG - 2022-06-20 02:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:59:06 --> No URI present. Default controller set.
DEBUG - 2022-06-20 02:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:29:07 --> Total execution time: 0.1101
DEBUG - 2022-06-20 02:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:29:14 --> Total execution time: 1.4534
DEBUG - 2022-06-20 02:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 02:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 02:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:29:55 --> Total execution time: 0.0418
DEBUG - 2022-06-20 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:30:03 --> Total execution time: 0.0857
DEBUG - 2022-06-20 03:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:30:32 --> Total execution time: 0.0594
DEBUG - 2022-06-20 03:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:00:34 --> Total execution time: 0.1295
DEBUG - 2022-06-20 03:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:00:37 --> Total execution time: 0.0660
DEBUG - 2022-06-20 03:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:00:37 --> Total execution time: 0.1145
DEBUG - 2022-06-20 03:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:30:42 --> Total execution time: 0.1361
DEBUG - 2022-06-20 03:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:31:09 --> Total execution time: 0.0549
DEBUG - 2022-06-20 03:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:31:14 --> Total execution time: 0.0480
DEBUG - 2022-06-20 03:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:34:02 --> Total execution time: 0.1843
DEBUG - 2022-06-20 03:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:34:09 --> Total execution time: 0.0536
DEBUG - 2022-06-20 03:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:05:10 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:35:11 --> Total execution time: 0.0953
DEBUG - 2022-06-20 03:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:35:14 --> Total execution time: 0.0374
DEBUG - 2022-06-20 03:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:35:47 --> Total execution time: 0.0474
DEBUG - 2022-06-20 03:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:37:10 --> Total execution time: 0.0499
DEBUG - 2022-06-20 03:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:37:12 --> Total execution time: 0.1308
DEBUG - 2022-06-20 03:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:37:34 --> Total execution time: 0.0524
DEBUG - 2022-06-20 03:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:37:45 --> Total execution time: 0.0552
DEBUG - 2022-06-20 03:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:09:01 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:01 --> Total execution time: 0.0901
DEBUG - 2022-06-20 03:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:12 --> Total execution time: 0.0494
DEBUG - 2022-06-20 03:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:23 --> Total execution time: 0.0839
DEBUG - 2022-06-20 03:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:09:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:52 --> Total execution time: 0.0427
DEBUG - 2022-06-20 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:08 --> Total execution time: 0.0414
DEBUG - 2022-06-20 03:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:10 --> Total execution time: 0.0415
DEBUG - 2022-06-20 03:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:10:17 --> Total execution time: 0.0439
DEBUG - 2022-06-20 03:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:10:19 --> Total execution time: 0.0445
DEBUG - 2022-06-20 03:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:10:19 --> Total execution time: 0.0732
DEBUG - 2022-06-20 03:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:24 --> Total execution time: 0.0681
DEBUG - 2022-06-20 03:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:31 --> Total execution time: 0.0533
DEBUG - 2022-06-20 03:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:36 --> Total execution time: 0.0529
DEBUG - 2022-06-20 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:46 --> Total execution time: 0.0497
DEBUG - 2022-06-20 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:52 --> Total execution time: 0.0547
DEBUG - 2022-06-20 03:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:52 --> Total execution time: 0.0471
DEBUG - 2022-06-20 03:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:53 --> Total execution time: 0.0417
DEBUG - 2022-06-20 03:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:55 --> Total execution time: 0.0527
DEBUG - 2022-06-20 03:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:59 --> Total execution time: 0.0487
DEBUG - 2022-06-20 03:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:06 --> Total execution time: 0.0638
DEBUG - 2022-06-20 03:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:09 --> Total execution time: 0.1111
DEBUG - 2022-06-20 03:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:12 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:12 --> Total execution time: 0.0441
DEBUG - 2022-06-20 03:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:11:13 --> Total execution time: 0.0429
DEBUG - 2022-06-20 03:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:11:13 --> Total execution time: 0.0443
DEBUG - 2022-06-20 03:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:11:14 --> Total execution time: 0.0836
DEBUG - 2022-06-20 03:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:17 --> Total execution time: 0.0459
DEBUG - 2022-06-20 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:28 --> Total execution time: 0.0529
DEBUG - 2022-06-20 03:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:35 --> Total execution time: 0.0679
DEBUG - 2022-06-20 03:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:41 --> Total execution time: 0.0857
DEBUG - 2022-06-20 03:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:11:46 --> Total execution time: 0.0566
DEBUG - 2022-06-20 03:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:11:47 --> Total execution time: 0.0432
DEBUG - 2022-06-20 03:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:48 --> Total execution time: 0.0470
DEBUG - 2022-06-20 03:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:52 --> Total execution time: 0.0470
DEBUG - 2022-06-20 03:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:55 --> Total execution time: 0.0572
DEBUG - 2022-06-20 03:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:41:59 --> Total execution time: 0.0600
DEBUG - 2022-06-20 03:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:42:03 --> Total execution time: 0.0560
DEBUG - 2022-06-20 03:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:42:07 --> Total execution time: 0.0454
DEBUG - 2022-06-20 03:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:42:12 --> Total execution time: 0.0517
DEBUG - 2022-06-20 03:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:42:17 --> Total execution time: 0.0643
DEBUG - 2022-06-20 03:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:42:21 --> Total execution time: 0.0750
DEBUG - 2022-06-20 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:42:26 --> Total execution time: 0.1521
DEBUG - 2022-06-20 03:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:52:23 --> Total execution time: 0.2816
DEBUG - 2022-06-20 03:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:55:40 --> Total execution time: 0.1967
DEBUG - 2022-06-20 03:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:55:40 --> Total execution time: 0.0526
DEBUG - 2022-06-20 03:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:55:50 --> Total execution time: 0.0753
DEBUG - 2022-06-20 03:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:29:27 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:59:27 --> Total execution time: 0.0785
DEBUG - 2022-06-20 03:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:59:38 --> Total execution time: 0.1048
DEBUG - 2022-06-20 03:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:29:44 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:59:44 --> Total execution time: 0.0666
DEBUG - 2022-06-20 03:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:30:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:00:17 --> Total execution time: 0.0555
DEBUG - 2022-06-20 03:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:00:26 --> Total execution time: 0.0522
DEBUG - 2022-06-20 03:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:00:35 --> Total execution time: 0.0736
DEBUG - 2022-06-20 03:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:00:50 --> Total execution time: 0.0562
DEBUG - 2022-06-20 03:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 03:31:02 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-06-20 03:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:01:14 --> Total execution time: 0.0563
DEBUG - 2022-06-20 03:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:01:23 --> Total execution time: 0.0494
DEBUG - 2022-06-20 03:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:01:30 --> Total execution time: 0.0550
DEBUG - 2022-06-20 03:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:32:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:02:52 --> Total execution time: 0.0693
DEBUG - 2022-06-20 03:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:32:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:02:52 --> Total execution time: 0.0330
DEBUG - 2022-06-20 03:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:32:59 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:02:59 --> Total execution time: 0.0537
DEBUG - 2022-06-20 03:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 03:33:13 --> 404 Page Not Found: Lessons/facebook-special-technique-for-personal-brandinng
DEBUG - 2022-06-20 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:04:55 --> Total execution time: 0.1436
DEBUG - 2022-06-20 03:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:04:55 --> Total execution time: 0.0932
DEBUG - 2022-06-20 03:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:05:12 --> Total execution time: 0.0731
DEBUG - 2022-06-20 03:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:37:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:07:37 --> Total execution time: 0.1324
DEBUG - 2022-06-20 14:07:37 --> Total execution time: 0.1449
DEBUG - 2022-06-20 03:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:07:56 --> Total execution time: 0.0565
DEBUG - 2022-06-20 03:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:01 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:08:01 --> Total execution time: 0.1121
DEBUG - 2022-06-20 03:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:08:05 --> Total execution time: 0.0643
DEBUG - 2022-06-20 03:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:08:16 --> Total execution time: 0.0467
DEBUG - 2022-06-20 03:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:08:27 --> Total execution time: 0.0526
DEBUG - 2022-06-20 03:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:08:33 --> Total execution time: 2.0060
DEBUG - 2022-06-20 03:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 03:38:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 03:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:08:40 --> Total execution time: 0.0763
DEBUG - 2022-06-20 03:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:38:40 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:08:40 --> Total execution time: 0.0622
DEBUG - 2022-06-20 03:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:08 --> Total execution time: 0.0997
DEBUG - 2022-06-20 03:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:09 --> Total execution time: 0.1225
DEBUG - 2022-06-20 03:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:16 --> Total execution time: 0.0385
DEBUG - 2022-06-20 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:19 --> Total execution time: 0.1138
DEBUG - 2022-06-20 03:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:26 --> Total execution time: 1.5796
DEBUG - 2022-06-20 03:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:29 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:29 --> Total execution time: 0.0535
DEBUG - 2022-06-20 03:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:36 --> Total execution time: 1.4617
DEBUG - 2022-06-20 03:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:39 --> Total execution time: 0.0663
DEBUG - 2022-06-20 03:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:49 --> Total execution time: 0.0629
DEBUG - 2022-06-20 03:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:09:59 --> Total execution time: 0.0879
DEBUG - 2022-06-20 03:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:10:10 --> Total execution time: 0.1135
DEBUG - 2022-06-20 03:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:10:11 --> Total execution time: 0.0589
DEBUG - 2022-06-20 03:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:10:30 --> Total execution time: 0.0648
DEBUG - 2022-06-20 03:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:10:37 --> Total execution time: 0.0972
DEBUG - 2022-06-20 03:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:11:16 --> Total execution time: 0.0943
DEBUG - 2022-06-20 03:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:11:25 --> Total execution time: 0.0906
DEBUG - 2022-06-20 03:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:11:55 --> Total execution time: 0.0710
DEBUG - 2022-06-20 03:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:12:19 --> Total execution time: 0.0591
DEBUG - 2022-06-20 03:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:12:24 --> Total execution time: 0.1113
DEBUG - 2022-06-20 03:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:14:31 --> Total execution time: 0.3080
DEBUG - 2022-06-20 03:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:14:36 --> Total execution time: 0.0461
DEBUG - 2022-06-20 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:14:38 --> Total execution time: 0.0675
DEBUG - 2022-06-20 03:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:14:45 --> Total execution time: 0.0453
DEBUG - 2022-06-20 03:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:51:13 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:21:14 --> Total execution time: 0.2539
DEBUG - 2022-06-20 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:21:17 --> Total execution time: 0.0869
DEBUG - 2022-06-20 03:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:21:22 --> Total execution time: 0.0813
DEBUG - 2022-06-20 03:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:21:25 --> Total execution time: 0.1023
DEBUG - 2022-06-20 03:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:21:27 --> Total execution time: 0.0571
DEBUG - 2022-06-20 03:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:21:30 --> Total execution time: 0.0581
DEBUG - 2022-06-20 03:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:52:44 --> Total execution time: 0.1299
DEBUG - 2022-06-20 03:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:52:55 --> Total execution time: 0.1060
DEBUG - 2022-06-20 03:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:53:45 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:45 --> Total execution time: 0.0483
DEBUG - 2022-06-20 03:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:50 --> Total execution time: 0.1251
DEBUG - 2022-06-20 03:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:53:55 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:55 --> Total execution time: 0.0442
DEBUG - 2022-06-20 03:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:53:56 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:56 --> Total execution time: 0.0424
DEBUG - 2022-06-20 03:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:58 --> Total execution time: 0.0541
DEBUG - 2022-06-20 03:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:24:02 --> Total execution time: 0.0746
DEBUG - 2022-06-20 03:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:24:11 --> Total execution time: 0.0457
DEBUG - 2022-06-20 03:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:24:14 --> Total execution time: 0.0520
DEBUG - 2022-06-20 03:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:24:39 --> Total execution time: 0.0526
DEBUG - 2022-06-20 03:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:25:06 --> Total execution time: 0.1193
DEBUG - 2022-06-20 03:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:25:07 --> Total execution time: 0.0450
DEBUG - 2022-06-20 03:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:55:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:25:08 --> Total execution time: 0.0478
DEBUG - 2022-06-20 03:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 03:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:25:09 --> Total execution time: 0.0359
DEBUG - 2022-06-20 03:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 03:59:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 03:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 03:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:29:52 --> Total execution time: 0.1653
DEBUG - 2022-06-20 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:03 --> Total execution time: 0.0843
DEBUG - 2022-06-20 04:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:06 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:06 --> Total execution time: 0.1907
DEBUG - 2022-06-20 04:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:15 --> Total execution time: 0.1431
DEBUG - 2022-06-20 04:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:22 --> Total execution time: 0.1333
DEBUG - 2022-06-20 04:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:25 --> Total execution time: 0.1254
DEBUG - 2022-06-20 04:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:27 --> Total execution time: 0.0826
DEBUG - 2022-06-20 04:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:33 --> Total execution time: 0.1750
DEBUG - 2022-06-20 04:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:34 --> Total execution time: 0.1980
DEBUG - 2022-06-20 04:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:46 --> Total execution time: 0.0868
DEBUG - 2022-06-20 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:30:57 --> Total execution time: 2.0812
DEBUG - 2022-06-20 04:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:01:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 04:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:06 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:31:06 --> Total execution time: 0.0739
DEBUG - 2022-06-20 04:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:31:08 --> Total execution time: 0.1257
DEBUG - 2022-06-20 04:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:31:16 --> Total execution time: 0.0659
DEBUG - 2022-06-20 04:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:31:22 --> Total execution time: 0.0733
DEBUG - 2022-06-20 04:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:31:39 --> Total execution time: 0.0485
DEBUG - 2022-06-20 04:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:31:40 --> Total execution time: 0.0470
DEBUG - 2022-06-20 04:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:31:42 --> Total execution time: 0.0732
DEBUG - 2022-06-20 04:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:31:52 --> Total execution time: 0.1027
DEBUG - 2022-06-20 04:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:02:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:02:14 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 04:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:03:05 --> Total execution time: 0.0772
DEBUG - 2022-06-20 04:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:03:12 --> Total execution time: 0.2024
DEBUG - 2022-06-20 04:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:18 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:33:18 --> Total execution time: 0.0567
DEBUG - 2022-06-20 04:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:18 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:33:19 --> Total execution time: 0.0448
DEBUG - 2022-06-20 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:33:28 --> Total execution time: 0.0570
DEBUG - 2022-06-20 04:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:33:30 --> Total execution time: 0.1332
DEBUG - 2022-06-20 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:03:32 --> 404 Page Not Found: Update-profile-basic-info/index
DEBUG - 2022-06-20 04:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:49 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:33:49 --> Total execution time: 0.0529
DEBUG - 2022-06-20 04:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:33:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:33:55 --> Total execution time: 0.0599
DEBUG - 2022-06-20 04:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:11 --> Total execution time: 0.0602
DEBUG - 2022-06-20 04:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:04:24 --> Total execution time: 0.0548
DEBUG - 2022-06-20 04:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:04:30 --> Total execution time: 0.0750
DEBUG - 2022-06-20 04:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:34 --> Total execution time: 0.0605
DEBUG - 2022-06-20 04:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:37 --> Total execution time: 0.0566
DEBUG - 2022-06-20 04:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:04:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 04:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:49 --> Total execution time: 0.0731
DEBUG - 2022-06-20 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:50 --> Total execution time: 0.0874
DEBUG - 2022-06-20 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:50 --> Total execution time: 0.0399
DEBUG - 2022-06-20 04:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:56 --> Total execution time: 0.0621
DEBUG - 2022-06-20 04:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:59 --> Total execution time: 0.0514
DEBUG - 2022-06-20 04:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:01 --> Total execution time: 0.0960
DEBUG - 2022-06-20 04:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:03 --> Total execution time: 0.0849
DEBUG - 2022-06-20 04:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:05 --> Total execution time: 0.0530
DEBUG - 2022-06-20 04:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:10 --> Total execution time: 0.0699
DEBUG - 2022-06-20 04:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:12 --> Total execution time: 0.0506
DEBUG - 2022-06-20 04:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:14 --> Total execution time: 0.0465
DEBUG - 2022-06-20 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:16 --> Total execution time: 0.1502
DEBUG - 2022-06-20 04:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:18 --> Total execution time: 0.0856
DEBUG - 2022-06-20 04:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:35 --> Total execution time: 0.0668
DEBUG - 2022-06-20 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:35 --> Total execution time: 0.0667
DEBUG - 2022-06-20 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:36 --> Total execution time: 0.0477
DEBUG - 2022-06-20 04:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:42 --> Total execution time: 0.0606
DEBUG - 2022-06-20 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:43 --> Total execution time: 0.0688
DEBUG - 2022-06-20 04:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:36:06 --> Total execution time: 0.1170
DEBUG - 2022-06-20 04:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:06:27 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:36:27 --> Total execution time: 0.0431
DEBUG - 2022-06-20 04:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:06:46 --> Total execution time: 0.0537
DEBUG - 2022-06-20 04:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:06:48 --> Total execution time: 0.0552
DEBUG - 2022-06-20 04:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:06:48 --> Total execution time: 0.1015
DEBUG - 2022-06-20 04:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:06:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:36:59 --> Total execution time: 0.0622
DEBUG - 2022-06-20 04:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:37:08 --> Total execution time: 0.0586
DEBUG - 2022-06-20 04:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:37:41 --> Total execution time: 0.0740
DEBUG - 2022-06-20 04:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:07:47 --> Total execution time: 0.0422
DEBUG - 2022-06-20 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:37:48 --> Total execution time: 0.0657
DEBUG - 2022-06-20 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:07:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:37:52 --> Total execution time: 0.1227
DEBUG - 2022-06-20 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:37:56 --> Total execution time: 0.0437
DEBUG - 2022-06-20 04:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:38:06 --> Total execution time: 0.0491
DEBUG - 2022-06-20 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:38:14 --> Total execution time: 0.0459
DEBUG - 2022-06-20 04:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:38:17 --> Total execution time: 0.1149
DEBUG - 2022-06-20 04:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:08:23 --> Total execution time: 0.0774
DEBUG - 2022-06-20 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:08:54 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:38:54 --> Total execution time: 0.1278
DEBUG - 2022-06-20 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:38:55 --> Total execution time: 0.0920
DEBUG - 2022-06-20 04:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:38:56 --> Total execution time: 0.1913
DEBUG - 2022-06-20 04:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:00 --> Total execution time: 0.0518
DEBUG - 2022-06-20 04:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:02 --> Total execution time: 0.1156
DEBUG - 2022-06-20 04:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:09 --> Total execution time: 0.0949
DEBUG - 2022-06-20 04:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:17 --> Total execution time: 0.0461
DEBUG - 2022-06-20 04:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:23 --> Total execution time: 0.0719
DEBUG - 2022-06-20 04:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:28 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:28 --> Total execution time: 0.0473
DEBUG - 2022-06-20 04:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:29 --> Total execution time: 0.0704
DEBUG - 2022-06-20 04:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:31 --> Total execution time: 0.0472
DEBUG - 2022-06-20 04:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:34 --> Total execution time: 0.0784
DEBUG - 2022-06-20 04:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:34 --> Total execution time: 0.0607
DEBUG - 2022-06-20 04:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:39:56 --> Total execution time: 0.0484
DEBUG - 2022-06-20 04:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:40:01 --> Total execution time: 0.0967
DEBUG - 2022-06-20 04:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:40:06 --> Total execution time: 0.0544
DEBUG - 2022-06-20 04:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:40:06 --> Total execution time: 0.0526
DEBUG - 2022-06-20 04:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:40:09 --> Total execution time: 0.1181
DEBUG - 2022-06-20 04:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:10:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:40:17 --> Total execution time: 0.0476
DEBUG - 2022-06-20 14:40:18 --> Total execution time: 1.6773
DEBUG - 2022-06-20 04:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:10:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 04:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:40:24 --> Total execution time: 0.0735
DEBUG - 2022-06-20 04:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:10:35 --> Total execution time: 0.0625
DEBUG - 2022-06-20 04:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:10:47 --> Total execution time: 0.0409
DEBUG - 2022-06-20 04:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:11:02 --> Total execution time: 0.0454
DEBUG - 2022-06-20 04:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:41:26 --> Total execution time: 0.0477
DEBUG - 2022-06-20 04:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:41:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:41:38 --> Total execution time: 0.0475
DEBUG - 2022-06-20 04:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:41:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 14:41:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 14:41:41 --> Total execution time: 0.2151
DEBUG - 2022-06-20 04:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:49 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:41:49 --> Total execution time: 0.0349
DEBUG - 2022-06-20 04:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:41:52 --> Total execution time: 0.0546
DEBUG - 2022-06-20 04:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:11:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:41:53 --> Total execution time: 0.1104
DEBUG - 2022-06-20 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:16 --> Total execution time: 0.0714
DEBUG - 2022-06-20 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:22 --> Total execution time: 0.1070
DEBUG - 2022-06-20 04:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:28 --> Total execution time: 0.0677
DEBUG - 2022-06-20 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:33 --> Total execution time: 0.0691
DEBUG - 2022-06-20 04:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:41 --> Total execution time: 0.0618
DEBUG - 2022-06-20 04:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:43 --> Total execution time: 0.0577
DEBUG - 2022-06-20 04:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:53 --> Total execution time: 0.0335
DEBUG - 2022-06-20 14:42:53 --> Total execution time: 0.0588
DEBUG - 2022-06-20 04:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:54 --> Total execution time: 0.0439
DEBUG - 2022-06-20 04:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:55 --> Total execution time: 0.0570
DEBUG - 2022-06-20 04:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:56 --> Total execution time: 0.0424
DEBUG - 2022-06-20 04:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:42:58 --> Total execution time: 0.0786
DEBUG - 2022-06-20 04:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:43:05 --> Total execution time: 0.0518
DEBUG - 2022-06-20 04:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:43:09 --> Total execution time: 0.0691
DEBUG - 2022-06-20 04:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:43:24 --> Total execution time: 0.0577
DEBUG - 2022-06-20 04:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:43:32 --> Total execution time: 0.0661
DEBUG - 2022-06-20 04:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:43:39 --> Total execution time: 0.0806
DEBUG - 2022-06-20 04:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:43:54 --> Total execution time: 0.0743
DEBUG - 2022-06-20 04:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:44:46 --> Total execution time: 0.1061
DEBUG - 2022-06-20 04:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:15:06 --> Total execution time: 0.0474
DEBUG - 2022-06-20 04:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:15:16 --> Total execution time: 0.0654
DEBUG - 2022-06-20 04:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:45:42 --> Total execution time: 0.0521
DEBUG - 2022-06-20 04:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:01 --> Total execution time: 0.0474
DEBUG - 2022-06-20 04:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:07 --> Total execution time: 0.1042
DEBUG - 2022-06-20 04:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:07 --> Total execution time: 0.0840
DEBUG - 2022-06-20 04:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:09 --> Total execution time: 0.1163
DEBUG - 2022-06-20 04:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:11 --> Total execution time: 0.0457
DEBUG - 2022-06-20 04:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:13 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:13 --> Total execution time: 0.0540
DEBUG - 2022-06-20 04:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:16 --> Total execution time: 0.0692
DEBUG - 2022-06-20 04:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:26 --> Total execution time: 0.0500
DEBUG - 2022-06-20 04:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:38 --> Total execution time: 0.0457
DEBUG - 2022-06-20 04:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:42 --> Total execution time: 0.0724
DEBUG - 2022-06-20 04:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:47 --> Total execution time: 0.0550
DEBUG - 2022-06-20 04:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:49 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:49 --> Total execution time: 0.0446
DEBUG - 2022-06-20 04:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:52 --> Total execution time: 0.0478
DEBUG - 2022-06-20 04:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:46:59 --> Total execution time: 0.0546
DEBUG - 2022-06-20 04:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:47:02 --> Total execution time: 0.0588
DEBUG - 2022-06-20 04:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:47:05 --> Total execution time: 0.0463
DEBUG - 2022-06-20 04:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:47:08 --> Total execution time: 0.0638
DEBUG - 2022-06-20 04:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:17:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:47:08 --> Total execution time: 0.0439
DEBUG - 2022-06-20 04:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:48:37 --> Total execution time: 0.1123
DEBUG - 2022-06-20 04:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:18:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:48:37 --> Total execution time: 0.1280
DEBUG - 2022-06-20 04:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:18:48 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:48:48 --> Total execution time: 0.0650
DEBUG - 2022-06-20 04:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:18:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:48:50 --> Total execution time: 0.0448
DEBUG - 2022-06-20 04:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:25 --> Total execution time: 0.0558
DEBUG - 2022-06-20 04:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:36 --> Total execution time: 0.0643
DEBUG - 2022-06-20 04:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:46 --> Total execution time: 0.0530
DEBUG - 2022-06-20 04:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:53 --> Total execution time: 0.0953
DEBUG - 2022-06-20 04:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:20 --> Total execution time: 0.0386
DEBUG - 2022-06-20 04:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:20 --> Total execution time: 0.0336
DEBUG - 2022-06-20 04:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:31 --> Total execution time: 0.0681
DEBUG - 2022-06-20 04:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:34 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:34 --> Total execution time: 0.0787
DEBUG - 2022-06-20 04:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:35 --> Total execution time: 0.0484
DEBUG - 2022-06-20 04:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:37 --> Total execution time: 0.0544
DEBUG - 2022-06-20 04:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:40 --> Total execution time: 0.1288
DEBUG - 2022-06-20 04:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:20:55 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:55 --> Total execution time: 0.0433
DEBUG - 2022-06-20 04:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:21:02 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:51:02 --> Total execution time: 0.1094
DEBUG - 2022-06-20 04:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:21:03 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:51:03 --> Total execution time: 0.0851
DEBUG - 2022-06-20 04:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:21:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:51:50 --> Total execution time: 0.1916
DEBUG - 2022-06-20 04:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:51:53 --> Total execution time: 0.0788
DEBUG - 2022-06-20 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:21:57 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:51:57 --> Total execution time: 0.0766
DEBUG - 2022-06-20 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:52:04 --> Total execution time: 0.0717
DEBUG - 2022-06-20 04:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:52:13 --> Total execution time: 0.0807
DEBUG - 2022-06-20 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:53:36 --> Total execution time: 0.0487
DEBUG - 2022-06-20 04:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:24:27 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:54:27 --> Total execution time: 0.0456
DEBUG - 2022-06-20 04:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:54:32 --> Total execution time: 0.0327
DEBUG - 2022-06-20 04:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:55:56 --> Total execution time: 0.0695
DEBUG - 2022-06-20 04:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:56:07 --> Total execution time: 0.0600
DEBUG - 2022-06-20 04:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:56:11 --> Total execution time: 0.0718
DEBUG - 2022-06-20 04:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:56:15 --> Total execution time: 0.0697
DEBUG - 2022-06-20 04:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:56:37 --> Total execution time: 0.0787
DEBUG - 2022-06-20 04:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:57:07 --> Total execution time: 0.0702
DEBUG - 2022-06-20 04:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:28:16 --> Total execution time: 0.1437
DEBUG - 2022-06-20 04:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:28:23 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:58:23 --> Total execution time: 0.1551
DEBUG - 2022-06-20 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:58:27 --> Total execution time: 0.0859
DEBUG - 2022-06-20 04:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:58:30 --> Total execution time: 0.0802
DEBUG - 2022-06-20 04:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:58:33 --> Total execution time: 0.0823
DEBUG - 2022-06-20 04:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:58:35 --> Total execution time: 0.0811
DEBUG - 2022-06-20 04:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:58:36 --> Total execution time: 0.0610
DEBUG - 2022-06-20 04:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:29:05 --> Total execution time: 0.1911
DEBUG - 2022-06-20 04:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:30:10 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:33:03 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 04:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:35:54 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:05:55 --> Total execution time: 0.2418
DEBUG - 2022-06-20 04:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:40:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:10:08 --> Total execution time: 0.2756
DEBUG - 2022-06-20 04:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:40:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:10:09 --> Total execution time: 0.0503
DEBUG - 2022-06-20 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:40:15 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:10:15 --> Total execution time: 0.0494
DEBUG - 2022-06-20 04:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:10:20 --> Total execution time: 0.0803
DEBUG - 2022-06-20 04:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:10:32 --> Total execution time: 0.0849
DEBUG - 2022-06-20 04:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:41:45 --> Total execution time: 0.0709
DEBUG - 2022-06-20 04:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:41:51 --> Total execution time: 0.1197
DEBUG - 2022-06-20 04:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:13:36 --> Total execution time: 0.0975
DEBUG - 2022-06-20 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:14:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:14:15 --> Total execution time: 0.1241
DEBUG - 2022-06-20 04:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:14:50 --> Total execution time: 0.0648
DEBUG - 2022-06-20 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:15:36 --> Total execution time: 0.0419
DEBUG - 2022-06-20 04:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:15:43 --> Total execution time: 0.0649
DEBUG - 2022-06-20 04:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:44 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:15:44 --> Total execution time: 0.1267
DEBUG - 2022-06-20 04:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:15:47 --> Total execution time: 0.0798
DEBUG - 2022-06-20 04:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:15:51 --> Total execution time: 0.1183
DEBUG - 2022-06-20 04:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:15:51 --> Total execution time: 0.0493
DEBUG - 2022-06-20 04:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:15:58 --> Total execution time: 0.1434
DEBUG - 2022-06-20 04:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:00 --> Total execution time: 0.0821
DEBUG - 2022-06-20 04:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:00 --> Total execution time: 0.1523
DEBUG - 2022-06-20 04:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:06 --> Total execution time: 0.0960
DEBUG - 2022-06-20 04:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:07 --> Total execution time: 0.0838
DEBUG - 2022-06-20 04:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:20 --> Total execution time: 0.0357
DEBUG - 2022-06-20 04:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:25 --> Total execution time: 0.0447
DEBUG - 2022-06-20 04:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:26 --> Total execution time: 0.0740
DEBUG - 2022-06-20 04:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:30 --> Total execution time: 0.0660
DEBUG - 2022-06-20 04:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:16:43 --> Total execution time: 0.0735
DEBUG - 2022-06-20 04:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:02 --> Total execution time: 0.0898
DEBUG - 2022-06-20 04:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:11 --> Total execution time: 0.0690
DEBUG - 2022-06-20 04:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:12 --> Total execution time: 0.0473
DEBUG - 2022-06-20 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:15 --> Total execution time: 0.0668
DEBUG - 2022-06-20 04:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:18 --> Total execution time: 0.0496
DEBUG - 2022-06-20 04:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:25 --> Total execution time: 0.0422
DEBUG - 2022-06-20 04:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:26 --> Total execution time: 0.0856
DEBUG - 2022-06-20 04:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:35 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:36 --> Total execution time: 0.0888
DEBUG - 2022-06-20 04:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:45 --> Total execution time: 0.0671
DEBUG - 2022-06-20 04:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:50 --> Total execution time: 0.0560
DEBUG - 2022-06-20 04:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:53 --> Total execution time: 0.0855
DEBUG - 2022-06-20 04:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:47:57 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:17:57 --> Total execution time: 0.0554
DEBUG - 2022-06-20 04:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:18:32 --> Total execution time: 0.0593
DEBUG - 2022-06-20 04:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:18:44 --> Total execution time: 0.0496
DEBUG - 2022-06-20 04:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:18:50 --> Total execution time: 0.0570
DEBUG - 2022-06-20 04:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:18:58 --> Total execution time: 0.0622
DEBUG - 2022-06-20 04:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:19:23 --> Total execution time: 0.0420
DEBUG - 2022-06-20 04:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:50:05 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:20:05 --> Total execution time: 0.0720
DEBUG - 2022-06-20 04:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:50:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:20:10 --> Total execution time: 0.0352
DEBUG - 2022-06-20 04:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:20:19 --> Total execution time: 0.0322
DEBUG - 2022-06-20 04:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:05 --> Total execution time: 0.0894
DEBUG - 2022-06-20 04:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:19 --> Total execution time: 0.0400
DEBUG - 2022-06-20 04:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:25 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:25 --> Total execution time: 0.0526
DEBUG - 2022-06-20 04:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:33 --> Total execution time: 0.0461
DEBUG - 2022-06-20 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:40 --> Total execution time: 0.0697
DEBUG - 2022-06-20 04:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:41 --> Total execution time: 0.0426
DEBUG - 2022-06-20 04:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:46 --> Total execution time: 0.0258
DEBUG - 2022-06-20 04:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:21:51 --> Total execution time: 0.1457
DEBUG - 2022-06-20 04:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:00 --> Total execution time: 0.1371
DEBUG - 2022-06-20 04:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:00 --> Total execution time: 0.0772
DEBUG - 2022-06-20 04:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:05 --> Total execution time: 0.0457
DEBUG - 2022-06-20 04:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:09 --> Total execution time: 0.0911
DEBUG - 2022-06-20 04:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:15 --> Total execution time: 0.1391
DEBUG - 2022-06-20 04:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:21 --> Total execution time: 0.0543
DEBUG - 2022-06-20 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:52:27 --> Total execution time: 0.1105
DEBUG - 2022-06-20 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:41 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:41 --> Total execution time: 0.0540
DEBUG - 2022-06-20 15:22:41 --> Total execution time: 0.1022
DEBUG - 2022-06-20 04:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:46 --> Total execution time: 0.0427
DEBUG - 2022-06-20 04:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:50 --> Total execution time: 0.0840
DEBUG - 2022-06-20 04:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:22:55 --> Total execution time: 0.0631
DEBUG - 2022-06-20 04:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:06 --> Total execution time: 0.0525
DEBUG - 2022-06-20 04:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:07 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:07 --> Total execution time: 0.0875
DEBUG - 2022-06-20 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:14 --> Total execution time: 2.0551
DEBUG - 2022-06-20 04:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:14 --> Total execution time: 0.0681
DEBUG - 2022-06-20 04:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 04:53:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 04:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:33 --> Total execution time: 0.0712
DEBUG - 2022-06-20 04:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:42 --> Total execution time: 0.0480
DEBUG - 2022-06-20 04:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:45 --> Total execution time: 0.0604
DEBUG - 2022-06-20 04:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:54 --> Total execution time: 0.0607
DEBUG - 2022-06-20 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:23:59 --> Total execution time: 0.0658
DEBUG - 2022-06-20 15:23:59 --> Total execution time: 0.1075
DEBUG - 2022-06-20 04:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:00 --> Total execution time: 0.0420
DEBUG - 2022-06-20 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:08 --> Total execution time: 0.0786
DEBUG - 2022-06-20 04:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:20 --> Total execution time: 0.1144
DEBUG - 2022-06-20 04:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:23 --> Total execution time: 0.0962
DEBUG - 2022-06-20 04:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:33 --> Total execution time: 0.1518
DEBUG - 2022-06-20 04:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:33 --> Total execution time: 0.0641
DEBUG - 2022-06-20 04:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:35 --> Total execution time: 0.0498
DEBUG - 2022-06-20 04:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:54:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:37 --> Total execution time: 0.2277
DEBUG - 2022-06-20 04:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:38 --> Total execution time: 0.1704
DEBUG - 2022-06-20 04:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:38 --> Total execution time: 0.0887
DEBUG - 2022-06-20 04:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:43 --> Total execution time: 0.1216
DEBUG - 2022-06-20 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:44 --> Total execution time: 0.0896
DEBUG - 2022-06-20 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:54:45 --> Total execution time: 0.0599
DEBUG - 2022-06-20 04:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:46 --> Total execution time: 0.1121
DEBUG - 2022-06-20 04:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:49 --> Total execution time: 0.0571
DEBUG - 2022-06-20 04:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:50 --> Total execution time: 0.0641
DEBUG - 2022-06-20 04:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:24:51 --> Total execution time: 0.0649
DEBUG - 2022-06-20 04:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:00 --> Total execution time: 0.0530
DEBUG - 2022-06-20 04:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:03 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:03 --> Total execution time: 0.1097
DEBUG - 2022-06-20 04:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:03 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:03 --> Total execution time: 0.1583
DEBUG - 2022-06-20 04:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:07 --> Total execution time: 0.0872
DEBUG - 2022-06-20 04:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:16 --> Total execution time: 0.1016
DEBUG - 2022-06-20 04:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:20 --> Total execution time: 0.0603
DEBUG - 2022-06-20 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:27 --> Total execution time: 0.0710
DEBUG - 2022-06-20 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:31 --> Total execution time: 0.0517
DEBUG - 2022-06-20 04:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:31 --> Total execution time: 0.0584
DEBUG - 2022-06-20 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:32 --> Total execution time: 0.0743
DEBUG - 2022-06-20 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:34 --> Total execution time: 0.1012
DEBUG - 2022-06-20 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:34 --> Total execution time: 0.0627
DEBUG - 2022-06-20 04:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:36 --> Total execution time: 0.0574
DEBUG - 2022-06-20 04:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 04:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:37 --> Total execution time: 0.0260
DEBUG - 2022-06-20 04:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:40 --> Total execution time: 0.0473
DEBUG - 2022-06-20 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:43 --> Total execution time: 0.0519
DEBUG - 2022-06-20 04:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:25:51 --> Total execution time: 0.0539
DEBUG - 2022-06-20 04:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:01 --> Total execution time: 0.0600
DEBUG - 2022-06-20 04:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:30 --> Total execution time: 0.1039
DEBUG - 2022-06-20 04:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:47 --> Total execution time: 0.1654
DEBUG - 2022-06-20 04:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:49 --> Total execution time: 0.0403
DEBUG - 2022-06-20 04:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:49 --> Total execution time: 0.0457
DEBUG - 2022-06-20 04:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:55 --> Total execution time: 0.0780
DEBUG - 2022-06-20 04:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:57 --> Total execution time: 0.0653
DEBUG - 2022-06-20 04:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 04:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:26:58 --> Total execution time: 0.0452
DEBUG - 2022-06-20 04:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:27:37 --> Total execution time: 0.1079
DEBUG - 2022-06-20 04:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:27:40 --> Total execution time: 0.0669
DEBUG - 2022-06-20 04:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:27:42 --> Total execution time: 0.0567
DEBUG - 2022-06-20 04:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:27:47 --> Total execution time: 0.0475
DEBUG - 2022-06-20 04:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:27:50 --> Total execution time: 0.1101
DEBUG - 2022-06-20 04:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:27:53 --> Total execution time: 0.0556
DEBUG - 2022-06-20 04:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:28:02 --> Total execution time: 0.0541
DEBUG - 2022-06-20 04:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:28:12 --> Total execution time: 0.1491
DEBUG - 2022-06-20 04:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:28:18 --> Total execution time: 0.0417
DEBUG - 2022-06-20 04:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:28:50 --> Total execution time: 0.0499
DEBUG - 2022-06-20 04:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:28:53 --> Total execution time: 0.0460
DEBUG - 2022-06-20 04:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:28:56 --> Total execution time: 0.0531
DEBUG - 2022-06-20 04:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:29:07 --> Total execution time: 0.0572
DEBUG - 2022-06-20 04:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:29:08 --> Total execution time: 0.0458
DEBUG - 2022-06-20 04:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 04:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 04:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 04:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:29:09 --> Total execution time: 0.0953
DEBUG - 2022-06-20 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:30:02 --> Total execution time: 0.1053
DEBUG - 2022-06-20 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:30:03 --> Total execution time: 0.1397
DEBUG - 2022-06-20 05:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:31:13 --> Total execution time: 0.0438
DEBUG - 2022-06-20 05:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:32:09 --> Total execution time: 0.1261
DEBUG - 2022-06-20 05:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:32:45 --> Total execution time: 0.0573
DEBUG - 2022-06-20 05:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:04:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:34:20 --> Total execution time: 0.1236
DEBUG - 2022-06-20 05:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:34:23 --> Total execution time: 0.0563
DEBUG - 2022-06-20 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:34:31 --> Total execution time: 0.1722
DEBUG - 2022-06-20 05:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 05:04:53 --> 404 Page Not Found: Teacher/chris-c-wallace
DEBUG - 2022-06-20 05:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:37:52 --> Total execution time: 0.1493
DEBUG - 2022-06-20 05:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:38:06 --> Total execution time: 0.0810
DEBUG - 2022-06-20 05:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:38:10 --> Total execution time: 0.0925
DEBUG - 2022-06-20 05:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:38:22 --> Total execution time: 0.0850
DEBUG - 2022-06-20 05:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:42:06 --> Total execution time: 0.1743
DEBUG - 2022-06-20 05:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:43:24 --> Total execution time: 0.0660
DEBUG - 2022-06-20 05:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:14:55 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:44:55 --> Total execution time: 0.0392
DEBUG - 2022-06-20 05:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:15:39 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:45:39 --> Total execution time: 0.0987
DEBUG - 2022-06-20 05:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:45:42 --> Total execution time: 0.0510
DEBUG - 2022-06-20 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:45:54 --> Total execution time: 0.1195
DEBUG - 2022-06-20 05:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:45:58 --> Total execution time: 0.0711
DEBUG - 2022-06-20 05:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:46:02 --> Total execution time: 0.1263
DEBUG - 2022-06-20 05:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:46:31 --> Total execution time: 0.0603
DEBUG - 2022-06-20 05:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:46:50 --> Total execution time: 0.1177
DEBUG - 2022-06-20 05:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:46:54 --> Total execution time: 0.0614
DEBUG - 2022-06-20 05:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:46:56 --> Total execution time: 0.1029
DEBUG - 2022-06-20 05:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:46:58 --> Total execution time: 0.0624
DEBUG - 2022-06-20 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:47:39 --> Total execution time: 0.0610
DEBUG - 2022-06-20 05:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:47:47 --> Total execution time: 0.0715
DEBUG - 2022-06-20 05:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:49:04 --> Total execution time: 0.0827
DEBUG - 2022-06-20 05:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:19:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:49:16 --> Total execution time: 0.1415
DEBUG - 2022-06-20 05:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:49:28 --> Total execution time: 0.0541
DEBUG - 2022-06-20 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:49:32 --> Total execution time: 0.0614
DEBUG - 2022-06-20 05:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:50:01 --> Total execution time: 0.0574
DEBUG - 2022-06-20 05:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:50:11 --> Total execution time: 0.0479
DEBUG - 2022-06-20 05:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:50:15 --> Total execution time: 0.1585
DEBUG - 2022-06-20 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:50:21 --> Total execution time: 0.1553
DEBUG - 2022-06-20 05:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:12 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:51:12 --> Total execution time: 0.1800
DEBUG - 2022-06-20 05:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:51:14 --> Total execution time: 0.2576
DEBUG - 2022-06-20 05:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:51:20 --> Total execution time: 0.0982
DEBUG - 2022-06-20 05:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:51:43 --> Total execution time: 0.0618
DEBUG - 2022-06-20 05:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:51:48 --> Total execution time: 0.1430
DEBUG - 2022-06-20 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:51:52 --> Total execution time: 0.0559
DEBUG - 2022-06-20 05:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:51:56 --> Total execution time: 0.1590
DEBUG - 2022-06-20 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:52:00 --> Total execution time: 0.1267
DEBUG - 2022-06-20 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:22:40 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:52:40 --> Total execution time: 0.1063
DEBUG - 2022-06-20 05:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:52:45 --> Total execution time: 0.0457
DEBUG - 2022-06-20 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:52:48 --> Total execution time: 0.0668
DEBUG - 2022-06-20 05:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:52:52 --> Total execution time: 0.1006
DEBUG - 2022-06-20 05:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:52:55 --> Total execution time: 0.0464
DEBUG - 2022-06-20 05:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:53:04 --> Total execution time: 0.1787
DEBUG - 2022-06-20 05:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:53:16 --> Total execution time: 0.1215
DEBUG - 2022-06-20 05:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:53:18 --> Total execution time: 0.0843
DEBUG - 2022-06-20 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:53:20 --> Total execution time: 0.0614
DEBUG - 2022-06-20 05:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:23:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:53:22 --> Total execution time: 0.1160
DEBUG - 2022-06-20 05:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:10 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:10 --> Total execution time: 0.1326
DEBUG - 2022-06-20 05:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:23 --> Total execution time: 0.0446
DEBUG - 2022-06-20 05:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:27 --> Total execution time: 0.1375
DEBUG - 2022-06-20 05:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:30 --> Total execution time: 0.0897
DEBUG - 2022-06-20 05:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:31 --> Total execution time: 0.1285
DEBUG - 2022-06-20 05:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:33 --> Total execution time: 0.0697
DEBUG - 2022-06-20 05:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 15:54:39 --> Total execution time: 0.0708
DEBUG - 2022-06-20 05:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:39 --> Total execution time: 0.0986
DEBUG - 2022-06-20 05:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:55 --> Total execution time: 0.0482
DEBUG - 2022-06-20 05:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:24:56 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:54:56 --> Total execution time: 0.0784
DEBUG - 2022-06-20 05:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:55:00 --> Total execution time: 0.0735
DEBUG - 2022-06-20 05:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:55:03 --> Total execution time: 0.0503
DEBUG - 2022-06-20 05:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:25:15 --> Total execution time: 0.0559
DEBUG - 2022-06-20 05:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:25:25 --> Total execution time: 0.0397
DEBUG - 2022-06-20 05:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:25:37 --> Total execution time: 0.0427
DEBUG - 2022-06-20 05:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:26:03 --> Total execution time: 0.0558
DEBUG - 2022-06-20 05:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:26:33 --> Total execution time: 0.0399
DEBUG - 2022-06-20 05:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:26:35 --> Total execution time: 0.0527
DEBUG - 2022-06-20 05:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:26:36 --> Total execution time: 0.0489
DEBUG - 2022-06-20 05:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:26:39 --> Total execution time: 0.0563
DEBUG - 2022-06-20 05:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:26:40 --> Total execution time: 0.0403
DEBUG - 2022-06-20 05:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:56:41 --> Total execution time: 0.1067
DEBUG - 2022-06-20 05:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:56:42 --> Total execution time: 0.0548
DEBUG - 2022-06-20 05:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:26:44 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:56:44 --> Total execution time: 0.0578
DEBUG - 2022-06-20 05:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:29:45 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:59:45 --> Total execution time: 0.0995
DEBUG - 2022-06-20 05:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:00:14 --> Total execution time: 0.0612
DEBUG - 2022-06-20 05:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:32:36 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:02:36 --> Total execution time: 0.0896
DEBUG - 2022-06-20 05:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:32:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:02:37 --> Total execution time: 0.0416
DEBUG - 2022-06-20 05:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:32:45 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:02:45 --> Total execution time: 0.1301
DEBUG - 2022-06-20 05:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:32:46 --> Total execution time: 0.0379
DEBUG - 2022-06-20 05:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:35:39 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:05:39 --> Total execution time: 0.1110
DEBUG - 2022-06-20 05:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:07:06 --> Total execution time: 0.0369
DEBUG - 2022-06-20 05:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:38:05 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:08:05 --> Total execution time: 0.1205
DEBUG - 2022-06-20 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:08:11 --> Total execution time: 0.0804
DEBUG - 2022-06-20 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:08:16 --> Total execution time: 0.0687
DEBUG - 2022-06-20 05:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:08:23 --> Total execution time: 0.0695
DEBUG - 2022-06-20 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:08:27 --> Total execution time: 0.0415
DEBUG - 2022-06-20 05:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:06 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:10:06 --> Total execution time: 0.2399
DEBUG - 2022-06-20 05:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:10:11 --> Total execution time: 0.1138
DEBUG - 2022-06-20 05:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:10:16 --> Total execution time: 0.0485
DEBUG - 2022-06-20 05:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:10:19 --> Total execution time: 0.0519
DEBUG - 2022-06-20 05:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:10:23 --> Total execution time: 0.0889
DEBUG - 2022-06-20 05:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:10:25 --> Total execution time: 0.0835
DEBUG - 2022-06-20 05:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:10:28 --> Total execution time: 0.0610
DEBUG - 2022-06-20 05:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 05:41:38 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 05:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:12:28 --> Total execution time: 0.0735
DEBUG - 2022-06-20 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:13:49 --> Total execution time: 0.0747
DEBUG - 2022-06-20 05:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:44:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 05:44:14 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 05:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:44:36 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:14:36 --> Total execution time: 0.0583
DEBUG - 2022-06-20 05:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:45:28 --> Total execution time: 0.3253
DEBUG - 2022-06-20 05:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:45:40 --> Total execution time: 0.1056
DEBUG - 2022-06-20 05:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:45:40 --> Total execution time: 0.1449
DEBUG - 2022-06-20 05:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 05:46:18 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 05:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:48:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 05:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:18:24 --> Total execution time: 1.9882
DEBUG - 2022-06-20 05:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 05:48:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 05:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:21:43 --> Total execution time: 1.6193
DEBUG - 2022-06-20 05:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:52:51 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:22:52 --> Total execution time: 0.1235
DEBUG - 2022-06-20 05:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:52:59 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:22:59 --> Total execution time: 0.0321
DEBUG - 2022-06-20 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:23:00 --> Total execution time: 0.0358
DEBUG - 2022-06-20 05:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:23:15 --> Total execution time: 0.0687
DEBUG - 2022-06-20 05:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:23:24 --> Total execution time: 0.0766
DEBUG - 2022-06-20 05:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:23:31 --> Total execution time: 0.0721
DEBUG - 2022-06-20 05:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:23:38 --> Total execution time: 0.1309
DEBUG - 2022-06-20 05:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:23:46 --> Total execution time: 0.0663
DEBUG - 2022-06-20 05:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:23:48 --> Total execution time: 0.0732
DEBUG - 2022-06-20 05:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:23:59 --> Total execution time: 0.0498
DEBUG - 2022-06-20 05:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:54:01 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:24:02 --> Total execution time: 0.0482
DEBUG - 2022-06-20 05:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:24:03 --> Total execution time: 0.0593
DEBUG - 2022-06-20 05:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 05:54:08 --> Total execution time: 0.0415
DEBUG - 2022-06-20 05:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:24:13 --> Total execution time: 0.0660
DEBUG - 2022-06-20 05:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:54:36 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:24:36 --> Total execution time: 0.0474
DEBUG - 2022-06-20 05:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:24:48 --> Total execution time: 0.1255
DEBUG - 2022-06-20 05:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:25:08 --> Total execution time: 0.0282
DEBUG - 2022-06-20 05:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:55:19 --> No URI present. Default controller set.
DEBUG - 2022-06-20 05:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:25:19 --> Total execution time: 0.0299
DEBUG - 2022-06-20 05:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 05:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 05:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:28:24 --> Total execution time: 0.1517
DEBUG - 2022-06-20 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:30:02 --> Total execution time: 0.0785
DEBUG - 2022-06-20 06:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:31:40 --> Total execution time: 0.1594
DEBUG - 2022-06-20 06:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:31:42 --> Total execution time: 0.0677
DEBUG - 2022-06-20 06:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:31:55 --> Total execution time: 0.0818
DEBUG - 2022-06-20 06:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:31:57 --> Total execution time: 0.0457
DEBUG - 2022-06-20 06:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:31:58 --> Total execution time: 0.0460
DEBUG - 2022-06-20 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:32:00 --> Total execution time: 0.0695
DEBUG - 2022-06-20 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:32:02 --> Total execution time: 0.0524
DEBUG - 2022-06-20 06:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:32:05 --> Total execution time: 0.0746
DEBUG - 2022-06-20 06:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:32:11 --> Total execution time: 0.0873
DEBUG - 2022-06-20 06:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:02:17 --> Total execution time: 0.0508
DEBUG - 2022-06-20 06:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:02:24 --> Total execution time: 0.0403
DEBUG - 2022-06-20 06:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:32:38 --> Total execution time: 0.1041
DEBUG - 2022-06-20 06:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:32:43 --> Total execution time: 0.0753
DEBUG - 2022-06-20 06:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:33:03 --> Total execution time: 0.0986
DEBUG - 2022-06-20 06:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:34:09 --> Total execution time: 0.0518
DEBUG - 2022-06-20 06:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:34:13 --> Total execution time: 0.0487
DEBUG - 2022-06-20 06:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:34:27 --> Total execution time: 0.0773
DEBUG - 2022-06-20 06:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:34:28 --> Total execution time: 0.0963
DEBUG - 2022-06-20 06:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:34:51 --> Total execution time: 0.0767
DEBUG - 2022-06-20 06:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:34:56 --> Total execution time: 0.0622
DEBUG - 2022-06-20 06:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:35:00 --> Total execution time: 0.0883
DEBUG - 2022-06-20 06:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:35:09 --> Total execution time: 0.0519
DEBUG - 2022-06-20 06:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:05:14 --> Total execution time: 0.0467
DEBUG - 2022-06-20 06:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:35:18 --> Total execution time: 0.0450
DEBUG - 2022-06-20 06:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:35:20 --> Total execution time: 0.0840
DEBUG - 2022-06-20 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:35:25 --> Total execution time: 0.0617
DEBUG - 2022-06-20 06:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:35:27 --> Total execution time: 0.0589
DEBUG - 2022-06-20 06:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:35:43 --> Total execution time: 0.0687
DEBUG - 2022-06-20 06:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:09:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 06:09:54 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 06:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:12:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:42:01 --> Total execution time: 0.1689
DEBUG - 2022-06-20 06:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:49:05 --> Total execution time: 0.0615
DEBUG - 2022-06-20 06:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:21:59 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:51:59 --> Total execution time: 0.1122
DEBUG - 2022-06-20 06:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:52:10 --> Total execution time: 0.0325
DEBUG - 2022-06-20 06:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:22:41 --> Total execution time: 0.0477
DEBUG - 2022-06-20 06:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:22:42 --> Total execution time: 0.0739
DEBUG - 2022-06-20 06:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:22:42 --> Total execution time: 0.0626
DEBUG - 2022-06-20 06:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:23:42 --> Total execution time: 0.0445
DEBUG - 2022-06-20 06:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:23:43 --> Total execution time: 0.0504
DEBUG - 2022-06-20 06:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:23:43 --> Total execution time: 0.0433
DEBUG - 2022-06-20 06:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:23:57 --> Total execution time: 0.0434
DEBUG - 2022-06-20 06:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:23:58 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:53:58 --> Total execution time: 0.0446
DEBUG - 2022-06-20 06:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:23:58 --> Total execution time: 0.0783
DEBUG - 2022-06-20 06:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:23:58 --> Total execution time: 0.1324
DEBUG - 2022-06-20 06:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:59:07 --> Total execution time: 0.2142
DEBUG - 2022-06-20 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:59:18 --> Total execution time: 0.0604
DEBUG - 2022-06-20 06:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:59:20 --> Total execution time: 0.1075
DEBUG - 2022-06-20 06:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:29:38 --> Total execution time: 0.0481
DEBUG - 2022-06-20 06:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:29:40 --> Total execution time: 0.0434
DEBUG - 2022-06-20 06:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:29:40 --> Total execution time: 0.1018
DEBUG - 2022-06-20 06:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:59:51 --> Total execution time: 0.0411
DEBUG - 2022-06-20 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:01:00 --> Total execution time: 0.0741
DEBUG - 2022-06-20 06:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:01:23 --> Total execution time: 0.0532
DEBUG - 2022-06-20 06:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:03:00 --> Total execution time: 0.0697
DEBUG - 2022-06-20 06:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:03:25 --> Total execution time: 0.0658
DEBUG - 2022-06-20 06:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:03:37 --> Total execution time: 0.0628
DEBUG - 2022-06-20 06:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:04:14 --> Total execution time: 0.0517
DEBUG - 2022-06-20 06:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:34:51 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:04:51 --> Total execution time: 0.0610
DEBUG - 2022-06-20 06:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:34:51 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:04:51 --> Total execution time: 0.0483
DEBUG - 2022-06-20 06:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:34:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:04:52 --> Total execution time: 0.0484
DEBUG - 2022-06-20 06:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:34:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:04:52 --> Total execution time: 0.0439
DEBUG - 2022-06-20 06:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:35:49 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:05:49 --> Total execution time: 0.0564
DEBUG - 2022-06-20 06:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:05:59 --> Total execution time: 1.8977
DEBUG - 2022-06-20 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:36:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 06:36:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:09:22 --> Total execution time: 0.0660
DEBUG - 2022-06-20 06:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:09:34 --> Total execution time: 0.0720
DEBUG - 2022-06-20 06:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:09:40 --> Total execution time: 0.1093
DEBUG - 2022-06-20 06:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:41:13 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:11:13 --> Total execution time: 0.0846
DEBUG - 2022-06-20 06:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:11:29 --> Total execution time: 1.4910
DEBUG - 2022-06-20 06:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:11:43 --> Total execution time: 1.4852
DEBUG - 2022-06-20 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:48:58 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:18:58 --> Total execution time: 0.1371
DEBUG - 2022-06-20 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:52:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:22:08 --> Total execution time: 0.0914
DEBUG - 2022-06-20 06:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:22:37 --> Total execution time: 0.1336
DEBUG - 2022-06-20 06:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:22:45 --> Total execution time: 0.0719
DEBUG - 2022-06-20 06:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:22:49 --> Total execution time: 0.0780
DEBUG - 2022-06-20 06:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:53:30 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:23:30 --> Total execution time: 0.0306
DEBUG - 2022-06-20 06:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:23:32 --> Total execution time: 0.0354
DEBUG - 2022-06-20 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:23:34 --> Total execution time: 0.0603
DEBUG - 2022-06-20 06:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:56:35 --> Total execution time: 0.0800
DEBUG - 2022-06-20 06:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:26:40 --> Total execution time: 0.0448
DEBUG - 2022-06-20 06:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:26:51 --> Total execution time: 0.0772
DEBUG - 2022-06-20 06:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:26:53 --> Total execution time: 0.0864
DEBUG - 2022-06-20 06:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:27:09 --> Total execution time: 0.1070
DEBUG - 2022-06-20 06:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:28:00 --> Total execution time: 0.0486
DEBUG - 2022-06-20 06:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:28:27 --> Total execution time: 0.1041
DEBUG - 2022-06-20 06:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:28:28 --> Total execution time: 0.0713
DEBUG - 2022-06-20 06:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:28:33 --> Total execution time: 0.0583
DEBUG - 2022-06-20 06:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:28:46 --> Total execution time: 0.0424
DEBUG - 2022-06-20 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:59:43 --> No URI present. Default controller set.
DEBUG - 2022-06-20 06:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:29:43 --> Total execution time: 0.0379
DEBUG - 2022-06-20 06:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:29:46 --> Total execution time: 0.0363
DEBUG - 2022-06-20 06:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:29:49 --> Total execution time: 0.0453
DEBUG - 2022-06-20 06:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 06:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 06:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 06:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:29:58 --> Total execution time: 0.0499
DEBUG - 2022-06-20 07:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:00 --> Total execution time: 0.0668
DEBUG - 2022-06-20 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:30:03 --> Total execution time: 0.1207
DEBUG - 2022-06-20 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:03 --> Total execution time: 0.1382
DEBUG - 2022-06-20 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:04 --> Total execution time: 0.0458
DEBUG - 2022-06-20 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:05 --> Total execution time: 0.1661
DEBUG - 2022-06-20 07:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:07 --> Total execution time: 0.2715
DEBUG - 2022-06-20 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:11 --> Total execution time: 0.0603
DEBUG - 2022-06-20 07:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:12 --> Total execution time: 0.0461
DEBUG - 2022-06-20 07:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:21 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:21 --> Total execution time: 0.0481
DEBUG - 2022-06-20 07:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:25 --> Total execution time: 0.0572
DEBUG - 2022-06-20 07:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 07:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:27 --> Total execution time: 0.0436
DEBUG - 2022-06-20 07:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 17:30:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 17:30:32 --> Total execution time: 0.1816
DEBUG - 2022-06-20 07:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:46 --> Total execution time: 0.0833
DEBUG - 2022-06-20 07:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:47 --> Total execution time: 0.0703
DEBUG - 2022-06-20 07:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:53 --> Total execution time: 0.0524
DEBUG - 2022-06-20 07:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:06:01 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:36:01 --> Total execution time: 0.2929
DEBUG - 2022-06-20 07:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:38:10 --> Total execution time: 0.0451
DEBUG - 2022-06-20 07:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:39:04 --> Total execution time: 0.1368
DEBUG - 2022-06-20 07:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:39:10 --> Total execution time: 0.0415
DEBUG - 2022-06-20 07:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:13:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:43:20 --> Total execution time: 0.0831
DEBUG - 2022-06-20 07:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:13:56 --> Total execution time: 0.0689
DEBUG - 2022-06-20 07:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:13:58 --> Total execution time: 0.0539
DEBUG - 2022-06-20 07:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:13:58 --> Total execution time: 0.0829
DEBUG - 2022-06-20 07:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:44:11 --> Total execution time: 0.0292
DEBUG - 2022-06-20 07:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:14:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:44:42 --> Total execution time: 1.9352
DEBUG - 2022-06-20 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 07:14:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 07:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:19:04 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:49:04 --> Total execution time: 0.2643
DEBUG - 2022-06-20 07:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:49:33 --> Total execution time: 1.5386
DEBUG - 2022-06-20 07:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:51:17 --> Total execution time: 1.5263
DEBUG - 2022-06-20 07:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:52:36 --> Total execution time: 0.1751
DEBUG - 2022-06-20 07:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:23:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 07:23:09 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 07:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:53:47 --> Total execution time: 1.5468
DEBUG - 2022-06-20 07:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:54:16 --> Total execution time: 0.0536
DEBUG - 2022-06-20 07:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:54:19 --> Total execution time: 0.0478
DEBUG - 2022-06-20 07:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:54:29 --> Total execution time: 0.0685
DEBUG - 2022-06-20 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:25:30 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:55:30 --> Total execution time: 0.0964
DEBUG - 2022-06-20 07:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:55:31 --> Total execution time: 1.6144
DEBUG - 2022-06-20 07:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:25:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 07:25:49 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:56:07 --> Total execution time: 1.5832
DEBUG - 2022-06-20 07:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 07:27:53 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 07:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:29:14 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:59:14 --> Total execution time: 0.0462
DEBUG - 2022-06-20 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 07:34:19 --> 404 Page Not Found: Membership-account/your-profile
DEBUG - 2022-06-20 07:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:36:49 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:06:49 --> Total execution time: 0.1164
DEBUG - 2022-06-20 07:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:06:50 --> Total execution time: 0.0355
DEBUG - 2022-06-20 07:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:36:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:06:53 --> Total execution time: 0.0657
DEBUG - 2022-06-20 07:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:06:56 --> Total execution time: 0.0626
DEBUG - 2022-06-20 07:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:06:57 --> Total execution time: 0.0422
DEBUG - 2022-06-20 07:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:07:14 --> Total execution time: 0.0590
DEBUG - 2022-06-20 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:07:52 --> Total execution time: 0.0394
DEBUG - 2022-06-20 07:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:08:03 --> Total execution time: 0.0548
DEBUG - 2022-06-20 07:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:08:28 --> Total execution time: 0.0891
DEBUG - 2022-06-20 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:08:34 --> Total execution time: 0.0733
DEBUG - 2022-06-20 07:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:08:54 --> Total execution time: 0.0413
DEBUG - 2022-06-20 07:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:44:58 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:14:58 --> Total execution time: 0.1106
DEBUG - 2022-06-20 07:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:15:24 --> Total execution time: 0.0405
DEBUG - 2022-06-20 07:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:15:30 --> Total execution time: 0.0503
DEBUG - 2022-06-20 07:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:15:57 --> Total execution time: 0.0423
DEBUG - 2022-06-20 07:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:16:00 --> Total execution time: 0.0487
DEBUG - 2022-06-20 07:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:16:07 --> Total execution time: 0.0515
DEBUG - 2022-06-20 07:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:16:12 --> Total execution time: 0.0544
DEBUG - 2022-06-20 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:16:19 --> Total execution time: 0.0484
DEBUG - 2022-06-20 07:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:17:11 --> Total execution time: 0.0511
DEBUG - 2022-06-20 07:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:17:36 --> Total execution time: 0.1015
DEBUG - 2022-06-20 07:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:17:36 --> Total execution time: 0.0912
DEBUG - 2022-06-20 07:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:17:55 --> Total execution time: 0.0604
DEBUG - 2022-06-20 07:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:17:59 --> Total execution time: 0.0497
DEBUG - 2022-06-20 07:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:18:08 --> Total execution time: 0.1309
DEBUG - 2022-06-20 07:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:18:32 --> Total execution time: 0.0765
DEBUG - 2022-06-20 07:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:48:36 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:18:36 --> Total execution time: 0.0462
DEBUG - 2022-06-20 07:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:48:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:18:46 --> Total execution time: 0.0320
DEBUG - 2022-06-20 07:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:48:59 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:18:59 --> Total execution time: 0.0479
DEBUG - 2022-06-20 07:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:19:00 --> Total execution time: 0.0513
DEBUG - 2022-06-20 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:49:07 --> No URI present. Default controller set.
DEBUG - 2022-06-20 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:19:07 --> Total execution time: 0.0307
DEBUG - 2022-06-20 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:19:48 --> Total execution time: 0.1250
DEBUG - 2022-06-20 07:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 07:50:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:51:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 07:51:30 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 07:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 07:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 07:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 07:59:56 --> Total execution time: 0.1321
DEBUG - 2022-06-20 08:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:00:00 --> Total execution time: 0.0542
DEBUG - 2022-06-20 08:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:00:01 --> Total execution time: 0.0941
DEBUG - 2022-06-20 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:30:02 --> Total execution time: 0.0567
DEBUG - 2022-06-20 08:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:30:57 --> Total execution time: 0.0360
DEBUG - 2022-06-20 08:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:11:01 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:41:02 --> Total execution time: 0.1338
DEBUG - 2022-06-20 08:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:41:16 --> Total execution time: 0.0326
DEBUG - 2022-06-20 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:41:23 --> Total execution time: 0.0700
DEBUG - 2022-06-20 08:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:14:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:44:08 --> Total execution time: 0.1031
DEBUG - 2022-06-20 08:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:14:11 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:44:11 --> Total execution time: 0.0312
DEBUG - 2022-06-20 08:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:44:20 --> Total execution time: 0.0303
DEBUG - 2022-06-20 08:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:44:35 --> Total execution time: 0.0593
DEBUG - 2022-06-20 08:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:44:43 --> Total execution time: 0.0689
DEBUG - 2022-06-20 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:44:47 --> Total execution time: 0.0677
DEBUG - 2022-06-20 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:44:55 --> Total execution time: 0.0445
DEBUG - 2022-06-20 08:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:16:55 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:46:55 --> Total execution time: 0.0311
DEBUG - 2022-06-20 08:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:46:59 --> Total execution time: 0.0394
DEBUG - 2022-06-20 08:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:47:05 --> Total execution time: 0.0569
DEBUG - 2022-06-20 08:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:47:13 --> Total execution time: 0.0815
DEBUG - 2022-06-20 08:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:17:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:47:16 --> Total execution time: 0.0392
DEBUG - 2022-06-20 08:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:18:25 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:48:25 --> Total execution time: 0.0987
DEBUG - 2022-06-20 08:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:26:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:56:20 --> Total execution time: 0.1141
DEBUG - 2022-06-20 08:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:27:38 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:57:38 --> Total execution time: 0.0440
DEBUG - 2022-06-20 08:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:27:39 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:57:40 --> Total execution time: 0.0562
DEBUG - 2022-06-20 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:57:45 --> Total execution time: 0.0483
DEBUG - 2022-06-20 08:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:57:53 --> Total execution time: 0.0507
DEBUG - 2022-06-20 08:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:58:00 --> Total execution time: 0.1020
DEBUG - 2022-06-20 08:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:59:49 --> Total execution time: 0.0450
DEBUG - 2022-06-20 08:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:59:55 --> Total execution time: 0.0415
DEBUG - 2022-06-20 08:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:00:02 --> Total execution time: 0.0423
DEBUG - 2022-06-20 08:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:00:18 --> Total execution time: 0.1237
DEBUG - 2022-06-20 08:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:00:41 --> Total execution time: 0.0822
DEBUG - 2022-06-20 08:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:00:53 --> Total execution time: 0.0482
DEBUG - 2022-06-20 08:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:01:02 --> Total execution time: 0.0459
DEBUG - 2022-06-20 08:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:01:09 --> Total execution time: 0.0471
DEBUG - 2022-06-20 08:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:35:05 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 08:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:35:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:35:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 08:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:06:13 --> Total execution time: 0.1630
DEBUG - 2022-06-20 08:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:06:52 --> Total execution time: 0.1422
DEBUG - 2022-06-20 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:09:52 --> Total execution time: 0.0928
DEBUG - 2022-06-20 08:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:40:38 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:10:38 --> Total execution time: 0.1115
DEBUG - 2022-06-20 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:10:42 --> Total execution time: 0.0407
DEBUG - 2022-06-20 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:10:49 --> Total execution time: 0.0646
DEBUG - 2022-06-20 08:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:10:56 --> Total execution time: 0.0373
DEBUG - 2022-06-20 08:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:10:58 --> Total execution time: 0.0376
DEBUG - 2022-06-20 08:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:11:02 --> Total execution time: 0.0332
DEBUG - 2022-06-20 08:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:11:33 --> Total execution time: 0.0334
DEBUG - 2022-06-20 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:49:56 --> 404 Page Not Found: Affiliate-account-page/index
ERROR - 2022-06-20 08:49:56 --> 404 Page Not Found: Cart/index
DEBUG - 2022-06-20 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:49:56 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-20 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:57 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:49:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:49:57 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:19:57 --> Total execution time: 0.0959
DEBUG - 2022-06-20 19:19:57 --> Total execution time: 0.0965
DEBUG - 2022-06-20 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:19:57 --> Total execution time: 0.0434
DEBUG - 2022-06-20 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:49:57 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:49:57 --> No URI present. Default controller set.
DEBUG - 2022-06-20 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:19:57 --> Total execution time: 0.0561
DEBUG - 2022-06-20 08:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:19:57 --> Total execution time: 0.0445
DEBUG - 2022-06-20 08:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:50:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 08:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:50:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 08:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:50:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 08:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:50:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 08:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 08:50:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 08:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:20:33 --> Total execution time: 0.0452
DEBUG - 2022-06-20 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:20:42 --> Total execution time: 0.0420
DEBUG - 2022-06-20 08:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:20:46 --> Total execution time: 0.0729
DEBUG - 2022-06-20 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 08:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:21:21 --> Total execution time: 0.0487
DEBUG - 2022-06-20 08:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 08:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 08:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:21:31 --> Total execution time: 0.0694
DEBUG - 2022-06-20 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:30:02 --> Total execution time: 0.1887
DEBUG - 2022-06-20 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:00:54 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:30:54 --> Total execution time: 0.0364
DEBUG - 2022-06-20 09:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:30:57 --> Total execution time: 0.0385
DEBUG - 2022-06-20 09:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:01:06 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:31:06 --> Total execution time: 0.0505
DEBUG - 2022-06-20 09:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:31:08 --> Total execution time: 0.0409
DEBUG - 2022-06-20 09:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:31:16 --> Total execution time: 0.0685
DEBUG - 2022-06-20 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:31:21 --> Total execution time: 0.0487
DEBUG - 2022-06-20 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:31:26 --> Total execution time: 0.0541
DEBUG - 2022-06-20 09:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:32:00 --> Total execution time: 0.0383
DEBUG - 2022-06-20 09:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:32:07 --> Total execution time: 0.0502
DEBUG - 2022-06-20 09:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:32:07 --> Total execution time: 0.0471
DEBUG - 2022-06-20 09:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:02:09 --> Total execution time: 0.0492
DEBUG - 2022-06-20 09:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:32:13 --> Total execution time: 0.0449
DEBUG - 2022-06-20 09:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:32:20 --> Total execution time: 0.0481
DEBUG - 2022-06-20 09:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:32:25 --> Total execution time: 0.0954
DEBUG - 2022-06-20 09:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:02:29 --> Total execution time: 0.0559
DEBUG - 2022-06-20 09:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:02:31 --> Total execution time: 0.0736
DEBUG - 2022-06-20 09:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:02:31 --> Total execution time: 0.1445
DEBUG - 2022-06-20 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:32:44 --> Total execution time: 0.0490
DEBUG - 2022-06-20 09:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:32:46 --> Total execution time: 0.0432
DEBUG - 2022-06-20 09:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:03:21 --> Total execution time: 0.0507
DEBUG - 2022-06-20 09:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:03:22 --> Total execution time: 0.0485
DEBUG - 2022-06-20 09:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:03:22 --> Total execution time: 0.0933
DEBUG - 2022-06-20 09:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:03:39 --> Total execution time: 0.0401
DEBUG - 2022-06-20 09:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:33:45 --> Total execution time: 0.0445
DEBUG - 2022-06-20 09:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:33:49 --> Total execution time: 0.0687
DEBUG - 2022-06-20 09:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:33:50 --> Total execution time: 0.0690
DEBUG - 2022-06-20 09:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:34:02 --> Total execution time: 0.0775
DEBUG - 2022-06-20 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:34:15 --> Total execution time: 0.0816
DEBUG - 2022-06-20 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:34:38 --> Total execution time: 0.0798
DEBUG - 2022-06-20 09:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:34:43 --> Total execution time: 0.0499
DEBUG - 2022-06-20 09:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:34:44 --> Total execution time: 0.0459
DEBUG - 2022-06-20 09:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:04:45 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:34:45 --> Total execution time: 0.0312
DEBUG - 2022-06-20 09:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:34:56 --> Total execution time: 0.0745
DEBUG - 2022-06-20 09:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:03 --> Total execution time: 0.0725
DEBUG - 2022-06-20 09:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:05 --> Total execution time: 0.0875
DEBUG - 2022-06-20 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:09 --> Total execution time: 0.0575
DEBUG - 2022-06-20 09:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:12 --> Total execution time: 0.0498
DEBUG - 2022-06-20 09:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:12 --> Total execution time: 0.0452
DEBUG - 2022-06-20 09:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:13 --> Total execution time: 0.0599
DEBUG - 2022-06-20 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:21 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:21 --> Total execution time: 0.0480
DEBUG - 2022-06-20 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:21 --> Total execution time: 0.0623
DEBUG - 2022-06-20 09:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:31 --> Total execution time: 0.0637
DEBUG - 2022-06-20 09:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:48 --> Total execution time: 0.0674
DEBUG - 2022-06-20 09:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:49 --> Total execution time: 0.0991
DEBUG - 2022-06-20 09:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:35:54 --> Total execution time: 0.0904
DEBUG - 2022-06-20 09:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:01 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:01 --> Total execution time: 0.1364
DEBUG - 2022-06-20 09:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:12 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:12 --> Total execution time: 0.0320
DEBUG - 2022-06-20 09:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:06:13 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 09:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:13 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:13 --> Total execution time: 0.0295
DEBUG - 2022-06-20 09:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:06:14 --> Total execution time: 0.0398
DEBUG - 2022-06-20 09:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:06:16 --> Total execution time: 0.0418
DEBUG - 2022-06-20 09:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:06:16 --> Total execution time: 0.0889
DEBUG - 2022-06-20 09:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:19 --> Total execution time: 0.0291
DEBUG - 2022-06-20 09:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:29 --> Total execution time: 0.0540
DEBUG - 2022-06-20 09:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:36 --> Total execution time: 0.0809
DEBUG - 2022-06-20 09:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:45 --> Total execution time: 0.0559
DEBUG - 2022-06-20 09:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:07:21 --> Total execution time: 0.0483
DEBUG - 2022-06-20 09:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:07:23 --> Total execution time: 0.0646
DEBUG - 2022-06-20 09:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:07:23 --> Total execution time: 0.1279
DEBUG - 2022-06-20 09:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:08:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:08:44 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 09:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:10:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:10:54 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 09:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:11:54 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:41:54 --> Total execution time: 0.0711
DEBUG - 2022-06-20 09:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:13:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:43:22 --> Total execution time: 0.0309
DEBUG - 2022-06-20 09:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:43:27 --> Total execution time: 0.0286
DEBUG - 2022-06-20 09:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:43:37 --> Total execution time: 0.0344
DEBUG - 2022-06-20 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:43:48 --> Total execution time: 0.0401
DEBUG - 2022-06-20 09:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:43:55 --> Total execution time: 0.0478
DEBUG - 2022-06-20 09:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:43:55 --> Total execution time: 0.0277
DEBUG - 2022-06-20 09:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:44:01 --> Total execution time: 0.0648
DEBUG - 2022-06-20 09:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:44:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 09:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:44:02 --> Total execution time: 0.0455
DEBUG - 2022-06-20 09:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:45:31 --> Total execution time: 0.0635
DEBUG - 2022-06-20 09:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:45:34 --> Total execution time: 0.0403
DEBUG - 2022-06-20 09:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:45:42 --> Total execution time: 0.0502
DEBUG - 2022-06-20 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:45:47 --> Total execution time: 0.1263
DEBUG - 2022-06-20 09:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:45:55 --> Total execution time: 0.0785
DEBUG - 2022-06-20 09:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:46:06 --> Total execution time: 0.1433
DEBUG - 2022-06-20 09:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:46:07 --> Total execution time: 0.0681
DEBUG - 2022-06-20 09:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:46:36 --> Total execution time: 0.0484
DEBUG - 2022-06-20 09:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:46:40 --> Total execution time: 0.0598
DEBUG - 2022-06-20 09:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:46:40 --> Total execution time: 0.0515
DEBUG - 2022-06-20 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:46:43 --> Total execution time: 0.0753
DEBUG - 2022-06-20 09:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:46:47 --> Total execution time: 0.0494
DEBUG - 2022-06-20 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:46:50 --> Total execution time: 0.0513
DEBUG - 2022-06-20 09:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:16:57 --> Total execution time: 0.0442
DEBUG - 2022-06-20 09:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:46:59 --> Total execution time: 0.0525
DEBUG - 2022-06-20 09:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:47:06 --> Total execution time: 0.0640
DEBUG - 2022-06-20 09:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:47:19 --> Total execution time: 0.0672
DEBUG - 2022-06-20 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:47:33 --> Total execution time: 0.0490
DEBUG - 2022-06-20 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:47:33 --> Total execution time: 0.0693
DEBUG - 2022-06-20 09:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:47:36 --> Total execution time: 0.0686
DEBUG - 2022-06-20 09:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:47:45 --> Total execution time: 0.0733
DEBUG - 2022-06-20 09:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:47:50 --> Total execution time: 0.0597
DEBUG - 2022-06-20 09:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:47:52 --> Total execution time: 0.0715
DEBUG - 2022-06-20 09:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:18:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:48:26 --> Total execution time: 0.0374
DEBUG - 2022-06-20 09:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:18:29 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:48:29 --> Total execution time: 0.0464
DEBUG - 2022-06-20 09:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:18:33 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:48:33 --> Total execution time: 0.1117
DEBUG - 2022-06-20 09:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:18:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 09:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:48:51 --> Total execution time: 1.8806
DEBUG - 2022-06-20 09:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:18:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 09:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:05 --> Total execution time: 0.0646
DEBUG - 2022-06-20 09:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:06 --> Total execution time: 0.0981
DEBUG - 2022-06-20 09:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:13 --> Total execution time: 0.0699
DEBUG - 2022-06-20 09:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:25 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:25 --> Total execution time: 0.0364
DEBUG - 2022-06-20 09:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:34 --> Total execution time: 0.0547
DEBUG - 2022-06-20 09:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:35 --> Total execution time: 0.0547
DEBUG - 2022-06-20 09:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:37 --> Total execution time: 0.0473
DEBUG - 2022-06-20 09:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:38 --> Total execution time: 0.0498
DEBUG - 2022-06-20 09:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 09:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:41 --> Total execution time: 0.0443
DEBUG - 2022-06-20 09:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:49:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 19:49:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 19:49:42 --> Total execution time: 0.1806
DEBUG - 2022-06-20 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:20:15 --> Total execution time: 0.0325
DEBUG - 2022-06-20 09:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:20:17 --> Total execution time: 0.0476
DEBUG - 2022-06-20 09:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:20:17 --> Total execution time: 0.0758
DEBUG - 2022-06-20 09:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:50:34 --> Total execution time: 0.0916
DEBUG - 2022-06-20 09:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:50:37 --> Total execution time: 0.0438
DEBUG - 2022-06-20 09:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:50:42 --> Total execution time: 0.0379
DEBUG - 2022-06-20 09:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:50:56 --> Total execution time: 0.0472
DEBUG - 2022-06-20 09:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:50:57 --> Total execution time: 0.0519
DEBUG - 2022-06-20 09:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:06 --> Total execution time: 0.0470
DEBUG - 2022-06-20 09:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:07 --> Total execution time: 0.0578
DEBUG - 2022-06-20 09:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:13 --> Total execution time: 0.0488
DEBUG - 2022-06-20 09:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:16 --> Total execution time: 0.0822
DEBUG - 2022-06-20 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:22 --> Total execution time: 0.0593
DEBUG - 2022-06-20 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:22 --> Total execution time: 0.0429
DEBUG - 2022-06-20 09:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:23 --> Total execution time: 0.0720
DEBUG - 2022-06-20 09:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:34 --> Total execution time: 0.0390
DEBUG - 2022-06-20 09:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:22:27 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:27 --> Total execution time: 0.0324
DEBUG - 2022-06-20 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:24:58 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:54:58 --> Total execution time: 0.0816
DEBUG - 2022-06-20 09:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:25:10 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 09:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:26:44 --> 404 Page Not Found: Cart/index
DEBUG - 2022-06-20 09:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:26:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 09:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:27:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:27:04 --> 404 Page Not Found: Cart/index
DEBUG - 2022-06-20 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:57:29 --> Total execution time: 0.0468
DEBUG - 2022-06-20 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:27:30 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:57:30 --> Total execution time: 0.0331
DEBUG - 2022-06-20 09:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:27:34 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:57:34 --> Total execution time: 0.0454
DEBUG - 2022-06-20 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:58:03 --> Total execution time: 0.0419
DEBUG - 2022-06-20 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:58:18 --> Total execution time: 0.0494
DEBUG - 2022-06-20 09:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:58:29 --> Total execution time: 0.0464
DEBUG - 2022-06-20 09:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:58:33 --> Total execution time: 0.0812
DEBUG - 2022-06-20 09:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:58:41 --> Total execution time: 0.0480
DEBUG - 2022-06-20 09:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:58:54 --> Total execution time: 0.0432
DEBUG - 2022-06-20 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:59:32 --> Total execution time: 0.0434
DEBUG - 2022-06-20 09:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:59:36 --> Total execution time: 0.0493
DEBUG - 2022-06-20 09:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:59:39 --> Total execution time: 0.0593
DEBUG - 2022-06-20 09:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:31:28 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:01:28 --> Total execution time: 0.0315
DEBUG - 2022-06-20 09:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:02:03 --> Total execution time: 0.0304
DEBUG - 2022-06-20 09:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:19 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:19 --> Total execution time: 0.0330
DEBUG - 2022-06-20 09:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:29 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:29 --> Total execution time: 0.1000
DEBUG - 2022-06-20 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:34 --> Total execution time: 0.0449
DEBUG - 2022-06-20 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:34 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:34 --> Total execution time: 0.0390
DEBUG - 2022-06-20 09:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:35 --> Total execution time: 0.0430
DEBUG - 2022-06-20 09:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:36 --> Total execution time: 0.0403
DEBUG - 2022-06-20 09:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:37 --> Total execution time: 0.0464
DEBUG - 2022-06-20 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:49 --> Total execution time: 0.0721
DEBUG - 2022-06-20 09:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:57 --> Total execution time: 0.0489
DEBUG - 2022-06-20 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:34:04 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:04:04 --> Total execution time: 0.0442
DEBUG - 2022-06-20 20:04:04 --> Total execution time: 0.0429
DEBUG - 2022-06-20 09:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:04:07 --> Total execution time: 0.0514
DEBUG - 2022-06-20 09:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:04:09 --> Total execution time: 0.0607
DEBUG - 2022-06-20 09:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:04:12 --> Total execution time: 0.0619
DEBUG - 2022-06-20 09:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:04:31 --> Total execution time: 0.0802
DEBUG - 2022-06-20 09:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:04:37 --> Total execution time: 0.0716
DEBUG - 2022-06-20 09:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:05:20 --> Total execution time: 0.1257
DEBUG - 2022-06-20 09:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:05:56 --> Total execution time: 0.0579
DEBUG - 2022-06-20 09:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:06:20 --> Total execution time: 0.0925
DEBUG - 2022-06-20 09:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:06:29 --> Total execution time: 0.0520
DEBUG - 2022-06-20 09:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:07:01 --> Total execution time: 0.0768
DEBUG - 2022-06-20 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:07:08 --> Total execution time: 0.0822
DEBUG - 2022-06-20 09:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:07:19 --> Total execution time: 0.0485
DEBUG - 2022-06-20 09:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:07:23 --> Total execution time: 0.0486
DEBUG - 2022-06-20 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:08:54 --> Total execution time: 0.0845
DEBUG - 2022-06-20 09:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:08:55 --> Total execution time: 0.0494
DEBUG - 2022-06-20 09:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:09:13 --> Total execution time: 0.0560
DEBUG - 2022-06-20 09:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:09:23 --> Total execution time: 0.1233
DEBUG - 2022-06-20 09:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:09:26 --> Total execution time: 0.1116
DEBUG - 2022-06-20 09:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:09:30 --> Total execution time: 0.0587
DEBUG - 2022-06-20 09:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:09:38 --> Total execution time: 0.0549
DEBUG - 2022-06-20 09:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 09:39:44 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:09:46 --> Total execution time: 0.0436
DEBUG - 2022-06-20 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:10:32 --> Total execution time: 0.0477
DEBUG - 2022-06-20 09:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:23 --> Total execution time: 0.0449
DEBUG - 2022-06-20 09:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:44 --> Total execution time: 0.0676
DEBUG - 2022-06-20 09:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:52 --> Total execution time: 0.0412
DEBUG - 2022-06-20 09:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:42:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:12:26 --> Total execution time: 0.0343
DEBUG - 2022-06-20 09:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:42:56 --> Total execution time: 0.0456
DEBUG - 2022-06-20 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:42:58 --> Total execution time: 0.0707
DEBUG - 2022-06-20 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:42:58 --> Total execution time: 0.1037
DEBUG - 2022-06-20 09:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:43:12 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:13:12 --> Total execution time: 0.0547
DEBUG - 2022-06-20 09:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:13:14 --> Total execution time: 0.0442
DEBUG - 2022-06-20 09:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:13:31 --> Total execution time: 0.0464
DEBUG - 2022-06-20 09:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:13:48 --> Total execution time: 0.0461
DEBUG - 2022-06-20 09:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:13:59 --> Total execution time: 0.0681
DEBUG - 2022-06-20 09:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:23 --> Total execution time: 0.0399
DEBUG - 2022-06-20 09:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:38 --> Total execution time: 0.0975
DEBUG - 2022-06-20 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:56 --> Total execution time: 0.0393
DEBUG - 2022-06-20 09:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:15:02 --> Total execution time: 0.0593
DEBUG - 2022-06-20 09:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:15:12 --> Total execution time: 0.0497
DEBUG - 2022-06-20 09:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:15:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 09:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:15:14 --> Total execution time: 0.0424
DEBUG - 2022-06-20 09:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:16:23 --> Total execution time: 0.0400
DEBUG - 2022-06-20 09:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:16:25 --> Total execution time: 0.0750
DEBUG - 2022-06-20 09:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:16:35 --> Total execution time: 0.0466
DEBUG - 2022-06-20 09:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:16:52 --> Total execution time: 0.0544
DEBUG - 2022-06-20 09:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:16:57 --> Total execution time: 0.0575
DEBUG - 2022-06-20 09:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:17:05 --> Total execution time: 0.0506
DEBUG - 2022-06-20 09:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:17:09 --> Total execution time: 0.0570
DEBUG - 2022-06-20 09:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:47:17 --> Total execution time: 0.0416
DEBUG - 2022-06-20 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:47:17 --> Total execution time: 0.0393
DEBUG - 2022-06-20 09:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:47:33 --> Total execution time: 0.0544
DEBUG - 2022-06-20 09:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:47:37 --> Total execution time: 0.0398
DEBUG - 2022-06-20 09:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:47:39 --> Total execution time: 0.0554
DEBUG - 2022-06-20 09:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:17:42 --> Total execution time: 0.0474
DEBUG - 2022-06-20 09:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:17:47 --> Total execution time: 0.0507
DEBUG - 2022-06-20 09:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:18:02 --> Total execution time: 0.1640
DEBUG - 2022-06-20 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:48:09 --> Total execution time: 0.0556
DEBUG - 2022-06-20 09:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:48:17 --> Total execution time: 0.0617
DEBUG - 2022-06-20 09:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:19:25 --> Total execution time: 0.0804
DEBUG - 2022-06-20 09:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:19:28 --> Total execution time: 0.0711
DEBUG - 2022-06-20 09:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:19:29 --> Total execution time: 0.0497
DEBUG - 2022-06-20 09:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:19:32 --> Total execution time: 0.0495
DEBUG - 2022-06-20 09:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:19:36 --> Total execution time: 0.0384
DEBUG - 2022-06-20 09:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:19:42 --> Total execution time: 0.0843
DEBUG - 2022-06-20 09:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:50:01 --> Total execution time: 0.0634
DEBUG - 2022-06-20 09:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:50:17 --> Total execution time: 0.0439
DEBUG - 2022-06-20 09:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:50:22 --> Total execution time: 0.0401
DEBUG - 2022-06-20 09:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:20:23 --> Total execution time: 0.0664
DEBUG - 2022-06-20 09:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:20:26 --> Total execution time: 0.0435
DEBUG - 2022-06-20 09:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:20:29 --> Total execution time: 0.0466
DEBUG - 2022-06-20 09:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:20:39 --> Total execution time: 0.0539
DEBUG - 2022-06-20 09:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:20:54 --> Total execution time: 0.0442
DEBUG - 2022-06-20 09:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:20:59 --> Total execution time: 0.1489
DEBUG - 2022-06-20 09:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:21:01 --> Total execution time: 0.0648
DEBUG - 2022-06-20 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:51:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:21:46 --> Total execution time: 0.0333
DEBUG - 2022-06-20 09:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:22:09 --> Total execution time: 0.0510
DEBUG - 2022-06-20 09:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:22:27 --> Total execution time: 0.0541
DEBUG - 2022-06-20 09:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:22:27 --> Total execution time: 0.0447
DEBUG - 2022-06-20 09:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:53:12 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:23:12 --> Total execution time: 0.0330
DEBUG - 2022-06-20 09:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:23:51 --> Total execution time: 0.0534
DEBUG - 2022-06-20 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:24:01 --> Total execution time: 0.0512
DEBUG - 2022-06-20 09:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:24:08 --> Total execution time: 0.0560
DEBUG - 2022-06-20 09:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:24:18 --> Total execution time: 0.0528
DEBUG - 2022-06-20 09:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:24:44 --> Total execution time: 0.0428
DEBUG - 2022-06-20 09:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:58:38 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:28:38 --> Total execution time: 0.0857
DEBUG - 2022-06-20 09:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:28:49 --> Total execution time: 0.0402
DEBUG - 2022-06-20 09:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:58:58 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:28:58 --> Total execution time: 0.0461
DEBUG - 2022-06-20 09:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:59:10 --> Total execution time: 0.0437
DEBUG - 2022-06-20 09:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:59:11 --> Total execution time: 0.0553
DEBUG - 2022-06-20 09:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 09:59:11 --> Total execution time: 0.0899
DEBUG - 2022-06-20 09:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:59:49 --> No URI present. Default controller set.
DEBUG - 2022-06-20 09:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:29:49 --> Total execution time: 0.0442
DEBUG - 2022-06-20 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 09:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:29:54 --> Total execution time: 0.0416
DEBUG - 2022-06-20 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:30:02 --> Total execution time: 0.0434
DEBUG - 2022-06-20 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:00:03 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:30:03 --> Total execution time: 0.0566
DEBUG - 2022-06-20 10:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:00:07 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:30:07 --> Total execution time: 0.1156
DEBUG - 2022-06-20 10:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:30:20 --> Total execution time: 0.0409
DEBUG - 2022-06-20 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:30:28 --> Total execution time: 0.0530
DEBUG - 2022-06-20 10:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:30:38 --> Total execution time: 0.0742
DEBUG - 2022-06-20 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:30:45 --> Total execution time: 0.0957
DEBUG - 2022-06-20 10:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:31:19 --> Total execution time: 0.0555
DEBUG - 2022-06-20 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:01:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:31:22 --> Total execution time: 0.0365
DEBUG - 2022-06-20 10:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:31:34 --> Total execution time: 0.0281
DEBUG - 2022-06-20 10:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:31:41 --> Total execution time: 0.0496
DEBUG - 2022-06-20 10:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:31:50 --> Total execution time: 0.0430
DEBUG - 2022-06-20 10:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:32:06 --> Total execution time: 0.0735
DEBUG - 2022-06-20 10:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 10:02:15 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 10:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:32:19 --> Total execution time: 0.0696
DEBUG - 2022-06-20 10:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:04:14 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:34:14 --> Total execution time: 0.1253
DEBUG - 2022-06-20 10:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:34:19 --> Total execution time: 0.0521
DEBUG - 2022-06-20 10:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:34:23 --> Total execution time: 0.0820
DEBUG - 2022-06-20 10:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:34:34 --> Total execution time: 0.0536
DEBUG - 2022-06-20 10:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:04:36 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:34:36 --> Total execution time: 0.0459
DEBUG - 2022-06-20 10:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:35:17 --> Total execution time: 0.0433
DEBUG - 2022-06-20 10:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:35:20 --> Total execution time: 0.0614
DEBUG - 2022-06-20 10:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:35:26 --> Total execution time: 0.0459
DEBUG - 2022-06-20 10:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:35:32 --> Total execution time: 0.0517
DEBUG - 2022-06-20 10:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:35:41 --> Total execution time: 0.0405
DEBUG - 2022-06-20 10:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:35:45 --> Total execution time: 0.0559
DEBUG - 2022-06-20 10:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:35:54 --> Total execution time: 0.0450
DEBUG - 2022-06-20 10:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:35:59 --> Total execution time: 0.0537
DEBUG - 2022-06-20 10:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:36:07 --> Total execution time: 0.0468
DEBUG - 2022-06-20 10:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:36:14 --> Total execution time: 0.0341
DEBUG - 2022-06-20 10:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:36:23 --> Total execution time: 0.0491
DEBUG - 2022-06-20 10:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:36:26 --> Total execution time: 0.0625
DEBUG - 2022-06-20 10:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:17:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:47:09 --> Total execution time: 0.0860
DEBUG - 2022-06-20 10:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:47:33 --> Total execution time: 0.0443
DEBUG - 2022-06-20 10:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:47:57 --> Total execution time: 0.0393
DEBUG - 2022-06-20 10:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:48:05 --> Total execution time: 0.0659
DEBUG - 2022-06-20 10:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:48:11 --> Total execution time: 0.1164
DEBUG - 2022-06-20 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:50:10 --> Total execution time: 0.0446
DEBUG - 2022-06-20 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:50:44 --> Total execution time: 0.0446
DEBUG - 2022-06-20 10:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:51:33 --> Total execution time: 0.0651
DEBUG - 2022-06-20 10:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:53:36 --> Total execution time: 0.0299
DEBUG - 2022-06-20 10:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:25:17 --> Total execution time: 0.0476
DEBUG - 2022-06-20 10:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:25:20 --> Total execution time: 0.0484
DEBUG - 2022-06-20 10:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:25:20 --> Total execution time: 0.1085
DEBUG - 2022-06-20 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:00:06 --> Total execution time: 0.1732
DEBUG - 2022-06-20 10:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:00:18 --> Total execution time: 0.0458
DEBUG - 2022-06-20 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:02:02 --> Total execution time: 0.0441
DEBUG - 2022-06-20 10:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:02:23 --> Total execution time: 0.0456
DEBUG - 2022-06-20 10:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:02:35 --> Total execution time: 0.0517
DEBUG - 2022-06-20 10:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:02:55 --> Total execution time: 0.0517
DEBUG - 2022-06-20 10:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:04:50 --> Total execution time: 0.0548
DEBUG - 2022-06-20 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:13 --> Total execution time: 0.0628
DEBUG - 2022-06-20 10:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:35:24 --> Total execution time: 0.0853
DEBUG - 2022-06-20 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:06:39 --> Total execution time: 0.0813
DEBUG - 2022-06-20 10:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:37:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:07:16 --> Total execution time: 0.0347
DEBUG - 2022-06-20 10:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:34 --> Total execution time: 0.0705
DEBUG - 2022-06-20 10:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:47 --> Total execution time: 0.0432
DEBUG - 2022-06-20 10:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:38:50 --> Total execution time: 0.0601
DEBUG - 2022-06-20 10:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:39:11 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:09:11 --> Total execution time: 0.0325
DEBUG - 2022-06-20 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:09:42 --> Total execution time: 0.0724
DEBUG - 2022-06-20 10:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:14 --> Total execution time: 0.0700
DEBUG - 2022-06-20 10:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:57 --> Total execution time: 0.0714
DEBUG - 2022-06-20 10:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:11:09 --> Total execution time: 0.0621
DEBUG - 2022-06-20 10:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:11:27 --> Total execution time: 0.0444
DEBUG - 2022-06-20 10:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:42 --> Total execution time: 0.0359
DEBUG - 2022-06-20 10:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:45 --> Total execution time: 0.0428
DEBUG - 2022-06-20 10:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:41:45 --> Total execution time: 0.0893
DEBUG - 2022-06-20 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:44:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:14:08 --> Total execution time: 0.0877
DEBUG - 2022-06-20 10:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:14:18 --> Total execution time: 0.0367
DEBUG - 2022-06-20 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:14:58 --> Total execution time: 0.0658
DEBUG - 2022-06-20 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:15:00 --> Total execution time: 0.0479
DEBUG - 2022-06-20 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:15:01 --> Total execution time: 0.0531
DEBUG - 2022-06-20 10:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:15:21 --> Total execution time: 0.0414
DEBUG - 2022-06-20 10:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:15:25 --> Total execution time: 0.0453
DEBUG - 2022-06-20 10:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:34 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:15:34 --> Total execution time: 0.0384
DEBUG - 2022-06-20 10:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:15:50 --> Total execution time: 0.0396
DEBUG - 2022-06-20 10:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:00 --> Total execution time: 0.0442
DEBUG - 2022-06-20 10:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:02 --> Total execution time: 0.0397
DEBUG - 2022-06-20 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:14 --> Total execution time: 0.0503
DEBUG - 2022-06-20 10:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:16 --> Total execution time: 0.0537
DEBUG - 2022-06-20 10:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:19 --> Total execution time: 0.0407
DEBUG - 2022-06-20 10:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:22 --> Total execution time: 0.0610
DEBUG - 2022-06-20 10:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:25 --> Total execution time: 0.0837
DEBUG - 2022-06-20 10:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:30 --> Total execution time: 0.0430
DEBUG - 2022-06-20 10:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:35 --> Total execution time: 0.0551
DEBUG - 2022-06-20 10:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:50 --> Total execution time: 0.0457
DEBUG - 2022-06-20 10:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:51 --> Total execution time: 0.0488
DEBUG - 2022-06-20 10:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:54 --> Total execution time: 0.0456
DEBUG - 2022-06-20 10:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:58 --> Total execution time: 0.0892
DEBUG - 2022-06-20 10:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:09 --> Total execution time: 0.0585
DEBUG - 2022-06-20 10:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:09 --> Total execution time: 0.0371
DEBUG - 2022-06-20 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:24 --> Total execution time: 0.0468
DEBUG - 2022-06-20 10:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:34 --> Total execution time: 0.0481
DEBUG - 2022-06-20 10:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:36 --> Total execution time: 0.0436
DEBUG - 2022-06-20 10:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:38 --> Total execution time: 0.0459
DEBUG - 2022-06-20 10:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:42 --> Total execution time: 0.0715
DEBUG - 2022-06-20 10:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:58 --> Total execution time: 0.0455
DEBUG - 2022-06-20 10:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:00 --> Total execution time: 0.0592
DEBUG - 2022-06-20 10:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:16 --> Total execution time: 0.0552
DEBUG - 2022-06-20 10:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:17 --> Total execution time: 0.0399
DEBUG - 2022-06-20 10:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:21 --> Total execution time: 0.0580
DEBUG - 2022-06-20 10:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:23 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:23 --> Total execution time: 0.0610
DEBUG - 2022-06-20 10:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:24 --> Total execution time: 0.0496
DEBUG - 2022-06-20 10:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:25 --> Total execution time: 0.0403
DEBUG - 2022-06-20 10:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:27 --> Total execution time: 0.0400
DEBUG - 2022-06-20 10:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:28 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:28 --> Total execution time: 0.0535
DEBUG - 2022-06-20 10:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:33 --> Total execution time: 0.0514
DEBUG - 2022-06-20 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:49:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:19:08 --> Total execution time: 0.0514
DEBUG - 2022-06-20 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:49:18 --> Total execution time: 0.0463
DEBUG - 2022-06-20 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:49:20 --> Total execution time: 0.0504
DEBUG - 2022-06-20 10:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:49:20 --> Total execution time: 0.1174
DEBUG - 2022-06-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:51:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:21:14 --> Total execution time: 1.9184
DEBUG - 2022-06-20 10:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:51:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 10:51:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:21:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 10:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:21:56 --> Total execution time: 0.0492
DEBUG - 2022-06-20 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:21:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 21:21:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 21:21:57 --> Total execution time: 0.1871
DEBUG - 2022-06-20 10:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:22:11 --> Total execution time: 0.0462
DEBUG - 2022-06-20 10:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:22:40 --> Total execution time: 0.0463
DEBUG - 2022-06-20 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:22:47 --> Total execution time: 0.0497
DEBUG - 2022-06-20 10:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:23:07 --> Total execution time: 0.0677
DEBUG - 2022-06-20 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:23:55 --> Total execution time: 0.0472
DEBUG - 2022-06-20 10:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:24:00 --> Total execution time: 0.0408
DEBUG - 2022-06-20 10:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:24:05 --> Total execution time: 0.0446
DEBUG - 2022-06-20 10:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:24:17 --> Total execution time: 0.0607
DEBUG - 2022-06-20 10:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:24:26 --> Total execution time: 0.0362
DEBUG - 2022-06-20 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:24:30 --> Total execution time: 0.0626
DEBUG - 2022-06-20 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:24:31 --> Total execution time: 0.0583
DEBUG - 2022-06-20 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:24:31 --> Total execution time: 0.0689
DEBUG - 2022-06-20 10:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 10:54:34 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 10:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:24:56 --> Total execution time: 0.0320
DEBUG - 2022-06-20 10:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:55:17 --> Total execution time: 0.0472
DEBUG - 2022-06-20 10:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:55:19 --> Total execution time: 0.0431
DEBUG - 2022-06-20 10:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 10:55:19 --> Total execution time: 0.1132
DEBUG - 2022-06-20 10:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:55:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:25:26 --> Total execution time: 0.0320
DEBUG - 2022-06-20 10:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:25:31 --> Total execution time: 0.0393
DEBUG - 2022-06-20 10:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:56:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:26:00 --> Total execution time: 0.0380
DEBUG - 2022-06-20 10:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:56:01 --> No URI present. Default controller set.
DEBUG - 2022-06-20 10:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:26:01 --> Total execution time: 0.0728
DEBUG - 2022-06-20 10:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 10:57:02 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:27:23 --> Total execution time: 0.1060
DEBUG - 2022-06-20 10:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:59:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 10:59:09 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:29:21 --> Total execution time: 0.0282
DEBUG - 2022-06-20 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 10:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 10:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:29:53 --> Total execution time: 0.1190
DEBUG - 2022-06-20 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:30:02 --> Total execution time: 0.0605
DEBUG - 2022-06-20 11:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:30:28 --> Total execution time: 0.0468
DEBUG - 2022-06-20 11:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:00:44 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:30:44 --> Total execution time: 0.0354
DEBUG - 2022-06-20 11:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:33:15 --> Total execution time: 0.1287
DEBUG - 2022-06-20 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:34:00 --> Total execution time: 0.0314
DEBUG - 2022-06-20 11:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:34:02 --> Total execution time: 0.0538
DEBUG - 2022-06-20 11:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:34:16 --> Total execution time: 0.0488
DEBUG - 2022-06-20 11:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:34:23 --> Total execution time: 0.0563
DEBUG - 2022-06-20 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:34:24 --> Total execution time: 0.0337
DEBUG - 2022-06-20 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:34:32 --> Total execution time: 0.0599
DEBUG - 2022-06-20 11:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:34:38 --> Total execution time: 0.0638
DEBUG - 2022-06-20 11:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:34:43 --> Total execution time: 0.0458
DEBUG - 2022-06-20 11:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:05:29 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:35:29 --> Total execution time: 0.0335
DEBUG - 2022-06-20 11:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:36:07 --> Total execution time: 0.0295
DEBUG - 2022-06-20 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:36:18 --> Total execution time: 0.0457
DEBUG - 2022-06-20 11:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:09:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:39:26 --> Total execution time: 0.0862
DEBUG - 2022-06-20 11:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:09:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:39:37 --> Total execution time: 0.0316
DEBUG - 2022-06-20 11:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:02 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:40:02 --> Total execution time: 0.0359
DEBUG - 2022-06-20 11:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:07 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:40:07 --> Total execution time: 0.0453
DEBUG - 2022-06-20 11:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:08 --> Total execution time: 0.0451
DEBUG - 2022-06-20 11:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:40:09 --> Total execution time: 0.1038
DEBUG - 2022-06-20 11:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:10 --> Total execution time: 0.0618
DEBUG - 2022-06-20 11:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:10 --> Total execution time: 0.0940
DEBUG - 2022-06-20 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:40:11 --> Total execution time: 0.0398
DEBUG - 2022-06-20 11:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:40:29 --> Total execution time: 0.0552
DEBUG - 2022-06-20 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:40:32 --> Total execution time: 0.0431
DEBUG - 2022-06-20 11:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:40:46 --> Total execution time: 0.1149
DEBUG - 2022-06-20 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:41:12 --> Total execution time: 0.0544
DEBUG - 2022-06-20 11:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:41:23 --> Total execution time: 0.0466
DEBUG - 2022-06-20 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:42:37 --> Total execution time: 0.0289
DEBUG - 2022-06-20 11:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:12:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:42:49 --> Total execution time: 2.0814
DEBUG - 2022-06-20 11:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:42:50 --> Total execution time: 0.0406
DEBUG - 2022-06-20 11:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:12:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 11:12:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 11:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 11:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:31 --> Total execution time: 0.0437
DEBUG - 2022-06-20 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 21:43:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 21:43:33 --> Total execution time: 0.1964
DEBUG - 2022-06-20 11:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:43 --> Total execution time: 0.0658
DEBUG - 2022-06-20 11:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:47 --> Total execution time: 0.0379
DEBUG - 2022-06-20 11:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:52 --> Total execution time: 0.0390
DEBUG - 2022-06-20 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:55 --> Total execution time: 0.0461
DEBUG - 2022-06-20 11:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:56 --> Total execution time: 0.1070
DEBUG - 2022-06-20 11:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:56 --> Total execution time: 0.0435
DEBUG - 2022-06-20 11:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:57 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:57 --> Total execution time: 0.0438
DEBUG - 2022-06-20 11:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:58 --> Total execution time: 0.0400
DEBUG - 2022-06-20 11:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:13:59 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:43:59 --> Total execution time: 0.0391
DEBUG - 2022-06-20 11:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:44:00 --> Total execution time: 0.0528
DEBUG - 2022-06-20 11:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:47:01 --> Total execution time: 0.2297
DEBUG - 2022-06-20 11:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:47:17 --> Total execution time: 0.0455
DEBUG - 2022-06-20 11:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:47:23 --> Total execution time: 0.0428
DEBUG - 2022-06-20 11:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:47:27 --> Total execution time: 0.0608
DEBUG - 2022-06-20 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:47:43 --> Total execution time: 0.0639
DEBUG - 2022-06-20 11:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:47:49 --> Total execution time: 0.0467
DEBUG - 2022-06-20 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:47:55 --> Total execution time: 0.1008
DEBUG - 2022-06-20 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:47:55 --> Total execution time: 0.0946
DEBUG - 2022-06-20 11:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:48:05 --> Total execution time: 0.1145
DEBUG - 2022-06-20 11:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:48:54 --> Total execution time: 0.0452
DEBUG - 2022-06-20 11:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:48:55 --> Total execution time: 0.0564
DEBUG - 2022-06-20 11:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:48:56 --> Total execution time: 0.0581
DEBUG - 2022-06-20 11:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:48:58 --> Total execution time: 0.0542
DEBUG - 2022-06-20 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:00 --> Total execution time: 0.0571
DEBUG - 2022-06-20 11:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:01 --> Total execution time: 0.0645
DEBUG - 2022-06-20 11:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:02 --> Total execution time: 0.0432
DEBUG - 2022-06-20 11:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:04 --> Total execution time: 0.0392
DEBUG - 2022-06-20 11:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:25 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:25 --> Total execution time: 0.0357
DEBUG - 2022-06-20 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:28 --> Total execution time: 0.0434
DEBUG - 2022-06-20 11:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:33 --> Total execution time: 0.0406
DEBUG - 2022-06-20 11:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:49 --> Total execution time: 0.0439
DEBUG - 2022-06-20 11:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:49:57 --> Total execution time: 0.0618
DEBUG - 2022-06-20 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:50:03 --> Total execution time: 0.0606
DEBUG - 2022-06-20 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:50:08 --> Total execution time: 0.0878
DEBUG - 2022-06-20 11:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:50:41 --> Total execution time: 0.0484
DEBUG - 2022-06-20 11:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:50:44 --> Total execution time: 0.0450
DEBUG - 2022-06-20 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:50:48 --> Total execution time: 0.0669
DEBUG - 2022-06-20 11:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:50:49 --> Total execution time: 0.0454
DEBUG - 2022-06-20 11:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:50:52 --> Total execution time: 0.0465
DEBUG - 2022-06-20 11:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:50:58 --> Total execution time: 0.0968
DEBUG - 2022-06-20 11:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:02 --> Total execution time: 0.0456
DEBUG - 2022-06-20 11:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:07 --> Total execution time: 0.0617
DEBUG - 2022-06-20 11:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:27 --> Total execution time: 0.0436
DEBUG - 2022-06-20 11:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:30 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:30 --> Total execution time: 0.0471
DEBUG - 2022-06-20 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:33 --> Total execution time: 0.0396
DEBUG - 2022-06-20 11:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:41 --> Total execution time: 0.0492
DEBUG - 2022-06-20 11:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:45 --> Total execution time: 0.0502
DEBUG - 2022-06-20 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:50 --> Total execution time: 0.0502
DEBUG - 2022-06-20 11:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:51:51 --> Total execution time: 0.0632
DEBUG - 2022-06-20 11:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 11:22:08 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 11:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:52:08 --> Total execution time: 0.0322
DEBUG - 2022-06-20 11:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:52:16 --> Total execution time: 0.0938
DEBUG - 2022-06-20 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 11:22:23 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 11:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:52:29 --> Total execution time: 0.0454
DEBUG - 2022-06-20 11:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:52:33 --> Total execution time: 0.0431
DEBUG - 2022-06-20 11:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:52:40 --> Total execution time: 0.1088
DEBUG - 2022-06-20 11:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:55 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:52:55 --> Total execution time: 0.0432
DEBUG - 2022-06-20 11:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 11:22:56 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 11:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:22:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 11:22:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 11:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:53:44 --> Total execution time: 0.1264
DEBUG - 2022-06-20 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:57:31 --> Total execution time: 0.0965
DEBUG - 2022-06-20 11:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:02:36 --> Total execution time: 0.1241
DEBUG - 2022-06-20 11:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:00 --> Total execution time: 0.1566
DEBUG - 2022-06-20 11:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:18 --> Total execution time: 0.0512
DEBUG - 2022-06-20 11:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:32 --> Total execution time: 0.0507
DEBUG - 2022-06-20 11:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:35 --> Total execution time: 0.0463
DEBUG - 2022-06-20 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:42 --> Total execution time: 0.0527
DEBUG - 2022-06-20 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:52 --> Total execution time: 0.0522
DEBUG - 2022-06-20 11:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:48:15 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:18:15 --> Total execution time: 0.1149
DEBUG - 2022-06-20 11:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:55:14 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:25:14 --> Total execution time: 0.1062
DEBUG - 2022-06-20 11:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:25:35 --> Total execution time: 0.0347
DEBUG - 2022-06-20 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:26:35 --> Total execution time: 0.0504
DEBUG - 2022-06-20 11:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:26:51 --> Total execution time: 0.0657
DEBUG - 2022-06-20 11:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:57:02 --> No URI present. Default controller set.
DEBUG - 2022-06-20 11:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:02 --> Total execution time: 0.1089
DEBUG - 2022-06-20 11:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:02 --> Total execution time: 0.0292
DEBUG - 2022-06-20 11:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:10 --> Total execution time: 0.0457
DEBUG - 2022-06-20 11:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:15 --> Total execution time: 0.0971
DEBUG - 2022-06-20 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:16 --> Total execution time: 0.0808
DEBUG - 2022-06-20 11:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:28:08 --> Total execution time: 0.1215
DEBUG - 2022-06-20 11:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:28:30 --> Total execution time: 0.0905
DEBUG - 2022-06-20 11:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:28:50 --> Total execution time: 0.0954
DEBUG - 2022-06-20 11:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:28:54 --> Total execution time: 0.1327
DEBUG - 2022-06-20 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:29:11 --> Total execution time: 0.0663
DEBUG - 2022-06-20 11:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 11:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 11:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:29:33 --> Total execution time: 0.0792
DEBUG - 2022-06-20 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:30:03 --> Total execution time: 0.0901
DEBUG - 2022-06-20 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:00:03 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:30:03 --> Total execution time: 0.0410
DEBUG - 2022-06-20 12:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:30:05 --> Total execution time: 0.0644
DEBUG - 2022-06-20 12:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:30:06 --> Total execution time: 0.0664
DEBUG - 2022-06-20 12:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:32:12 --> Total execution time: 0.1676
DEBUG - 2022-06-20 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:07:05 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:37:05 --> Total execution time: 0.0817
DEBUG - 2022-06-20 12:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:09:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:39:26 --> Total execution time: 0.0845
DEBUG - 2022-06-20 12:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:39:33 --> Total execution time: 0.0491
DEBUG - 2022-06-20 12:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:39:50 --> Total execution time: 0.0402
DEBUG - 2022-06-20 12:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:40:03 --> Total execution time: 0.0423
DEBUG - 2022-06-20 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:10:23 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:40:23 --> Total execution time: 0.0527
DEBUG - 2022-06-20 12:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:10:48 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:40:48 --> Total execution time: 0.0482
DEBUG - 2022-06-20 12:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:41:05 --> Total execution time: 0.0453
DEBUG - 2022-06-20 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:11:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:41:08 --> Total execution time: 0.0405
DEBUG - 2022-06-20 12:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:41:13 --> Total execution time: 0.0541
DEBUG - 2022-06-20 12:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:41:22 --> Total execution time: 0.0439
DEBUG - 2022-06-20 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:42:02 --> Total execution time: 0.0464
DEBUG - 2022-06-20 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:42:04 --> Total execution time: 0.0468
DEBUG - 2022-06-20 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:42:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 12:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:42:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:42:15 --> Total execution time: 0.0444
DEBUG - 2022-06-20 12:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:45:02 --> Total execution time: 0.1416
DEBUG - 2022-06-20 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:45:04 --> Total execution time: 0.0435
DEBUG - 2022-06-20 12:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:45:11 --> Total execution time: 0.0482
DEBUG - 2022-06-20 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:45:12 --> Total execution time: 0.0338
DEBUG - 2022-06-20 12:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:45:36 --> Total execution time: 0.0445
DEBUG - 2022-06-20 12:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:45:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 12:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:45:38 --> Total execution time: 0.0455
DEBUG - 2022-06-20 12:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:46:33 --> Total execution time: 0.0955
DEBUG - 2022-06-20 12:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:46:40 --> Total execution time: 0.0478
DEBUG - 2022-06-20 12:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:16:40 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:46:40 --> Total execution time: 0.0463
DEBUG - 2022-06-20 12:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:16:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:46:53 --> Total execution time: 0.0563
DEBUG - 2022-06-20 12:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:16:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:46:53 --> Total execution time: 0.0373
DEBUG - 2022-06-20 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:46:56 --> Total execution time: 0.0427
DEBUG - 2022-06-20 12:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:46:57 --> Total execution time: 0.0430
DEBUG - 2022-06-20 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:47:00 --> Total execution time: 0.0469
DEBUG - 2022-06-20 12:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:47:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 12:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:47:01 --> Total execution time: 0.0423
DEBUG - 2022-06-20 12:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:48:02 --> Total execution time: 0.0396
DEBUG - 2022-06-20 12:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:48:11 --> Total execution time: 0.0411
DEBUG - 2022-06-20 12:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:48:22 --> Total execution time: 0.0569
DEBUG - 2022-06-20 12:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:48:22 --> Total execution time: 0.0411
DEBUG - 2022-06-20 12:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:48:29 --> Total execution time: 0.0557
DEBUG - 2022-06-20 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:48:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:48:30 --> Total execution time: 0.0396
DEBUG - 2022-06-20 12:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:20:45 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:50:45 --> Total execution time: 0.0307
DEBUG - 2022-06-20 12:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:50:46 --> Total execution time: 0.0399
DEBUG - 2022-06-20 12:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:50:48 --> Total execution time: 0.0421
DEBUG - 2022-06-20 12:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:53:12 --> Total execution time: 0.1659
DEBUG - 2022-06-20 12:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:27:38 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:57:38 --> Total execution time: 0.1157
DEBUG - 2022-06-20 12:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:27:39 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:57:39 --> Total execution time: 0.0329
DEBUG - 2022-06-20 12:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:08 --> Total execution time: 0.0323
DEBUG - 2022-06-20 12:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:09 --> Total execution time: 0.0313
DEBUG - 2022-06-20 12:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:12 --> Total execution time: 0.0421
DEBUG - 2022-06-20 12:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:16 --> Total execution time: 0.0460
DEBUG - 2022-06-20 12:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:18 --> Total execution time: 0.0506
DEBUG - 2022-06-20 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:25 --> Total execution time: 0.0629
DEBUG - 2022-06-20 12:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:30 --> Total execution time: 0.0552
DEBUG - 2022-06-20 12:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:31 --> Total execution time: 0.0431
DEBUG - 2022-06-20 12:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:33 --> Total execution time: 0.0532
DEBUG - 2022-06-20 12:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:39 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:39 --> Total execution time: 0.0472
DEBUG - 2022-06-20 12:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:41 --> Total execution time: 0.0454
DEBUG - 2022-06-20 12:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:43 --> Total execution time: 0.0448
DEBUG - 2022-06-20 12:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:43 --> Total execution time: 0.0900
DEBUG - 2022-06-20 12:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:45 --> Total execution time: 0.0463
DEBUG - 2022-06-20 12:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:45 --> Total execution time: 0.0475
DEBUG - 2022-06-20 12:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:59:51 --> Total execution time: 0.0553
DEBUG - 2022-06-20 12:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:30:05 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:05 --> Total execution time: 0.0474
DEBUG - 2022-06-20 12:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:31:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:01:31 --> Total execution time: 0.0432
DEBUG - 2022-06-20 12:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:02:01 --> Total execution time: 0.1328
DEBUG - 2022-06-20 12:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:32:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:32:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 12:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:34:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:04:22 --> Total execution time: 0.1070
DEBUG - 2022-06-20 12:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:34:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:34:50 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:36:15 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:06:15 --> Total execution time: 0.0314
DEBUG - 2022-06-20 12:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:36:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 12:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:39:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:09:08 --> Total execution time: 0.0828
DEBUG - 2022-06-20 12:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:10:06 --> Total execution time: 0.0459
DEBUG - 2022-06-20 12:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:40:57 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:10:57 --> Total execution time: 0.0973
DEBUG - 2022-06-20 12:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:01 --> Total execution time: 0.0456
DEBUG - 2022-06-20 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:03 --> Total execution time: 0.0395
DEBUG - 2022-06-20 12:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:04 --> Total execution time: 0.0561
DEBUG - 2022-06-20 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:07 --> Total execution time: 0.0489
DEBUG - 2022-06-20 12:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:22 --> Total execution time: 0.0476
DEBUG - 2022-06-20 12:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:23 --> Total execution time: 0.0499
DEBUG - 2022-06-20 12:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:41:25 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:25 --> Total execution time: 0.0420
DEBUG - 2022-06-20 12:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:44:54 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:14:54 --> Total execution time: 0.0831
DEBUG - 2022-06-20 12:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:45:02 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:15:02 --> Total execution time: 0.0359
DEBUG - 2022-06-20 12:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:45:03 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:15:03 --> Total execution time: 0.0253
DEBUG - 2022-06-20 12:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:45:26 --> Total execution time: 0.0313
DEBUG - 2022-06-20 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:45:27 --> Total execution time: 0.0505
DEBUG - 2022-06-20 12:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:45:27 --> Total execution time: 0.0978
DEBUG - 2022-06-20 12:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:46:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 12:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:40 --> Total execution time: 1.9187
DEBUG - 2022-06-20 12:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:46:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 12:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:46:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:46:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-20 12:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:55 --> Total execution time: 0.0276
DEBUG - 2022-06-20 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:18:01 --> Total execution time: 1.4517
DEBUG - 2022-06-20 12:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:18:33 --> Total execution time: 1.4958
DEBUG - 2022-06-20 12:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:18:37 --> Total execution time: 0.0593
DEBUG - 2022-06-20 12:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:39 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:18:39 --> Total execution time: 0.0437
DEBUG - 2022-06-20 12:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:18:43 --> Total execution time: 0.0474
DEBUG - 2022-06-20 12:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:18:49 --> Total execution time: 0.0485
DEBUG - 2022-06-20 12:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:18:49 --> Total execution time: 0.0652
DEBUG - 2022-06-20 12:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:48:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:18:53 --> Total execution time: 0.0440
DEBUG - 2022-06-20 12:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:49:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:22 --> Total execution time: 0.0339
DEBUG - 2022-06-20 12:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:25 --> Total execution time: 1.4299
DEBUG - 2022-06-20 12:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:49:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 12:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:31 --> Total execution time: 0.0428
DEBUG - 2022-06-20 12:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:35 --> Total execution time: 0.0615
DEBUG - 2022-06-20 12:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:50 --> Total execution time: 0.0455
DEBUG - 2022-06-20 12:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:56 --> Total execution time: 0.0535
DEBUG - 2022-06-20 12:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:58 --> Total execution time: 0.0590
DEBUG - 2022-06-20 12:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:03 --> Total execution time: 0.0991
DEBUG - 2022-06-20 12:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:10 --> Total execution time: 0.0559
DEBUG - 2022-06-20 12:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:11 --> Total execution time: 0.0442
DEBUG - 2022-06-20 12:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:19 --> Total execution time: 0.0491
DEBUG - 2022-06-20 12:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:52 --> Total execution time: 0.0944
DEBUG - 2022-06-20 12:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:57 --> Total execution time: 0.0933
DEBUG - 2022-06-20 12:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:04 --> Total execution time: 0.0435
DEBUG - 2022-06-20 12:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:09 --> Total execution time: 0.0564
DEBUG - 2022-06-20 12:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:12 --> Total execution time: 0.0663
DEBUG - 2022-06-20 12:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 12:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:23 --> Total execution time: 0.0582
DEBUG - 2022-06-20 12:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:27 --> Total execution time: 0.0509
DEBUG - 2022-06-20 12:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:35 --> Total execution time: 0.0514
DEBUG - 2022-06-20 12:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:39 --> Total execution time: 0.0596
DEBUG - 2022-06-20 12:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 12:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 12:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:22:12 --> Total execution time: 0.0377
DEBUG - 2022-06-20 12:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:57:03 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-20 12:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:57:03 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-20 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:57:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:57:04 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-20 12:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 12:59:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 12:59:43 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:30:03 --> Total execution time: 0.1459
DEBUG - 2022-06-20 13:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:31:35 --> Total execution time: 0.0368
DEBUG - 2022-06-20 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:03:11 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:33:11 --> Total execution time: 0.0418
DEBUG - 2022-06-20 13:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:03:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:33:31 --> Total execution time: 0.0315
DEBUG - 2022-06-20 13:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:03:59 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:33:59 --> Total execution time: 0.0314
DEBUG - 2022-06-20 13:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:08:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 13:08:13 --> 404 Page Not Found: Assets/images
DEBUG - 2022-06-20 13:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:13:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:43:50 --> Total execution time: 0.1926
DEBUG - 2022-06-20 13:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:53:02 --> Total execution time: 0.0698
DEBUG - 2022-06-20 13:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:06 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:06 --> Total execution time: 0.0848
DEBUG - 2022-06-20 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:11 --> Total execution time: 0.0698
DEBUG - 2022-06-20 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:17 --> Total execution time: 0.0491
DEBUG - 2022-06-20 13:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 13:25:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-06-20 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:27 --> Total execution time: 0.0485
DEBUG - 2022-06-20 13:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 13:25:28 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-06-20 13:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:30 --> Total execution time: 0.0434
DEBUG - 2022-06-20 13:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 13:25:31 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-06-20 13:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:57 --> Total execution time: 0.0457
DEBUG - 2022-06-20 13:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:25:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 13:25:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-06-20 13:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:56:03 --> Total execution time: 0.0643
DEBUG - 2022-06-20 13:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 13:26:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-06-20 13:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:56:09 --> Total execution time: 0.0629
DEBUG - 2022-06-20 13:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 13:26:10 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-06-20 13:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:56:15 --> Total execution time: 0.0449
DEBUG - 2022-06-20 13:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:28:34 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:58:34 --> Total execution time: 0.1625
DEBUG - 2022-06-20 13:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:31 --> Total execution time: 0.0409
DEBUG - 2022-06-20 13:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:38:40 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:38:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:39:10 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:39:45 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:16 --> Total execution time: 0.0479
DEBUG - 2022-06-20 13:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:18 --> Total execution time: 0.0439
DEBUG - 2022-06-20 13:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:18 --> Total execution time: 0.0882
DEBUG - 2022-06-20 13:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:27 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:44:04 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:44:04 --> No URI present. Default controller set.
DEBUG - 2022-06-20 13:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:44:10 --> Total execution time: 0.0450
DEBUG - 2022-06-20 13:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 13:44:12 --> Total execution time: 0.0498
DEBUG - 2022-06-20 13:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 13:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 13:44:12 --> Total execution time: 0.0602
DEBUG - 2022-06-20 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:04:42 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:04:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:05:28 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:08:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 14:08:55 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 14:11:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 14:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:13:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 14:13:23 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 14:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:20:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:21:05 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:21:34 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:23:04 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:23:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:24:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 14:24:31 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-20 14:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:24:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:24:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:24:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 14:24:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:51 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 14:35:55 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 14:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:23 --> Total execution time: 0.0413
DEBUG - 2022-06-20 14:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:53:23 --> No URI present. Default controller set.
DEBUG - 2022-06-20 14:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 14:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 14:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 14:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 15:44:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 15:44:55 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 15:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 15:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 15:47:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 15:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 15:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 15:49:22 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 15:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 15:50:20 --> No URI present. Default controller set.
DEBUG - 2022-06-20 15:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 15:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 15:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 15:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 15:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 15:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 15:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 15:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 15:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 16:11:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 16:11:52 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 16:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 16:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 16:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 16:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 16:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 16:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 16:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 16:51:34 --> 404 Page Not Found: Category/sports
DEBUG - 2022-06-20 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:04:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 17:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:05:12 --> No URI present. Default controller set.
DEBUG - 2022-06-20 17:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:06:11 --> No URI present. Default controller set.
DEBUG - 2022-06-20 17:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:06:19 --> Total execution time: 0.0451
DEBUG - 2022-06-20 17:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:06:21 --> Total execution time: 0.0414
DEBUG - 2022-06-20 17:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:06:21 --> Total execution time: 0.0939
DEBUG - 2022-06-20 17:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:08:43 --> No URI present. Default controller set.
DEBUG - 2022-06-20 17:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:08:44 --> No URI present. Default controller set.
DEBUG - 2022-06-20 17:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:11:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 17:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:20:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 17:20:41 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 17:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 17:23:13 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 17:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:25:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 17:25:24 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 17:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:30:55 --> No URI present. Default controller set.
DEBUG - 2022-06-20 17:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 17:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 17:44:16 --> 404 Page Not Found: Sports/feed
DEBUG - 2022-06-20 17:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:48:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 17:48:47 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 17:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 17:58:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 17:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 17:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 18:22:06 --> No URI present. Default controller set.
DEBUG - 2022-06-20 18:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 18:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 18:25:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 18:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 18:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 18:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 18:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:25:39 --> Total execution time: 0.0756
DEBUG - 2022-06-20 18:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 18:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 18:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 18:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 18:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:25:40 --> Total execution time: 0.0496
DEBUG - 2022-06-20 18:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:25:41 --> Total execution time: 0.1096
DEBUG - 2022-06-20 18:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 18:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 18:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 18:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 18:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 18:57:42 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:00:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 19:00:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 19:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 19:02:34 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 19:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:26 --> No URI present. Default controller set.
DEBUG - 2022-06-20 19:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 19:12:27 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 19:12:27 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 19:12:27 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:24:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 19:24:38 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 19:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:35:58 --> No URI present. Default controller set.
DEBUG - 2022-06-20 19:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:36:00 --> No URI present. Default controller set.
DEBUG - 2022-06-20 19:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:36:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 19:36:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 19:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:37:51 --> No URI present. Default controller set.
DEBUG - 2022-06-20 19:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:37:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 19:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:43:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 19:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:45:30 --> No URI present. Default controller set.
DEBUG - 2022-06-20 19:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 19:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 19:52:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 19:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 19:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:03:03 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:16 --> Total execution time: 0.0427
DEBUG - 2022-06-20 20:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:17 --> Total execution time: 0.0714
DEBUG - 2022-06-20 20:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:17 --> Total execution time: 0.1123
DEBUG - 2022-06-20 20:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:03:19 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:03:45 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:09:58 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:17:45 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:22:37 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:33:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 20:33:11 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 20:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 20:35:33 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 20:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:37:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 20:37:34 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 20:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:39:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:39:39 --> Total execution time: 0.0377
DEBUG - 2022-06-20 20:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:39:40 --> Total execution time: 0.0620
DEBUG - 2022-06-20 20:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:39:40 --> Total execution time: 0.0904
DEBUG - 2022-06-20 20:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:40:44 --> Total execution time: 0.0503
DEBUG - 2022-06-20 20:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:40:45 --> Total execution time: 0.0505
DEBUG - 2022-06-20 20:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:40:45 --> Total execution time: 0.0676
DEBUG - 2022-06-20 20:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:42:03 --> Total execution time: 0.0508
DEBUG - 2022-06-20 20:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:42:04 --> Total execution time: 0.0492
DEBUG - 2022-06-20 20:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:42:04 --> Total execution time: 0.0785
DEBUG - 2022-06-20 20:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:52:28 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:53:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 20:53:02 --> 404 Page Not Found: List_teacher/index
DEBUG - 2022-06-20 20:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:53:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 20:53:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 20:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:53:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 20:53:10 --> 404 Page Not Found: Become-an-affiliate/index
DEBUG - 2022-06-20 20:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:53:14 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:58:17 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:58:54 --> No URI present. Default controller set.
DEBUG - 2022-06-20 20:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 20:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 20:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:59:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 20:59:42 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-20 20:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 20:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 20:59:50 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:02:24 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:09:13 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:09:33 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:10 --> Total execution time: 0.0673
DEBUG - 2022-06-20 21:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:21 --> Total execution time: 0.0396
DEBUG - 2022-06-20 21:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:28 --> Total execution time: 0.0420
DEBUG - 2022-06-20 21:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:32 --> Total execution time: 0.0439
DEBUG - 2022-06-20 21:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:10:53 --> Total execution time: 0.0452
DEBUG - 2022-06-20 21:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:17:10 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:17:21 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:17:30 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:17:30 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:18:01 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:19:25 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:32:43 --> No URI present. Default controller set.
DEBUG - 2022-06-20 21:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 21:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 21:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:48:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 21:48:10 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-20 21:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:48:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 21:48:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-20 21:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 21:58:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 21:58:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-20 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:04:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 22:07:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 22:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:10:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 22:10:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 22:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:12:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 22:12:13 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 22:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:14:43 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:10 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:09 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:11 --> Total execution time: 0.0455
DEBUG - 2022-06-20 22:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:12 --> Total execution time: 0.0445
DEBUG - 2022-06-20 22:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:12 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:13 --> Total execution time: 0.0407
DEBUG - 2022-06-20 22:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:21 --> Total execution time: 0.0411
DEBUG - 2022-06-20 22:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:25 --> Total execution time: 0.0410
DEBUG - 2022-06-20 22:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:27:53 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:28:21 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:34:52 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:34:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 22:34:52 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-20 22:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:35:06 --> Total execution time: 0.0328
DEBUG - 2022-06-20 22:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:35:27 --> Total execution time: 0.0476
DEBUG - 2022-06-20 22:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:35:27 --> Total execution time: 0.1260
DEBUG - 2022-06-20 22:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:43:32 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 22:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 22:57:25 --> No URI present. Default controller set.
DEBUG - 2022-06-20 22:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 22:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:06:31 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:10:46 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:15:59 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:16:28 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:17:59 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:19:16 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:19:38 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:08 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:27 --> Total execution time: 0.0454
DEBUG - 2022-06-20 23:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:33 --> Total execution time: 0.0522
DEBUG - 2022-06-20 23:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:33 --> Total execution time: 0.0980
DEBUG - 2022-06-20 23:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:20:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:21:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-20 23:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:21:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 23:21:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 23:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:24:32 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:34:43 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:34:43 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:36:27 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:39:56 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:40:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 23:40:05 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-20 23:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:40:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 23:40:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-20 23:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:40:22 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:40:29 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:41:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:41:50 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:42:07 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:42:15 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 23:43:01 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-20 23:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:45:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 23:45:23 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-20 23:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-20 23:47:25 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-20 23:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:49:51 --> No URI present. Default controller set.
DEBUG - 2022-06-20 23:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-20 23:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-20 23:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-20 23:59:55 --> Encryption: Auto-configured driver 'openssl'.
