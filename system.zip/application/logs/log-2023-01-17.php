<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-17 08:02:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:02:45 --> No URI present. Default controller set.
DEBUG - 2023-01-17 08:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:32:46 --> Total execution time: 0.8216
DEBUG - 2023-01-17 08:03:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:33:45 --> Total execution time: 0.1451
DEBUG - 2023-01-17 08:03:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:33:48 --> Total execution time: 0.1218
DEBUG - 2023-01-17 08:03:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:33:51 --> Total execution time: 0.0564
DEBUG - 2023-01-17 08:03:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:33:53 --> Total execution time: 0.1211
DEBUG - 2023-01-17 08:08:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:38:27 --> Total execution time: 0.0930
DEBUG - 2023-01-17 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:38:45 --> Total execution time: 0.0631
DEBUG - 2023-01-17 08:09:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:39:35 --> Total execution time: 0.0614
DEBUG - 2023-01-17 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:12:59 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 08:12:59 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 08:12:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:12:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:43:00 --> Total execution time: 0.0639
DEBUG - 2023-01-17 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:13:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:13:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:13:01 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 08:13:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:13:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:13:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:43:42 --> Total execution time: 0.0614
DEBUG - 2023-01-17 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:13:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:13:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:13:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:13:42 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:15:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:45:46 --> Total execution time: 0.0588
DEBUG - 2023-01-17 08:15:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:15:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:15:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:15:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:15:46 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 08:15:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:15:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:15:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:15:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:46:22 --> Total execution time: 0.0702
DEBUG - 2023-01-17 08:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:16:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:16:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:16:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:16:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:16:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:16:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 08:19:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:19:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:49:44 --> Severity: Notice --> Undefined property: Payment_Controller::$Posts C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Payment_Controller.php 19
ERROR - 2023-01-17 12:49:44 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Payment_Controller.php 19
DEBUG - 2023-01-17 08:19:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:19:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:49:50 --> Severity: Notice --> Undefined variable: slug C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\Payment_Controller.php 19
ERROR - 2023-01-17 12:49:50 --> 404 Page Not Found: 
DEBUG - 2023-01-17 08:19:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:51:07 --> Total execution time: 0.0454
DEBUG - 2023-01-17 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:21:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:21:08 --> UTF-8 Support Enabled
ERROR - 2023-01-17 08:21:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:21:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:21:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:21:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:22:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:52:27 --> Total execution time: 0.0710
DEBUG - 2023-01-17 08:22:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:52:32 --> Total execution time: 0.0660
DEBUG - 2023-01-17 08:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:22:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:22:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:22:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:22:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:22:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:52:55 --> Total execution time: 0.0592
DEBUG - 2023-01-17 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:22:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:22:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:22:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:22:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:23:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:53:47 --> Total execution time: 0.0826
DEBUG - 2023-01-17 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:23:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:23:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:23:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:23:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:54:38 --> Total execution time: 0.0509
DEBUG - 2023-01-17 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:54:47 --> Total execution time: 0.0625
DEBUG - 2023-01-17 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:26:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:56:16 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:56:16 --> Severity: Notice --> Trying to get property 'pg_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:56:16 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:56:16 --> Severity: Notice --> Trying to get property 'pg_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:56:16 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
ERROR - 2023-01-17 12:56:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
ERROR - 2023-01-17 12:56:16 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 93
ERROR - 2023-01-17 12:56:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 93
DEBUG - 2023-01-17 12:56:16 --> Total execution time: 0.0678
DEBUG - 2023-01-17 08:26:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:26:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:56:25 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:56:25 --> Severity: Notice --> Trying to get property 'pg_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:56:25 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:56:25 --> Severity: Notice --> Trying to get property 'pg_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:56:25 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
ERROR - 2023-01-17 12:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
ERROR - 2023-01-17 12:56:25 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 93
ERROR - 2023-01-17 12:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 93
DEBUG - 2023-01-17 12:56:25 --> Total execution time: 0.0764
DEBUG - 2023-01-17 08:26:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:26:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:56:38 --> Severity: error --> Exception: syntax error, unexpected '.0' (T_DNUMBER), expecting ';' or ',' C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 93
DEBUG - 2023-01-17 08:26:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:26:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:56:44 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:56:44 --> Severity: Notice --> Trying to get property 'pg_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:56:44 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:56:44 --> Severity: Notice --> Trying to get property 'pg_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:56:44 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
ERROR - 2023-01-17 12:56:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
DEBUG - 2023-01-17 12:56:44 --> Total execution time: 0.0913
DEBUG - 2023-01-17 08:27:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:27:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:57:34 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:57:34 --> Severity: Notice --> Trying to get property 'pg_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:57:34 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:57:34 --> Severity: Notice --> Trying to get property 'pg_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:57:34 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
ERROR - 2023-01-17 12:57:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
DEBUG - 2023-01-17 12:57:34 --> Total execution time: 0.0697
DEBUG - 2023-01-17 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:27:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:57:55 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:57:55 --> Severity: Notice --> Trying to get property 'pg_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 58
ERROR - 2023-01-17 12:57:55 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:57:55 --> Severity: Notice --> Trying to get property 'pg_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 59
ERROR - 2023-01-17 12:57:55 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
ERROR - 2023-01-17 12:57:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 60
DEBUG - 2023-01-17 12:57:55 --> Total execution time: 0.0480
DEBUG - 2023-01-17 08:29:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:29:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 12:59:23 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 43
ERROR - 2023-01-17 12:59:23 --> Severity: Notice --> Trying to get property 'pg_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 43
ERROR - 2023-01-17 12:59:23 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 44
ERROR - 2023-01-17 12:59:23 --> Severity: Notice --> Trying to get property 'pg_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 44
ERROR - 2023-01-17 12:59:23 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 45
ERROR - 2023-01-17 12:59:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 45
DEBUG - 2023-01-17 12:59:23 --> Total execution time: 0.0471
DEBUG - 2023-01-17 08:30:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:30:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 13:00:01 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 43
ERROR - 2023-01-17 13:00:01 --> Severity: Notice --> Trying to get property 'pg_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 43
ERROR - 2023-01-17 13:00:01 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 44
ERROR - 2023-01-17 13:00:01 --> Severity: Notice --> Trying to get property 'pg_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 44
ERROR - 2023-01-17 13:00:01 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 45
ERROR - 2023-01-17 13:00:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 45
DEBUG - 2023-01-17 13:00:01 --> Total execution time: 0.0555
DEBUG - 2023-01-17 08:30:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:30:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 13:00:26 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 43
ERROR - 2023-01-17 13:00:26 --> Severity: Notice --> Trying to get property 'pg_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 43
ERROR - 2023-01-17 13:00:26 --> Severity: Notice --> Undefined variable: product C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 44
ERROR - 2023-01-17 13:00:26 --> Severity: Notice --> Trying to get property 'pg_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 44
ERROR - 2023-01-17 13:00:26 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 45
ERROR - 2023-01-17 13:00:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\stripe-form.php 45
DEBUG - 2023-01-17 13:00:26 --> Total execution time: 0.0469
DEBUG - 2023-01-17 08:38:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:08:35 --> Total execution time: 0.0478
DEBUG - 2023-01-17 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:38:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:38:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:38:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:38:44 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:39:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:09:38 --> Total execution time: 0.0787
DEBUG - 2023-01-17 08:39:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:09:45 --> Total execution time: 0.0436
DEBUG - 2023-01-17 08:41:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:11:25 --> Total execution time: 0.0488
DEBUG - 2023-01-17 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:11:48 --> Total execution time: 0.0461
DEBUG - 2023-01-17 08:43:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:13:34 --> Total execution time: 0.0629
DEBUG - 2023-01-17 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:14:28 --> Total execution time: 0.0477
DEBUG - 2023-01-17 08:44:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:14:43 --> Total execution time: 0.0613
DEBUG - 2023-01-17 08:45:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:45:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:45:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:45:01 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 08:45:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:45:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:45:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:45:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:45:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:45:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 08:45:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 08:45:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 08:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 08:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 08:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:15:22 --> Total execution time: 0.0463
DEBUG - 2023-01-17 09:49:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:19:36 --> Total execution time: 0.0567
DEBUG - 2023-01-17 09:49:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:49:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 14:19:59 --> Query error: Unknown column 'ord_currency' in 'field list' - Invalid query: UPDATE `donations` SET `don_txn_id` = 'txn_3MRArlIn1EyeRCZU1jF8lUVP', `ord_currency` = 'usd', `ord_status` = 'success', `don_date` = '2023-01-17 14:19:59'
WHERE `don_order_id` = 'CF585108523'
DEBUG - 2023-01-17 09:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:50:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:20:41 --> Total execution time: 0.0650
DEBUG - 2023-01-17 09:50:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:50:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 14:20:50 --> Query error: Unknown column 'ord_status' in 'field list' - Invalid query: UPDATE `donations` SET `don_txn_id` = 'txn_3MRAsaIn1EyeRCZU1a0ZkoZD', `don_currency` = 'usd', `ord_status` = 'success', `don_date` = '2023-01-17 14:20:50'
WHERE `don_order_id` = 'CF585108524'
DEBUG - 2023-01-17 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:21:04 --> Total execution time: 0.0605
DEBUG - 2023-01-17 09:51:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 09:51:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 09:51:12 --> 404 Page Not Found: User/transaction-status
DEBUG - 2023-01-17 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:21:24 --> Total execution time: 0.0435
DEBUG - 2023-01-17 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:21:41 --> Total execution time: 0.0587
DEBUG - 2023-01-17 09:51:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 09:51:57 --> 404 Page Not Found: User/transaction-status
DEBUG - 2023-01-17 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 09:55:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:55:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 14:25:52 --> Severity: Notice --> Undefined variable: PageTitle C:\xampp\htdocs\gopal\crowd_funding\application\views\website\inc\stylesheet.php 3
ERROR - 2023-01-17 14:25:52 --> Severity: Notice --> Undefined variable: PageTitle C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 21
ERROR - 2023-01-17 14:25:52 --> Severity: Notice --> Undefined variable: PageTitle C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 25
DEBUG - 2023-01-17 14:25:52 --> Total execution time: 0.0656
DEBUG - 2023-01-17 09:56:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:26:07 --> Total execution time: 0.0789
DEBUG - 2023-01-17 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:26:36 --> Total execution time: 0.0842
DEBUG - 2023-01-17 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:26:40 --> Total execution time: 0.0451
DEBUG - 2023-01-17 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 09:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 09:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 09:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 14:26:58 --> Total execution time: 0.0744
DEBUG - 2023-01-17 12:11:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:11:07 --> No URI present. Default controller set.
DEBUG - 2023-01-17 12:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 16:41:07 --> Total execution time: 0.0758
DEBUG - 2023-01-17 12:11:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 16:41:10 --> Total execution time: 0.0694
DEBUG - 2023-01-17 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 16:52:48 --> Total execution time: 0.0466
DEBUG - 2023-01-17 12:22:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 16:52:51 --> Total execution time: 0.0819
DEBUG - 2023-01-17 12:23:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 16:53:02 --> Total execution time: 0.0458
DEBUG - 2023-01-17 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:26:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 16:56:51 --> Total execution time: 0.0424
DEBUG - 2023-01-17 12:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:31:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 17:01:05 --> Severity: Notice --> Undefined property: stdClass::$ord_order_id C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 50
ERROR - 2023-01-17 17:01:05 --> Severity: Notice --> Undefined property: stdClass::$ord_amount C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 55
ERROR - 2023-01-17 17:01:05 --> Severity: Notice --> Undefined property: stdClass::$ord_pay_order_id C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 59
ERROR - 2023-01-17 17:01:05 --> Severity: Notice --> Undefined property: stdClass::$ord_payment_id C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 63
ERROR - 2023-01-17 17:01:05 --> Severity: Notice --> Undefined property: stdClass::$ord_date C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 67
DEBUG - 2023-01-17 17:01:05 --> Total execution time: 0.0535
DEBUG - 2023-01-17 12:31:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:31:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-17 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:31:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 17:01:28 --> Severity: Notice --> Undefined property: stdClass::$ord_order_id C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 50
ERROR - 2023-01-17 17:01:28 --> Severity: Notice --> Undefined property: stdClass::$ord_amount C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 55
ERROR - 2023-01-17 17:01:28 --> Severity: Notice --> Undefined property: stdClass::$ord_pay_order_id C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 59
ERROR - 2023-01-17 17:01:28 --> Severity: Notice --> Undefined property: stdClass::$ord_payment_id C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 63
ERROR - 2023-01-17 17:01:28 --> Severity: Notice --> Undefined property: stdClass::$ord_date C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 67
DEBUG - 2023-01-17 17:01:28 --> Total execution time: 0.0466
DEBUG - 2023-01-17 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:33:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 17:03:53 --> Severity: Notice --> Undefined property: stdClass::$ord_date C:\xampp\htdocs\gopal\crowd_funding\application\views\website\payment\transaction-status.php 63
DEBUG - 2023-01-17 17:03:53 --> Total execution time: 0.0446
DEBUG - 2023-01-17 12:34:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:04:07 --> Total execution time: 0.0430
DEBUG - 2023-01-17 12:34:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:04:40 --> Total execution time: 0.0430
DEBUG - 2023-01-17 12:35:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:05:31 --> Total execution time: 0.0409
DEBUG - 2023-01-17 12:35:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:05:53 --> Total execution time: 0.0543
DEBUG - 2023-01-17 12:36:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:06:02 --> Total execution time: 0.0688
DEBUG - 2023-01-17 12:36:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:06:29 --> Total execution time: 0.0442
DEBUG - 2023-01-17 12:36:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:06:45 --> Total execution time: 0.0584
DEBUG - 2023-01-17 12:36:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:06:46 --> Total execution time: 0.0608
DEBUG - 2023-01-17 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:36:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:36:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:36:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:36:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:36:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:07:34 --> Total execution time: 0.0678
DEBUG - 2023-01-17 12:37:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:07:52 --> Total execution time: 0.0456
DEBUG - 2023-01-17 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:38:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:38:06 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:38:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:38:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:08:20 --> Total execution time: 0.0916
DEBUG - 2023-01-17 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:38:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:38:20 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:38:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:38:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:38:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:08:39 --> Total execution time: 0.0422
DEBUG - 2023-01-17 12:38:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:08:47 --> Total execution time: 0.0878
DEBUG - 2023-01-17 12:38:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:51 --> No URI present. Default controller set.
DEBUG - 2023-01-17 12:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:08:51 --> Total execution time: 0.0687
DEBUG - 2023-01-17 12:38:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:08:53 --> Total execution time: 0.0661
DEBUG - 2023-01-17 12:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:39:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:39:11 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:39:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:39:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:42:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:12:25 --> Total execution time: 0.0451
DEBUG - 2023-01-17 12:42:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:42:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:42:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:42:25 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:42:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:42:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:42:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:12:51 --> Total execution time: 0.1087
DEBUG - 2023-01-17 12:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:42:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:42:51 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:42:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:42:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:42:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:13:51 --> Total execution time: 0.0595
DEBUG - 2023-01-17 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:43:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:43:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:43:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:43:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:45:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:16:00 --> Total execution time: 0.0705
DEBUG - 2023-01-17 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:46:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:46:00 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:46:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:46:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:46:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:47:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:17:53 --> Total execution time: 0.0494
DEBUG - 2023-01-17 12:47:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:47:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:47:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:47:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:47:53 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:47:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:47:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:47:53 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:18:05 --> Total execution time: 0.0568
DEBUG - 2023-01-17 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:06 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:48:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:18:20 --> Total execution time: 0.1094
DEBUG - 2023-01-17 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:20 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:48:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:18:40 --> Total execution time: 0.0820
DEBUG - 2023-01-17 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:18:51 --> Total execution time: 0.0529
DEBUG - 2023-01-17 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:51 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 12:48:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 12:48:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 12:49:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:19:42 --> Total execution time: 0.0650
DEBUG - 2023-01-17 12:49:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:19:59 --> Total execution time: 0.0623
DEBUG - 2023-01-17 12:50:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:20:16 --> Total execution time: 0.0532
DEBUG - 2023-01-17 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:22:57 --> Total execution time: 0.0671
DEBUG - 2023-01-17 12:54:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:24:05 --> Total execution time: 0.0687
DEBUG - 2023-01-17 12:54:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:24:31 --> Total execution time: 0.0831
DEBUG - 2023-01-17 12:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:24:39 --> Total execution time: 0.0750
DEBUG - 2023-01-17 12:54:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:24:57 --> Total execution time: 0.0572
DEBUG - 2023-01-17 12:55:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:25:34 --> Total execution time: 0.0812
DEBUG - 2023-01-17 12:55:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:25:42 --> Total execution time: 0.0814
DEBUG - 2023-01-17 12:55:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:25:47 --> Total execution time: 0.0814
DEBUG - 2023-01-17 12:55:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:25:56 --> Total execution time: 0.0798
DEBUG - 2023-01-17 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:56:36 --> Total execution time: 0.0707
DEBUG - 2023-01-17 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 12:56:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:26:40 --> Total execution time: 0.1174
DEBUG - 2023-01-17 12:56:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:26:47 --> Total execution time: 0.1104
DEBUG - 2023-01-17 12:56:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:26:50 --> Total execution time: 0.1772
DEBUG - 2023-01-17 12:58:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 12:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 12:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 12:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:28:09 --> Total execution time: 0.0869
DEBUG - 2023-01-17 13:02:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:32:27 --> Total execution time: 0.0772
DEBUG - 2023-01-17 13:05:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:35:01 --> Total execution time: 0.0734
DEBUG - 2023-01-17 13:08:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:38:22 --> Total execution time: 0.0682
DEBUG - 2023-01-17 13:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:43:24 --> Total execution time: 0.1896
DEBUG - 2023-01-17 13:17:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:17:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 17:47:58 --> Query error: Table 'crowd_funding.country_id' doesn't exist - Invalid query: SELECT *
FROM `countries`, `country_id`
DEBUG - 2023-01-17 13:18:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:18:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-17 17:48:03 --> Query error: Table 'crowd_funding.country_id' doesn't exist - Invalid query: SELECT *
FROM `countries`, `country_id`
DEBUG - 2023-01-17 13:18:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:48:12 --> Total execution time: 0.0854
DEBUG - 2023-01-17 13:18:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:48:45 --> Total execution time: 0.0717
DEBUG - 2023-01-17 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:49:40 --> Total execution time: 0.0585
DEBUG - 2023-01-17 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:19:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:19:43 --> UTF-8 Support Enabled
ERROR - 2023-01-17 13:19:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:19:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:19:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:49:56 --> Total execution time: 0.0734
DEBUG - 2023-01-17 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:19:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:19:56 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 13:19:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:19:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:19:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:20:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:50:57 --> Total execution time: 0.0649
DEBUG - 2023-01-17 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:20:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:20:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:20:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:20:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:28:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 17:58:28 --> Total execution time: 0.0843
DEBUG - 2023-01-17 13:36:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:06:22 --> Total execution time: 0.0703
DEBUG - 2023-01-17 13:36:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:06:59 --> Total execution time: 0.0929
DEBUG - 2023-01-17 13:39:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:09:59 --> Total execution time: 0.0715
DEBUG - 2023-01-17 13:40:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:10:11 --> Total execution time: 0.0680
DEBUG - 2023-01-17 13:43:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:13:29 --> Total execution time: 0.0730
DEBUG - 2023-01-17 13:43:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:13:50 --> Total execution time: 0.0923
DEBUG - 2023-01-17 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:44:05 --> UTF-8 Support Enabled
ERROR - 2023-01-17 13:44:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:44:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:44:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:44:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:14:50 --> Total execution time: 0.0805
DEBUG - 2023-01-17 13:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:44:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:44:50 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 13:44:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:44:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:44:50 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 13:48:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:18:49 --> Total execution time: 0.0719
DEBUG - 2023-01-17 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:20:38 --> Total execution time: 0.0583
DEBUG - 2023-01-17 13:51:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:21:29 --> Total execution time: 0.0795
DEBUG - 2023-01-17 13:52:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:22:42 --> Total execution time: 0.0700
DEBUG - 2023-01-17 13:52:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:22:49 --> Total execution time: 0.1266
DEBUG - 2023-01-17 13:53:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:23:23 --> Total execution time: 0.0814
DEBUG - 2023-01-17 13:53:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:23:54 --> Total execution time: 0.1089
DEBUG - 2023-01-17 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:53:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:53:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:53:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:53:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:53:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:53:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:53:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:53:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-17 13:53:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:24:20 --> Total execution time: 0.0816
DEBUG - 2023-01-17 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-17 13:54:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:24:39 --> Total execution time: 0.0856
DEBUG - 2023-01-17 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-17 13:54:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:24:47 --> Total execution time: 0.0715
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-17 13:54:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:47 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-17 13:54:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
ERROR - 2023-01-17 13:54:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 13:54:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-17 13:55:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:55:07 --> No URI present. Default controller set.
DEBUG - 2023-01-17 13:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:25:07 --> Total execution time: 0.0525
DEBUG - 2023-01-17 13:55:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:25:09 --> Total execution time: 0.0475
DEBUG - 2023-01-17 13:55:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:25:11 --> Total execution time: 0.0640
DEBUG - 2023-01-17 13:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 13:55:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:25:17 --> Total execution time: 0.1311
DEBUG - 2023-01-17 13:55:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:25:21 --> Total execution time: 0.0752
DEBUG - 2023-01-17 13:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:25:24 --> Total execution time: 0.1475
DEBUG - 2023-01-17 13:58:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:28:17 --> Total execution time: 0.0766
DEBUG - 2023-01-17 13:58:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:28:39 --> Total execution time: 0.0586
DEBUG - 2023-01-17 13:59:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:29:00 --> Total execution time: 0.0688
DEBUG - 2023-01-17 13:59:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:29:21 --> Total execution time: 0.0863
DEBUG - 2023-01-17 13:59:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:29:30 --> Total execution time: 0.0646
DEBUG - 2023-01-17 13:59:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 13:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 13:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 13:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:29:46 --> Total execution time: 0.0673
DEBUG - 2023-01-17 14:00:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:30:31 --> Total execution time: 0.0645
DEBUG - 2023-01-17 14:00:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:30:49 --> Total execution time: 0.0913
DEBUG - 2023-01-17 14:00:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:30:51 --> Total execution time: 0.0677
DEBUG - 2023-01-17 14:00:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:30:53 --> Total execution time: 0.0449
DEBUG - 2023-01-17 14:00:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:30:54 --> Total execution time: 0.0458
DEBUG - 2023-01-17 14:00:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:30:55 --> Total execution time: 0.0760
DEBUG - 2023-01-17 14:00:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:30:57 --> Total execution time: 0.0457
DEBUG - 2023-01-17 14:00:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:31:00 --> Total execution time: 0.0623
DEBUG - 2023-01-17 14:01:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:31:03 --> Total execution time: 0.0450
DEBUG - 2023-01-17 14:01:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:31:04 --> Total execution time: 0.0465
DEBUG - 2023-01-17 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:31:06 --> Total execution time: 0.0466
DEBUG - 2023-01-17 14:01:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:31:08 --> Total execution time: 0.0602
DEBUG - 2023-01-17 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:37:37 --> Total execution time: 0.0717
DEBUG - 2023-01-17 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:37:43 --> Total execution time: 0.0684
DEBUG - 2023-01-17 14:07:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:37:45 --> Total execution time: 0.0477
DEBUG - 2023-01-17 14:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:39:46 --> Total execution time: 0.0813
DEBUG - 2023-01-17 14:09:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:39:46 --> Total execution time: 0.0549
DEBUG - 2023-01-17 14:09:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:39:52 --> Total execution time: 0.0558
DEBUG - 2023-01-17 14:10:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:40:13 --> Total execution time: 0.0607
DEBUG - 2023-01-17 14:10:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:10:19 --> No URI present. Default controller set.
DEBUG - 2023-01-17 14:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:40:19 --> Total execution time: 0.0438
DEBUG - 2023-01-17 14:10:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:40:23 --> Total execution time: 0.0590
DEBUG - 2023-01-17 14:14:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:44:04 --> Total execution time: 0.0815
DEBUG - 2023-01-17 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 14:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 14:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 14:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 18:45:21 --> Total execution time: 0.0976
DEBUG - 2023-01-17 15:48:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:48:25 --> No URI present. Default controller set.
DEBUG - 2023-01-17 15:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 15:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 15:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 20:18:25 --> Total execution time: 0.1323
DEBUG - 2023-01-17 15:48:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 15:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 15:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 20:18:33 --> Total execution time: 0.1420
DEBUG - 2023-01-17 15:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 15:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 15:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 20:18:39 --> Total execution time: 0.0711
DEBUG - 2023-01-17 15:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 15:48:39 --> 404 Page Not Found: Assets/uploads
DEBUG - 2023-01-17 15:48:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:48:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 15:48:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 15:48:46 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-17 15:48:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 15:48:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:48:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 15:48:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 15:48:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:48:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 15:48:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 15:49:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-17 15:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-17 15:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-17 20:19:19 --> Total execution time: 0.1270
DEBUG - 2023-01-17 15:49:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 15:49:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 15:49:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:49:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 15:49:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 15:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 15:49:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-17 15:49:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-17 15:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-17 15:49:19 --> 404 Page Not Found: Assets/website
