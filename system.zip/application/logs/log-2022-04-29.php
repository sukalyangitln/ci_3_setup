<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-29 03:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:42:55 --> No URI present. Default controller set.
DEBUG - 2022-04-29 03:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:12:56 --> Total execution time: 1.3131
DEBUG - 2022-04-29 03:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 03:43:15 --> Total execution time: 0.0441
DEBUG - 2022-04-29 03:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 03:43:15 --> Total execution time: 0.0275
DEBUG - 2022-04-29 03:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 03:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 03:43:18 --> Total execution time: 0.0295
DEBUG - 2022-04-29 03:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 03:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:13:23 --> Total execution time: 0.0886
DEBUG - 2022-04-29 03:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:13:33 --> Total execution time: 0.0478
DEBUG - 2022-04-29 03:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:13:37 --> Total execution time: 0.1371
DEBUG - 2022-04-29 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:13:56 --> Total execution time: 0.1041
DEBUG - 2022-04-29 03:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:15:19 --> Total execution time: 0.8750
DEBUG - 2022-04-29 03:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:15:22 --> Total execution time: 0.0490
DEBUG - 2022-04-29 03:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:16:08 --> Total execution time: 0.4341
DEBUG - 2022-04-29 03:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:17:16 --> Total execution time: 0.9431
DEBUG - 2022-04-29 03:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:19:53 --> Total execution time: 0.8051
DEBUG - 2022-04-29 03:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:20:26 --> Total execution time: 0.8171
DEBUG - 2022-04-29 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:20:51 --> Total execution time: 0.0428
DEBUG - 2022-04-29 03:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:26:38 --> Total execution time: 0.8051
DEBUG - 2022-04-29 03:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:57:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 09:27:44 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::order_buy() /home/gvprods/public_html/v1/gvv3/application/helpers/project_helper.php 243
DEBUG - 2022-04-29 03:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:58:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 09:28:07 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::order_buy() /home/gvprods/public_html/v1/gvv3/application/helpers/project_helper.php 243
DEBUG - 2022-04-29 03:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:58:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 09:28:35 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::order_buy() /home/gvprods/public_html/v1/gvv3/application/helpers/project_helper.php 243
DEBUG - 2022-04-29 03:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 03:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 03:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:29:04 --> Total execution time: 0.0420
DEBUG - 2022-04-29 04:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:35:37 --> Total execution time: 0.8521
DEBUG - 2022-04-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:05:47 --> UTF-8 Support Enabled
ERROR - 2022-04-29 04:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 04:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:05:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 04:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:05:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 04:05:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 04:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:37:24 --> Total execution time: 0.0308
DEBUG - 2022-04-29 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:07:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:07:29 --> 404 Page Not Found: User/my-courses-view
DEBUG - 2022-04-29 04:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:37:31 --> Total execution time: 0.0315
DEBUG - 2022-04-29 04:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:37:49 --> Total execution time: 0.0328
DEBUG - 2022-04-29 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:37:52 --> Total execution time: 0.0327
DEBUG - 2022-04-29 04:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:37:57 --> Total execution time: 0.0297
DEBUG - 2022-04-29 04:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:38:29 --> Total execution time: 0.0444
DEBUG - 2022-04-29 04:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:38:34 --> Total execution time: 0.0413
DEBUG - 2022-04-29 04:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:40:49 --> Total execution time: 0.8211
DEBUG - 2022-04-29 04:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:40:51 --> Total execution time: 0.0667
DEBUG - 2022-04-29 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:10:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:10:55 --> 404 Page Not Found: Admin/request-withdrawal
DEBUG - 2022-04-29 04:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:17:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 04:17:29 --> 404 Page Not Found: Admin/Request_Withdrawal_Controller/index
DEBUG - 2022-04-29 04:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:47:44 --> Total execution time: 0.6067
DEBUG - 2022-04-29 04:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:49:55 --> Total execution time: 0.2306
DEBUG - 2022-04-29 04:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 10:04:16 --> Total execution time: 0.9021
DEBUG - 2022-04-29 04:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 04:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 04:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 10:04:20 --> Total execution time: 0.0564
DEBUG - 2022-04-29 05:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 10:32:16 --> Total execution time: 0.8161
DEBUG - 2022-04-29 05:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:10:41 --> Total execution time: 0.8201
DEBUG - 2022-04-29 05:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:11:16 --> Total execution time: 0.0345
DEBUG - 2022-04-29 05:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:11:18 --> Total execution time: 0.0526
DEBUG - 2022-04-29 05:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:12:19 --> Total execution time: 0.1034
DEBUG - 2022-04-29 05:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:12:22 --> Total execution time: 0.0303
DEBUG - 2022-04-29 05:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:12:35 --> Total execution time: 0.0514
DEBUG - 2022-04-29 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:12:40 --> Total execution time: 0.0309
DEBUG - 2022-04-29 05:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:12:52 --> Total execution time: 0.0288
DEBUG - 2022-04-29 05:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 05:42:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 05:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:12:54 --> Total execution time: 0.0279
DEBUG - 2022-04-29 05:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:13:18 --> Total execution time: 0.0295
DEBUG - 2022-04-29 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:13:20 --> Total execution time: 0.0294
DEBUG - 2022-04-29 05:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 05:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 05:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:13:31 --> Total execution time: 0.0653
DEBUG - 2022-04-29 08:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:10:55 --> Total execution time: 1.2262
DEBUG - 2022-04-29 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 08:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:11:24 --> Total execution time: 0.2076
DEBUG - 2022-04-29 08:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:43:13 --> No URI present. Default controller set.
DEBUG - 2022-04-29 08:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:13:13 --> Total execution time: 0.8011
DEBUG - 2022-04-29 08:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 08:43:37 --> Total execution time: 0.1199
DEBUG - 2022-04-29 08:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 08:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:14:06 --> Total execution time: 0.0849
DEBUG - 2022-04-29 08:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:46:30 --> No URI present. Default controller set.
DEBUG - 2022-04-29 08:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:16:31 --> Total execution time: 0.8842
DEBUG - 2022-04-29 08:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:21:25 --> Total execution time: 0.8322
DEBUG - 2022-04-29 08:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:52:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 14:22:04 --> Severity: error --> Exception: syntax error, unexpected 'Admin' (T_STRING), expecting ')' /home/gvprods/public_html/v1/gvv3/application/views/Admin/inc/sidebar.php 59
DEBUG - 2022-04-29 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:52:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 14:22:36 --> Severity: error --> Exception: syntax error, unexpected 'Admin' (T_STRING), expecting ')' /home/gvprods/public_html/v1/gvv3/application/views/Admin/inc/sidebar.php 59
DEBUG - 2022-04-29 08:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:53:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 14:23:46 --> Severity: error --> Exception: syntax error, unexpected 'Admin' (T_STRING), expecting ')' /home/gvprods/public_html/v1/gvv3/application/views/Admin/inc/sidebar.php 59
DEBUG - 2022-04-29 08:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:23:49 --> Total execution time: 0.0469
DEBUG - 2022-04-29 08:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:53:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 59
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 59
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 65
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_name' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 65
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 73
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_show_name' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 73
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 81
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_contact_no' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 81
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 89
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_whats_app_no' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 89
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 97
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_email' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 97
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 107
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_copyright' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 107
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 115
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_develop_by' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 115
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 117
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_develop_by_link' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 117
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 125
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_logo' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 125
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 127
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 127
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 127
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_logo' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 127
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 137
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_favicon' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 137
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 139
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 139
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 139
ERROR - 2022-04-29 14:23:52 --> Severity: Notice --> Trying to get property 'comp_favicon' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 139
DEBUG - 2022-04-29 14:23:52 --> Total execution time: 0.0474
DEBUG - 2022-04-29 08:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:56:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 14:26:28 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 36
ERROR - 2022-04-29 14:26:28 --> Severity: Notice --> Trying to get property 'comp_favicon' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 36
ERROR - 2022-04-29 14:26:28 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 37
ERROR - 2022-04-29 14:26:28 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 37
ERROR - 2022-04-29 14:26:28 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 37
ERROR - 2022-04-29 14:26:28 --> Severity: Notice --> Trying to get property 'comp_favicon' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 37
DEBUG - 2022-04-29 14:26:28 --> Total execution time: 0.8291
DEBUG - 2022-04-29 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:56:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 14:26:47 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 37
ERROR - 2022-04-29 14:26:47 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 37
ERROR - 2022-04-29 14:26:47 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 37
ERROR - 2022-04-29 14:26:47 --> Severity: Notice --> Trying to get property 'comp_favicon' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/home_page_banner.php 37
DEBUG - 2022-04-29 14:26:47 --> Total execution time: 0.0496
DEBUG - 2022-04-29 08:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:27:26 --> Total execution time: 0.4382
DEBUG - 2022-04-29 08:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:28:05 --> Total execution time: 0.8091
DEBUG - 2022-04-29 08:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:28:07 --> Total execution time: 0.0705
DEBUG - 2022-04-29 08:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:28:59 --> Total execution time: 0.8331
DEBUG - 2022-04-29 08:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 08:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 08:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:29:04 --> Total execution time: 0.8871
DEBUG - 2022-04-29 09:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:30:42 --> Total execution time: 0.9731
DEBUG - 2022-04-29 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:30:54 --> Total execution time: 0.0309
DEBUG - 2022-04-29 09:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:33:49 --> Total execution time: 0.8601
DEBUG - 2022-04-29 09:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:04:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:04:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:04:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:04:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:04:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:04:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:04:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:04:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:35:13 --> Total execution time: 0.9083
DEBUG - 2022-04-29 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 09:05:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:35:23 --> Total execution time: 0.2952
DEBUG - 2022-04-29 09:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 09:05:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:35:34 --> Total execution time: 0.8721
DEBUG - 2022-04-29 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:05:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:36:03 --> Total execution time: 0.8251
DEBUG - 2022-04-29 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:06:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 09:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:06:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 09:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:06:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:06:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:06:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 09:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:36:22 --> Total execution time: 0.8171
DEBUG - 2022-04-29 09:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:40:23 --> Total execution time: 0.7742
DEBUG - 2022-04-29 09:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:10:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:10:39 --> 404 Page Not Found: Admin/site-settings
DEBUG - 2022-04-29 09:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:41:13 --> Total execution time: 0.0302
DEBUG - 2022-04-29 09:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:41:19 --> Total execution time: 0.0293
DEBUG - 2022-04-29 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:11:32 --> 404 Page Not Found: Admin/site-settings
DEBUG - 2022-04-29 09:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:42:19 --> Total execution time: 0.6631
DEBUG - 2022-04-29 09:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:42:22 --> Total execution time: 0.0308
DEBUG - 2022-04-29 09:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 09:12:35 --> 404 Page Not Found: Admin/site-settings
DEBUG - 2022-04-29 09:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:42:45 --> Total execution time: 0.0307
DEBUG - 2022-04-29 09:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:42:48 --> Total execution time: 0.0282
DEBUG - 2022-04-29 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:12:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 14:42:57 --> Severity: Notice --> Undefined property: Homepage_Settings::$User_logins /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/settings/Homepage_Settings.php 22
ERROR - 2022-04-29 14:42:57 --> Severity: error --> Exception: Call to a member function check() on null /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/settings/Homepage_Settings.php 22
ERROR - 2022-04-29 14:42:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-04-29 09:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:43:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-29 14:43:24 --> Total execution time: 0.6450
DEBUG - 2022-04-29 09:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:46:39 --> Total execution time: 0.8441
DEBUG - 2022-04-29 09:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:47:27 --> Total execution time: 0.8011
DEBUG - 2022-04-29 09:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:47:33 --> Total execution time: 0.0300
DEBUG - 2022-04-29 09:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:47:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-29 09:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:47:45 --> Total execution time: 0.0533
DEBUG - 2022-04-29 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:51:23 --> Total execution time: 0.8561
DEBUG - 2022-04-29 09:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:26:21 --> No URI present. Default controller set.
DEBUG - 2022-04-29 09:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:56:22 --> Total execution time: 0.8633
DEBUG - 2022-04-29 09:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:58:41 --> Total execution time: 0.0565
DEBUG - 2022-04-29 09:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:28:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 14:58:45 --> Severity: error --> Exception: Call to undefined method Homepage_Settings::unlink() /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/settings/Homepage_Settings.php 52
DEBUG - 2022-04-29 09:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 09:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:59:11 --> Total execution time: 0.0338
DEBUG - 2022-04-29 09:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:59:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-29 09:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:59:24 --> Total execution time: 0.0300
DEBUG - 2022-04-29 09:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:00:11 --> Total execution time: 0.0305
DEBUG - 2022-04-29 09:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 09:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 09:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:00:14 --> Total execution time: 0.0283
DEBUG - 2022-04-29 10:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:49:33 --> Total execution time: 1.0934
DEBUG - 2022-04-29 10:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:49:47 --> Total execution time: 0.0433
DEBUG - 2022-04-29 10:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:49:56 --> Total execution time: 0.0287
DEBUG - 2022-04-29 10:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:49:59 --> Total execution time: 0.0310
DEBUG - 2022-04-29 10:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:50:07 --> Total execution time: 0.1230
DEBUG - 2022-04-29 10:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:50:20 --> Total execution time: 0.0354
DEBUG - 2022-04-29 10:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:50:30 --> Total execution time: 0.0576
DEBUG - 2022-04-29 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:50:43 --> Total execution time: 0.0299
DEBUG - 2022-04-29 10:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:50:52 --> Total execution time: 0.0405
DEBUG - 2022-04-29 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:58:56 --> Total execution time: 0.8281
DEBUG - 2022-04-29 10:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:29:06 --> No URI present. Default controller set.
DEBUG - 2022-04-29 10:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:59:06 --> Total execution time: 0.0777
DEBUG - 2022-04-29 10:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:29:08 --> No URI present. Default controller set.
DEBUG - 2022-04-29 10:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:59:08 --> Total execution time: 0.0373
DEBUG - 2022-04-29 10:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 10:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 10:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:07:19 --> Total execution time: 0.8271
DEBUG - 2022-04-29 11:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:53:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 11:53:33 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 25
ERROR - 2022-04-29 11:53:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-04-29 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:53:40 --> Total execution time: 0.6483
DEBUG - 2022-04-29 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:53:44 --> Total execution time: 0.0319
DEBUG - 2022-04-29 11:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:23:51 --> Total execution time: 0.1568
DEBUG - 2022-04-29 11:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:54:02 --> No URI present. Default controller set.
DEBUG - 2022-04-29 11:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:24:02 --> Total execution time: 0.4143
DEBUG - 2022-04-29 11:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:58:40 --> No URI present. Default controller set.
DEBUG - 2022-04-29 11:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:28:41 --> Total execution time: 0.8322
DEBUG - 2022-04-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 11:59:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 11:59:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 11:59:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 11:59:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 11:59:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 11:59:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 11:59:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 11:59:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 11:59:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:00:06 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:30:06 --> Total execution time: 0.6229
DEBUG - 2022-04-29 12:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:31:05 --> Total execution time: 0.8992
DEBUG - 2022-04-29 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:01:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:31:41 --> Total execution time: 0.7409
DEBUG - 2022-04-29 12:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:01:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:01:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:32:05 --> Total execution time: 0.0300
DEBUG - 2022-04-29 12:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:32:37 --> Total execution time: 0.0316
DEBUG - 2022-04-29 12:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:02:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:33:32 --> Total execution time: 0.8171
DEBUG - 2022-04-29 12:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:03:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:03:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:03:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:04:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:04:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:30 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:34:31 --> Total execution time: 0.8442
DEBUG - 2022-04-29 12:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:34:35 --> Total execution time: 0.0468
DEBUG - 2022-04-29 12:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:34:44 --> Total execution time: 0.0804
DEBUG - 2022-04-29 12:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:04:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:35:21 --> Total execution time: 0.8171
DEBUG - 2022-04-29 12:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:35:44 --> Total execution time: 0.0531
DEBUG - 2022-04-29 12:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:35:44 --> Total execution time: 0.0280
DEBUG - 2022-04-29 12:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:35:49 --> Total execution time: 0.0540
DEBUG - 2022-04-29 12:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:35:51 --> Total execution time: 0.0292
DEBUG - 2022-04-29 12:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:38:47 --> Total execution time: 0.7842
DEBUG - 2022-04-29 12:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:44:48 --> Total execution time: 0.8122
DEBUG - 2022-04-29 12:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:44:53 --> Total execution time: 0.0350
DEBUG - 2022-04-29 12:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:45:09 --> Total execution time: 0.0302
DEBUG - 2022-04-29 12:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:02:53 --> Total execution time: 0.0638
DEBUG - 2022-04-29 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:02:59 --> Total execution time: 0.1536
DEBUG - 2022-04-29 12:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:05:15 --> Total execution time: 0.8751
DEBUG - 2022-04-29 12:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:05:20 --> Total execution time: 0.0709
DEBUG - 2022-04-29 12:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:05:25 --> Total execution time: 0.0289
DEBUG - 2022-04-29 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:35:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:35:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:35:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:35:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:35:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:35:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:35:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:35:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:06:13 --> Total execution time: 0.0933
DEBUG - 2022-04-29 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:36:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:36:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:36:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:36:16 --> UTF-8 Support Enabled
ERROR - 2022-04-29 12:36:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:36:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:36:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:36:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:36:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:06:17 --> Total execution time: 0.0295
DEBUG - 2022-04-29 12:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:07:29 --> Total execution time: 0.0835
DEBUG - 2022-04-29 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:37:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:37:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:37:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:37:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:37:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:37:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:37:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:37:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 12:37:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:07:34 --> Total execution time: 0.0305
DEBUG - 2022-04-29 12:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:08:15 --> Total execution time: 0.0678
DEBUG - 2022-04-29 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:08:20 --> Total execution time: 0.0377
DEBUG - 2022-04-29 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:38:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:38:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:38:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:38:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:38:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:38:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:38:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:38:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:08:37 --> Total execution time: 0.0293
DEBUG - 2022-04-29 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:09:01 --> Total execution time: 0.7805
DEBUG - 2022-04-29 12:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:09:05 --> Total execution time: 0.0356
DEBUG - 2022-04-29 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:39 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:09:39 --> Total execution time: 0.0833
DEBUG - 2022-04-29 12:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:09:41 --> Total execution time: 0.0639
DEBUG - 2022-04-29 12:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:09:44 --> Total execution time: 0.0286
DEBUG - 2022-04-29 12:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:39:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:09:48 --> Total execution time: 0.0423
DEBUG - 2022-04-29 12:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:39:48 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:09:48 --> Total execution time: 0.0292
DEBUG - 2022-04-29 12:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:06 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:10:07 --> Total execution time: 0.7923
DEBUG - 2022-04-29 12:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:10:41 --> Total execution time: 0.0638
DEBUG - 2022-04-29 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:10:45 --> Total execution time: 0.0328
DEBUG - 2022-04-29 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:10:53 --> Total execution time: 0.0306
DEBUG - 2022-04-29 12:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:11:29 --> Total execution time: 0.1127
DEBUG - 2022-04-29 12:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:11:48 --> Total execution time: 0.0306
DEBUG - 2022-04-29 12:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:11:56 --> Total execution time: 0.0318
DEBUG - 2022-04-29 12:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:12:08 --> Total execution time: 0.7239
DEBUG - 2022-04-29 12:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:42:17 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:12:17 --> Total execution time: 0.0322
DEBUG - 2022-04-29 12:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:12:24 --> Total execution time: 0.0280
DEBUG - 2022-04-29 12:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:42:30 --> 404 Page Not Found: Testimonial/index
DEBUG - 2022-04-29 12:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:12:42 --> Total execution time: 0.0585
DEBUG - 2022-04-29 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:42:54 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:12:54 --> Total execution time: 0.0297
DEBUG - 2022-04-29 12:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:15:52 --> Total execution time: 0.8291
DEBUG - 2022-04-29 12:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:15:55 --> Total execution time: 0.0277
DEBUG - 2022-04-29 12:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:46:32 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:16:32 --> Total execution time: 0.0827
DEBUG - 2022-04-29 12:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:21 --> Total execution time: 0.0516
DEBUG - 2022-04-29 12:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:22 --> Total execution time: 0.0782
DEBUG - 2022-04-29 12:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:22 --> Total execution time: 0.0302
DEBUG - 2022-04-29 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:34 --> Total execution time: 0.0979
DEBUG - 2022-04-29 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:34 --> Total execution time: 0.0875
DEBUG - 2022-04-29 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:34 --> Total execution time: 0.0826
DEBUG - 2022-04-29 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:34 --> Total execution time: 0.0289
DEBUG - 2022-04-29 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:34 --> Total execution time: 0.0316
DEBUG - 2022-04-29 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:34 --> Total execution time: 0.0322
DEBUG - 2022-04-29 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:35 --> Total execution time: 0.0586
DEBUG - 2022-04-29 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:47:35 --> Total execution time: 0.0287
DEBUG - 2022-04-29 12:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:47:41 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:17:41 --> Total execution time: 0.0313
DEBUG - 2022-04-29 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:48:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:48:15 --> 404 Page Not Found: Testimonial/index
DEBUG - 2022-04-29 12:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:48:22 --> No URI present. Default controller set.
DEBUG - 2022-04-29 12:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:18:22 --> Total execution time: 0.0325
DEBUG - 2022-04-29 12:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:21:23 --> Total execution time: 0.7791
DEBUG - 2022-04-29 12:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:21:47 --> Total execution time: 0.1027
DEBUG - 2022-04-29 12:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:22:17 --> Total execution time: 0.0307
DEBUG - 2022-04-29 12:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:23:08 --> Total execution time: 0.0325
DEBUG - 2022-04-29 12:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:23:18 --> Total execution time: 0.0312
DEBUG - 2022-04-29 12:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:24:34 --> Total execution time: 0.0322
DEBUG - 2022-04-29 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:26:07 --> Total execution time: 0.0728
DEBUG - 2022-04-29 12:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:26:12 --> Total execution time: 0.0315
DEBUG - 2022-04-29 12:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 12:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:26:33 --> Total execution time: 0.0297
DEBUG - 2022-04-29 12:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 12:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:26:34 --> Total execution time: 0.0321
DEBUG - 2022-04-29 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:57:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:57:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:57:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:57:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:57:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:57:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:57:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:57:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:57:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:57:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:57:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 12:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 12:57:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:36:22 --> Total execution time: 0.8363
DEBUG - 2022-04-29 13:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:36:29 --> Total execution time: 0.0290
DEBUG - 2022-04-29 13:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:36:31 --> Total execution time: 0.0328
DEBUG - 2022-04-29 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:36:48 --> Total execution time: 0.0292
DEBUG - 2022-04-29 13:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:36:51 --> Total execution time: 0.0296
DEBUG - 2022-04-29 13:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:36:54 --> Total execution time: 0.0337
DEBUG - 2022-04-29 13:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:37:20 --> Total execution time: 0.0573
DEBUG - 2022-04-29 13:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:37:27 --> Total execution time: 0.0352
DEBUG - 2022-04-29 13:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:38:25 --> Total execution time: 0.0314
DEBUG - 2022-04-29 13:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:38:49 --> Total execution time: 0.0347
DEBUG - 2022-04-29 13:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:38:53 --> Total execution time: 0.0319
DEBUG - 2022-04-29 13:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:40:39 --> Total execution time: 0.0292
DEBUG - 2022-04-29 13:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:41:04 --> Total execution time: 0.0326
DEBUG - 2022-04-29 13:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:41:19 --> Total execution time: 0.0392
DEBUG - 2022-04-29 13:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:41:21 --> Total execution time: 0.0282
DEBUG - 2022-04-29 13:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:43:05 --> Total execution time: 0.0318
DEBUG - 2022-04-29 13:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:43:58 --> Total execution time: 0.0307
DEBUG - 2022-04-29 13:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:44:00 --> Total execution time: 0.0291
DEBUG - 2022-04-29 13:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:44:02 --> Total execution time: 0.0296
DEBUG - 2022-04-29 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:44:05 --> Total execution time: 0.0344
DEBUG - 2022-04-29 13:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:44:25 --> Total execution time: 0.0468
DEBUG - 2022-04-29 13:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:14:30 --> No URI present. Default controller set.
DEBUG - 2022-04-29 13:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:44:30 --> Total execution time: 0.0556
DEBUG - 2022-04-29 13:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:44:33 --> Total execution time: 0.0312
DEBUG - 2022-04-29 13:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:14:43 --> 404 Page Not Found: Testimonial/index
DEBUG - 2022-04-29 13:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:14:44 --> No URI present. Default controller set.
DEBUG - 2022-04-29 13:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:44:44 --> Total execution time: 0.0286
DEBUG - 2022-04-29 13:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:16:06 --> No URI present. Default controller set.
DEBUG - 2022-04-29 13:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:46:06 --> Total execution time: 0.0317
DEBUG - 2022-04-29 13:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:17:25 --> No URI present. Default controller set.
DEBUG - 2022-04-29 13:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:47:26 --> Total execution time: 0.0348
DEBUG - 2022-04-29 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:18:28 --> No URI present. Default controller set.
DEBUG - 2022-04-29 13:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:48:28 --> Total execution time: 0.0342
DEBUG - 2022-04-29 13:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:49:06 --> Total execution time: 0.0308
DEBUG - 2022-04-29 13:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:49:07 --> Total execution time: 0.0526
DEBUG - 2022-04-29 13:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:56:06 --> Total execution time: 0.8091
DEBUG - 2022-04-29 13:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:56:09 --> Total execution time: 0.0314
DEBUG - 2022-04-29 13:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 18:56:26 --> Total execution time: 0.0284
DEBUG - 2022-04-29 13:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:09:57 --> Total execution time: 0.8081
DEBUG - 2022-04-29 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:10:43 --> Total execution time: 0.0345
DEBUG - 2022-04-29 13:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:06 --> Total execution time: 0.0383
DEBUG - 2022-04-29 13:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:12:16 --> Total execution time: 0.0358
DEBUG - 2022-04-29 13:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:13:21 --> Total execution time: 0.0365
DEBUG - 2022-04-29 13:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:43:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:14:36 --> Total execution time: 0.0575
DEBUG - 2022-04-29 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:44:37 --> UTF-8 Support Enabled
ERROR - 2022-04-29 13:44:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:44:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:44:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:44:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 13:44:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 13:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:15:21 --> Total execution time: 0.0375
DEBUG - 2022-04-29 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 13:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:17:20 --> Total execution time: 0.0350
DEBUG - 2022-04-29 13:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:25:28 --> Total execution time: 0.8051
DEBUG - 2022-04-29 13:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:26:00 --> Total execution time: 0.0298
DEBUG - 2022-04-29 13:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 13:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 13:56:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 19:26:04 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/admin-commission-setting.php 30
ERROR - 2022-04-29 19:26:04 --> Severity: Notice --> Trying to get property 'comp_id' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/admin-commission-setting.php 30
ERROR - 2022-04-29 19:26:04 --> Severity: Notice --> Undefined variable: profile /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/admin-commission-setting.php 33
ERROR - 2022-04-29 19:26:04 --> Severity: Notice --> Trying to get property 'comp_name' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/settings/admin-commission-setting.php 33
DEBUG - 2022-04-29 19:26:04 --> Total execution time: 0.0470
DEBUG - 2022-04-29 14:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:31:09 --> Total execution time: 0.1336
DEBUG - 2022-04-29 14:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:32:09 --> Total execution time: 0.0300
DEBUG - 2022-04-29 14:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:34:43 --> Total execution time: 0.8251
DEBUG - 2022-04-29 14:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:34:50 --> Total execution time: 0.0298
DEBUG - 2022-04-29 14:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:34:59 --> Total execution time: 0.0297
DEBUG - 2022-04-29 14:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:35:07 --> Total execution time: 0.0326
DEBUG - 2022-04-29 14:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:36:46 --> Total execution time: 0.0672
DEBUG - 2022-04-29 14:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:37:21 --> Total execution time: 0.0317
DEBUG - 2022-04-29 14:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:37:24 --> Total execution time: 0.0319
DEBUG - 2022-04-29 14:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:37:44 --> Total execution time: 0.0306
DEBUG - 2022-04-29 14:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:37:51 --> Total execution time: 0.0287
DEBUG - 2022-04-29 14:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:39:22 --> Total execution time: 0.8342
DEBUG - 2022-04-29 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:39:26 --> Total execution time: 0.0395
DEBUG - 2022-04-29 14:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:44:39 --> Total execution time: 0.9043
DEBUG - 2022-04-29 14:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:47:21 --> Total execution time: 0.8214
DEBUG - 2022-04-29 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:49:13 --> Total execution time: 1.2041
DEBUG - 2022-04-29 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:50:27 --> Total execution time: 0.8162
DEBUG - 2022-04-29 14:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:53:45 --> Total execution time: 0.8201
DEBUG - 2022-04-29 14:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:54:03 --> Total execution time: 0.5290
DEBUG - 2022-04-29 14:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:54:20 --> Total execution time: 0.5226
DEBUG - 2022-04-29 14:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:54:22 --> Total execution time: 0.1191
DEBUG - 2022-04-29 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:25:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:25:38 --> 404 Page Not Found: User/index
DEBUG - 2022-04-29 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:55:39 --> Total execution time: 0.6077
DEBUG - 2022-04-29 14:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:25:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:25:40 --> 404 Page Not Found: User/l
DEBUG - 2022-04-29 14:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:59:57 --> Total execution time: 1.0519
DEBUG - 2022-04-29 14:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:00:00 --> Total execution time: 0.1078
DEBUG - 2022-04-29 14:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:00:10 --> Total execution time: 0.0342
DEBUG - 2022-04-29 14:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:00:46 --> Total execution time: 0.0309
DEBUG - 2022-04-29 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:31:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-29 14:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:01:52 --> Total execution time: 0.6210
DEBUG - 2022-04-29 14:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:03:41 --> Total execution time: 0.8241
DEBUG - 2022-04-29 14:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:04:02 --> Total execution time: 0.0329
DEBUG - 2022-04-29 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:04:23 --> Total execution time: 0.6360
DEBUG - 2022-04-29 14:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:04:26 --> Total execution time: 0.0332
DEBUG - 2022-04-29 14:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:04:37 --> Total execution time: 0.2666
DEBUG - 2022-04-29 14:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:34:42 --> UTF-8 Support Enabled
ERROR - 2022-04-29 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 14:34:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 14:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:04:53 --> Total execution time: 0.8442
DEBUG - 2022-04-29 14:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:05:36 --> Total execution time: 1.1061
DEBUG - 2022-04-29 14:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:07:14 --> Total execution time: 0.8482
DEBUG - 2022-04-29 14:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:07:20 --> Total execution time: 0.0690
DEBUG - 2022-04-29 14:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:07:24 --> Total execution time: 0.0370
DEBUG - 2022-04-29 14:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:27:28 --> Total execution time: 0.9502
DEBUG - 2022-04-29 14:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:27:47 --> Total execution time: 0.0843
DEBUG - 2022-04-29 14:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:28:01 --> Total execution time: 0.1230
DEBUG - 2022-04-29 14:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 14:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:29:10 --> Total execution time: 0.0908
DEBUG - 2022-04-29 14:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 14:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 14:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:29:22 --> Total execution time: 0.0549
DEBUG - 2022-04-29 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:09:56 --> No URI present. Default controller set.
DEBUG - 2022-04-29 15:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:39:57 --> Total execution time: 0.9469
DEBUG - 2022-04-29 15:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:10:10 --> No URI present. Default controller set.
DEBUG - 2022-04-29 15:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:40:10 --> Total execution time: 0.0355
DEBUG - 2022-04-29 15:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 15:10:30 --> 404 Page Not Found: User/index
DEBUG - 2022-04-29 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:10:45 --> No URI present. Default controller set.
DEBUG - 2022-04-29 15:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:40:45 --> Total execution time: 0.0308
DEBUG - 2022-04-29 15:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:41:05 --> Total execution time: 0.1403
DEBUG - 2022-04-29 15:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:07 --> No URI present. Default controller set.
DEBUG - 2022-04-29 15:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:41:07 --> Total execution time: 0.0306
DEBUG - 2022-04-29 15:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:41:22 --> Total execution time: 0.0613
DEBUG - 2022-04-29 15:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:11:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 15:11:25 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 49
ERROR - 2022-04-29 15:11:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-04-29 15:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 15:11:41 --> 404 Page Not Found: User/index
DEBUG - 2022-04-29 15:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 15:11:42 --> 404 Page Not Found: User/lo
DEBUG - 2022-04-29 15:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 15:11:42 --> 404 Page Not Found: User/log
DEBUG - 2022-04-29 15:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 15:11:42 --> 404 Page Not Found: User/logi
DEBUG - 2022-04-29 15:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:41:43 --> Total execution time: 0.0360
DEBUG - 2022-04-29 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:15:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 15:15:17 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 25
ERROR - 2022-04-29 15:15:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-04-29 15:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:16:56 --> No URI present. Default controller set.
DEBUG - 2022-04-29 15:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:46:56 --> Total execution time: 0.0770
DEBUG - 2022-04-29 15:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:48:52 --> Total execution time: 0.1660
DEBUG - 2022-04-29 15:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 15:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:49:03 --> Total execution time: 0.0604
DEBUG - 2022-04-29 15:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 15:19:47 --> 404 Page Not Found: User/leaderboard
DEBUG - 2022-04-29 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:49:50 --> Total execution time: 0.0344
DEBUG - 2022-04-29 15:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:52:27 --> Total execution time: 0.2245
DEBUG - 2022-04-29 15:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:54:55 --> Total execution time: 0.2003
DEBUG - 2022-04-29 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:55:03 --> Total execution time: 0.0352
DEBUG - 2022-04-29 15:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 15:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 15:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:29:21 --> Total execution time: 0.8241
DEBUG - 2022-04-29 16:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:31:24 --> Total execution time: 0.0317
DEBUG - 2022-04-29 16:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:31:36 --> Total execution time: 0.0332
DEBUG - 2022-04-29 16:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:31:43 --> Total execution time: 0.0309
DEBUG - 2022-04-29 16:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:36:16 --> Total execution time: 0.8241
DEBUG - 2022-04-29 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:10:33 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:40:34 --> Total execution time: 0.4801
DEBUG - 2022-04-29 16:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:40:50 --> Total execution time: 0.0311
DEBUG - 2022-04-29 16:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:10:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 21:40:54 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) /home/gvprods/public_html/v1/gvv3/application/views/Admin/users/user_profile.php 426
DEBUG - 2022-04-29 16:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:11:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 21:41:11 --> Severity: Notice --> Undefined property: CI_Loader::$User_joins /home/gvprods/public_html/v1/gvv3/application/views/Admin/users/user_profile.php 426
ERROR - 2022-04-29 21:41:11 --> Severity: error --> Exception: Call to a member function get_direct_downline() on null /home/gvprods/public_html/v1/gvv3/application/views/Admin/users/user_profile.php 426
DEBUG - 2022-04-29 16:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:41:14 --> Total execution time: 0.0666
DEBUG - 2022-04-29 16:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:11:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 21:41:24 --> Severity: Notice --> Undefined property: CI_Loader::$User_joins /home/gvprods/public_html/v1/gvv3/application/views/Admin/users/user_profile.php 426
ERROR - 2022-04-29 21:41:24 --> Severity: error --> Exception: Call to a member function get_direct_downline() on null /home/gvprods/public_html/v1/gvv3/application/views/Admin/users/user_profile.php 426
DEBUG - 2022-04-29 16:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:11:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 21:41:28 --> Severity: Notice --> Undefined property: CI_Loader::$User_joins /home/gvprods/public_html/v1/gvv3/application/views/Admin/users/user_profile.php 426
ERROR - 2022-04-29 21:41:28 --> Severity: error --> Exception: Call to a member function get_direct_downline() on null /home/gvprods/public_html/v1/gvv3/application/views/Admin/users/user_profile.php 426
DEBUG - 2022-04-29 16:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:11:35 --> Total execution time: 0.0325
DEBUG - 2022-04-29 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:41:43 --> Total execution time: 0.0375
DEBUG - 2022-04-29 16:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:41:48 --> Total execution time: 0.0338
DEBUG - 2022-04-29 16:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:42:04 --> Total execution time: 0.0396
DEBUG - 2022-04-29 16:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:13:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 16:13:16 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 25
ERROR - 2022-04-29 16:13:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-04-29 16:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:13:19 --> Total execution time: 0.0280
DEBUG - 2022-04-29 16:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:13:29 --> Total execution time: 0.0306
DEBUG - 2022-04-29 16:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:13:45 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:43:45 --> Total execution time: 0.0777
DEBUG - 2022-04-29 16:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:43:45 --> Total execution time: 0.0298
DEBUG - 2022-04-29 16:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:43:59 --> Total execution time: 0.0300
DEBUG - 2022-04-29 16:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:44:10 --> Total execution time: 0.0294
DEBUG - 2022-04-29 16:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:44:22 --> Total execution time: 0.0329
DEBUG - 2022-04-29 16:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:14:25 --> 404 Page Not Found: U/index
DEBUG - 2022-04-29 16:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:44:27 --> Total execution time: 0.0496
DEBUG - 2022-04-29 16:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:44:41 --> Total execution time: 0.0310
DEBUG - 2022-04-29 16:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:45:07 --> Total execution time: 0.0359
DEBUG - 2022-04-29 16:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:45:13 --> Total execution time: 0.0370
DEBUG - 2022-04-29 16:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:45:17 --> Total execution time: 0.0478
DEBUG - 2022-04-29 16:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:15:54 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:45:54 --> Total execution time: 0.0311
DEBUG - 2022-04-29 16:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:16:30 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:46:30 --> Total execution time: 0.0327
DEBUG - 2022-04-29 16:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:47:53 --> Total execution time: 0.0416
DEBUG - 2022-04-29 16:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:50:09 --> Total execution time: 0.7944
DEBUG - 2022-04-29 16:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:52:23 --> Total execution time: 0.0644
DEBUG - 2022-04-29 16:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:52:29 --> Total execution time: 0.0374
DEBUG - 2022-04-29 16:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:22:41 --> 404 Page Not Found: User/leaderboard
DEBUG - 2022-04-29 16:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:52:43 --> Total execution time: 0.0314
DEBUG - 2022-04-29 16:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:52:49 --> Total execution time: 0.0413
DEBUG - 2022-04-29 16:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:53:06 --> Total execution time: 0.0315
DEBUG - 2022-04-29 16:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:53:12 --> Total execution time: 0.0339
DEBUG - 2022-04-29 16:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:53:22 --> Total execution time: 0.0413
DEBUG - 2022-04-29 16:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:53:53 --> Total execution time: 0.0316
DEBUG - 2022-04-29 16:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:23:54 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:53:55 --> Total execution time: 0.0847
DEBUG - 2022-04-29 16:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:54:03 --> Total execution time: 0.0431
DEBUG - 2022-04-29 16:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:24:27 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:54:27 --> Total execution time: 0.0313
DEBUG - 2022-04-29 16:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:55:10 --> Total execution time: 0.0411
DEBUG - 2022-04-29 16:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:25:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:25:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:55:43 --> Total execution time: 0.0349
DEBUG - 2022-04-29 16:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:55:51 --> Total execution time: 0.0319
DEBUG - 2022-04-29 16:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:56:17 --> Total execution time: 0.0297
DEBUG - 2022-04-29 16:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:56:26 --> Total execution time: 0.0315
DEBUG - 2022-04-29 16:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:56:32 --> Total execution time: 0.0411
DEBUG - 2022-04-29 16:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:56:45 --> Total execution time: 0.0313
DEBUG - 2022-04-29 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:56:54 --> Total execution time: 0.0369
DEBUG - 2022-04-29 16:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:56:56 --> Total execution time: 0.4992
DEBUG - 2022-04-29 16:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:26:56 --> UTF-8 Support Enabled
ERROR - 2022-04-29 16:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:57:46 --> Total execution time: 0.0390
DEBUG - 2022-04-29 16:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:58:00 --> Total execution time: 0.0347
DEBUG - 2022-04-29 16:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:58:09 --> Total execution time: 0.0322
DEBUG - 2022-04-29 16:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:58:14 --> Total execution time: 0.0290
DEBUG - 2022-04-29 16:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:58:43 --> Total execution time: 0.0368
DEBUG - 2022-04-29 16:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:00:50 --> Total execution time: 0.0800
DEBUG - 2022-04-29 16:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:01:23 --> Total execution time: 0.0329
DEBUG - 2022-04-29 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:32:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:32:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-29 16:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:03:37 --> Total execution time: 0.0798
DEBUG - 2022-04-29 16:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:03:52 --> Total execution time: 0.0293
DEBUG - 2022-04-29 16:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:34:05 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:04:05 --> Total execution time: 0.0551
DEBUG - 2022-04-29 16:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:34:12 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:04:12 --> Total execution time: 0.0332
DEBUG - 2022-04-29 16:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:34:46 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:04:46 --> Total execution time: 0.0572
DEBUG - 2022-04-29 16:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:35:03 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:05:03 --> Total execution time: 0.0312
DEBUG - 2022-04-29 16:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:36:17 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:06:17 --> Total execution time: 0.0323
DEBUG - 2022-04-29 16:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:38:03 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:08:03 --> Total execution time: 0.0384
DEBUG - 2022-04-29 16:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:38:28 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:08:28 --> Total execution time: 0.0418
DEBUG - 2022-04-29 16:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:38:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:38:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:38:55 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:08:55 --> Total execution time: 0.0344
DEBUG - 2022-04-29 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:38:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:38:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:06 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:09:06 --> Total execution time: 0.0302
DEBUG - 2022-04-29 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:39:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:39:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:16 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:09:16 --> Total execution time: 0.0320
DEBUG - 2022-04-29 16:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:39:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:39:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:39:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:53 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:09:53 --> Total execution time: 0.0391
DEBUG - 2022-04-29 16:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:39:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 16:39:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-04-29 16:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:40:13 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:10:13 --> Total execution time: 0.0343
DEBUG - 2022-04-29 16:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:41:11 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:11:11 --> Total execution time: 0.0312
DEBUG - 2022-04-29 16:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:41:57 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:11:57 --> Total execution time: 0.0325
DEBUG - 2022-04-29 16:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:12:00 --> Total execution time: 0.0388
DEBUG - 2022-04-29 16:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:12:29 --> Total execution time: 0.0330
DEBUG - 2022-04-29 16:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:12:30 --> Total execution time: 0.0331
DEBUG - 2022-04-29 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:12:34 --> Total execution time: 0.0336
DEBUG - 2022-04-29 16:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:43:38 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:13:38 --> Total execution time: 0.0302
DEBUG - 2022-04-29 16:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:44:35 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:14:35 --> Total execution time: 0.0333
DEBUG - 2022-04-29 16:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:45:38 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:15:38 --> Total execution time: 0.0572
DEBUG - 2022-04-29 16:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:48:20 --> No URI present. Default controller set.
DEBUG - 2022-04-29 16:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:18:21 --> Total execution time: 0.8010
DEBUG - 2022-04-29 16:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:19:13 --> Total execution time: 0.0728
DEBUG - 2022-04-29 16:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 16:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:19:24 --> Total execution time: 0.0421
DEBUG - 2022-04-29 16:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 16:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 16:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:20:20 --> Total execution time: 0.0373
DEBUG - 2022-04-29 17:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:53:57 --> Total execution time: 0.1408
DEBUG - 2022-04-29 17:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:54:29 --> Total execution time: 0.0738
DEBUG - 2022-04-29 17:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:25:19 --> Total execution time: 0.8012
DEBUG - 2022-04-29 17:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:26:04 --> Total execution time: 0.6531
DEBUG - 2022-04-29 17:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:26:05 --> Total execution time: 0.0327
DEBUG - 2022-04-29 17:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:26:05 --> Total execution time: 0.0766
DEBUG - 2022-04-29 17:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:26:11 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:56:11 --> Total execution time: 0.0460
DEBUG - 2022-04-29 17:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:28:19 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 17:28:19 --> Total execution time: 0.6879
DEBUG - 2022-04-29 17:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:58:19 --> Total execution time: 0.6966
DEBUG - 2022-04-29 17:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:29:55 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 22:59:55 --> Total execution time: 0.3087
DEBUG - 2022-04-29 17:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:30:48 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:00:48 --> Total execution time: 0.2557
DEBUG - 2022-04-29 17:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:31:52 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:01:53 --> Total execution time: 0.1481
DEBUG - 2022-04-29 17:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:32:03 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:02:03 --> Total execution time: 0.0849
DEBUG - 2022-04-29 17:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:32:04 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:02:04 --> Total execution time: 0.0332
DEBUG - 2022-04-29 17:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:33:02 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:03:02 --> Total execution time: 0.0336
DEBUG - 2022-04-29 17:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:34:15 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:04:15 --> Total execution time: 0.0371
DEBUG - 2022-04-29 17:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:36:11 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:06:12 --> Total execution time: 0.2424
DEBUG - 2022-04-29 17:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:36:26 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:06:26 --> Total execution time: 0.0308
DEBUG - 2022-04-29 17:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:41:11 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:11:12 --> Total execution time: 0.9101
DEBUG - 2022-04-29 17:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:41:45 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:11:45 --> Total execution time: 0.0311
DEBUG - 2022-04-29 17:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:12:13 --> Total execution time: 0.0321
DEBUG - 2022-04-29 17:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:42:22 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:12:22 --> Total execution time: 0.0297
DEBUG - 2022-04-29 17:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:47:16 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:17:17 --> Total execution time: 0.8281
DEBUG - 2022-04-29 17:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 17:50:15 --> No URI present. Default controller set.
DEBUG - 2022-04-29 17:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 17:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:20:16 --> Total execution time: 0.8280
DEBUG - 2022-04-29 19:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:09:10 --> No URI present. Default controller set.
DEBUG - 2022-04-29 19:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:09:12 --> No URI present. Default controller set.
DEBUG - 2022-04-29 19:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:09:35 --> No URI present. Default controller set.
DEBUG - 2022-04-29 19:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-29 19:12:14 --> 404 Page Not Found: User/leaderboard
DEBUG - 2022-04-29 19:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 19:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 19:42:17 --> No URI present. Default controller set.
DEBUG - 2022-04-29 19:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 19:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 20:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 20:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 20:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 20:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 20:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:00:07 --> Total execution time: 0.0389
DEBUG - 2022-04-29 21:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 21:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:07:40 --> No URI present. Default controller set.
DEBUG - 2022-04-29 21:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-29 23:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 23:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 23:11:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-29 23:11:47 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 49
ERROR - 2022-04-29 23:11:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
