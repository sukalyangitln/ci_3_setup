<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-20 16:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 16:12:58 --> No URI present. Default controller set.
DEBUG - 2022-04-20 16:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 16:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 16:23:47 --> No URI present. Default controller set.
DEBUG - 2022-04-20 16:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 16:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:00:28 --> No URI present. Default controller set.
DEBUG - 2022-04-20 17:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:02:52 --> No URI present. Default controller set.
DEBUG - 2022-04-20 17:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:03:03 --> No URI present. Default controller set.
DEBUG - 2022-04-20 17:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:03:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\stylesheet.php 3
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\stylesheet.php 8
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 8
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 11
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 17
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 20
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:03:53 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:03:53 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:03:53 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\sidebar.php 5
ERROR - 2022-04-20 17:03:53 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 40
ERROR - 2022-04-20 17:03:53 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 63
ERROR - 2022-04-20 17:03:53 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 81
ERROR - 2022-04-20 17:03:53 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 99
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_COPYRIGHT - assumed 'SITE_COPYRIGHT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 5
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY_URL - assumed 'SITE_DEV_BY_URL' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 9
ERROR - 2022-04-20 17:03:53 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 9
DEBUG - 2022-04-20 17:03:53 --> Total execution time: 0.1247
DEBUG - 2022-04-20 17:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:04:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\stylesheet.php 3
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\stylesheet.php 8
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 8
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 11
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 17
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 20
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:04:41 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:04:41 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:04:41 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\sidebar.php 5
ERROR - 2022-04-20 17:04:41 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 40
ERROR - 2022-04-20 17:04:41 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 63
ERROR - 2022-04-20 17:04:41 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 81
ERROR - 2022-04-20 17:04:41 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 99
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_COPYRIGHT - assumed 'SITE_COPYRIGHT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 5
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY_URL - assumed 'SITE_DEV_BY_URL' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 9
ERROR - 2022-04-20 17:04:41 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 9
DEBUG - 2022-04-20 17:04:41 --> Total execution time: 0.0794
DEBUG - 2022-04-20 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:05:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\stylesheet.php 3
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\stylesheet.php 8
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 8
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 11
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 17
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 20
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:05:06 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:05:06 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:05:06 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\sidebar.php 5
ERROR - 2022-04-20 17:05:06 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 40
ERROR - 2022-04-20 17:05:06 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 63
ERROR - 2022-04-20 17:05:06 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 81
ERROR - 2022-04-20 17:05:06 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 99
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_COPYRIGHT - assumed 'SITE_COPYRIGHT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 5
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY_URL - assumed 'SITE_DEV_BY_URL' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 9
ERROR - 2022-04-20 17:05:06 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 9
DEBUG - 2022-04-20 17:05:06 --> Total execution time: 0.0936
DEBUG - 2022-04-20 17:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:06:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\stylesheet.php 3
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\stylesheet.php 8
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 8
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 11
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 17
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\header.php 20
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:06:25 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:06:25 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:06:25 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
ERROR - 2022-04-20 17:06:25 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\sidebar.php 5
ERROR - 2022-04-20 17:06:25 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 40
ERROR - 2022-04-20 17:06:25 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 63
ERROR - 2022-04-20 17:06:25 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 81
ERROR - 2022-04-20 17:06:25 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 99
ERROR - 2022-04-20 17:06:26 --> Severity: Warning --> Use of undefined constant SITE_COPYRIGHT - assumed 'SITE_COPYRIGHT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 5
ERROR - 2022-04-20 17:06:26 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY_URL - assumed 'SITE_DEV_BY_URL' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 9
ERROR - 2022-04-20 17:06:26 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\Admin\inc\footer.php 9
DEBUG - 2022-04-20 17:06:26 --> Total execution time: 0.0860
DEBUG - 2022-04-20 17:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:06:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\stylesheet.php 3
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\stylesheet.php 8
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\header.php 8
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\header.php 11
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\header.php 17
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\header.php 20
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:06:36 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:06:36 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:06:36 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\sidebar.php 5
ERROR - 2022-04-20 17:06:36 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 40
ERROR - 2022-04-20 17:06:36 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 63
ERROR - 2022-04-20 17:06:36 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 81
ERROR - 2022-04-20 17:06:36 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 99
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_COPYRIGHT - assumed 'SITE_COPYRIGHT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\footer.php 5
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY_URL - assumed 'SITE_DEV_BY_URL' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\footer.php 9
ERROR - 2022-04-20 17:06:36 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\footer.php 9
DEBUG - 2022-04-20 17:06:36 --> Total execution time: 0.1080
DEBUG - 2022-04-20 17:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:06:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\stylesheet.php 3
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\stylesheet.php 8
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\header.php 8
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\header.php 11
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\header.php 17
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\header.php 20
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:06:47 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:06:47 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:06:47 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\sidebar.php 5
ERROR - 2022-04-20 17:06:47 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 40
ERROR - 2022-04-20 17:06:47 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 63
ERROR - 2022-04-20 17:06:47 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 81
ERROR - 2022-04-20 17:06:47 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 99
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_COPYRIGHT - assumed 'SITE_COPYRIGHT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\footer.php 5
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY_URL - assumed 'SITE_DEV_BY_URL' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\footer.php 9
ERROR - 2022-04-20 17:06:47 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\footer.php 9
DEBUG - 2022-04-20 17:06:47 --> Total execution time: 0.0762
DEBUG - 2022-04-20 17:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:08:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:08:13 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:08:13 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:08:13 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:08:13 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:08:13 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
ERROR - 2022-04-20 17:08:13 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 40
ERROR - 2022-04-20 17:08:13 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 63
ERROR - 2022-04-20 17:08:13 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 81
ERROR - 2022-04-20 17:08:13 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 99
DEBUG - 2022-04-20 17:08:13 --> Total execution time: 0.6612
DEBUG - 2022-04-20 17:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:09:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:09:02 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:09:02 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:09:02 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:09:02 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:09:02 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
ERROR - 2022-04-20 17:09:02 --> Severity: Notice --> Undefined variable: thisYear C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 40
ERROR - 2022-04-20 17:09:02 --> Severity: Notice --> Undefined variable: PrevMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 63
ERROR - 2022-04-20 17:09:02 --> Severity: Notice --> Undefined variable: ThisMonth C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 81
ERROR - 2022-04-20 17:09:02 --> Severity: Notice --> Undefined variable: TotalDue C:\xampp\htdocs\gopal\leadrsark\application\views\User\dashboard.php 99
DEBUG - 2022-04-20 17:09:02 --> Total execution time: 0.0729
DEBUG - 2022-04-20 17:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:09:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:09:26 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:09:26 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:09:26 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:09:26 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:09:26 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
DEBUG - 2022-04-20 17:09:26 --> Total execution time: 0.0738
DEBUG - 2022-04-20 17:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:09:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:09:30 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 14
ERROR - 2022-04-20 17:09:30 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:09:30 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 16
ERROR - 2022-04-20 17:09:30 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:09:30 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
DEBUG - 2022-04-20 17:09:30 --> Total execution time: 0.0611
DEBUG - 2022-04-20 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:11:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:11:28 --> Severity: Warning --> Use of undefined constant UL_ID - assumed 'UL_ID' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 6
ERROR - 2022-04-20 17:11:28 --> Severity: Notice --> Trying to get property 'Admin_Name' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 8
DEBUG - 2022-04-20 17:11:28 --> Total execution time: 0.0572
DEBUG - 2022-04-20 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:11:28 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-20 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:11:45 --> Total execution time: 0.0503
DEBUG - 2022-04-20 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:11:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:11:45 --> 404 Page Not Found: Assets/images
DEBUG - 2022-04-20 17:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:12:23 --> Total execution time: 0.0583
DEBUG - 2022-04-20 17:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:12:45 --> Total execution time: 0.0517
DEBUG - 2022-04-20 17:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:13:09 --> Total execution time: 0.0514
DEBUG - 2022-04-20 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:13:30 --> Total execution time: 0.0481
DEBUG - 2022-04-20 17:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:13:40 --> Total execution time: 0.0479
DEBUG - 2022-04-20 17:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:15:00 --> Total execution time: 0.0702
DEBUG - 2022-04-20 17:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:15:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 20:45:02 --> Query error: Table 'leadsark.rents' doesn't exist - Invalid query: SELECT SUM(`rent_amount_paid`) AS `rent_amount_paid`
FROM `rents`
WHERE YEAR(rent_date) = '2022'
DEBUG - 2022-04-20 17:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 20:45:16 --> Total execution time: 0.0982
DEBUG - 2022-04-20 17:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 20:45:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 17:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 20:45:56 --> Total execution time: 0.0513
DEBUG - 2022-04-20 17:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:15:59 --> Total execution time: 0.0675
DEBUG - 2022-04-20 17:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:16:08 --> Total execution time: 0.0505
DEBUG - 2022-04-20 17:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:16:59 --> Total execution time: 0.0522
DEBUG - 2022-04-20 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:17:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:17:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:17:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:17:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:17:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:17:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:17:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:17:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:18:39 --> Total execution time: 0.0555
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:18:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:18:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:18:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:18:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:18:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:18:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:18:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:18:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:23:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-20 17:23:08 --> Severity: error --> Exception: Call to undefined function UserMenuActive() C:\xampp\htdocs\gopal\leadrsark\application\views\User\inc\sidebar.php 6
DEBUG - 2022-04-20 17:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:23:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:23:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:23:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:23:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:24:47 --> Total execution time: 0.0492
DEBUG - 2022-04-20 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:24:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:24:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:24:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:26:32 --> Total execution time: 0.0600
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:26:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:26:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:26:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:26:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:26:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:26:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:26:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:26:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:27:16 --> Total execution time: 0.0513
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:27:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:27:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:27:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:27:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:27:33 --> Total execution time: 0.0814
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:27:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:27:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:33 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:27:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:27:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:27:52 --> Total execution time: 0.0668
DEBUG - 2022-04-20 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:52 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:52 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:52 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:27:52 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:27:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:27:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:28:33 --> Total execution time: 0.0631
DEBUG - 2022-04-20 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:28:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:28:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:28:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:28:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:28:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:28:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:28:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:28:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:28:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:29:01 --> Total execution time: 0.0792
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:29:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:29:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:29:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:29:26 --> Total execution time: 0.0778
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:29:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:29:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:29:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:29:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:30:04 --> Total execution time: 0.0485
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:30:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:30:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:30:43 --> Total execution time: 0.0925
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:30:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:30:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:30:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:30:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:31:13 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:31:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:31:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:31:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:31:45 --> Total execution time: 0.0495
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:31:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:31:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:31:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:31:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:31:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:33:05 --> Total execution time: 0.0521
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:33:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:33:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:33:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:33:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:33:55 --> Total execution time: 0.0789
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:33:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:33:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:33:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:34:09 --> Total execution time: 0.0484
DEBUG - 2022-04-20 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:34:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:10 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:34:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:10 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:34:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:34:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:34:50 --> Total execution time: 0.0486
DEBUG - 2022-04-20 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:34:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:34:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:34:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:34:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:35:58 --> Total execution time: 0.0752
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:35:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:35:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:35:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:36:13 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:36:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:36:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:36:13 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:36:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:36:56 --> Total execution time: 0.0587
DEBUG - 2022-04-20 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:36:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:36:57 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:36:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:36:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:36:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:37:03 --> Total execution time: 0.0800
DEBUG - 2022-04-20 17:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:37:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:37:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:03 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:37:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:08 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:37:24 --> Total execution time: 0.0566
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:37:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:37:24 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:37:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:37:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:37:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:38:28 --> Total execution time: 0.0480
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:38:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:38:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:38:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:39:22 --> Total execution time: 0.0827
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:39:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:39:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:39:39 --> Total execution time: 0.0702
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:39:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:39:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:39:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:41:01 --> Total execution time: 0.0554
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:41:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:41:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:41:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:46:12 --> Total execution time: 0.0548
DEBUG - 2022-04-20 17:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:47:02 --> Total execution time: 0.0656
DEBUG - 2022-04-20 17:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:47:23 --> Total execution time: 0.0625
DEBUG - 2022-04-20 17:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:47:28 --> Total execution time: 0.0607
DEBUG - 2022-04-20 17:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:47:41 --> Total execution time: 0.0615
DEBUG - 2022-04-20 17:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:47:51 --> Total execution time: 0.0569
DEBUG - 2022-04-20 17:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:48:03 --> Total execution time: 0.0513
DEBUG - 2022-04-20 17:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:48:10 --> Total execution time: 0.0853
DEBUG - 2022-04-20 17:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:48:19 --> Total execution time: 0.0639
DEBUG - 2022-04-20 17:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:48:26 --> Total execution time: 0.0967
DEBUG - 2022-04-20 17:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:48:33 --> Total execution time: 0.0730
DEBUG - 2022-04-20 17:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:49:16 --> Total execution time: 0.0489
DEBUG - 2022-04-20 17:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:49:37 --> Total execution time: 0.0714
DEBUG - 2022-04-20 17:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:50:14 --> Total execution time: 0.0532
DEBUG - 2022-04-20 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:50:31 --> UTF-8 Support Enabled
ERROR - 2022-04-20 17:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:50:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:50:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:50:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:50:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-20 17:51:02 --> Total execution time: 0.0530
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:51:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:51:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-20 17:51:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:51:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:51:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:51:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:51:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-20 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 17:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 17:51:02 --> 404 Page Not Found: Assets/backend
