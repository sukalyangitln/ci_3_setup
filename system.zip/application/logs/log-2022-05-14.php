<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-14 01:29:05 --> Total execution time: 0.0688
DEBUG - 2022-05-14 03:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 03:10:06 --> Total execution time: 1.2230
DEBUG - 2022-05-14 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 03:10:07 --> Total execution time: 0.0296
DEBUG - 2022-05-14 03:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 03:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:40:29 --> Total execution time: 0.0799
DEBUG - 2022-05-14 03:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:40:46 --> Total execution time: 0.0810
DEBUG - 2022-05-14 03:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:40:59 --> Total execution time: 0.0936
DEBUG - 2022-05-14 03:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:41:16 --> Total execution time: 0.0342
DEBUG - 2022-05-14 03:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 03:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:41:48 --> Total execution time: 0.0317
DEBUG - 2022-05-14 03:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:41:58 --> Total execution time: 0.0348
DEBUG - 2022-05-14 03:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:44:34 --> Total execution time: 0.0927
DEBUG - 2022-05-14 03:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:44:52 --> Total execution time: 0.0335
DEBUG - 2022-05-14 03:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:48:17 --> Total execution time: 0.0340
DEBUG - 2022-05-14 03:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 03:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:48:46 --> Total execution time: 0.0878
DEBUG - 2022-05-14 03:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:48:53 --> Total execution time: 0.0403
DEBUG - 2022-05-14 03:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:53:40 --> Total execution time: 0.0319
DEBUG - 2022-05-14 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:53:48 --> Total execution time: 0.0286
DEBUG - 2022-05-14 03:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:55:29 --> Total execution time: 0.0294
DEBUG - 2022-05-14 03:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:55:48 --> Total execution time: 0.0327
DEBUG - 2022-05-14 03:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:56:30 --> Total execution time: 0.0631
DEBUG - 2022-05-14 03:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 03:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:57:30 --> Total execution time: 0.0363
DEBUG - 2022-05-14 03:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:58:08 --> Total execution time: 0.5536
DEBUG - 2022-05-14 03:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:58:57 --> Total execution time: 0.0316
DEBUG - 2022-05-14 03:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 03:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:59:08 --> Total execution time: 0.0907
DEBUG - 2022-05-14 03:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 08:59:19 --> Total execution time: 0.0311
DEBUG - 2022-05-14 03:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:09:00 --> Total execution time: 0.8608
DEBUG - 2022-05-14 03:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:09:09 --> Total execution time: 0.0383
DEBUG - 2022-05-14 03:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 03:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 03:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:12:22 --> Total execution time: 0.9114
DEBUG - 2022-05-14 04:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:40:47 --> Total execution time: 0.1333
DEBUG - 2022-05-14 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:40:54 --> Total execution time: 0.0370
DEBUG - 2022-05-14 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:47:40 --> Total execution time: 0.8393
DEBUG - 2022-05-14 04:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:47:54 --> Total execution time: 0.0907
DEBUG - 2022-05-14 04:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:48:10 --> Total execution time: 0.0294
DEBUG - 2022-05-14 04:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:52:30 --> Total execution time: 0.8795
DEBUG - 2022-05-14 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:53:27 --> Total execution time: 0.0932
DEBUG - 2022-05-14 04:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:53:35 --> Total execution time: 0.0316
DEBUG - 2022-05-14 04:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:59:10 --> Total execution time: 0.8597
DEBUG - 2022-05-14 04:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:59:17 --> Total execution time: 0.0855
DEBUG - 2022-05-14 04:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:59:27 --> Total execution time: 0.0333
DEBUG - 2022-05-14 04:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 09:59:32 --> Total execution time: 0.0308
DEBUG - 2022-05-14 04:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:00:26 --> Total execution time: 0.1790
DEBUG - 2022-05-14 04:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:00:52 --> Total execution time: 0.0660
DEBUG - 2022-05-14 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:00:58 --> Total execution time: 0.0299
DEBUG - 2022-05-14 04:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:01:09 --> Total execution time: 0.0302
DEBUG - 2022-05-14 04:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:01:15 --> Total execution time: 0.0415
DEBUG - 2022-05-14 04:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:02:05 --> Total execution time: 0.0307
DEBUG - 2022-05-14 04:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:03:17 --> Total execution time: 0.0306
DEBUG - 2022-05-14 04:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:03:30 --> Total execution time: 0.0296
DEBUG - 2022-05-14 04:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:04:59 --> Total execution time: 0.0299
DEBUG - 2022-05-14 04:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:05:12 --> Total execution time: 0.0321
DEBUG - 2022-05-14 04:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:05:22 --> Total execution time: 0.0294
DEBUG - 2022-05-14 04:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:21:12 --> Total execution time: 0.9712
DEBUG - 2022-05-14 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:21:28 --> Total execution time: 0.0834
DEBUG - 2022-05-14 04:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 04:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:21:51 --> Total execution time: 0.0301
DEBUG - 2022-05-14 04:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:21:58 --> Total execution time: 0.0322
DEBUG - 2022-05-14 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:22:53 --> Total execution time: 0.0294
DEBUG - 2022-05-14 04:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:24:05 --> Total execution time: 0.5676
DEBUG - 2022-05-14 04:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:24:07 --> Total execution time: 0.0399
DEBUG - 2022-05-14 04:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 04:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 04:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:25:20 --> Total execution time: 0.0324
DEBUG - 2022-05-14 05:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 05:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:34:08 --> Total execution time: 0.0886
DEBUG - 2022-05-14 05:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:35:42 --> Total execution time: 0.0415
DEBUG - 2022-05-14 05:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:37:16 --> Total execution time: 0.5512
DEBUG - 2022-05-14 05:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:37:27 --> Total execution time: 0.0323
DEBUG - 2022-05-14 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:39:58 --> Total execution time: 0.0312
DEBUG - 2022-05-14 05:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:40:16 --> Total execution time: 0.0314
DEBUG - 2022-05-14 05:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:44:43 --> Total execution time: 0.0779
DEBUG - 2022-05-14 05:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:44:51 --> Total execution time: 0.0293
DEBUG - 2022-05-14 05:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:45:08 --> Total execution time: 0.5476
DEBUG - 2022-05-14 05:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:48:25 --> Total execution time: 0.0338
DEBUG - 2022-05-14 05:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:48:38 --> Total execution time: 0.0297
DEBUG - 2022-05-14 05:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:52:16 --> Total execution time: 0.3024
DEBUG - 2022-05-14 05:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:52:27 --> Total execution time: 0.0315
DEBUG - 2022-05-14 05:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:54:04 --> Total execution time: 0.0301
DEBUG - 2022-05-14 05:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:54:15 --> Total execution time: 0.0310
DEBUG - 2022-05-14 05:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:56:16 --> Total execution time: 0.0311
DEBUG - 2022-05-14 05:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:26:22 --> No URI present. Default controller set.
DEBUG - 2022-05-14 05:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:56:22 --> Total execution time: 0.0883
DEBUG - 2022-05-14 05:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:56:32 --> Total execution time: 2.4079
DEBUG - 2022-05-14 05:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:56:47 --> Total execution time: 0.0372
DEBUG - 2022-05-14 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 05:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:56:55 --> Total execution time: 0.0917
DEBUG - 2022-05-14 05:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:56:57 --> Total execution time: 0.0475
DEBUG - 2022-05-14 05:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 05:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 05:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 10:57:03 --> Total execution time: 0.0419
DEBUG - 2022-05-14 10:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 10:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 10:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 16:27:37 --> Total execution time: 1.1170
DEBUG - 2022-05-14 13:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 13:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 13:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 13:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 13:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 13:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 18:35:29 --> Total execution time: 0.0719
DEBUG - 2022-05-14 13:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 13:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 13:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 18:36:04 --> Total execution time: 0.0347
DEBUG - 2022-05-14 13:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 13:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 13:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 18:36:19 --> Total execution time: 0.0304
DEBUG - 2022-05-14 13:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 13:07:10 --> No URI present. Default controller set.
DEBUG - 2022-05-14 13:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 13:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 18:37:11 --> Total execution time: 0.0733
DEBUG - 2022-05-14 13:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 13:07:35 --> No URI present. Default controller set.
DEBUG - 2022-05-14 13:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 13:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 18:37:35 --> Total execution time: 0.0365
DEBUG - 2022-05-14 15:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 15:41:20 --> Total execution time: 0.9881
DEBUG - 2022-05-14 15:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 15:41:21 --> Total execution time: 0.0286
DEBUG - 2022-05-14 15:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 15:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 15:41:27 --> Total execution time: 0.0282
DEBUG - 2022-05-14 15:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 15:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 21:11:34 --> Total execution time: 0.0859
DEBUG - 2022-05-14 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-14 21:11:43 --> Total execution time: 2.5778
