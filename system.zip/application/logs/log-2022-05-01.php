<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-01 01:38:40 --> Total execution time: 1.6081
DEBUG - 2022-05-01 01:38:56 --> Total execution time: 0.0578
DEBUG - 2022-05-01 01:39:02 --> Total execution time: 0.8284
DEBUG - 2022-05-01 01:39:05 --> Total execution time: 0.0338
DEBUG - 2022-05-01 06:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:14:35 --> No URI present. Default controller set.
DEBUG - 2022-05-01 06:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:44:36 --> Total execution time: 1.3711
DEBUG - 2022-05-01 06:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:44:54 --> Total execution time: 0.0525
DEBUG - 2022-05-01 06:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:15:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-01 06:15:03 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 25
ERROR - 2022-05-01 06:15:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-05-01 06:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:18:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-01 06:18:11 --> Severity: Notice --> Trying to access array offset on value of type null /home/gvprods/public_html/v1/gvv3/application/core/DB_Controller.php 25
ERROR - 2022-05-01 06:18:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/helpers/url_helper.php 564
DEBUG - 2022-05-01 06:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 06:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 06:19:07 --> Total execution time: 0.0416
DEBUG - 2022-05-01 06:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 06:19:43 --> Total execution time: 0.0307
DEBUG - 2022-05-01 06:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 06:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:49:48 --> Total execution time: 0.0845
DEBUG - 2022-05-01 06:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 06:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:49:56 --> Total execution time: 0.1022
DEBUG - 2022-05-01 06:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:51:11 --> Total execution time: 0.0523
DEBUG - 2022-05-01 06:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:52:07 --> Total execution time: 0.0305
DEBUG - 2022-05-01 06:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:52:25 --> Total execution time: 0.0314
DEBUG - 2022-05-01 06:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:53:18 --> Total execution time: 0.0382
DEBUG - 2022-05-01 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:25:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:25:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:25:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:25:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:25:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:25:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 06:25:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:25:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:25:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:25:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:25:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:25:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:25:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:25:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:25:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:56:51 --> Total execution time: 0.0342
DEBUG - 2022-05-01 06:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:26:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:26:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:26:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:26:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 11:57:49 --> Total execution time: 0.0343
DEBUG - 2022-05-01 06:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:27:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 06:27:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:27:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:27:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:27:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:27:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:27:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:27:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:00:16 --> Total execution time: 0.0611
DEBUG - 2022-05-01 06:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:03:12 --> Total execution time: 0.0340
DEBUG - 2022-05-01 06:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:11:44 --> Total execution time: 0.8292
DEBUG - 2022-05-01 06:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:12:13 --> Total execution time: 0.0326
DEBUG - 2022-05-01 06:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:12:35 --> Total execution time: 0.0302
DEBUG - 2022-05-01 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:13:05 --> Total execution time: 0.0307
DEBUG - 2022-05-01 06:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:13:27 --> Total execution time: 0.0316
DEBUG - 2022-05-01 06:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:43:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:43:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:43:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 06:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:43:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:14:52 --> Total execution time: 0.0323
DEBUG - 2022-05-01 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:44:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:44:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:44:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:44:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:44:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 06:44:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:15:12 --> Total execution time: 0.0307
DEBUG - 2022-05-01 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 06:45:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:15:43 --> Total execution time: 0.0302
DEBUG - 2022-05-01 06:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:45:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 06:45:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 06:45:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 06:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 06:45:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 06:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:18:53 --> Total execution time: 0.0339
DEBUG - 2022-05-01 06:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:19:22 --> Total execution time: 0.0310
DEBUG - 2022-05-01 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:19:40 --> Total execution time: 0.0351
DEBUG - 2022-05-01 06:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:19:56 --> Total execution time: 0.0310
DEBUG - 2022-05-01 06:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:20:05 --> Total execution time: 0.0292
DEBUG - 2022-05-01 06:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:20:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-01 06:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:20:37 --> Total execution time: 0.0312
DEBUG - 2022-05-01 06:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:57:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-01 12:27:04 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/gvprods/public_html/v1/gvv3/application/views/User/profile/kyc-details.php 65
DEBUG - 2022-05-01 06:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:57:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-01 12:27:23 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF) /home/gvprods/public_html/v1/gvv3/application/views/User/profile/kyc-details.php 95
DEBUG - 2022-05-01 06:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:28:03 --> Total execution time: 0.2947
DEBUG - 2022-05-01 06:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:28:52 --> Total execution time: 0.0293
DEBUG - 2022-05-01 06:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 06:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 06:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:29:34 --> Total execution time: 0.8252
DEBUG - 2022-05-01 07:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:33:05 --> Total execution time: 0.8242
DEBUG - 2022-05-01 07:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:33:10 --> Total execution time: 0.0431
DEBUG - 2022-05-01 07:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:33:13 --> Total execution time: 0.0302
DEBUG - 2022-05-01 07:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:33:32 --> Total execution time: 0.8202
DEBUG - 2022-05-01 07:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:03:35 --> UTF-8 Support Enabled
ERROR - 2022-05-01 07:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:03:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:36:50 --> Total execution time: 0.8251
DEBUG - 2022-05-01 07:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:06:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:06:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:06:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:06:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:06:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:06:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:06:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:06:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:06:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:06:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:37:32 --> Total execution time: 0.0536
DEBUG - 2022-05-01 07:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:37:36 --> Total execution time: 0.0646
DEBUG - 2022-05-01 07:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:37:42 --> Total execution time: 0.0424
DEBUG - 2022-05-01 07:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:37:55 --> Total execution time: 0.0292
DEBUG - 2022-05-01 07:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:37:58 --> Total execution time: 0.0647
DEBUG - 2022-05-01 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:38:14 --> Total execution time: 0.0780
DEBUG - 2022-05-01 07:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:38:18 --> Total execution time: 0.0640
DEBUG - 2022-05-01 07:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:40:59 --> Total execution time: 0.9382
DEBUG - 2022-05-01 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:44:01 --> Total execution time: 0.9072
DEBUG - 2022-05-01 07:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:44:12 --> Total execution time: 0.8352
DEBUG - 2022-05-01 07:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:44:22 --> Total execution time: 0.1101
DEBUG - 2022-05-01 07:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:44:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-01 07:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:44:59 --> Total execution time: 0.0381
DEBUG - 2022-05-01 07:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:45:08 --> Total execution time: 0.8723
DEBUG - 2022-05-01 07:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:46:30 --> Total execution time: 0.0647
DEBUG - 2022-05-01 07:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:16:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:16:39 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:16:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:16:40 --> UTF-8 Support Enabled
ERROR - 2022-05-01 07:16:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:16:40 --> UTF-8 Support Enabled
ERROR - 2022-05-01 07:16:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:16:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:16:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:16:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:47:42 --> Total execution time: 0.0311
DEBUG - 2022-05-01 07:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:47:48 --> Total execution time: 0.0299
DEBUG - 2022-05-01 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:17:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:17:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:17:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:17:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:17:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:17:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:17:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:17:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:48:11 --> Total execution time: 0.0315
DEBUG - 2022-05-01 07:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:48:41 --> Total execution time: 0.0341
DEBUG - 2022-05-01 07:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:18:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:48:47 --> Total execution time: 0.0312
DEBUG - 2022-05-01 07:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:48:57 --> Total execution time: 0.0309
DEBUG - 2022-05-01 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:18:59 --> UTF-8 Support Enabled
ERROR - 2022-05-01 07:18:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:18:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:18:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:49:07 --> Total execution time: 0.0338
DEBUG - 2022-05-01 07:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:51:52 --> Total execution time: 0.9181
DEBUG - 2022-05-01 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:52:08 --> Total execution time: 0.9254
DEBUG - 2022-05-01 07:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:52:14 --> Total execution time: 1.0004
DEBUG - 2022-05-01 07:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:52:20 --> Total execution time: 0.0376
DEBUG - 2022-05-01 07:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:52:22 --> Total execution time: 0.0329
DEBUG - 2022-05-01 07:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:56:16 --> Total execution time: 0.8361
DEBUG - 2022-05-01 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:26:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:26:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:26:38 --> UTF-8 Support Enabled
ERROR - 2022-05-01 07:26:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:26:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:26:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:26:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:26:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:26:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:56:53 --> Total execution time: 0.3296
DEBUG - 2022-05-01 07:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:13 --> Total execution time: 0.2146
DEBUG - 2022-05-01 07:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:17 --> Total execution time: 0.0408
DEBUG - 2022-05-01 07:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:19 --> Total execution time: 0.0342
DEBUG - 2022-05-01 07:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:22 --> Total execution time: 0.0331
DEBUG - 2022-05-01 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:25 --> Total execution time: 0.0327
DEBUG - 2022-05-01 07:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:28 --> Total execution time: 0.0316
DEBUG - 2022-05-01 07:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:31 --> Total execution time: 0.3744
DEBUG - 2022-05-01 07:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:37 --> Total execution time: 0.4219
DEBUG - 2022-05-01 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:40 --> Total execution time: 0.0469
DEBUG - 2022-05-01 07:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:57:58 --> Total execution time: 0.8321
DEBUG - 2022-05-01 07:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:58:03 --> Total execution time: 0.8292
DEBUG - 2022-05-01 07:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:58:05 --> Total execution time: 0.0585
DEBUG - 2022-05-01 07:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:58:08 --> Total execution time: 0.0314
DEBUG - 2022-05-01 07:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:58:10 --> Total execution time: 0.0375
DEBUG - 2022-05-01 07:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 12:58:28 --> Total execution time: 0.8281
DEBUG - 2022-05-01 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:05:29 --> Total execution time: 1.3130
DEBUG - 2022-05-01 07:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:06:16 --> Total execution time: 0.9071
DEBUG - 2022-05-01 07:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:07:18 --> Total execution time: 0.8291
DEBUG - 2022-05-01 07:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:07:38 --> Total execution time: 0.0305
DEBUG - 2022-05-01 07:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:08:36 --> Total execution time: 0.8321
DEBUG - 2022-05-01 07:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:08:53 --> Total execution time: 0.0397
DEBUG - 2022-05-01 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:08:56 --> Total execution time: 0.0352
DEBUG - 2022-05-01 07:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:09:24 --> Total execution time: 0.2777
DEBUG - 2022-05-01 07:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:09:28 --> Total execution time: 0.0329
DEBUG - 2022-05-01 07:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:09:58 --> Total execution time: 0.5511
DEBUG - 2022-05-01 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:40:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:04 --> UTF-8 Support Enabled
ERROR - 2022-05-01 07:40:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:10:15 --> Total execution time: 0.8443
DEBUG - 2022-05-01 07:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:40:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:40:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:40:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:18 --> UTF-8 Support Enabled
ERROR - 2022-05-01 07:40:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:10:40 --> Total execution time: 0.8324
DEBUG - 2022-05-01 07:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:40:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:40:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:11:08 --> Total execution time: 0.8781
DEBUG - 2022-05-01 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:41:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:41:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:41:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:41:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:41:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:41:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:41:16 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:41:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:11:50 --> Total execution time: 0.9012
DEBUG - 2022-05-01 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:42:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:12:45 --> Total execution time: 0.8252
DEBUG - 2022-05-01 07:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:42:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:42:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:42:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:42:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:13:20 --> Total execution time: 0.0324
DEBUG - 2022-05-01 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:43:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-01 13:13:42 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/gvprods/public_html/v1/gvv3/application/views/User/leaderboard.php 5
DEBUG - 2022-05-01 07:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:13:56 --> Total execution time: 0.0368
DEBUG - 2022-05-01 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:43:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:43:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:43:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:43:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:43:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:43:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:43:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:43:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:13:59 --> Total execution time: 0.0377
DEBUG - 2022-05-01 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:10 --> No URI present. Default controller set.
DEBUG - 2022-05-01 07:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:14:10 --> Total execution time: 0.0745
DEBUG - 2022-05-01 07:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:14:24 --> Total execution time: 0.9171
DEBUG - 2022-05-01 07:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:14:27 --> Total execution time: 0.0343
DEBUG - 2022-05-01 07:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:44:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:29 --> UTF-8 Support Enabled
ERROR - 2022-05-01 07:44:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:14:31 --> Total execution time: 0.0356
DEBUG - 2022-05-01 07:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:44:40 --> Total execution time: 0.8458
DEBUG - 2022-05-01 07:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:14:43 --> Total execution time: 0.0713
DEBUG - 2022-05-01 07:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:14:55 --> Total execution time: 0.0474
DEBUG - 2022-05-01 07:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:44:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:44:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:15:01 --> Total execution time: 0.0331
DEBUG - 2022-05-01 07:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:15:45 --> Total execution time: 0.8252
DEBUG - 2022-05-01 07:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:45:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:45:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:45:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:45:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:16:41 --> Total execution time: 0.8251
DEBUG - 2022-05-01 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:46:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:46:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:46:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:46:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:46:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:46:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 07:46:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:46:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 07:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:17:07 --> Total execution time: 2.2371
DEBUG - 2022-05-01 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:21:12 --> Total execution time: 0.8282
DEBUG - 2022-05-01 07:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:22:25 --> Total execution time: 0.8251
DEBUG - 2022-05-01 07:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:22:32 --> Total execution time: 0.1147
DEBUG - 2022-05-01 07:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:22:48 --> Total execution time: 0.9481
DEBUG - 2022-05-01 07:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:23:05 --> Total execution time: 0.8252
DEBUG - 2022-05-01 07:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:23:16 --> Total execution time: 0.0621
DEBUG - 2022-05-01 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:24:54 --> Total execution time: 0.8211
DEBUG - 2022-05-01 07:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:25:07 --> Total execution time: 0.0694
DEBUG - 2022-05-01 07:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:25:36 --> Total execution time: 0.0305
DEBUG - 2022-05-01 07:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:25:43 --> Total execution time: 0.0302
DEBUG - 2022-05-01 07:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:55:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-01 13:25:47 --> Severity: Notice --> Undefined variable: request_amount /home/gvprods/public_html/v1/gvv3/application/controllers/User/My_Account_Controller.php 48
ERROR - 2022-05-01 13:25:47 --> Query error: Column 'wt_amount' cannot be null - Invalid query: INSERT INTO `wallet_transaction` (`wt_FK_ul_id`, `wt_type`, `wt_amount`, `wt_status`, `wt_date`, `wt_approve_date`, `wt_note`) VALUES ('1', 'debit', NULL, 0, '2022-05-01 13:25:47', '', 'Bank Withdrawal Request')
ERROR - 2022-05-01 13:25:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/gvprods/public_html/v1/gvv3/system/core/Exceptions.php:271) /home/gvprods/public_html/v1/gvv3/system/core/Common.php 564
DEBUG - 2022-05-01 07:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:26:16 --> Total execution time: 0.0329
DEBUG - 2022-05-01 07:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:56:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 07:56:18 --> 404 Page Not Found: User/My_Account_Controller/withdrawal_history
DEBUG - 2022-05-01 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:26:20 --> Total execution time: 0.0317
DEBUG - 2022-05-01 07:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 07:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 07:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 07:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:26:30 --> Total execution time: 0.0308
DEBUG - 2022-05-01 08:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 08:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:42:40 --> Total execution time: 0.1750
DEBUG - 2022-05-01 08:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:43:06 --> Total execution time: 0.2021
DEBUG - 2022-05-01 08:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:43:16 --> Total execution time: 0.0307
DEBUG - 2022-05-01 08:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:43:38 --> Total execution time: 0.0378
DEBUG - 2022-05-01 08:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:01:23 --> Total execution time: 0.8673
DEBUG - 2022-05-01 08:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:02:22 --> Total execution time: 0.0547
DEBUG - 2022-05-01 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:04:27 --> Total execution time: 0.2596
DEBUG - 2022-05-01 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:34:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:06:33 --> Total execution time: 0.0343
DEBUG - 2022-05-01 08:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:36:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:36:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:36:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:36:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:36:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:36:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:36:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:36:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:07:06 --> Total execution time: 0.0322
DEBUG - 2022-05-01 08:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:07:27 --> Total execution time: 0.0384
DEBUG - 2022-05-01 08:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:37:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:08:38 --> Total execution time: 0.0347
DEBUG - 2022-05-01 08:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:38:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:38:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:38:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:38:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:38:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 08:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:09:06 --> Total execution time: 0.0327
DEBUG - 2022-05-01 08:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 08:39:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:09:58 --> Total execution time: 0.0314
DEBUG - 2022-05-01 08:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:39:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:39:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:40:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 08:40:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:40:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:40:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:40:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:10:38 --> Total execution time: 0.0356
DEBUG - 2022-05-01 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:10:41 --> Total execution time: 0.0336
DEBUG - 2022-05-01 08:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:11:07 --> Total execution time: 0.0337
DEBUG - 2022-05-01 08:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:11:19 --> Total execution time: 0.1139
DEBUG - 2022-05-01 08:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:16:58 --> Total execution time: 0.8441
DEBUG - 2022-05-01 08:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:17:07 --> Total execution time: 0.0541
DEBUG - 2022-05-01 08:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:18:11 --> Total execution time: 0.0302
DEBUG - 2022-05-01 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:18:15 --> Total execution time: 0.0316
DEBUG - 2022-05-01 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:18:58 --> Total execution time: 0.0358
DEBUG - 2022-05-01 08:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:19:22 --> Total execution time: 0.0323
DEBUG - 2022-05-01 08:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:49:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 08:49:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:49:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:49:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:20:11 --> Total execution time: 0.5580
DEBUG - 2022-05-01 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:50:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:50:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:50:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:50:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:50:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:50:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 08:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 08:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:21:07 --> Total execution time: 0.0336
DEBUG - 2022-05-01 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:22:25 --> Total execution time: 0.0339
DEBUG - 2022-05-01 08:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:22:28 --> Total execution time: 0.0313
DEBUG - 2022-05-01 08:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:22:48 --> Total execution time: 0.0341
DEBUG - 2022-05-01 08:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:22:52 --> Total execution time: 0.0314
DEBUG - 2022-05-01 08:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:23:19 --> Total execution time: 0.5402
DEBUG - 2022-05-01 08:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:23:26 --> Total execution time: 0.0314
DEBUG - 2022-05-01 08:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 08:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 08:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:23:32 --> Total execution time: 0.0318
DEBUG - 2022-05-01 09:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:30:43 --> Total execution time: 0.8131
DEBUG - 2022-05-01 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 09:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 14:34:18 --> Total execution time: 0.2900
DEBUG - 2022-05-01 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 09:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:34:36 --> Total execution time: 0.0318
DEBUG - 2022-05-01 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:04:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:04:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 09:04:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:34:40 --> Total execution time: 0.0305
DEBUG - 2022-05-01 09:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:34:41 --> Total execution time: 0.0284
DEBUG - 2022-05-01 09:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:19 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' /home/gvprods/public_html/v1/gvv3/application/controllers/Admin/AdminLeaderboard_Controller.php 48
DEBUG - 2022-05-01 09:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:42:47 --> Total execution time: 0.5618
DEBUG - 2022-05-01 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 09:12:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 09:12:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:42:53 --> Total execution time: 0.0301
DEBUG - 2022-05-01 09:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:42:55 --> Total execution time: 0.0316
DEBUG - 2022-05-01 09:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 09:12:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:12:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:42:59 --> Total execution time: 0.0302
DEBUG - 2022-05-01 09:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:43:00 --> Total execution time: 0.0345
DEBUG - 2022-05-01 09:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:13:03 --> UTF-8 Support Enabled
ERROR - 2022-05-01 09:13:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:43:03 --> Total execution time: 0.0312
DEBUG - 2022-05-01 09:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:43:05 --> Total execution time: 0.0330
DEBUG - 2022-05-01 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:13:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:13:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:44:09 --> Total execution time: 0.0310
DEBUG - 2022-05-01 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:14:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-01 09:14:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:44:12 --> Total execution time: 0.0408
DEBUG - 2022-05-01 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:44:17 --> Total execution time: 0.0284
DEBUG - 2022-05-01 09:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:44:21 --> Total execution time: 0.0315
DEBUG - 2022-05-01 09:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:39 --> 404 Page Not Found: U/index
DEBUG - 2022-05-01 09:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:14:43 --> 404 Page Not Found: User/index
DEBUG - 2022-05-01 09:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 09:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:44:49 --> Total execution time: 0.0647
DEBUG - 2022-05-01 09:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:44:53 --> Total execution time: 0.0452
DEBUG - 2022-05-01 09:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:47:09 --> Total execution time: 0.0338
DEBUG - 2022-05-01 09:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:47:15 --> Total execution time: 0.0296
DEBUG - 2022-05-01 09:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:47:17 --> Total execution time: 0.0332
DEBUG - 2022-05-01 09:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:47:21 --> Total execution time: 0.0318
DEBUG - 2022-05-01 09:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:47:23 --> Total execution time: 0.5240
DEBUG - 2022-05-01 09:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:47:25 --> Total execution time: 0.0736
DEBUG - 2022-05-01 09:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:49:27 --> Total execution time: 0.0368
DEBUG - 2022-05-01 09:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:50:53 --> Total execution time: 0.0310
DEBUG - 2022-05-01 09:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:52:37 --> Total execution time: 0.0334
DEBUG - 2022-05-01 09:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:53:32 --> Total execution time: 0.0327
DEBUG - 2022-05-01 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:54:20 --> Total execution time: 0.0345
DEBUG - 2022-05-01 09:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:54:24 --> Total execution time: 0.0356
DEBUG - 2022-05-01 09:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:55:15 --> Total execution time: 0.0715
DEBUG - 2022-05-01 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:57:15 --> Total execution time: 0.0304
DEBUG - 2022-05-01 09:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:58:17 --> Total execution time: 0.0298
DEBUG - 2022-05-01 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:29:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:29:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:29:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:29:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:29:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:29:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:29:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:29:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:29:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:00:41 --> Total execution time: 0.0327
DEBUG - 2022-05-01 09:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:01:36 --> Total execution time: 0.0300
DEBUG - 2022-05-01 09:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:31:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:31:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:31:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:31:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:31:57 --> No URI present. Default controller set.
DEBUG - 2022-05-01 09:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:01:57 --> Total execution time: 0.0974
DEBUG - 2022-05-01 09:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:02:45 --> Total execution time: 0.0316
DEBUG - 2022-05-01 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:32:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:32:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:32:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:32:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:32:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 09:32:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-01 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:04:05 --> Total execution time: 0.4779
DEBUG - 2022-05-01 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:34:58 --> No URI present. Default controller set.
DEBUG - 2022-05-01 09:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:04:58 --> Total execution time: 0.0312
DEBUG - 2022-05-01 09:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:09:33 --> Total execution time: 0.0923
DEBUG - 2022-05-01 09:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:09:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-01 15:09:45 --> You did not select a file to upload.
DEBUG - 2022-05-01 15:09:45 --> You did not select a file to upload.
DEBUG - 2022-05-01 09:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:09:45 --> Total execution time: 0.0307
DEBUG - 2022-05-01 09:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:39:51 --> No URI present. Default controller set.
DEBUG - 2022-05-01 09:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:09:51 --> Total execution time: 0.0310
DEBUG - 2022-05-01 09:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 09:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 09:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:09:55 --> Total execution time: 0.0363
DEBUG - 2022-05-01 12:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 12:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 12:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:29:29 --> Total execution time: 1.2261
DEBUG - 2022-05-01 12:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 12:59:38 --> No URI present. Default controller set.
DEBUG - 2022-05-01 12:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 12:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:29:38 --> Total execution time: 0.2007
DEBUG - 2022-05-01 12:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:41:32 --> Total execution time: 0.8211
DEBUG - 2022-05-01 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:41:39 --> Total execution time: 0.0914
DEBUG - 2022-05-01 13:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:41:45 --> Total execution time: 0.0508
DEBUG - 2022-05-01 13:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:41:47 --> Total execution time: 0.0420
DEBUG - 2022-05-01 13:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:41:53 --> Total execution time: 0.0414
DEBUG - 2022-05-01 13:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:55 --> No URI present. Default controller set.
DEBUG - 2022-05-01 13:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:41:55 --> Total execution time: 0.0402
DEBUG - 2022-05-01 13:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:41:59 --> Total execution time: 0.0289
DEBUG - 2022-05-01 13:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-01 13:12:10 --> 404 Page Not Found: User/index
DEBUG - 2022-05-01 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:15 --> Total execution time: 0.0303
DEBUG - 2022-05-01 13:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:25 --> Total execution time: 0.0294
DEBUG - 2022-05-01 13:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:32 --> Total execution time: 0.0307
DEBUG - 2022-05-01 13:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:37 --> Total execution time: 0.0416
DEBUG - 2022-05-01 13:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:43 --> Total execution time: 0.0484
DEBUG - 2022-05-01 13:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 13:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:44 --> Total execution time: 0.0306
DEBUG - 2022-05-01 13:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:51 --> Total execution time: 0.0352
DEBUG - 2022-05-01 13:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:52 --> Total execution time: 0.0377
DEBUG - 2022-05-01 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:42:59 --> Total execution time: 0.0317
DEBUG - 2022-05-01 13:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:43:12 --> Total execution time: 0.0344
DEBUG - 2022-05-01 13:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:49:19 --> Total execution time: 0.8951
DEBUG - 2022-05-01 13:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:49:24 --> Total execution time: 0.0504
DEBUG - 2022-05-01 13:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:58:35 --> Total execution time: 0.8090
DEBUG - 2022-05-01 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:28:49 --> No URI present. Default controller set.
DEBUG - 2022-05-01 13:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 18:58:49 --> Total execution time: 0.0615
DEBUG - 2022-05-01 13:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 13:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 13:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 19:12:09 --> Total execution time: 0.8361
DEBUG - 2022-05-01 14:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:07:35 --> No URI present. Default controller set.
DEBUG - 2022-05-01 14:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 14:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 19:37:36 --> Total execution time: 0.8361
DEBUG - 2022-05-01 14:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 14:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 14:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 14:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 19:38:33 --> Total execution time: 0.0660
DEBUG - 2022-05-01 14:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:08:39 --> No URI present. Default controller set.
DEBUG - 2022-05-01 14:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 14:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 19:38:39 --> Total execution time: 0.0339
DEBUG - 2022-05-01 14:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:08:51 --> No URI present. Default controller set.
DEBUG - 2022-05-01 14:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 14:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 19:38:51 --> Total execution time: 0.0307
DEBUG - 2022-05-01 14:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:19:06 --> No URI present. Default controller set.
DEBUG - 2022-05-01 14:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 14:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 19:49:07 --> Total execution time: 0.3190
DEBUG - 2022-05-01 14:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:20:19 --> No URI present. Default controller set.
DEBUG - 2022-05-01 14:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 14:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 19:50:19 --> Total execution time: 0.0412
DEBUG - 2022-05-01 14:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 14:21:03 --> No URI present. Default controller set.
DEBUG - 2022-05-01 14:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 14:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 19:51:03 --> Total execution time: 0.0333
DEBUG - 2022-05-01 14:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:00:33 --> No URI present. Default controller set.
DEBUG - 2022-05-01 15:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 20:30:33 --> Total execution time: 0.8331
DEBUG - 2022-05-01 15:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:10:53 --> No URI present. Default controller set.
DEBUG - 2022-05-01 15:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 20:40:53 --> Total execution time: 0.8079
DEBUG - 2022-05-01 15:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:13:06 --> No URI present. Default controller set.
DEBUG - 2022-05-01 15:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 20:43:06 --> Total execution time: 0.2653
DEBUG - 2022-05-01 15:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:04:28 --> Total execution time: 1.3280
DEBUG - 2022-05-01 15:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:04:37 --> Total execution time: 0.0289
DEBUG - 2022-05-01 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 15:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:04:45 --> Total execution time: 0.2066
DEBUG - 2022-05-01 15:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:04:55 --> Total execution time: 0.0435
DEBUG - 2022-05-01 15:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:05:00 --> Total execution time: 0.0551
DEBUG - 2022-05-01 15:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:05:05 --> Total execution time: 0.0343
DEBUG - 2022-05-01 15:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:05:10 --> Total execution time: 0.1307
DEBUG - 2022-05-01 15:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:05:22 --> Total execution time: 0.0878
DEBUG - 2022-05-01 15:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:05:25 --> Total execution time: 0.0464
DEBUG - 2022-05-01 15:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:05:35 --> Total execution time: 0.0349
DEBUG - 2022-05-01 15:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-01 15:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-01 15:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-01 21:05:38 --> Total execution time: 0.0337
