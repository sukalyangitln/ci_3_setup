<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-08-21 00:04:44 --> Total execution time: 0.1070
DEBUG - 2022-08-21 00:07:06 --> Total execution time: 0.1475
DEBUG - 2022-08-21 00:07:08 --> Total execution time: 0.0974
DEBUG - 2022-08-21 00:07:16 --> Total execution time: 0.0917
DEBUG - 2022-08-21 00:07:16 --> Total execution time: 0.0976
DEBUG - 2022-08-21 00:07:16 --> Total execution time: 0.0898
DEBUG - 2022-08-21 00:07:37 --> Total execution time: 0.0903
DEBUG - 2022-08-21 00:07:42 --> Total execution time: 0.0912
DEBUG - 2022-08-21 00:07:48 --> Total execution time: 0.1132
DEBUG - 2022-08-21 00:07:53 --> Total execution time: 0.0900
DEBUG - 2022-08-21 00:08:38 --> Total execution time: 0.0574
DEBUG - 2022-08-21 00:09:01 --> Total execution time: 2.3096
DEBUG - 2022-08-21 00:09:11 --> Total execution time: 0.2177
DEBUG - 2022-08-21 00:13:10 --> Total execution time: 0.1060
DEBUG - 2022-08-21 00:14:15 --> Total execution time: 1.9669
DEBUG - 2022-08-21 00:14:22 --> Total execution time: 0.1215
DEBUG - 2022-08-21 00:14:30 --> Total execution time: 0.1249
DEBUG - 2022-08-21 00:14:39 --> Total execution time: 0.0876
DEBUG - 2022-08-21 00:14:52 --> Total execution time: 0.1256
DEBUG - 2022-08-21 00:14:56 --> Total execution time: 0.1022
DEBUG - 2022-08-21 00:15:05 --> Total execution time: 0.0871
DEBUG - 2022-08-21 00:15:27 --> Total execution time: 0.1082
DEBUG - 2022-08-21 00:15:35 --> Total execution time: 0.0905
DEBUG - 2022-08-21 00:15:49 --> Total execution time: 1.8059
DEBUG - 2022-08-21 00:15:59 --> Total execution time: 0.0811
DEBUG - 2022-08-21 00:16:03 --> Total execution time: 0.0842
DEBUG - 2022-08-21 00:16:06 --> Total execution time: 0.1043
DEBUG - 2022-08-21 00:16:17 --> Total execution time: 0.0939
DEBUG - 2022-08-21 00:18:15 --> Total execution time: 0.0962
DEBUG - 2022-08-21 00:18:24 --> Total execution time: 0.1077
DEBUG - 2022-08-21 00:21:50 --> Total execution time: 0.0985
DEBUG - 2022-08-21 00:22:57 --> Total execution time: 0.0846
DEBUG - 2022-08-21 00:24:01 --> Total execution time: 0.2145
DEBUG - 2022-08-21 00:24:22 --> Total execution time: 0.0901
DEBUG - 2022-08-21 00:24:29 --> Total execution time: 0.1400
DEBUG - 2022-08-21 00:24:50 --> Total execution time: 0.0927
DEBUG - 2022-08-21 00:24:52 --> Total execution time: 0.1173
DEBUG - 2022-08-21 00:24:54 --> Total execution time: 0.0905
DEBUG - 2022-08-21 00:25:01 --> Total execution time: 0.1272
DEBUG - 2022-08-21 00:25:07 --> Total execution time: 0.0881
DEBUG - 2022-08-21 00:25:53 --> Total execution time: 0.0572
DEBUG - 2022-08-21 00:27:42 --> Total execution time: 0.2275
DEBUG - 2022-08-21 00:27:48 --> Total execution time: 0.0948
DEBUG - 2022-08-21 00:28:13 --> Total execution time: 0.0932
DEBUG - 2022-08-21 00:28:25 --> Total execution time: 0.1082
DEBUG - 2022-08-21 00:28:35 --> Total execution time: 0.0966
DEBUG - 2022-08-21 00:28:37 --> Total execution time: 0.0862
DEBUG - 2022-08-21 00:28:37 --> Total execution time: 0.0908
DEBUG - 2022-08-21 00:28:38 --> Total execution time: 0.0849
DEBUG - 2022-08-21 00:28:39 --> Total execution time: 0.0868
DEBUG - 2022-08-21 00:28:40 --> Total execution time: 0.0909
DEBUG - 2022-08-21 00:28:42 --> Total execution time: 0.1037
DEBUG - 2022-08-21 00:28:44 --> Total execution time: 0.0899
DEBUG - 2022-08-21 00:28:44 --> Total execution time: 0.0870
DEBUG - 2022-08-21 00:28:49 --> Total execution time: 0.0865
DEBUG - 2022-08-21 00:28:51 --> Total execution time: 0.0898
DEBUG - 2022-08-21 00:28:52 --> Total execution time: 0.0934
DEBUG - 2022-08-21 00:28:53 --> Total execution time: 0.0882
DEBUG - 2022-08-21 00:28:54 --> Total execution time: 0.0874
DEBUG - 2022-08-21 00:28:55 --> Total execution time: 0.0940
DEBUG - 2022-08-21 00:28:56 --> Total execution time: 0.1334
DEBUG - 2022-08-21 00:28:57 --> Total execution time: 0.0928
DEBUG - 2022-08-21 00:29:03 --> Total execution time: 0.0822
DEBUG - 2022-08-21 00:29:06 --> Total execution time: 0.0812
DEBUG - 2022-08-21 00:29:17 --> Total execution time: 0.0868
DEBUG - 2022-08-21 00:29:19 --> Total execution time: 0.0876
DEBUG - 2022-08-21 00:29:43 --> Total execution time: 0.0841
DEBUG - 2022-08-21 00:30:02 --> Total execution time: 0.1785
DEBUG - 2022-08-21 00:30:49 --> Total execution time: 0.2128
DEBUG - 2022-08-21 00:31:49 --> Total execution time: 0.0826
DEBUG - 2022-08-21 00:31:51 --> Total execution time: 0.0840
DEBUG - 2022-08-21 00:31:52 --> Total execution time: 0.0759
DEBUG - 2022-08-21 00:31:53 --> Total execution time: 0.0808
DEBUG - 2022-08-21 00:31:53 --> Total execution time: 0.0890
DEBUG - 2022-08-21 00:31:54 --> Total execution time: 0.0757
DEBUG - 2022-08-21 00:31:57 --> Total execution time: 0.0763
DEBUG - 2022-08-21 00:31:58 --> Total execution time: 0.0757
DEBUG - 2022-08-21 00:31:58 --> Total execution time: 0.1678
DEBUG - 2022-08-21 00:31:59 --> Total execution time: 0.0751
DEBUG - 2022-08-21 00:32:01 --> Total execution time: 0.1375
DEBUG - 2022-08-21 00:33:43 --> Total execution time: 0.0555
DEBUG - 2022-08-21 00:35:30 --> Total execution time: 0.0563
DEBUG - 2022-08-21 00:38:38 --> Total execution time: 0.1050
DEBUG - 2022-08-21 00:38:40 --> Total execution time: 0.0830
DEBUG - 2022-08-21 00:39:10 --> Total execution time: 0.0862
DEBUG - 2022-08-21 00:40:25 --> Total execution time: 0.0958
DEBUG - 2022-08-21 00:40:35 --> Total execution time: 0.1121
DEBUG - 2022-08-21 00:43:42 --> Total execution time: 0.1051
DEBUG - 2022-08-21 00:43:59 --> Total execution time: 0.0810
DEBUG - 2022-08-21 00:44:01 --> Total execution time: 0.0580
DEBUG - 2022-08-21 00:44:50 --> Total execution time: 0.0825
DEBUG - 2022-08-21 00:45:10 --> Total execution time: 0.0766
DEBUG - 2022-08-21 00:47:09 --> Total execution time: 0.1331
DEBUG - 2022-08-21 00:47:14 --> Total execution time: 0.0977
DEBUG - 2022-08-21 00:47:15 --> Total execution time: 0.0892
DEBUG - 2022-08-21 00:47:20 --> Total execution time: 0.0895
DEBUG - 2022-08-21 00:47:35 --> Total execution time: 0.0876
DEBUG - 2022-08-21 00:47:41 --> Total execution time: 0.0887
DEBUG - 2022-08-21 00:47:44 --> Total execution time: 0.0912
DEBUG - 2022-08-21 00:49:05 --> Total execution time: 0.0572
DEBUG - 2022-08-21 00:50:19 --> Total execution time: 0.2207
DEBUG - 2022-08-21 00:51:13 --> Total execution time: 0.1324
DEBUG - 2022-08-21 00:51:20 --> Total execution time: 0.0559
DEBUG - 2022-08-21 00:51:23 --> Total execution time: 0.0563
DEBUG - 2022-08-21 00:51:23 --> Total execution time: 0.0593
DEBUG - 2022-08-21 00:51:45 --> Total execution time: 0.0869
DEBUG - 2022-08-21 00:51:55 --> Total execution time: 0.1309
DEBUG - 2022-08-21 00:51:58 --> Total execution time: 0.0464
DEBUG - 2022-08-21 00:52:24 --> Total execution time: 0.0559
DEBUG - 2022-08-21 00:53:00 --> Total execution time: 0.0775
DEBUG - 2022-08-21 00:54:53 --> Total execution time: 0.0700
DEBUG - 2022-08-21 00:55:00 --> Total execution time: 0.0704
DEBUG - 2022-08-21 00:56:02 --> Total execution time: 0.0704
DEBUG - 2022-08-21 00:56:02 --> Total execution time: 0.0472
DEBUG - 2022-08-21 00:56:04 --> Total execution time: 0.0782
DEBUG - 2022-08-21 00:56:05 --> Total execution time: 0.0764
DEBUG - 2022-08-21 01:12:39 --> Total execution time: 0.0855
DEBUG - 2022-08-21 01:12:40 --> Total execution time: 0.0805
DEBUG - 2022-08-21 01:12:40 --> Total execution time: 0.0840
DEBUG - 2022-08-21 01:16:42 --> Total execution time: 0.0650
DEBUG - 2022-08-21 01:18:47 --> Total execution time: 0.0557
DEBUG - 2022-08-21 01:30:02 --> Total execution time: 0.1969
DEBUG - 2022-08-21 01:35:34 --> Total execution time: 0.1096
DEBUG - 2022-08-21 01:36:00 --> Total execution time: 0.0637
DEBUG - 2022-08-21 01:39:26 --> Total execution time: 0.0864
DEBUG - 2022-08-21 01:40:34 --> Total execution time: 0.0916
DEBUG - 2022-08-21 01:40:42 --> Total execution time: 0.0989
DEBUG - 2022-08-21 01:41:00 --> Total execution time: 0.0818
DEBUG - 2022-08-21 01:41:19 --> Total execution time: 0.0860
DEBUG - 2022-08-21 01:41:34 --> Total execution time: 0.1304
DEBUG - 2022-08-21 01:41:37 --> Total execution time: 0.0919
DEBUG - 2022-08-21 01:41:48 --> Total execution time: 0.0858
DEBUG - 2022-08-21 01:43:07 --> Total execution time: 0.1029
DEBUG - 2022-08-21 01:43:07 --> Total execution time: 0.0824
DEBUG - 2022-08-21 02:14:03 --> Total execution time: 0.1933
DEBUG - 2022-08-21 02:14:03 --> Total execution time: 0.1799
DEBUG - 2022-08-21 02:14:03 --> Total execution time: 0.2344
DEBUG - 2022-08-21 02:14:03 --> Total execution time: 0.0704
DEBUG - 2022-08-21 02:21:32 --> Total execution time: 0.0943
DEBUG - 2022-08-21 02:30:03 --> Total execution time: 0.1206
DEBUG - 2022-08-21 03:14:22 --> Total execution time: 0.2967
DEBUG - 2022-08-21 03:20:54 --> Total execution time: 0.0834
DEBUG - 2022-08-21 03:30:02 --> Total execution time: 0.4940
DEBUG - 2022-08-21 03:50:54 --> Total execution time: 0.3166
DEBUG - 2022-08-21 04:12:05 --> Total execution time: 0.2708
DEBUG - 2022-08-21 04:30:02 --> Total execution time: 0.3341
DEBUG - 2022-08-21 04:39:13 --> Total execution time: 0.0925
DEBUG - 2022-08-21 04:39:26 --> Total execution time: 0.0815
DEBUG - 2022-08-21 04:39:55 --> Total execution time: 0.1093
DEBUG - 2022-08-21 04:40:10 --> Total execution time: 0.0995
DEBUG - 2022-08-21 04:40:17 --> Total execution time: 0.0938
DEBUG - 2022-08-21 04:40:46 --> Total execution time: 0.0916
DEBUG - 2022-08-21 04:41:00 --> Total execution time: 0.0925
DEBUG - 2022-08-21 04:41:07 --> Total execution time: 0.1064
DEBUG - 2022-08-21 04:43:09 --> Total execution time: 0.1365
DEBUG - 2022-08-21 04:44:01 --> Total execution time: 0.1099
DEBUG - 2022-08-21 04:44:13 --> Total execution time: 0.0889
DEBUG - 2022-08-21 04:47:02 --> Total execution time: 0.0828
DEBUG - 2022-08-21 04:47:07 --> Total execution time: 0.0870
DEBUG - 2022-08-21 04:47:59 --> Total execution time: 0.0818
DEBUG - 2022-08-21 04:48:48 --> Total execution time: 0.0890
DEBUG - 2022-08-21 04:48:56 --> Total execution time: 0.0903
DEBUG - 2022-08-21 05:02:41 --> Total execution time: 0.2907
DEBUG - 2022-08-21 05:03:12 --> Total execution time: 0.1045
DEBUG - 2022-08-21 05:03:14 --> Total execution time: 0.1339
DEBUG - 2022-08-21 05:03:33 --> Total execution time: 0.0900
DEBUG - 2022-08-21 05:03:37 --> Total execution time: 0.1016
DEBUG - 2022-08-21 05:03:41 --> Total execution time: 0.0983
DEBUG - 2022-08-21 05:03:53 --> Total execution time: 0.0978
DEBUG - 2022-08-21 05:03:56 --> Total execution time: 0.0933
DEBUG - 2022-08-21 05:08:37 --> Total execution time: 0.0975
DEBUG - 2022-08-21 05:08:47 --> Total execution time: 0.0862
DEBUG - 2022-08-21 05:08:53 --> Total execution time: 0.0830
DEBUG - 2022-08-21 05:10:31 --> Total execution time: 0.0590
DEBUG - 2022-08-21 05:11:10 --> Total execution time: 0.0830
DEBUG - 2022-08-21 05:11:43 --> Total execution time: 0.0858
DEBUG - 2022-08-21 05:18:28 --> Total execution time: 0.1369
DEBUG - 2022-08-21 05:30:02 --> Total execution time: 0.1063
DEBUG - 2022-08-21 05:33:08 --> Total execution time: 0.1087
DEBUG - 2022-08-21 05:33:09 --> Total execution time: 0.0540
DEBUG - 2022-08-21 05:33:23 --> Total execution time: 0.0609
DEBUG - 2022-08-21 05:33:24 --> Total execution time: 0.0777
DEBUG - 2022-08-21 05:33:40 --> Total execution time: 0.0586
DEBUG - 2022-08-21 05:35:46 --> Total execution time: 0.2879
DEBUG - 2022-08-21 05:35:53 --> Total execution time: 0.0917
DEBUG - 2022-08-21 05:35:56 --> Total execution time: 0.0949
DEBUG - 2022-08-21 05:36:08 --> Total execution time: 0.0914
DEBUG - 2022-08-21 05:39:07 --> Total execution time: 0.1451
DEBUG - 2022-08-21 05:39:11 --> Total execution time: 0.0556
DEBUG - 2022-08-21 05:39:20 --> Total execution time: 0.0991
DEBUG - 2022-08-21 05:39:25 --> Total execution time: 0.1128
DEBUG - 2022-08-21 05:39:32 --> Total execution time: 0.1197
DEBUG - 2022-08-21 05:42:20 --> Total execution time: 0.0780
DEBUG - 2022-08-21 05:42:44 --> Total execution time: 0.0879
DEBUG - 2022-08-21 05:43:01 --> Total execution time: 0.0958
DEBUG - 2022-08-21 05:43:11 --> Total execution time: 0.0911
DEBUG - 2022-08-21 05:43:23 --> Total execution time: 0.0922
DEBUG - 2022-08-21 05:43:32 --> Total execution time: 0.1035
DEBUG - 2022-08-21 05:56:25 --> Total execution time: 0.1343
DEBUG - 2022-08-21 06:16:06 --> Total execution time: 0.1458
DEBUG - 2022-08-21 06:25:38 --> Total execution time: 0.1070
DEBUG - 2022-08-21 06:25:42 --> Total execution time: 0.0947
DEBUG - 2022-08-21 06:25:46 --> Total execution time: 0.0964
DEBUG - 2022-08-21 06:25:57 --> Total execution time: 0.0963
DEBUG - 2022-08-21 06:30:02 --> Total execution time: 0.2231
DEBUG - 2022-08-21 06:46:51 --> Total execution time: 0.1003
DEBUG - 2022-08-21 06:53:25 --> Total execution time: 0.0838
DEBUG - 2022-08-21 06:53:34 --> Total execution time: 0.0849
DEBUG - 2022-08-21 06:53:41 --> Total execution time: 0.0818
DEBUG - 2022-08-21 06:53:50 --> Total execution time: 0.1479
DEBUG - 2022-08-21 06:54:02 --> Total execution time: 0.1013
DEBUG - 2022-08-21 06:54:22 --> Total execution time: 0.0920
DEBUG - 2022-08-21 06:54:32 --> Total execution time: 0.1340
DEBUG - 2022-08-21 07:10:09 --> Total execution time: 0.1186
DEBUG - 2022-08-21 07:10:12 --> Total execution time: 0.0815
DEBUG - 2022-08-21 07:10:22 --> Total execution time: 0.0824
DEBUG - 2022-08-21 07:10:35 --> Total execution time: 0.0915
DEBUG - 2022-08-21 07:10:54 --> Total execution time: 0.0850
DEBUG - 2022-08-21 07:11:01 --> Total execution time: 0.0895
DEBUG - 2022-08-21 07:11:15 --> Total execution time: 0.0894
DEBUG - 2022-08-21 07:12:02 --> Total execution time: 0.0596
DEBUG - 2022-08-21 07:12:16 --> Total execution time: 0.0624
DEBUG - 2022-08-21 07:12:28 --> Total execution time: 0.0968
DEBUG - 2022-08-21 07:12:43 --> Total execution time: 0.0935
DEBUG - 2022-08-21 07:12:59 --> Total execution time: 0.1109
DEBUG - 2022-08-21 07:12:59 --> Total execution time: 0.0860
DEBUG - 2022-08-21 07:13:03 --> Total execution time: 0.0880
DEBUG - 2022-08-21 07:13:17 --> Total execution time: 0.0844
DEBUG - 2022-08-21 07:13:40 --> Total execution time: 0.0817
DEBUG - 2022-08-21 07:14:05 --> Total execution time: 0.0816
DEBUG - 2022-08-21 07:14:19 --> Total execution time: 0.0938
DEBUG - 2022-08-21 07:14:29 --> Total execution time: 0.0831
DEBUG - 2022-08-21 07:16:22 --> Total execution time: 0.1031
DEBUG - 2022-08-21 07:16:30 --> Total execution time: 0.0837
DEBUG - 2022-08-21 07:16:53 --> Total execution time: 0.0551
DEBUG - 2022-08-21 07:17:24 --> Total execution time: 0.2181
DEBUG - 2022-08-21 07:17:30 --> Total execution time: 0.0928
DEBUG - 2022-08-21 07:17:37 --> Total execution time: 0.1089
DEBUG - 2022-08-21 07:17:44 --> Total execution time: 0.1167
DEBUG - 2022-08-21 07:18:37 --> Total execution time: 0.1579
DEBUG - 2022-08-21 07:19:29 --> Total execution time: 0.0547
DEBUG - 2022-08-21 07:19:45 --> Total execution time: 0.0851
DEBUG - 2022-08-21 07:20:04 --> Total execution time: 0.0887
DEBUG - 2022-08-21 07:20:22 --> Total execution time: 0.0625
DEBUG - 2022-08-21 07:20:25 --> Total execution time: 0.0554
DEBUG - 2022-08-21 07:20:57 --> Total execution time: 0.0555
DEBUG - 2022-08-21 07:24:09 --> Total execution time: 0.1355
DEBUG - 2022-08-21 07:24:46 --> Total execution time: 0.0614
DEBUG - 2022-08-21 07:25:51 --> Total execution time: 0.0713
DEBUG - 2022-08-21 07:30:03 --> Total execution time: 0.1243
DEBUG - 2022-08-21 07:37:29 --> Total execution time: 0.1442
DEBUG - 2022-08-21 07:42:12 --> Total execution time: 0.1522
DEBUG - 2022-08-21 07:42:12 --> Total execution time: 0.0621
DEBUG - 2022-08-21 07:42:37 --> Total execution time: 0.0920
DEBUG - 2022-08-21 07:42:44 --> Total execution time: 0.1127
DEBUG - 2022-08-21 07:42:48 --> Total execution time: 0.1320
DEBUG - 2022-08-21 07:56:11 --> Total execution time: 0.4877
DEBUG - 2022-08-21 07:59:33 --> Total execution time: 0.0864
DEBUG - 2022-08-21 08:03:13 --> Total execution time: 0.1099
DEBUG - 2022-08-21 08:04:58 --> Total execution time: 0.0901
DEBUG - 2022-08-21 08:05:03 --> Total execution time: 0.0964
DEBUG - 2022-08-21 08:05:07 --> Total execution time: 0.0849
DEBUG - 2022-08-21 08:08:57 --> Total execution time: 0.1049
DEBUG - 2022-08-21 08:14:20 --> Total execution time: 0.1022
DEBUG - 2022-08-21 08:14:44 --> Total execution time: 0.0990
DEBUG - 2022-08-21 08:14:58 --> Total execution time: 0.0960
DEBUG - 2022-08-21 08:15:23 --> Total execution time: 0.1094
DEBUG - 2022-08-21 08:15:59 --> Total execution time: 0.0823
DEBUG - 2022-08-21 08:21:53 --> Total execution time: 0.2728
DEBUG - 2022-08-21 08:23:09 --> Total execution time: 0.0910
DEBUG - 2022-08-21 08:23:13 --> Total execution time: 0.0582
DEBUG - 2022-08-21 08:23:18 --> Total execution time: 0.0934
DEBUG - 2022-08-21 08:23:32 --> Total execution time: 0.1484
DEBUG - 2022-08-21 08:23:45 --> Total execution time: 0.0980
DEBUG - 2022-08-21 08:23:46 --> Total execution time: 0.0908
DEBUG - 2022-08-21 08:25:43 --> Total execution time: 0.2595
DEBUG - 2022-08-21 08:25:52 --> Total execution time: 0.0913
DEBUG - 2022-08-21 08:26:33 --> Total execution time: 0.0861
DEBUG - 2022-08-21 08:26:34 --> Total execution time: 0.1091
DEBUG - 2022-08-21 08:26:35 --> Total execution time: 0.0861
DEBUG - 2022-08-21 08:26:37 --> Total execution time: 0.0857
DEBUG - 2022-08-21 08:26:45 --> Total execution time: 0.0897
DEBUG - 2022-08-21 08:26:50 --> Total execution time: 0.0864
DEBUG - 2022-08-21 08:26:52 --> Total execution time: 0.0905
DEBUG - 2022-08-21 08:26:54 --> Total execution time: 0.0872
DEBUG - 2022-08-21 08:26:56 --> Total execution time: 0.0869
DEBUG - 2022-08-21 08:27:04 --> Total execution time: 0.1194
DEBUG - 2022-08-21 08:28:16 --> Total execution time: 0.0928
DEBUG - 2022-08-21 08:29:25 --> Total execution time: 0.0903
DEBUG - 2022-08-21 08:29:26 --> Total execution time: 0.2052
DEBUG - 2022-08-21 08:29:30 --> Total execution time: 0.1057
DEBUG - 2022-08-21 08:29:50 --> Total execution time: 0.0986
DEBUG - 2022-08-21 08:30:02 --> Total execution time: 0.0859
DEBUG - 2022-08-21 08:30:53 --> Total execution time: 0.0488
DEBUG - 2022-08-21 08:31:03 --> Total execution time: 0.0533
DEBUG - 2022-08-21 08:31:04 --> Total execution time: 0.0805
DEBUG - 2022-08-21 08:31:08 --> Total execution time: 0.0809
DEBUG - 2022-08-21 08:32:05 --> Total execution time: 2.3171
DEBUG - 2022-08-21 08:32:18 --> Total execution time: 0.0547
DEBUG - 2022-08-21 08:33:02 --> Total execution time: 0.2236
DEBUG - 2022-08-21 08:33:04 --> Total execution time: 0.0922
DEBUG - 2022-08-21 08:33:10 --> Total execution time: 0.0804
DEBUG - 2022-08-21 08:33:16 --> Total execution time: 0.0540
DEBUG - 2022-08-21 08:33:26 --> Total execution time: 0.0862
DEBUG - 2022-08-21 08:33:33 --> Total execution time: 0.1059
DEBUG - 2022-08-21 08:33:34 --> Total execution time: 0.1061
DEBUG - 2022-08-21 08:33:45 --> Total execution time: 0.0890
DEBUG - 2022-08-21 08:34:29 --> Total execution time: 0.0552
DEBUG - 2022-08-21 08:35:08 --> Total execution time: 0.0537
DEBUG - 2022-08-21 08:35:31 --> Total execution time: 0.0531
DEBUG - 2022-08-21 08:35:42 --> Total execution time: 0.0546
DEBUG - 2022-08-21 08:37:23 --> Total execution time: 0.0519
DEBUG - 2022-08-21 08:37:39 --> Total execution time: 0.0524
DEBUG - 2022-08-21 08:37:41 --> Total execution time: 0.0547
DEBUG - 2022-08-21 08:37:41 --> Total execution time: 0.0596
DEBUG - 2022-08-21 08:38:11 --> Total execution time: 0.0822
DEBUG - 2022-08-21 08:38:48 --> Total execution time: 0.0596
DEBUG - 2022-08-21 08:38:48 --> Total execution time: 0.0518
DEBUG - 2022-08-21 08:39:07 --> Total execution time: 0.1205
DEBUG - 2022-08-21 08:39:10 --> Total execution time: 0.0519
DEBUG - 2022-08-21 08:39:51 --> Total execution time: 0.0684
DEBUG - 2022-08-21 08:40:14 --> Total execution time: 0.0873
DEBUG - 2022-08-21 08:40:26 --> Total execution time: 0.0579
DEBUG - 2022-08-21 08:40:26 --> Total execution time: 0.0548
DEBUG - 2022-08-21 08:40:28 --> Total execution time: 0.0837
DEBUG - 2022-08-21 08:40:33 --> Total execution time: 0.0526
DEBUG - 2022-08-21 08:40:34 --> Total execution time: 0.0513
DEBUG - 2022-08-21 08:40:35 --> Total execution time: 0.0521
DEBUG - 2022-08-21 08:40:58 --> Total execution time: 0.0882
DEBUG - 2022-08-21 08:41:22 --> Total execution time: 0.1047
DEBUG - 2022-08-21 08:41:25 --> Total execution time: 0.1023
DEBUG - 2022-08-21 08:41:32 --> Total execution time: 0.0815
DEBUG - 2022-08-21 08:41:46 --> Total execution time: 0.1310
DEBUG - 2022-08-21 08:43:14 --> Total execution time: 0.2230
DEBUG - 2022-08-21 08:43:20 --> Total execution time: 0.0887
DEBUG - 2022-08-21 08:49:35 --> Total execution time: 0.1300
DEBUG - 2022-08-21 08:50:43 --> Total execution time: 0.2156
DEBUG - 2022-08-21 08:50:44 --> Total execution time: 0.0844
DEBUG - 2022-08-21 08:50:52 --> Total execution time: 0.2004
DEBUG - 2022-08-21 08:51:21 --> Total execution time: 0.0515
DEBUG - 2022-08-21 08:51:58 --> Total execution time: 0.0566
DEBUG - 2022-08-21 08:52:06 --> Total execution time: 0.2307
DEBUG - 2022-08-21 08:52:13 --> Total execution time: 0.0873
DEBUG - 2022-08-21 08:52:24 --> Total execution time: 0.1227
DEBUG - 2022-08-21 08:53:12 --> Total execution time: 0.0838
DEBUG - 2022-08-21 09:00:10 --> Total execution time: 0.1155
DEBUG - 2022-08-21 09:00:47 --> Total execution time: 0.0567
DEBUG - 2022-08-21 09:00:48 --> Total execution time: 0.0580
DEBUG - 2022-08-21 09:00:49 --> Total execution time: 0.0582
DEBUG - 2022-08-21 09:00:49 --> Total execution time: 0.0599
DEBUG - 2022-08-21 09:01:26 --> Total execution time: 0.0588
DEBUG - 2022-08-21 09:01:29 --> Total execution time: 0.0532
DEBUG - 2022-08-21 09:01:33 --> Total execution time: 0.0545
DEBUG - 2022-08-21 09:01:35 --> Total execution time: 0.0562
DEBUG - 2022-08-21 09:02:29 --> Total execution time: 0.0560
DEBUG - 2022-08-21 09:02:30 --> Total execution time: 0.0656
DEBUG - 2022-08-21 09:02:31 --> Total execution time: 0.0526
DEBUG - 2022-08-21 09:03:45 --> Total execution time: 0.0598
DEBUG - 2022-08-21 09:06:34 --> Total execution time: 0.1184
DEBUG - 2022-08-21 09:06:35 --> Total execution time: 0.2223
DEBUG - 2022-08-21 09:06:49 --> Total execution time: 0.0921
DEBUG - 2022-08-21 09:06:58 --> Total execution time: 0.1109
DEBUG - 2022-08-21 09:07:15 --> Total execution time: 0.1102
DEBUG - 2022-08-21 09:07:18 --> Total execution time: 0.1005
DEBUG - 2022-08-21 09:07:23 --> Total execution time: 0.0951
DEBUG - 2022-08-21 09:07:48 --> Total execution time: 0.0978
DEBUG - 2022-08-21 09:10:12 --> Total execution time: 0.2717
DEBUG - 2022-08-21 09:11:14 --> Total execution time: 0.0871
DEBUG - 2022-08-21 09:11:51 --> Total execution time: 0.2249
DEBUG - 2022-08-21 09:12:05 --> Total execution time: 0.0889
DEBUG - 2022-08-21 09:12:26 --> Total execution time: 0.0887
DEBUG - 2022-08-21 09:12:40 --> Total execution time: 0.1182
DEBUG - 2022-08-21 09:12:43 --> Total execution time: 0.1337
DEBUG - 2022-08-21 09:12:45 --> Total execution time: 0.1130
DEBUG - 2022-08-21 09:12:59 --> Total execution time: 0.1397
DEBUG - 2022-08-21 09:13:23 --> Total execution time: 0.1515
DEBUG - 2022-08-21 09:14:07 --> Total execution time: 0.0889
DEBUG - 2022-08-21 09:15:34 --> Total execution time: 0.2309
DEBUG - 2022-08-21 09:15:36 --> Total execution time: 0.0886
DEBUG - 2022-08-21 09:15:37 --> Total execution time: 0.0873
DEBUG - 2022-08-21 09:15:41 --> Total execution time: 0.2403
DEBUG - 2022-08-21 09:15:48 --> Total execution time: 0.0852
DEBUG - 2022-08-21 09:15:53 --> Total execution time: 0.0853
DEBUG - 2022-08-21 09:15:59 --> Total execution time: 0.0884
DEBUG - 2022-08-21 09:16:12 --> Total execution time: 0.0938
DEBUG - 2022-08-21 09:16:15 --> Total execution time: 0.0868
DEBUG - 2022-08-21 09:16:26 --> Total execution time: 0.0991
DEBUG - 2022-08-21 09:16:28 --> Total execution time: 0.0909
DEBUG - 2022-08-21 09:16:36 --> Total execution time: 0.0923
DEBUG - 2022-08-21 09:16:47 --> Total execution time: 0.1167
DEBUG - 2022-08-21 09:16:55 --> Total execution time: 0.0543
DEBUG - 2022-08-21 09:17:15 --> Total execution time: 0.0926
DEBUG - 2022-08-21 09:17:16 --> Total execution time: 0.0848
DEBUG - 2022-08-21 09:17:17 --> Total execution time: 0.0846
DEBUG - 2022-08-21 09:17:19 --> Total execution time: 0.0864
DEBUG - 2022-08-21 09:18:01 --> Total execution time: 0.1364
DEBUG - 2022-08-21 09:18:44 --> Total execution time: 0.0931
DEBUG - 2022-08-21 09:20:06 --> Total execution time: 0.0552
DEBUG - 2022-08-21 09:20:07 --> Total execution time: 0.0621
DEBUG - 2022-08-21 09:20:16 --> Total execution time: 0.2374
DEBUG - 2022-08-21 09:20:19 --> Total execution time: 0.0819
DEBUG - 2022-08-21 09:20:44 --> Total execution time: 0.0874
DEBUG - 2022-08-21 09:20:59 --> Total execution time: 0.0965
DEBUG - 2022-08-21 09:21:15 --> Total execution time: 0.1950
DEBUG - 2022-08-21 09:21:28 --> Total execution time: 0.0903
DEBUG - 2022-08-21 09:21:38 --> Total execution time: 0.0871
DEBUG - 2022-08-21 09:21:58 --> Total execution time: 0.2530
DEBUG - 2022-08-21 09:23:06 --> Total execution time: 0.1008
DEBUG - 2022-08-21 09:23:07 --> Total execution time: 0.0935
DEBUG - 2022-08-21 09:23:14 --> Total execution time: 0.0943
DEBUG - 2022-08-21 09:23:16 --> Total execution time: 0.0957
DEBUG - 2022-08-21 09:23:19 --> Total execution time: 0.0927
DEBUG - 2022-08-21 09:23:23 --> Total execution time: 0.0859
DEBUG - 2022-08-21 09:23:25 --> Total execution time: 0.1186
DEBUG - 2022-08-21 09:23:27 --> Total execution time: 0.1247
DEBUG - 2022-08-21 09:23:28 --> Total execution time: 0.0837
DEBUG - 2022-08-21 09:23:34 --> Total execution time: 0.2248
DEBUG - 2022-08-21 09:23:39 --> Total execution time: 0.1040
DEBUG - 2022-08-21 09:23:47 --> Total execution time: 0.0832
DEBUG - 2022-08-21 09:23:57 --> Total execution time: 0.0873
DEBUG - 2022-08-21 09:24:00 --> Total execution time: 0.1320
DEBUG - 2022-08-21 09:24:07 --> Total execution time: 0.0960
DEBUG - 2022-08-21 09:24:14 --> Total execution time: 0.0880
DEBUG - 2022-08-21 09:30:02 --> Total execution time: 0.1919
DEBUG - 2022-08-21 09:31:35 --> Total execution time: 0.0885
DEBUG - 2022-08-21 09:32:18 --> Total execution time: 0.0776
DEBUG - 2022-08-21 09:32:21 --> Total execution time: 0.0554
DEBUG - 2022-08-21 09:32:42 --> Total execution time: 0.0721
DEBUG - 2022-08-21 09:32:57 --> Total execution time: 0.0926
DEBUG - 2022-08-21 09:33:08 --> Total execution time: 0.0874
DEBUG - 2022-08-21 09:33:13 --> Total execution time: 0.1033
DEBUG - 2022-08-21 09:33:19 --> Total execution time: 0.0928
DEBUG - 2022-08-21 09:33:54 --> Total execution time: 0.1230
DEBUG - 2022-08-21 09:34:12 --> Total execution time: 0.2602
DEBUG - 2022-08-21 09:34:34 --> Total execution time: 0.0830
DEBUG - 2022-08-21 09:34:48 --> Total execution time: 0.0837
DEBUG - 2022-08-21 09:35:10 --> Total execution time: 0.0912
DEBUG - 2022-08-21 09:35:17 --> Total execution time: 0.2265
DEBUG - 2022-08-21 09:35:29 --> Total execution time: 0.0902
DEBUG - 2022-08-21 09:35:41 --> Total execution time: 0.1142
DEBUG - 2022-08-21 09:39:56 --> Total execution time: 0.1058
DEBUG - 2022-08-21 09:40:16 --> Total execution time: 0.0983
DEBUG - 2022-08-21 09:41:30 --> Total execution time: 0.0585
DEBUG - 2022-08-21 09:46:32 --> Total execution time: 0.1023
DEBUG - 2022-08-21 09:46:49 --> Total execution time: 0.1015
DEBUG - 2022-08-21 09:46:59 --> Total execution time: 0.1245
DEBUG - 2022-08-21 09:47:18 --> Total execution time: 0.1041
DEBUG - 2022-08-21 09:48:14 --> Total execution time: 0.0815
DEBUG - 2022-08-21 09:48:51 --> Total execution time: 0.0770
DEBUG - 2022-08-21 09:49:02 --> Total execution time: 0.0855
DEBUG - 2022-08-21 09:49:19 --> Total execution time: 0.0915
DEBUG - 2022-08-21 09:49:28 --> Total execution time: 0.0892
DEBUG - 2022-08-21 09:49:35 --> Total execution time: 0.0915
DEBUG - 2022-08-21 09:49:37 --> Total execution time: 0.0833
DEBUG - 2022-08-21 09:49:56 --> Total execution time: 0.0867
DEBUG - 2022-08-21 09:50:10 --> Total execution time: 0.0827
DEBUG - 2022-08-21 09:50:12 --> Total execution time: 0.0891
DEBUG - 2022-08-21 09:50:20 --> Total execution time: 0.0903
DEBUG - 2022-08-21 09:50:21 --> Total execution time: 0.0892
DEBUG - 2022-08-21 09:50:30 --> Total execution time: 0.0952
DEBUG - 2022-08-21 09:50:33 --> Total execution time: 0.0901
DEBUG - 2022-08-21 09:50:34 --> Total execution time: 0.1203
DEBUG - 2022-08-21 09:50:41 --> Total execution time: 0.0813
DEBUG - 2022-08-21 09:50:44 --> Total execution time: 0.0822
DEBUG - 2022-08-21 09:51:22 --> Total execution time: 0.0649
DEBUG - 2022-08-21 09:51:30 --> Total execution time: 0.0519
DEBUG - 2022-08-21 09:51:42 --> Total execution time: 0.0851
DEBUG - 2022-08-21 09:51:49 --> Total execution time: 0.1186
DEBUG - 2022-08-21 09:52:14 --> Total execution time: 0.1124
DEBUG - 2022-08-21 09:52:25 --> Total execution time: 0.0937
DEBUG - 2022-08-21 09:52:35 --> Total execution time: 0.0956
DEBUG - 2022-08-21 09:52:47 --> Total execution time: 0.1470
DEBUG - 2022-08-21 09:53:49 --> Total execution time: 0.1194
DEBUG - 2022-08-21 09:53:50 --> Total execution time: 0.1168
DEBUG - 2022-08-21 09:54:10 --> Total execution time: 0.1872
DEBUG - 2022-08-21 09:54:15 --> Total execution time: 0.1541
DEBUG - 2022-08-21 09:54:20 --> Total execution time: 0.1016
DEBUG - 2022-08-21 09:54:29 --> Total execution time: 0.0861
DEBUG - 2022-08-21 09:54:36 --> Total execution time: 0.1284
DEBUG - 2022-08-21 09:54:44 --> Total execution time: 0.1078
DEBUG - 2022-08-21 09:54:50 --> Total execution time: 0.0854
DEBUG - 2022-08-21 09:54:58 --> Total execution time: 0.0930
DEBUG - 2022-08-21 09:55:07 --> Total execution time: 0.0989
DEBUG - 2022-08-21 09:55:11 --> Total execution time: 0.1127
DEBUG - 2022-08-21 09:55:30 --> Total execution time: 0.0868
DEBUG - 2022-08-21 09:55:57 --> Total execution time: 0.0887
DEBUG - 2022-08-21 09:55:57 --> Total execution time: 0.0804
DEBUG - 2022-08-21 09:56:43 --> Total execution time: 0.0644
DEBUG - 2022-08-21 10:01:08 --> Total execution time: 2.6404
DEBUG - 2022-08-21 10:03:00 --> Total execution time: 0.0945
DEBUG - 2022-08-21 10:03:02 --> Total execution time: 0.2506
DEBUG - 2022-08-21 10:05:35 --> Total execution time: 0.1269
DEBUG - 2022-08-21 10:06:59 --> Total execution time: 0.0748
DEBUG - 2022-08-21 10:10:12 --> Total execution time: 0.1055
DEBUG - 2022-08-21 10:10:36 --> Total execution time: 0.0581
DEBUG - 2022-08-21 10:12:02 --> Total execution time: 0.0602
DEBUG - 2022-08-21 10:12:23 --> Total execution time: 0.0835
DEBUG - 2022-08-21 10:12:27 --> Total execution time: 0.0516
DEBUG - 2022-08-21 10:12:34 --> Total execution time: 0.1418
DEBUG - 2022-08-21 10:12:42 --> Total execution time: 0.1088
DEBUG - 2022-08-21 10:12:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 10:12:57 --> Total execution time: 0.0912
DEBUG - 2022-08-21 10:13:56 --> Total execution time: 0.2111
DEBUG - 2022-08-21 10:13:58 --> Total execution time: 0.0849
DEBUG - 2022-08-21 10:14:01 --> Total execution time: 0.0857
DEBUG - 2022-08-21 10:14:20 --> Total execution time: 0.0907
DEBUG - 2022-08-21 10:14:43 --> Total execution time: 0.0809
DEBUG - 2022-08-21 10:14:57 --> Total execution time: 0.0862
DEBUG - 2022-08-21 10:15:31 --> Total execution time: 0.0522
DEBUG - 2022-08-21 10:15:39 --> Total execution time: 0.0903
DEBUG - 2022-08-21 10:15:44 --> Total execution time: 0.1103
DEBUG - 2022-08-21 10:16:04 --> Total execution time: 0.0859
DEBUG - 2022-08-21 10:16:06 --> Total execution time: 0.0873
DEBUG - 2022-08-21 10:16:28 --> Total execution time: 0.2239
DEBUG - 2022-08-21 10:16:33 --> Total execution time: 0.0978
DEBUG - 2022-08-21 10:16:41 --> Total execution time: 0.0884
DEBUG - 2022-08-21 10:17:14 --> Total execution time: 0.0802
DEBUG - 2022-08-21 10:17:28 --> Total execution time: 0.0865
DEBUG - 2022-08-21 10:17:38 --> Total execution time: 0.0763
DEBUG - 2022-08-21 10:17:50 --> Total execution time: 0.0565
DEBUG - 2022-08-21 10:18:05 --> Total execution time: 0.0855
DEBUG - 2022-08-21 10:18:10 --> Total execution time: 0.2255
DEBUG - 2022-08-21 10:18:18 --> Total execution time: 0.0851
DEBUG - 2022-08-21 10:18:31 --> Total execution time: 0.1440
DEBUG - 2022-08-21 10:18:52 --> Total execution time: 0.0853
DEBUG - 2022-08-21 10:18:55 --> Total execution time: 0.0907
DEBUG - 2022-08-21 10:18:58 --> Total execution time: 0.0903
DEBUG - 2022-08-21 10:19:06 --> Total execution time: 0.0808
DEBUG - 2022-08-21 10:19:15 --> Total execution time: 0.0918
DEBUG - 2022-08-21 10:19:16 --> Total execution time: 0.0920
DEBUG - 2022-08-21 10:19:21 --> Total execution time: 0.1119
DEBUG - 2022-08-21 10:19:25 --> Total execution time: 0.0817
DEBUG - 2022-08-21 10:19:35 --> Total execution time: 0.0870
DEBUG - 2022-08-21 10:19:42 --> Total execution time: 0.1162
DEBUG - 2022-08-21 10:19:48 --> Total execution time: 0.0853
DEBUG - 2022-08-21 10:20:26 --> Total execution time: 0.0826
DEBUG - 2022-08-21 10:20:43 --> Total execution time: 0.0818
DEBUG - 2022-08-21 10:20:52 --> Total execution time: 0.0920
DEBUG - 2022-08-21 10:20:55 --> Total execution time: 0.1002
DEBUG - 2022-08-21 10:20:58 --> Total execution time: 0.0973
DEBUG - 2022-08-21 10:21:00 --> Total execution time: 0.0972
DEBUG - 2022-08-21 10:21:03 --> Total execution time: 0.1195
DEBUG - 2022-08-21 10:25:06 --> Total execution time: 0.2699
DEBUG - 2022-08-21 10:25:44 --> Total execution time: 0.0786
DEBUG - 2022-08-21 10:25:53 --> Total execution time: 0.1069
DEBUG - 2022-08-21 10:26:08 --> Total execution time: 0.2245
DEBUG - 2022-08-21 10:26:15 --> Total execution time: 0.0845
DEBUG - 2022-08-21 10:26:18 --> Total execution time: 0.2103
DEBUG - 2022-08-21 10:26:22 --> Total execution time: 0.0772
DEBUG - 2022-08-21 10:26:31 --> Total execution time: 0.0502
DEBUG - 2022-08-21 10:26:39 --> Total execution time: 0.0486
DEBUG - 2022-08-21 10:26:39 --> Total execution time: 0.0769
DEBUG - 2022-08-21 10:26:54 --> Total execution time: 0.0824
DEBUG - 2022-08-21 10:27:21 --> Total execution time: 0.0764
DEBUG - 2022-08-21 10:27:34 --> Total execution time: 0.0530
DEBUG - 2022-08-21 10:27:40 --> Total execution time: 0.0779
DEBUG - 2022-08-21 10:28:21 --> Total execution time: 0.0990
DEBUG - 2022-08-21 10:28:32 --> Total execution time: 0.0777
DEBUG - 2022-08-21 10:29:18 --> Total execution time: 0.0764
DEBUG - 2022-08-21 10:29:39 --> Total execution time: 0.2234
DEBUG - 2022-08-21 10:29:46 --> Total execution time: 0.0869
DEBUG - 2022-08-21 10:29:55 --> Total execution time: 0.0851
DEBUG - 2022-08-21 10:29:57 --> Total execution time: 0.0809
DEBUG - 2022-08-21 00:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:30:02 --> Total execution time: 0.0767
DEBUG - 2022-08-21 00:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:30:10 --> Total execution time: 0.2201
DEBUG - 2022-08-21 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:30:51 --> Total execution time: 0.2123
DEBUG - 2022-08-21 00:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:31:11 --> Total execution time: 0.0834
DEBUG - 2022-08-21 00:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:31:21 --> Total execution time: 0.0960
DEBUG - 2022-08-21 00:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:31:22 --> Total execution time: 0.0527
DEBUG - 2022-08-21 00:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:31:46 --> Total execution time: 0.0985
DEBUG - 2022-08-21 00:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:32:40 --> Total execution time: 0.0828
DEBUG - 2022-08-21 00:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:32:42 --> Total execution time: 0.1062
DEBUG - 2022-08-21 00:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:34:21 --> Total execution time: 0.0825
DEBUG - 2022-08-21 00:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:34:33 --> Total execution time: 0.0891
DEBUG - 2022-08-21 00:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:17 --> Total execution time: 0.0855
DEBUG - 2022-08-21 00:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:29 --> Total execution time: 0.0854
DEBUG - 2022-08-21 00:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:40 --> Total execution time: 0.0879
DEBUG - 2022-08-21 00:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:42 --> Total execution time: 0.0855
DEBUG - 2022-08-21 00:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:44 --> Total execution time: 0.0954
DEBUG - 2022-08-21 00:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:47 --> Total execution time: 0.0885
DEBUG - 2022-08-21 00:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:52 --> Total execution time: 0.0893
DEBUG - 2022-08-21 00:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:55 --> Total execution time: 0.0880
DEBUG - 2022-08-21 00:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:35:58 --> Total execution time: 0.0862
DEBUG - 2022-08-21 00:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:36:02 --> Total execution time: 0.0866
DEBUG - 2022-08-21 00:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:06:10 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:36:10 --> Total execution time: 0.2179
DEBUG - 2022-08-21 00:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:06:26 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:36:26 --> Total execution time: 0.0847
DEBUG - 2022-08-21 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:36:36 --> Total execution time: 0.0867
DEBUG - 2022-08-21 00:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:37:31 --> Total execution time: 0.0954
DEBUG - 2022-08-21 00:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:08:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:38:13 --> Total execution time: 0.0731
DEBUG - 2022-08-21 00:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:38:14 --> Total execution time: 0.0897
DEBUG - 2022-08-21 00:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:38:41 --> Total execution time: 0.0856
DEBUG - 2022-08-21 00:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:39:08 --> Total execution time: 0.1060
DEBUG - 2022-08-21 00:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:39:10 --> Total execution time: 0.0853
DEBUG - 2022-08-21 00:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:40:03 --> Total execution time: 0.1199
DEBUG - 2022-08-21 00:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:10:20 --> Total execution time: 0.0959
DEBUG - 2022-08-21 00:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:10:30 --> Total execution time: 0.0968
DEBUG - 2022-08-21 00:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:41:53 --> Total execution time: 0.2250
DEBUG - 2022-08-21 00:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:42:02 --> Total execution time: 0.0844
DEBUG - 2022-08-21 00:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:13:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:29 --> Total execution time: 0.0716
DEBUG - 2022-08-21 00:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:13:32 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:32 --> Total execution time: 0.0692
DEBUG - 2022-08-21 00:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:45 --> Total execution time: 0.1107
DEBUG - 2022-08-21 00:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:44:16 --> Total execution time: 0.2256
DEBUG - 2022-08-21 00:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:01 --> Total execution time: 0.1045
DEBUG - 2022-08-21 00:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:13 --> Total execution time: 0.1080
DEBUG - 2022-08-21 00:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 00:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:30 --> Total execution time: 0.1102
DEBUG - 2022-08-21 00:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 00:18:20 --> 404 Page Not Found: User/update-thumbnail
DEBUG - 2022-08-21 00:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 00:18:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 00:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:18:32 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:48:32 --> Total execution time: 0.2177
DEBUG - 2022-08-21 00:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:49:01 --> Total execution time: 0.0910
DEBUG - 2022-08-21 00:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:49:14 --> Total execution time: 0.1124
DEBUG - 2022-08-21 00:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:20:05 --> Total execution time: 0.2266
DEBUG - 2022-08-21 00:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:20:07 --> Total execution time: 0.0961
DEBUG - 2022-08-21 00:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:20:07 --> Total execution time: 0.0828
DEBUG - 2022-08-21 00:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:20:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:50:29 --> Total execution time: 0.0588
DEBUG - 2022-08-21 00:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:51:33 --> Total execution time: 0.0839
DEBUG - 2022-08-21 00:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:52:00 --> Total execution time: 0.0867
DEBUG - 2022-08-21 00:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:22:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:52:30 --> Total execution time: 0.0555
DEBUG - 2022-08-21 00:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:52:35 --> Total execution time: 0.0843
DEBUG - 2022-08-21 00:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:53:05 --> Total execution time: 0.0815
DEBUG - 2022-08-21 00:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:54:07 --> Total execution time: 0.0767
DEBUG - 2022-08-21 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:56:25 --> Total execution time: 0.3147
DEBUG - 2022-08-21 00:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:56:33 --> Total execution time: 0.0851
DEBUG - 2022-08-21 00:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:56:44 --> Total execution time: 0.0673
DEBUG - 2022-08-21 00:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:14 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:14 --> Total execution time: 0.0572
DEBUG - 2022-08-21 00:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:19 --> Total execution time: 0.0548
DEBUG - 2022-08-21 00:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:19 --> Total execution time: 0.0531
DEBUG - 2022-08-21 00:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:22 --> Total execution time: 0.0829
DEBUG - 2022-08-21 00:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:35 --> Total execution time: 0.1075
DEBUG - 2022-08-21 00:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:37 --> Total execution time: 0.0835
DEBUG - 2022-08-21 00:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:41 --> Total execution time: 0.0889
DEBUG - 2022-08-21 00:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:44 --> Total execution time: 0.0809
DEBUG - 2022-08-21 00:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:51 --> Total execution time: 0.1231
DEBUG - 2022-08-21 00:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:59:06 --> Total execution time: 0.0828
DEBUG - 2022-08-21 00:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:59:41 --> Total execution time: 0.2278
DEBUG - 2022-08-21 00:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:00:01 --> Total execution time: 0.1260
DEBUG - 2022-08-21 00:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:00:06 --> Total execution time: 0.0845
DEBUG - 2022-08-21 00:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:00:51 --> Total execution time: 0.0775
DEBUG - 2022-08-21 00:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:02:22 --> Total execution time: 0.0762
DEBUG - 2022-08-21 00:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:02:35 --> Total execution time: 0.0972
DEBUG - 2022-08-21 00:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:02:57 --> Total execution time: 0.0896
DEBUG - 2022-08-21 00:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:03:19 --> Total execution time: 0.1239
DEBUG - 2022-08-21 00:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:03:34 --> Total execution time: 0.1126
DEBUG - 2022-08-21 00:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:33:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:03:49 --> Total execution time: 0.0605
DEBUG - 2022-08-21 00:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:09:53 --> Total execution time: 0.1735
DEBUG - 2022-08-21 00:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:40:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:10:16 --> Total execution time: 0.0667
DEBUG - 2022-08-21 00:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:12:25 --> Total execution time: 0.1420
DEBUG - 2022-08-21 00:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:44:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:14:11 --> Total execution time: 0.0870
DEBUG - 2022-08-21 00:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:14:33 --> Total execution time: 0.0856
DEBUG - 2022-08-21 00:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:15:06 --> Total execution time: 0.0912
DEBUG - 2022-08-21 00:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:15:49 --> Total execution time: 0.0977
DEBUG - 2022-08-21 00:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:17:15 --> Total execution time: 0.0859
DEBUG - 2022-08-21 00:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:17:19 --> Total execution time: 0.0804
DEBUG - 2022-08-21 00:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:20:21 --> Total execution time: 0.2643
DEBUG - 2022-08-21 00:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:22:39 --> Total execution time: 0.2809
DEBUG - 2022-08-21 00:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:54:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:24:30 --> Total execution time: 0.0956
DEBUG - 2022-08-21 00:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:25:55 --> Total execution time: 0.0599
DEBUG - 2022-08-21 00:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:25:56 --> Total execution time: 0.0536
DEBUG - 2022-08-21 00:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:26:05 --> Total execution time: 0.0857
DEBUG - 2022-08-21 00:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:57:33 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:27:33 --> Total execution time: 0.0586
DEBUG - 2022-08-21 00:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:58:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 00:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:28:08 --> Total execution time: 0.0615
DEBUG - 2022-08-21 00:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:28:49 --> Total execution time: 0.0864
DEBUG - 2022-08-21 00:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:59:07 --> Total execution time: 0.0880
DEBUG - 2022-08-21 00:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 00:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 00:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 00:59:16 --> Total execution time: 0.1079
DEBUG - 2022-08-21 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:30:02 --> Total execution time: 0.1077
DEBUG - 2022-08-21 01:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:30:06 --> Total execution time: 0.0970
DEBUG - 2022-08-21 01:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:00:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:30:19 --> Total execution time: 0.1035
DEBUG - 2022-08-21 01:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:00:28 --> Total execution time: 0.0877
DEBUG - 2022-08-21 01:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:00:30 --> Total execution time: 0.1225
DEBUG - 2022-08-21 01:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:00:31 --> Total execution time: 0.0969
DEBUG - 2022-08-21 01:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:31:27 --> Total execution time: 2.4874
DEBUG - 2022-08-21 01:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 01:01:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 01:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:32:11 --> Total execution time: 0.0948
DEBUG - 2022-08-21 01:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:32:13 --> Total execution time: 0.2440
DEBUG - 2022-08-21 01:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:33:40 --> Total execution time: 0.1205
DEBUG - 2022-08-21 01:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:34:13 --> Total execution time: 0.0944
DEBUG - 2022-08-21 01:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:35:04 --> Total execution time: 0.0755
DEBUG - 2022-08-21 01:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:40:36 --> Total execution time: 0.0953
DEBUG - 2022-08-21 01:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:39 --> Total execution time: 0.1351
DEBUG - 2022-08-21 01:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:50 --> Total execution time: 0.0920
DEBUG - 2022-08-21 01:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:42:40 --> Total execution time: 0.1077
DEBUG - 2022-08-21 01:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:43:03 --> Total execution time: 0.0972
DEBUG - 2022-08-21 01:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:43:05 --> Total execution time: 0.1018
DEBUG - 2022-08-21 01:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:43:06 --> Total execution time: 0.0893
DEBUG - 2022-08-21 01:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:43:07 --> Total execution time: 0.1518
DEBUG - 2022-08-21 01:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:13:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:43:08 --> Total execution time: 0.0976
DEBUG - 2022-08-21 01:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:43:08 --> Total execution time: 0.2243
DEBUG - 2022-08-21 01:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:43:08 --> Total execution time: 0.1928
DEBUG - 2022-08-21 01:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:15:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:45:40 --> Total execution time: 0.1082
DEBUG - 2022-08-21 01:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:45:41 --> Total execution time: 0.0863
DEBUG - 2022-08-21 01:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:45:54 --> Total execution time: 0.0539
DEBUG - 2022-08-21 01:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:45:56 --> Total execution time: 0.0472
DEBUG - 2022-08-21 01:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:45:56 --> Total execution time: 0.0466
DEBUG - 2022-08-21 01:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:45:59 --> Total execution time: 0.0770
DEBUG - 2022-08-21 01:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:09 --> Total execution time: 0.0948
DEBUG - 2022-08-21 01:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:16 --> Total execution time: 0.1370
DEBUG - 2022-08-21 01:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:17 --> Total execution time: 0.0855
DEBUG - 2022-08-21 01:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:21 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:21 --> Total execution time: 0.0502
DEBUG - 2022-08-21 01:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:22 --> Total execution time: 0.0546
DEBUG - 2022-08-21 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:29 --> Total execution time: 0.0494
DEBUG - 2022-08-21 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:29 --> Total execution time: 0.0931
DEBUG - 2022-08-21 01:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:29 --> Total execution time: 0.1063
DEBUG - 2022-08-21 01:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:36 --> Total execution time: 0.0902
DEBUG - 2022-08-21 01:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:38 --> Total execution time: 0.0822
DEBUG - 2022-08-21 01:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:42 --> Total execution time: 0.0558
DEBUG - 2022-08-21 01:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:45 --> Total execution time: 0.0952
DEBUG - 2022-08-21 01:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:49 --> Total execution time: 0.0888
DEBUG - 2022-08-21 01:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:51 --> Total execution time: 0.0789
DEBUG - 2022-08-21 01:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:53 --> Total execution time: 0.0932
DEBUG - 2022-08-21 01:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:47:09 --> Total execution time: 0.0882
DEBUG - 2022-08-21 01:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:47:09 --> Total execution time: 0.1215
DEBUG - 2022-08-21 01:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:47:14 --> Total execution time: 0.0894
DEBUG - 2022-08-21 01:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:47:20 --> Total execution time: 0.0906
DEBUG - 2022-08-21 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:47:31 --> Total execution time: 0.0825
DEBUG - 2022-08-21 01:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:55:04 --> Total execution time: 0.2958
DEBUG - 2022-08-21 01:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:55:43 --> Total execution time: 0.0839
DEBUG - 2022-08-21 01:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:56:39 --> Total execution time: 0.0531
DEBUG - 2022-08-21 01:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:58:16 --> Total execution time: 0.0840
DEBUG - 2022-08-21 01:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:31:00 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:01:00 --> Total execution time: 0.0595
DEBUG - 2022-08-21 01:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:32:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 01:32:25 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-21 01:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:02:53 --> Total execution time: 0.0991
DEBUG - 2022-08-21 01:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:02:54 --> Total execution time: 0.0859
DEBUG - 2022-08-21 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:35:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:05:30 --> Total execution time: 0.1616
DEBUG - 2022-08-21 01:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:05:55 --> Total execution time: 0.0576
DEBUG - 2022-08-21 01:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:36:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:06:11 --> Total execution time: 0.0565
DEBUG - 2022-08-21 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:06:17 --> Total execution time: 0.1178
DEBUG - 2022-08-21 01:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:06:40 --> Total execution time: 0.1140
DEBUG - 2022-08-21 01:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:06:52 --> Total execution time: 0.0983
DEBUG - 2022-08-21 01:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:06:55 --> Total execution time: 0.0991
DEBUG - 2022-08-21 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:07:04 --> Total execution time: 0.0850
DEBUG - 2022-08-21 01:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:37:18 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:07:18 --> Total execution time: 0.0920
DEBUG - 2022-08-21 01:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:37:43 --> Total execution time: 0.0878
DEBUG - 2022-08-21 01:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:37:57 --> Total execution time: 0.0959
DEBUG - 2022-08-21 01:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:37:57 --> Total execution time: 0.1043
DEBUG - 2022-08-21 01:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:08:35 --> Total execution time: 2.3463
DEBUG - 2022-08-21 01:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:08:35 --> Total execution time: 0.1044
DEBUG - 2022-08-21 01:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:08:36 --> Total execution time: 0.0966
DEBUG - 2022-08-21 01:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:08:39 --> Total execution time: 0.0942
DEBUG - 2022-08-21 01:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:38:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 01:38:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 01:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:40:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:10:43 --> Total execution time: 0.0547
DEBUG - 2022-08-21 01:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:10:45 --> Total execution time: 0.0822
DEBUG - 2022-08-21 01:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 01:41:25 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 01:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:11:36 --> Total execution time: 0.0891
DEBUG - 2022-08-21 01:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:12 --> Total execution time: 0.0911
DEBUG - 2022-08-21 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:20 --> Total execution time: 1.9307
DEBUG - 2022-08-21 01:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:20 --> Total execution time: 0.0969
DEBUG - 2022-08-21 01:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:24 --> Total execution time: 0.0920
DEBUG - 2022-08-21 01:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:42 --> Total execution time: 0.0918
DEBUG - 2022-08-21 01:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:43 --> Total execution time: 0.0901
DEBUG - 2022-08-21 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:15:03 --> Total execution time: 0.0779
DEBUG - 2022-08-21 01:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:16:41 --> Total execution time: 0.0806
DEBUG - 2022-08-21 01:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:49:21 --> Total execution time: 0.1104
DEBUG - 2022-08-21 01:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:25:16 --> Total execution time: 0.0841
DEBUG - 2022-08-21 01:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:25:30 --> Total execution time: 0.2792
DEBUG - 2022-08-21 01:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:25:32 --> Total execution time: 0.1015
DEBUG - 2022-08-21 01:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:27:59 --> Total execution time: 0.0525
DEBUG - 2022-08-21 01:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:07 --> Total execution time: 0.1030
DEBUG - 2022-08-21 01:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:12 --> Total execution time: 0.0754
DEBUG - 2022-08-21 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:21 --> Total execution time: 0.0776
DEBUG - 2022-08-21 01:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:58:22 --> Total execution time: 0.0798
DEBUG - 2022-08-21 01:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:24 --> Total execution time: 0.0792
DEBUG - 2022-08-21 01:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:58:24 --> Total execution time: 0.0834
DEBUG - 2022-08-21 01:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 01:58:25 --> Total execution time: 0.1773
DEBUG - 2022-08-21 01:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:28 --> No URI present. Default controller set.
DEBUG - 2022-08-21 01:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:28 --> Total execution time: 0.0938
DEBUG - 2022-08-21 01:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:31 --> Total execution time: 0.0807
DEBUG - 2022-08-21 01:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 01:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 01:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:29:13 --> Total execution time: 0.0855
DEBUG - 2022-08-21 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:30:02 --> Total execution time: 0.1644
DEBUG - 2022-08-21 02:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:05:45 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:35:45 --> Total execution time: 0.1110
DEBUG - 2022-08-21 02:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:36:49 --> Total execution time: 0.0910
DEBUG - 2022-08-21 02:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:39:16 --> Total execution time: 0.1083
DEBUG - 2022-08-21 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:39:26 --> Total execution time: 0.1158
DEBUG - 2022-08-21 02:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:39:42 --> Total execution time: 0.1407
DEBUG - 2022-08-21 02:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:12 --> Total execution time: 0.0808
DEBUG - 2022-08-21 02:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:15 --> Total execution time: 0.0967
DEBUG - 2022-08-21 02:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:22 --> Total execution time: 0.0754
DEBUG - 2022-08-21 02:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:29 --> Total execution time: 0.0812
DEBUG - 2022-08-21 02:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:40 --> Total execution time: 0.0862
DEBUG - 2022-08-21 02:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:44 --> Total execution time: 0.0893
DEBUG - 2022-08-21 02:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:50 --> Total execution time: 0.0939
DEBUG - 2022-08-21 02:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:10:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:53 --> Total execution time: 0.1272
DEBUG - 2022-08-21 02:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:41:05 --> Total execution time: 0.0861
DEBUG - 2022-08-21 02:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:11:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:41:13 --> Total execution time: 0.0985
DEBUG - 2022-08-21 02:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:11:22 --> Total execution time: 0.0917
DEBUG - 2022-08-21 02:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:11:24 --> Total execution time: 0.0906
DEBUG - 2022-08-21 02:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:11:25 --> Total execution time: 0.0880
DEBUG - 2022-08-21 02:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:43:23 --> Total execution time: 0.0933
DEBUG - 2022-08-21 02:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:43:54 --> Total execution time: 2.4931
DEBUG - 2022-08-21 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 02:13:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 02:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:45:10 --> Total execution time: 0.0899
DEBUG - 2022-08-21 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:45:17 --> Total execution time: 0.2577
DEBUG - 2022-08-21 02:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:45:59 --> Total execution time: 1.9909
DEBUG - 2022-08-21 02:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:46:10 --> Total execution time: 0.0957
DEBUG - 2022-08-21 02:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:46:21 --> Total execution time: 0.0810
DEBUG - 2022-08-21 02:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:46:24 --> Total execution time: 0.0900
DEBUG - 2022-08-21 02:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:46:43 --> Total execution time: 0.0861
DEBUG - 2022-08-21 02:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:46:58 --> Total execution time: 0.1121
DEBUG - 2022-08-21 02:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:50:32 --> Total execution time: 0.1518
DEBUG - 2022-08-21 02:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:21:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:51:16 --> Total execution time: 0.0601
DEBUG - 2022-08-21 02:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:21:32 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:51:32 --> Total execution time: 0.0554
DEBUG - 2022-08-21 02:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:21:47 --> Total execution time: 0.0981
DEBUG - 2022-08-21 02:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:21:49 --> Total execution time: 0.0876
DEBUG - 2022-08-21 02:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:21:50 --> Total execution time: 0.1089
DEBUG - 2022-08-21 02:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:22:07 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:52:07 --> Total execution time: 0.0860
DEBUG - 2022-08-21 02:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:52:39 --> Total execution time: 0.0838
DEBUG - 2022-08-21 02:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:52:50 --> Total execution time: 0.0955
DEBUG - 2022-08-21 02:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:23:32 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:53:32 --> Total execution time: 0.0589
DEBUG - 2022-08-21 02:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:53:40 --> Total execution time: 0.0835
DEBUG - 2022-08-21 02:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:54:11 --> Total execution time: 0.0829
DEBUG - 2022-08-21 02:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:54:31 --> Total execution time: 0.0998
DEBUG - 2022-08-21 02:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:54:41 --> Total execution time: 0.1163
DEBUG - 2022-08-21 02:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:55:00 --> Total execution time: 0.1252
DEBUG - 2022-08-21 02:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:55:15 --> Total execution time: 0.1007
DEBUG - 2022-08-21 02:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:55:21 --> Total execution time: 0.0988
DEBUG - 2022-08-21 02:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:55:29 --> Total execution time: 0.0826
DEBUG - 2022-08-21 02:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:55:37 --> Total execution time: 0.0915
DEBUG - 2022-08-21 02:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:55:54 --> Total execution time: 0.0856
DEBUG - 2022-08-21 02:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:28:05 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:58:05 --> Total execution time: 0.0588
DEBUG - 2022-08-21 02:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:28:12 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:58:13 --> Total execution time: 0.0891
DEBUG - 2022-08-21 02:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:58:24 --> Total execution time: 0.0870
DEBUG - 2022-08-21 02:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:58:53 --> Total execution time: 0.0805
DEBUG - 2022-08-21 02:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:58:54 --> Total execution time: 0.0888
DEBUG - 2022-08-21 02:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:58:55 --> Total execution time: 0.1059
DEBUG - 2022-08-21 02:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:29:04 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:59:04 --> Total execution time: 0.0526
DEBUG - 2022-08-21 02:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:59:06 --> Total execution time: 0.0958
DEBUG - 2022-08-21 02:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:29:40 --> Total execution time: 0.0887
DEBUG - 2022-08-21 02:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:32:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:02:19 --> Total execution time: 0.0595
DEBUG - 2022-08-21 02:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:32:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:02:25 --> Total execution time: 0.1041
DEBUG - 2022-08-21 02:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:02:26 --> Total execution time: 0.2226
DEBUG - 2022-08-21 02:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:32:40 --> Total execution time: 0.0829
DEBUG - 2022-08-21 02:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:32:42 --> Total execution time: 0.1022
DEBUG - 2022-08-21 02:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:32:43 --> Total execution time: 0.0869
DEBUG - 2022-08-21 02:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:33:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:03:16 --> Total execution time: 0.2155
DEBUG - 2022-08-21 02:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:03:22 --> Total execution time: 0.0850
DEBUG - 2022-08-21 02:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:33:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:03:38 --> Total execution time: 0.1244
DEBUG - 2022-08-21 02:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:04:29 --> Total execution time: 0.0879
DEBUG - 2022-08-21 02:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:04:33 --> Total execution time: 0.1098
DEBUG - 2022-08-21 02:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:04:53 --> Total execution time: 2.3647
DEBUG - 2022-08-21 02:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:04:53 --> Total execution time: 2.1526
DEBUG - 2022-08-21 02:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:04:55 --> Total execution time: 0.0854
DEBUG - 2022-08-21 02:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:05:14 --> Total execution time: 0.0887
DEBUG - 2022-08-21 02:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:06:07 --> Total execution time: 0.0866
DEBUG - 2022-08-21 02:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:06:26 --> Total execution time: 0.0902
DEBUG - 2022-08-21 02:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:06:29 --> Total execution time: 0.0962
DEBUG - 2022-08-21 02:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:36:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:06:35 --> Total execution time: 0.2390
DEBUG - 2022-08-21 02:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:06:42 --> Total execution time: 0.1554
DEBUG - 2022-08-21 02:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:06:54 --> Total execution time: 0.1175
DEBUG - 2022-08-21 02:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:07 --> Total execution time: 0.0894
DEBUG - 2022-08-21 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:20 --> Total execution time: 0.0971
DEBUG - 2022-08-21 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:20 --> Total execution time: 0.0974
DEBUG - 2022-08-21 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:20 --> Total execution time: 0.1045
DEBUG - 2022-08-21 02:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:20 --> Total execution time: 0.2628
DEBUG - 2022-08-21 02:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:24 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:25 --> Total execution time: 0.0931
DEBUG - 2022-08-21 02:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:32 --> Total execution time: 0.0994
DEBUG - 2022-08-21 02:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:37 --> Total execution time: 1.9676
DEBUG - 2022-08-21 02:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 02:37:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 02:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:50 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:07:50 --> Total execution time: 0.0979
DEBUG - 2022-08-21 02:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:37:53 --> Total execution time: 0.0859
DEBUG - 2022-08-21 02:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:00 --> Total execution time: 0.1275
DEBUG - 2022-08-21 13:08:00 --> Total execution time: 1.9407
DEBUG - 2022-08-21 02:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:11 --> Total execution time: 0.0842
DEBUG - 2022-08-21 02:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:13 --> Total execution time: 0.0810
DEBUG - 2022-08-21 02:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:24 --> Total execution time: 0.0769
DEBUG - 2022-08-21 02:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:34 --> Total execution time: 0.0906
DEBUG - 2022-08-21 02:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:37 --> Total execution time: 0.0761
DEBUG - 2022-08-21 02:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:51 --> Total execution time: 0.0787
DEBUG - 2022-08-21 02:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:38:52 --> Total execution time: 0.0828
DEBUG - 2022-08-21 02:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:39:05 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:09:05 --> Total execution time: 0.0590
DEBUG - 2022-08-21 02:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:09:13 --> Total execution time: 0.2188
DEBUG - 2022-08-21 02:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:09:16 --> Total execution time: 0.0834
DEBUG - 2022-08-21 02:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:09:20 --> Total execution time: 0.0910
DEBUG - 2022-08-21 02:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:39:33 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:09:33 --> Total execution time: 0.0697
DEBUG - 2022-08-21 02:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:09:39 --> Total execution time: 0.0823
DEBUG - 2022-08-21 02:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:09:46 --> Total execution time: 0.0823
DEBUG - 2022-08-21 02:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:09:52 --> Total execution time: 0.0888
DEBUG - 2022-08-21 02:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:10:33 --> Total execution time: 0.0548
DEBUG - 2022-08-21 02:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:40:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 02:40:55 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 02:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:41:07 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:11:07 --> Total execution time: 0.0625
DEBUG - 2022-08-21 02:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:41:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:11:38 --> Total execution time: 0.0591
DEBUG - 2022-08-21 02:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:41:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:11:47 --> Total execution time: 0.0560
DEBUG - 2022-08-21 02:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:43:07 --> Total execution time: 0.1021
DEBUG - 2022-08-21 02:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:43:09 --> Total execution time: 0.1044
DEBUG - 2022-08-21 02:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:43:10 --> Total execution time: 0.0816
DEBUG - 2022-08-21 02:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:14:28 --> Total execution time: 1.9987
DEBUG - 2022-08-21 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 02:44:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 02:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:15:14 --> Total execution time: 0.0554
DEBUG - 2022-08-21 02:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:15:18 --> Total execution time: 0.0851
DEBUG - 2022-08-21 02:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:15:19 --> Total execution time: 0.0770
DEBUG - 2022-08-21 02:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:15:20 --> Total execution time: 0.2389
DEBUG - 2022-08-21 02:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:15:32 --> Total execution time: 0.0856
DEBUG - 2022-08-21 02:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:15:43 --> Total execution time: 0.2209
DEBUG - 2022-08-21 02:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:15:52 --> Total execution time: 0.0520
DEBUG - 2022-08-21 02:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:15:56 --> Total execution time: 0.0828
DEBUG - 2022-08-21 02:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:16:02 --> Total execution time: 0.0855
DEBUG - 2022-08-21 02:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:16:04 --> Total execution time: 0.0993
DEBUG - 2022-08-21 02:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:16:06 --> Total execution time: 0.0868
DEBUG - 2022-08-21 02:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:16:18 --> Total execution time: 0.1300
DEBUG - 2022-08-21 02:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:16:19 --> Total execution time: 0.0881
DEBUG - 2022-08-21 02:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:16:37 --> Total execution time: 0.0938
DEBUG - 2022-08-21 02:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:17:28 --> Total execution time: 0.2233
DEBUG - 2022-08-21 02:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:18:21 --> Total execution time: 0.1185
DEBUG - 2022-08-21 02:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:48:57 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:18:57 --> Total execution time: 0.0647
DEBUG - 2022-08-21 02:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:19:09 --> Total execution time: 0.0852
DEBUG - 2022-08-21 02:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:49:12 --> Total execution time: 0.0887
DEBUG - 2022-08-21 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:49:19 --> Total execution time: 0.1473
DEBUG - 2022-08-21 02:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:19:33 --> Total execution time: 0.0819
DEBUG - 2022-08-21 02:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:21:13 --> Total execution time: 0.1286
DEBUG - 2022-08-21 02:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:21:25 --> Total execution time: 0.1233
DEBUG - 2022-08-21 02:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:22:05 --> Total execution time: 0.0958
DEBUG - 2022-08-21 02:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:22:24 --> Total execution time: 0.1222
DEBUG - 2022-08-21 02:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:22:32 --> Total execution time: 0.1213
DEBUG - 2022-08-21 02:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:22:45 --> Total execution time: 0.0994
DEBUG - 2022-08-21 02:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:23:03 --> Total execution time: 0.0890
DEBUG - 2022-08-21 02:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:23:08 --> Total execution time: 0.1379
DEBUG - 2022-08-21 02:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:23:18 --> Total execution time: 0.1287
DEBUG - 2022-08-21 02:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:23:18 --> Total execution time: 0.1334
DEBUG - 2022-08-21 02:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:24:13 --> Total execution time: 0.1294
DEBUG - 2022-08-21 02:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:24:14 --> Total execution time: 0.0951
DEBUG - 2022-08-21 02:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 02:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:24:21 --> Total execution time: 0.0890
DEBUG - 2022-08-21 02:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:54:22 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:24:22 --> Total execution time: 0.0902
DEBUG - 2022-08-21 02:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:58:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 02:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:28:43 --> Total execution time: 0.1363
DEBUG - 2022-08-21 02:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 02:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 02:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:28:44 --> Total execution time: 0.0484
DEBUG - 2022-08-21 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:30:02 --> Total execution time: 0.0595
DEBUG - 2022-08-21 13:30:02 --> Total execution time: 0.0891
DEBUG - 2022-08-21 03:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:30:23 --> Total execution time: 0.2219
DEBUG - 2022-08-21 03:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:30:26 --> Total execution time: 0.0868
DEBUG - 2022-08-21 03:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:30:56 --> Total execution time: 0.0793
DEBUG - 2022-08-21 03:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:31:20 --> Total execution time: 0.0892
DEBUG - 2022-08-21 03:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:31:32 --> Total execution time: 0.1274
DEBUG - 2022-08-21 03:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:31:46 --> Total execution time: 0.0786
DEBUG - 2022-08-21 03:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:31:52 --> Total execution time: 0.1013
DEBUG - 2022-08-21 03:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:31:53 --> Total execution time: 0.0758
DEBUG - 2022-08-21 03:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:01 --> Total execution time: 0.1201
DEBUG - 2022-08-21 03:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:09 --> Total execution time: 0.0857
DEBUG - 2022-08-21 03:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:09 --> Total execution time: 0.0906
DEBUG - 2022-08-21 03:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:12 --> Total execution time: 0.1299
DEBUG - 2022-08-21 03:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:18 --> Total execution time: 0.1011
DEBUG - 2022-08-21 03:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:19 --> Total execution time: 0.1319
DEBUG - 2022-08-21 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:24 --> Total execution time: 0.0878
DEBUG - 2022-08-21 03:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:25 --> Total execution time: 0.0917
DEBUG - 2022-08-21 03:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:41 --> Total execution time: 0.1109
DEBUG - 2022-08-21 03:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:04:38 --> Total execution time: 0.0895
DEBUG - 2022-08-21 03:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:34:45 --> Total execution time: 0.0979
DEBUG - 2022-08-21 03:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:34:52 --> Total execution time: 0.1061
DEBUG - 2022-08-21 03:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:34:55 --> Total execution time: 0.1147
DEBUG - 2022-08-21 03:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:35:04 --> Total execution time: 0.1203
DEBUG - 2022-08-21 03:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:35:13 --> Total execution time: 0.1240
DEBUG - 2022-08-21 03:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:06:15 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:36:15 --> Total execution time: 0.0611
DEBUG - 2022-08-21 03:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:07:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 03:07:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-21 03:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:37:53 --> Total execution time: 0.0633
DEBUG - 2022-08-21 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:38:35 --> Total execution time: 0.0972
DEBUG - 2022-08-21 03:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:38:39 --> Total execution time: 0.0823
DEBUG - 2022-08-21 03:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:38:47 --> Total execution time: 0.1148
DEBUG - 2022-08-21 03:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:38:49 --> Total execution time: 0.0845
DEBUG - 2022-08-21 03:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:08:51 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:38:51 --> Total execution time: 0.0565
DEBUG - 2022-08-21 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:38:57 --> Total execution time: 0.1110
DEBUG - 2022-08-21 03:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:39:07 --> Total execution time: 0.1256
DEBUG - 2022-08-21 03:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:39:15 --> Total execution time: 0.1015
DEBUG - 2022-08-21 03:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:39:17 --> Total execution time: 0.1110
DEBUG - 2022-08-21 03:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:39:41 --> Total execution time: 0.0867
DEBUG - 2022-08-21 03:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:09:56 --> Total execution time: 0.0840
DEBUG - 2022-08-21 03:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:10:04 --> Total execution time: 0.1124
DEBUG - 2022-08-21 03:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:10:55 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:40:55 --> Total execution time: 0.0612
DEBUG - 2022-08-21 03:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:41:38 --> Total execution time: 0.1147
DEBUG - 2022-08-21 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:41:42 --> Total execution time: 0.1155
DEBUG - 2022-08-21 03:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:42:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 03:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:42:18 --> Total execution time: 0.1153
DEBUG - 2022-08-21 03:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:42:29 --> Total execution time: 0.0877
DEBUG - 2022-08-21 03:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:15:14 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:45:15 --> Total execution time: 0.1375
DEBUG - 2022-08-21 03:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:15:20 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:45:20 --> Total execution time: 0.0898
DEBUG - 2022-08-21 03:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:16:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:46:49 --> Total execution time: 0.0669
DEBUG - 2022-08-21 03:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:49:06 --> Total execution time: 0.0894
DEBUG - 2022-08-21 03:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:49:34 --> Total execution time: 0.0901
DEBUG - 2022-08-21 03:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:49:36 --> Total execution time: 0.2173
DEBUG - 2022-08-21 03:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:49:41 --> Total execution time: 0.0950
DEBUG - 2022-08-21 03:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:49:42 --> Total execution time: 0.0864
DEBUG - 2022-08-21 03:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:49:46 --> Total execution time: 0.1155
DEBUG - 2022-08-21 03:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:49:48 --> Total execution time: 0.0858
DEBUG - 2022-08-21 03:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:49:57 --> Total execution time: 0.1197
DEBUG - 2022-08-21 03:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:50:01 --> Total execution time: 0.0890
DEBUG - 2022-08-21 03:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:50:08 --> Total execution time: 0.1357
DEBUG - 2022-08-21 03:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:50:14 --> Total execution time: 0.0861
DEBUG - 2022-08-21 03:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:50:28 --> Total execution time: 0.1537
DEBUG - 2022-08-21 03:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:51:32 --> Total execution time: 0.0929
DEBUG - 2022-08-21 03:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:51:40 --> Total execution time: 0.1146
DEBUG - 2022-08-21 03:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:52:05 --> Total execution time: 0.0910
DEBUG - 2022-08-21 03:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:52:13 --> Total execution time: 0.1064
DEBUG - 2022-08-21 03:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:52:29 --> Total execution time: 0.0850
DEBUG - 2022-08-21 03:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:52:57 --> Total execution time: 0.2213
DEBUG - 2022-08-21 03:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:00 --> Total execution time: 0.0870
DEBUG - 2022-08-21 03:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:18 --> Total execution time: 0.2362
DEBUG - 2022-08-21 03:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:32 --> Total execution time: 0.0842
DEBUG - 2022-08-21 03:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:32 --> Total execution time: 0.0812
DEBUG - 2022-08-21 03:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:35 --> Total execution time: 0.0590
DEBUG - 2022-08-21 03:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:39 --> Total execution time: 0.0883
DEBUG - 2022-08-21 03:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:43 --> Total execution time: 0.1136
DEBUG - 2022-08-21 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:44 --> Total execution time: 0.0863
DEBUG - 2022-08-21 03:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:50 --> Total execution time: 0.0941
DEBUG - 2022-08-21 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:52 --> Total execution time: 0.1207
DEBUG - 2022-08-21 03:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:55 --> Total execution time: 0.0822
DEBUG - 2022-08-21 03:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:57 --> Total execution time: 0.0863
DEBUG - 2022-08-21 03:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:01 --> Total execution time: 0.1187
DEBUG - 2022-08-21 03:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:02 --> Total execution time: 0.0860
DEBUG - 2022-08-21 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:05 --> Total execution time: 0.0890
DEBUG - 2022-08-21 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:07 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:08 --> Total execution time: 0.0621
DEBUG - 2022-08-21 03:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:08 --> Total execution time: 0.1063
DEBUG - 2022-08-21 03:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:16 --> Total execution time: 0.0965
DEBUG - 2022-08-21 03:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:20 --> Total execution time: 0.1424
DEBUG - 2022-08-21 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:29 --> Total execution time: 0.0892
DEBUG - 2022-08-21 03:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:33 --> Total execution time: 0.1283
DEBUG - 2022-08-21 03:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:34 --> Total execution time: 0.0981
DEBUG - 2022-08-21 03:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:36 --> Total execution time: 0.1025
DEBUG - 2022-08-21 03:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:49 --> Total execution time: 0.1086
DEBUG - 2022-08-21 03:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:54 --> Total execution time: 0.1269
DEBUG - 2022-08-21 03:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:56:10 --> Total execution time: 0.0916
DEBUG - 2022-08-21 03:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:56:15 --> Total execution time: 0.1387
DEBUG - 2022-08-21 03:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:26:22 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:56:23 --> Total execution time: 0.0797
DEBUG - 2022-08-21 03:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:26:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:56:47 --> Total execution time: 0.0884
DEBUG - 2022-08-21 03:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:56:56 --> Total execution time: 0.1198
DEBUG - 2022-08-21 03:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:00 --> Total execution time: 0.1118
DEBUG - 2022-08-21 03:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:15 --> Total execution time: 0.0821
DEBUG - 2022-08-21 03:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:20 --> Total execution time: 0.1098
DEBUG - 2022-08-21 03:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:28 --> Total execution time: 0.0993
DEBUG - 2022-08-21 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:35 --> Total execution time: 0.1150
DEBUG - 2022-08-21 03:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:40 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:40 --> Total execution time: 0.0717
DEBUG - 2022-08-21 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:42 --> Total execution time: 0.0545
DEBUG - 2022-08-21 03:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:48 --> Total execution time: 0.0545
DEBUG - 2022-08-21 03:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:49 --> Total execution time: 0.0945
DEBUG - 2022-08-21 03:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:58:26 --> Total execution time: 0.0868
DEBUG - 2022-08-21 03:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:58:34 --> Total execution time: 0.1340
DEBUG - 2022-08-21 03:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:58:51 --> Total execution time: 0.1168
DEBUG - 2022-08-21 03:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:58:55 --> Total execution time: 0.0909
DEBUG - 2022-08-21 03:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:59:16 --> Total execution time: 0.1095
DEBUG - 2022-08-21 03:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:59:25 --> Total execution time: 0.2156
DEBUG - 2022-08-21 03:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:59:34 --> Total execution time: 0.1180
DEBUG - 2022-08-21 03:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:00:10 --> Total execution time: 0.0967
DEBUG - 2022-08-21 03:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:00:34 --> Total execution time: 0.2341
DEBUG - 2022-08-21 03:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:00:43 --> Total execution time: 0.0976
DEBUG - 2022-08-21 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:30:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 03:30:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 03:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:30:59 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:00:59 --> Total execution time: 0.0579
DEBUG - 2022-08-21 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:31:45 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:01:45 --> Total execution time: 0.1554
DEBUG - 2022-08-21 03:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:31:46 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:01:46 --> Total execution time: 0.3170
DEBUG - 2022-08-21 03:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:02:23 --> Total execution time: 0.0563
DEBUG - 2022-08-21 03:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:02:31 --> Total execution time: 0.0859
DEBUG - 2022-08-21 03:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:32:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:02:35 --> Total execution time: 0.0879
DEBUG - 2022-08-21 03:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:02:45 --> Total execution time: 0.0868
DEBUG - 2022-08-21 03:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:02:56 --> Total execution time: 0.0956
DEBUG - 2022-08-21 03:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:03:02 --> Total execution time: 0.0954
DEBUG - 2022-08-21 03:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:03:12 --> Total execution time: 0.1065
DEBUG - 2022-08-21 03:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:03:32 --> Total execution time: 0.0957
DEBUG - 2022-08-21 03:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:34:28 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:04:28 --> Total execution time: 0.0559
DEBUG - 2022-08-21 03:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:06:55 --> Total execution time: 0.1155
DEBUG - 2022-08-21 03:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:07:02 --> Total execution time: 0.0911
DEBUG - 2022-08-21 03:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:37:57 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:07:57 --> Total execution time: 0.2319
DEBUG - 2022-08-21 03:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 03:38:13 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 03:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:10:05 --> Total execution time: 0.2284
DEBUG - 2022-08-21 03:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:10:11 --> Total execution time: 0.0978
DEBUG - 2022-08-21 03:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:40:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:10:29 --> Total execution time: 0.0578
DEBUG - 2022-08-21 03:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:10:47 --> Total execution time: 0.0563
DEBUG - 2022-08-21 03:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:04 --> Total execution time: 0.0963
DEBUG - 2022-08-21 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:13 --> Total execution time: 0.1377
DEBUG - 2022-08-21 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:47 --> Total execution time: 0.0911
DEBUG - 2022-08-21 03:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:53 --> Total execution time: 0.1040
DEBUG - 2022-08-21 03:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:12:12 --> Total execution time: 0.0827
DEBUG - 2022-08-21 03:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:12:38 --> Total execution time: 0.2500
DEBUG - 2022-08-21 03:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:14:12 --> Total execution time: 0.1269
DEBUG - 2022-08-21 03:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:14:22 --> Total execution time: 0.0937
DEBUG - 2022-08-21 03:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:14:29 --> Total execution time: 0.1136
DEBUG - 2022-08-21 03:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:14:46 --> Total execution time: 0.0963
DEBUG - 2022-08-21 03:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:14:53 --> Total execution time: 0.1295
DEBUG - 2022-08-21 03:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:02 --> Total execution time: 0.2194
DEBUG - 2022-08-21 03:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:09 --> Total execution time: 0.0822
DEBUG - 2022-08-21 03:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:45:34 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:34 --> Total execution time: 0.0618
DEBUG - 2022-08-21 03:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:19 --> Total execution time: 0.0819
DEBUG - 2022-08-21 03:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:30 --> Total execution time: 0.1117
DEBUG - 2022-08-21 03:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:34 --> Total execution time: 0.0907
DEBUG - 2022-08-21 03:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:41 --> Total execution time: 0.0901
DEBUG - 2022-08-21 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:44 --> Total execution time: 0.0981
DEBUG - 2022-08-21 03:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:49 --> Total execution time: 0.0826
DEBUG - 2022-08-21 03:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:51 --> Total execution time: 0.0816
DEBUG - 2022-08-21 03:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:59 --> Total execution time: 0.0879
DEBUG - 2022-08-21 03:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:17:04 --> Total execution time: 0.0889
DEBUG - 2022-08-21 03:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:17:07 --> Total execution time: 0.0978
DEBUG - 2022-08-21 03:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:17:13 --> Total execution time: 0.0826
DEBUG - 2022-08-21 03:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 03:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:17:42 --> Total execution time: 0.0815
DEBUG - 2022-08-21 03:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:51:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 03:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:21:01 --> Total execution time: 0.0620
DEBUG - 2022-08-21 03:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:21:40 --> Total execution time: 0.2329
DEBUG - 2022-08-21 03:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:27:25 --> Total execution time: 0.1687
DEBUG - 2022-08-21 03:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:27:32 --> Total execution time: 0.2538
DEBUG - 2022-08-21 03:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:27:36 --> Total execution time: 0.0968
DEBUG - 2022-08-21 03:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:27:36 --> Total execution time: 0.1206
DEBUG - 2022-08-21 03:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 03:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 03:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:27:41 --> Total execution time: 0.0840
DEBUG - 2022-08-21 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:30:02 --> Total execution time: 0.0818
DEBUG - 2022-08-21 04:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:22 --> Total execution time: 0.2251
DEBUG - 2022-08-21 04:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:42 --> Total execution time: 0.0958
DEBUG - 2022-08-21 04:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:49 --> Total execution time: 0.1193
DEBUG - 2022-08-21 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:55 --> Total execution time: 0.0920
DEBUG - 2022-08-21 04:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:58 --> Total execution time: 0.0900
DEBUG - 2022-08-21 04:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:01:59 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:59 --> Total execution time: 0.0760
DEBUG - 2022-08-21 04:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:32:04 --> Total execution time: 0.0820
DEBUG - 2022-08-21 04:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:32:07 --> Total execution time: 0.0881
DEBUG - 2022-08-21 04:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:32:21 --> Total execution time: 0.0909
DEBUG - 2022-08-21 04:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 04:02:27 --> 404 Page Not Found: Lessons/filmora-registration
DEBUG - 2022-08-21 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:32:46 --> Total execution time: 0.0956
DEBUG - 2022-08-21 04:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:34:27 --> Total execution time: 0.1759
DEBUG - 2022-08-21 04:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:34:28 --> Total execution time: 0.1368
DEBUG - 2022-08-21 04:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:34:37 --> Total execution time: 0.1049
DEBUG - 2022-08-21 04:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:34:44 --> Total execution time: 0.0846
DEBUG - 2022-08-21 04:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:36:10 --> Total execution time: 0.2468
DEBUG - 2022-08-21 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:36:23 --> Total execution time: 0.1261
DEBUG - 2022-08-21 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:06:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:36:39 --> Total execution time: 0.0572
DEBUG - 2022-08-21 04:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:36:48 --> Total execution time: 0.1151
DEBUG - 2022-08-21 04:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:37:07 --> Total execution time: 0.1066
DEBUG - 2022-08-21 04:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:38:44 --> Total execution time: 0.2224
DEBUG - 2022-08-21 04:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:39:34 --> Total execution time: 0.0946
DEBUG - 2022-08-21 04:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:09:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:39:48 --> Total execution time: 0.2168
DEBUG - 2022-08-21 04:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:39:50 --> Total execution time: 0.1138
DEBUG - 2022-08-21 04:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:39:56 --> Total execution time: 0.0920
DEBUG - 2022-08-21 04:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:40:04 --> Total execution time: 0.1021
DEBUG - 2022-08-21 04:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:40:18 --> Total execution time: 0.1177
DEBUG - 2022-08-21 04:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:42:49 --> Total execution time: 0.1203
DEBUG - 2022-08-21 04:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:45:28 --> Total execution time: 0.0849
DEBUG - 2022-08-21 04:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:13 --> Total execution time: 0.2240
DEBUG - 2022-08-21 04:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:17 --> Total execution time: 0.1048
DEBUG - 2022-08-21 04:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:21 --> Total execution time: 0.0937
DEBUG - 2022-08-21 04:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:31 --> Total execution time: 0.2257
DEBUG - 2022-08-21 04:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:31 --> Total execution time: 0.0961
DEBUG - 2022-08-21 04:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:41 --> Total execution time: 0.0911
DEBUG - 2022-08-21 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:48:33 --> Total execution time: 0.2653
DEBUG - 2022-08-21 04:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:49:10 --> Total execution time: 0.0849
DEBUG - 2022-08-21 04:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:20:10 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:50:10 --> Total execution time: 0.0576
DEBUG - 2022-08-21 04:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 04:22:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 04:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:22:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:52:53 --> Total execution time: 0.0910
DEBUG - 2022-08-21 04:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:23:10 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:53:10 --> Total execution time: 0.0561
DEBUG - 2022-08-21 04:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:55:33 --> Total execution time: 0.4681
DEBUG - 2022-08-21 04:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:55:40 --> Total execution time: 0.0888
DEBUG - 2022-08-21 04:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:55:53 --> Total execution time: 0.0887
DEBUG - 2022-08-21 04:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:56:16 --> Total execution time: 0.1138
DEBUG - 2022-08-21 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:26:24 --> Total execution time: 0.0841
DEBUG - 2022-08-21 04:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:56:25 --> Total execution time: 0.2277
DEBUG - 2022-08-21 04:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:56:28 --> Total execution time: 0.0578
DEBUG - 2022-08-21 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:56:35 --> Total execution time: 0.0851
DEBUG - 2022-08-21 04:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:26:38 --> Total execution time: 0.0913
DEBUG - 2022-08-21 04:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:26:43 --> Total execution time: 0.0983
DEBUG - 2022-08-21 04:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:26:55 --> Total execution time: 0.0923
DEBUG - 2022-08-21 04:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:27:02 --> Total execution time: 0.0880
DEBUG - 2022-08-21 04:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:27:10 --> Total execution time: 0.0784
DEBUG - 2022-08-21 04:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:27:25 --> Total execution time: 0.0795
DEBUG - 2022-08-21 04:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:57:31 --> Total execution time: 0.0664
DEBUG - 2022-08-21 04:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:37 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:57:37 --> Total execution time: 0.0549
DEBUG - 2022-08-21 04:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:27:42 --> Total execution time: 0.0824
DEBUG - 2022-08-21 04:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:28:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:58:43 --> Total execution time: 0.1027
DEBUG - 2022-08-21 04:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:28:58 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:58:58 --> Total execution time: 0.0884
DEBUG - 2022-08-21 04:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:59:02 --> Total execution time: 0.0853
DEBUG - 2022-08-21 04:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:29:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:59:06 --> Total execution time: 0.0868
DEBUG - 2022-08-21 04:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:59:16 --> Total execution time: 0.0868
DEBUG - 2022-08-21 04:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:59:26 --> Total execution time: 0.1294
DEBUG - 2022-08-21 04:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:59:30 --> Total execution time: 0.0930
DEBUG - 2022-08-21 04:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:29:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:59:53 --> Total execution time: 0.0688
DEBUG - 2022-08-21 04:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:00:37 --> Total execution time: 0.0556
DEBUG - 2022-08-21 04:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:30:46 --> Total execution time: 0.1697
DEBUG - 2022-08-21 04:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:00:46 --> Total execution time: 0.2276
DEBUG - 2022-08-21 04:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:07 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:07 --> Total execution time: 0.0567
DEBUG - 2022-08-21 04:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:08 --> Total execution time: 0.0670
DEBUG - 2022-08-21 04:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:10 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:10 --> Total execution time: 0.0547
DEBUG - 2022-08-21 04:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:11 --> Total execution time: 0.0625
DEBUG - 2022-08-21 04:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:11 --> Total execution time: 0.0630
DEBUG - 2022-08-21 04:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:12 --> Total execution time: 0.0735
DEBUG - 2022-08-21 04:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:13 --> Total execution time: 0.0528
DEBUG - 2022-08-21 04:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:14 --> Total execution time: 0.0532
DEBUG - 2022-08-21 04:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:17 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:17 --> Total execution time: 0.0546
DEBUG - 2022-08-21 04:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:18 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:18 --> Total execution time: 0.0501
DEBUG - 2022-08-21 04:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:22 --> Total execution time: 0.0869
DEBUG - 2022-08-21 04:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:25 --> Total execution time: 0.0537
DEBUG - 2022-08-21 04:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:30 --> Total execution time: 0.0933
DEBUG - 2022-08-21 04:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:33 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:33 --> Total execution time: 0.0549
DEBUG - 2022-08-21 04:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:38 --> Total execution time: 0.1477
DEBUG - 2022-08-21 04:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:31:48 --> Total execution time: 0.0914
DEBUG - 2022-08-21 04:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:31:51 --> Total execution time: 0.0875
DEBUG - 2022-08-21 04:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:31:51 --> Total execution time: 0.0881
DEBUG - 2022-08-21 04:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:31:52 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:01:52 --> Total execution time: 0.0579
DEBUG - 2022-08-21 04:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:02:03 --> Total execution time: 0.0897
DEBUG - 2022-08-21 04:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:02:18 --> Total execution time: 0.0886
DEBUG - 2022-08-21 04:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:02:24 --> Total execution time: 0.0886
DEBUG - 2022-08-21 04:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:02:33 --> Total execution time: 0.0980
DEBUG - 2022-08-21 04:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:02:46 --> Total execution time: 0.0876
DEBUG - 2022-08-21 04:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 04:32:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 04:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:05:06 --> Total execution time: 0.0843
DEBUG - 2022-08-21 04:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:38:07 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:08:07 --> Total execution time: 0.1299
DEBUG - 2022-08-21 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:40:51 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:10:52 --> Total execution time: 0.1427
DEBUG - 2022-08-21 04:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:11:29 --> Total execution time: 0.2775
DEBUG - 2022-08-21 04:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:41:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:11:47 --> Total execution time: 0.0623
DEBUG - 2022-08-21 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:11:59 --> Total execution time: 0.3230
DEBUG - 2022-08-21 04:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:12:11 --> Total execution time: 0.0561
DEBUG - 2022-08-21 04:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:12:37 --> Total execution time: 0.0830
DEBUG - 2022-08-21 04:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:12:56 --> Total execution time: 0.0947
DEBUG - 2022-08-21 04:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:13:21 --> Total execution time: 0.1172
DEBUG - 2022-08-21 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:13:22 --> Total execution time: 0.1138
DEBUG - 2022-08-21 04:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:13:31 --> Total execution time: 0.1122
DEBUG - 2022-08-21 04:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:13:47 --> Total execution time: 0.0878
DEBUG - 2022-08-21 04:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:13:51 --> Total execution time: 0.1113
DEBUG - 2022-08-21 04:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:14:00 --> Total execution time: 0.1365
DEBUG - 2022-08-21 04:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:14:18 --> Total execution time: 0.1083
DEBUG - 2022-08-21 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:20 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:14:20 --> Total execution time: 0.0545
DEBUG - 2022-08-21 04:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:24 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:14:24 --> Total execution time: 0.0829
DEBUG - 2022-08-21 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:14:26 --> Total execution time: 0.0892
DEBUG - 2022-08-21 04:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:14:36 --> Total execution time: 0.1118
DEBUG - 2022-08-21 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:44:45 --> Total execution time: 0.0960
DEBUG - 2022-08-21 04:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:14:55 --> Total execution time: 0.1331
DEBUG - 2022-08-21 04:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:45:05 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:15:05 --> Total execution time: 0.0573
DEBUG - 2022-08-21 04:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:15:09 --> Total execution time: 0.0883
DEBUG - 2022-08-21 04:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:15:21 --> Total execution time: 0.0962
DEBUG - 2022-08-21 04:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:15:38 --> Total execution time: 0.2066
DEBUG - 2022-08-21 04:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:15:55 --> Total execution time: 0.1192
DEBUG - 2022-08-21 04:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:46:10 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:16:11 --> Total execution time: 0.0730
DEBUG - 2022-08-21 04:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:16:35 --> Total execution time: 0.2195
DEBUG - 2022-08-21 04:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:16:44 --> Total execution time: 0.0905
DEBUG - 2022-08-21 04:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:16:45 --> Total execution time: 0.1096
DEBUG - 2022-08-21 04:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:16:46 --> Total execution time: 0.1068
DEBUG - 2022-08-21 04:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:17:13 --> Total execution time: 0.2168
DEBUG - 2022-08-21 04:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:47:18 --> Total execution time: 0.0828
DEBUG - 2022-08-21 04:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:17:22 --> Total execution time: 0.0884
DEBUG - 2022-08-21 04:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:17:27 --> Total execution time: 0.0892
DEBUG - 2022-08-21 04:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:17:29 --> Total execution time: 0.0585
DEBUG - 2022-08-21 04:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:17:34 --> Total execution time: 0.0908
DEBUG - 2022-08-21 04:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 04:47:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 04:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:17:52 --> Total execution time: 0.0928
DEBUG - 2022-08-21 04:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:48:04 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:18:04 --> Total execution time: 0.1224
DEBUG - 2022-08-21 04:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:18:13 --> Total execution time: 0.0555
DEBUG - 2022-08-21 04:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:18:25 --> Total execution time: 0.1018
DEBUG - 2022-08-21 04:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:18:30 --> Total execution time: 0.1131
DEBUG - 2022-08-21 04:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:18:45 --> Total execution time: 0.1055
DEBUG - 2022-08-21 04:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:18:55 --> Total execution time: 0.0956
DEBUG - 2022-08-21 04:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:19:00 --> Total execution time: 0.0849
DEBUG - 2022-08-21 04:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:19:13 --> Total execution time: 0.0886
DEBUG - 2022-08-21 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:19:21 --> Total execution time: 0.0870
DEBUG - 2022-08-21 04:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:19:30 --> Total execution time: 0.1146
DEBUG - 2022-08-21 04:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:19:42 --> Total execution time: 0.1011
DEBUG - 2022-08-21 04:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:20:00 --> Total execution time: 0.1675
DEBUG - 2022-08-21 04:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:20:17 --> Total execution time: 0.0896
DEBUG - 2022-08-21 04:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:20:21 --> Total execution time: 0.0919
DEBUG - 2022-08-21 04:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:52:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:22:19 --> Total execution time: 0.0571
DEBUG - 2022-08-21 04:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:52:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:22:47 --> Total execution time: 0.0580
DEBUG - 2022-08-21 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:22:53 --> Total execution time: 0.0942
DEBUG - 2022-08-21 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:02 --> Total execution time: 0.0931
DEBUG - 2022-08-21 04:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:08 --> Total execution time: 0.0815
DEBUG - 2022-08-21 04:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:21 --> Total execution time: 0.0881
DEBUG - 2022-08-21 04:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:22 --> Total execution time: 0.0889
DEBUG - 2022-08-21 04:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:26 --> Total execution time: 0.1255
DEBUG - 2022-08-21 04:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:32 --> Total execution time: 0.0911
DEBUG - 2022-08-21 04:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:40 --> Total execution time: 0.0882
DEBUG - 2022-08-21 04:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:48 --> Total execution time: 0.1020
DEBUG - 2022-08-21 04:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:23:53 --> Total execution time: 0.1068
DEBUG - 2022-08-21 04:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:24:05 --> Total execution time: 0.1025
DEBUG - 2022-08-21 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:55:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:25:01 --> Total execution time: 0.0689
DEBUG - 2022-08-21 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:55:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:25:42 --> Total execution time: 0.0792
DEBUG - 2022-08-21 04:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:25:48 --> Total execution time: 0.0909
DEBUG - 2022-08-21 04:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:25:55 --> Total execution time: 0.0985
DEBUG - 2022-08-21 04:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:26:00 --> Total execution time: 0.0955
DEBUG - 2022-08-21 04:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:26:08 --> Total execution time: 0.0929
DEBUG - 2022-08-21 04:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:26:12 --> Total execution time: 0.0884
DEBUG - 2022-08-21 04:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:26:18 --> Total execution time: 0.0914
DEBUG - 2022-08-21 04:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:26:25 --> Total execution time: 0.0905
DEBUG - 2022-08-21 04:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:26:36 --> Total execution time: 0.0836
DEBUG - 2022-08-21 04:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:26:36 --> Total execution time: 0.0863
DEBUG - 2022-08-21 04:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 04:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 04:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 04:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:29:57 --> Total execution time: 0.0925
DEBUG - 2022-08-21 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:30:02 --> Total execution time: 0.0631
DEBUG - 2022-08-21 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:00:59 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:30:59 --> Total execution time: 0.0563
DEBUG - 2022-08-21 05:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:32:44 --> Total execution time: 0.0869
DEBUG - 2022-08-21 05:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:32:55 --> Total execution time: 0.0541
DEBUG - 2022-08-21 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:03:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:33:48 --> Total execution time: 0.0607
DEBUG - 2022-08-21 05:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:04:36 --> Total execution time: 0.1054
DEBUG - 2022-08-21 05:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:04:38 --> Total execution time: 0.0853
DEBUG - 2022-08-21 05:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:04:38 --> Total execution time: 0.0884
DEBUG - 2022-08-21 05:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:08:37 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:38:37 --> Total execution time: 0.1556
DEBUG - 2022-08-21 05:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:09:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:39:11 --> Total execution time: 0.0595
DEBUG - 2022-08-21 05:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:10:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:40:16 --> Total execution time: 0.0595
DEBUG - 2022-08-21 05:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:10:20 --> 404 Page Not Found: Https:/www.esalestrix.in
DEBUG - 2022-08-21 05:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:40:22 --> Total execution time: 0.0523
DEBUG - 2022-08-21 05:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:10:23 --> 404 Page Not Found: Https:/esalestrix.in
DEBUG - 2022-08-21 05:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:13:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:13:03 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 05:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:13:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:13:04 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 05:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:13:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:13:04 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-21 05:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:13:59 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 05:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:14:00 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 05:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:14:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:14:00 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-21 05:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:44:10 --> Total execution time: 0.1351
DEBUG - 2022-08-21 05:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:14:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:44:31 --> Total execution time: 0.0632
DEBUG - 2022-08-21 05:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:14:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:44:35 --> Total execution time: 0.0894
DEBUG - 2022-08-21 05:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:14:37 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:44:37 --> Total execution time: 0.1117
DEBUG - 2022-08-21 05:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:14:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:44:38 --> Total execution time: 0.0842
DEBUG - 2022-08-21 05:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:14:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:44:53 --> Total execution time: 0.0550
DEBUG - 2022-08-21 05:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:15:08 --> Total execution time: 0.0865
DEBUG - 2022-08-21 05:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:15:10 --> Total execution time: 0.0883
DEBUG - 2022-08-21 05:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:15:10 --> Total execution time: 0.1940
DEBUG - 2022-08-21 05:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:15:45 --> Total execution time: 0.0833
DEBUG - 2022-08-21 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:15:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:45:47 --> Total execution time: 0.0551
DEBUG - 2022-08-21 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:15:47 --> Total execution time: 0.0976
DEBUG - 2022-08-21 05:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:15:48 --> Total execution time: 0.0873
DEBUG - 2022-08-21 05:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:16:22 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:46:23 --> Total execution time: 0.0849
DEBUG - 2022-08-21 05:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:46:38 --> Total execution time: 0.0553
DEBUG - 2022-08-21 05:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:16:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:46:42 --> Total execution time: 0.0577
DEBUG - 2022-08-21 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:17:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:47:08 --> Total execution time: 0.0587
DEBUG - 2022-08-21 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:17:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:47:08 --> Total execution time: 0.0555
DEBUG - 2022-08-21 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:17:40 --> Total execution time: 0.0596
DEBUG - 2022-08-21 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:47:53 --> Total execution time: 0.0590
DEBUG - 2022-08-21 05:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:48:48 --> Total execution time: 0.2476
DEBUG - 2022-08-21 05:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:49:02 --> Total execution time: 0.0943
DEBUG - 2022-08-21 05:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:49:16 --> Total execution time: 0.0846
DEBUG - 2022-08-21 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:49:35 --> Total execution time: 0.2716
DEBUG - 2022-08-21 05:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:49:58 --> Total execution time: 0.0862
DEBUG - 2022-08-21 05:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:49:58 --> Total execution time: 0.1892
DEBUG - 2022-08-21 05:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:49:59 --> Total execution time: 0.0808
DEBUG - 2022-08-21 05:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:49:59 --> Total execution time: 0.1487
DEBUG - 2022-08-21 05:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:59 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:49:59 --> Total execution time: 0.0849
DEBUG - 2022-08-21 05:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 15:50:00 --> Total execution time: 0.1425
DEBUG - 2022-08-21 05:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:00 --> Total execution time: 0.1662
DEBUG - 2022-08-21 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:01 --> Total execution time: 0.1048
DEBUG - 2022-08-21 05:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 15:50:01 --> Total execution time: 0.1799
DEBUG - 2022-08-21 05:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:01 --> Total execution time: 0.1380
DEBUG - 2022-08-21 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:02 --> Total execution time: 0.1123
DEBUG - 2022-08-21 05:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:02 --> Total execution time: 0.0935
DEBUG - 2022-08-21 05:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:02 --> Total execution time: 0.0901
DEBUG - 2022-08-21 05:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:03 --> Total execution time: 0.0811
DEBUG - 2022-08-21 05:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:04 --> Total execution time: 0.1048
DEBUG - 2022-08-21 05:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:05 --> Total execution time: 0.0822
DEBUG - 2022-08-21 05:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:12 --> Total execution time: 0.2185
DEBUG - 2022-08-21 05:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:15 --> Total execution time: 0.0938
DEBUG - 2022-08-21 05:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:16 --> Total execution time: 0.1151
DEBUG - 2022-08-21 05:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:17 --> Total execution time: 0.0946
DEBUG - 2022-08-21 05:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:17 --> Total execution time: 0.1269
DEBUG - 2022-08-21 05:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:18 --> Total execution time: 0.1155
DEBUG - 2022-08-21 05:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:27 --> Total execution time: 0.0956
DEBUG - 2022-08-21 05:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:31 --> Total execution time: 0.1314
DEBUG - 2022-08-21 05:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:38 --> Total execution time: 0.1400
DEBUG - 2022-08-21 05:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:40 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:40 --> Total execution time: 0.1330
DEBUG - 2022-08-21 05:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:50:55 --> Total execution time: 0.1800
DEBUG - 2022-08-21 05:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:51:16 --> Total execution time: 0.1258
DEBUG - 2022-08-21 05:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:51:29 --> Total execution time: 0.0881
DEBUG - 2022-08-21 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:52:11 --> Total execution time: 0.0955
DEBUG - 2022-08-21 05:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:52:20 --> Total execution time: 0.0942
DEBUG - 2022-08-21 05:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:22:27 --> Total execution time: 0.0846
DEBUG - 2022-08-21 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:22:36 --> Total execution time: 0.0848
DEBUG - 2022-08-21 05:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:52:49 --> Total execution time: 0.0928
DEBUG - 2022-08-21 05:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:22:49 --> Total execution time: 0.1970
DEBUG - 2022-08-21 05:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:52:51 --> Total execution time: 0.0867
DEBUG - 2022-08-21 05:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:53:23 --> Total execution time: 0.0846
DEBUG - 2022-08-21 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:53:24 --> Total execution time: 0.0817
DEBUG - 2022-08-21 05:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:53:26 --> Total execution time: 0.0917
DEBUG - 2022-08-21 05:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:53:35 --> Total execution time: 0.0926
DEBUG - 2022-08-21 05:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:53:47 --> Total execution time: 0.0881
DEBUG - 2022-08-21 05:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:53:53 --> Total execution time: 0.2331
DEBUG - 2022-08-21 05:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:54:01 --> Total execution time: 0.3173
DEBUG - 2022-08-21 05:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:54:29 --> Total execution time: 0.1513
DEBUG - 2022-08-21 05:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:54:41 --> Total execution time: 0.0870
DEBUG - 2022-08-21 05:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:55:18 --> Total execution time: 0.0924
DEBUG - 2022-08-21 05:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:25:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:55:25 --> Total execution time: 0.2249
DEBUG - 2022-08-21 05:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:25:39 --> Total execution time: 0.0860
DEBUG - 2022-08-21 05:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:25:42 --> Total execution time: 0.0863
DEBUG - 2022-08-21 05:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:25:42 --> Total execution time: 0.0930
DEBUG - 2022-08-21 05:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:56:04 --> Total execution time: 0.0910
DEBUG - 2022-08-21 05:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:56:11 --> Total execution time: 0.1151
DEBUG - 2022-08-21 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:56:37 --> Total execution time: 0.1020
DEBUG - 2022-08-21 05:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:56:47 --> Total execution time: 0.0986
DEBUG - 2022-08-21 05:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:56:58 --> Total execution time: 0.0901
DEBUG - 2022-08-21 05:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:57:05 --> Total execution time: 0.0861
DEBUG - 2022-08-21 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:58:13 --> Total execution time: 0.0693
DEBUG - 2022-08-21 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:59:44 --> Total execution time: 0.0863
DEBUG - 2022-08-21 05:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:00:22 --> Total execution time: 0.0844
DEBUG - 2022-08-21 05:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:30:22 --> Total execution time: 0.1311
DEBUG - 2022-08-21 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:00:36 --> Total execution time: 0.2270
DEBUG - 2022-08-21 05:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:00:39 --> Total execution time: 0.0880
DEBUG - 2022-08-21 05:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:30:51 --> Total execution time: 0.0831
DEBUG - 2022-08-21 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:30:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:00:53 --> Total execution time: 0.0928
DEBUG - 2022-08-21 05:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:30:54 --> Total execution time: 0.0884
DEBUG - 2022-08-21 05:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:31:03 --> Total execution time: 0.0823
DEBUG - 2022-08-21 05:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:31:05 --> Total execution time: 0.0910
DEBUG - 2022-08-21 05:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:31:06 --> Total execution time: 0.0952
DEBUG - 2022-08-21 05:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:01:27 --> Total execution time: 0.1787
DEBUG - 2022-08-21 05:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:02:34 --> Total execution time: 0.2187
DEBUG - 2022-08-21 05:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:02:49 --> Total execution time: 0.0912
DEBUG - 2022-08-21 05:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:03:02 --> Total execution time: 0.2456
DEBUG - 2022-08-21 05:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:02 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:03:02 --> Total execution time: 0.0918
DEBUG - 2022-08-21 05:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:33:13 --> Total execution time: 0.0905
DEBUG - 2022-08-21 05:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:33:15 --> Total execution time: 0.0958
DEBUG - 2022-08-21 05:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:33:16 --> Total execution time: 0.0876
DEBUG - 2022-08-21 05:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:03:22 --> Total execution time: 0.0983
DEBUG - 2022-08-21 05:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:03:29 --> Total execution time: 0.0807
DEBUG - 2022-08-21 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:03:31 --> Total execution time: 0.0959
DEBUG - 2022-08-21 05:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:03:35 --> Total execution time: 0.0861
DEBUG - 2022-08-21 05:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:03:57 --> Total execution time: 0.1021
DEBUG - 2022-08-21 05:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:04:30 --> Total execution time: 0.0627
DEBUG - 2022-08-21 05:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:34:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:04:30 --> Total execution time: 0.0996
DEBUG - 2022-08-21 05:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:04:31 --> Total execution time: 0.0542
DEBUG - 2022-08-21 05:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:04:50 --> Total execution time: 0.0869
DEBUG - 2022-08-21 05:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:05:16 --> Total execution time: 0.0845
DEBUG - 2022-08-21 05:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:05:24 --> Total execution time: 0.1127
DEBUG - 2022-08-21 05:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:05:52 --> Total execution time: 0.0865
DEBUG - 2022-08-21 05:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:06:13 --> Total execution time: 0.0818
DEBUG - 2022-08-21 05:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:36:18 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:06:18 --> Total execution time: 0.0564
DEBUG - 2022-08-21 05:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:06:27 --> Total execution time: 0.0743
DEBUG - 2022-08-21 05:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:06:31 --> Total execution time: 0.0803
DEBUG - 2022-08-21 05:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:06:51 --> Total execution time: 0.0892
DEBUG - 2022-08-21 05:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:07:23 --> Total execution time: 0.0858
DEBUG - 2022-08-21 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:07:25 --> Total execution time: 0.0892
DEBUG - 2022-08-21 05:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:07:48 --> Total execution time: 0.0990
DEBUG - 2022-08-21 05:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:07:54 --> Total execution time: 0.1150
DEBUG - 2022-08-21 05:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:08:04 --> Total execution time: 0.1093
DEBUG - 2022-08-21 05:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:04 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:08:04 --> Total execution time: 0.0736
DEBUG - 2022-08-21 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:38:25 --> Total execution time: 0.0840
DEBUG - 2022-08-21 05:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:38:27 --> Total execution time: 0.0861
DEBUG - 2022-08-21 05:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:38:28 --> Total execution time: 0.1063
DEBUG - 2022-08-21 05:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:08:35 --> Total execution time: 0.0591
DEBUG - 2022-08-21 05:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:08:37 --> Total execution time: 0.1078
DEBUG - 2022-08-21 05:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:38:39 --> Total execution time: 0.0846
DEBUG - 2022-08-21 05:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:08:45 --> Total execution time: 0.0998
DEBUG - 2022-08-21 05:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:38:45 --> Total execution time: 0.1084
DEBUG - 2022-08-21 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:08:50 --> Total execution time: 0.1587
DEBUG - 2022-08-21 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:08:51 --> Total execution time: 0.1546
DEBUG - 2022-08-21 05:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:08:59 --> Total execution time: 0.0915
DEBUG - 2022-08-21 05:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:09:00 --> Total execution time: 0.0991
DEBUG - 2022-08-21 05:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:09:08 --> Total execution time: 0.1402
DEBUG - 2022-08-21 05:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:09:18 --> Total execution time: 0.0904
DEBUG - 2022-08-21 05:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:09:23 --> Total execution time: 2.5819
DEBUG - 2022-08-21 05:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 05:39:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 05:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:09:30 --> Total execution time: 0.1111
DEBUG - 2022-08-21 05:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:09:35 --> Total execution time: 0.1133
DEBUG - 2022-08-21 05:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:09:46 --> Total execution time: 0.0927
DEBUG - 2022-08-21 05:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:10:00 --> Total execution time: 0.1125
DEBUG - 2022-08-21 05:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:10:09 --> Total execution time: 0.1037
DEBUG - 2022-08-21 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:10:43 --> Total execution time: 0.1079
DEBUG - 2022-08-21 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:40:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:10:48 --> Total execution time: 0.3875
DEBUG - 2022-08-21 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:10:48 --> Total execution time: 0.1429
DEBUG - 2022-08-21 05:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:40:55 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:10:55 --> Total execution time: 0.0866
DEBUG - 2022-08-21 05:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:11:19 --> Total execution time: 0.0935
DEBUG - 2022-08-21 05:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:21 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:11:21 --> Total execution time: 0.0825
DEBUG - 2022-08-21 05:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:22 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:11:22 --> Total execution time: 0.0580
DEBUG - 2022-08-21 05:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:11:28 --> Total execution time: 0.0932
DEBUG - 2022-08-21 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:41:30 --> Total execution time: 0.1004
DEBUG - 2022-08-21 05:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:41:32 --> Total execution time: 0.1351
DEBUG - 2022-08-21 05:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:41:33 --> Total execution time: 0.0982
DEBUG - 2022-08-21 05:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:11:39 --> Total execution time: 0.0980
DEBUG - 2022-08-21 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:11:42 --> Total execution time: 0.1005
DEBUG - 2022-08-21 05:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:11:51 --> Total execution time: 0.1409
DEBUG - 2022-08-21 05:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:11:59 --> Total execution time: 0.1065
DEBUG - 2022-08-21 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:12:16 --> Total execution time: 0.1717
DEBUG - 2022-08-21 05:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:12:23 --> Total execution time: 0.1010
DEBUG - 2022-08-21 05:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:45:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:15:39 --> Total execution time: 0.1881
DEBUG - 2022-08-21 05:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:46:12 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:16:12 --> Total execution time: 0.0594
DEBUG - 2022-08-21 05:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:46:24 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:16:24 --> Total execution time: 0.0942
DEBUG - 2022-08-21 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:18:40 --> Total execution time: 0.1177
DEBUG - 2022-08-21 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:49:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 05:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:19:32 --> Total execution time: 0.1285
DEBUG - 2022-08-21 05:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:19:35 --> Total execution time: 0.1329
DEBUG - 2022-08-21 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:20:12 --> Total execution time: 0.0910
DEBUG - 2022-08-21 05:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:20:13 --> Total execution time: 0.0893
DEBUG - 2022-08-21 05:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:20:20 --> Total execution time: 0.0962
DEBUG - 2022-08-21 05:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:20:23 --> Total execution time: 0.1095
DEBUG - 2022-08-21 05:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:20:27 --> Total execution time: 0.0934
DEBUG - 2022-08-21 05:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:20:56 --> Total execution time: 0.0951
DEBUG - 2022-08-21 05:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:20:58 --> Total execution time: 0.0892
DEBUG - 2022-08-21 05:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:21:02 --> Total execution time: 0.1134
DEBUG - 2022-08-21 05:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:21:46 --> Total execution time: 0.0867
DEBUG - 2022-08-21 05:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:22:12 --> Total execution time: 0.0883
DEBUG - 2022-08-21 05:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:22:17 --> Total execution time: 0.1411
DEBUG - 2022-08-21 05:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:22:21 --> Total execution time: 0.0975
DEBUG - 2022-08-21 05:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:22:53 --> Total execution time: 0.0976
DEBUG - 2022-08-21 05:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:28:05 --> Total execution time: 0.1447
DEBUG - 2022-08-21 05:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:28:16 --> Total execution time: 0.2289
DEBUG - 2022-08-21 05:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:28:54 --> Total execution time: 0.1016
DEBUG - 2022-08-21 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:59:30 --> Total execution time: 0.0972
DEBUG - 2022-08-21 05:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 05:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:29:32 --> Total execution time: 0.1026
DEBUG - 2022-08-21 05:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 05:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 05:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:29:32 --> Total execution time: 0.0816
DEBUG - 2022-08-21 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:30:02 --> Total execution time: 0.0656
DEBUG - 2022-08-21 06:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:00:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:30:38 --> Total execution time: 0.0659
DEBUG - 2022-08-21 06:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:00:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:30:38 --> Total execution time: 0.0830
DEBUG - 2022-08-21 06:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:00:54 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:30:54 --> Total execution time: 0.0570
DEBUG - 2022-08-21 06:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:31:38 --> Total execution time: 0.0911
DEBUG - 2022-08-21 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:02:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:32:06 --> Total execution time: 0.0724
DEBUG - 2022-08-21 06:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:02:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:32:08 --> Total execution time: 0.0845
DEBUG - 2022-08-21 06:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:32:20 --> Total execution time: 0.0610
DEBUG - 2022-08-21 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:32:29 --> Total execution time: 0.1568
DEBUG - 2022-08-21 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:32:39 --> Total execution time: 0.0908
DEBUG - 2022-08-21 06:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:32:43 --> Total execution time: 0.1302
DEBUG - 2022-08-21 06:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:32:50 --> Total execution time: 0.1228
DEBUG - 2022-08-21 06:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:33:07 --> Total execution time: 0.0907
DEBUG - 2022-08-21 06:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:03:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:33:13 --> Total execution time: 0.0743
DEBUG - 2022-08-21 06:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:04:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:34:35 --> Total execution time: 0.0732
DEBUG - 2022-08-21 06:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:05:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:35:14 --> Total execution time: 0.0884
DEBUG - 2022-08-21 06:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:37:51 --> Total execution time: 0.0899
DEBUG - 2022-08-21 06:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:07:54 --> Total execution time: 0.2182
DEBUG - 2022-08-21 06:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:07:56 --> Total execution time: 0.1060
DEBUG - 2022-08-21 06:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:07:57 --> Total execution time: 0.0833
DEBUG - 2022-08-21 06:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:38:02 --> Total execution time: 0.1445
DEBUG - 2022-08-21 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:38:08 --> Total execution time: 0.0896
DEBUG - 2022-08-21 06:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:38:16 --> Total execution time: 0.0963
DEBUG - 2022-08-21 06:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:38:16 --> Total execution time: 0.0871
DEBUG - 2022-08-21 06:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:38:28 --> Total execution time: 0.0868
DEBUG - 2022-08-21 06:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:38:40 --> Total execution time: 0.1195
DEBUG - 2022-08-21 06:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:50 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:38:50 --> Total execution time: 0.1150
DEBUG - 2022-08-21 06:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:39:01 --> Total execution time: 2.2993
DEBUG - 2022-08-21 06:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:09:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 06:09:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 06:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:39:22 --> Total execution time: 0.0906
DEBUG - 2022-08-21 06:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:39:30 --> Total execution time: 0.2488
DEBUG - 2022-08-21 06:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:39:37 --> Total execution time: 0.1177
DEBUG - 2022-08-21 06:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:39:42 --> Total execution time: 0.0986
DEBUG - 2022-08-21 06:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:39:48 --> Total execution time: 0.0917
DEBUG - 2022-08-21 06:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:40:06 --> Total execution time: 0.0976
DEBUG - 2022-08-21 06:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:40:17 --> Total execution time: 0.1444
DEBUG - 2022-08-21 06:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:40:28 --> Total execution time: 0.0910
DEBUG - 2022-08-21 06:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:10:41 --> Total execution time: 0.0863
DEBUG - 2022-08-21 06:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:10:44 --> Total execution time: 0.0929
DEBUG - 2022-08-21 06:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:10:44 --> Total execution time: 0.1159
DEBUG - 2022-08-21 06:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:11:17 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:41:17 --> Total execution time: 0.0760
DEBUG - 2022-08-21 06:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:41:49 --> Total execution time: 0.1376
DEBUG - 2022-08-21 06:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:12:17 --> Total execution time: 0.0824
DEBUG - 2022-08-21 06:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:12:22 --> Total execution time: 0.0921
DEBUG - 2022-08-21 06:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:12:23 --> Total execution time: 0.1059
DEBUG - 2022-08-21 06:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:42:38 --> Total execution time: 0.1167
DEBUG - 2022-08-21 06:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:12:44 --> Total execution time: 0.0888
DEBUG - 2022-08-21 06:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:12:45 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:42:45 --> Total execution time: 0.0948
DEBUG - 2022-08-21 06:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:13:23 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:43:23 --> Total execution time: 0.2541
DEBUG - 2022-08-21 06:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:43:40 --> Total execution time: 1.6777
DEBUG - 2022-08-21 06:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:45:16 --> Total execution time: 0.1353
DEBUG - 2022-08-21 06:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:45:23 --> Total execution time: 0.1133
DEBUG - 2022-08-21 06:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:45:38 --> Total execution time: 0.1122
DEBUG - 2022-08-21 06:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:45:44 --> Total execution time: 0.0986
DEBUG - 2022-08-21 06:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:46:06 --> Total execution time: 0.1136
DEBUG - 2022-08-21 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:46:41 --> Total execution time: 0.0842
DEBUG - 2022-08-21 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:48:00 --> Total execution time: 0.0542
DEBUG - 2022-08-21 06:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:48:01 --> Total execution time: 0.0790
DEBUG - 2022-08-21 06:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:48:13 --> Total execution time: 0.0840
DEBUG - 2022-08-21 06:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:18:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:48:29 --> Total execution time: 0.2319
DEBUG - 2022-08-21 06:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:18:51 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:48:51 --> Total execution time: 0.0608
DEBUG - 2022-08-21 06:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:49:39 --> Total execution time: 0.0878
DEBUG - 2022-08-21 06:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:50:53 --> Total execution time: 0.0688
DEBUG - 2022-08-21 06:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:51:08 --> Total execution time: 0.1517
DEBUG - 2022-08-21 06:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:51:10 --> Total execution time: 0.0865
DEBUG - 2022-08-21 06:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:51:19 --> Total execution time: 0.1488
DEBUG - 2022-08-21 06:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:51:33 --> Total execution time: 0.0528
DEBUG - 2022-08-21 06:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:51:44 --> Total execution time: 0.0993
DEBUG - 2022-08-21 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:57:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:57:40 --> Total execution time: 0.1336
DEBUG - 2022-08-21 06:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:27:52 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:57:53 --> Total execution time: 0.0901
DEBUG - 2022-08-21 06:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:27:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:57:53 --> Total execution time: 0.0572
DEBUG - 2022-08-21 06:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:58:16 --> Total execution time: 0.2498
DEBUG - 2022-08-21 06:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:58:30 --> Total execution time: 0.0940
DEBUG - 2022-08-21 06:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:59:06 --> Total execution time: 0.2264
DEBUG - 2022-08-21 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:29:16 --> Total execution time: 0.0916
DEBUG - 2022-08-21 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:29:18 --> Total execution time: 0.0949
DEBUG - 2022-08-21 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:29:18 --> Total execution time: 0.0898
DEBUG - 2022-08-21 06:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:59:20 --> Total execution time: 0.1374
DEBUG - 2022-08-21 06:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:59:29 --> Total execution time: 0.0922
DEBUG - 2022-08-21 06:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:59:29 --> Total execution time: 0.0888
DEBUG - 2022-08-21 06:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:59:31 --> Total execution time: 0.1229
DEBUG - 2022-08-21 06:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:59:45 --> Total execution time: 0.1086
DEBUG - 2022-08-21 06:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:59:46 --> Total execution time: 0.1054
DEBUG - 2022-08-21 06:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:59:48 --> Total execution time: 0.1033
DEBUG - 2022-08-21 06:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:00:35 --> Total execution time: 0.0853
DEBUG - 2022-08-21 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:00:43 --> Total execution time: 0.0853
DEBUG - 2022-08-21 06:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:00:44 --> Total execution time: 0.0876
DEBUG - 2022-08-21 06:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:05:04 --> Total execution time: 0.1354
DEBUG - 2022-08-21 06:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:05:29 --> Total execution time: 0.1089
DEBUG - 2022-08-21 06:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:05:33 --> Total execution time: 0.0871
DEBUG - 2022-08-21 06:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:05:35 --> Total execution time: 0.1328
DEBUG - 2022-08-21 06:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:05:52 --> Total execution time: 0.0849
DEBUG - 2022-08-21 06:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:38:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:08:02 --> Total execution time: 0.0649
DEBUG - 2022-08-21 06:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:39:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:09:09 --> Total execution time: 0.0945
DEBUG - 2022-08-21 06:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:39:29 --> Total execution time: 0.0843
DEBUG - 2022-08-21 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:39:32 --> Total execution time: 0.0923
DEBUG - 2022-08-21 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:39:32 --> Total execution time: 0.0879
DEBUG - 2022-08-21 06:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:39:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:09:38 --> Total execution time: 0.0894
DEBUG - 2022-08-21 06:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:39:45 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:09:45 --> Total execution time: 0.0667
DEBUG - 2022-08-21 06:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:09:49 --> Total execution time: 0.0579
DEBUG - 2022-08-21 06:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:10:02 --> Total execution time: 0.1428
DEBUG - 2022-08-21 06:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:10:08 --> Total execution time: 0.1196
DEBUG - 2022-08-21 06:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:10:11 --> Total execution time: 0.1099
DEBUG - 2022-08-21 06:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:10:45 --> Total execution time: 0.0938
DEBUG - 2022-08-21 06:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:11:16 --> Total execution time: 0.1494
DEBUG - 2022-08-21 06:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:11:43 --> Total execution time: 0.0709
DEBUG - 2022-08-21 06:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:15:03 --> Total execution time: 0.1954
DEBUG - 2022-08-21 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:06 --> Total execution time: 0.0868
DEBUG - 2022-08-21 06:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:11 --> Total execution time: 0.0671
DEBUG - 2022-08-21 06:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 06:46:13 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 06:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:15 --> Total execution time: 0.0854
DEBUG - 2022-08-21 06:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:20 --> Total execution time: 0.0944
DEBUG - 2022-08-21 06:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:25 --> Total execution time: 0.1046
DEBUG - 2022-08-21 06:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:29 --> Total execution time: 0.0938
DEBUG - 2022-08-21 06:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:39 --> Total execution time: 0.2581
DEBUG - 2022-08-21 06:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:47 --> Total execution time: 0.2338
DEBUG - 2022-08-21 06:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:48 --> Total execution time: 0.0824
DEBUG - 2022-08-21 06:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:50 --> Total execution time: 0.0870
DEBUG - 2022-08-21 06:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:50 --> Total execution time: 0.0857
DEBUG - 2022-08-21 06:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:54 --> Total execution time: 0.1044
DEBUG - 2022-08-21 06:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:57 --> Total execution time: 0.0981
DEBUG - 2022-08-21 06:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:16:58 --> Total execution time: 0.0894
DEBUG - 2022-08-21 06:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:17:17 --> Total execution time: 0.0936
DEBUG - 2022-08-21 06:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:17:35 --> Total execution time: 0.0863
DEBUG - 2022-08-21 06:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:18:27 --> Total execution time: 0.0885
DEBUG - 2022-08-21 06:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:19:11 --> Total execution time: 0.0940
DEBUG - 2022-08-21 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:20:01 --> Total execution time: 0.0897
DEBUG - 2022-08-21 06:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:50:27 --> No URI present. Default controller set.
DEBUG - 2022-08-21 06:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:20:27 --> Total execution time: 0.0551
DEBUG - 2022-08-21 06:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:22:59 --> Total execution time: 0.3633
DEBUG - 2022-08-21 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:23:18 --> Total execution time: 0.1456
DEBUG - 2022-08-21 06:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:23:30 --> Total execution time: 0.0918
DEBUG - 2022-08-21 06:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:23:37 --> Total execution time: 0.0902
DEBUG - 2022-08-21 06:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:23:40 --> Total execution time: 0.1011
DEBUG - 2022-08-21 06:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:24:01 --> Total execution time: 0.0971
DEBUG - 2022-08-21 06:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:25:17 --> Total execution time: 0.1006
DEBUG - 2022-08-21 06:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:25:23 --> Total execution time: 0.1200
DEBUG - 2022-08-21 06:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:25:27 --> Total execution time: 0.0920
DEBUG - 2022-08-21 06:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:26:28 --> Total execution time: 0.0934
DEBUG - 2022-08-21 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:27:53 --> Total execution time: 0.0850
DEBUG - 2022-08-21 06:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 06:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:29:02 --> Total execution time: 0.0857
DEBUG - 2022-08-21 06:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 06:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 06:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:29:33 --> Total execution time: 0.1117
DEBUG - 2022-08-21 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:30:02 --> Total execution time: 0.0757
DEBUG - 2022-08-21 07:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:00:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:30:08 --> Total execution time: 0.0868
DEBUG - 2022-08-21 07:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:01:56 --> Total execution time: 0.0784
DEBUG - 2022-08-21 07:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:32:03 --> Total execution time: 0.0816
DEBUG - 2022-08-21 07:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:32:13 --> Total execution time: 0.1266
DEBUG - 2022-08-21 07:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:32:15 --> Total execution time: 0.1174
DEBUG - 2022-08-21 07:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:32:20 --> Total execution time: 0.1055
DEBUG - 2022-08-21 07:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:32:23 --> Total execution time: 0.1164
DEBUG - 2022-08-21 07:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:32:42 --> Total execution time: 0.1324
DEBUG - 2022-08-21 07:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:34:45 --> Total execution time: 0.0875
DEBUG - 2022-08-21 07:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:35:09 --> Total execution time: 0.0845
DEBUG - 2022-08-21 07:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:35:17 --> Total execution time: 0.0904
DEBUG - 2022-08-21 07:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:35:23 --> Total execution time: 0.0904
DEBUG - 2022-08-21 07:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:35:30 --> Total execution time: 0.2496
DEBUG - 2022-08-21 07:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:35:33 --> Total execution time: 0.1027
DEBUG - 2022-08-21 07:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:35:35 --> Total execution time: 0.1085
DEBUG - 2022-08-21 07:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:35:38 --> Total execution time: 0.0947
DEBUG - 2022-08-21 07:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:36:27 --> Total execution time: 0.1059
DEBUG - 2022-08-21 07:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:36:31 --> Total execution time: 0.0959
DEBUG - 2022-08-21 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:36:38 --> Total execution time: 0.0926
DEBUG - 2022-08-21 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:36:44 --> Total execution time: 0.0538
DEBUG - 2022-08-21 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:08:44 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:38:44 --> Total execution time: 0.0634
DEBUG - 2022-08-21 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:39:50 --> Total execution time: 0.0785
DEBUG - 2022-08-21 07:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:40:09 --> Total execution time: 0.1196
DEBUG - 2022-08-21 07:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:40:27 --> Total execution time: 0.1139
DEBUG - 2022-08-21 07:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:40:32 --> Total execution time: 0.0856
DEBUG - 2022-08-21 07:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:40:39 --> Total execution time: 0.0865
DEBUG - 2022-08-21 07:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:40:47 --> Total execution time: 0.1016
DEBUG - 2022-08-21 07:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:41:20 --> Total execution time: 0.1105
DEBUG - 2022-08-21 07:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:41:43 --> Total execution time: 0.1080
DEBUG - 2022-08-21 07:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:41:44 --> Total execution time: 0.0899
DEBUG - 2022-08-21 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:41:46 --> Total execution time: 0.0911
DEBUG - 2022-08-21 07:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:41:47 --> Total execution time: 0.0877
DEBUG - 2022-08-21 07:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:41:47 --> Total execution time: 0.0844
DEBUG - 2022-08-21 07:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:11:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:41:48 --> Total execution time: 0.0814
DEBUG - 2022-08-21 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:43:32 --> Total execution time: 0.1132
DEBUG - 2022-08-21 07:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:45:44 --> Total execution time: 0.2830
DEBUG - 2022-08-21 07:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:45:48 --> Total execution time: 0.0957
DEBUG - 2022-08-21 07:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:45:51 --> Total execution time: 0.0862
DEBUG - 2022-08-21 07:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:46:47 --> Total execution time: 0.0886
DEBUG - 2022-08-21 07:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:47:29 --> Total execution time: 0.0841
DEBUG - 2022-08-21 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:49:46 --> Total execution time: 0.0907
DEBUG - 2022-08-21 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:49:56 --> Total execution time: 0.0893
DEBUG - 2022-08-21 07:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 07:19:59 --> 404 Page Not Found: Lessons/instagram-profile-optimization
DEBUG - 2022-08-21 07:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:50:16 --> Total execution time: 0.0874
DEBUG - 2022-08-21 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:50:22 --> Total execution time: 0.1147
DEBUG - 2022-08-21 07:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:21:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:51:36 --> Total execution time: 0.0628
DEBUG - 2022-08-21 07:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:21:37 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:51:37 --> Total execution time: 0.0592
DEBUG - 2022-08-21 07:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:51:41 --> Total execution time: 0.0855
DEBUG - 2022-08-21 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:52:16 --> Total execution time: 0.0916
DEBUG - 2022-08-21 07:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:52:50 --> Total execution time: 0.0769
DEBUG - 2022-08-21 07:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:54:20 --> Total execution time: 0.0910
DEBUG - 2022-08-21 07:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:54:37 --> Total execution time: 0.0817
DEBUG - 2022-08-21 07:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:57:45 --> Total execution time: 0.0890
DEBUG - 2022-08-21 07:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:58:11 --> Total execution time: 0.0876
DEBUG - 2022-08-21 07:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:58:28 --> Total execution time: 0.1480
DEBUG - 2022-08-21 07:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:58:45 --> Total execution time: 0.2231
DEBUG - 2022-08-21 07:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:59:06 --> Total execution time: 0.0921
DEBUG - 2022-08-21 07:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:59:17 --> Total execution time: 0.0908
DEBUG - 2022-08-21 07:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:59:26 --> Total execution time: 0.0969
DEBUG - 2022-08-21 07:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:59:41 --> Total execution time: 0.0873
DEBUG - 2022-08-21 07:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:00:30 --> Total execution time: 0.0846
DEBUG - 2022-08-21 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:00:34 --> Total execution time: 0.0967
DEBUG - 2022-08-21 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:00:34 --> Total execution time: 0.0896
DEBUG - 2022-08-21 07:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:01:16 --> Total execution time: 0.0967
DEBUG - 2022-08-21 07:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:01:23 --> Total execution time: 0.0926
DEBUG - 2022-08-21 07:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:01:33 --> Total execution time: 0.0927
DEBUG - 2022-08-21 07:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:01:59 --> Total execution time: 0.0886
DEBUG - 2022-08-21 07:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:02:16 --> Total execution time: 0.1566
DEBUG - 2022-08-21 07:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:32:33 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:02:33 --> Total execution time: 0.0614
DEBUG - 2022-08-21 07:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:02:33 --> Total execution time: 0.0901
DEBUG - 2022-08-21 07:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:02:39 --> Total execution time: 0.0554
DEBUG - 2022-08-21 07:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:02:54 --> Total execution time: 0.0950
DEBUG - 2022-08-21 07:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:03:14 --> Total execution time: 0.0909
DEBUG - 2022-08-21 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:03:44 --> Total execution time: 0.0809
DEBUG - 2022-08-21 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:03:52 --> Total execution time: 0.0887
DEBUG - 2022-08-21 07:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:03:56 --> Total execution time: 0.1045
DEBUG - 2022-08-21 07:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:04:07 --> Total execution time: 0.0992
DEBUG - 2022-08-21 07:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:04:20 --> Total execution time: 0.0823
DEBUG - 2022-08-21 07:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:04:25 --> Total execution time: 0.2272
DEBUG - 2022-08-21 07:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:04:48 --> Total execution time: 0.0880
DEBUG - 2022-08-21 07:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:05:02 --> Total execution time: 0.0926
DEBUG - 2022-08-21 07:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:05:57 --> Total execution time: 0.0972
DEBUG - 2022-08-21 07:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:06:00 --> Total execution time: 0.0880
DEBUG - 2022-08-21 07:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:06:06 --> Total execution time: 0.2240
DEBUG - 2022-08-21 07:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:06:25 --> Total execution time: 0.1262
DEBUG - 2022-08-21 07:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:06:48 --> Total execution time: 0.0948
DEBUG - 2022-08-21 07:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:06:54 --> Total execution time: 0.1264
DEBUG - 2022-08-21 07:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:07:04 --> Total execution time: 0.0910
DEBUG - 2022-08-21 07:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:07:16 --> Total execution time: 0.0900
DEBUG - 2022-08-21 07:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:07:23 --> Total execution time: 0.0910
DEBUG - 2022-08-21 07:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:07:33 --> Total execution time: 0.0898
DEBUG - 2022-08-21 07:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:07:37 --> Total execution time: 0.1105
DEBUG - 2022-08-21 07:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:08:38 --> Total execution time: 0.1000
DEBUG - 2022-08-21 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:08:56 --> Total execution time: 0.0830
DEBUG - 2022-08-21 07:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:09:03 --> Total execution time: 0.0879
DEBUG - 2022-08-21 07:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:09:53 --> Total execution time: 0.2227
DEBUG - 2022-08-21 07:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:39:55 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:09:56 --> Total execution time: 0.0579
DEBUG - 2022-08-21 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:41:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:11:01 --> Total execution time: 0.1125
DEBUG - 2022-08-21 07:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:11:58 --> Total execution time: 0.0832
DEBUG - 2022-08-21 07:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:13:37 --> Total execution time: 0.0826
DEBUG - 2022-08-21 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:13:58 --> Total execution time: 0.0799
DEBUG - 2022-08-21 07:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:15:01 --> Total execution time: 0.3675
DEBUG - 2022-08-21 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:15:37 --> Total execution time: 0.0903
DEBUG - 2022-08-21 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:15:48 --> Total execution time: 0.1262
DEBUG - 2022-08-21 07:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:16:00 --> Total execution time: 0.0900
DEBUG - 2022-08-21 07:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:16:04 --> Total execution time: 0.2294
DEBUG - 2022-08-21 07:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:16:22 --> Total execution time: 0.0831
DEBUG - 2022-08-21 07:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:16:34 --> Total execution time: 0.1195
DEBUG - 2022-08-21 07:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:16:37 --> Total execution time: 0.1133
DEBUG - 2022-08-21 07:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:16:51 --> Total execution time: 0.2224
DEBUG - 2022-08-21 07:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:17:47 --> Total execution time: 0.0847
DEBUG - 2022-08-21 07:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:17:52 --> Total execution time: 0.0811
DEBUG - 2022-08-21 07:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:18:02 --> Total execution time: 0.0865
DEBUG - 2022-08-21 07:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:18:16 --> Total execution time: 0.0888
DEBUG - 2022-08-21 07:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:18:27 --> Total execution time: 0.1438
DEBUG - 2022-08-21 07:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:00 --> No URI present. Default controller set.
DEBUG - 2022-08-21 07:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:19:00 --> Total execution time: 0.0571
DEBUG - 2022-08-21 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:19:07 --> Total execution time: 0.0917
DEBUG - 2022-08-21 07:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:19:11 --> Total execution time: 0.1053
DEBUG - 2022-08-21 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:19:12 --> Total execution time: 0.1475
DEBUG - 2022-08-21 07:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:19:15 --> Total execution time: 0.1585
DEBUG - 2022-08-21 07:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:19:20 --> Total execution time: 0.0934
DEBUG - 2022-08-21 07:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:19:27 --> Total execution time: 0.0967
DEBUG - 2022-08-21 07:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:49:41 --> Total execution time: 0.0898
DEBUG - 2022-08-21 07:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:49:43 --> Total execution time: 0.0887
DEBUG - 2022-08-21 07:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 07:49:43 --> Total execution time: 0.0817
DEBUG - 2022-08-21 07:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:20:40 --> Total execution time: 0.0842
DEBUG - 2022-08-21 07:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:27:45 --> Total execution time: 0.2828
DEBUG - 2022-08-21 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 07:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 07:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:30:02 --> Total execution time: 0.0726
DEBUG - 2022-08-21 08:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:30:07 --> Total execution time: 0.1178
DEBUG - 2022-08-21 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:30:10 --> Total execution time: 0.2935
DEBUG - 2022-08-21 08:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:30:17 --> Total execution time: 0.0910
DEBUG - 2022-08-21 08:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:30:53 --> Total execution time: 0.2288
DEBUG - 2022-08-21 08:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:03:50 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:33:50 --> Total execution time: 0.0634
DEBUG - 2022-08-21 08:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:04:02 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:34:02 --> Total execution time: 0.1089
DEBUG - 2022-08-21 08:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:04:38 --> Total execution time: 0.1052
DEBUG - 2022-08-21 08:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:04:42 --> Total execution time: 0.0906
DEBUG - 2022-08-21 08:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:04:42 --> Total execution time: 0.0874
DEBUG - 2022-08-21 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 08:05:48 --> 404 Page Not Found: Affiliate-tos-page-2/esalestrix.in
DEBUG - 2022-08-21 08:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:06:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:36:06 --> Total execution time: 0.0612
DEBUG - 2022-08-21 08:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:36:10 --> Total execution time: 0.0640
DEBUG - 2022-08-21 08:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:36:12 --> Total execution time: 0.0933
DEBUG - 2022-08-21 08:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:36:22 --> Total execution time: 0.0864
DEBUG - 2022-08-21 08:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:36:31 --> Total execution time: 0.1059
DEBUG - 2022-08-21 08:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:36:38 --> Total execution time: 0.1231
DEBUG - 2022-08-21 08:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:36:54 --> Total execution time: 0.1304
DEBUG - 2022-08-21 08:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:37:01 --> Total execution time: 0.1594
DEBUG - 2022-08-21 08:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:37:02 --> Total execution time: 0.0928
DEBUG - 2022-08-21 08:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:37:02 --> Total execution time: 0.2271
DEBUG - 2022-08-21 08:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:37:12 --> Total execution time: 0.1160
DEBUG - 2022-08-21 08:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:37:13 --> Total execution time: 0.0910
DEBUG - 2022-08-21 08:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:37:15 --> Total execution time: 0.0956
DEBUG - 2022-08-21 08:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:07:18 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:37:18 --> Total execution time: 0.1499
DEBUG - 2022-08-21 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:38:41 --> Total execution time: 0.0829
DEBUG - 2022-08-21 18:38:41 --> Total execution time: 2.5323
DEBUG - 2022-08-21 08:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:08:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:38:42 --> Total execution time: 0.0546
DEBUG - 2022-08-21 08:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:08:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 08:08:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 08:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:09:04 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:39:04 --> Total execution time: 0.0858
DEBUG - 2022-08-21 08:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:39:27 --> Total execution time: 0.1057
DEBUG - 2022-08-21 08:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:39:35 --> Total execution time: 0.0866
DEBUG - 2022-08-21 08:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:39:42 --> Total execution time: 0.1326
DEBUG - 2022-08-21 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:39:55 --> Total execution time: 0.0876
DEBUG - 2022-08-21 08:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:41:55 --> Total execution time: 0.0901
DEBUG - 2022-08-21 08:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:41:57 --> Total execution time: 0.2513
DEBUG - 2022-08-21 08:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:42:17 --> Total execution time: 0.1084
DEBUG - 2022-08-21 08:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:42:19 --> Total execution time: 0.0563
DEBUG - 2022-08-21 08:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:42:26 --> Total execution time: 0.0921
DEBUG - 2022-08-21 08:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:42:27 --> Total execution time: 0.0542
DEBUG - 2022-08-21 08:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:42:33 --> Total execution time: 0.0903
DEBUG - 2022-08-21 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:42:35 --> Total execution time: 0.0872
DEBUG - 2022-08-21 08:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:42:41 --> Total execution time: 0.1150
DEBUG - 2022-08-21 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:42:48 --> Total execution time: 0.0832
DEBUG - 2022-08-21 08:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:43:32 --> Total execution time: 0.0887
DEBUG - 2022-08-21 08:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:43:50 --> Total execution time: 0.1255
DEBUG - 2022-08-21 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:15:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:45:36 --> Total execution time: 0.0581
DEBUG - 2022-08-21 08:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:15:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:45:53 --> Total execution time: 0.0574
DEBUG - 2022-08-21 08:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:45:57 --> Total execution time: 0.0995
DEBUG - 2022-08-21 08:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:46:02 --> Total execution time: 0.0998
DEBUG - 2022-08-21 08:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:16:07 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:46:07 --> Total execution time: 0.0727
DEBUG - 2022-08-21 08:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:16:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:46:08 --> Total execution time: 0.0564
DEBUG - 2022-08-21 08:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:46:09 --> Total execution time: 0.1162
DEBUG - 2022-08-21 08:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:46:50 --> Total execution time: 0.0851
DEBUG - 2022-08-21 08:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:17:58 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:47:58 --> Total execution time: 0.0918
DEBUG - 2022-08-21 08:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:48:02 --> Total execution time: 0.0937
DEBUG - 2022-08-21 08:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:48:27 --> Total execution time: 0.1120
DEBUG - 2022-08-21 08:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:48:49 --> Total execution time: 0.0900
DEBUG - 2022-08-21 08:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:48:59 --> Total execution time: 0.0911
DEBUG - 2022-08-21 08:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:49:15 --> Total execution time: 0.0976
DEBUG - 2022-08-21 08:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:49:20 --> Total execution time: 0.0913
DEBUG - 2022-08-21 08:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:49:32 --> Total execution time: 0.0954
DEBUG - 2022-08-21 08:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:51:27 --> Total execution time: 0.2205
DEBUG - 2022-08-21 08:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:21:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:51:31 --> Total execution time: 0.0578
DEBUG - 2022-08-21 08:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:51:38 --> Total execution time: 0.1121
DEBUG - 2022-08-21 08:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:51:58 --> Total execution time: 0.1245
DEBUG - 2022-08-21 08:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:52:44 --> Total execution time: 0.1168
DEBUG - 2022-08-21 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:24:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:54:50 --> Total execution time: 0.1295
DEBUG - 2022-08-21 08:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:24:59 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:54:59 --> Total execution time: 0.0884
DEBUG - 2022-08-21 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:55:14 --> Total execution time: 0.0870
DEBUG - 2022-08-21 08:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:55:15 --> Total execution time: 0.0523
DEBUG - 2022-08-21 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:55:16 --> Total execution time: 0.0943
DEBUG - 2022-08-21 08:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:55:33 --> Total execution time: 0.0827
DEBUG - 2022-08-21 08:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:56:11 --> Total execution time: 0.0886
DEBUG - 2022-08-21 08:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:56:19 --> Total execution time: 0.0816
DEBUG - 2022-08-21 08:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:57:12 --> Total execution time: 0.0801
DEBUG - 2022-08-21 08:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:57:22 --> Total execution time: 0.0811
DEBUG - 2022-08-21 08:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:57:23 --> Total execution time: 0.0950
DEBUG - 2022-08-21 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:27:54 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:57:54 --> Total execution time: 0.0624
DEBUG - 2022-08-21 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:58:08 --> Total execution time: 0.0949
DEBUG - 2022-08-21 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:28:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:58:13 --> Total execution time: 0.0797
DEBUG - 2022-08-21 08:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:58:19 --> Total execution time: 0.0815
DEBUG - 2022-08-21 08:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:28:26 --> Total execution time: 0.1018
DEBUG - 2022-08-21 08:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:58:38 --> Total execution time: 0.0830
DEBUG - 2022-08-21 08:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:30:03 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:00:03 --> Total execution time: 0.2394
DEBUG - 2022-08-21 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:00:15 --> Total execution time: 0.0848
DEBUG - 2022-08-21 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:00:30 --> Total execution time: 0.1331
DEBUG - 2022-08-21 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:01:31 --> Total execution time: 0.0969
DEBUG - 2022-08-21 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:03:14 --> Total execution time: 0.0900
DEBUG - 2022-08-21 08:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:04:00 --> Total execution time: 0.0925
DEBUG - 2022-08-21 08:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:04:28 --> Total execution time: 0.1180
DEBUG - 2022-08-21 08:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:04:29 --> Total execution time: 0.1235
DEBUG - 2022-08-21 08:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:04:46 --> Total execution time: 0.0824
DEBUG - 2022-08-21 08:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:34:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:04:49 --> Total execution time: 0.0591
DEBUG - 2022-08-21 08:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:05:20 --> Total execution time: 0.0825
DEBUG - 2022-08-21 08:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:05:27 --> Total execution time: 0.0897
DEBUG - 2022-08-21 08:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:05:29 --> Total execution time: 0.0514
DEBUG - 2022-08-21 08:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:05:34 --> Total execution time: 0.1033
DEBUG - 2022-08-21 08:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:05:35 --> Total execution time: 0.0905
DEBUG - 2022-08-21 08:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:05:42 --> Total execution time: 0.1320
DEBUG - 2022-08-21 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:35:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:05:47 --> Total execution time: 0.0554
DEBUG - 2022-08-21 08:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:06:09 --> Total execution time: 0.2073
DEBUG - 2022-08-21 08:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:36:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:06:30 --> Total execution time: 0.0977
DEBUG - 2022-08-21 08:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:36:32 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:06:32 --> Total execution time: 0.1361
DEBUG - 2022-08-21 08:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:07:06 --> Total execution time: 0.0750
DEBUG - 2022-08-21 08:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:07:09 --> Total execution time: 0.1436
DEBUG - 2022-08-21 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:37:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:07:32 --> Total execution time: 0.0770
DEBUG - 2022-08-21 08:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:37:41 --> Total execution time: 0.0869
DEBUG - 2022-08-21 08:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:37:53 --> Total execution time: 0.0912
DEBUG - 2022-08-21 08:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:37:53 --> Total execution time: 0.2026
DEBUG - 2022-08-21 08:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:08:10 --> Total execution time: 0.0552
DEBUG - 2022-08-21 08:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:08:18 --> Total execution time: 0.0892
DEBUG - 2022-08-21 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:08:27 --> Total execution time: 0.0895
DEBUG - 2022-08-21 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:08:28 --> Total execution time: 0.1180
DEBUG - 2022-08-21 08:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:08:42 --> Total execution time: 0.1008
DEBUG - 2022-08-21 08:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:08:47 --> Total execution time: 0.1001
DEBUG - 2022-08-21 08:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:08:51 --> Total execution time: 0.0969
DEBUG - 2022-08-21 08:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:09:04 --> Total execution time: 0.0873
DEBUG - 2022-08-21 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:40:41 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:10:41 --> Total execution time: 0.0604
DEBUG - 2022-08-21 08:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:43:27 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:13:28 --> Total execution time: 0.1980
DEBUG - 2022-08-21 08:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:15:08 --> Total execution time: 0.0549
DEBUG - 2022-08-21 08:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:45:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:15:38 --> Total execution time: 0.0866
DEBUG - 2022-08-21 08:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:17:28 --> Total execution time: 0.1052
DEBUG - 2022-08-21 08:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:17:43 --> Total execution time: 0.1420
DEBUG - 2022-08-21 08:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:48:17 --> Total execution time: 0.0906
DEBUG - 2022-08-21 08:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:48:30 --> Total execution time: 0.1228
DEBUG - 2022-08-21 08:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:18:32 --> Total execution time: 0.2138
DEBUG - 2022-08-21 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:18:52 --> Total execution time: 0.1145
DEBUG - 2022-08-21 08:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:19:47 --> Total execution time: 0.0881
DEBUG - 2022-08-21 08:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:00 --> Total execution time: 0.5497
DEBUG - 2022-08-21 08:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:19 --> Total execution time: 0.0816
DEBUG - 2022-08-21 08:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:36 --> Total execution time: 0.0962
DEBUG - 2022-08-21 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:42 --> Total execution time: 0.0921
DEBUG - 2022-08-21 08:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:45 --> Total execution time: 0.0953
DEBUG - 2022-08-21 08:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:46 --> Total execution time: 0.1191
DEBUG - 2022-08-21 08:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 08:50:48 --> 404 Page Not Found: List_teacher/index
DEBUG - 2022-08-21 08:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:53 --> Total execution time: 0.0854
DEBUG - 2022-08-21 08:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:56 --> Total execution time: 0.0876
DEBUG - 2022-08-21 08:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:51:37 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:21:37 --> Total execution time: 0.1803
DEBUG - 2022-08-21 08:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:21:43 --> Total execution time: 0.1442
DEBUG - 2022-08-21 08:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:22:12 --> Total execution time: 0.3642
DEBUG - 2022-08-21 08:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:52:20 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:22:20 --> Total execution time: 0.0568
DEBUG - 2022-08-21 08:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:22:42 --> Total execution time: 0.1380
DEBUG - 2022-08-21 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:52:54 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:22:54 --> Total execution time: 0.0558
DEBUG - 2022-08-21 08:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:23:44 --> Total execution time: 0.1572
DEBUG - 2022-08-21 08:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:24:38 --> Total execution time: 0.0882
DEBUG - 2022-08-21 08:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:54:57 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:24:57 --> Total execution time: 0.0552
DEBUG - 2022-08-21 08:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:25:11 --> Total execution time: 0.0543
DEBUG - 2022-08-21 08:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:55:15 --> Total execution time: 0.0921
DEBUG - 2022-08-21 08:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:55:17 --> Total execution time: 0.1067
DEBUG - 2022-08-21 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:55:18 --> Total execution time: 0.0969
DEBUG - 2022-08-21 08:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:25:20 --> Total execution time: 0.0605
DEBUG - 2022-08-21 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:25:29 --> Total execution time: 0.0904
DEBUG - 2022-08-21 08:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:25:33 --> Total execution time: 0.0836
DEBUG - 2022-08-21 08:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:25:38 --> Total execution time: 0.0856
DEBUG - 2022-08-21 08:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:55:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:25:49 --> Total execution time: 0.0575
DEBUG - 2022-08-21 08:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:02 --> Total execution time: 0.0960
DEBUG - 2022-08-21 08:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:04 --> Total execution time: 0.1169
DEBUG - 2022-08-21 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:08 --> Total execution time: 0.0970
DEBUG - 2022-08-21 08:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:13 --> Total execution time: 0.0901
DEBUG - 2022-08-21 08:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:14 --> Total execution time: 0.0817
DEBUG - 2022-08-21 08:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:19 --> Total execution time: 0.0825
DEBUG - 2022-08-21 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:25 --> Total execution time: 0.1221
DEBUG - 2022-08-21 08:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:29 --> Total execution time: 0.1151
DEBUG - 2022-08-21 08:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:32 --> Total execution time: 0.1229
DEBUG - 2022-08-21 08:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:33 --> Total execution time: 0.0873
DEBUG - 2022-08-21 08:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:35 --> Total execution time: 0.0870
DEBUG - 2022-08-21 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:45 --> Total execution time: 0.0816
DEBUG - 2022-08-21 08:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:53 --> Total execution time: 0.0864
DEBUG - 2022-08-21 08:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:26:57 --> Total execution time: 0.0848
DEBUG - 2022-08-21 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:56:57 --> Total execution time: 0.0838
DEBUG - 2022-08-21 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:57:00 --> Total execution time: 0.0879
DEBUG - 2022-08-21 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:57:01 --> Total execution time: 0.0943
DEBUG - 2022-08-21 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:27:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 08:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:27:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 08:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:27:15 --> Total execution time: 0.1228
DEBUG - 2022-08-21 08:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:27:25 --> Total execution time: 0.0836
DEBUG - 2022-08-21 08:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:27:33 --> Total execution time: 0.1112
DEBUG - 2022-08-21 08:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:58:22 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:28:22 --> Total execution time: 0.0600
DEBUG - 2022-08-21 08:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:58:23 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:28:23 --> Total execution time: 0.0520
DEBUG - 2022-08-21 08:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:28:41 --> Total execution time: 0.0836
DEBUG - 2022-08-21 08:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:29:16 --> Total execution time: 0.0811
DEBUG - 2022-08-21 08:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:29:21 --> Total execution time: 0.0755
DEBUG - 2022-08-21 08:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 08:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:29:31 --> Total execution time: 0.2501
DEBUG - 2022-08-21 08:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:29:35 --> Total execution time: 0.1088
DEBUG - 2022-08-21 08:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:29:45 --> Total execution time: 0.0966
DEBUG - 2022-08-21 08:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:29:47 --> Total execution time: 0.0896
DEBUG - 2022-08-21 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 08:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:29:48 --> Total execution time: 0.1030
DEBUG - 2022-08-21 08:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 08:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 08:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:30:01 --> Total execution time: 0.0964
DEBUG - 2022-08-21 09:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:30:02 --> Total execution time: 0.0976
DEBUG - 2022-08-21 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:30:02 --> Total execution time: 0.0763
DEBUG - 2022-08-21 09:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:30:31 --> Total execution time: 0.2166
DEBUG - 2022-08-21 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:30:39 --> Total execution time: 0.0898
DEBUG - 2022-08-21 09:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:30:41 --> Total execution time: 0.0819
DEBUG - 2022-08-21 09:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:31:27 --> Total execution time: 0.0825
DEBUG - 2022-08-21 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:31:50 --> Total execution time: 0.0887
DEBUG - 2022-08-21 09:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:31:51 --> Total execution time: 0.2068
DEBUG - 2022-08-21 09:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:31:52 --> Total execution time: 0.1292
DEBUG - 2022-08-21 09:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:32:22 --> Total execution time: 0.2195
DEBUG - 2022-08-21 09:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:32:50 --> Total execution time: 0.1300
DEBUG - 2022-08-21 09:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:33:00 --> Total execution time: 0.1493
DEBUG - 2022-08-21 09:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:33:09 --> Total execution time: 0.1090
DEBUG - 2022-08-21 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:33:16 --> Total execution time: 0.0873
DEBUG - 2022-08-21 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:33:29 --> Total execution time: 0.0874
DEBUG - 2022-08-21 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:33:37 --> Total execution time: 0.1587
DEBUG - 2022-08-21 09:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:33:39 --> Total execution time: 0.0491
DEBUG - 2022-08-21 09:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:03:44 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:33:44 --> Total execution time: 0.0901
DEBUG - 2022-08-21 09:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:34:19 --> Total execution time: 2.5242
DEBUG - 2022-08-21 09:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 09:04:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 09:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:08:28 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:38:28 --> Total execution time: 0.1453
DEBUG - 2022-08-21 09:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:08:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:38:29 --> Total execution time: 0.0873
DEBUG - 2022-08-21 09:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:09:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:39:39 --> Total execution time: 0.2247
DEBUG - 2022-08-21 09:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:43:04 --> Total execution time: 0.0934
DEBUG - 2022-08-21 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:13:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:43:40 --> Total execution time: 0.0904
DEBUG - 2022-08-21 09:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:44:17 --> Total execution time: 0.0860
DEBUG - 2022-08-21 09:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:20:57 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:50:57 --> Total execution time: 0.2741
DEBUG - 2022-08-21 09:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:21:07 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:51:07 --> Total execution time: 0.2218
DEBUG - 2022-08-21 09:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:21:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:51:08 --> Total execution time: 0.0857
DEBUG - 2022-08-21 09:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:21:23 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:51:23 --> Total execution time: 0.0851
DEBUG - 2022-08-21 09:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:24:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:54:26 --> Total execution time: 0.2643
DEBUG - 2022-08-21 09:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:24:34 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:54:35 --> Total execution time: 0.0858
DEBUG - 2022-08-21 09:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:24:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:54:39 --> Total execution time: 0.0920
DEBUG - 2022-08-21 09:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:24:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:54:39 --> Total execution time: 0.0594
DEBUG - 2022-08-21 09:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:54:43 --> Total execution time: 0.0998
DEBUG - 2022-08-21 09:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:03 --> Total execution time: 0.0872
DEBUG - 2022-08-21 09:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:05 --> Total execution time: 0.0917
DEBUG - 2022-08-21 09:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:11 --> Total execution time: 0.0699
DEBUG - 2022-08-21 09:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:12 --> Total execution time: 0.0870
DEBUG - 2022-08-21 09:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:14 --> Total execution time: 0.1055
DEBUG - 2022-08-21 09:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:19 --> Total execution time: 0.0889
DEBUG - 2022-08-21 09:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:21 --> Total execution time: 0.0542
DEBUG - 2022-08-21 09:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:24 --> Total execution time: 0.0886
DEBUG - 2022-08-21 09:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:37 --> Total execution time: 0.0867
DEBUG - 2022-08-21 09:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:52 --> Total execution time: 0.0890
DEBUG - 2022-08-21 09:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:55:53 --> Total execution time: 0.0892
DEBUG - 2022-08-21 09:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:56:01 --> Total execution time: 0.1103
DEBUG - 2022-08-21 09:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:56:08 --> Total execution time: 0.0915
DEBUG - 2022-08-21 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:56:14 --> Total execution time: 0.1378
DEBUG - 2022-08-21 09:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:56:59 --> Total execution time: 0.0930
DEBUG - 2022-08-21 09:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:59:20 --> Total execution time: 0.1392
DEBUG - 2022-08-21 09:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:01:29 --> Total execution time: 0.0867
DEBUG - 2022-08-21 09:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:01:36 --> Total execution time: 0.0921
DEBUG - 2022-08-21 09:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:01:42 --> Total execution time: 0.1095
DEBUG - 2022-08-21 09:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:01:43 --> Total execution time: 0.1067
DEBUG - 2022-08-21 09:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:32:20 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:02:20 --> Total execution time: 0.0585
DEBUG - 2022-08-21 09:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:02:31 --> Total execution time: 0.0538
DEBUG - 2022-08-21 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:34:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:04:48 --> Total execution time: 0.1138
DEBUG - 2022-08-21 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:05:04 --> Total execution time: 0.2259
DEBUG - 2022-08-21 09:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:05:48 --> Total execution time: 0.0747
DEBUG - 2022-08-21 09:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:06:09 --> Total execution time: 0.0829
DEBUG - 2022-08-21 09:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:06:15 --> Total execution time: 0.0868
DEBUG - 2022-08-21 09:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:06:24 --> Total execution time: 0.0899
DEBUG - 2022-08-21 09:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:10:23 --> Total execution time: 0.0921
DEBUG - 2022-08-21 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:10:41 --> Total execution time: 0.0861
DEBUG - 2022-08-21 09:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:10:59 --> Total execution time: 0.0966
DEBUG - 2022-08-21 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:11:06 --> Total execution time: 0.0892
DEBUG - 2022-08-21 09:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:42:41 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:12:41 --> Total execution time: 0.2258
DEBUG - 2022-08-21 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:12:58 --> Total execution time: 0.0848
DEBUG - 2022-08-21 09:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:13:39 --> Total execution time: 0.0821
DEBUG - 2022-08-21 09:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:16:21 --> Total execution time: 0.2767
DEBUG - 2022-08-21 09:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:16:43 --> Total execution time: 0.0914
DEBUG - 2022-08-21 09:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:46:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:16:49 --> Total execution time: 0.1132
DEBUG - 2022-08-21 09:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:16:54 --> Total execution time: 0.0838
DEBUG - 2022-08-21 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:16:56 --> Total execution time: 0.1175
DEBUG - 2022-08-21 09:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:01 --> Total execution time: 0.0568
DEBUG - 2022-08-21 09:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:07 --> Total execution time: 0.0811
DEBUG - 2022-08-21 09:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:10 --> Total execution time: 0.0805
DEBUG - 2022-08-21 09:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:20 --> Total execution time: 0.0889
DEBUG - 2022-08-21 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:26 --> Total execution time: 0.0818
DEBUG - 2022-08-21 09:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:36 --> Total execution time: 0.1138
DEBUG - 2022-08-21 09:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:49 --> Total execution time: 0.1045
DEBUG - 2022-08-21 09:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:53 --> Total execution time: 0.0893
DEBUG - 2022-08-21 09:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:47:55 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:55 --> Total execution time: 0.0661
DEBUG - 2022-08-21 09:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:04 --> Total execution time: 0.0942
DEBUG - 2022-08-21 09:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:09 --> Total execution time: 0.0816
DEBUG - 2022-08-21 09:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:18 --> Total execution time: 0.0780
DEBUG - 2022-08-21 09:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:40 --> Total execution time: 0.1079
DEBUG - 2022-08-21 09:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:11 --> Total execution time: 0.0904
DEBUG - 2022-08-21 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:18 --> Total execution time: 0.0978
DEBUG - 2022-08-21 09:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:29 --> Total execution time: 0.0980
DEBUG - 2022-08-21 09:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:04 --> Total execution time: 0.0904
DEBUG - 2022-08-21 09:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:54 --> Total execution time: 0.0845
DEBUG - 2022-08-21 09:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:24:36 --> Total execution time: 0.1071
DEBUG - 2022-08-21 09:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:24:48 --> Total execution time: 0.0903
DEBUG - 2022-08-21 09:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:24:51 --> Total execution time: 0.0882
DEBUG - 2022-08-21 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:24:59 --> Total execution time: 0.1097
DEBUG - 2022-08-21 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:25:01 --> Total execution time: 0.0860
DEBUG - 2022-08-21 09:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:55:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:25:01 --> Total execution time: 0.0634
DEBUG - 2022-08-21 09:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:25:47 --> Total execution time: 0.0827
DEBUG - 2022-08-21 09:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:26:06 --> Total execution time: 0.0877
DEBUG - 2022-08-21 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:26:15 --> Total execution time: 0.0889
DEBUG - 2022-08-21 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:26:16 --> Total execution time: 0.0846
DEBUG - 2022-08-21 09:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:26:53 --> Total execution time: 0.1145
DEBUG - 2022-08-21 09:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:26:56 --> Total execution time: 0.1107
DEBUG - 2022-08-21 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 09:56:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:56:59 --> No URI present. Default controller set.
DEBUG - 2022-08-21 09:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:26:59 --> Total execution time: 0.0675
DEBUG - 2022-08-21 09:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:08 --> Total execution time: 0.0899
DEBUG - 2022-08-21 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:22 --> Total execution time: 0.0909
DEBUG - 2022-08-21 09:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:33 --> Total execution time: 0.0801
DEBUG - 2022-08-21 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:02 --> Total execution time: 0.2237
DEBUG - 2022-08-21 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:02 --> Total execution time: 0.1044
DEBUG - 2022-08-21 09:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 09:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:03 --> Total execution time: 0.0800
DEBUG - 2022-08-21 09:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:32 --> Total execution time: 0.2418
DEBUG - 2022-08-21 09:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:39 --> Total execution time: 0.0526
DEBUG - 2022-08-21 09:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:43 --> Total execution time: 0.0891
DEBUG - 2022-08-21 09:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:48 --> Total execution time: 0.0874
DEBUG - 2022-08-21 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 09:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:54 --> Total execution time: 0.0825
DEBUG - 2022-08-21 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:03 --> Total execution time: 0.0641
DEBUG - 2022-08-21 10:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:00:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:16 --> Total execution time: 0.0558
DEBUG - 2022-08-21 10:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:00:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:47 --> Total execution time: 0.0554
DEBUG - 2022-08-21 10:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:31:24 --> Total execution time: 0.0828
DEBUG - 2022-08-21 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:01:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:31:25 --> Total execution time: 0.0873
DEBUG - 2022-08-21 10:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:01:57 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:31:57 --> Total execution time: 0.0852
DEBUG - 2022-08-21 10:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:02:12 --> Total execution time: 0.0585
DEBUG - 2022-08-21 10:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:02:14 --> Total execution time: 0.0875
DEBUG - 2022-08-21 10:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:32:14 --> Total execution time: 0.0541
DEBUG - 2022-08-21 10:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:02:14 --> Total execution time: 0.0850
DEBUG - 2022-08-21 10:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:02:45 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:32:45 --> Total execution time: 0.0615
DEBUG - 2022-08-21 10:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:32:59 --> Total execution time: 0.0858
DEBUG - 2022-08-21 10:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:04:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:19 --> Total execution time: 0.0594
DEBUG - 2022-08-21 10:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:04:21 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:21 --> Total execution time: 0.0995
DEBUG - 2022-08-21 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:04:45 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:45 --> Total execution time: 0.0555
DEBUG - 2022-08-21 10:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:50 --> Total execution time: 0.0590
DEBUG - 2022-08-21 10:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:04 --> Total execution time: 0.0847
DEBUG - 2022-08-21 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:08 --> Total execution time: 0.1214
DEBUG - 2022-08-21 10:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:15 --> Total execution time: 0.1172
DEBUG - 2022-08-21 10:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:21 --> Total execution time: 0.1043
DEBUG - 2022-08-21 10:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:25 --> Total execution time: 0.0775
DEBUG - 2022-08-21 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:31 --> Total execution time: 0.0825
DEBUG - 2022-08-21 10:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:31 --> Total execution time: 0.0532
DEBUG - 2022-08-21 10:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:35 --> Total execution time: 0.0798
DEBUG - 2022-08-21 10:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:47 --> Total execution time: 0.0999
DEBUG - 2022-08-21 10:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:57 --> Total execution time: 0.0998
DEBUG - 2022-08-21 20:35:57 --> Total execution time: 2.3967
DEBUG - 2022-08-21 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 10:06:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 10:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:06:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:36:30 --> Total execution time: 0.0873
DEBUG - 2022-08-21 10:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:06:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 10:06:58 --> 404 Page Not Found: Product-category/uncategorized
DEBUG - 2022-08-21 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:07:27 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:37:27 --> Total execution time: 0.0772
DEBUG - 2022-08-21 10:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:07:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:37:38 --> Total execution time: 0.0537
DEBUG - 2022-08-21 10:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:37:50 --> Total execution time: 0.0559
DEBUG - 2022-08-21 10:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:38:55 --> Total execution time: 0.0832
DEBUG - 2022-08-21 10:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:09:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 10:09:15 --> 404 Page Not Found: Importance-of-research-seminar/esalestrix.in
DEBUG - 2022-08-21 10:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:40:15 --> Total execution time: 0.0910
DEBUG - 2022-08-21 10:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:10:18 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:40:18 --> Total execution time: 0.0562
DEBUG - 2022-08-21 10:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:12:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:42:19 --> Total execution time: 0.0607
DEBUG - 2022-08-21 10:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:42:33 --> Total execution time: 0.0873
DEBUG - 2022-08-21 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:12:40 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:42:40 --> Total execution time: 0.0855
DEBUG - 2022-08-21 10:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 10:12:44 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 10:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:13:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:43:13 --> Total execution time: 0.0888
DEBUG - 2022-08-21 10:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:13:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:43:31 --> Total execution time: 0.0993
DEBUG - 2022-08-21 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:13:37 --> Total execution time: 0.0820
DEBUG - 2022-08-21 10:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:13:41 --> Total execution time: 0.0873
DEBUG - 2022-08-21 10:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:13:42 --> Total execution time: 0.0878
DEBUG - 2022-08-21 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:13:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:43:50 --> Total execution time: 0.0874
DEBUG - 2022-08-21 10:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:13:58 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:43:58 --> Total execution time: 0.2672
DEBUG - 2022-08-21 10:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:13:59 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:43:59 --> Total execution time: 0.0911
DEBUG - 2022-08-21 10:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:03 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:44:03 --> Total execution time: 0.0800
DEBUG - 2022-08-21 10:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:44:04 --> Total execution time: 0.0836
DEBUG - 2022-08-21 10:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:14:09 --> Total execution time: 0.0792
DEBUG - 2022-08-21 10:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:14:12 --> Total execution time: 0.0852
DEBUG - 2022-08-21 10:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:14:12 --> Total execution time: 0.0766
DEBUG - 2022-08-21 10:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:44:24 --> Total execution time: 0.1011
DEBUG - 2022-08-21 10:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:44:31 --> Total execution time: 0.0923
DEBUG - 2022-08-21 10:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:44:44 --> Total execution time: 0.0870
DEBUG - 2022-08-21 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:44:52 --> Total execution time: 0.1141
DEBUG - 2022-08-21 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:45:37 --> Total execution time: 2.1315
DEBUG - 2022-08-21 10:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:45:39 --> Total execution time: 0.0920
DEBUG - 2022-08-21 10:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:45:44 --> Total execution time: 0.0898
DEBUG - 2022-08-21 10:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:15:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 10:15:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 10:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:45:52 --> Total execution time: 0.0830
DEBUG - 2022-08-21 10:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:45:53 --> Total execution time: 0.1307
DEBUG - 2022-08-21 10:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:27 --> Total execution time: 0.0823
DEBUG - 2022-08-21 10:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:27 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:27 --> Total execution time: 0.0552
DEBUG - 2022-08-21 10:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:29 --> Total execution time: 0.0849
DEBUG - 2022-08-21 10:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:35 --> Total execution time: 0.0817
DEBUG - 2022-08-21 10:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:36 --> Total execution time: 0.0875
DEBUG - 2022-08-21 10:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:38 --> Total execution time: 0.2320
DEBUG - 2022-08-21 10:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:47 --> Total execution time: 0.0945
DEBUG - 2022-08-21 10:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:51 --> Total execution time: 0.0963
DEBUG - 2022-08-21 10:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:52 --> Total execution time: 0.0882
DEBUG - 2022-08-21 10:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:55 --> Total execution time: 0.0875
DEBUG - 2022-08-21 10:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:46:58 --> Total execution time: 0.0937
DEBUG - 2022-08-21 10:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:01 --> Total execution time: 0.0894
DEBUG - 2022-08-21 10:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:09 --> Total execution time: 0.0572
DEBUG - 2022-08-21 10:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:12 --> Total execution time: 0.0934
DEBUG - 2022-08-21 10:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:15 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:15 --> Total execution time: 0.0559
DEBUG - 2022-08-21 10:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:18 --> Total execution time: 0.0886
DEBUG - 2022-08-21 10:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:19 --> Total execution time: 0.1257
DEBUG - 2022-08-21 10:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:32 --> Total execution time: 0.2309
DEBUG - 2022-08-21 10:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:40 --> Total execution time: 0.1130
DEBUG - 2022-08-21 10:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:43 --> Total execution time: 0.0631
DEBUG - 2022-08-21 10:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:44 --> Total execution time: 0.1099
DEBUG - 2022-08-21 10:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:47 --> Total execution time: 0.0879
DEBUG - 2022-08-21 10:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:57 --> Total execution time: 0.0835
DEBUG - 2022-08-21 10:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:01 --> Total execution time: 0.1023
DEBUG - 2022-08-21 10:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:18:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:09 --> Total execution time: 0.0699
DEBUG - 2022-08-21 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:20 --> Total execution time: 0.0823
DEBUG - 2022-08-21 10:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:24 --> Total execution time: 0.1169
DEBUG - 2022-08-21 10:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:18:40 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:40 --> Total execution time: 0.0607
DEBUG - 2022-08-21 10:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:51 --> Total execution time: 0.1478
DEBUG - 2022-08-21 10:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:20:02 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:50:02 --> Total execution time: 0.0745
DEBUG - 2022-08-21 10:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:50:20 --> Total execution time: 0.1074
DEBUG - 2022-08-21 10:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:50:31 --> Total execution time: 0.0968
DEBUG - 2022-08-21 10:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:50:45 --> Total execution time: 0.1034
DEBUG - 2022-08-21 10:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 10:20:48 --> 404 Page Not Found: Events/page
DEBUG - 2022-08-21 10:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:51:00 --> Total execution time: 0.2229
DEBUG - 2022-08-21 10:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:51:03 --> Total execution time: 0.0921
DEBUG - 2022-08-21 10:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:21:21 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:51:21 --> Total execution time: 0.0607
DEBUG - 2022-08-21 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:21:57 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:51:57 --> Total execution time: 0.0855
DEBUG - 2022-08-21 10:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:53:17 --> Total execution time: 0.1075
DEBUG - 2022-08-21 10:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:53:43 --> Total execution time: 0.1100
DEBUG - 2022-08-21 10:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:53:54 --> Total execution time: 0.2681
DEBUG - 2022-08-21 10:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:54:44 --> Total execution time: 0.0818
DEBUG - 2022-08-21 10:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:54:54 --> Total execution time: 0.0888
DEBUG - 2022-08-21 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:55:01 --> Total execution time: 0.1209
DEBUG - 2022-08-21 10:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:55:10 --> Total execution time: 0.0907
DEBUG - 2022-08-21 10:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:55:17 --> Total execution time: 0.0595
DEBUG - 2022-08-21 10:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:55:18 --> Total execution time: 0.1068
DEBUG - 2022-08-21 10:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:55:41 --> Total execution time: 0.0850
DEBUG - 2022-08-21 10:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:26:26 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:56:26 --> Total execution time: 0.0880
DEBUG - 2022-08-21 10:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:56:30 --> Total execution time: 0.1335
DEBUG - 2022-08-21 10:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:56:33 --> Total execution time: 0.0963
DEBUG - 2022-08-21 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:56:53 --> Total execution time: 0.0932
DEBUG - 2022-08-21 10:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:57:14 --> Total execution time: 0.1218
DEBUG - 2022-08-21 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:57:14 --> Total execution time: 0.0908
DEBUG - 2022-08-21 10:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:57:23 --> Total execution time: 0.0887
DEBUG - 2022-08-21 10:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:57:42 --> Total execution time: 0.0894
DEBUG - 2022-08-21 10:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:57:45 --> Total execution time: 0.1082
DEBUG - 2022-08-21 10:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:58:28 --> Total execution time: 0.0826
DEBUG - 2022-08-21 10:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:58:30 --> Total execution time: 0.1192
DEBUG - 2022-08-21 10:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:00:27 --> Total execution time: 0.0940
DEBUG - 2022-08-21 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:31:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 10:31:54 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-08-21 10:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:03:58 --> Total execution time: 0.2009
DEBUG - 2022-08-21 10:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:04:02 --> Total execution time: 0.1278
DEBUG - 2022-08-21 10:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:04:09 --> Total execution time: 0.0922
DEBUG - 2022-08-21 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:04:26 --> Total execution time: 0.0863
DEBUG - 2022-08-21 10:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:05:23 --> Total execution time: 0.0899
DEBUG - 2022-08-21 10:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:35:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:05:31 --> Total execution time: 0.0543
DEBUG - 2022-08-21 10:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:05:39 --> Total execution time: 0.0917
DEBUG - 2022-08-21 10:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:37:26 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:07:26 --> Total execution time: 0.0603
DEBUG - 2022-08-21 10:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:07:37 --> Total execution time: 0.2277
DEBUG - 2022-08-21 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:07:45 --> Total execution time: 0.0889
DEBUG - 2022-08-21 10:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:07:53 --> Total execution time: 0.0940
DEBUG - 2022-08-21 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:07:56 --> Total execution time: 0.0960
DEBUG - 2022-08-21 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:03 --> Total execution time: 0.0876
DEBUG - 2022-08-21 10:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:07 --> Total execution time: 0.1177
DEBUG - 2022-08-21 10:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:38:11 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:11 --> Total execution time: 0.0958
DEBUG - 2022-08-21 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:38:12 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:12 --> Total execution time: 0.0881
DEBUG - 2022-08-21 10:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:24 --> Total execution time: 0.1170
DEBUG - 2022-08-21 10:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:55 --> Total execution time: 0.0909
DEBUG - 2022-08-21 10:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:39:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:09:09 --> Total execution time: 0.0881
DEBUG - 2022-08-21 10:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:37 --> Total execution time: 0.1211
DEBUG - 2022-08-21 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:38 --> Total execution time: 0.0990
DEBUG - 2022-08-21 10:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:38 --> Total execution time: 0.1594
DEBUG - 2022-08-21 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:38 --> Total execution time: 0.1351
DEBUG - 2022-08-21 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:39 --> Total execution time: 0.1261
DEBUG - 2022-08-21 10:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:39 --> Total execution time: 0.2402
DEBUG - 2022-08-21 10:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:49 --> Total execution time: 0.1037
DEBUG - 2022-08-21 10:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:49 --> Total execution time: 0.1358
DEBUG - 2022-08-21 10:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:41:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:08 --> Total execution time: 0.2218
DEBUG - 2022-08-21 10:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:41:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:09 --> Total execution time: 0.0912
DEBUG - 2022-08-21 10:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:41:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:47 --> Total execution time: 0.0977
DEBUG - 2022-08-21 10:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:06 --> Total execution time: 0.2781
DEBUG - 2022-08-21 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:32 --> Total execution time: 0.1137
DEBUG - 2022-08-21 10:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:33 --> Total execution time: 0.0928
DEBUG - 2022-08-21 10:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:33 --> Total execution time: 0.0991
DEBUG - 2022-08-21 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:37 --> Total execution time: 0.0881
DEBUG - 2022-08-21 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:38 --> Total execution time: 0.1214
DEBUG - 2022-08-21 10:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:41 --> Total execution time: 0.0977
DEBUG - 2022-08-21 10:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:45 --> Total execution time: 0.0831
DEBUG - 2022-08-21 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:08 --> Total execution time: 0.0861
DEBUG - 2022-08-21 10:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:14 --> Total execution time: 0.0926
DEBUG - 2022-08-21 10:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:21 --> Total execution time: 0.0913
DEBUG - 2022-08-21 10:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:05 --> Total execution time: 0.0835
DEBUG - 2022-08-21 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:19 --> Total execution time: 0.0821
DEBUG - 2022-08-21 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:28 --> Total execution time: 0.0883
DEBUG - 2022-08-21 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:35 --> Total execution time: 0.0910
DEBUG - 2022-08-21 10:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:45:36 --> Total execution time: 0.0831
DEBUG - 2022-08-21 10:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:03 --> Total execution time: 0.2975
DEBUG - 2022-08-21 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:20 --> Total execution time: 0.1240
DEBUG - 2022-08-21 10:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:45 --> Total execution time: 0.1142
DEBUG - 2022-08-21 10:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:07 --> Total execution time: 0.0559
DEBUG - 2022-08-21 10:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:37 --> Total execution time: 0.0977
DEBUG - 2022-08-21 10:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:52 --> Total execution time: 0.0931
DEBUG - 2022-08-21 10:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:00 --> Total execution time: 0.1157
DEBUG - 2022-08-21 10:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:25 --> Total execution time: 0.1077
DEBUG - 2022-08-21 10:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:33 --> Total execution time: 0.0868
DEBUG - 2022-08-21 10:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:52:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:22:19 --> Total execution time: 0.0702
DEBUG - 2022-08-21 10:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:22:39 --> Total execution time: 0.0943
DEBUG - 2022-08-21 10:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 10:52:56 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-21 10:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:11 --> Total execution time: 0.0870
DEBUG - 2022-08-21 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:24 --> Total execution time: 0.1024
DEBUG - 2022-08-21 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:34 --> Total execution time: 0.0909
DEBUG - 2022-08-21 10:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:41 --> Total execution time: 0.0954
DEBUG - 2022-08-21 10:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:47 --> Total execution time: 0.0932
DEBUG - 2022-08-21 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:52 --> Total execution time: 0.0837
DEBUG - 2022-08-21 10:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:54 --> Total execution time: 0.0782
DEBUG - 2022-08-21 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:55 --> Total execution time: 0.0821
DEBUG - 2022-08-21 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:57 --> Total execution time: 0.0839
DEBUG - 2022-08-21 10:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:24:00 --> Total execution time: 0.0838
DEBUG - 2022-08-21 10:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:24:04 --> Total execution time: 0.1138
DEBUG - 2022-08-21 10:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:24:16 --> Total execution time: 0.0900
DEBUG - 2022-08-21 10:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:36 --> Total execution time: 0.1657
DEBUG - 2022-08-21 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:57:33 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:33 --> Total execution time: 0.0703
DEBUG - 2022-08-21 10:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:57:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:36 --> Total execution time: 0.0562
DEBUG - 2022-08-21 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:28:02 --> Total execution time: 0.0924
DEBUG - 2022-08-21 10:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:28:16 --> Total execution time: 0.0935
DEBUG - 2022-08-21 10:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:17 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:28:17 --> Total execution time: 0.1225
DEBUG - 2022-08-21 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:28:25 --> Total execution time: 0.0967
DEBUG - 2022-08-21 10:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:28:31 --> Total execution time: 0.0925
DEBUG - 2022-08-21 10:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:28:44 --> Total execution time: 0.0945
DEBUG - 2022-08-21 10:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:50 --> Total execution time: 0.0880
DEBUG - 2022-08-21 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:53 --> Total execution time: 0.0880
DEBUG - 2022-08-21 10:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:58:53 --> Total execution time: 0.0896
DEBUG - 2022-08-21 10:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:28:54 --> Total execution time: 0.2208
DEBUG - 2022-08-21 10:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:02 --> Total execution time: 0.0902
DEBUG - 2022-08-21 10:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:28 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:28 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:28 --> Total execution time: 0.1067
DEBUG - 2022-08-21 10:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:28 --> Total execution time: 0.1409
DEBUG - 2022-08-21 10:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:59:28 --> Total execution time: 0.0930
DEBUG - 2022-08-21 10:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:28 --> Total execution time: 0.1548
DEBUG - 2022-08-21 10:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:29 --> Total execution time: 0.1524
DEBUG - 2022-08-21 10:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:59:29 --> Total execution time: 0.1534
DEBUG - 2022-08-21 10:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:30 --> Total execution time: 0.0779
DEBUG - 2022-08-21 10:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:59:31 --> Total execution time: 0.1403
DEBUG - 2022-08-21 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 10:59:32 --> Total execution time: 0.0955
DEBUG - 2022-08-21 10:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:37 --> Total execution time: 0.1131
DEBUG - 2022-08-21 10:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:38 --> Total execution time: 0.0585
DEBUG - 2022-08-21 10:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:43 --> Total execution time: 0.1248
DEBUG - 2022-08-21 10:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:49 --> Total execution time: 0.0856
DEBUG - 2022-08-21 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:52 --> Total execution time: 0.0945
DEBUG - 2022-08-21 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:52 --> Total execution time: 0.0913
DEBUG - 2022-08-21 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 10:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:29:53 --> Total execution time: 0.0860
DEBUG - 2022-08-21 10:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 10:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 10:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:00 --> Total execution time: 0.0895
DEBUG - 2022-08-21 11:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:03 --> Total execution time: 0.0918
DEBUG - 2022-08-21 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:05 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:05 --> Total execution time: 0.0976
DEBUG - 2022-08-21 11:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:06 --> Total execution time: 0.0903
DEBUG - 2022-08-21 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:14 --> Total execution time: 0.0905
DEBUG - 2022-08-21 11:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:21 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:21 --> Total execution time: 0.0856
DEBUG - 2022-08-21 11:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:23 --> Total execution time: 0.0838
DEBUG - 2022-08-21 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:00:25 --> Total execution time: 0.0928
DEBUG - 2022-08-21 11:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:29 --> Total execution time: 0.1132
DEBUG - 2022-08-21 11:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:00:36 --> Total execution time: 0.0890
DEBUG - 2022-08-21 11:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:00:36 --> Total execution time: 0.1974
DEBUG - 2022-08-21 11:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:30:48 --> Total execution time: 0.0542
DEBUG - 2022-08-21 11:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:31:06 --> Total execution time: 0.1041
DEBUG - 2022-08-21 11:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:31:29 --> Total execution time: 0.1024
DEBUG - 2022-08-21 11:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:32:41 --> Total execution time: 2.5921
DEBUG - 2022-08-21 11:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:02:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 11:02:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 11:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:45 --> Total execution time: 0.0894
DEBUG - 2022-08-21 11:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:48 --> Total execution time: 0.2486
DEBUG - 2022-08-21 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:34:03 --> Total execution time: 0.0929
DEBUG - 2022-08-21 11:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:34:15 --> Total execution time: 0.1110
DEBUG - 2022-08-21 11:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:34:33 --> Total execution time: 0.0869
DEBUG - 2022-08-21 11:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:34:37 --> Total execution time: 0.0914
DEBUG - 2022-08-21 11:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:34:51 --> Total execution time: 0.0896
DEBUG - 2022-08-21 11:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:04:52 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:34:52 --> Total execution time: 0.0552
DEBUG - 2022-08-21 11:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:11 --> Total execution time: 0.0563
DEBUG - 2022-08-21 11:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:16 --> Total execution time: 0.0788
DEBUG - 2022-08-21 11:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:17 --> Total execution time: 0.0820
DEBUG - 2022-08-21 11:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:25 --> Total execution time: 0.0868
DEBUG - 2022-08-21 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:28 --> Total execution time: 0.0868
DEBUG - 2022-08-21 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:32 --> Total execution time: 0.1001
DEBUG - 2022-08-21 11:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:40 --> Total execution time: 0.2305
DEBUG - 2022-08-21 11:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:43 --> Total execution time: 0.0970
DEBUG - 2022-08-21 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 11:05:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:05:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:49 --> Total execution time: 0.0550
DEBUG - 2022-08-21 11:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:06:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:36:01 --> Total execution time: 0.1192
DEBUG - 2022-08-21 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:36:08 --> Total execution time: 0.0956
DEBUG - 2022-08-21 11:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:36:29 --> Total execution time: 0.0951
DEBUG - 2022-08-21 11:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:38:24 --> Total execution time: 0.2207
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:38:25 --> Total execution time: 0.1019
DEBUG - 2022-08-21 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:38:25 --> Total execution time: 0.0871
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:38:25 --> Total execution time: 0.0882
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:38:25 --> Total execution time: 0.1352
DEBUG - 2022-08-21 11:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:38:26 --> Total execution time: 0.1440
DEBUG - 2022-08-21 11:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:38:26 --> Total execution time: 0.2469
DEBUG - 2022-08-21 11:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:38:46 --> Total execution time: 0.2355
DEBUG - 2022-08-21 11:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:39:08 --> Total execution time: 0.0830
DEBUG - 2022-08-21 11:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:42:38 --> Total execution time: 0.0544
DEBUG - 2022-08-21 11:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:12 --> Total execution time: 0.2262
DEBUG - 2022-08-21 11:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:27 --> Total execution time: 0.1093
DEBUG - 2022-08-21 11:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:42 --> Total execution time: 0.1008
DEBUG - 2022-08-21 11:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:44:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 11:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:44:41 --> Total execution time: 0.1101
DEBUG - 2022-08-21 11:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:45:31 --> Total execution time: 0.2281
DEBUG - 2022-08-21 11:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:15:41 --> Total execution time: 0.0959
DEBUG - 2022-08-21 11:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:15:47 --> Total execution time: 0.1320
DEBUG - 2022-08-21 11:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:46:16 --> Total execution time: 0.1169
DEBUG - 2022-08-21 11:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:46:26 --> Total execution time: 0.0951
DEBUG - 2022-08-21 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:51:27 --> Total execution time: 0.1186
DEBUG - 2022-08-21 11:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:51:51 --> Total execution time: 0.0913
DEBUG - 2022-08-21 11:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:22:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:52:06 --> Total execution time: 0.0695
DEBUG - 2022-08-21 11:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:53:20 --> Total execution time: 0.1016
DEBUG - 2022-08-21 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:53:30 --> Total execution time: 0.1546
DEBUG - 2022-08-21 11:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:54:12 --> Total execution time: 0.0920
DEBUG - 2022-08-21 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:54:27 --> Total execution time: 0.0930
DEBUG - 2022-08-21 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:56:10 --> Total execution time: 0.2453
DEBUG - 2022-08-21 11:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:56:26 --> Total execution time: 0.0835
DEBUG - 2022-08-21 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:26:43 --> Total execution time: 0.0849
DEBUG - 2022-08-21 11:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:57:03 --> Total execution time: 0.0871
DEBUG - 2022-08-21 11:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:29:34 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:59:34 --> Total execution time: 0.2121
DEBUG - 2022-08-21 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:29:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:59:36 --> Total execution time: 0.1216
DEBUG - 2022-08-21 11:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:59:45 --> Total execution time: 0.8966
DEBUG - 2022-08-21 11:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:29:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:59:49 --> Total execution time: 0.2701
DEBUG - 2022-08-21 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:59:55 --> Total execution time: 0.2699
DEBUG - 2022-08-21 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:29:56 --> Total execution time: 0.2423
DEBUG - 2022-08-21 11:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:30:00 --> Total execution time: 0.5349
DEBUG - 2022-08-21 11:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:30:01 --> Total execution time: 0.7699
DEBUG - 2022-08-21 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:00:18 --> Total execution time: 0.0834
DEBUG - 2022-08-21 11:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:00:58 --> Total execution time: 0.3474
DEBUG - 2022-08-21 11:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:01:40 --> Total execution time: 0.8458
DEBUG - 2022-08-21 11:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:01:40 --> Total execution time: 0.3604
DEBUG - 2022-08-21 11:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:02:20 --> Total execution time: 0.4130
DEBUG - 2022-08-21 11:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:02:48 --> Total execution time: 0.3824
DEBUG - 2022-08-21 11:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:02:54 --> Total execution time: 0.3943
DEBUG - 2022-08-21 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:34:05 --> Total execution time: 0.2547
DEBUG - 2022-08-21 11:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:34:12 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:04:13 --> Total execution time: 0.5799
DEBUG - 2022-08-21 11:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:34:22 --> Total execution time: 0.3309
DEBUG - 2022-08-21 11:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:04:23 --> Total execution time: 0.7586
DEBUG - 2022-08-21 11:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:04:29 --> Total execution time: 0.5088
DEBUG - 2022-08-21 11:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:04:30 --> Total execution time: 0.8129
DEBUG - 2022-08-21 11:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:05:06 --> Total execution time: 0.1051
DEBUG - 2022-08-21 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:05:12 --> Total execution time: 0.3386
DEBUG - 2022-08-21 11:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:05:20 --> Total execution time: 0.4286
DEBUG - 2022-08-21 11:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:05:27 --> Total execution time: 0.0949
DEBUG - 2022-08-21 11:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:35:46 --> Total execution time: 1.2604
DEBUG - 2022-08-21 11:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:05:53 --> Total execution time: 0.2206
DEBUG - 2022-08-21 11:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:05:57 --> Total execution time: 0.0577
DEBUG - 2022-08-21 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:05:57 --> Total execution time: 0.1148
DEBUG - 2022-08-21 11:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:06:01 --> Total execution time: 0.2753
DEBUG - 2022-08-21 11:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:06:10 --> Total execution time: 1.4096
DEBUG - 2022-08-21 11:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:06:10 --> Total execution time: 0.5845
DEBUG - 2022-08-21 11:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:06:14 --> Total execution time: 1.0974
DEBUG - 2022-08-21 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:06:18 --> Total execution time: 0.1250
DEBUG - 2022-08-21 11:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:06:20 --> Total execution time: 0.3631
DEBUG - 2022-08-21 11:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:36:23 --> Total execution time: 1.2047
DEBUG - 2022-08-21 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:36:39 --> Total execution time: 0.1303
DEBUG - 2022-08-21 11:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:36:56 --> Total execution time: 0.1705
DEBUG - 2022-08-21 11:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:37:03 --> Total execution time: 0.3783
DEBUG - 2022-08-21 11:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:37:08 --> Total execution time: 1.8487
DEBUG - 2022-08-21 11:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:37:10 --> Total execution time: 0.2517
DEBUG - 2022-08-21 11:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:37:12 --> Total execution time: 0.3355
DEBUG - 2022-08-21 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:37:15 --> Total execution time: 0.6815
DEBUG - 2022-08-21 11:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:37:24 --> Total execution time: 0.3963
DEBUG - 2022-08-21 11:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:37:44 --> Total execution time: 0.1189
DEBUG - 2022-08-21 11:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:38:01 --> Total execution time: 0.0907
DEBUG - 2022-08-21 11:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:08:06 --> Total execution time: 0.4537
DEBUG - 2022-08-21 11:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:38:16 --> Total execution time: 0.2560
DEBUG - 2022-08-21 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:38:59 --> Total execution time: 0.3904
DEBUG - 2022-08-21 11:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:39:21 --> Total execution time: 0.1174
DEBUG - 2022-08-21 11:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:39:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:09:36 --> Total execution time: 0.1149
DEBUG - 2022-08-21 11:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:09:41 --> Total execution time: 0.4277
DEBUG - 2022-08-21 11:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:39:55 --> Total execution time: 0.1410
DEBUG - 2022-08-21 11:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:39:56 --> Total execution time: 0.1943
DEBUG - 2022-08-21 11:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:39:57 --> Total execution time: 0.5895
DEBUG - 2022-08-21 11:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:40:14 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:15 --> Total execution time: 0.1911
DEBUG - 2022-08-21 11:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:40:25 --> Total execution time: 0.2969
DEBUG - 2022-08-21 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:40:28 --> Total execution time: 0.7125
DEBUG - 2022-08-21 11:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:40:28 --> Total execution time: 0.5159
DEBUG - 2022-08-21 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:40:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:38 --> Total execution time: 0.3561
DEBUG - 2022-08-21 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:40:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:40 --> Total execution time: 0.2468
DEBUG - 2022-08-21 11:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:11:10 --> Total execution time: 0.4629
DEBUG - 2022-08-21 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:11:14 --> Total execution time: 0.1220
DEBUG - 2022-08-21 11:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:15 --> Total execution time: 0.6953
DEBUG - 2022-08-21 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:11:17 --> Total execution time: 0.3679
DEBUG - 2022-08-21 11:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:30 --> Total execution time: 0.1117
DEBUG - 2022-08-21 11:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:11:31 --> Total execution time: 0.4609
DEBUG - 2022-08-21 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:11:35 --> Total execution time: 0.1316
DEBUG - 2022-08-21 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:11:44 --> Total execution time: 0.3737
DEBUG - 2022-08-21 11:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:45 --> Total execution time: 0.1512
DEBUG - 2022-08-21 11:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:11:51 --> Total execution time: 0.4945
DEBUG - 2022-08-21 11:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:56 --> Total execution time: 0.4610
DEBUG - 2022-08-21 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:41:57 --> Total execution time: 0.3861
DEBUG - 2022-08-21 11:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:02 --> Total execution time: 0.2241
DEBUG - 2022-08-21 11:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:08 --> Total execution time: 0.1143
DEBUG - 2022-08-21 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:09 --> Total execution time: 0.4023
DEBUG - 2022-08-21 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:10 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:10 --> Total execution time: 0.1311
DEBUG - 2022-08-21 11:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:24 --> Total execution time: 0.1224
DEBUG - 2022-08-21 11:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:33 --> Total execution time: 0.2848
DEBUG - 2022-08-21 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:34 --> Total execution time: 0.0949
DEBUG - 2022-08-21 11:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:41 --> Total execution time: 0.4077
DEBUG - 2022-08-21 11:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:44 --> Total execution time: 0.0992
DEBUG - 2022-08-21 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:52 --> Total execution time: 0.1044
DEBUG - 2022-08-21 11:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:53 --> Total execution time: 0.0953
DEBUG - 2022-08-21 11:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:12:59 --> Total execution time: 0.0853
DEBUG - 2022-08-21 11:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:13:02 --> Total execution time: 0.1012
DEBUG - 2022-08-21 11:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:13:09 --> Total execution time: 0.1056
DEBUG - 2022-08-21 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:13:11 --> Total execution time: 0.0838
DEBUG - 2022-08-21 11:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:13:20 --> Total execution time: 0.0891
DEBUG - 2022-08-21 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:13:49 --> Total execution time: 0.0561
DEBUG - 2022-08-21 11:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 11:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:19 --> Total execution time: 0.0925
DEBUG - 2022-08-21 11:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:21 --> Total execution time: 0.0832
DEBUG - 2022-08-21 11:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:29 --> Total execution time: 0.0994
DEBUG - 2022-08-21 11:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:44:45 --> Total execution time: 0.0847
DEBUG - 2022-08-21 11:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:55 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:55 --> Total execution time: 0.2204
DEBUG - 2022-08-21 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:59 --> Total execution time: 0.0872
DEBUG - 2022-08-21 11:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:04 --> Total execution time: 0.0925
DEBUG - 2022-08-21 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:45:05 --> Total execution time: 0.1172
DEBUG - 2022-08-21 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:05 --> Total execution time: 0.0910
DEBUG - 2022-08-21 11:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:07 --> Total execution time: 0.0895
DEBUG - 2022-08-21 11:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:11 --> Total execution time: 0.0910
DEBUG - 2022-08-21 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:13 --> Total execution time: 0.0942
DEBUG - 2022-08-21 11:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:24 --> Total execution time: 0.0838
DEBUG - 2022-08-21 11:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:32 --> Total execution time: 0.1042
DEBUG - 2022-08-21 11:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:38 --> Total execution time: 0.1119
DEBUG - 2022-08-21 11:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:16:38 --> Total execution time: 0.1250
DEBUG - 2022-08-21 11:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:16:54 --> Total execution time: 0.1177
DEBUG - 2022-08-21 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:17:00 --> Total execution time: 0.2041
DEBUG - 2022-08-21 11:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:47:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:17:09 --> Total execution time: 0.1941
DEBUG - 2022-08-21 11:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:47:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:17:09 --> Total execution time: 0.1356
DEBUG - 2022-08-21 11:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:47:32 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:17:32 --> Total execution time: 0.2471
DEBUG - 2022-08-21 11:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:48:51 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:18:51 --> Total execution time: 0.1835
DEBUG - 2022-08-21 11:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:19:03 --> Total execution time: 0.1661
DEBUG - 2022-08-21 11:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:19:38 --> Total execution time: 0.1833
DEBUG - 2022-08-21 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:20:46 --> Total execution time: 0.0863
DEBUG - 2022-08-21 11:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:21:49 --> Total execution time: 0.0814
DEBUG - 2022-08-21 11:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:52:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:22:43 --> Total execution time: 0.0620
DEBUG - 2022-08-21 11:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 11:52:50 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-21 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:22:54 --> Total execution time: 0.0489
DEBUG - 2022-08-21 11:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:23:08 --> Total execution time: 0.0807
DEBUG - 2022-08-21 11:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:21 --> Total execution time: 0.1263
DEBUG - 2022-08-21 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:25 --> Total execution time: 0.0830
DEBUG - 2022-08-21 11:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:28 --> Total execution time: 0.0823
DEBUG - 2022-08-21 11:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 11:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:33 --> Total execution time: 0.0847
DEBUG - 2022-08-21 11:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:55:44 --> No URI present. Default controller set.
DEBUG - 2022-08-21 11:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:44 --> Total execution time: 0.0699
DEBUG - 2022-08-21 11:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:29:23 --> Total execution time: 0.3222
DEBUG - 2022-08-21 11:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 11:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 11:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:29:30 --> Total execution time: 0.0888
DEBUG - 2022-08-21 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:30:02 --> Total execution time: 0.1330
DEBUG - 2022-08-21 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:31:01 --> Total execution time: 0.0963
DEBUG - 2022-08-21 12:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:31:11 --> Total execution time: 0.1107
DEBUG - 2022-08-21 12:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:31:31 --> Total execution time: 0.1153
DEBUG - 2022-08-21 12:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:02:56 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:32:56 --> Total execution time: 0.2573
DEBUG - 2022-08-21 12:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:10 --> Total execution time: 0.1476
DEBUG - 2022-08-21 12:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:18 --> Total execution time: 0.0966
DEBUG - 2022-08-21 12:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:03:18 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:19 --> Total execution time: 0.0551
DEBUG - 2022-08-21 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:03:34 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:34 --> Total execution time: 0.0874
DEBUG - 2022-08-21 12:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:03:41 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:41 --> Total execution time: 0.0837
DEBUG - 2022-08-21 12:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:03:52 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:52 --> Total execution time: 0.0890
DEBUG - 2022-08-21 12:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:39:37 --> Total execution time: 0.3515
DEBUG - 2022-08-21 12:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:09:44 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:39:44 --> Total execution time: 0.0916
DEBUG - 2022-08-21 12:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:39:52 --> Total execution time: 0.0942
DEBUG - 2022-08-21 12:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:39:56 --> Total execution time: 0.0938
DEBUG - 2022-08-21 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:40:03 --> Total execution time: 0.0928
DEBUG - 2022-08-21 12:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:40:26 --> Total execution time: 0.1185
DEBUG - 2022-08-21 12:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:40:40 --> Total execution time: 0.1162
DEBUG - 2022-08-21 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:40:56 --> Total execution time: 0.2137
DEBUG - 2022-08-21 12:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:41:03 --> Total execution time: 0.0792
DEBUG - 2022-08-21 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:41:08 --> Total execution time: 0.0836
DEBUG - 2022-08-21 12:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:41:11 --> Total execution time: 0.1149
DEBUG - 2022-08-21 12:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:43:16 --> Total execution time: 0.0936
DEBUG - 2022-08-21 12:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:43:19 --> Total execution time: 0.0887
DEBUG - 2022-08-21 12:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:43:24 --> Total execution time: 0.0819
DEBUG - 2022-08-21 12:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:43:31 --> Total execution time: 0.0829
DEBUG - 2022-08-21 12:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:43:42 --> Total execution time: 0.1121
DEBUG - 2022-08-21 12:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:43:44 --> Total execution time: 0.0937
DEBUG - 2022-08-21 12:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:43:53 --> Total execution time: 0.2319
DEBUG - 2022-08-21 12:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:45:16 --> Total execution time: 0.2509
DEBUG - 2022-08-21 12:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:45:34 --> Total execution time: 0.1060
DEBUG - 2022-08-21 12:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:46:08 --> Total execution time: 0.0915
DEBUG - 2022-08-21 12:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:46:14 --> Total execution time: 0.0888
DEBUG - 2022-08-21 12:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:46:21 --> Total execution time: 0.0906
DEBUG - 2022-08-21 12:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:16:55 --> Total execution time: 0.0890
DEBUG - 2022-08-21 12:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:47:36 --> Total execution time: 0.0905
DEBUG - 2022-08-21 12:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:18:54 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:54 --> Total execution time: 0.2207
DEBUG - 2022-08-21 12:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:18:56 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:56 --> Total execution time: 0.1173
DEBUG - 2022-08-21 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:00 --> Total execution time: 0.0866
DEBUG - 2022-08-21 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:08 --> Total execution time: 0.0883
DEBUG - 2022-08-21 12:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:20 --> Total execution time: 0.1744
DEBUG - 2022-08-21 12:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:31 --> Total execution time: 0.1175
DEBUG - 2022-08-21 12:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:33 --> Total execution time: 0.1126
DEBUG - 2022-08-21 12:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:53 --> Total execution time: 0.0819
DEBUG - 2022-08-21 12:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:22 --> Total execution time: 0.0826
DEBUG - 2022-08-21 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:58 --> Total execution time: 0.1059
DEBUG - 2022-08-21 12:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:51:04 --> Total execution time: 0.0826
DEBUG - 2022-08-21 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:51:30 --> Total execution time: 0.0957
DEBUG - 2022-08-21 12:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:51:37 --> Total execution time: 0.1288
DEBUG - 2022-08-21 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:51:55 --> Total execution time: 0.1083
DEBUG - 2022-08-21 12:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:51:57 --> Total execution time: 0.1511
DEBUG - 2022-08-21 12:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:23:23 --> Total execution time: 0.1127
DEBUG - 2022-08-21 12:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:23:27 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:53:27 --> Total execution time: 0.0577
DEBUG - 2022-08-21 12:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:53:36 --> Total execution time: 0.2282
DEBUG - 2022-08-21 12:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:53:45 --> Total execution time: 0.0526
DEBUG - 2022-08-21 12:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:00 --> Total execution time: 0.0945
DEBUG - 2022-08-21 12:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:18 --> Total execution time: 0.1100
DEBUG - 2022-08-21 12:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:25 --> Total execution time: 0.1288
DEBUG - 2022-08-21 12:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:29 --> Total execution time: 0.0828
DEBUG - 2022-08-21 12:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:36 --> Total execution time: 0.0829
DEBUG - 2022-08-21 12:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:42 --> Total execution time: 0.2260
DEBUG - 2022-08-21 12:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:54 --> Total execution time: 0.0834
DEBUG - 2022-08-21 12:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:24:58 --> Total execution time: 0.0861
DEBUG - 2022-08-21 12:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:55:23 --> Total execution time: 0.1208
DEBUG - 2022-08-21 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:25:26 --> Total execution time: 0.1082
DEBUG - 2022-08-21 12:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:55:32 --> Total execution time: 0.0958
DEBUG - 2022-08-21 12:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:55:51 --> Total execution time: 0.1011
DEBUG - 2022-08-21 12:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:56:36 --> Total execution time: 0.0893
DEBUG - 2022-08-21 12:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:56:48 --> Total execution time: 0.0814
DEBUG - 2022-08-21 12:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:57:13 --> Total execution time: 0.0875
DEBUG - 2022-08-21 12:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:57:15 --> Total execution time: 0.0910
DEBUG - 2022-08-21 12:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:57:22 --> Total execution time: 0.1118
DEBUG - 2022-08-21 12:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:57:37 --> Total execution time: 0.1097
DEBUG - 2022-08-21 12:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:27:58 --> Total execution time: 0.0929
DEBUG - 2022-08-21 12:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:28:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:58:09 --> Total execution time: 0.0912
DEBUG - 2022-08-21 12:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:28:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:58:20 --> Total execution time: 0.0856
DEBUG - 2022-08-21 12:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:21 --> Total execution time: 0.1411
DEBUG - 2022-08-21 12:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:58:40 --> Total execution time: 0.0836
DEBUG - 2022-08-21 12:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:58:51 --> Total execution time: 0.0912
DEBUG - 2022-08-21 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:58:58 --> Total execution time: 0.0819
DEBUG - 2022-08-21 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:59:05 --> Total execution time: 0.1003
DEBUG - 2022-08-21 12:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:59:06 --> Total execution time: 0.0982
DEBUG - 2022-08-21 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:59:25 --> Total execution time: 0.0896
DEBUG - 2022-08-21 12:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:59:33 --> Total execution time: 0.0848
DEBUG - 2022-08-21 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:00:01 --> Total execution time: 0.1312
DEBUG - 2022-08-21 12:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:00:10 --> Total execution time: 0.1191
DEBUG - 2022-08-21 12:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:00:24 --> Total execution time: 0.1242
DEBUG - 2022-08-21 12:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:00:25 --> Total execution time: 0.0855
DEBUG - 2022-08-21 12:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:00:27 --> Total execution time: 0.0894
DEBUG - 2022-08-21 12:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:30:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:00:43 --> Total execution time: 0.0602
DEBUG - 2022-08-21 12:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:31:17 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:01:18 --> Total execution time: 0.0597
DEBUG - 2022-08-21 12:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:32:17 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:17 --> Total execution time: 0.2667
DEBUG - 2022-08-21 12:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:21 --> Total execution time: 0.1211
DEBUG - 2022-08-21 12:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:26 --> Total execution time: 0.0888
DEBUG - 2022-08-21 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:28 --> Total execution time: 0.0844
DEBUG - 2022-08-21 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:29 --> Total execution time: 0.0851
DEBUG - 2022-08-21 12:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:32 --> Total execution time: 0.0816
DEBUG - 2022-08-21 12:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:03:09 --> Total execution time: 0.0931
DEBUG - 2022-08-21 12:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:03:24 --> Total execution time: 0.1049
DEBUG - 2022-08-21 12:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:03:43 --> Total execution time: 0.0941
DEBUG - 2022-08-21 12:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:34:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:04:06 --> Total execution time: 0.0571
DEBUG - 2022-08-21 12:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:04:13 --> Total execution time: 0.0842
DEBUG - 2022-08-21 12:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:04:56 --> Total execution time: 0.2772
DEBUG - 2022-08-21 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:05:08 --> Total execution time: 0.0826
DEBUG - 2022-08-21 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:35:29 --> Total execution time: 0.0853
DEBUG - 2022-08-21 12:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:35:46 --> Total execution time: 0.1083
DEBUG - 2022-08-21 12:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:20 --> Total execution time: 0.2216
DEBUG - 2022-08-21 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:21 --> Total execution time: 0.0897
DEBUG - 2022-08-21 12:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:24 --> Total execution time: 0.1073
DEBUG - 2022-08-21 12:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:28 --> Total execution time: 0.1067
DEBUG - 2022-08-21 12:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:30 --> Total execution time: 0.0875
DEBUG - 2022-08-21 12:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:36 --> Total execution time: 0.0909
DEBUG - 2022-08-21 12:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:50 --> Total execution time: 0.0950
DEBUG - 2022-08-21 12:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:07:03 --> Total execution time: 0.0890
DEBUG - 2022-08-21 12:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:07:16 --> Total execution time: 0.2289
DEBUG - 2022-08-21 12:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:39:37 --> Total execution time: 0.1945
DEBUG - 2022-08-21 12:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:39:51 --> Total execution time: 0.1025
DEBUG - 2022-08-21 12:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:25 --> Total execution time: 0.1519
DEBUG - 2022-08-21 12:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:34 --> Total execution time: 0.1110
DEBUG - 2022-08-21 12:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:35 --> Total execution time: 0.0929
DEBUG - 2022-08-21 12:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:40 --> Total execution time: 0.0899
DEBUG - 2022-08-21 12:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:54 --> Total execution time: 0.0967
DEBUG - 2022-08-21 12:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:59 --> Total execution time: 0.1169
DEBUG - 2022-08-21 12:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:11:12 --> Total execution time: 0.1212
DEBUG - 2022-08-21 12:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:11:53 --> Total execution time: 0.0897
DEBUG - 2022-08-21 12:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:03 --> Total execution time: 0.2279
DEBUG - 2022-08-21 12:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:13 --> Total execution time: 0.0846
DEBUG - 2022-08-21 12:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-21 12:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:18 --> Total execution time: 0.1191
DEBUG - 2022-08-21 12:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:30 --> Total execution time: 0.1245
DEBUG - 2022-08-21 12:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:42:51 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:51 --> Total execution time: 0.0708
DEBUG - 2022-08-21 12:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:13:13 --> Total execution time: 0.0936
DEBUG - 2022-08-21 12:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:13:23 --> Total execution time: 0.1201
DEBUG - 2022-08-21 12:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:43:32 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:13:32 --> Total execution time: 0.0846
DEBUG - 2022-08-21 12:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:14:02 --> Total execution time: 0.0806
DEBUG - 2022-08-21 12:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:44:13 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:14:13 --> Total execution time: 0.0999
DEBUG - 2022-08-21 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:15:27 --> Total execution time: 0.0848
DEBUG - 2022-08-21 12:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:15:29 --> Total execution time: 0.0857
DEBUG - 2022-08-21 12:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:15:31 --> Total execution time: 0.0848
DEBUG - 2022-08-21 12:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:15:40 --> Total execution time: 0.0931
DEBUG - 2022-08-21 12:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:15:43 --> Total execution time: 0.0824
DEBUG - 2022-08-21 12:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:15:45 --> Total execution time: 0.0836
DEBUG - 2022-08-21 12:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:46 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:15:46 --> Total execution time: 0.0877
DEBUG - 2022-08-21 12:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:45:53 --> Total execution time: 0.0863
DEBUG - 2022-08-21 12:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:46:01 --> Total execution time: 0.0869
DEBUG - 2022-08-21 12:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:46:02 --> Total execution time: 0.1381
DEBUG - 2022-08-21 12:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:16:11 --> Total execution time: 2.3701
DEBUG - 2022-08-21 12:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 12:46:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 12:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:46:33 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:16:33 --> Total execution time: 0.0602
DEBUG - 2022-08-21 12:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:16:41 --> Total execution time: 0.0832
DEBUG - 2022-08-21 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:17:01 --> Total execution time: 0.0988
DEBUG - 2022-08-21 12:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:17:08 --> Total execution time: 0.0575
DEBUG - 2022-08-21 12:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:17:11 --> Total execution time: 0.0870
DEBUG - 2022-08-21 12:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:17:19 --> Total execution time: 0.0872
DEBUG - 2022-08-21 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:47:26 --> Total execution time: 0.0773
DEBUG - 2022-08-21 12:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:47:27 --> Total execution time: 0.0816
DEBUG - 2022-08-21 12:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:47:27 --> Total execution time: 0.0871
DEBUG - 2022-08-21 12:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:17:31 --> Total execution time: 0.2398
DEBUG - 2022-08-21 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:18:15 --> Total execution time: 0.0839
DEBUG - 2022-08-21 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:18:41 --> Total execution time: 0.0821
DEBUG - 2022-08-21 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:18:51 --> Total execution time: 0.1041
DEBUG - 2022-08-21 12:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:19:28 --> Total execution time: 0.0880
DEBUG - 2022-08-21 12:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:49:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:19:30 --> Total execution time: 0.2193
DEBUG - 2022-08-21 12:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:49:33 --> Total execution time: 0.0853
DEBUG - 2022-08-21 12:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:49:34 --> Total execution time: 0.1083
DEBUG - 2022-08-21 12:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:49:34 --> Total execution time: 0.0938
DEBUG - 2022-08-21 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:50:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:20:01 --> Total execution time: 0.0604
DEBUG - 2022-08-21 12:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:50:31 --> Total execution time: 0.0853
DEBUG - 2022-08-21 12:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:50:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:20:36 --> Total execution time: 0.0631
DEBUG - 2022-08-21 12:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:50:53 --> Total execution time: 0.0860
DEBUG - 2022-08-21 12:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:50:58 --> Total execution time: 0.0829
DEBUG - 2022-08-21 12:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:51:02 --> Total execution time: 0.0964
DEBUG - 2022-08-21 12:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:51:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:21:38 --> Total execution time: 0.0846
DEBUG - 2022-08-21 12:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:21:51 --> Total execution time: 0.2220
DEBUG - 2022-08-21 12:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:22:19 --> Total execution time: 0.0984
DEBUG - 2022-08-21 12:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:22:28 --> Total execution time: 0.0803
DEBUG - 2022-08-21 12:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:54:20 --> No URI present. Default controller set.
DEBUG - 2022-08-21 12:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:20 --> Total execution time: 0.0944
DEBUG - 2022-08-21 12:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:27 --> Total execution time: 0.0839
DEBUG - 2022-08-21 12:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:25:39 --> Total execution time: 0.0781
DEBUG - 2022-08-21 12:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:25:51 --> Total execution time: 0.0839
DEBUG - 2022-08-21 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:39 --> Total execution time: 0.2525
DEBUG - 2022-08-21 12:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:22 --> Total execution time: 0.1203
DEBUG - 2022-08-21 12:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 12:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 12:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:27 --> Total execution time: 0.0902
DEBUG - 2022-08-21 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 12:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 12:59:04 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-08-21 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:30:02 --> Total execution time: 0.0764
DEBUG - 2022-08-21 13:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:01:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 13:01:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 13:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:34:17 --> Total execution time: 0.0962
DEBUG - 2022-08-21 13:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:35:50 --> Total execution time: 0.0900
DEBUG - 2022-08-21 13:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:35:58 --> Total execution time: 0.1184
DEBUG - 2022-08-21 13:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:43:10 --> Total execution time: 0.3223
DEBUG - 2022-08-21 13:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:43:23 --> Total execution time: 0.1001
DEBUG - 2022-08-21 13:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:43:24 --> Total execution time: 0.0923
DEBUG - 2022-08-21 13:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:43:39 --> Total execution time: 0.0903
DEBUG - 2022-08-21 13:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:43:49 --> Total execution time: 0.0971
DEBUG - 2022-08-21 13:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:43:59 --> Total execution time: 0.0896
DEBUG - 2022-08-21 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:44:05 --> Total execution time: 0.1092
DEBUG - 2022-08-21 13:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:44:17 --> Total execution time: 0.1222
DEBUG - 2022-08-21 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:44:23 --> Total execution time: 0.0877
DEBUG - 2022-08-21 13:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:45:51 --> Total execution time: 0.0898
DEBUG - 2022-08-21 13:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:46:18 --> Total execution time: 0.0882
DEBUG - 2022-08-21 13:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:46:37 --> Total execution time: 0.0836
DEBUG - 2022-08-21 13:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:47:54 --> Total execution time: 0.2256
DEBUG - 2022-08-21 13:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:48:01 --> Total execution time: 0.0939
DEBUG - 2022-08-21 13:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 13:18:40 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:49:40 --> Total execution time: 0.2274
DEBUG - 2022-08-21 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:49:50 --> Total execution time: 0.0897
DEBUG - 2022-08-21 13:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:49:52 --> Total execution time: 0.0910
DEBUG - 2022-08-21 13:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:49:53 --> Total execution time: 0.0837
DEBUG - 2022-08-21 13:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:50:28 --> Total execution time: 0.0830
DEBUG - 2022-08-21 13:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:50:42 --> Total execution time: 0.0830
DEBUG - 2022-08-21 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:50:53 --> Total execution time: 0.0854
DEBUG - 2022-08-21 13:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:21:07 --> No URI present. Default controller set.
DEBUG - 2022-08-21 13:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:51:07 --> Total execution time: 0.0840
DEBUG - 2022-08-21 13:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:51:31 --> Total execution time: 0.2244
DEBUG - 2022-08-21 13:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:56:33 --> Total execution time: 0.2985
DEBUG - 2022-08-21 13:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:32:20 --> No URI present. Default controller set.
DEBUG - 2022-08-21 13:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:32:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 13:32:48 --> 404 Page Not Found: Terms/feed
DEBUG - 2022-08-21 13:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:41:28 --> No URI present. Default controller set.
DEBUG - 2022-08-21 13:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:43:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 13:43:28 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-08-21 13:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:44:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 13:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:44:55 --> Total execution time: 0.0868
DEBUG - 2022-08-21 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:44:58 --> Total execution time: 0.1007
DEBUG - 2022-08-21 13:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:44:58 --> Total execution time: 0.1994
DEBUG - 2022-08-21 13:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:45:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 13:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 13:46:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 13:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:46:59 --> Total execution time: 0.0911
DEBUG - 2022-08-21 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:55:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 13:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:45 --> Total execution time: 0.0817
DEBUG - 2022-08-21 13:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:47 --> Total execution time: 0.0772
DEBUG - 2022-08-21 13:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:55:47 --> Total execution time: 0.0831
DEBUG - 2022-08-21 13:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 13:57:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 13:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:17 --> No URI present. Default controller set.
DEBUG - 2022-08-21 13:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 13:58:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 13:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:34 --> No URI present. Default controller set.
DEBUG - 2022-08-21 13:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 13:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 13:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 13:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:28 --> Total execution time: 0.0552
DEBUG - 2022-08-21 14:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:45 --> Total execution time: 0.0767
DEBUG - 2022-08-21 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:11:58 --> Total execution time: 0.0836
DEBUG - 2022-08-21 14:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:14:03 --> Total execution time: 0.0810
DEBUG - 2022-08-21 14:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:15:56 --> No URI present. Default controller set.
DEBUG - 2022-08-21 14:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 14:17:48 --> 404 Page Not Found: Course-category/development
DEBUG - 2022-08-21 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:20:45 --> Total execution time: 0.0850
DEBUG - 2022-08-21 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:20:51 --> Total execution time: 0.1023
DEBUG - 2022-08-21 14:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:26:26 --> No URI present. Default controller set.
DEBUG - 2022-08-21 14:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:29:51 --> No URI present. Default controller set.
DEBUG - 2022-08-21 14:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:31:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 14:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:37:55 --> No URI present. Default controller set.
DEBUG - 2022-08-21 14:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:43:04 --> No URI present. Default controller set.
DEBUG - 2022-08-21 14:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:43:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 14:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:47:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 14:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 14:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 14:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 14:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 15:02:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 15:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 15:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 15:10:50 --> No URI present. Default controller set.
DEBUG - 2022-08-21 15:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 15:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 15:28:02 --> No URI present. Default controller set.
DEBUG - 2022-08-21 15:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 15:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 15:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 15:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 15:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 15:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 15:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 16:20:07 --> 404 Page Not Found: Course/freelancing
DEBUG - 2022-08-21 16:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 16:33:56 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 16:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:33:58 --> No URI present. Default controller set.
DEBUG - 2022-08-21 16:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 16:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 16:49:10 --> No URI present. Default controller set.
DEBUG - 2022-08-21 16:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 16:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:06:00 --> No URI present. Default controller set.
DEBUG - 2022-08-21 17:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 17:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 17:22:31 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 17:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:22:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 17:22:38 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 17:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:22:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 17:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 17:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:29:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 17:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 17:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 17:32:01 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 17:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 17:32:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 17:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:32:10 --> No URI present. Default controller set.
DEBUG - 2022-08-21 17:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 17:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 17:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 17:34:37 --> No URI present. Default controller set.
DEBUG - 2022-08-21 17:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 17:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 18:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 18:27:05 --> No URI present. Default controller set.
DEBUG - 2022-08-21 18:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 18:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:12:46 --> No URI present. Default controller set.
DEBUG - 2022-08-21 19:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:13:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 19:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:13:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 19:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:16:59 --> No URI present. Default controller set.
DEBUG - 2022-08-21 19:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:17:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 19:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:19:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 19:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:27:34 --> No URI present. Default controller set.
DEBUG - 2022-08-21 19:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 19:27:35 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-21 19:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 19:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 19:45:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 19:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 19:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:15:58 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:17:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:22 --> Total execution time: 0.0584
DEBUG - 2022-08-21 20:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:24 --> Total execution time: 0.0838
DEBUG - 2022-08-21 20:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:25 --> Total execution time: 0.0782
DEBUG - 2022-08-21 20:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:55 --> Total execution time: 0.0844
DEBUG - 2022-08-21 20:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:57 --> Total execution time: 0.0875
DEBUG - 2022-08-21 20:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:17:57 --> Total execution time: 0.1949
DEBUG - 2022-08-21 20:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:26 --> Total execution time: 0.0839
DEBUG - 2022-08-21 20:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:27 --> Total execution time: 0.0826
DEBUG - 2022-08-21 20:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:28 --> Total execution time: 0.0982
DEBUG - 2022-08-21 20:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:28 --> Total execution time: 0.0852
DEBUG - 2022-08-21 20:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:19:24 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:20:23 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:15 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:45 --> Total execution time: 0.0929
DEBUG - 2022-08-21 20:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:21:56 --> Total execution time: 0.0824
DEBUG - 2022-08-21 20:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:20 --> Total execution time: 0.0930
DEBUG - 2022-08-21 20:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:24 --> Total execution time: 0.2231
DEBUG - 2022-08-21 20:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:25 --> Total execution time: 0.0838
DEBUG - 2022-08-21 20:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:27 --> Total execution time: 0.0914
DEBUG - 2022-08-21 20:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:23:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:28:28 --> Total execution time: 0.0926
DEBUG - 2022-08-21 20:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:28:37 --> Total execution time: 0.1405
DEBUG - 2022-08-21 20:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 20:33:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 20:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:22 --> Total execution time: 0.0846
DEBUG - 2022-08-21 20:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:35 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:35:23 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:47:41 --> No URI present. Default controller set.
DEBUG - 2022-08-21 20:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 20:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 20:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 20:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:00:28 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:02:22 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:05:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:05:55 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:10:25 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:32 --> Total execution time: 0.0913
DEBUG - 2022-08-21 21:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:33 --> Total execution time: 0.0528
DEBUG - 2022-08-21 21:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:35 --> Total execution time: 0.0533
DEBUG - 2022-08-21 21:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:35 --> Total execution time: 0.0527
DEBUG - 2022-08-21 21:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:13:55 --> Total execution time: 0.0827
DEBUG - 2022-08-21 21:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:10 --> Total execution time: 0.0809
DEBUG - 2022-08-21 21:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:15 --> Total execution time: 0.0826
DEBUG - 2022-08-21 21:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:20 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:18 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:25 --> Total execution time: 0.0958
DEBUG - 2022-08-21 21:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:27 --> Total execution time: 0.0931
DEBUG - 2022-08-21 21:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:27 --> Total execution time: 0.0888
DEBUG - 2022-08-21 21:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:15:55 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:16:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:16:47 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:16:49 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:16:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:21 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:36 --> Total execution time: 0.0958
DEBUG - 2022-08-21 21:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:42 --> Total execution time: 0.1274
DEBUG - 2022-08-21 21:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:12 --> Total execution time: 0.0843
DEBUG - 2022-08-21 21:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:14 --> Total execution time: 0.0894
DEBUG - 2022-08-21 21:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:14 --> Total execution time: 0.0821
DEBUG - 2022-08-21 21:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:01 --> Total execution time: 0.0987
DEBUG - 2022-08-21 21:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 21:21:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 21:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:34 --> Total execution time: 0.1090
DEBUG - 2022-08-21 21:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:36 --> Total execution time: 0.0976
DEBUG - 2022-08-21 21:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:25:23 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:02 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:09 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:26:56 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:21 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:21 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:26 --> Total execution time: 0.0843
DEBUG - 2022-08-21 21:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:37 --> Total execution time: 0.0829
DEBUG - 2022-08-21 21:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:40 --> Total execution time: 0.0832
DEBUG - 2022-08-21 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:32:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:35:58 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:36:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 21:36:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 21:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:36:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:43:29 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:46:22 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:46:45 --> No URI present. Default controller set.
DEBUG - 2022-08-21 21:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 21:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 21:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 21:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:00:31 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:00:53 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:06:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:08:19 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:08:27 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:10:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:13:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:14:01 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:14:33 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:14:48 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:15:40 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:48 --> Total execution time: 0.0839
DEBUG - 2022-08-21 22:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:50 --> Total execution time: 0.0870
DEBUG - 2022-08-21 22:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:15:50 --> Total execution time: 0.0868
DEBUG - 2022-08-21 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 22:16:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-21 22:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:18:38 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:19:16 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:21:17 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:25:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:26:18 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:33:27 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:34:43 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:40:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:46:20 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:54 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:14 --> Total execution time: 0.0667
DEBUG - 2022-08-21 22:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:20 --> Total execution time: 0.0905
DEBUG - 2022-08-21 22:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:20 --> Total execution time: 0.1237
DEBUG - 2022-08-21 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:25 --> Total execution time: 0.0875
DEBUG - 2022-08-21 22:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:27 --> Total execution time: 0.0936
DEBUG - 2022-08-21 22:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:50:28 --> Total execution time: 0.0889
DEBUG - 2022-08-21 22:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:52:15 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:53:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 22:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 22:55:08 --> 404 Page Not Found: Terms/feed
DEBUG - 2022-08-21 22:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 22:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 22:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 22:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:02:27 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:02:39 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:06:50 --> Total execution time: 0.1015
DEBUG - 2022-08-21 23:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:06:50 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:08:45 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:10:06 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:11:00 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:15:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-21 23:15:05 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-21 23:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:25:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:54 --> Total execution time: 0.1067
DEBUG - 2022-08-21 23:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:34 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:42 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:31:54 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:36:30 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:40:08 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:46:16 --> Total execution time: 0.0539
DEBUG - 2022-08-21 23:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:46:21 --> Total execution time: 0.0780
DEBUG - 2022-08-21 23:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:46:26 --> Total execution time: 0.0905
DEBUG - 2022-08-21 23:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:55:36 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:55:37 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:04 --> No URI present. Default controller set.
DEBUG - 2022-08-21 23:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-21 23:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-21 23:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-21 23:59:01 --> Encryption: Auto-configured driver 'openssl'.
