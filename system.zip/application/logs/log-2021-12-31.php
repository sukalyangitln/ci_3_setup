<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-31 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:35:26 --> No URI present. Default controller set.
DEBUG - 2021-12-31 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:05:28 --> Total execution time: 2.8164
DEBUG - 2021-12-31 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 10:35:35 --> Total execution time: 0.0533
DEBUG - 2021-12-31 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:35:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-31 15:05:37 --> Query error: Table 'jaal.payments' doesn't exist - Invalid query: SELECT *
FROM `payments`
JOIN `users` ON `users`.`u_id` = `payments`.`p_FK_ul_id`
DEBUG - 2021-12-31 10:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 10:36:48 --> 404 Page Not Found: Admin/DashboardController/Payment_List
DEBUG - 2021-12-31 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:06:56 --> Total execution time: 0.5925
DEBUG - 2021-12-31 10:37:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:07:13 --> Total execution time: 0.0505
DEBUG - 2021-12-31 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:08:10 --> Total execution time: 0.0596
DEBUG - 2021-12-31 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:08:59 --> Total execution time: 0.0497
DEBUG - 2021-12-31 10:39:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:09:07 --> Total execution time: 0.0755
DEBUG - 2021-12-31 10:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:09:32 --> Total execution time: 0.0689
DEBUG - 2021-12-31 10:39:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:09:43 --> Total execution time: 0.0620
DEBUG - 2021-12-31 10:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:10:32 --> Total execution time: 0.0656
DEBUG - 2021-12-31 10:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:10:43 --> Total execution time: 0.0501
DEBUG - 2021-12-31 10:41:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:11:14 --> Total execution time: 0.0851
DEBUG - 2021-12-31 10:41:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:11:42 --> Total execution time: 0.0527
DEBUG - 2021-12-31 10:42:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:12:02 --> Total execution time: 0.0578
DEBUG - 2021-12-31 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:12:32 --> Total execution time: 0.0741
DEBUG - 2021-12-31 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:12:42 --> Total execution time: 0.0592
DEBUG - 2021-12-31 10:43:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:13:27 --> Total execution time: 0.0776
DEBUG - 2021-12-31 10:43:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:13:29 --> Total execution time: 0.0526
DEBUG - 2021-12-31 10:43:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:13:35 --> Total execution time: 0.1156
DEBUG - 2021-12-31 10:44:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:14:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:14:12 --> You did not select a file to upload.
DEBUG - 2021-12-31 15:14:12 --> You did not select a file to upload.
DEBUG - 2021-12-31 10:44:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:14:12 --> Total execution time: 0.0530
DEBUG - 2021-12-31 10:44:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:14:16 --> Total execution time: 0.0564
DEBUG - 2021-12-31 10:45:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:15:08 --> Total execution time: 0.0627
DEBUG - 2021-12-31 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:15:18 --> Total execution time: 0.0809
DEBUG - 2021-12-31 10:45:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:15:49 --> Total execution time: 0.0763
DEBUG - 2021-12-31 10:46:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:16:40 --> Total execution time: 0.0692
DEBUG - 2021-12-31 10:47:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:17:57 --> Total execution time: 0.0519
DEBUG - 2021-12-31 10:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:19:28 --> Total execution time: 0.0533
DEBUG - 2021-12-31 10:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:19:33 --> Total execution time: 0.0501
DEBUG - 2021-12-31 10:59:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:29:59 --> Total execution time: 0.0564
DEBUG - 2021-12-31 11:04:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:34:47 --> Total execution time: 0.0718
DEBUG - 2021-12-31 11:09:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:39:45 --> Total execution time: 0.0708
DEBUG - 2021-12-31 11:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:39:57 --> Total execution time: 0.1016
DEBUG - 2021-12-31 11:10:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:40:01 --> Total execution time: 0.1014
DEBUG - 2021-12-31 11:11:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:41:51 --> Total execution time: 0.0652
DEBUG - 2021-12-31 11:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:42:27 --> Total execution time: 0.0513
DEBUG - 2021-12-31 11:14:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:44:25 --> Total execution time: 0.0706
DEBUG - 2021-12-31 11:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:44:36 --> Total execution time: 0.0520
DEBUG - 2021-12-31 11:14:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 15:44:46 --> Total execution time: 0.0551
DEBUG - 2021-12-31 17:20:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-31 17:20:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\personal\jaal\application\core\DB_Controller.php 28
DEBUG - 2021-12-31 17:20:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 17:20:41 --> Total execution time: 0.0600
DEBUG - 2021-12-31 17:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 17:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 21:50:42 --> Total execution time: 0.0582
DEBUG - 2021-12-31 17:20:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 21:50:47 --> Total execution time: 0.0751
DEBUG - 2021-12-31 17:20:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 21:50:53 --> Total execution time: 0.0678
DEBUG - 2021-12-31 17:20:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 21:50:55 --> Total execution time: 0.0527
DEBUG - 2021-12-31 17:20:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 21:50:56 --> Total execution time: 0.0734
DEBUG - 2021-12-31 17:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 17:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 17:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-31 21:50:58 --> Total execution time: 0.0558
