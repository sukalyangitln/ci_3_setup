<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-25 08:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 08:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 08:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 08:33:20 --> Total execution time: 1.5665
DEBUG - 2022-11-25 08:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 08:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 08:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 08:33:22 --> Total execution time: 0.0470
DEBUG - 2022-11-25 08:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 08:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 08:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 08:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 08:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 08:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:03:24 --> Total execution time: 0.1168
DEBUG - 2022-11-25 08:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 08:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 08:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:03:38 --> Total execution time: 0.1189
DEBUG - 2022-11-25 09:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:44:05 --> Total execution time: 0.0541
DEBUG - 2022-11-25 09:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:14:11 --> No URI present. Default controller set.
DEBUG - 2022-11-25 09:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:44:11 --> Total execution time: 0.1291
DEBUG - 2022-11-25 09:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:44:28 --> Total execution time: 0.0582
DEBUG - 2022-11-25 09:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:44:33 --> Total execution time: 0.0616
DEBUG - 2022-11-25 09:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:45:48 --> Total execution time: 0.1174
DEBUG - 2022-11-25 09:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 09:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:45:56 --> Total execution time: 0.1483
DEBUG - 2022-11-25 09:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:46:01 --> Total execution time: 0.1072
DEBUG - 2022-11-25 09:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 13:46:13 --> Total execution time: 0.1042
DEBUG - 2022-11-25 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:04:58 --> Total execution time: 0.0779
DEBUG - 2022-11-25 09:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:05:06 --> Total execution time: 0.0595
DEBUG - 2022-11-25 09:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:35:10 --> No URI present. Default controller set.
DEBUG - 2022-11-25 09:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:05:10 --> Total execution time: 0.0501
DEBUG - 2022-11-25 09:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:05:19 --> Total execution time: 1.3702
DEBUG - 2022-11-25 09:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:35:25 --> No URI present. Default controller set.
DEBUG - 2022-11-25 09:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:05:25 --> Total execution time: 0.0581
DEBUG - 2022-11-25 09:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:36:50 --> No URI present. Default controller set.
DEBUG - 2022-11-25 09:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:06:50 --> Total execution time: 0.0465
DEBUG - 2022-11-25 09:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:06:55 --> Total execution time: 1.4658
DEBUG - 2022-11-25 09:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:37:04 --> No URI present. Default controller set.
DEBUG - 2022-11-25 09:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:07:04 --> Total execution time: 0.0453
DEBUG - 2022-11-25 09:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:17:12 --> Total execution time: 0.0940
DEBUG - 2022-11-25 09:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:17:56 --> Total execution time: 0.0658
DEBUG - 2022-11-25 09:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:20:15 --> Total execution time: 0.0711
DEBUG - 2022-11-25 09:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:20:47 --> Total execution time: 0.0452
DEBUG - 2022-11-25 09:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:20:55 --> Total execution time: 0.0585
DEBUG - 2022-11-25 09:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:21:01 --> Total execution time: 0.0640
DEBUG - 2022-11-25 09:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:21:10 --> Total execution time: 0.0599
DEBUG - 2022-11-25 09:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:21:38 --> Total execution time: 0.0683
DEBUG - 2022-11-25 09:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:21:39 --> Total execution time: 0.0666
DEBUG - 2022-11-25 09:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:26:22 --> Total execution time: 0.0621
DEBUG - 2022-11-25 09:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:26:43 --> Total execution time: 0.0561
DEBUG - 2022-11-25 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 09:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 09:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:27:02 --> Total execution time: 0.0487
DEBUG - 2022-11-25 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 10:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 10:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:33:32 --> Total execution time: 0.0549
DEBUG - 2022-11-25 10:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 10:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 10:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:35:58 --> Total execution time: 0.0478
DEBUG - 2022-11-25 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-25 10:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-25 10:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-25 14:41:24 --> Total execution time: 0.0659
