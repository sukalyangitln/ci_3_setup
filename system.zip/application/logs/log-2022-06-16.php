<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-16 00:05:15 --> Total execution time: 0.1244
DEBUG - 2022-06-16 00:07:51 --> Total execution time: 0.1269
DEBUG - 2022-06-16 00:09:08 --> Total execution time: 0.0429
DEBUG - 2022-06-16 00:09:59 --> Total execution time: 0.0304
DEBUG - 2022-06-16 00:12:44 --> Total execution time: 0.0816
DEBUG - 2022-06-16 00:19:25 --> Total execution time: 0.0870
DEBUG - 2022-06-16 00:20:54 --> Total execution time: 0.0321
DEBUG - 2022-06-16 00:20:56 --> Total execution time: 0.0627
DEBUG - 2022-06-16 00:20:58 --> Total execution time: 0.0387
DEBUG - 2022-06-16 00:24:01 --> Total execution time: 0.1064
DEBUG - 2022-06-16 00:24:04 --> Total execution time: 0.0376
DEBUG - 2022-06-16 00:24:06 --> Total execution time: 0.0408
DEBUG - 2022-06-16 00:24:36 --> Total execution time: 0.1177
DEBUG - 2022-06-16 00:26:49 --> Total execution time: 0.0879
DEBUG - 2022-06-16 00:27:03 --> Total execution time: 0.0405
DEBUG - 2022-06-16 00:27:03 --> Total execution time: 0.0401
DEBUG - 2022-06-16 00:27:26 --> Total execution time: 0.0506
DEBUG - 2022-06-16 00:27:26 --> Total execution time: 0.0621
DEBUG - 2022-06-16 00:27:26 --> Total execution time: 0.0527
DEBUG - 2022-06-16 00:27:26 --> Total execution time: 0.0621
DEBUG - 2022-06-16 00:28:15 --> Total execution time: 0.0377
DEBUG - 2022-06-16 00:30:02 --> Total execution time: 0.2691
DEBUG - 2022-06-16 00:33:55 --> Total execution time: 0.1134
DEBUG - 2022-06-16 00:38:12 --> Total execution time: 0.1023
DEBUG - 2022-06-16 00:42:47 --> Total execution time: 0.1905
DEBUG - 2022-06-16 00:43:06 --> Total execution time: 0.2146
DEBUG - 2022-06-16 00:43:19 --> Total execution time: 0.0405
DEBUG - 2022-06-16 00:43:40 --> Total execution time: 0.0430
DEBUG - 2022-06-16 00:47:30 --> Total execution time: 1.8792
DEBUG - 2022-06-16 00:49:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 00:49:30 --> Total execution time: 0.0543
DEBUG - 2022-06-16 00:49:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 00:49:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 00:49:36 --> Total execution time: 0.1746
DEBUG - 2022-06-16 00:55:12 --> Total execution time: 0.1546
DEBUG - 2022-06-16 01:02:35 --> Total execution time: 0.1571
DEBUG - 2022-06-16 01:08:19 --> Total execution time: 0.1670
DEBUG - 2022-06-16 01:08:44 --> Total execution time: 0.0606
DEBUG - 2022-06-16 01:08:56 --> Total execution time: 0.1186
DEBUG - 2022-06-16 01:09:04 --> Total execution time: 0.0609
DEBUG - 2022-06-16 01:09:10 --> Total execution time: 0.0898
DEBUG - 2022-06-16 01:22:34 --> Total execution time: 0.1720
DEBUG - 2022-06-16 01:30:03 --> Total execution time: 0.2782
DEBUG - 2022-06-16 01:32:58 --> Total execution time: 0.0968
DEBUG - 2022-06-16 01:37:39 --> Total execution time: 0.0526
DEBUG - 2022-06-16 01:48:40 --> Total execution time: 0.0511
DEBUG - 2022-06-16 01:48:53 --> Total execution time: 0.0773
DEBUG - 2022-06-16 01:48:57 --> Total execution time: 0.0619
DEBUG - 2022-06-16 01:48:59 --> Total execution time: 0.0607
DEBUG - 2022-06-16 01:49:10 --> Total execution time: 0.0415
DEBUG - 2022-06-16 01:50:18 --> Total execution time: 0.0423
DEBUG - 2022-06-16 01:50:20 --> Total execution time: 0.0730
DEBUG - 2022-06-16 01:50:32 --> Total execution time: 0.0427
DEBUG - 2022-06-16 01:52:58 --> Total execution time: 0.0482
DEBUG - 2022-06-16 01:53:00 --> Total execution time: 0.0527
DEBUG - 2022-06-16 01:53:09 --> Total execution time: 0.0486
DEBUG - 2022-06-16 01:53:59 --> Total execution time: 0.0928
DEBUG - 2022-06-16 01:54:03 --> Total execution time: 0.0440
DEBUG - 2022-06-16 01:54:07 --> Total execution time: 0.0464
DEBUG - 2022-06-16 01:54:21 --> Total execution time: 0.0371
DEBUG - 2022-06-16 01:54:53 --> Total execution time: 0.0470
DEBUG - 2022-06-16 01:55:00 --> Total execution time: 0.0504
DEBUG - 2022-06-16 01:55:23 --> Total execution time: 0.0358
DEBUG - 2022-06-16 01:55:24 --> Total execution time: 0.0480
DEBUG - 2022-06-16 01:55:31 --> Total execution time: 0.0444
DEBUG - 2022-06-16 01:55:41 --> Total execution time: 0.0469
DEBUG - 2022-06-16 01:55:46 --> Total execution time: 0.0601
DEBUG - 2022-06-16 01:55:52 --> Total execution time: 0.0430
DEBUG - 2022-06-16 01:55:57 --> Total execution time: 0.0449
DEBUG - 2022-06-16 01:56:25 --> Total execution time: 0.0428
DEBUG - 2022-06-16 01:56:30 --> Total execution time: 0.0442
DEBUG - 2022-06-16 01:56:33 --> Total execution time: 0.0694
DEBUG - 2022-06-16 01:56:38 --> Total execution time: 0.0376
DEBUG - 2022-06-16 01:56:46 --> Total execution time: 0.0425
DEBUG - 2022-06-16 01:56:48 --> Total execution time: 0.0479
DEBUG - 2022-06-16 01:56:50 --> Total execution time: 0.0356
DEBUG - 2022-06-16 01:56:52 --> Total execution time: 0.0459
DEBUG - 2022-06-16 01:56:59 --> Total execution time: 0.0368
DEBUG - 2022-06-16 01:57:56 --> Total execution time: 0.0270
DEBUG - 2022-06-16 01:57:57 --> Total execution time: 0.0468
DEBUG - 2022-06-16 02:13:02 --> Total execution time: 0.0558
DEBUG - 2022-06-16 02:13:09 --> Total execution time: 0.0543
DEBUG - 2022-06-16 02:13:52 --> Total execution time: 0.0664
DEBUG - 2022-06-16 02:14:02 --> Total execution time: 0.0520
DEBUG - 2022-06-16 02:14:16 --> Total execution time: 0.0449
DEBUG - 2022-06-16 02:15:13 --> Total execution time: 0.0497
DEBUG - 2022-06-16 02:15:54 --> Total execution time: 0.0499
DEBUG - 2022-06-16 02:16:12 --> Total execution time: 0.0413
DEBUG - 2022-06-16 02:16:24 --> Total execution time: 0.0427
DEBUG - 2022-06-16 02:16:26 --> Total execution time: 0.0981
DEBUG - 2022-06-16 02:16:29 --> Total execution time: 0.0618
DEBUG - 2022-06-16 02:16:34 --> Total execution time: 0.0458
DEBUG - 2022-06-16 02:16:42 --> Total execution time: 0.0429
DEBUG - 2022-06-16 02:16:44 --> Total execution time: 0.0671
DEBUG - 2022-06-16 02:16:47 --> Total execution time: 0.0557
DEBUG - 2022-06-16 02:16:55 --> Total execution time: 0.0621
DEBUG - 2022-06-16 02:16:58 --> Total execution time: 0.0817
DEBUG - 2022-06-16 02:16:59 --> Total execution time: 0.0363
DEBUG - 2022-06-16 02:17:17 --> Total execution time: 0.0442
DEBUG - 2022-06-16 02:17:20 --> Total execution time: 0.0520
DEBUG - 2022-06-16 02:17:24 --> Total execution time: 0.0958
DEBUG - 2022-06-16 02:17:27 --> Total execution time: 0.0453
DEBUG - 2022-06-16 02:17:35 --> Total execution time: 0.0525
DEBUG - 2022-06-16 02:17:42 --> Total execution time: 0.1380
DEBUG - 2022-06-16 02:17:51 --> Total execution time: 0.0369
DEBUG - 2022-06-16 02:17:58 --> Total execution time: 0.0611
DEBUG - 2022-06-16 02:18:02 --> Total execution time: 0.0943
DEBUG - 2022-06-16 02:18:38 --> Total execution time: 0.0710
DEBUG - 2022-06-16 02:18:39 --> Total execution time: 0.0454
DEBUG - 2022-06-16 02:18:45 --> Total execution time: 0.0397
DEBUG - 2022-06-16 02:19:11 --> Total execution time: 0.0897
DEBUG - 2022-06-16 02:19:13 --> Total execution time: 0.0436
DEBUG - 2022-06-16 02:19:16 --> Total execution time: 0.0421
DEBUG - 2022-06-16 02:19:24 --> Total execution time: 0.0425
DEBUG - 2022-06-16 02:19:26 --> Total execution time: 0.0447
DEBUG - 2022-06-16 02:20:05 --> Total execution time: 0.0389
DEBUG - 2022-06-16 02:20:47 --> Total execution time: 0.0660
DEBUG - 2022-06-16 02:20:49 --> Total execution time: 0.0596
DEBUG - 2022-06-16 02:20:55 --> Total execution time: 0.0492
DEBUG - 2022-06-16 02:21:02 --> Total execution time: 0.0911
DEBUG - 2022-06-16 02:21:53 --> Total execution time: 0.0429
DEBUG - 2022-06-16 02:22:05 --> Total execution time: 0.1325
DEBUG - 2022-06-16 02:23:51 --> Total execution time: 0.1000
DEBUG - 2022-06-16 02:26:53 --> Total execution time: 0.0835
DEBUG - 2022-06-16 02:26:54 --> Total execution time: 0.0530
DEBUG - 2022-06-16 02:26:56 --> Total execution time: 0.0364
DEBUG - 2022-06-16 02:30:03 --> Total execution time: 0.1779
DEBUG - 2022-06-16 02:53:45 --> Total execution time: 0.2052
DEBUG - 2022-06-16 02:54:06 --> Total execution time: 0.0589
DEBUG - 2022-06-16 02:54:14 --> Total execution time: 0.0418
DEBUG - 2022-06-16 02:54:22 --> Total execution time: 0.0486
DEBUG - 2022-06-16 02:54:41 --> Total execution time: 0.0644
DEBUG - 2022-06-16 02:54:55 --> Total execution time: 0.1201
DEBUG - 2022-06-16 02:54:59 --> Total execution time: 0.0833
DEBUG - 2022-06-16 02:55:06 --> Total execution time: 0.0516
DEBUG - 2022-06-16 02:55:26 --> Total execution time: 0.0993
DEBUG - 2022-06-16 02:55:31 --> Total execution time: 0.0523
DEBUG - 2022-06-16 03:00:34 --> Total execution time: 0.0817
DEBUG - 2022-06-16 03:00:42 --> Total execution time: 0.0398
DEBUG - 2022-06-16 03:00:51 --> Total execution time: 0.0382
DEBUG - 2022-06-16 03:01:07 --> Total execution time: 0.0521
DEBUG - 2022-06-16 03:01:08 --> Total execution time: 0.0858
DEBUG - 2022-06-16 03:01:15 --> Total execution time: 0.0442
DEBUG - 2022-06-16 03:01:38 --> Total execution time: 0.0526
DEBUG - 2022-06-16 03:01:41 --> Total execution time: 0.0743
DEBUG - 2022-06-16 03:01:53 --> Total execution time: 0.0385
DEBUG - 2022-06-16 03:06:56 --> Total execution time: 0.0785
DEBUG - 2022-06-16 03:07:03 --> Total execution time: 0.0335
DEBUG - 2022-06-16 03:07:06 --> Total execution time: 0.1048
DEBUG - 2022-06-16 03:07:13 --> Total execution time: 0.0515
DEBUG - 2022-06-16 03:08:02 --> Total execution time: 0.0488
DEBUG - 2022-06-16 03:08:09 --> Total execution time: 0.0437
DEBUG - 2022-06-16 03:08:18 --> Total execution time: 0.0397
DEBUG - 2022-06-16 03:15:27 --> Total execution time: 0.0945
DEBUG - 2022-06-16 03:20:33 --> Total execution time: 0.0986
DEBUG - 2022-06-16 03:20:54 --> Total execution time: 0.0468
DEBUG - 2022-06-16 03:21:03 --> Total execution time: 0.0454
DEBUG - 2022-06-16 03:21:20 --> Total execution time: 0.0385
DEBUG - 2022-06-16 03:26:16 --> Total execution time: 0.1029
DEBUG - 2022-06-16 03:28:41 --> Total execution time: 0.0499
DEBUG - 2022-06-16 03:30:03 --> Total execution time: 0.0839
DEBUG - 2022-06-16 03:31:43 --> Total execution time: 0.0423
DEBUG - 2022-06-16 03:35:01 --> Total execution time: 0.1507
DEBUG - 2022-06-16 03:35:07 --> Total execution time: 0.0799
DEBUG - 2022-06-16 03:35:13 --> Total execution time: 0.0686
DEBUG - 2022-06-16 03:35:22 --> Total execution time: 0.2516
DEBUG - 2022-06-16 03:35:25 --> Total execution time: 0.4728
DEBUG - 2022-06-16 03:35:30 --> Total execution time: 0.0421
DEBUG - 2022-06-16 03:39:37 --> Total execution time: 0.0881
DEBUG - 2022-06-16 03:44:16 --> Total execution time: 0.1538
DEBUG - 2022-06-16 03:44:58 --> Total execution time: 0.0944
DEBUG - 2022-06-16 03:45:09 --> Total execution time: 0.0379
DEBUG - 2022-06-16 04:30:03 --> Total execution time: 0.3445
DEBUG - 2022-06-16 05:07:00 --> Total execution time: 0.1529
DEBUG - 2022-06-16 05:07:02 --> Total execution time: 0.0380
DEBUG - 2022-06-16 05:07:03 --> Total execution time: 0.0394
DEBUG - 2022-06-16 05:30:03 --> Total execution time: 0.3972
DEBUG - 2022-06-16 05:36:52 --> Total execution time: 0.1137
DEBUG - 2022-06-16 05:36:53 --> Total execution time: 0.0365
DEBUG - 2022-06-16 05:37:02 --> Total execution time: 0.0303
DEBUG - 2022-06-16 05:37:12 --> Total execution time: 0.0790
DEBUG - 2022-06-16 05:37:17 --> Total execution time: 0.0792
DEBUG - 2022-06-16 05:37:21 --> Total execution time: 0.0435
DEBUG - 2022-06-16 05:37:23 --> Total execution time: 0.0539
DEBUG - 2022-06-16 05:37:27 --> Total execution time: 0.0376
DEBUG - 2022-06-16 05:44:26 --> Total execution time: 0.0389
DEBUG - 2022-06-16 05:44:34 --> Total execution time: 0.0429
DEBUG - 2022-06-16 05:45:37 --> Total execution time: 0.0347
DEBUG - 2022-06-16 05:49:28 --> Total execution time: 0.0877
DEBUG - 2022-06-16 05:52:36 --> Total execution time: 0.0690
DEBUG - 2022-06-16 05:52:40 --> Total execution time: 0.0548
DEBUG - 2022-06-16 05:52:42 --> Total execution time: 0.0453
DEBUG - 2022-06-16 05:52:49 --> Total execution time: 0.0388
DEBUG - 2022-06-16 06:01:31 --> Total execution time: 0.1118
DEBUG - 2022-06-16 06:02:56 --> Total execution time: 0.0471
DEBUG - 2022-06-16 06:03:07 --> Total execution time: 0.0451
DEBUG - 2022-06-16 06:12:52 --> Total execution time: 0.1686
DEBUG - 2022-06-16 06:12:56 --> Total execution time: 0.0410
DEBUG - 2022-06-16 06:13:15 --> Total execution time: 0.0691
DEBUG - 2022-06-16 06:14:23 --> Total execution time: 0.0507
DEBUG - 2022-06-16 06:15:42 --> Total execution time: 0.0314
DEBUG - 2022-06-16 06:30:03 --> Total execution time: 0.2057
DEBUG - 2022-06-16 06:51:18 --> Total execution time: 0.1554
DEBUG - 2022-06-16 06:51:18 --> Total execution time: 0.0237
DEBUG - 2022-06-16 06:51:21 --> Total execution time: 0.0271
DEBUG - 2022-06-16 06:51:36 --> Total execution time: 0.0996
DEBUG - 2022-06-16 06:51:44 --> Total execution time: 0.0697
DEBUG - 2022-06-16 06:52:29 --> Total execution time: 0.0986
DEBUG - 2022-06-16 06:53:42 --> Total execution time: 0.0566
DEBUG - 2022-06-16 06:53:45 --> Total execution time: 0.2111
DEBUG - 2022-06-16 06:53:58 --> Total execution time: 0.0305
DEBUG - 2022-06-16 06:54:26 --> Total execution time: 0.0419
DEBUG - 2022-06-16 07:04:24 --> Total execution time: 0.1012
DEBUG - 2022-06-16 07:06:12 --> Total execution time: 0.1201
DEBUG - 2022-06-16 07:13:42 --> Total execution time: 0.0384
DEBUG - 2022-06-16 07:13:56 --> Total execution time: 0.0402
DEBUG - 2022-06-16 07:14:06 --> Total execution time: 0.0458
DEBUG - 2022-06-16 07:14:22 --> Total execution time: 0.0376
DEBUG - 2022-06-16 07:14:30 --> Total execution time: 0.0626
DEBUG - 2022-06-16 07:14:38 --> Total execution time: 0.0369
DEBUG - 2022-06-16 07:16:01 --> Total execution time: 0.0341
DEBUG - 2022-06-16 07:16:05 --> Total execution time: 0.0312
DEBUG - 2022-06-16 07:16:28 --> Total execution time: 0.0291
DEBUG - 2022-06-16 07:16:28 --> Total execution time: 0.0286
DEBUG - 2022-06-16 07:19:32 --> Total execution time: 0.0885
DEBUG - 2022-06-16 07:19:48 --> Total execution time: 0.0399
DEBUG - 2022-06-16 07:20:02 --> Total execution time: 0.0559
DEBUG - 2022-06-16 07:20:07 --> Total execution time: 0.0393
DEBUG - 2022-06-16 07:28:12 --> Total execution time: 0.0996
DEBUG - 2022-06-16 07:28:13 --> Total execution time: 0.0334
DEBUG - 2022-06-16 07:28:59 --> Total execution time: 0.0279
DEBUG - 2022-06-16 07:30:04 --> Total execution time: 0.0496
DEBUG - 2022-06-16 07:30:12 --> Total execution time: 0.0303
DEBUG - 2022-06-16 07:30:15 --> Total execution time: 0.0400
DEBUG - 2022-06-16 07:30:24 --> Total execution time: 0.0381
DEBUG - 2022-06-16 07:30:34 --> Total execution time: 0.0382
DEBUG - 2022-06-16 07:30:49 --> Total execution time: 0.0429
DEBUG - 2022-06-16 07:31:12 --> Total execution time: 0.0521
DEBUG - 2022-06-16 07:31:20 --> Total execution time: 0.0428
DEBUG - 2022-06-16 07:31:32 --> Total execution time: 0.0429
DEBUG - 2022-06-16 07:31:42 --> Total execution time: 0.0448
DEBUG - 2022-06-16 07:31:46 --> Total execution time: 0.0369
DEBUG - 2022-06-16 07:31:59 --> Total execution time: 0.0394
DEBUG - 2022-06-16 07:32:33 --> Total execution time: 0.0732
DEBUG - 2022-06-16 07:32:40 --> Total execution time: 0.0831
DEBUG - 2022-06-16 07:32:43 --> Total execution time: 0.0528
DEBUG - 2022-06-16 07:35:23 --> Total execution time: 0.0900
DEBUG - 2022-06-16 07:35:41 --> Total execution time: 0.0412
DEBUG - 2022-06-16 07:36:38 --> Total execution time: 0.0394
DEBUG - 2022-06-16 07:37:04 --> Total execution time: 0.0494
DEBUG - 2022-06-16 07:39:01 --> Total execution time: 2.0241
DEBUG - 2022-06-16 07:42:44 --> Total execution time: 0.0574
DEBUG - 2022-06-16 07:43:16 --> Total execution time: 0.0417
DEBUG - 2022-06-16 07:43:23 --> Total execution time: 0.0378
DEBUG - 2022-06-16 07:43:23 --> Total execution time: 0.0562
DEBUG - 2022-06-16 07:43:29 --> Total execution time: 0.0599
DEBUG - 2022-06-16 07:43:58 --> Total execution time: 0.0655
DEBUG - 2022-06-16 07:44:06 --> Total execution time: 0.0438
DEBUG - 2022-06-16 07:44:16 --> Total execution time: 0.0567
DEBUG - 2022-06-16 07:44:21 --> Total execution time: 0.0513
DEBUG - 2022-06-16 07:44:24 --> Total execution time: 0.0578
DEBUG - 2022-06-16 07:44:24 --> Total execution time: 0.0433
DEBUG - 2022-06-16 07:44:25 --> Total execution time: 0.0621
DEBUG - 2022-06-16 07:44:25 --> Total execution time: 0.0498
DEBUG - 2022-06-16 07:44:27 --> Total execution time: 0.0640
DEBUG - 2022-06-16 07:44:44 --> Total execution time: 0.0403
DEBUG - 2022-06-16 07:45:00 --> Total execution time: 0.0409
DEBUG - 2022-06-16 07:45:29 --> Total execution time: 0.0417
DEBUG - 2022-06-16 07:46:00 --> Total execution time: 0.0288
DEBUG - 2022-06-16 07:46:38 --> Total execution time: 0.0287
DEBUG - 2022-06-16 07:51:21 --> Total execution time: 0.1037
DEBUG - 2022-06-16 07:52:04 --> Total execution time: 0.0298
DEBUG - 2022-06-16 07:52:05 --> Total execution time: 0.0386
DEBUG - 2022-06-16 07:52:07 --> Total execution time: 0.0558
DEBUG - 2022-06-16 07:56:04 --> Total execution time: 0.0397
DEBUG - 2022-06-16 07:56:15 --> Total execution time: 0.0389
DEBUG - 2022-06-16 07:56:24 --> Total execution time: 0.0642
DEBUG - 2022-06-16 07:56:27 --> Total execution time: 0.0720
DEBUG - 2022-06-16 07:56:50 --> Total execution time: 0.1097
DEBUG - 2022-06-16 07:57:03 --> Total execution time: 0.0329
DEBUG - 2022-06-16 07:57:10 --> Total execution time: 0.0524
DEBUG - 2022-06-16 08:00:21 --> Total execution time: 0.0936
DEBUG - 2022-06-16 08:01:56 --> Total execution time: 0.0307
DEBUG - 2022-06-16 08:06:14 --> Total execution time: 0.0435
DEBUG - 2022-06-16 08:10:07 --> Total execution time: 0.0389
DEBUG - 2022-06-16 08:10:26 --> Total execution time: 0.0381
DEBUG - 2022-06-16 08:11:14 --> Total execution time: 0.0512
DEBUG - 2022-06-16 08:11:21 --> Total execution time: 0.0606
DEBUG - 2022-06-16 08:14:43 --> Total execution time: 0.0394
DEBUG - 2022-06-16 08:15:40 --> Total execution time: 0.0855
DEBUG - 2022-06-16 08:15:43 --> Total execution time: 0.0399
DEBUG - 2022-06-16 08:15:48 --> Total execution time: 0.0486
DEBUG - 2022-06-16 08:15:53 --> Total execution time: 0.0861
DEBUG - 2022-06-16 08:16:09 --> Total execution time: 0.0412
DEBUG - 2022-06-16 08:16:23 --> Total execution time: 0.0518
DEBUG - 2022-06-16 08:18:44 --> Total execution time: 0.0368
DEBUG - 2022-06-16 08:19:05 --> Total execution time: 0.0424
DEBUG - 2022-06-16 08:19:26 --> Total execution time: 0.0367
DEBUG - 2022-06-16 08:19:43 --> Total execution time: 0.0369
DEBUG - 2022-06-16 08:20:05 --> Total execution time: 0.0495
DEBUG - 2022-06-16 08:20:08 --> Total execution time: 1.8910
DEBUG - 2022-06-16 08:20:09 --> Total execution time: 0.0404
DEBUG - 2022-06-16 08:20:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 08:20:10 --> Total execution time: 0.0373
DEBUG - 2022-06-16 08:20:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 08:20:47 --> Total execution time: 0.0475
DEBUG - 2022-06-16 08:20:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 08:20:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 08:20:49 --> Total execution time: 0.1763
DEBUG - 2022-06-16 08:20:55 --> Total execution time: 0.0350
DEBUG - 2022-06-16 08:20:56 --> Total execution time: 0.0301
DEBUG - 2022-06-16 08:20:57 --> Total execution time: 0.0340
DEBUG - 2022-06-16 08:21:08 --> Total execution time: 0.0477
DEBUG - 2022-06-16 08:21:16 --> Total execution time: 0.0511
DEBUG - 2022-06-16 08:21:26 --> Total execution time: 0.0379
DEBUG - 2022-06-16 08:21:34 --> Total execution time: 0.0561
DEBUG - 2022-06-16 08:21:39 --> Total execution time: 0.0420
DEBUG - 2022-06-16 08:21:53 --> Total execution time: 0.0451
DEBUG - 2022-06-16 08:21:56 --> Total execution time: 0.0475
DEBUG - 2022-06-16 08:22:07 --> Total execution time: 0.0496
DEBUG - 2022-06-16 08:22:15 --> Total execution time: 0.0429
DEBUG - 2022-06-16 08:22:17 --> Total execution time: 0.0959
DEBUG - 2022-06-16 08:22:18 --> Total execution time: 0.0533
DEBUG - 2022-06-16 08:22:26 --> Total execution time: 0.0391
DEBUG - 2022-06-16 08:22:37 --> Total execution time: 0.0373
DEBUG - 2022-06-16 08:22:52 --> Total execution time: 0.0439
DEBUG - 2022-06-16 08:23:13 --> Total execution time: 0.0633
DEBUG - 2022-06-16 08:23:17 --> Total execution time: 0.0402
DEBUG - 2022-06-16 08:23:26 --> Total execution time: 0.0689
DEBUG - 2022-06-16 08:23:31 --> Total execution time: 0.0794
DEBUG - 2022-06-16 08:23:40 --> Total execution time: 0.0533
DEBUG - 2022-06-16 08:23:51 --> Total execution time: 0.0409
DEBUG - 2022-06-16 08:23:56 --> Total execution time: 0.0380
DEBUG - 2022-06-16 08:24:02 --> Total execution time: 0.0538
DEBUG - 2022-06-16 08:24:05 --> Total execution time: 0.0284
DEBUG - 2022-06-16 08:24:16 --> Total execution time: 0.0376
DEBUG - 2022-06-16 08:24:18 --> Total execution time: 0.0308
DEBUG - 2022-06-16 08:24:27 --> Total execution time: 0.0422
DEBUG - 2022-06-16 08:24:35 --> Total execution time: 0.0454
DEBUG - 2022-06-16 08:24:57 --> Total execution time: 0.0309
DEBUG - 2022-06-16 08:25:54 --> Total execution time: 0.0357
DEBUG - 2022-06-16 08:26:44 --> Total execution time: 0.0313
DEBUG - 2022-06-16 08:26:45 --> Total execution time: 0.0357
DEBUG - 2022-06-16 08:27:08 --> Total execution time: 0.0402
DEBUG - 2022-06-16 08:27:14 --> Total execution time: 1.4528
DEBUG - 2022-06-16 08:28:09 --> Total execution time: 0.0398
DEBUG - 2022-06-16 08:28:36 --> Total execution time: 0.0389
DEBUG - 2022-06-16 08:28:45 --> Total execution time: 0.0462
DEBUG - 2022-06-16 08:29:13 --> Total execution time: 0.0289
DEBUG - 2022-06-16 08:29:35 --> Total execution time: 0.0518
DEBUG - 2022-06-16 08:29:43 --> Total execution time: 0.0881
DEBUG - 2022-06-16 08:29:45 --> Total execution time: 0.0406
DEBUG - 2022-06-16 08:29:49 --> Total execution time: 0.0403
DEBUG - 2022-06-16 08:29:55 --> Total execution time: 1.4507
DEBUG - 2022-06-16 08:30:02 --> Total execution time: 0.0465
DEBUG - 2022-06-16 08:30:13 --> Total execution time: 0.0392
DEBUG - 2022-06-16 08:31:31 --> Total execution time: 0.0602
DEBUG - 2022-06-16 08:31:35 --> Total execution time: 0.0634
DEBUG - 2022-06-16 08:31:39 --> Total execution time: 0.0419
DEBUG - 2022-06-16 08:31:44 --> Total execution time: 0.0431
DEBUG - 2022-06-16 08:31:50 --> Total execution time: 0.0981
DEBUG - 2022-06-16 08:31:57 --> Total execution time: 0.0620
DEBUG - 2022-06-16 08:32:02 --> Total execution time: 0.0914
DEBUG - 2022-06-16 08:32:03 --> Total execution time: 0.0387
DEBUG - 2022-06-16 08:32:07 --> Total execution time: 0.0535
DEBUG - 2022-06-16 08:32:08 --> Total execution time: 0.0412
DEBUG - 2022-06-16 08:32:16 --> Total execution time: 0.0372
DEBUG - 2022-06-16 08:32:16 --> Total execution time: 0.0848
DEBUG - 2022-06-16 08:32:19 --> Total execution time: 0.0507
DEBUG - 2022-06-16 08:32:20 --> Total execution time: 0.0769
DEBUG - 2022-06-16 08:32:28 --> Total execution time: 0.1325
DEBUG - 2022-06-16 08:32:33 --> Total execution time: 0.0432
DEBUG - 2022-06-16 08:32:36 --> Total execution time: 0.0517
DEBUG - 2022-06-16 08:32:40 --> Total execution time: 0.0484
DEBUG - 2022-06-16 08:32:50 --> Total execution time: 0.0387
DEBUG - 2022-06-16 08:32:52 --> Total execution time: 0.0322
DEBUG - 2022-06-16 08:32:55 --> Total execution time: 0.0346
DEBUG - 2022-06-16 08:33:00 --> Total execution time: 0.0356
DEBUG - 2022-06-16 08:33:53 --> Total execution time: 0.1099
DEBUG - 2022-06-16 08:34:00 --> Total execution time: 0.0459
DEBUG - 2022-06-16 08:34:17 --> Total execution time: 0.0306
DEBUG - 2022-06-16 08:34:35 --> Total execution time: 0.0399
DEBUG - 2022-06-16 08:34:36 --> Total execution time: 0.0560
DEBUG - 2022-06-16 08:35:45 --> Total execution time: 0.0447
DEBUG - 2022-06-16 08:36:01 --> Total execution time: 0.0476
DEBUG - 2022-06-16 08:36:04 --> Total execution time: 0.0462
DEBUG - 2022-06-16 08:36:11 --> Total execution time: 0.0351
DEBUG - 2022-06-16 08:36:13 --> Total execution time: 0.0574
DEBUG - 2022-06-16 08:36:34 --> Total execution time: 0.0294
DEBUG - 2022-06-16 08:36:42 --> Total execution time: 0.0384
DEBUG - 2022-06-16 08:38:03 --> Total execution time: 0.0440
DEBUG - 2022-06-16 08:38:38 --> Total execution time: 0.0936
DEBUG - 2022-06-16 08:38:46 --> Total execution time: 0.0488
DEBUG - 2022-06-16 08:39:15 --> Total execution time: 0.0492
DEBUG - 2022-06-16 08:39:19 --> Total execution time: 0.0717
DEBUG - 2022-06-16 08:39:23 --> Total execution time: 0.0562
DEBUG - 2022-06-16 08:41:03 --> Total execution time: 0.0427
DEBUG - 2022-06-16 08:41:20 --> Total execution time: 0.1093
DEBUG - 2022-06-16 08:41:44 --> Total execution time: 0.0314
DEBUG - 2022-06-16 08:49:43 --> Total execution time: 0.0819
DEBUG - 2022-06-16 08:49:57 --> Total execution time: 0.0444
DEBUG - 2022-06-16 08:50:27 --> Total execution time: 0.0436
DEBUG - 2022-06-16 08:50:33 --> Total execution time: 0.0810
DEBUG - 2022-06-16 08:50:49 --> Total execution time: 0.0446
DEBUG - 2022-06-16 08:51:58 --> Total execution time: 0.1052
DEBUG - 2022-06-16 08:52:07 --> Total execution time: 0.0474
DEBUG - 2022-06-16 08:52:11 --> Total execution time: 0.0389
DEBUG - 2022-06-16 08:52:22 --> Total execution time: 0.0826
DEBUG - 2022-06-16 08:52:34 --> Total execution time: 0.0722
DEBUG - 2022-06-16 08:52:42 --> Total execution time: 0.0591
DEBUG - 2022-06-16 08:53:05 --> Total execution time: 0.0462
DEBUG - 2022-06-16 08:53:08 --> Total execution time: 0.0471
DEBUG - 2022-06-16 08:53:33 --> Total execution time: 0.0583
DEBUG - 2022-06-16 08:53:35 --> Total execution time: 0.0503
DEBUG - 2022-06-16 08:53:42 --> Total execution time: 0.0753
DEBUG - 2022-06-16 08:53:57 --> Total execution time: 0.0407
DEBUG - 2022-06-16 08:54:00 --> Total execution time: 0.0331
DEBUG - 2022-06-16 08:54:03 --> Total execution time: 0.0540
DEBUG - 2022-06-16 08:54:08 --> Total execution time: 0.0851
DEBUG - 2022-06-16 08:54:54 --> Total execution time: 0.0441
DEBUG - 2022-06-16 08:54:58 --> Total execution time: 0.0463
DEBUG - 2022-06-16 08:55:01 --> Total execution time: 0.0895
DEBUG - 2022-06-16 08:55:23 --> Total execution time: 0.0409
DEBUG - 2022-06-16 08:55:39 --> Total execution time: 0.0437
DEBUG - 2022-06-16 08:55:44 --> Total execution time: 0.0438
DEBUG - 2022-06-16 08:55:55 --> Total execution time: 0.0427
DEBUG - 2022-06-16 08:55:56 --> Total execution time: 0.1021
DEBUG - 2022-06-16 08:56:03 --> Total execution time: 0.0790
DEBUG - 2022-06-16 08:56:07 --> Total execution time: 0.0555
DEBUG - 2022-06-16 08:56:09 --> Total execution time: 0.0422
DEBUG - 2022-06-16 08:56:14 --> Total execution time: 0.0807
DEBUG - 2022-06-16 08:56:16 --> Total execution time: 0.0429
DEBUG - 2022-06-16 08:56:18 --> Total execution time: 0.0428
DEBUG - 2022-06-16 08:56:20 --> Total execution time: 0.0380
DEBUG - 2022-06-16 08:56:29 --> Total execution time: 0.0431
DEBUG - 2022-06-16 08:56:31 --> Total execution time: 0.0446
DEBUG - 2022-06-16 08:56:36 --> Total execution time: 0.0513
DEBUG - 2022-06-16 08:56:55 --> Total execution time: 0.0306
DEBUG - 2022-06-16 08:56:55 --> Total execution time: 0.0409
DEBUG - 2022-06-16 08:56:58 --> Total execution time: 0.0572
DEBUG - 2022-06-16 08:56:59 --> Total execution time: 0.0465
DEBUG - 2022-06-16 08:57:00 --> Total execution time: 0.0416
DEBUG - 2022-06-16 08:57:02 --> Total execution time: 0.0600
DEBUG - 2022-06-16 08:57:12 --> Total execution time: 0.0621
DEBUG - 2022-06-16 08:57:25 --> Total execution time: 0.0289
DEBUG - 2022-06-16 08:57:43 --> Total execution time: 0.0417
DEBUG - 2022-06-16 08:57:46 --> Total execution time: 0.0363
DEBUG - 2022-06-16 08:57:47 --> Total execution time: 0.0375
DEBUG - 2022-06-16 08:58:02 --> Total execution time: 0.0400
DEBUG - 2022-06-16 08:58:16 --> Total execution time: 0.0304
DEBUG - 2022-06-16 08:58:27 --> Total execution time: 0.0500
DEBUG - 2022-06-16 08:59:44 --> Total execution time: 1.9651
DEBUG - 2022-06-16 09:00:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 09:00:57 --> Total execution time: 0.1179
DEBUG - 2022-06-16 09:00:57 --> Total execution time: 0.1301
DEBUG - 2022-06-16 09:00:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 09:00:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 09:00:59 --> Total execution time: 0.2766
DEBUG - 2022-06-16 09:01:19 --> Total execution time: 0.0420
DEBUG - 2022-06-16 09:01:20 --> Total execution time: 0.0389
DEBUG - 2022-06-16 09:01:25 --> Total execution time: 0.0661
DEBUG - 2022-06-16 09:01:26 --> Total execution time: 0.0400
DEBUG - 2022-06-16 09:01:41 --> Total execution time: 1.5137
DEBUG - 2022-06-16 09:01:43 --> Total execution time: 1.8677
DEBUG - 2022-06-16 09:01:51 --> Total execution time: 0.0502
DEBUG - 2022-06-16 09:03:04 --> Total execution time: 0.0415
DEBUG - 2022-06-16 09:03:13 --> Total execution time: 0.0553
DEBUG - 2022-06-16 09:03:14 --> Total execution time: 0.0516
DEBUG - 2022-06-16 09:03:26 --> Total execution time: 0.0444
DEBUG - 2022-06-16 09:03:33 --> Total execution time: 0.0407
DEBUG - 2022-06-16 09:03:33 --> Total execution time: 0.0542
DEBUG - 2022-06-16 09:03:38 --> Total execution time: 0.0557
DEBUG - 2022-06-16 09:03:45 --> Total execution time: 0.0387
DEBUG - 2022-06-16 09:03:52 --> Total execution time: 0.0806
DEBUG - 2022-06-16 09:04:53 --> Total execution time: 0.0300
DEBUG - 2022-06-16 09:05:03 --> Total execution time: 0.0356
DEBUG - 2022-06-16 09:06:06 --> Total execution time: 0.0445
DEBUG - 2022-06-16 09:06:14 --> Total execution time: 0.0434
DEBUG - 2022-06-16 09:06:18 --> Total execution time: 0.0437
DEBUG - 2022-06-16 09:06:22 --> Total execution time: 0.0680
DEBUG - 2022-06-16 09:06:32 --> Total execution time: 0.0364
DEBUG - 2022-06-16 09:06:36 --> Total execution time: 0.0387
DEBUG - 2022-06-16 09:08:55 --> Total execution time: 0.1203
DEBUG - 2022-06-16 09:08:59 --> Total execution time: 0.0431
DEBUG - 2022-06-16 09:09:04 --> Total execution time: 0.0549
DEBUG - 2022-06-16 09:09:11 --> Total execution time: 0.0459
DEBUG - 2022-06-16 09:09:28 --> Total execution time: 0.0425
DEBUG - 2022-06-16 09:11:45 --> Total execution time: 0.0395
DEBUG - 2022-06-16 09:11:59 --> Total execution time: 0.0489
DEBUG - 2022-06-16 09:12:01 --> Total execution time: 0.0920
DEBUG - 2022-06-16 09:14:11 --> Total execution time: 0.1117
DEBUG - 2022-06-16 09:14:22 --> Total execution time: 0.0800
DEBUG - 2022-06-16 09:14:54 --> Total execution time: 0.0546
DEBUG - 2022-06-16 09:16:11 --> Total execution time: 0.0474
DEBUG - 2022-06-16 09:16:14 --> Total execution time: 0.0564
DEBUG - 2022-06-16 09:16:18 --> Total execution time: 0.0593
DEBUG - 2022-06-16 09:16:20 --> Total execution time: 0.0461
DEBUG - 2022-06-16 09:16:23 --> Total execution time: 0.0342
DEBUG - 2022-06-16 09:18:33 --> Total execution time: 0.0730
DEBUG - 2022-06-16 09:18:33 --> Total execution time: 0.0302
DEBUG - 2022-06-16 09:21:15 --> Total execution time: 0.0349
DEBUG - 2022-06-16 09:21:22 --> Total execution time: 0.0894
DEBUG - 2022-06-16 09:21:38 --> Total execution time: 0.0909
DEBUG - 2022-06-16 09:21:43 --> Total execution time: 0.1154
DEBUG - 2022-06-16 09:23:47 --> Total execution time: 0.0811
DEBUG - 2022-06-16 09:28:09 --> Total execution time: 0.0697
DEBUG - 2022-06-16 09:29:32 --> Total execution time: 0.0377
DEBUG - 2022-06-16 09:30:02 --> Total execution time: 0.1011
DEBUG - 2022-06-16 09:30:27 --> Total execution time: 0.0460
DEBUG - 2022-06-16 09:31:39 --> Total execution time: 0.0705
DEBUG - 2022-06-16 09:31:57 --> Total execution time: 0.0298
DEBUG - 2022-06-16 09:32:41 --> Total execution time: 0.0803
DEBUG - 2022-06-16 09:33:14 --> Total execution time: 0.0504
DEBUG - 2022-06-16 09:33:46 --> Total execution time: 0.0394
DEBUG - 2022-06-16 09:33:53 --> Total execution time: 0.0423
DEBUG - 2022-06-16 09:33:53 --> Total execution time: 0.0319
DEBUG - 2022-06-16 09:33:55 --> Total execution time: 0.1051
DEBUG - 2022-06-16 09:34:08 --> Total execution time: 0.0902
DEBUG - 2022-06-16 09:34:13 --> Total execution time: 0.0856
DEBUG - 2022-06-16 09:34:19 --> Total execution time: 0.0581
DEBUG - 2022-06-16 09:34:41 --> Total execution time: 0.0469
DEBUG - 2022-06-16 09:34:42 --> Total execution time: 0.0616
DEBUG - 2022-06-16 09:34:43 --> Total execution time: 0.0729
DEBUG - 2022-06-16 09:34:44 --> Total execution time: 0.0434
DEBUG - 2022-06-16 09:34:44 --> Total execution time: 0.0550
DEBUG - 2022-06-16 09:34:45 --> Total execution time: 0.0508
DEBUG - 2022-06-16 09:34:46 --> Total execution time: 0.0435
DEBUG - 2022-06-16 09:34:46 --> Total execution time: 0.0470
DEBUG - 2022-06-16 09:35:07 --> Total execution time: 0.0860
DEBUG - 2022-06-16 09:35:11 --> Total execution time: 0.0413
DEBUG - 2022-06-16 09:35:47 --> Total execution time: 0.0320
DEBUG - 2022-06-16 09:39:27 --> Total execution time: 0.1533
DEBUG - 2022-06-16 09:39:30 --> Total execution time: 0.0518
DEBUG - 2022-06-16 09:39:37 --> Total execution time: 0.0384
DEBUG - 2022-06-16 09:39:45 --> Total execution time: 0.0479
DEBUG - 2022-06-16 09:39:54 --> Total execution time: 0.0722
DEBUG - 2022-06-16 09:40:12 --> Total execution time: 0.0927
DEBUG - 2022-06-16 09:41:16 --> Total execution time: 0.0455
DEBUG - 2022-06-16 09:41:20 --> Total execution time: 0.0571
DEBUG - 2022-06-16 09:41:34 --> Total execution time: 0.0615
DEBUG - 2022-06-16 09:42:37 --> Total execution time: 0.0563
DEBUG - 2022-06-16 09:42:40 --> Total execution time: 0.0470
DEBUG - 2022-06-16 09:42:51 --> Total execution time: 0.0450
DEBUG - 2022-06-16 09:43:02 --> Total execution time: 0.0877
DEBUG - 2022-06-16 09:43:42 --> Total execution time: 0.0401
DEBUG - 2022-06-16 09:43:45 --> Total execution time: 0.0456
DEBUG - 2022-06-16 09:43:51 --> Total execution time: 0.0476
DEBUG - 2022-06-16 09:43:54 --> Total execution time: 0.0448
DEBUG - 2022-06-16 09:44:10 --> Total execution time: 0.0535
DEBUG - 2022-06-16 09:44:41 --> Total execution time: 0.0848
DEBUG - 2022-06-16 09:44:42 --> Total execution time: 0.0439
DEBUG - 2022-06-16 09:45:02 --> Total execution time: 0.1686
DEBUG - 2022-06-16 09:46:49 --> Total execution time: 0.0490
DEBUG - 2022-06-16 09:46:51 --> Total execution time: 0.2207
DEBUG - 2022-06-16 09:46:57 --> Total execution time: 0.0813
DEBUG - 2022-06-16 09:47:02 --> Total execution time: 0.0626
DEBUG - 2022-06-16 09:47:09 --> Total execution time: 0.0634
DEBUG - 2022-06-16 09:47:25 --> Total execution time: 0.1468
DEBUG - 2022-06-16 09:47:28 --> Total execution time: 0.0847
DEBUG - 2022-06-16 09:47:29 --> Total execution time: 0.0861
DEBUG - 2022-06-16 09:47:40 --> Total execution time: 0.0632
DEBUG - 2022-06-16 09:47:42 --> Total execution time: 0.0506
DEBUG - 2022-06-16 09:47:58 --> Total execution time: 0.0737
DEBUG - 2022-06-16 09:48:01 --> Total execution time: 0.0767
DEBUG - 2022-06-16 09:48:02 --> Total execution time: 0.0766
DEBUG - 2022-06-16 09:48:11 --> Total execution time: 0.0637
DEBUG - 2022-06-16 09:48:13 --> Total execution time: 0.0550
DEBUG - 2022-06-16 09:48:16 --> Total execution time: 0.0475
DEBUG - 2022-06-16 09:48:19 --> Total execution time: 0.0505
DEBUG - 2022-06-16 09:48:21 --> Total execution time: 0.0508
DEBUG - 2022-06-16 09:48:22 --> Total execution time: 0.0444
DEBUG - 2022-06-16 09:48:23 --> Total execution time: 0.0439
DEBUG - 2022-06-16 09:48:24 --> Total execution time: 0.0442
DEBUG - 2022-06-16 09:48:25 --> Total execution time: 0.0892
DEBUG - 2022-06-16 09:48:25 --> Total execution time: 0.0484
DEBUG - 2022-06-16 09:48:30 --> Total execution time: 0.0647
DEBUG - 2022-06-16 09:48:34 --> Total execution time: 0.0646
DEBUG - 2022-06-16 09:48:34 --> Total execution time: 0.0497
DEBUG - 2022-06-16 09:48:37 --> Total execution time: 0.0589
DEBUG - 2022-06-16 09:48:38 --> Total execution time: 0.0612
DEBUG - 2022-06-16 09:48:39 --> Total execution time: 0.0457
DEBUG - 2022-06-16 09:48:40 --> Total execution time: 0.0458
DEBUG - 2022-06-16 09:48:47 --> Total execution time: 0.0470
DEBUG - 2022-06-16 09:48:51 --> Total execution time: 0.0531
DEBUG - 2022-06-16 09:48:51 --> Total execution time: 0.0453
DEBUG - 2022-06-16 09:48:52 --> Total execution time: 0.0495
DEBUG - 2022-06-16 09:49:04 --> Total execution time: 0.0479
DEBUG - 2022-06-16 09:49:06 --> Total execution time: 0.0559
DEBUG - 2022-06-16 09:49:10 --> Total execution time: 0.0952
DEBUG - 2022-06-16 09:49:13 --> Total execution time: 0.0903
DEBUG - 2022-06-16 09:49:19 --> Total execution time: 0.0632
DEBUG - 2022-06-16 09:49:31 --> Total execution time: 0.0533
DEBUG - 2022-06-16 09:49:39 --> Total execution time: 0.0417
DEBUG - 2022-06-16 09:49:40 --> Total execution time: 0.0363
DEBUG - 2022-06-16 09:49:46 --> Total execution time: 0.0363
DEBUG - 2022-06-16 09:49:47 --> Total execution time: 0.0502
DEBUG - 2022-06-16 09:49:56 --> Total execution time: 0.0418
DEBUG - 2022-06-16 09:50:12 --> Total execution time: 0.0477
DEBUG - 2022-06-16 09:50:35 --> Total execution time: 0.0747
DEBUG - 2022-06-16 09:51:24 --> Total execution time: 0.0494
DEBUG - 2022-06-16 09:51:46 --> Total execution time: 0.0625
DEBUG - 2022-06-16 09:51:53 --> Total execution time: 0.1097
DEBUG - 2022-06-16 09:51:54 --> Total execution time: 0.0484
DEBUG - 2022-06-16 09:52:52 --> Total execution time: 0.0642
DEBUG - 2022-06-16 09:52:56 --> Total execution time: 0.0396
DEBUG - 2022-06-16 09:53:02 --> Total execution time: 0.0502
DEBUG - 2022-06-16 09:53:43 --> Total execution time: 0.0506
DEBUG - 2022-06-16 09:53:54 --> Total execution time: 0.0917
DEBUG - 2022-06-16 09:54:05 --> Total execution time: 0.0440
DEBUG - 2022-06-16 09:54:13 --> Total execution time: 0.0694
DEBUG - 2022-06-16 09:54:18 --> Total execution time: 0.0448
DEBUG - 2022-06-16 09:55:01 --> Total execution time: 0.0879
DEBUG - 2022-06-16 09:55:19 --> Total execution time: 0.0466
DEBUG - 2022-06-16 09:55:21 --> Total execution time: 0.1091
DEBUG - 2022-06-16 09:55:22 --> Total execution time: 0.0495
DEBUG - 2022-06-16 09:55:28 --> Total execution time: 0.0499
DEBUG - 2022-06-16 09:55:43 --> Total execution time: 0.0463
DEBUG - 2022-06-16 09:55:59 --> Total execution time: 0.0408
DEBUG - 2022-06-16 09:56:00 --> Total execution time: 0.0586
DEBUG - 2022-06-16 09:56:07 --> Total execution time: 0.0712
DEBUG - 2022-06-16 09:56:15 --> Total execution time: 0.0543
DEBUG - 2022-06-16 09:56:25 --> Total execution time: 0.0479
DEBUG - 2022-06-16 09:56:59 --> Total execution time: 0.0616
DEBUG - 2022-06-16 09:57:06 --> Total execution time: 0.0477
DEBUG - 2022-06-16 09:57:12 --> Total execution time: 0.0556
DEBUG - 2022-06-16 09:59:51 --> Total execution time: 0.0499
DEBUG - 2022-06-16 10:00:29 --> Total execution time: 0.0415
DEBUG - 2022-06-16 10:03:04 --> Total execution time: 0.1248
DEBUG - 2022-06-16 10:03:20 --> Total execution time: 0.0464
DEBUG - 2022-06-16 10:03:23 --> Total execution time: 0.1172
DEBUG - 2022-06-16 10:09:12 --> Total execution time: 0.0526
DEBUG - 2022-06-16 10:09:30 --> Total execution time: 0.0524
DEBUG - 2022-06-16 10:09:40 --> Total execution time: 0.0535
DEBUG - 2022-06-16 10:09:49 --> Total execution time: 0.0465
DEBUG - 2022-06-16 10:09:54 --> Total execution time: 0.0443
DEBUG - 2022-06-16 10:09:54 --> Total execution time: 0.0295
DEBUG - 2022-06-16 10:09:55 --> Total execution time: 0.0324
DEBUG - 2022-06-16 10:10:15 --> Total execution time: 0.0457
DEBUG - 2022-06-16 10:10:34 --> Total execution time: 0.0355
DEBUG - 2022-06-16 10:10:47 --> Total execution time: 0.1351
DEBUG - 2022-06-16 10:11:04 --> Total execution time: 0.0720
DEBUG - 2022-06-16 10:11:28 --> Total execution time: 0.0801
DEBUG - 2022-06-16 10:11:33 --> Total execution time: 0.0676
DEBUG - 2022-06-16 10:11:39 --> Total execution time: 0.0634
DEBUG - 2022-06-16 10:13:23 --> Total execution time: 0.0843
DEBUG - 2022-06-16 10:15:21 --> Total execution time: 0.1147
DEBUG - 2022-06-16 10:15:29 --> Total execution time: 0.0355
DEBUG - 2022-06-16 10:15:43 --> Total execution time: 0.0421
DEBUG - 2022-06-16 10:15:56 --> Total execution time: 0.0660
DEBUG - 2022-06-16 10:16:12 --> Total execution time: 0.0556
DEBUG - 2022-06-16 10:16:16 --> Total execution time: 0.0848
DEBUG - 2022-06-16 10:16:28 --> Total execution time: 0.0475
DEBUG - 2022-06-16 10:16:30 --> Total execution time: 0.0407
DEBUG - 2022-06-16 10:16:35 --> Total execution time: 0.0372
DEBUG - 2022-06-16 10:16:37 --> Total execution time: 0.0650
DEBUG - 2022-06-16 10:16:54 --> Total execution time: 0.0685
DEBUG - 2022-06-16 10:17:01 --> Total execution time: 0.0703
DEBUG - 2022-06-16 10:18:04 --> Total execution time: 0.0481
DEBUG - 2022-06-16 10:18:22 --> Total execution time: 0.0538
DEBUG - 2022-06-16 10:18:32 --> Total execution time: 0.0508
DEBUG - 2022-06-16 10:18:36 --> Total execution time: 0.0599
DEBUG - 2022-06-16 10:18:40 --> Total execution time: 0.0452
DEBUG - 2022-06-16 10:23:00 --> Total execution time: 0.0510
DEBUG - 2022-06-16 10:24:17 --> Total execution time: 0.1074
DEBUG - 2022-06-16 10:24:24 --> Total execution time: 0.0547
DEBUG - 2022-06-16 10:24:26 --> Total execution time: 0.0403
DEBUG - 2022-06-16 10:26:06 --> Total execution time: 0.0373
DEBUG - 2022-06-16 10:26:08 --> Total execution time: 0.0451
DEBUG - 2022-06-16 10:26:08 --> Total execution time: 0.0452
DEBUG - 2022-06-16 10:26:27 --> Total execution time: 0.0298
DEBUG - 2022-06-16 10:26:30 --> Total execution time: 0.0436
DEBUG - 2022-06-16 10:26:34 --> Total execution time: 0.0441
DEBUG - 2022-06-16 10:26:35 --> Total execution time: 0.0437
DEBUG - 2022-06-16 10:26:37 --> Total execution time: 0.0421
DEBUG - 2022-06-16 10:26:43 --> Total execution time: 0.0309
DEBUG - 2022-06-16 10:26:44 --> Total execution time: 0.0287
DEBUG - 2022-06-16 10:26:45 --> Total execution time: 0.0482
DEBUG - 2022-06-16 10:27:25 --> Total execution time: 0.0651
DEBUG - 2022-06-16 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:30:03 --> Total execution time: 0.1054
DEBUG - 2022-06-16 00:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:32:56 --> Total execution time: 0.2332
DEBUG - 2022-06-16 00:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:34:52 --> Total execution time: 0.0776
DEBUG - 2022-06-16 00:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:05:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:35:08 --> Total execution time: 0.1140
DEBUG - 2022-06-16 00:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:35:23 --> Total execution time: 0.0331
DEBUG - 2022-06-16 00:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:36:23 --> Total execution time: 0.1011
DEBUG - 2022-06-16 00:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:36:46 --> Total execution time: 0.0598
DEBUG - 2022-06-16 00:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:06:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:36:53 --> Total execution time: 0.0432
DEBUG - 2022-06-16 00:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:06:54 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:36:54 --> Total execution time: 0.0291
DEBUG - 2022-06-16 00:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:37:03 --> Total execution time: 0.0318
DEBUG - 2022-06-16 00:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:37:12 --> Total execution time: 0.0672
DEBUG - 2022-06-16 00:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:37:34 --> Total execution time: 0.0400
DEBUG - 2022-06-16 00:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:37:46 --> Total execution time: 0.0423
DEBUG - 2022-06-16 00:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:37:49 --> Total execution time: 0.0457
DEBUG - 2022-06-16 00:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:38:04 --> Total execution time: 0.0583
DEBUG - 2022-06-16 00:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:38:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:38:05 --> Total execution time: 0.0485
DEBUG - 2022-06-16 00:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:42 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:38:42 --> Total execution time: 0.0334
DEBUG - 2022-06-16 00:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:38:44 --> Total execution time: 0.0395
DEBUG - 2022-06-16 00:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:38:45 --> Total execution time: 0.0570
DEBUG - 2022-06-16 00:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:38:48 --> Total execution time: 0.0482
DEBUG - 2022-06-16 00:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:38:50 --> Total execution time: 0.0725
DEBUG - 2022-06-16 00:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:39:11 --> Total execution time: 0.0276
DEBUG - 2022-06-16 00:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:39:13 --> Total execution time: 0.0855
DEBUG - 2022-06-16 00:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:39:18 --> Total execution time: 0.0707
DEBUG - 2022-06-16 00:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:09:28 --> Total execution time: 0.0797
DEBUG - 2022-06-16 00:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:39:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:39:34 --> Total execution time: 0.0625
DEBUG - 2022-06-16 00:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:35 --> Total execution time: 0.0429
DEBUG - 2022-06-16 00:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:09:35 --> Total execution time: 0.0618
DEBUG - 2022-06-16 00:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:09:50 --> Total execution time: 0.0589
DEBUG - 2022-06-16 00:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:39:53 --> Total execution time: 0.0639
DEBUG - 2022-06-16 00:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:09:58 --> Total execution time: 0.1007
DEBUG - 2022-06-16 00:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:40:06 --> Total execution time: 0.1378
DEBUG - 2022-06-16 00:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:10:16 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:40:16 --> Total execution time: 0.0420
DEBUG - 2022-06-16 00:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:40:36 --> Total execution time: 0.0760
DEBUG - 2022-06-16 00:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:40:52 --> Total execution time: 0.0481
DEBUG - 2022-06-16 00:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:11:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:41:18 --> Total execution time: 0.0341
DEBUG - 2022-06-16 00:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:11:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 00:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:41:24 --> Total execution time: 1.9346
DEBUG - 2022-06-16 00:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 00:11:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 00:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:41:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 00:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:41:59 --> Total execution time: 0.0529
DEBUG - 2022-06-16 00:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:42:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 10:42:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 10:42:01 --> Total execution time: 0.2884
DEBUG - 2022-06-16 00:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:42:04 --> Total execution time: 0.0464
DEBUG - 2022-06-16 00:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:42:19 --> Total execution time: 0.0692
DEBUG - 2022-06-16 00:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:42:28 --> Total execution time: 0.0367
DEBUG - 2022-06-16 00:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:43:11 --> Total execution time: 0.0611
DEBUG - 2022-06-16 00:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:43:21 --> Total execution time: 0.0609
DEBUG - 2022-06-16 00:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:13:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:43:59 --> Total execution time: 0.0509
DEBUG - 2022-06-16 00:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:02 --> Total execution time: 0.0304
DEBUG - 2022-06-16 00:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:03 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:03 --> Total execution time: 0.0348
DEBUG - 2022-06-16 00:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:06 --> Total execution time: 0.0357
DEBUG - 2022-06-16 00:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:07 --> Total execution time: 0.0304
DEBUG - 2022-06-16 00:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:11 --> Total execution time: 0.0471
DEBUG - 2022-06-16 00:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:14 --> Total execution time: 0.0585
DEBUG - 2022-06-16 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:26 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:26 --> Total execution time: 0.0577
DEBUG - 2022-06-16 00:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:26 --> Total execution time: 0.0456
DEBUG - 2022-06-16 00:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:28 --> Total execution time: 0.0839
DEBUG - 2022-06-16 00:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:35 --> Total execution time: 0.0949
DEBUG - 2022-06-16 00:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:40 --> Total execution time: 0.0467
DEBUG - 2022-06-16 00:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:44:48 --> Total execution time: 0.0576
DEBUG - 2022-06-16 00:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 00:14:56 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-06-16 00:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 00:14:56 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-06-16 00:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:14:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 00:14:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 00:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:45:12 --> Total execution time: 0.0285
DEBUG - 2022-06-16 00:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:45:25 --> Total execution time: 0.0446
DEBUG - 2022-06-16 00:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:46:10 --> Total execution time: 0.1292
DEBUG - 2022-06-16 00:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:46:28 --> Total execution time: 0.0537
DEBUG - 2022-06-16 00:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:46:36 --> Total execution time: 0.0440
DEBUG - 2022-06-16 00:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:46:44 --> Total execution time: 0.0529
DEBUG - 2022-06-16 00:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:46:45 --> Total execution time: 0.0713
DEBUG - 2022-06-16 00:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:47:27 --> Total execution time: 0.0451
DEBUG - 2022-06-16 00:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:49:00 --> Total execution time: 0.0615
DEBUG - 2022-06-16 00:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:49:15 --> Total execution time: 0.0431
DEBUG - 2022-06-16 00:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:50:18 --> Total execution time: 0.0474
DEBUG - 2022-06-16 00:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:51:16 --> Total execution time: 0.0794
DEBUG - 2022-06-16 00:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:51:28 --> Total execution time: 0.0519
DEBUG - 2022-06-16 00:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:51:36 --> Total execution time: 0.0462
DEBUG - 2022-06-16 00:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:22:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:52:53 --> Total execution time: 0.0425
DEBUG - 2022-06-16 00:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:23:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:53:59 --> Total execution time: 0.0600
DEBUG - 2022-06-16 00:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:54:19 --> Total execution time: 0.1246
DEBUG - 2022-06-16 00:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:54:53 --> Total execution time: 0.0767
DEBUG - 2022-06-16 00:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:56:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 00:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:56:55 --> Total execution time: 0.0638
DEBUG - 2022-06-16 00:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:57:06 --> Total execution time: 0.0631
DEBUG - 2022-06-16 00:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:59:52 --> Total execution time: 0.5152
DEBUG - 2022-06-16 00:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:00:35 --> Total execution time: 0.0591
DEBUG - 2022-06-16 00:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:31:14 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:01:14 --> Total execution time: 0.1404
DEBUG - 2022-06-16 00:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:02:42 --> Total execution time: 0.0623
DEBUG - 2022-06-16 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:02:51 --> Total execution time: 0.0526
DEBUG - 2022-06-16 00:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:02:58 --> Total execution time: 0.0783
DEBUG - 2022-06-16 00:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:03:24 --> Total execution time: 0.0320
DEBUG - 2022-06-16 00:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:04:01 --> Total execution time: 0.1275
DEBUG - 2022-06-16 00:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 00:34:02 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 00:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 00:34:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 00:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:04:21 --> Total execution time: 0.0643
DEBUG - 2022-06-16 00:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:04:25 --> Total execution time: 0.0467
DEBUG - 2022-06-16 00:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:04:52 --> Total execution time: 0.0791
DEBUG - 2022-06-16 00:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:05:07 --> Total execution time: 0.0685
DEBUG - 2022-06-16 00:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:05:42 --> Total execution time: 0.0611
DEBUG - 2022-06-16 00:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:06:08 --> Total execution time: 0.1169
DEBUG - 2022-06-16 00:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:06:35 --> Total execution time: 0.1208
DEBUG - 2022-06-16 00:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:06:39 --> Total execution time: 0.0769
DEBUG - 2022-06-16 00:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:06:47 --> Total execution time: 0.0509
DEBUG - 2022-06-16 00:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:06:51 --> Total execution time: 0.0578
DEBUG - 2022-06-16 00:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:06:53 --> Total execution time: 0.0469
DEBUG - 2022-06-16 00:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:06:56 --> Total execution time: 0.0685
DEBUG - 2022-06-16 00:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:06:58 --> Total execution time: 0.0537
DEBUG - 2022-06-16 00:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:00 --> Total execution time: 0.0421
DEBUG - 2022-06-16 00:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:04 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:04 --> Total execution time: 0.0475
DEBUG - 2022-06-16 00:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:08 --> Total execution time: 0.0673
DEBUG - 2022-06-16 00:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:28 --> Total execution time: 0.0725
DEBUG - 2022-06-16 00:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:31 --> Total execution time: 0.0421
DEBUG - 2022-06-16 00:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:33 --> Total execution time: 0.0524
DEBUG - 2022-06-16 00:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:37 --> Total execution time: 0.0446
DEBUG - 2022-06-16 00:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:40 --> Total execution time: 0.0631
DEBUG - 2022-06-16 00:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:49 --> Total execution time: 0.0494
DEBUG - 2022-06-16 00:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:07:55 --> Total execution time: 0.0529
DEBUG - 2022-06-16 00:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:38:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:08:00 --> Total execution time: 0.0421
DEBUG - 2022-06-16 00:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 00:38:10 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-16 00:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:08:20 --> Total execution time: 0.0723
DEBUG - 2022-06-16 00:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:08:24 --> Total execution time: 0.0451
DEBUG - 2022-06-16 00:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:14:48 --> Total execution time: 0.0451
DEBUG - 2022-06-16 00:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:18:03 --> Total execution time: 0.3366
DEBUG - 2022-06-16 00:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:18:15 --> Total execution time: 0.0990
DEBUG - 2022-06-16 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:18:27 --> Total execution time: 0.0423
DEBUG - 2022-06-16 00:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:18:53 --> Total execution time: 0.0269
DEBUG - 2022-06-16 00:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:18:54 --> Total execution time: 0.0702
DEBUG - 2022-06-16 00:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:19:03 --> Total execution time: 0.0846
DEBUG - 2022-06-16 00:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:19:15 --> Total execution time: 0.1003
DEBUG - 2022-06-16 00:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:19:41 --> Total execution time: 0.1343
DEBUG - 2022-06-16 00:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:19:53 --> Total execution time: 0.0834
DEBUG - 2022-06-16 00:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:20:01 --> Total execution time: 0.0845
DEBUG - 2022-06-16 00:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:20:16 --> Total execution time: 0.0715
DEBUG - 2022-06-16 00:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:20:20 --> Total execution time: 0.0686
DEBUG - 2022-06-16 00:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:20:24 --> Total execution time: 0.0678
DEBUG - 2022-06-16 00:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:20:56 --> Total execution time: 0.1621
DEBUG - 2022-06-16 00:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:21:27 --> Total execution time: 0.0415
DEBUG - 2022-06-16 00:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:53:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:23:20 --> Total execution time: 0.0340
DEBUG - 2022-06-16 00:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:23:51 --> Total execution time: 0.0388
DEBUG - 2022-06-16 00:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:54:04 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:24:04 --> Total execution time: 0.0480
DEBUG - 2022-06-16 00:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:54:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:24:05 --> Total execution time: 0.0627
DEBUG - 2022-06-16 00:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:24:09 --> Total execution time: 0.0269
DEBUG - 2022-06-16 00:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:24:15 --> Total execution time: 0.0528
DEBUG - 2022-06-16 00:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:24:19 --> Total execution time: 0.0618
DEBUG - 2022-06-16 00:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:55:37 --> Total execution time: 0.0455
DEBUG - 2022-06-16 00:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:55:40 --> Total execution time: 0.0495
DEBUG - 2022-06-16 00:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:55:40 --> Total execution time: 0.0890
DEBUG - 2022-06-16 00:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:55:46 --> Total execution time: 0.0443
DEBUG - 2022-06-16 00:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:55:47 --> Total execution time: 0.0673
DEBUG - 2022-06-16 00:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:55:47 --> Total execution time: 0.0853
DEBUG - 2022-06-16 00:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:56:45 --> Total execution time: 0.0295
DEBUG - 2022-06-16 00:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:56:47 --> Total execution time: 0.0445
DEBUG - 2022-06-16 00:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 00:56:47 --> Total execution time: 0.0846
DEBUG - 2022-06-16 00:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 00:57:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 00:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 00:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:27:30 --> Total execution time: 0.0329
DEBUG - 2022-06-16 01:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:30:03 --> Total execution time: 0.1597
DEBUG - 2022-06-16 01:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:00:23 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:30:23 --> Total execution time: 0.2784
DEBUG - 2022-06-16 01:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:02:58 --> Total execution time: 0.1157
DEBUG - 2022-06-16 01:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:03:47 --> Total execution time: 0.1801
DEBUG - 2022-06-16 01:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:03:47 --> Total execution time: 0.2435
DEBUG - 2022-06-16 01:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:06:31 --> Total execution time: 0.0576
DEBUG - 2022-06-16 01:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:06:33 --> Total execution time: 0.0385
DEBUG - 2022-06-16 01:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:06:33 --> Total execution time: 0.0963
DEBUG - 2022-06-16 01:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:36:45 --> Total execution time: 0.0490
DEBUG - 2022-06-16 01:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:36:57 --> Total execution time: 0.0480
DEBUG - 2022-06-16 01:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:05 --> Total execution time: 0.0693
DEBUG - 2022-06-16 01:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:19 --> Total execution time: 0.0382
DEBUG - 2022-06-16 01:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:30 --> Total execution time: 0.0427
DEBUG - 2022-06-16 01:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:33 --> Total execution time: 0.0635
DEBUG - 2022-06-16 01:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:38 --> Total execution time: 0.0707
DEBUG - 2022-06-16 01:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:44 --> Total execution time: 0.1172
DEBUG - 2022-06-16 01:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:50 --> Total execution time: 0.0843
DEBUG - 2022-06-16 01:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:50 --> Total execution time: 0.0989
DEBUG - 2022-06-16 01:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:52 --> Total execution time: 0.0543
DEBUG - 2022-06-16 01:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:37:57 --> Total execution time: 0.0786
DEBUG - 2022-06-16 01:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:38:00 --> Total execution time: 0.0789
DEBUG - 2022-06-16 01:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:08:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:38:05 --> Total execution time: 0.1779
DEBUG - 2022-06-16 01:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:08:28 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:38:28 --> Total execution time: 0.1169
DEBUG - 2022-06-16 01:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:44:33 --> Total execution time: 0.1428
DEBUG - 2022-06-16 01:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:44:45 --> Total execution time: 0.0513
DEBUG - 2022-06-16 01:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:44:53 --> Total execution time: 0.0699
DEBUG - 2022-06-16 01:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:45:05 --> Total execution time: 0.0660
DEBUG - 2022-06-16 01:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:45:40 --> Total execution time: 0.0689
DEBUG - 2022-06-16 01:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:53:13 --> Total execution time: 0.0435
DEBUG - 2022-06-16 01:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:23:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:53:15 --> Total execution time: 0.0494
DEBUG - 2022-06-16 01:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:53:19 --> Total execution time: 0.0491
DEBUG - 2022-06-16 01:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:53:36 --> Total execution time: 0.0530
DEBUG - 2022-06-16 01:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:53:46 --> Total execution time: 0.1057
DEBUG - 2022-06-16 01:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:53:54 --> Total execution time: 0.1160
DEBUG - 2022-06-16 01:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:24:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:54:08 --> Total execution time: 0.0450
DEBUG - 2022-06-16 01:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:24:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:54:09 --> Total execution time: 0.0756
DEBUG - 2022-06-16 01:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:24:26 --> Total execution time: 0.0890
DEBUG - 2022-06-16 01:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:54:50 --> Total execution time: 0.1539
DEBUG - 2022-06-16 01:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:24:56 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:54:56 --> Total execution time: 0.0878
DEBUG - 2022-06-16 01:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:24:58 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:54:58 --> Total execution time: 0.0825
DEBUG - 2022-06-16 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:56:29 --> Total execution time: 0.0574
DEBUG - 2022-06-16 01:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:56:36 --> Total execution time: 0.0917
DEBUG - 2022-06-16 01:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:56:48 --> Total execution time: 0.0652
DEBUG - 2022-06-16 01:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:56:52 --> Total execution time: 0.0549
DEBUG - 2022-06-16 01:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:56:57 --> Total execution time: 0.1074
DEBUG - 2022-06-16 01:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:57:06 --> Total execution time: 0.0952
DEBUG - 2022-06-16 01:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:57:08 --> Total execution time: 0.0712
DEBUG - 2022-06-16 01:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:57:11 --> Total execution time: 0.1046
DEBUG - 2022-06-16 01:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:57:21 --> Total execution time: 0.0440
DEBUG - 2022-06-16 01:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:58:16 --> Total execution time: 0.0923
DEBUG - 2022-06-16 01:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:59:35 --> Total execution time: 0.0327
DEBUG - 2022-06-16 01:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 01:30:37 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 01:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:30:38 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:00:38 --> Total execution time: 0.0516
DEBUG - 2022-06-16 01:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:31:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:01:05 --> Total execution time: 0.0492
DEBUG - 2022-06-16 01:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:31:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:01:15 --> Total execution time: 0.1224
DEBUG - 2022-06-16 01:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:31:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:01:24 --> Total execution time: 0.0320
DEBUG - 2022-06-16 01:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:31:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:01:25 --> Total execution time: 0.0358
DEBUG - 2022-06-16 01:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 01:31:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 01:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:31:52 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:01:52 --> Total execution time: 0.0715
DEBUG - 2022-06-16 01:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:32:31 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:02:32 --> Total execution time: 0.0900
DEBUG - 2022-06-16 01:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:03:25 --> Total execution time: 0.0716
DEBUG - 2022-06-16 01:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:03:40 --> Total execution time: 0.0591
DEBUG - 2022-06-16 01:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:03:41 --> Total execution time: 0.0605
DEBUG - 2022-06-16 01:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:03:50 --> Total execution time: 0.0410
DEBUG - 2022-06-16 01:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:04:13 --> Total execution time: 0.0765
DEBUG - 2022-06-16 01:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:04:43 --> Total execution time: 0.0684
DEBUG - 2022-06-16 01:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:04:47 --> Total execution time: 0.0670
DEBUG - 2022-06-16 01:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:05:07 --> Total execution time: 0.1107
DEBUG - 2022-06-16 01:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:35:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 01:35:16 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-16 01:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 01:35:56 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-16 01:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:37:31 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:07:31 --> Total execution time: 0.1245
DEBUG - 2022-06-16 01:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:37:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:07:32 --> Total execution time: 0.0885
DEBUG - 2022-06-16 01:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:38:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:08:02 --> Total execution time: 0.1221
DEBUG - 2022-06-16 01:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:38:45 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:08:45 --> Total execution time: 0.1196
DEBUG - 2022-06-16 01:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 01:40:40 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-16 01:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:11:09 --> Total execution time: 0.1944
DEBUG - 2022-06-16 01:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:11:15 --> Total execution time: 0.0474
DEBUG - 2022-06-16 01:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:11:19 --> Total execution time: 0.0486
DEBUG - 2022-06-16 01:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:11:26 --> Total execution time: 0.0896
DEBUG - 2022-06-16 01:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:11:41 --> Total execution time: 0.1260
DEBUG - 2022-06-16 01:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:42:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:12:24 --> Total execution time: 0.3495
DEBUG - 2022-06-16 01:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:13:03 --> Total execution time: 0.0761
DEBUG - 2022-06-16 01:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:13:24 --> Total execution time: 0.0673
DEBUG - 2022-06-16 01:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:43:34 --> Total execution time: 0.0562
DEBUG - 2022-06-16 01:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:43:35 --> Total execution time: 0.0442
DEBUG - 2022-06-16 01:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:43:35 --> Total execution time: 0.0983
DEBUG - 2022-06-16 01:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:13:40 --> Total execution time: 0.0715
DEBUG - 2022-06-16 01:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:13:56 --> Total execution time: 0.0920
DEBUG - 2022-06-16 01:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:14:15 --> Total execution time: 0.1342
DEBUG - 2022-06-16 01:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:26 --> Total execution time: 0.0647
DEBUG - 2022-06-16 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:36 --> Total execution time: 0.0418
DEBUG - 2022-06-16 01:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:43 --> Total execution time: 0.0461
DEBUG - 2022-06-16 01:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:54 --> Total execution time: 0.0551
DEBUG - 2022-06-16 01:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:44:57 --> Total execution time: 0.0396
DEBUG - 2022-06-16 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:45:00 --> Total execution time: 0.0552
DEBUG - 2022-06-16 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:01 --> Total execution time: 0.0748
DEBUG - 2022-06-16 01:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:45:04 --> Total execution time: 0.0741
DEBUG - 2022-06-16 01:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:06 --> Total execution time: 0.1071
DEBUG - 2022-06-16 01:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:19 --> Total execution time: 0.0485
DEBUG - 2022-06-16 01:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:32 --> Total execution time: 0.0560
DEBUG - 2022-06-16 01:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:16:41 --> Total execution time: 0.0522
DEBUG - 2022-06-16 01:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:16:48 --> Total execution time: 0.0676
DEBUG - 2022-06-16 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:16:56 --> Total execution time: 0.0513
DEBUG - 2022-06-16 01:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:17:26 --> Total execution time: 0.0798
DEBUG - 2022-06-16 01:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:17:27 --> Total execution time: 0.0681
DEBUG - 2022-06-16 01:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:17:34 --> Total execution time: 0.0574
DEBUG - 2022-06-16 01:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:18:27 --> Total execution time: 0.2202
DEBUG - 2022-06-16 01:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:49:28 --> Total execution time: 0.0473
DEBUG - 2022-06-16 01:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:19:36 --> Total execution time: 0.0509
DEBUG - 2022-06-16 01:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:49:37 --> Total execution time: 0.0698
DEBUG - 2022-06-16 01:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:49:37 --> Total execution time: 0.1001
DEBUG - 2022-06-16 01:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:19:37 --> Total execution time: 0.0479
DEBUG - 2022-06-16 01:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:19:45 --> Total execution time: 0.0537
DEBUG - 2022-06-16 01:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:19:50 --> Total execution time: 0.0639
DEBUG - 2022-06-16 01:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:19:54 --> Total execution time: 0.1799
DEBUG - 2022-06-16 01:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:04 --> Total execution time: 0.0651
DEBUG - 2022-06-16 01:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:50:05 --> Total execution time: 0.0792
DEBUG - 2022-06-16 01:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:05 --> Total execution time: 0.0847
DEBUG - 2022-06-16 01:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:50:11 --> Total execution time: 0.0561
DEBUG - 2022-06-16 01:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:19 --> Total execution time: 0.0608
DEBUG - 2022-06-16 01:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:25 --> Total execution time: 0.0527
DEBUG - 2022-06-16 01:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:22:31 --> Total execution time: 0.1172
DEBUG - 2022-06-16 01:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:23:59 --> Total execution time: 0.1709
DEBUG - 2022-06-16 01:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:24:05 --> Total execution time: 0.0465
DEBUG - 2022-06-16 01:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:24:11 --> Total execution time: 0.1058
DEBUG - 2022-06-16 01:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:24:50 --> Total execution time: 0.0513
DEBUG - 2022-06-16 01:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:24:54 --> Total execution time: 0.0761
DEBUG - 2022-06-16 01:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:24:55 --> Total execution time: 0.1224
DEBUG - 2022-06-16 01:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:24:58 --> Total execution time: 0.0534
DEBUG - 2022-06-16 01:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:25:19 --> Total execution time: 0.0501
DEBUG - 2022-06-16 01:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:25:27 --> Total execution time: 0.0584
DEBUG - 2022-06-16 01:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:58:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 01:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:28:15 --> Total execution time: 0.1969
DEBUG - 2022-06-16 01:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:28:20 --> Total execution time: 0.2607
DEBUG - 2022-06-16 01:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:28:24 --> Total execution time: 0.0547
DEBUG - 2022-06-16 01:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 01:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:28:48 --> Total execution time: 0.0894
DEBUG - 2022-06-16 01:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:28:58 --> Total execution time: 0.1137
DEBUG - 2022-06-16 01:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:29:00 --> Total execution time: 0.1337
DEBUG - 2022-06-16 01:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:29:08 --> Total execution time: 0.1244
DEBUG - 2022-06-16 01:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:29:17 --> Total execution time: 0.0753
DEBUG - 2022-06-16 01:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 01:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 01:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:29:20 --> Total execution time: 0.1009
DEBUG - 2022-06-16 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:03 --> Total execution time: 0.0638
DEBUG - 2022-06-16 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:04 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:04 --> Total execution time: 0.0430
DEBUG - 2022-06-16 02:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:09 --> Total execution time: 0.0876
DEBUG - 2022-06-16 02:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:19 --> Total execution time: 0.0976
DEBUG - 2022-06-16 02:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:30 --> Total execution time: 0.0372
DEBUG - 2022-06-16 02:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:31 --> Total execution time: 0.0702
DEBUG - 2022-06-16 02:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:31 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:31 --> Total execution time: 0.0459
DEBUG - 2022-06-16 02:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:35 --> Total execution time: 0.0311
DEBUG - 2022-06-16 02:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:35 --> Total execution time: 0.0410
DEBUG - 2022-06-16 02:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:44 --> Total execution time: 0.0516
DEBUG - 2022-06-16 02:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:51 --> Total execution time: 0.0776
DEBUG - 2022-06-16 02:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:55 --> Total execution time: 0.0700
DEBUG - 2022-06-16 02:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:30:59 --> Total execution time: 0.0575
DEBUG - 2022-06-16 02:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:31:07 --> Total execution time: 0.1014
DEBUG - 2022-06-16 02:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:31:07 --> Total execution time: 0.1142
DEBUG - 2022-06-16 02:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:31:11 --> Total execution time: 0.0919
DEBUG - 2022-06-16 02:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:01:46 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:31:46 --> Total execution time: 0.0413
DEBUG - 2022-06-16 02:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:01:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:31:50 --> Total execution time: 0.0337
DEBUG - 2022-06-16 02:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:02:10 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:32:10 --> Total execution time: 0.0346
DEBUG - 2022-06-16 02:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:02:26 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:32:26 --> Total execution time: 0.0360
DEBUG - 2022-06-16 02:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:02:54 --> Total execution time: 0.1110
DEBUG - 2022-06-16 02:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:02:55 --> Total execution time: 0.0505
DEBUG - 2022-06-16 02:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:02:55 --> Total execution time: 0.0993
DEBUG - 2022-06-16 02:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:33:47 --> Total execution time: 0.1760
DEBUG - 2022-06-16 02:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:34:16 --> Total execution time: 0.0916
DEBUG - 2022-06-16 02:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:34:40 --> Total execution time: 0.0942
DEBUG - 2022-06-16 02:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:34:49 --> Total execution time: 0.1298
DEBUG - 2022-06-16 02:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:35:22 --> Total execution time: 0.0795
DEBUG - 2022-06-16 02:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:35:25 --> Total execution time: 0.0671
DEBUG - 2022-06-16 02:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:05:36 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:35:36 --> Total execution time: 0.1484
DEBUG - 2022-06-16 02:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:06:00 --> Total execution time: 0.0347
DEBUG - 2022-06-16 02:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:06:03 --> Total execution time: 0.0791
DEBUG - 2022-06-16 02:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:06:03 --> Total execution time: 0.1114
DEBUG - 2022-06-16 02:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:06:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:36:25 --> Total execution time: 0.0433
DEBUG - 2022-06-16 02:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:06:33 --> Total execution time: 0.0419
DEBUG - 2022-06-16 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:06:36 --> Total execution time: 0.0592
DEBUG - 2022-06-16 02:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:06:36 --> Total execution time: 0.0928
DEBUG - 2022-06-16 02:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:07:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:37:01 --> Total execution time: 0.0656
DEBUG - 2022-06-16 02:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:07:06 --> Total execution time: 0.0482
DEBUG - 2022-06-16 02:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:07:08 --> Total execution time: 0.0805
DEBUG - 2022-06-16 02:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:07:08 --> Total execution time: 0.1161
DEBUG - 2022-06-16 02:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:07:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:37:20 --> Total execution time: 0.0493
DEBUG - 2022-06-16 02:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:09:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:39:34 --> Total execution time: 0.1450
DEBUG - 2022-06-16 02:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:40:02 --> Total execution time: 0.3360
DEBUG - 2022-06-16 02:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:13:48 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:43:48 --> Total execution time: 0.1184
DEBUG - 2022-06-16 02:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:13:49 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:43:49 --> Total execution time: 0.0253
DEBUG - 2022-06-16 02:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:44:02 --> Total execution time: 0.0374
DEBUG - 2022-06-16 02:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:44:39 --> Total execution time: 0.0484
DEBUG - 2022-06-16 02:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:44:57 --> Total execution time: 0.1380
DEBUG - 2022-06-16 02:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:45:02 --> Total execution time: 0.0652
DEBUG - 2022-06-16 02:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:45:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 02:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:45:03 --> Total execution time: 0.0869
DEBUG - 2022-06-16 02:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:45:58 --> Total execution time: 0.0475
DEBUG - 2022-06-16 02:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:45:59 --> Total execution time: 0.0626
DEBUG - 2022-06-16 02:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:46:09 --> Total execution time: 0.1419
DEBUG - 2022-06-16 02:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:46:14 --> Total execution time: 0.0682
DEBUG - 2022-06-16 02:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:46:28 --> Total execution time: 0.0574
DEBUG - 2022-06-16 02:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:46:56 --> Total execution time: 0.0752
DEBUG - 2022-06-16 02:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:46:58 --> Total execution time: 0.0605
DEBUG - 2022-06-16 02:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:47:15 --> Total execution time: 0.1662
DEBUG - 2022-06-16 02:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:47:26 --> Total execution time: 0.0499
DEBUG - 2022-06-16 02:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:50:16 --> Total execution time: 0.1827
DEBUG - 2022-06-16 02:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:50:43 --> Total execution time: 0.0998
DEBUG - 2022-06-16 02:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:51:31 --> Total execution time: 0.0549
DEBUG - 2022-06-16 02:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:51:53 --> Total execution time: 0.0695
DEBUG - 2022-06-16 02:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:51:57 --> Total execution time: 0.0459
DEBUG - 2022-06-16 02:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:53:38 --> Total execution time: 0.0495
DEBUG - 2022-06-16 02:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:23:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:53:40 --> Total execution time: 0.1024
DEBUG - 2022-06-16 02:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:23:43 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:53:43 --> Total execution time: 0.0422
DEBUG - 2022-06-16 02:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:23:52 --> Total execution time: 0.0645
DEBUG - 2022-06-16 02:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:23:53 --> Total execution time: 0.0703
DEBUG - 2022-06-16 02:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:23:53 --> Total execution time: 0.0827
DEBUG - 2022-06-16 02:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:24:14 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:54:14 --> Total execution time: 0.0415
DEBUG - 2022-06-16 02:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:24:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:54:15 --> Total execution time: 0.0403
DEBUG - 2022-06-16 02:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:54:18 --> Total execution time: 0.0420
DEBUG - 2022-06-16 02:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:24:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:54:24 --> Total execution time: 0.0361
DEBUG - 2022-06-16 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:54:58 --> Total execution time: 0.0465
DEBUG - 2022-06-16 02:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:25:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 02:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:56:00 --> Total execution time: 2.0281
DEBUG - 2022-06-16 02:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 02:26:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 02:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:56:09 --> Total execution time: 0.0580
DEBUG - 2022-06-16 02:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:58:08 --> Total execution time: 0.0346
DEBUG - 2022-06-16 02:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:58:31 --> Total execution time: 0.1081
DEBUG - 2022-06-16 02:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:58:33 --> Total execution time: 0.0637
DEBUG - 2022-06-16 02:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:28:37 --> Total execution time: 0.0368
DEBUG - 2022-06-16 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:28:51 --> Total execution time: 0.0506
DEBUG - 2022-06-16 02:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:28:51 --> Total execution time: 0.0852
DEBUG - 2022-06-16 02:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:58:57 --> Total execution time: 0.0397
DEBUG - 2022-06-16 02:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:01 --> Total execution time: 0.0564
DEBUG - 2022-06-16 02:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:04 --> Total execution time: 0.0580
DEBUG - 2022-06-16 02:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:09 --> Total execution time: 0.0497
DEBUG - 2022-06-16 02:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:11 --> Total execution time: 0.1540
DEBUG - 2022-06-16 02:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:12 --> Total execution time: 0.0576
DEBUG - 2022-06-16 02:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:15 --> Total execution time: 0.0459
DEBUG - 2022-06-16 02:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:19 --> Total execution time: 0.0427
DEBUG - 2022-06-16 02:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:21 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:21 --> Total execution time: 0.0557
DEBUG - 2022-06-16 02:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:57 --> Total execution time: 0.0566
DEBUG - 2022-06-16 02:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:29:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:59:59 --> Total execution time: 0.1050
DEBUG - 2022-06-16 02:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:00:41 --> Total execution time: 0.0877
DEBUG - 2022-06-16 02:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:30:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:00:42 --> Total execution time: 0.0574
DEBUG - 2022-06-16 02:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:00:49 --> Total execution time: 0.1044
DEBUG - 2022-06-16 02:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:00:57 --> Total execution time: 0.0874
DEBUG - 2022-06-16 02:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:01:00 --> Total execution time: 0.0455
DEBUG - 2022-06-16 02:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:31:11 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:01:11 --> Total execution time: 0.0438
DEBUG - 2022-06-16 02:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:01:17 --> Total execution time: 0.0658
DEBUG - 2022-06-16 02:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:31:23 --> Total execution time: 0.0594
DEBUG - 2022-06-16 02:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:31:41 --> Total execution time: 0.0531
DEBUG - 2022-06-16 02:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:31:41 --> Total execution time: 0.0985
DEBUG - 2022-06-16 02:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:32:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:02:30 --> Total execution time: 0.0528
DEBUG - 2022-06-16 02:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:32:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:02:30 --> Total execution time: 0.0374
DEBUG - 2022-06-16 02:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:02:33 --> Total execution time: 0.0463
DEBUG - 2022-06-16 02:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:02:44 --> Total execution time: 0.0456
DEBUG - 2022-06-16 02:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:32:51 --> Total execution time: 0.0698
DEBUG - 2022-06-16 02:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:32:55 --> Total execution time: 0.1041
DEBUG - 2022-06-16 02:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:33:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 02:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:03:13 --> Total execution time: 1.5430
DEBUG - 2022-06-16 02:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 02:33:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 02:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:03:41 --> Total execution time: 0.0547
DEBUG - 2022-06-16 02:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:07 --> Total execution time: 0.1138
DEBUG - 2022-06-16 02:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:12 --> Total execution time: 0.0990
DEBUG - 2022-06-16 02:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:18 --> Total execution time: 0.0611
DEBUG - 2022-06-16 02:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:18 --> Total execution time: 0.0572
DEBUG - 2022-06-16 02:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:21 --> Total execution time: 0.1025
DEBUG - 2022-06-16 02:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:22 --> Total execution time: 0.1007
DEBUG - 2022-06-16 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 02:34:24 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-16 02:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 02:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:28 --> Total execution time: 0.0604
DEBUG - 2022-06-16 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:31 --> Total execution time: 0.0497
DEBUG - 2022-06-16 02:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:04:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 13:04:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 13:04:31 --> Total execution time: 0.2005
DEBUG - 2022-06-16 02:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:05:34 --> Total execution time: 0.0604
DEBUG - 2022-06-16 02:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:05:54 --> Total execution time: 0.0400
DEBUG - 2022-06-16 02:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:06:19 --> Total execution time: 0.0429
DEBUG - 2022-06-16 02:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:06:25 --> Total execution time: 0.1010
DEBUG - 2022-06-16 02:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:06:49 --> Total execution time: 0.0363
DEBUG - 2022-06-16 02:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:06:57 --> Total execution time: 0.0316
DEBUG - 2022-06-16 02:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:07:02 --> Total execution time: 0.0416
DEBUG - 2022-06-16 02:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:07:07 --> Total execution time: 0.0407
DEBUG - 2022-06-16 02:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:07:26 --> Total execution time: 0.0949
DEBUG - 2022-06-16 02:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:07:37 --> Total execution time: 0.1058
DEBUG - 2022-06-16 02:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:07:44 --> Total execution time: 0.0408
DEBUG - 2022-06-16 02:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:07:45 --> Total execution time: 0.0540
DEBUG - 2022-06-16 02:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:07:50 --> Total execution time: 0.0381
DEBUG - 2022-06-16 02:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:07:53 --> Total execution time: 0.1234
DEBUG - 2022-06-16 02:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:08:18 --> Total execution time: 0.0407
DEBUG - 2022-06-16 02:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:08:18 --> Total execution time: 0.0766
DEBUG - 2022-06-16 02:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:08:24 --> Total execution time: 0.0936
DEBUG - 2022-06-16 02:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:08:31 --> Total execution time: 0.0494
DEBUG - 2022-06-16 02:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:08:36 --> Total execution time: 0.0495
DEBUG - 2022-06-16 02:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:08:44 --> Total execution time: 0.0425
DEBUG - 2022-06-16 02:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:08:48 --> Total execution time: 0.0352
DEBUG - 2022-06-16 02:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:08:54 --> Total execution time: 0.0563
DEBUG - 2022-06-16 02:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:09:17 --> Total execution time: 0.0424
DEBUG - 2022-06-16 02:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:09:23 --> Total execution time: 0.0427
DEBUG - 2022-06-16 02:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:09:28 --> Total execution time: 0.0479
DEBUG - 2022-06-16 02:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:09:35 --> Total execution time: 0.0415
DEBUG - 2022-06-16 02:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:10:29 --> Total execution time: 0.1221
DEBUG - 2022-06-16 02:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:10:38 --> Total execution time: 0.0516
DEBUG - 2022-06-16 02:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:20 --> Total execution time: 0.0537
DEBUG - 2022-06-16 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:24 --> Total execution time: 0.0668
DEBUG - 2022-06-16 02:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:28 --> Total execution time: 0.0545
DEBUG - 2022-06-16 02:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:33 --> Total execution time: 0.0701
DEBUG - 2022-06-16 02:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:33 --> Total execution time: 0.0629
DEBUG - 2022-06-16 02:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:34 --> Total execution time: 0.0761
DEBUG - 2022-06-16 02:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:34 --> Total execution time: 0.0734
DEBUG - 2022-06-16 02:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:34 --> Total execution time: 0.0404
DEBUG - 2022-06-16 02:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:34 --> Total execution time: 0.0673
DEBUG - 2022-06-16 02:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:35 --> Total execution time: 0.0830
DEBUG - 2022-06-16 02:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:43 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:43 --> Total execution time: 0.0445
DEBUG - 2022-06-16 02:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:47 --> Total execution time: 0.0481
DEBUG - 2022-06-16 02:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:49 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:49 --> Total execution time: 0.0527
DEBUG - 2022-06-16 02:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:11:55 --> Total execution time: 0.0478
DEBUG - 2022-06-16 02:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:12:24 --> Total execution time: 1.5377
DEBUG - 2022-06-16 02:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:42:35 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:12:35 --> Total execution time: 0.0947
DEBUG - 2022-06-16 02:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:12:41 --> Total execution time: 0.0332
DEBUG - 2022-06-16 02:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:12:54 --> Total execution time: 0.0490
DEBUG - 2022-06-16 02:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:12:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 02:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:12:55 --> Total execution time: 0.0429
DEBUG - 2022-06-16 02:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:13:27 --> Total execution time: 0.0389
DEBUG - 2022-06-16 02:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:13:48 --> Total execution time: 0.0446
DEBUG - 2022-06-16 02:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:13:51 --> Total execution time: 0.0396
DEBUG - 2022-06-16 02:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:14:27 --> Total execution time: 0.0414
DEBUG - 2022-06-16 02:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:14:30 --> Total execution time: 0.0479
DEBUG - 2022-06-16 02:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:14:51 --> Total execution time: 0.0414
DEBUG - 2022-06-16 02:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:45:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:15:34 --> Total execution time: 0.1275
DEBUG - 2022-06-16 02:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:47:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:17:02 --> Total execution time: 0.0460
DEBUG - 2022-06-16 02:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:47:26 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:17:26 --> Total execution time: 0.0307
DEBUG - 2022-06-16 02:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:47:26 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:17:26 --> Total execution time: 0.0315
DEBUG - 2022-06-16 02:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:47:47 --> Total execution time: 0.0509
DEBUG - 2022-06-16 02:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:47:49 --> Total execution time: 0.0484
DEBUG - 2022-06-16 02:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:47:49 --> Total execution time: 0.0755
DEBUG - 2022-06-16 02:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:48:21 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:18:21 --> Total execution time: 0.0653
DEBUG - 2022-06-16 02:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:18:35 --> Total execution time: 0.0384
DEBUG - 2022-06-16 02:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:19:04 --> Total execution time: 0.0642
DEBUG - 2022-06-16 02:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:49:14 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:19:14 --> Total execution time: 0.0422
DEBUG - 2022-06-16 02:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:19:15 --> Total execution time: 0.0826
DEBUG - 2022-06-16 02:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:19:30 --> Total execution time: 0.0790
DEBUG - 2022-06-16 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:50:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:20:08 --> Total execution time: 0.1477
DEBUG - 2022-06-16 02:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:50:11 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:20:11 --> Total execution time: 0.0721
DEBUG - 2022-06-16 02:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:50:12 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:20:12 --> Total execution time: 0.0765
DEBUG - 2022-06-16 02:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:50:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:20:27 --> Total execution time: 0.0563
DEBUG - 2022-06-16 02:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:51:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:21:22 --> Total execution time: 0.0720
DEBUG - 2022-06-16 02:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:21:28 --> Total execution time: 0.0437
DEBUG - 2022-06-16 02:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:51:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:21:32 --> Total execution time: 0.0294
DEBUG - 2022-06-16 02:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:21:34 --> Total execution time: 0.0430
DEBUG - 2022-06-16 02:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:21:35 --> Total execution time: 0.0560
DEBUG - 2022-06-16 02:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:51:43 --> Total execution time: 0.0549
DEBUG - 2022-06-16 02:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:22:11 --> Total execution time: 0.0825
DEBUG - 2022-06-16 02:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:22:41 --> Total execution time: 0.0663
DEBUG - 2022-06-16 02:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:23:01 --> Total execution time: 0.0820
DEBUG - 2022-06-16 02:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:23:59 --> Total execution time: 0.1572
DEBUG - 2022-06-16 02:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:23:59 --> Total execution time: 0.0437
DEBUG - 2022-06-16 02:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:24:02 --> Total execution time: 0.0507
DEBUG - 2022-06-16 02:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:24:07 --> Total execution time: 0.0657
DEBUG - 2022-06-16 02:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:54:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 02:54:14 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-06-16 02:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:24:34 --> Total execution time: 0.0980
DEBUG - 2022-06-16 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 02:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:24:45 --> Total execution time: 0.2338
DEBUG - 2022-06-16 02:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:24:47 --> Total execution time: 0.0831
DEBUG - 2022-06-16 02:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:25:05 --> Total execution time: 0.0784
DEBUG - 2022-06-16 02:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:25:17 --> Total execution time: 0.1134
DEBUG - 2022-06-16 02:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:25:29 --> Total execution time: 0.1034
DEBUG - 2022-06-16 02:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 02:55:53 --> 404 Page Not Found: Shop/feed
DEBUG - 2022-06-16 02:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:01 --> Total execution time: 0.0973
DEBUG - 2022-06-16 02:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:12 --> Total execution time: 0.0475
DEBUG - 2022-06-16 02:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:17 --> Total execution time: 0.0493
DEBUG - 2022-06-16 02:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:23 --> Total execution time: 0.0783
DEBUG - 2022-06-16 02:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:32 --> Total execution time: 0.0440
DEBUG - 2022-06-16 02:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 02:57:14 --> No URI present. Default controller set.
DEBUG - 2022-06-16 02:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 02:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:27:14 --> Total execution time: 0.0494
DEBUG - 2022-06-16 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:30:03 --> Total execution time: 0.3198
DEBUG - 2022-06-16 03:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:30:25 --> Total execution time: 0.1296
DEBUG - 2022-06-16 03:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:00:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:30:30 --> Total execution time: 0.1017
DEBUG - 2022-06-16 03:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:00:51 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:30:51 --> Total execution time: 0.0364
DEBUG - 2022-06-16 03:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:01:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:31:27 --> Total execution time: 0.0323
DEBUG - 2022-06-16 03:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 03:02:25 --> 404 Page Not Found: Teacher/ana-murphy
DEBUG - 2022-06-16 03:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:33:36 --> Total execution time: 0.0690
DEBUG - 2022-06-16 03:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:34:18 --> Total execution time: 0.0743
DEBUG - 2022-06-16 03:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:34:23 --> Total execution time: 0.0634
DEBUG - 2022-06-16 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:34:37 --> Total execution time: 0.0406
DEBUG - 2022-06-16 03:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 03:05:04 --> 404 Page Not Found: Category/health
DEBUG - 2022-06-16 03:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:37:08 --> Total execution time: 0.0800
DEBUG - 2022-06-16 03:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:07:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 03:07:14 --> 404 Page Not Found: Category/culture
DEBUG - 2022-06-16 03:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:07:16 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:37:16 --> Total execution time: 0.0508
DEBUG - 2022-06-16 03:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:38:41 --> Total execution time: 0.0323
DEBUG - 2022-06-16 03:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:38:47 --> Total execution time: 0.0450
DEBUG - 2022-06-16 03:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:38:50 --> Total execution time: 0.0495
DEBUG - 2022-06-16 03:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:39:10 --> Total execution time: 0.0380
DEBUG - 2022-06-16 03:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:39:19 --> Total execution time: 0.0500
DEBUG - 2022-06-16 03:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:39:27 --> Total execution time: 0.0638
DEBUG - 2022-06-16 03:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:40:56 --> Total execution time: 0.1142
DEBUG - 2022-06-16 03:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:41:01 --> Total execution time: 0.0578
DEBUG - 2022-06-16 03:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:41:09 --> Total execution time: 0.0489
DEBUG - 2022-06-16 03:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:41:17 --> Total execution time: 0.0443
DEBUG - 2022-06-16 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:41:19 --> Total execution time: 0.0892
DEBUG - 2022-06-16 03:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:41:21 --> Total execution time: 0.0552
DEBUG - 2022-06-16 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:41:29 --> Total execution time: 0.0477
DEBUG - 2022-06-16 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:41:29 --> Total execution time: 0.0564
DEBUG - 2022-06-16 03:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:11:59 --> Total execution time: 0.0516
DEBUG - 2022-06-16 03:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:12:10 --> Total execution time: 0.1303
DEBUG - 2022-06-16 03:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:42:56 --> Total execution time: 0.0329
DEBUG - 2022-06-16 03:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:43:04 --> Total execution time: 0.0412
DEBUG - 2022-06-16 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:43:45 --> Total execution time: 0.1050
DEBUG - 2022-06-16 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:12 --> Total execution time: 0.0771
DEBUG - 2022-06-16 03:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:57 --> Total execution time: 0.0628
DEBUG - 2022-06-16 03:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:46:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 03:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:46:20 --> Total execution time: 0.1391
DEBUG - 2022-06-16 03:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:46:32 --> Total execution time: 0.0625
DEBUG - 2022-06-16 03:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:46:37 --> Total execution time: 0.0611
DEBUG - 2022-06-16 03:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:46:44 --> Total execution time: 0.0421
DEBUG - 2022-06-16 03:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:08 --> Total execution time: 0.0641
DEBUG - 2022-06-16 03:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:49:06 --> Total execution time: 0.0490
DEBUG - 2022-06-16 03:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:49:14 --> Total execution time: 0.0520
DEBUG - 2022-06-16 03:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:49:20 --> Total execution time: 0.0625
DEBUG - 2022-06-16 03:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:49:39 --> Total execution time: 0.0851
DEBUG - 2022-06-16 03:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:49:52 --> Total execution time: 0.0949
DEBUG - 2022-06-16 03:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:02 --> Total execution time: 0.1536
DEBUG - 2022-06-16 03:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:15 --> Total execution time: 0.0678
DEBUG - 2022-06-16 03:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:20 --> Total execution time: 0.0466
DEBUG - 2022-06-16 03:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:24 --> Total execution time: 0.1125
DEBUG - 2022-06-16 03:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:31 --> Total execution time: 0.0696
DEBUG - 2022-06-16 03:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:20:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:40 --> Total execution time: 0.0570
DEBUG - 2022-06-16 03:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:42 --> Total execution time: 0.0650
DEBUG - 2022-06-16 03:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:08 --> Total execution time: 0.0620
DEBUG - 2022-06-16 03:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:11 --> Total execution time: 0.1249
DEBUG - 2022-06-16 03:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:14 --> Total execution time: 0.0786
DEBUG - 2022-06-16 03:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:16 --> Total execution time: 0.0463
DEBUG - 2022-06-16 03:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:20 --> Total execution time: 0.0668
DEBUG - 2022-06-16 03:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:23 --> Total execution time: 0.0583
DEBUG - 2022-06-16 03:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:24 --> Total execution time: 0.0677
DEBUG - 2022-06-16 03:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:26 --> Total execution time: 0.0664
DEBUG - 2022-06-16 03:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:32 --> Total execution time: 0.0435
DEBUG - 2022-06-16 03:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:36 --> Total execution time: 0.0500
DEBUG - 2022-06-16 03:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:49 --> Total execution time: 0.0579
DEBUG - 2022-06-16 03:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:51:59 --> Total execution time: 0.0592
DEBUG - 2022-06-16 03:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:04 --> Total execution time: 0.0411
DEBUG - 2022-06-16 03:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:22:09 --> Total execution time: 0.0391
DEBUG - 2022-06-16 03:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:15 --> Total execution time: 0.0444
DEBUG - 2022-06-16 03:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:19 --> Total execution time: 0.0429
DEBUG - 2022-06-16 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:19 --> Total execution time: 0.0735
DEBUG - 2022-06-16 03:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:23 --> Total execution time: 0.1511
DEBUG - 2022-06-16 03:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:24 --> Total execution time: 0.1026
DEBUG - 2022-06-16 03:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:25 --> Total execution time: 0.0736
DEBUG - 2022-06-16 03:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:28 --> Total execution time: 0.0826
DEBUG - 2022-06-16 03:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:33 --> Total execution time: 0.0494
DEBUG - 2022-06-16 03:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:52:38 --> Total execution time: 0.0572
DEBUG - 2022-06-16 03:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:53:05 --> Total execution time: 0.0565
DEBUG - 2022-06-16 03:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:53:14 --> Total execution time: 0.0506
DEBUG - 2022-06-16 03:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 03:23:15 --> 404 Page Not Found: Category/reviews
DEBUG - 2022-06-16 03:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:53:34 --> Total execution time: 0.0498
DEBUG - 2022-06-16 03:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 03:26:57 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-16 03:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:30:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:00:02 --> Total execution time: 0.4766
DEBUG - 2022-06-16 03:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:00:31 --> Total execution time: 0.0478
DEBUG - 2022-06-16 03:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:06:11 --> Total execution time: 0.0813
DEBUG - 2022-06-16 03:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:06:15 --> Total execution time: 0.0526
DEBUG - 2022-06-16 03:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:06:16 --> Total execution time: 0.0974
DEBUG - 2022-06-16 03:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:36:48 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:06:48 --> Total execution time: 0.0367
DEBUG - 2022-06-16 03:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:37:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:07:05 --> Total execution time: 0.0354
DEBUG - 2022-06-16 03:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:37:06 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:07:06 --> Total execution time: 0.0292
DEBUG - 2022-06-16 03:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:39:11 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:09:12 --> Total execution time: 0.1623
DEBUG - 2022-06-16 03:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:40:48 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:10:48 --> Total execution time: 0.0671
DEBUG - 2022-06-16 03:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:10:59 --> Total execution time: 0.0526
DEBUG - 2022-06-16 03:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:11:00 --> Total execution time: 0.0882
DEBUG - 2022-06-16 03:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:11:22 --> Total execution time: 0.0698
DEBUG - 2022-06-16 03:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:11:34 --> Total execution time: 0.0479
DEBUG - 2022-06-16 03:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:11:37 --> Total execution time: 0.0659
DEBUG - 2022-06-16 03:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:11:48 --> Total execution time: 0.0385
DEBUG - 2022-06-16 03:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:12:13 --> Total execution time: 0.0422
DEBUG - 2022-06-16 03:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:12:26 --> Total execution time: 0.0431
DEBUG - 2022-06-16 03:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:12:44 --> Total execution time: 0.0634
DEBUG - 2022-06-16 03:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:13:03 --> Total execution time: 0.0862
DEBUG - 2022-06-16 03:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:13:24 --> Total execution time: 0.0629
DEBUG - 2022-06-16 03:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:13:35 --> Total execution time: 0.0546
DEBUG - 2022-06-16 03:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:44:12 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:14:12 --> Total execution time: 0.1286
DEBUG - 2022-06-16 03:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:15:06 --> Total execution time: 0.0435
DEBUG - 2022-06-16 03:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:17:56 --> Total execution time: 0.0452
DEBUG - 2022-06-16 03:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:47:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:17:59 --> Total execution time: 0.0345
DEBUG - 2022-06-16 03:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:48:39 --> Total execution time: 0.0456
DEBUG - 2022-06-16 03:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:48:40 --> Total execution time: 0.0695
DEBUG - 2022-06-16 03:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:48:40 --> Total execution time: 0.0868
DEBUG - 2022-06-16 03:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:48:43 --> Total execution time: 0.0394
DEBUG - 2022-06-16 03:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:48:45 --> Total execution time: 0.0333
DEBUG - 2022-06-16 03:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 03:49:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 03:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:19:20 --> Total execution time: 1.9706
DEBUG - 2022-06-16 03:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 03:49:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 03:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:50:03 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:20:03 --> Total execution time: 0.0341
DEBUG - 2022-06-16 03:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:50:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:20:05 --> Total execution time: 0.0352
DEBUG - 2022-06-16 03:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:50:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:20:40 --> Total execution time: 0.0303
DEBUG - 2022-06-16 03:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:53:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 03:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:23:19 --> Total execution time: 0.0814
DEBUG - 2022-06-16 03:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:25:19 --> Total execution time: 0.0547
DEBUG - 2022-06-16 03:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:28:19 --> Total execution time: 0.1045
DEBUG - 2022-06-16 03:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:29:58 --> Total execution time: 0.0906
DEBUG - 2022-06-16 03:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:29:58 --> Total execution time: 0.1288
DEBUG - 2022-06-16 03:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:29:59 --> Total execution time: 0.0551
DEBUG - 2022-06-16 03:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 03:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 03:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:29:59 --> Total execution time: 0.0492
DEBUG - 2022-06-16 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:30:02 --> Total execution time: 0.0910
DEBUG - 2022-06-16 04:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:30:05 --> Total execution time: 0.1024
DEBUG - 2022-06-16 04:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:01:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:31:08 --> Total execution time: 0.0543
DEBUG - 2022-06-16 04:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:01:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:31:09 --> Total execution time: 0.0304
DEBUG - 2022-06-16 04:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:31:16 --> Total execution time: 0.0326
DEBUG - 2022-06-16 04:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:31:27 --> Total execution time: 0.0461
DEBUG - 2022-06-16 04:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:31:36 --> Total execution time: 0.0707
DEBUG - 2022-06-16 04:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:32:01 --> Total execution time: 0.1585
DEBUG - 2022-06-16 04:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:32:06 --> Total execution time: 0.0383
DEBUG - 2022-06-16 04:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:33:00 --> Total execution time: 0.0486
DEBUG - 2022-06-16 04:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:33:18 --> Total execution time: 0.0427
DEBUG - 2022-06-16 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:33:23 --> Total execution time: 0.0447
DEBUG - 2022-06-16 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:33:23 --> Total execution time: 0.0525
DEBUG - 2022-06-16 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:33:28 --> Total execution time: 0.3247
DEBUG - 2022-06-16 04:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:33:34 --> Total execution time: 0.0766
DEBUG - 2022-06-16 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:34:13 --> Total execution time: 0.0445
DEBUG - 2022-06-16 04:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:35:24 --> Total execution time: 0.0279
DEBUG - 2022-06-16 04:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:35:31 --> Total execution time: 0.0529
DEBUG - 2022-06-16 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:35:35 --> Total execution time: 0.0697
DEBUG - 2022-06-16 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:35:47 --> Total execution time: 0.0814
DEBUG - 2022-06-16 04:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:35:55 --> Total execution time: 0.0459
DEBUG - 2022-06-16 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:35:57 --> Total execution time: 0.0584
DEBUG - 2022-06-16 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:36:06 --> Total execution time: 0.0530
DEBUG - 2022-06-16 04:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:36:16 --> Total execution time: 0.0495
DEBUG - 2022-06-16 04:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:36:16 --> Total execution time: 0.1141
DEBUG - 2022-06-16 04:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:48:52 --> Total execution time: 0.0704
DEBUG - 2022-06-16 04:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:48:59 --> Total execution time: 0.0776
DEBUG - 2022-06-16 04:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:49:02 --> Total execution time: 0.1009
DEBUG - 2022-06-16 04:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:49:06 --> Total execution time: 0.0907
DEBUG - 2022-06-16 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:49:13 --> Total execution time: 0.0484
DEBUG - 2022-06-16 04:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:19:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:49:20 --> Total execution time: 0.1009
DEBUG - 2022-06-16 04:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:49:33 --> Total execution time: 0.0482
DEBUG - 2022-06-16 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:50:00 --> Total execution time: 0.0682
DEBUG - 2022-06-16 04:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:50:04 --> Total execution time: 0.0841
DEBUG - 2022-06-16 04:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:50:16 --> Total execution time: 0.0809
DEBUG - 2022-06-16 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:20:29 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:50:29 --> Total execution time: 0.0326
DEBUG - 2022-06-16 04:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:20:35 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:50:35 --> Total execution time: 0.0349
DEBUG - 2022-06-16 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:51:00 --> Total execution time: 0.0697
DEBUG - 2022-06-16 04:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:51:11 --> Total execution time: 0.0526
DEBUG - 2022-06-16 04:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:52:05 --> Total execution time: 0.0521
DEBUG - 2022-06-16 04:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:52:10 --> Total execution time: 0.0629
DEBUG - 2022-06-16 04:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:52:13 --> Total execution time: 0.0353
DEBUG - 2022-06-16 04:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 04:22:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 04:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 04:22:23 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-16 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:52:28 --> Total execution time: 0.0641
DEBUG - 2022-06-16 04:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 04:22:31 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-16 04:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:52:32 --> Total execution time: 0.0559
DEBUG - 2022-06-16 04:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 04:22:34 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-16 04:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:02 --> Total execution time: 0.1008
DEBUG - 2022-06-16 04:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:07 --> Total execution time: 0.1208
DEBUG - 2022-06-16 04:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:16 --> Total execution time: 0.0492
DEBUG - 2022-06-16 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:27 --> Total execution time: 0.0779
DEBUG - 2022-06-16 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:27 --> Total execution time: 0.0721
DEBUG - 2022-06-16 04:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:28 --> Total execution time: 0.0504
DEBUG - 2022-06-16 04:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:31 --> Total execution time: 0.0655
DEBUG - 2022-06-16 04:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:43 --> Total execution time: 0.0485
DEBUG - 2022-06-16 04:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:46 --> Total execution time: 0.0462
DEBUG - 2022-06-16 04:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:23:49 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:49 --> Total execution time: 0.0822
DEBUG - 2022-06-16 04:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:24:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:54:34 --> Total execution time: 0.0405
DEBUG - 2022-06-16 04:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:54:39 --> Total execution time: 0.0299
DEBUG - 2022-06-16 04:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:54:42 --> Total execution time: 0.1265
DEBUG - 2022-06-16 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:55:18 --> Total execution time: 0.0580
DEBUG - 2022-06-16 04:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:55:23 --> Total execution time: 0.0629
DEBUG - 2022-06-16 04:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:55:27 --> Total execution time: 0.0831
DEBUG - 2022-06-16 04:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:55:33 --> Total execution time: 0.0501
DEBUG - 2022-06-16 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:01:17 --> Total execution time: 0.4043
DEBUG - 2022-06-16 04:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:02:30 --> Total execution time: 0.0962
DEBUG - 2022-06-16 04:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:33:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:03:27 --> Total execution time: 0.0723
DEBUG - 2022-06-16 04:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:04:44 --> Total execution time: 0.1588
DEBUG - 2022-06-16 04:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:44:28 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:14:29 --> Total execution time: 0.2989
DEBUG - 2022-06-16 04:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:15:22 --> Total execution time: 0.0430
DEBUG - 2022-06-16 04:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:15:27 --> Total execution time: 0.0572
DEBUG - 2022-06-16 04:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:15:40 --> Total execution time: 0.0547
DEBUG - 2022-06-16 04:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:15:47 --> Total execution time: 0.0750
DEBUG - 2022-06-16 04:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:15:58 --> Total execution time: 0.0908
DEBUG - 2022-06-16 04:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:15:58 --> Total execution time: 0.0637
DEBUG - 2022-06-16 04:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:16:05 --> Total execution time: 0.0600
DEBUG - 2022-06-16 04:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:16:58 --> Total execution time: 0.0682
DEBUG - 2022-06-16 04:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:47:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:17:22 --> Total execution time: 0.0347
DEBUG - 2022-06-16 04:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:47:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:17:22 --> Total execution time: 0.0538
DEBUG - 2022-06-16 04:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:51:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:21:20 --> Total execution time: 0.1629
DEBUG - 2022-06-16 04:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:21:27 --> Total execution time: 0.0546
DEBUG - 2022-06-16 04:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:21:44 --> Total execution time: 0.0464
DEBUG - 2022-06-16 04:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:21:46 --> Total execution time: 0.0573
DEBUG - 2022-06-16 04:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:21:57 --> Total execution time: 0.0680
DEBUG - 2022-06-16 04:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:21:59 --> Total execution time: 0.0489
DEBUG - 2022-06-16 04:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:22:02 --> Total execution time: 0.0980
DEBUG - 2022-06-16 04:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:22:13 --> Total execution time: 0.0716
DEBUG - 2022-06-16 04:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:22:16 --> Total execution time: 0.0832
DEBUG - 2022-06-16 04:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:22:21 --> Total execution time: 0.0441
DEBUG - 2022-06-16 04:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:22:24 --> Total execution time: 0.1013
DEBUG - 2022-06-16 04:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:55:36 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:25:36 --> Total execution time: 0.0972
DEBUG - 2022-06-16 04:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:55:48 --> Total execution time: 0.0482
DEBUG - 2022-06-16 04:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:55:49 --> Total execution time: 0.0681
DEBUG - 2022-06-16 04:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:55:49 --> Total execution time: 0.1159
DEBUG - 2022-06-16 04:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:56:57 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:26:57 --> Total execution time: 0.0518
DEBUG - 2022-06-16 04:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:57:05 --> Total execution time: 0.0504
DEBUG - 2022-06-16 04:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:57:06 --> Total execution time: 0.0497
DEBUG - 2022-06-16 04:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 04:57:06 --> Total execution time: 0.0762
DEBUG - 2022-06-16 04:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 04:57:13 --> No URI present. Default controller set.
DEBUG - 2022-06-16 04:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 04:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:27:13 --> Total execution time: 0.0554
DEBUG - 2022-06-16 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:30:03 --> Total execution time: 0.1824
DEBUG - 2022-06-16 05:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:04:13 --> 404 Page Not Found: Category/uncategorized
DEBUG - 2022-06-16 05:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:06:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:06:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-16 05:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:38:46 --> Total execution time: 0.3401
DEBUG - 2022-06-16 05:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:09:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:09:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 05:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:39:04 --> Total execution time: 0.0845
DEBUG - 2022-06-16 05:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:11:02 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 05:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:11:02 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-16 05:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:44:48 --> Total execution time: 0.1288
DEBUG - 2022-06-16 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:47:01 --> Total execution time: 0.1120
DEBUG - 2022-06-16 05:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:17:51 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:47:51 --> Total execution time: 0.0409
DEBUG - 2022-06-16 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:23:11 --> 404 Page Not Found: Designer-bag-bingo-new-choices-fundraiser/esalestrix.in
DEBUG - 2022-06-16 05:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:25:57 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:55:57 --> Total execution time: 0.1476
DEBUG - 2022-06-16 05:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:57:38 --> Total execution time: 0.0391
DEBUG - 2022-06-16 05:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:59:00 --> Total execution time: 0.0577
DEBUG - 2022-06-16 05:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:59:01 --> Total execution time: 0.0394
DEBUG - 2022-06-16 05:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:59:03 --> Total execution time: 0.0392
DEBUG - 2022-06-16 05:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:59:04 --> Total execution time: 0.0492
DEBUG - 2022-06-16 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:59:06 --> Total execution time: 0.0479
DEBUG - 2022-06-16 05:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:59:09 --> Total execution time: 0.0721
DEBUG - 2022-06-16 05:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:59:11 --> Total execution time: 0.0722
DEBUG - 2022-06-16 05:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:02:05 --> Total execution time: 0.1958
DEBUG - 2022-06-16 05:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:06 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:02:06 --> Total execution time: 0.0517
DEBUG - 2022-06-16 05:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:02:12 --> Total execution time: 0.0287
DEBUG - 2022-06-16 05:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:02:32 --> Total execution time: 0.0713
DEBUG - 2022-06-16 05:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:02:37 --> Total execution time: 0.1006
DEBUG - 2022-06-16 05:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:02:47 --> Total execution time: 0.0613
DEBUG - 2022-06-16 05:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:02:49 --> Total execution time: 0.0570
DEBUG - 2022-06-16 05:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:02:52 --> Total execution time: 0.0637
DEBUG - 2022-06-16 05:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:03:02 --> Total execution time: 0.0819
DEBUG - 2022-06-16 05:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:04:47 --> Total execution time: 0.0702
DEBUG - 2022-06-16 05:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:35:22 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-16 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:07:25 --> Total execution time: 0.0436
DEBUG - 2022-06-16 05:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:07:32 --> Total execution time: 0.0410
DEBUG - 2022-06-16 05:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:07:41 --> Total execution time: 0.1758
DEBUG - 2022-06-16 05:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:41:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:11:06 --> Total execution time: 0.1641
DEBUG - 2022-06-16 05:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:11:25 --> Total execution time: 0.0396
DEBUG - 2022-06-16 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:42:45 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:12:45 --> Total execution time: 0.0392
DEBUG - 2022-06-16 05:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:14:22 --> Total execution time: 0.0406
DEBUG - 2022-06-16 05:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:44:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:14:50 --> Total execution time: 0.0372
DEBUG - 2022-06-16 05:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:15:00 --> Total execution time: 0.0513
DEBUG - 2022-06-16 05:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:15:18 --> Total execution time: 0.0743
DEBUG - 2022-06-16 05:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:15:27 --> Total execution time: 0.0761
DEBUG - 2022-06-16 05:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:15:49 --> Total execution time: 0.0485
DEBUG - 2022-06-16 05:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:01 --> Total execution time: 0.0705
DEBUG - 2022-06-16 05:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:04 --> Total execution time: 0.0660
DEBUG - 2022-06-16 05:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:13 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:13 --> Total execution time: 0.0394
DEBUG - 2022-06-16 05:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:20 --> Total execution time: 0.0440
DEBUG - 2022-06-16 05:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:21 --> Total execution time: 0.0633
DEBUG - 2022-06-16 05:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:28 --> Total execution time: 0.0360
DEBUG - 2022-06-16 05:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:34 --> Total execution time: 0.0539
DEBUG - 2022-06-16 05:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:46 --> Total execution time: 0.0466
DEBUG - 2022-06-16 05:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:16:46 --> Total execution time: 0.0421
DEBUG - 2022-06-16 05:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:17:03 --> Total execution time: 0.0503
DEBUG - 2022-06-16 05:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:17:08 --> Total execution time: 0.0509
DEBUG - 2022-06-16 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:17:20 --> Total execution time: 0.1536
DEBUG - 2022-06-16 05:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:17:30 --> Total execution time: 0.0568
DEBUG - 2022-06-16 05:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:17:34 --> Total execution time: 0.0974
DEBUG - 2022-06-16 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:17:44 --> Total execution time: 0.0406
DEBUG - 2022-06-16 05:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:18:17 --> Total execution time: 0.0433
DEBUG - 2022-06-16 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:50:16 --> 404 Page Not Found: Category/world
DEBUG - 2022-06-16 05:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:52:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:22:22 --> Total execution time: 0.0931
DEBUG - 2022-06-16 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:22:24 --> Total execution time: 0.0477
DEBUG - 2022-06-16 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:22:25 --> Total execution time: 0.0378
DEBUG - 2022-06-16 05:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:56:10 --> 404 Page Not Found: Learning-friendship-and-fun-for-everyone/index
DEBUG - 2022-06-16 05:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:56:11 --> No URI present. Default controller set.
DEBUG - 2022-06-16 05:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:26:11 --> Total execution time: 0.0806
DEBUG - 2022-06-16 05:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:26:13 --> Total execution time: 0.0620
DEBUG - 2022-06-16 05:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:27:11 --> Total execution time: 0.0669
DEBUG - 2022-06-16 05:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:27:24 --> Total execution time: 0.1151
DEBUG - 2022-06-16 05:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:27:32 --> Total execution time: 0.0442
DEBUG - 2022-06-16 05:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:27:37 --> Total execution time: 0.0711
DEBUG - 2022-06-16 05:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:27:38 --> Total execution time: 0.0856
DEBUG - 2022-06-16 05:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:27:43 --> Total execution time: 0.0396
DEBUG - 2022-06-16 05:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:59:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 05:59:28 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-16 05:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 05:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 05:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:29:34 --> Total execution time: 0.0532
DEBUG - 2022-06-16 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:30:02 --> Total execution time: 0.0800
DEBUG - 2022-06-16 06:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:00:16 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:30:16 --> Total execution time: 0.1030
DEBUG - 2022-06-16 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:32:46 --> Total execution time: 0.0975
DEBUG - 2022-06-16 06:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 06:03:41 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-16 06:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:05:10 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:35:10 --> Total execution time: 0.0343
DEBUG - 2022-06-16 06:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:36:16 --> Total execution time: 0.0529
DEBUG - 2022-06-16 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:36:47 --> Total execution time: 0.0473
DEBUG - 2022-06-16 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:37:01 --> Total execution time: 0.0414
DEBUG - 2022-06-16 06:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:07:18 --> Total execution time: 0.0518
DEBUG - 2022-06-16 06:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:07:19 --> Total execution time: 0.0711
DEBUG - 2022-06-16 06:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:07:19 --> Total execution time: 0.1047
DEBUG - 2022-06-16 06:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:36 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:37:36 --> Total execution time: 0.0542
DEBUG - 2022-06-16 06:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:07:42 --> Total execution time: 0.0546
DEBUG - 2022-06-16 06:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:07:44 --> Total execution time: 0.0709
DEBUG - 2022-06-16 06:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:07:44 --> Total execution time: 0.0796
DEBUG - 2022-06-16 06:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:46 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:37:46 --> Total execution time: 0.0540
DEBUG - 2022-06-16 06:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:37:54 --> Total execution time: 0.0368
DEBUG - 2022-06-16 06:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:38:00 --> Total execution time: 0.0476
DEBUG - 2022-06-16 06:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:38:02 --> Total execution time: 0.1166
DEBUG - 2022-06-16 06:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:38:13 --> Total execution time: 0.0629
DEBUG - 2022-06-16 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:38:25 --> Total execution time: 0.0481
DEBUG - 2022-06-16 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:38:34 --> Total execution time: 0.0988
DEBUG - 2022-06-16 06:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:38:42 --> Total execution time: 0.0506
DEBUG - 2022-06-16 06:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:38:43 --> Total execution time: 0.0882
DEBUG - 2022-06-16 06:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:38:57 --> Total execution time: 0.0575
DEBUG - 2022-06-16 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:39:06 --> Total execution time: 0.1043
DEBUG - 2022-06-16 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:39:23 --> Total execution time: 0.0638
DEBUG - 2022-06-16 06:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:39:34 --> Total execution time: 0.0411
DEBUG - 2022-06-16 06:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:39:40 --> Total execution time: 0.1173
DEBUG - 2022-06-16 06:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:40:09 --> Total execution time: 0.0543
DEBUG - 2022-06-16 06:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 06:11:32 --> 404 Page Not Found: Category/news
DEBUG - 2022-06-16 06:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:42:30 --> Total execution time: 0.0832
DEBUG - 2022-06-16 06:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:44:09 --> Total execution time: 0.1154
DEBUG - 2022-06-16 06:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:44:13 --> Total execution time: 0.0614
DEBUG - 2022-06-16 06:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:44:14 --> Total execution time: 0.0541
DEBUG - 2022-06-16 06:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:44:19 --> Total execution time: 0.0535
DEBUG - 2022-06-16 06:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:14:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:44:19 --> Total execution time: 0.0657
DEBUG - 2022-06-16 06:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:14:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:44:19 --> Total execution time: 0.0358
DEBUG - 2022-06-16 06:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 06:14:48 --> 404 Page Not Found: News/feed
DEBUG - 2022-06-16 06:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:44:57 --> Total execution time: 0.0894
DEBUG - 2022-06-16 06:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 06:15:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:46:46 --> Total execution time: 0.0296
DEBUG - 2022-06-16 06:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:46:51 --> Total execution time: 0.0627
DEBUG - 2022-06-16 06:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:46:59 --> Total execution time: 0.0644
DEBUG - 2022-06-16 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:08 --> Total execution time: 0.0733
DEBUG - 2022-06-16 06:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:23 --> Total execution time: 0.0628
DEBUG - 2022-06-16 06:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:28 --> Total execution time: 0.0455
DEBUG - 2022-06-16 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:45 --> Total execution time: 0.0663
DEBUG - 2022-06-16 06:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:17:49 --> Total execution time: 0.0368
DEBUG - 2022-06-16 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:18:33 --> Total execution time: 0.0713
DEBUG - 2022-06-16 06:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:18:37 --> Total execution time: 0.0533
DEBUG - 2022-06-16 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:18:39 --> Total execution time: 0.0485
DEBUG - 2022-06-16 06:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:18:40 --> Total execution time: 0.0449
DEBUG - 2022-06-16 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:18:41 --> Total execution time: 0.0390
DEBUG - 2022-06-16 06:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:48:43 --> Total execution time: 0.0793
DEBUG - 2022-06-16 06:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:49:01 --> Total execution time: 0.1024
DEBUG - 2022-06-16 06:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:49:59 --> Total execution time: 0.1339
DEBUG - 2022-06-16 06:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:00 --> Total execution time: 0.1634
DEBUG - 2022-06-16 06:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:01 --> Total execution time: 0.1111
DEBUG - 2022-06-16 06:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:08 --> Total execution time: 0.0561
DEBUG - 2022-06-16 06:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:09 --> Total execution time: 0.0568
DEBUG - 2022-06-16 06:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:15 --> Total execution time: 0.0654
DEBUG - 2022-06-16 06:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:20 --> Total execution time: 0.0486
DEBUG - 2022-06-16 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:23 --> Total execution time: 0.0444
DEBUG - 2022-06-16 06:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:30 --> Total execution time: 0.0710
DEBUG - 2022-06-16 06:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:34 --> Total execution time: 0.0678
DEBUG - 2022-06-16 06:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:51 --> Total execution time: 0.0709
DEBUG - 2022-06-16 06:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:20:58 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:58 --> Total execution time: 0.1026
DEBUG - 2022-06-16 06:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:21:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:09 --> Total execution time: 0.0590
DEBUG - 2022-06-16 06:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:20 --> Total execution time: 0.0812
DEBUG - 2022-06-16 06:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:33 --> Total execution time: 0.0526
DEBUG - 2022-06-16 06:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:37 --> Total execution time: 0.0571
DEBUG - 2022-06-16 06:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:44 --> Total execution time: 0.0652
DEBUG - 2022-06-16 06:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 06:21:53 --> 404 Page Not Found: Appphp/feed
DEBUG - 2022-06-16 06:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:58 --> Total execution time: 0.0779
DEBUG - 2022-06-16 06:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:52:50 --> Total execution time: 0.0449
DEBUG - 2022-06-16 06:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:23:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:53:44 --> Total execution time: 0.0498
DEBUG - 2022-06-16 06:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:53:48 --> Total execution time: 0.0670
DEBUG - 2022-06-16 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:54:54 --> Total execution time: 0.0377
DEBUG - 2022-06-16 06:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:55:06 --> Total execution time: 0.0606
DEBUG - 2022-06-16 06:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:55:10 --> Total execution time: 0.0437
DEBUG - 2022-06-16 06:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:55:18 --> Total execution time: 0.0549
DEBUG - 2022-06-16 06:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:55:26 --> Total execution time: 0.0713
DEBUG - 2022-06-16 06:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:55:35 --> Total execution time: 0.0632
DEBUG - 2022-06-16 06:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:55:43 --> Total execution time: 0.0528
DEBUG - 2022-06-16 06:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:55:52 --> Total execution time: 0.0601
DEBUG - 2022-06-16 06:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:55:58 --> Total execution time: 0.0568
DEBUG - 2022-06-16 06:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:27:36 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:57:36 --> Total execution time: 0.1126
DEBUG - 2022-06-16 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:28:26 --> Total execution time: 0.1074
DEBUG - 2022-06-16 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:28:29 --> Total execution time: 0.0487
DEBUG - 2022-06-16 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:28:29 --> Total execution time: 0.0734
DEBUG - 2022-06-16 06:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:59:26 --> Total execution time: 0.0419
DEBUG - 2022-06-16 06:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:29:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 06:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:59:37 --> Total execution time: 1.9225
DEBUG - 2022-06-16 06:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:59:42 --> Total execution time: 0.0493
DEBUG - 2022-06-16 06:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:59:48 --> Total execution time: 0.0628
DEBUG - 2022-06-16 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 06:30:39 --> 404 Page Not Found: Blog/feed
DEBUG - 2022-06-16 06:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 06:31:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-16 06:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:31:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 06:31:23 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-16 06:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:34:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:04:22 --> Total execution time: 0.1360
DEBUG - 2022-06-16 06:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:04:33 --> Total execution time: 0.0402
DEBUG - 2022-06-16 06:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:04:41 --> Total execution time: 0.0456
DEBUG - 2022-06-16 06:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:04:54 --> Total execution time: 0.0789
DEBUG - 2022-06-16 06:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:36:55 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:06:55 --> Total execution time: 0.0391
DEBUG - 2022-06-16 06:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:36:56 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:06:56 --> Total execution time: 0.0410
DEBUG - 2022-06-16 06:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:09:01 --> Total execution time: 0.4976
DEBUG - 2022-06-16 06:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:09:44 --> Total execution time: 0.0789
DEBUG - 2022-06-16 06:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:10:00 --> Total execution time: 0.1265
DEBUG - 2022-06-16 06:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:10:05 --> Total execution time: 0.0888
DEBUG - 2022-06-16 06:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:10:11 --> Total execution time: 0.0456
DEBUG - 2022-06-16 06:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:10:15 --> Total execution time: 0.0537
DEBUG - 2022-06-16 06:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:10:20 --> Total execution time: 0.0544
DEBUG - 2022-06-16 06:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:10:25 --> Total execution time: 0.0596
DEBUG - 2022-06-16 06:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:10:49 --> Total execution time: 0.0701
DEBUG - 2022-06-16 06:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:40:52 --> Total execution time: 0.0495
DEBUG - 2022-06-16 06:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:11:36 --> Total execution time: 0.0506
DEBUG - 2022-06-16 06:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:41:55 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:11:55 --> Total execution time: 0.0580
DEBUG - 2022-06-16 06:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:06 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:12:06 --> Total execution time: 0.0900
DEBUG - 2022-06-16 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:42:21 --> Total execution time: 0.0467
DEBUG - 2022-06-16 06:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:42:30 --> Total execution time: 0.0525
DEBUG - 2022-06-16 06:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:12:30 --> Total execution time: 0.0336
DEBUG - 2022-06-16 06:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:12:33 --> Total execution time: 0.0668
DEBUG - 2022-06-16 06:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:12:35 --> Total execution time: 0.0607
DEBUG - 2022-06-16 06:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:42:39 --> Total execution time: 0.0769
DEBUG - 2022-06-16 06:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:12:51 --> Total execution time: 0.0638
DEBUG - 2022-06-16 06:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:13:00 --> Total execution time: 0.0495
DEBUG - 2022-06-16 06:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:43:08 --> Total execution time: 0.0407
DEBUG - 2022-06-16 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:43:21 --> Total execution time: 0.0537
DEBUG - 2022-06-16 06:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:13:23 --> Total execution time: 0.0513
DEBUG - 2022-06-16 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:13:36 --> Total execution time: 0.0449
DEBUG - 2022-06-16 06:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:13:42 --> Total execution time: 0.0821
DEBUG - 2022-06-16 06:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:13:44 --> Total execution time: 0.1447
DEBUG - 2022-06-16 06:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:13:54 --> Total execution time: 0.0470
DEBUG - 2022-06-16 06:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:13:58 --> Total execution time: 0.0500
DEBUG - 2022-06-16 06:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:03 --> Total execution time: 0.0461
DEBUG - 2022-06-16 06:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:12 --> Total execution time: 0.0465
DEBUG - 2022-06-16 06:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:16 --> Total execution time: 0.0452
DEBUG - 2022-06-16 06:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:14:22 --> Total execution time: 0.1080
DEBUG - 2022-06-16 06:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:14:24 --> Total execution time: 0.0677
DEBUG - 2022-06-16 06:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:25 --> Total execution time: 0.0774
DEBUG - 2022-06-16 06:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:29 --> Total execution time: 0.0438
DEBUG - 2022-06-16 06:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:32 --> Total execution time: 0.0575
DEBUG - 2022-06-16 06:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:44:34 --> Total execution time: 0.0373
DEBUG - 2022-06-16 06:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:14:35 --> Total execution time: 0.0598
DEBUG - 2022-06-16 06:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:14:42 --> Total execution time: 0.1629
DEBUG - 2022-06-16 06:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:14:50 --> Total execution time: 0.0551
DEBUG - 2022-06-16 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:14:54 --> Total execution time: 0.0510
DEBUG - 2022-06-16 06:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:14:56 --> Total execution time: 0.0598
DEBUG - 2022-06-16 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:01 --> Total execution time: 0.1370
DEBUG - 2022-06-16 06:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:01 --> Total execution time: 0.0896
DEBUG - 2022-06-16 06:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:12 --> Total execution time: 0.0682
DEBUG - 2022-06-16 06:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:12 --> Total execution time: 0.0685
DEBUG - 2022-06-16 06:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:13 --> Total execution time: 0.0652
DEBUG - 2022-06-16 06:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:13 --> Total execution time: 0.0430
DEBUG - 2022-06-16 06:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:13 --> Total execution time: 0.0483
DEBUG - 2022-06-16 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:15 --> Total execution time: 0.0483
DEBUG - 2022-06-16 06:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:17 --> Total execution time: 0.0905
DEBUG - 2022-06-16 06:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:25 --> Total execution time: 0.0503
DEBUG - 2022-06-16 06:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:27 --> Total execution time: 0.0587
DEBUG - 2022-06-16 06:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:45:41 --> Total execution time: 0.0551
DEBUG - 2022-06-16 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:43 --> Total execution time: 0.1043
DEBUG - 2022-06-16 06:45:43 --> Total execution time: 0.1654
DEBUG - 2022-06-16 06:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:45:43 --> Total execution time: 0.1908
DEBUG - 2022-06-16 06:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:45:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:50 --> Total execution time: 0.0435
DEBUG - 2022-06-16 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:16:16 --> Total execution time: 0.0614
DEBUG - 2022-06-16 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:16:40 --> Total execution time: 0.0486
DEBUG - 2022-06-16 06:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:16:47 --> Total execution time: 0.0514
DEBUG - 2022-06-16 06:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:16:51 --> Total execution time: 0.0445
DEBUG - 2022-06-16 06:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:47:36 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:17:36 --> Total execution time: 0.0885
DEBUG - 2022-06-16 06:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:50:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:20:53 --> Total execution time: 0.1168
DEBUG - 2022-06-16 06:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:50:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:20:53 --> Total execution time: 0.0485
DEBUG - 2022-06-16 06:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:20:56 --> Total execution time: 0.0297
DEBUG - 2022-06-16 06:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:21:06 --> Total execution time: 0.0451
DEBUG - 2022-06-16 06:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:21:34 --> Total execution time: 0.0397
DEBUG - 2022-06-16 06:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:21:38 --> Total execution time: 0.0510
DEBUG - 2022-06-16 06:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:21:43 --> Total execution time: 0.0430
DEBUG - 2022-06-16 06:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:21:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 06:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:21:44 --> Total execution time: 0.0714
DEBUG - 2022-06-16 06:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:52:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:22:25 --> Total execution time: 0.0531
DEBUG - 2022-06-16 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:22:29 --> Total execution time: 0.0491
DEBUG - 2022-06-16 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:22:30 --> Total execution time: 0.0541
DEBUG - 2022-06-16 06:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:22:43 --> Total execution time: 0.0814
DEBUG - 2022-06-16 06:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:24:00 --> Total execution time: 0.0578
DEBUG - 2022-06-16 06:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:24:07 --> Total execution time: 0.0719
DEBUG - 2022-06-16 06:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:55:06 --> No URI present. Default controller set.
DEBUG - 2022-06-16 06:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:25:06 --> Total execution time: 0.0533
DEBUG - 2022-06-16 06:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:26:26 --> Total execution time: 0.0588
DEBUG - 2022-06-16 06:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:26:40 --> Total execution time: 0.0491
DEBUG - 2022-06-16 06:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:56:44 --> Total execution time: 0.0465
DEBUG - 2022-06-16 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:57:06 --> Total execution time: 0.0372
DEBUG - 2022-06-16 06:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 06:57:14 --> Total execution time: 0.0819
DEBUG - 2022-06-16 06:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:27:16 --> Total execution time: 0.0516
DEBUG - 2022-06-16 06:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:27:18 --> Total execution time: 0.0471
DEBUG - 2022-06-16 06:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:27:26 --> Total execution time: 0.0557
DEBUG - 2022-06-16 06:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:27:35 --> Total execution time: 0.0485
DEBUG - 2022-06-16 06:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:27:41 --> Total execution time: 0.0751
DEBUG - 2022-06-16 06:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:27:47 --> Total execution time: 0.0719
DEBUG - 2022-06-16 06:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:27:54 --> Total execution time: 0.0916
DEBUG - 2022-06-16 06:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:27:58 --> Total execution time: 0.0503
DEBUG - 2022-06-16 06:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 06:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 06:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:28:15 --> Total execution time: 0.0535
DEBUG - 2022-06-16 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:30:04 --> Total execution time: 0.0535
DEBUG - 2022-06-16 07:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:01:12 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:31:12 --> Total execution time: 0.0445
DEBUG - 2022-06-16 07:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:32:22 --> Total execution time: 0.0488
DEBUG - 2022-06-16 07:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:32:35 --> Total execution time: 0.0507
DEBUG - 2022-06-16 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:32:46 --> Total execution time: 0.0790
DEBUG - 2022-06-16 07:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:32:54 --> Total execution time: 0.0483
DEBUG - 2022-06-16 07:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:33:43 --> Total execution time: 0.0521
DEBUG - 2022-06-16 07:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:34:02 --> Total execution time: 0.1430
DEBUG - 2022-06-16 07:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:35:02 --> Total execution time: 0.0590
DEBUG - 2022-06-16 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:08:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:38:47 --> Total execution time: 0.1286
DEBUG - 2022-06-16 07:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:38:50 --> Total execution time: 0.0480
DEBUG - 2022-06-16 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:38:59 --> Total execution time: 0.0468
DEBUG - 2022-06-16 07:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:39:05 --> Total execution time: 0.0466
DEBUG - 2022-06-16 07:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:39:25 --> Total execution time: 0.0454
DEBUG - 2022-06-16 07:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:39:27 --> Total execution time: 0.0465
DEBUG - 2022-06-16 07:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:09:57 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:39:57 --> Total execution time: 0.0490
DEBUG - 2022-06-16 07:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:40:39 --> Total execution time: 0.0301
DEBUG - 2022-06-16 07:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:41:06 --> Total execution time: 0.0391
DEBUG - 2022-06-16 07:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:11:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:11:09 --> 404 Page Not Found: Category/opinion
DEBUG - 2022-06-16 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:41:19 --> Total execution time: 0.0464
DEBUG - 2022-06-16 07:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:11:33 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-16 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:42:13 --> Total execution time: 0.0639
DEBUG - 2022-06-16 07:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:12:16 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:42:16 --> Total execution time: 0.0473
DEBUG - 2022-06-16 07:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:12:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:42:32 --> Total execution time: 0.0674
DEBUG - 2022-06-16 07:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:43:13 --> Total execution time: 0.0504
DEBUG - 2022-06-16 07:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:43:14 --> Total execution time: 0.0572
DEBUG - 2022-06-16 07:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:43:30 --> Total execution time: 0.0599
DEBUG - 2022-06-16 07:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:43:34 --> Total execution time: 0.0555
DEBUG - 2022-06-16 07:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:43:52 --> Total execution time: 0.0448
DEBUG - 2022-06-16 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:44:00 --> Total execution time: 0.0467
DEBUG - 2022-06-16 07:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:44:08 --> Total execution time: 0.0651
DEBUG - 2022-06-16 07:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:14:26 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:44:26 --> Total execution time: 0.0411
DEBUG - 2022-06-16 07:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:15:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:15:09 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 07:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:16:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:46:22 --> Total execution time: 0.0414
DEBUG - 2022-06-16 07:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:46:36 --> Total execution time: 0.0457
DEBUG - 2022-06-16 07:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:47:35 --> Total execution time: 0.1060
DEBUG - 2022-06-16 07:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:47:46 --> Total execution time: 0.1274
DEBUG - 2022-06-16 07:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:47:49 --> Total execution time: 0.0455
DEBUG - 2022-06-16 07:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:47:55 --> Total execution time: 0.0433
DEBUG - 2022-06-16 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:17:57 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:47:57 --> Total execution time: 0.0535
DEBUG - 2022-06-16 07:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:48:05 --> Total execution time: 0.1094
DEBUG - 2022-06-16 07:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:48:07 --> Total execution time: 0.0715
DEBUG - 2022-06-16 07:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:48:08 --> Total execution time: 0.0447
DEBUG - 2022-06-16 07:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:48:12 --> Total execution time: 0.0727
DEBUG - 2022-06-16 07:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:18:15 --> 404 Page Not Found: Category/lifestyle
DEBUG - 2022-06-16 07:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:48:32 --> Total execution time: 0.2826
DEBUG - 2022-06-16 07:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:48:38 --> Total execution time: 0.0838
DEBUG - 2022-06-16 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:48:44 --> Total execution time: 0.0451
DEBUG - 2022-06-16 07:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:48:58 --> Total execution time: 0.0633
DEBUG - 2022-06-16 07:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:49:03 --> Total execution time: 0.0442
DEBUG - 2022-06-16 07:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:49:10 --> Total execution time: 0.0801
DEBUG - 2022-06-16 07:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:49:27 --> Total execution time: 0.0688
DEBUG - 2022-06-16 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:49:48 --> Total execution time: 0.0456
DEBUG - 2022-06-16 07:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:49:49 --> Total execution time: 0.0671
DEBUG - 2022-06-16 07:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:50:12 --> Total execution time: 0.0636
DEBUG - 2022-06-16 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:50:22 --> Total execution time: 0.0654
DEBUG - 2022-06-16 07:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:50:31 --> Total execution time: 0.0664
DEBUG - 2022-06-16 07:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:50:41 --> Total execution time: 0.0598
DEBUG - 2022-06-16 07:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:50:46 --> Total execution time: 0.0876
DEBUG - 2022-06-16 07:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:50:57 --> Total execution time: 0.0382
DEBUG - 2022-06-16 07:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:51:01 --> Total execution time: 0.0769
DEBUG - 2022-06-16 07:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:51:02 --> Total execution time: 0.2152
DEBUG - 2022-06-16 07:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:23:58 --> Total execution time: 0.1110
DEBUG - 2022-06-16 07:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:24:10 --> Total execution time: 0.0771
DEBUG - 2022-06-16 07:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:26:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:26:03 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-16 07:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:27:07 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-16 07:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:57:40 --> Total execution time: 0.0804
DEBUG - 2022-06-16 07:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:57:54 --> Total execution time: 0.1040
DEBUG - 2022-06-16 07:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:58:28 --> Total execution time: 0.1051
DEBUG - 2022-06-16 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:28:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:28:58 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-16 07:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:29:06 --> 404 Page Not Found: Category/technology
DEBUG - 2022-06-16 07:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:12 --> Total execution time: 0.0512
DEBUG - 2022-06-16 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:40 --> Total execution time: 0.0662
DEBUG - 2022-06-16 07:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:50 --> Total execution time: 0.0623
DEBUG - 2022-06-16 07:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:53 --> Total execution time: 0.0831
DEBUG - 2022-06-16 07:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:01:03 --> Total execution time: 0.0860
DEBUG - 2022-06-16 07:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:01:07 --> Total execution time: 0.0639
DEBUG - 2022-06-16 07:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:01:20 --> Total execution time: 0.0568
DEBUG - 2022-06-16 07:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:34:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:34:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:04:27 --> Total execution time: 0.1270
DEBUG - 2022-06-16 07:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:04:48 --> Total execution time: 0.0690
DEBUG - 2022-06-16 07:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:38:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:38:31 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-16 07:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:08:41 --> Total execution time: 0.1588
DEBUG - 2022-06-16 07:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:10:37 --> Total execution time: 0.0480
DEBUG - 2022-06-16 07:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:40:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:10:40 --> Total execution time: 0.0482
DEBUG - 2022-06-16 07:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:40:55 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:10:55 --> Total execution time: 0.0365
DEBUG - 2022-06-16 07:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:41:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:11:15 --> Total execution time: 0.0489
DEBUG - 2022-06-16 07:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:41:46 --> Total execution time: 0.0522
DEBUG - 2022-06-16 07:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:41:48 --> Total execution time: 0.0432
DEBUG - 2022-06-16 07:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:41:48 --> Total execution time: 0.1183
DEBUG - 2022-06-16 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:42:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:42:51 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:12:51 --> Total execution time: 0.0371
DEBUG - 2022-06-16 18:12:51 --> Total execution time: 1.9515
DEBUG - 2022-06-16 07:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:12:52 --> Total execution time: 0.0608
DEBUG - 2022-06-16 07:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:13:10 --> Total execution time: 0.0629
DEBUG - 2022-06-16 07:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:13:15 --> Total execution time: 0.0817
DEBUG - 2022-06-16 07:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:13:16 --> Total execution time: 0.0745
DEBUG - 2022-06-16 07:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:43:23 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:13:23 --> Total execution time: 0.0398
DEBUG - 2022-06-16 07:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:43:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:13:35 --> Total execution time: 1.4819
DEBUG - 2022-06-16 07:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:13:35 --> Total execution time: 1.1794
DEBUG - 2022-06-16 07:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:13:43 --> Total execution time: 1.4901
DEBUG - 2022-06-16 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:43:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:14:13 --> Total execution time: 1.4981
DEBUG - 2022-06-16 07:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:44:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:14:40 --> Total execution time: 0.0551
DEBUG - 2022-06-16 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:44:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:14:40 --> Total execution time: 0.0446
DEBUG - 2022-06-16 07:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:44:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:14:40 --> Total execution time: 0.0423
DEBUG - 2022-06-16 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:44:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:14:41 --> Total execution time: 0.0449
DEBUG - 2022-06-16 07:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:15:03 --> Total execution time: 0.0581
DEBUG - 2022-06-16 07:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:15:19 --> Total execution time: 0.1429
DEBUG - 2022-06-16 07:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:46:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:16:00 --> Total execution time: 0.0309
DEBUG - 2022-06-16 07:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:46:11 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:16:11 --> Total execution time: 0.0412
DEBUG - 2022-06-16 07:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:16:14 --> Total execution time: 0.0381
DEBUG - 2022-06-16 07:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:16:38 --> Total execution time: 0.0345
DEBUG - 2022-06-16 07:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:16:50 --> Total execution time: 0.0507
DEBUG - 2022-06-16 07:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:17:07 --> Total execution time: 0.0403
DEBUG - 2022-06-16 07:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:17:14 --> Total execution time: 0.0453
DEBUG - 2022-06-16 07:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:17:18 --> Total execution time: 0.0401
DEBUG - 2022-06-16 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:47:21 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:17:21 --> Total execution time: 0.0422
DEBUG - 2022-06-16 07:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:47:51 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:17:51 --> Total execution time: 0.0423
DEBUG - 2022-06-16 07:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:48:16 --> Total execution time: 0.0555
DEBUG - 2022-06-16 07:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:48:17 --> Total execution time: 0.0618
DEBUG - 2022-06-16 07:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:48:17 --> Total execution time: 0.1152
DEBUG - 2022-06-16 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:49:08 --> Total execution time: 0.0414
DEBUG - 2022-06-16 07:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:49:09 --> Total execution time: 0.0420
DEBUG - 2022-06-16 07:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:49:09 --> Total execution time: 0.0882
DEBUG - 2022-06-16 07:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:49:17 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:19:17 --> Total execution time: 0.0605
DEBUG - 2022-06-16 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:49:28 --> Total execution time: 0.0549
DEBUG - 2022-06-16 07:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:49:29 --> Total execution time: 0.0522
DEBUG - 2022-06-16 07:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:49:29 --> Total execution time: 0.1280
DEBUG - 2022-06-16 07:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:50:03 --> Total execution time: 0.0472
DEBUG - 2022-06-16 07:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:50:04 --> Total execution time: 0.0588
DEBUG - 2022-06-16 07:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:50:04 --> Total execution time: 0.1408
DEBUG - 2022-06-16 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:50:12 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:20:12 --> Total execution time: 0.0491
DEBUG - 2022-06-16 07:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:20:16 --> Total execution time: 0.0380
DEBUG - 2022-06-16 07:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:50:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:20:47 --> Total execution time: 0.0839
DEBUG - 2022-06-16 07:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:20:47 --> Total execution time: 0.1207
DEBUG - 2022-06-16 07:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:51:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:21:05 --> Total execution time: 0.0588
DEBUG - 2022-06-16 07:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:51:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:21:47 --> Total execution time: 0.0635
DEBUG - 2022-06-16 07:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:22:18 --> Total execution time: 0.0437
DEBUG - 2022-06-16 07:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:22:21 --> Total execution time: 0.0354
DEBUG - 2022-06-16 07:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:22:24 --> Total execution time: 0.0400
DEBUG - 2022-06-16 07:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:22:25 --> Total execution time: 0.0736
DEBUG - 2022-06-16 07:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:22:37 --> Total execution time: 0.0423
DEBUG - 2022-06-16 07:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:22:41 --> Total execution time: 0.0620
DEBUG - 2022-06-16 07:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:22:48 --> Total execution time: 1.5687
DEBUG - 2022-06-16 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:52:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 07:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:52:55 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:22:55 --> Total execution time: 0.0365
DEBUG - 2022-06-16 07:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:23:01 --> Total execution time: 0.1004
DEBUG - 2022-06-16 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:23:34 --> Total execution time: 0.0475
DEBUG - 2022-06-16 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:24:20 --> Total execution time: 0.0610
DEBUG - 2022-06-16 07:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:24:27 --> Total execution time: 0.0517
DEBUG - 2022-06-16 07:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:24:33 --> Total execution time: 0.0713
DEBUG - 2022-06-16 07:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:55:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 07:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:25:34 --> Total execution time: 0.1586
DEBUG - 2022-06-16 07:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 07:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:27:43 --> Total execution time: 0.1735
DEBUG - 2022-06-16 07:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 07:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 07:58:23 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-06-16 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:30:03 --> Total execution time: 0.0635
DEBUG - 2022-06-16 08:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:05:07 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:35:08 --> Total execution time: 0.1580
DEBUG - 2022-06-16 08:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:35:27 --> Total execution time: 0.0337
DEBUG - 2022-06-16 08:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:35:52 --> Total execution time: 0.0941
DEBUG - 2022-06-16 08:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:02 --> Total execution time: 0.0704
DEBUG - 2022-06-16 08:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:07 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:07 --> Total execution time: 0.0515
DEBUG - 2022-06-16 08:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:11 --> Total execution time: 0.0595
DEBUG - 2022-06-16 08:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:16 --> Total execution time: 0.0430
DEBUG - 2022-06-16 08:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:33 --> Total execution time: 0.0546
DEBUG - 2022-06-16 08:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:41 --> Total execution time: 0.1035
DEBUG - 2022-06-16 08:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:44 --> Total execution time: 0.0442
DEBUG - 2022-06-16 08:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:48 --> Total execution time: 0.0566
DEBUG - 2022-06-16 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:52 --> Total execution time: 0.0615
DEBUG - 2022-06-16 08:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:36:54 --> Total execution time: 0.0763
DEBUG - 2022-06-16 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:10:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:10:49 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-06-16 08:10:49 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-16 08:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:10:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:10:50 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-16 08:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:10:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:10:50 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-16 08:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:10:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:10:51 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-16 08:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:10:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:10:51 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-16 08:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:10:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:10:52 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-16 08:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:10:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:10:52 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-16 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:42:15 --> Total execution time: 0.0623
DEBUG - 2022-06-16 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:12:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:42:59 --> Total execution time: 0.1044
DEBUG - 2022-06-16 08:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:43:05 --> Total execution time: 0.0599
DEBUG - 2022-06-16 08:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:43:09 --> Total execution time: 0.0847
DEBUG - 2022-06-16 08:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:43:12 --> Total execution time: 0.0654
DEBUG - 2022-06-16 08:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:43:15 --> Total execution time: 0.0323
DEBUG - 2022-06-16 08:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:43:15 --> Total execution time: 0.0334
DEBUG - 2022-06-16 08:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:13:31 --> Total execution time: 0.0325
DEBUG - 2022-06-16 08:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:13:32 --> Total execution time: 0.0561
DEBUG - 2022-06-16 08:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:13:32 --> Total execution time: 0.0696
DEBUG - 2022-06-16 08:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:43:50 --> Total execution time: 0.0423
DEBUG - 2022-06-16 08:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:13:56 --> Total execution time: 0.0730
DEBUG - 2022-06-16 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:13:57 --> Total execution time: 0.0839
DEBUG - 2022-06-16 08:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:13:57 --> Total execution time: 0.0901
DEBUG - 2022-06-16 08:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:44:19 --> Total execution time: 0.0386
DEBUG - 2022-06-16 08:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:23 --> Total execution time: 0.0459
DEBUG - 2022-06-16 08:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:24 --> Total execution time: 0.0652
DEBUG - 2022-06-16 08:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:25 --> Total execution time: 0.0907
DEBUG - 2022-06-16 08:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:44:27 --> Total execution time: 0.0816
DEBUG - 2022-06-16 08:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:44:28 --> Total execution time: 0.0639
DEBUG - 2022-06-16 08:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:35 --> Total execution time: 0.0579
DEBUG - 2022-06-16 08:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:36 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:44:36 --> Total execution time: 0.0442
DEBUG - 2022-06-16 08:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:38 --> Total execution time: 0.0675
DEBUG - 2022-06-16 08:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:39 --> Total execution time: 0.0896
DEBUG - 2022-06-16 08:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:39 --> Total execution time: 0.1150
DEBUG - 2022-06-16 08:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:44:40 --> Total execution time: 0.0974
DEBUG - 2022-06-16 08:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:44:44 --> Total execution time: 0.1421
DEBUG - 2022-06-16 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:44:51 --> Total execution time: 0.0752
DEBUG - 2022-06-16 08:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:44:54 --> Total execution time: 0.0556
DEBUG - 2022-06-16 08:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:17:25 --> Total execution time: 0.0823
DEBUG - 2022-06-16 08:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:17:26 --> Total execution time: 0.0516
DEBUG - 2022-06-16 08:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:17:26 --> Total execution time: 0.1118
DEBUG - 2022-06-16 08:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:47:33 --> Total execution time: 0.0364
DEBUG - 2022-06-16 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:49:21 --> Total execution time: 0.0617
DEBUG - 2022-06-16 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:49:25 --> Total execution time: 0.0985
DEBUG - 2022-06-16 08:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:49:29 --> Total execution time: 0.0443
DEBUG - 2022-06-16 08:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:49:32 --> Total execution time: 0.0532
DEBUG - 2022-06-16 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:19:41 --> 404 Page Not Found: Accessonphp/index
DEBUG - 2022-06-16 08:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:49:42 --> Total execution time: 0.0440
DEBUG - 2022-06-16 08:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:49:43 --> Total execution time: 0.0600
DEBUG - 2022-06-16 08:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:49:46 --> Total execution time: 0.0499
DEBUG - 2022-06-16 08:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:50:25 --> Total execution time: 0.0408
DEBUG - 2022-06-16 08:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:50:38 --> Total execution time: 0.0568
DEBUG - 2022-06-16 08:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:50:41 --> Total execution time: 0.0499
DEBUG - 2022-06-16 08:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:50:49 --> Total execution time: 0.0536
DEBUG - 2022-06-16 08:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:51:47 --> Total execution time: 0.0513
DEBUG - 2022-06-16 08:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:11 --> Total execution time: 0.1106
DEBUG - 2022-06-16 08:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:12 --> Total execution time: 0.0791
DEBUG - 2022-06-16 08:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:15 --> Total execution time: 0.0504
DEBUG - 2022-06-16 08:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:19 --> Total execution time: 0.0525
DEBUG - 2022-06-16 08:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:25 --> Total execution time: 0.0492
DEBUG - 2022-06-16 08:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:36 --> Total execution time: 0.0463
DEBUG - 2022-06-16 08:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:43 --> Total execution time: 0.0668
DEBUG - 2022-06-16 08:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:44 --> Total execution time: 0.0423
DEBUG - 2022-06-16 08:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:50 --> Total execution time: 0.0514
DEBUG - 2022-06-16 08:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:53:54 --> Total execution time: 0.0449
DEBUG - 2022-06-16 08:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:23:59 --> Total execution time: 0.0631
DEBUG - 2022-06-16 08:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:54:02 --> Total execution time: 0.0576
DEBUG - 2022-06-16 08:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:54:18 --> Total execution time: 0.0656
DEBUG - 2022-06-16 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:54:33 --> Total execution time: 0.1300
DEBUG - 2022-06-16 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:54:36 --> Total execution time: 0.0420
DEBUG - 2022-06-16 08:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:25:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:25:47 --> 404 Page Not Found: Category/features
DEBUG - 2022-06-16 08:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:56:56 --> Total execution time: 0.1727
DEBUG - 2022-06-16 08:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:57:01 --> Total execution time: 0.0779
DEBUG - 2022-06-16 08:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:57:02 --> Total execution time: 0.0479
DEBUG - 2022-06-16 08:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:57:05 --> Total execution time: 0.1077
DEBUG - 2022-06-16 08:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:57:19 --> Total execution time: 0.0668
DEBUG - 2022-06-16 08:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:57:24 --> Total execution time: 0.0557
DEBUG - 2022-06-16 08:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:57:27 --> Total execution time: 0.0782
DEBUG - 2022-06-16 08:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:57:31 --> Total execution time: 0.0446
DEBUG - 2022-06-16 08:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:36 --> Total execution time: 0.0490
DEBUG - 2022-06-16 08:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:57:38 --> Total execution time: 0.0893
DEBUG - 2022-06-16 08:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:43 --> Total execution time: 0.0368
DEBUG - 2022-06-16 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:47 --> Total execution time: 0.0639
DEBUG - 2022-06-16 08:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:53 --> Total execution time: 0.0402
DEBUG - 2022-06-16 08:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:27:58 --> Total execution time: 0.0592
DEBUG - 2022-06-16 08:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:28:02 --> Total execution time: 0.0402
DEBUG - 2022-06-16 08:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:28:04 --> Total execution time: 0.0431
DEBUG - 2022-06-16 08:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:28:05 --> Total execution time: 0.0393
DEBUG - 2022-06-16 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:58:07 --> Total execution time: 0.0477
DEBUG - 2022-06-16 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:58:13 --> Total execution time: 0.1177
DEBUG - 2022-06-16 08:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:58:16 --> Total execution time: 0.0645
DEBUG - 2022-06-16 08:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:28:32 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-16 08:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:58:36 --> Total execution time: 0.0742
DEBUG - 2022-06-16 08:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:58:39 --> Total execution time: 0.0763
DEBUG - 2022-06-16 08:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:58:43 --> Total execution time: 0.0496
DEBUG - 2022-06-16 08:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:28:48 --> Total execution time: 0.0325
DEBUG - 2022-06-16 08:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:58:50 --> Total execution time: 0.0721
DEBUG - 2022-06-16 08:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 08:29:36 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-16 08:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:59:48 --> Total execution time: 0.1367
DEBUG - 2022-06-16 08:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:00:23 --> Total execution time: 0.0507
DEBUG - 2022-06-16 08:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:00:28 --> Total execution time: 0.0605
DEBUG - 2022-06-16 08:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:30:48 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:00:48 --> Total execution time: 0.0766
DEBUG - 2022-06-16 08:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:30:48 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:00:48 --> Total execution time: 0.0369
DEBUG - 2022-06-16 08:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:00:51 --> Total execution time: 0.0395
DEBUG - 2022-06-16 08:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:01:00 --> Total execution time: 0.0451
DEBUG - 2022-06-16 08:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:01:02 --> Total execution time: 0.0824
DEBUG - 2022-06-16 08:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:01:07 --> Total execution time: 0.0807
DEBUG - 2022-06-16 08:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:34:57 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:04:57 --> Total execution time: 0.0996
DEBUG - 2022-06-16 08:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:04:58 --> Total execution time: 0.0393
DEBUG - 2022-06-16 08:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:05:00 --> Total execution time: 0.0300
DEBUG - 2022-06-16 08:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:05:03 --> Total execution time: 0.0399
DEBUG - 2022-06-16 08:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:38:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:08:01 --> Total execution time: 0.1119
DEBUG - 2022-06-16 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:38:46 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:08:46 --> Total execution time: 0.0899
DEBUG - 2022-06-16 08:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:09:15 --> Total execution time: 0.0477
DEBUG - 2022-06-16 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:09:19 --> Total execution time: 0.0391
DEBUG - 2022-06-16 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:10:49 --> Total execution time: 0.1173
DEBUG - 2022-06-16 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:11:10 --> Total execution time: 0.0595
DEBUG - 2022-06-16 08:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:11:10 --> Total execution time: 0.1152
DEBUG - 2022-06-16 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:11:16 --> Total execution time: 0.0500
DEBUG - 2022-06-16 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:11:21 --> Total execution time: 0.0444
DEBUG - 2022-06-16 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:11:27 --> Total execution time: 0.0556
DEBUG - 2022-06-16 08:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:11:30 --> Total execution time: 0.0377
DEBUG - 2022-06-16 08:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:11:34 --> Total execution time: 0.0498
DEBUG - 2022-06-16 08:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:14:00 --> Total execution time: 0.1169
DEBUG - 2022-06-16 08:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:44:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:14:15 --> Total execution time: 0.0349
DEBUG - 2022-06-16 08:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:45:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:15:30 --> Total execution time: 0.0442
DEBUG - 2022-06-16 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:19:15 --> Total execution time: 0.0656
DEBUG - 2022-06-16 08:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:19:18 --> Total execution time: 0.0452
DEBUG - 2022-06-16 08:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:19:22 --> Total execution time: 0.0417
DEBUG - 2022-06-16 08:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:20:04 --> Total execution time: 0.0972
DEBUG - 2022-06-16 08:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:58:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:28:32 --> Total execution time: 0.1482
DEBUG - 2022-06-16 08:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:58:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 08:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:28:33 --> Total execution time: 0.0482
DEBUG - 2022-06-16 08:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:28:35 --> Total execution time: 0.0972
DEBUG - 2022-06-16 08:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 08:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:28:43 --> Total execution time: 0.0528
DEBUG - 2022-06-16 08:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:28:57 --> Total execution time: 0.0801
DEBUG - 2022-06-16 08:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:29:00 --> Total execution time: 0.0674
DEBUG - 2022-06-16 08:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:29:13 --> Total execution time: 0.1247
DEBUG - 2022-06-16 08:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:29:33 --> Total execution time: 0.0667
DEBUG - 2022-06-16 08:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:29:43 --> Total execution time: 0.0497
DEBUG - 2022-06-16 08:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 08:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 08:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:29:52 --> Total execution time: 0.0797
DEBUG - 2022-06-16 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:30:02 --> Total execution time: 0.0749
DEBUG - 2022-06-16 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:30:03 --> Total execution time: 0.1029
DEBUG - 2022-06-16 09:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:30:13 --> Total execution time: 0.1903
DEBUG - 2022-06-16 09:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:00:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:30:25 --> Total execution time: 0.0967
DEBUG - 2022-06-16 09:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:31:07 --> Total execution time: 0.0435
DEBUG - 2022-06-16 09:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:31:20 --> Total execution time: 0.0738
DEBUG - 2022-06-16 09:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:31:56 --> Total execution time: 0.0459
DEBUG - 2022-06-16 09:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:32:32 --> Total execution time: 0.0541
DEBUG - 2022-06-16 09:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:04:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:34:05 --> Total execution time: 0.0373
DEBUG - 2022-06-16 09:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:04:39 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:34:39 --> Total execution time: 0.0299
DEBUG - 2022-06-16 09:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:05:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:35:20 --> Total execution time: 0.0451
DEBUG - 2022-06-16 09:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:36:04 --> Total execution time: 0.0486
DEBUG - 2022-06-16 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:06:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:36:05 --> Total execution time: 0.0639
DEBUG - 2022-06-16 09:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:36:28 --> Total execution time: 0.1079
DEBUG - 2022-06-16 09:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:36:32 --> Total execution time: 0.0711
DEBUG - 2022-06-16 09:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:06:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:36:50 --> Total execution time: 0.0972
DEBUG - 2022-06-16 09:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:36:57 --> Total execution time: 1.9579
DEBUG - 2022-06-16 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 09:07:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 09:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:07:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:07:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:37:08 --> Total execution time: 0.0536
DEBUG - 2022-06-16 09:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:37:08 --> Total execution time: 0.0452
DEBUG - 2022-06-16 09:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:37:20 --> Total execution time: 0.0428
DEBUG - 2022-06-16 09:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:07:21 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:37:21 --> Total execution time: 0.0354
DEBUG - 2022-06-16 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:07:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:37:25 --> Total execution time: 0.0469
DEBUG - 2022-06-16 09:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:37:32 --> Total execution time: 1.5366
DEBUG - 2022-06-16 09:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:07:58 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:37:58 --> Total execution time: 0.0543
DEBUG - 2022-06-16 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:08:01 --> Total execution time: 0.0754
DEBUG - 2022-06-16 09:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:38:02 --> Total execution time: 0.0721
DEBUG - 2022-06-16 09:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:08:05 --> Total execution time: 0.0598
DEBUG - 2022-06-16 09:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:08:05 --> Total execution time: 0.1358
DEBUG - 2022-06-16 09:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:38:16 --> Total execution time: 0.0747
DEBUG - 2022-06-16 09:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:38:20 --> Total execution time: 0.0657
DEBUG - 2022-06-16 09:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:38:57 --> Total execution time: 0.0404
DEBUG - 2022-06-16 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:11:05 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:41:05 --> Total execution time: 0.1003
DEBUG - 2022-06-16 09:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:11:27 --> Total execution time: 0.0443
DEBUG - 2022-06-16 09:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:11:29 --> Total execution time: 0.0551
DEBUG - 2022-06-16 09:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:11:29 --> Total execution time: 0.0951
DEBUG - 2022-06-16 09:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:11:55 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:41:55 --> Total execution time: 0.0321
DEBUG - 2022-06-16 09:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:12:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 09:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:42:13 --> Total execution time: 1.5118
DEBUG - 2022-06-16 09:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:12:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 09:12:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 09:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:43:17 --> Total execution time: 0.0581
DEBUG - 2022-06-16 09:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:43:28 --> Total execution time: 0.0432
DEBUG - 2022-06-16 09:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:44:57 --> Total execution time: 0.0712
DEBUG - 2022-06-16 09:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:44:57 --> Total execution time: 0.2109
DEBUG - 2022-06-16 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:45:06 --> Total execution time: 0.0435
DEBUG - 2022-06-16 09:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:45:13 --> Total execution time: 0.0752
DEBUG - 2022-06-16 09:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:45:23 --> Total execution time: 0.1365
DEBUG - 2022-06-16 09:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:45:32 --> Total execution time: 0.0479
DEBUG - 2022-06-16 09:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:45:36 --> Total execution time: 0.0417
DEBUG - 2022-06-16 09:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:45:48 --> Total execution time: 0.0464
DEBUG - 2022-06-16 09:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:17:23 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:47:23 --> Total execution time: 0.0335
DEBUG - 2022-06-16 09:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:47:27 --> Total execution time: 0.0336
DEBUG - 2022-06-16 09:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:47:40 --> Total execution time: 0.0678
DEBUG - 2022-06-16 09:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:47:53 --> Total execution time: 0.0647
DEBUG - 2022-06-16 09:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:48:11 --> Total execution time: 0.0634
DEBUG - 2022-06-16 09:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:49:34 --> Total execution time: 0.1034
DEBUG - 2022-06-16 09:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:49:40 --> Total execution time: 0.1528
DEBUG - 2022-06-16 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:49:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 09:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:49:59 --> Total execution time: 0.0689
DEBUG - 2022-06-16 09:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 09:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:34 --> Total execution time: 0.0758
DEBUG - 2022-06-16 09:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:42 --> Total execution time: 0.0661
DEBUG - 2022-06-16 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:45 --> Total execution time: 0.0898
DEBUG - 2022-06-16 09:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:46 --> Total execution time: 0.0461
DEBUG - 2022-06-16 09:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:51 --> Total execution time: 0.0724
DEBUG - 2022-06-16 09:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:58 --> Total execution time: 0.0414
DEBUG - 2022-06-16 09:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:04 --> Total execution time: 0.0665
DEBUG - 2022-06-16 09:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:06 --> Total execution time: 0.0665
DEBUG - 2022-06-16 09:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:14 --> Total execution time: 0.0633
DEBUG - 2022-06-16 09:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:19 --> Total execution time: 0.0370
DEBUG - 2022-06-16 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:22 --> Total execution time: 0.0412
DEBUG - 2022-06-16 09:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:27 --> Total execution time: 0.0403
DEBUG - 2022-06-16 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:48 --> Total execution time: 0.0430
DEBUG - 2022-06-16 09:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:52:12 --> Total execution time: 0.1031
DEBUG - 2022-06-16 09:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 09:23:18 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 09:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 09:23:28 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-16 09:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:23:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:53:34 --> Total execution time: 0.1082
DEBUG - 2022-06-16 09:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:23:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:53:53 --> Total execution time: 0.0530
DEBUG - 2022-06-16 09:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:54:10 --> Total execution time: 1.9070
DEBUG - 2022-06-16 09:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 09:24:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 09:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:24:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:54:41 --> Total execution time: 0.1042
DEBUG - 2022-06-16 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:27:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:57:08 --> Total execution time: 0.1277
DEBUG - 2022-06-16 19:57:10 --> Total execution time: 1.6211
DEBUG - 2022-06-16 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 09:27:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:57:44 --> Total execution time: 0.0447
DEBUG - 2022-06-16 09:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:57:51 --> Total execution time: 0.0610
DEBUG - 2022-06-16 09:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:30:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:00:09 --> Total execution time: 0.0869
DEBUG - 2022-06-16 09:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:30:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:00:20 --> Total execution time: 0.0390
DEBUG - 2022-06-16 09:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:00:32 --> Total execution time: 0.0408
DEBUG - 2022-06-16 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:00:37 --> Total execution time: 0.0593
DEBUG - 2022-06-16 09:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:00:43 --> Total execution time: 0.0570
DEBUG - 2022-06-16 09:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:30:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:00:51 --> Total execution time: 0.0464
DEBUG - 2022-06-16 09:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:30:58 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:00:58 --> Total execution time: 0.0321
DEBUG - 2022-06-16 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:01:06 --> Total execution time: 0.0484
DEBUG - 2022-06-16 09:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:01:07 --> Total execution time: 0.0417
DEBUG - 2022-06-16 09:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:01:13 --> Total execution time: 0.0462
DEBUG - 2022-06-16 09:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:01:36 --> Total execution time: 0.0775
DEBUG - 2022-06-16 09:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:01:59 --> Total execution time: 0.0570
DEBUG - 2022-06-16 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:06 --> Total execution time: 0.1291
DEBUG - 2022-06-16 09:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:30 --> Total execution time: 0.0413
DEBUG - 2022-06-16 09:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:31 --> Total execution time: 0.0940
DEBUG - 2022-06-16 09:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:38 --> Total execution time: 0.0581
DEBUG - 2022-06-16 09:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:39 --> Total execution time: 0.0517
DEBUG - 2022-06-16 09:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:43 --> Total execution time: 0.0703
DEBUG - 2022-06-16 09:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:49 --> Total execution time: 0.0625
DEBUG - 2022-06-16 09:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:53 --> Total execution time: 0.0418
DEBUG - 2022-06-16 09:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:32:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:02:53 --> Total execution time: 0.0471
DEBUG - 2022-06-16 09:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:00 --> Total execution time: 0.0989
DEBUG - 2022-06-16 09:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:10 --> Total execution time: 0.0503
DEBUG - 2022-06-16 09:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:14 --> Total execution time: 0.0411
DEBUG - 2022-06-16 09:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:15 --> Total execution time: 0.0395
DEBUG - 2022-06-16 09:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:26 --> Total execution time: 0.0467
DEBUG - 2022-06-16 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:34 --> Total execution time: 0.0584
DEBUG - 2022-06-16 09:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:36 --> Total execution time: 0.0530
DEBUG - 2022-06-16 09:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:39 --> Total execution time: 0.0513
DEBUG - 2022-06-16 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:44 --> Total execution time: 0.0493
DEBUG - 2022-06-16 09:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:03:55 --> Total execution time: 0.0648
DEBUG - 2022-06-16 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:04:00 --> Total execution time: 0.0401
DEBUG - 2022-06-16 09:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:04:09 --> Total execution time: 0.0493
DEBUG - 2022-06-16 09:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:04:19 --> Total execution time: 0.0441
DEBUG - 2022-06-16 09:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:04:22 --> Total execution time: 0.0490
DEBUG - 2022-06-16 09:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:04:23 --> Total execution time: 0.0477
DEBUG - 2022-06-16 09:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:04:26 --> Total execution time: 0.0440
DEBUG - 2022-06-16 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:34:33 --> Total execution time: 0.0638
DEBUG - 2022-06-16 09:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:34:35 --> Total execution time: 0.0540
DEBUG - 2022-06-16 09:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:34:35 --> Total execution time: 0.0715
DEBUG - 2022-06-16 09:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:04:39 --> Total execution time: 0.0734
DEBUG - 2022-06-16 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:05:04 --> Total execution time: 0.0430
DEBUG - 2022-06-16 09:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:35:12 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:05:12 --> Total execution time: 0.0482
DEBUG - 2022-06-16 09:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:35:52 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:05:52 --> Total execution time: 0.0515
DEBUG - 2022-06-16 09:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:36:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:06:19 --> Total execution time: 0.0458
DEBUG - 2022-06-16 09:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:36:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 09:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:36:52 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:06:53 --> Total execution time: 0.0597
DEBUG - 2022-06-16 20:06:53 --> Total execution time: 1.5199
DEBUG - 2022-06-16 09:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 09:36:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:06:58 --> Total execution time: 0.0417
DEBUG - 2022-06-16 09:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:03 --> Total execution time: 0.0440
DEBUG - 2022-06-16 09:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:04 --> Total execution time: 0.0353
DEBUG - 2022-06-16 09:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:06 --> Total execution time: 0.0451
DEBUG - 2022-06-16 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:08 --> Total execution time: 0.0974
DEBUG - 2022-06-16 09:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:10 --> Total execution time: 0.0375
DEBUG - 2022-06-16 09:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:37:25 --> Total execution time: 0.0438
DEBUG - 2022-06-16 09:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:37:26 --> Total execution time: 0.0471
DEBUG - 2022-06-16 09:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:37:26 --> Total execution time: 0.0769
DEBUG - 2022-06-16 09:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:30 --> Total execution time: 0.0379
DEBUG - 2022-06-16 09:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:33 --> Total execution time: 0.0602
DEBUG - 2022-06-16 09:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:36 --> Total execution time: 0.0681
DEBUG - 2022-06-16 09:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 09:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:47 --> Total execution time: 0.0573
DEBUG - 2022-06-16 09:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:47 --> Total execution time: 0.0450
DEBUG - 2022-06-16 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 20:07:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 20:07:49 --> Total execution time: 0.1807
DEBUG - 2022-06-16 09:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:51 --> Total execution time: 0.0404
DEBUG - 2022-06-16 09:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:07:53 --> Total execution time: 0.0421
DEBUG - 2022-06-16 09:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:08:10 --> Total execution time: 0.0463
DEBUG - 2022-06-16 09:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:08:13 --> Total execution time: 0.0565
DEBUG - 2022-06-16 09:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:08:22 --> Total execution time: 0.0391
DEBUG - 2022-06-16 09:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:08:33 --> Total execution time: 0.0468
DEBUG - 2022-06-16 09:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:08:38 --> Total execution time: 0.0382
DEBUG - 2022-06-16 09:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:08:39 --> Total execution time: 0.0470
DEBUG - 2022-06-16 09:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:13 --> Total execution time: 0.0652
DEBUG - 2022-06-16 09:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:49 --> Total execution time: 0.0381
DEBUG - 2022-06-16 09:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:13:26 --> Total execution time: 0.1935
DEBUG - 2022-06-16 09:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:13:31 --> Total execution time: 0.1438
DEBUG - 2022-06-16 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:13:40 --> Total execution time: 0.0470
DEBUG - 2022-06-16 09:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:13:42 --> Total execution time: 0.0456
DEBUG - 2022-06-16 09:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:13:45 --> Total execution time: 0.0660
DEBUG - 2022-06-16 09:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:43:57 --> Total execution time: 0.0352
DEBUG - 2022-06-16 09:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:43:58 --> Total execution time: 0.0323
DEBUG - 2022-06-16 09:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:44:14 --> Total execution time: 0.0489
DEBUG - 2022-06-16 09:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:14:18 --> Total execution time: 0.0446
DEBUG - 2022-06-16 09:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:14:30 --> Total execution time: 0.0555
DEBUG - 2022-06-16 09:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:44:36 --> Total execution time: 0.0305
DEBUG - 2022-06-16 09:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:46 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:14:47 --> Total execution time: 0.0309
DEBUG - 2022-06-16 09:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:14:47 --> Total execution time: 0.0372
DEBUG - 2022-06-16 09:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:44:50 --> Total execution time: 0.0429
DEBUG - 2022-06-16 09:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:44:57 --> Total execution time: 0.0417
DEBUG - 2022-06-16 09:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:03 --> Total execution time: 0.2208
DEBUG - 2022-06-16 09:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:10 --> Total execution time: 0.0491
DEBUG - 2022-06-16 09:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:16 --> Total execution time: 0.0557
DEBUG - 2022-06-16 09:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:45:21 --> Total execution time: 0.0405
DEBUG - 2022-06-16 09:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:45:30 --> Total execution time: 0.0423
DEBUG - 2022-06-16 09:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:30 --> Total execution time: 0.0296
DEBUG - 2022-06-16 09:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:32 --> Total execution time: 0.0313
DEBUG - 2022-06-16 09:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:45:33 --> Total execution time: 0.0408
DEBUG - 2022-06-16 09:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:45:34 --> Total execution time: 0.0433
DEBUG - 2022-06-16 09:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:34 --> Total execution time: 0.0307
DEBUG - 2022-06-16 09:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:45:35 --> Total execution time: 0.0432
DEBUG - 2022-06-16 09:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:37 --> Total execution time: 0.0475
DEBUG - 2022-06-16 09:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:39 --> Total execution time: 0.0506
DEBUG - 2022-06-16 09:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:39 --> Total execution time: 0.0536
DEBUG - 2022-06-16 09:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:40 --> Total execution time: 0.0621
DEBUG - 2022-06-16 09:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:42 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:42 --> Total execution time: 0.0398
DEBUG - 2022-06-16 09:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:42 --> Total execution time: 0.0449
DEBUG - 2022-06-16 09:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:43 --> Total execution time: 0.0401
DEBUG - 2022-06-16 09:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:43 --> Total execution time: 0.0531
DEBUG - 2022-06-16 09:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:44 --> Total execution time: 0.0998
DEBUG - 2022-06-16 09:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:45 --> Total execution time: 0.0823
DEBUG - 2022-06-16 09:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:49 --> Total execution time: 0.0472
DEBUG - 2022-06-16 09:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:15:54 --> Total execution time: 0.0518
DEBUG - 2022-06-16 09:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:16:15 --> Total execution time: 0.0449
DEBUG - 2022-06-16 09:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:16:31 --> Total execution time: 0.0381
DEBUG - 2022-06-16 09:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:16:35 --> Total execution time: 0.0596
DEBUG - 2022-06-16 09:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:16:43 --> Total execution time: 0.0536
DEBUG - 2022-06-16 09:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:16:49 --> Total execution time: 0.0452
DEBUG - 2022-06-16 09:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:54 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:16:54 --> Total execution time: 0.0508
DEBUG - 2022-06-16 09:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:46:54 --> Total execution time: 0.0395
DEBUG - 2022-06-16 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:46:55 --> Total execution time: 0.0437
DEBUG - 2022-06-16 09:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:46:55 --> Total execution time: 0.0617
DEBUG - 2022-06-16 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:16:57 --> Total execution time: 0.0413
DEBUG - 2022-06-16 09:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:17:07 --> Total execution time: 0.0424
DEBUG - 2022-06-16 09:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:17:15 --> Total execution time: 0.0440
DEBUG - 2022-06-16 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:17:17 --> Total execution time: 0.0481
DEBUG - 2022-06-16 09:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:17:23 --> Total execution time: 0.0622
DEBUG - 2022-06-16 09:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:17:43 --> Total execution time: 0.0474
DEBUG - 2022-06-16 09:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:49:17 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:19:17 --> Total execution time: 0.0604
DEBUG - 2022-06-16 09:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:49:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:19:33 --> Total execution time: 0.0485
DEBUG - 2022-06-16 09:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:01 --> Total execution time: 0.1888
DEBUG - 2022-06-16 09:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:03 --> Total execution time: 0.0375
DEBUG - 2022-06-16 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 09:50:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-16 09:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:22 --> Total execution time: 0.0560
DEBUG - 2022-06-16 09:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:30 --> Total execution time: 0.0432
DEBUG - 2022-06-16 09:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:46 --> Total execution time: 0.0386
DEBUG - 2022-06-16 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:50 --> Total execution time: 0.0590
DEBUG - 2022-06-16 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:50 --> Total execution time: 0.0507
DEBUG - 2022-06-16 09:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:57 --> Total execution time: 0.0884
DEBUG - 2022-06-16 09:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:05 --> Total execution time: 0.0538
DEBUG - 2022-06-16 09:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:26 --> Total execution time: 0.0554
DEBUG - 2022-06-16 09:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:29 --> Total execution time: 0.0433
DEBUG - 2022-06-16 09:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:32 --> Total execution time: 0.0428
DEBUG - 2022-06-16 09:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:37 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:37 --> Total execution time: 0.0697
DEBUG - 2022-06-16 09:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:37 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:37 --> Total execution time: 0.0301
DEBUG - 2022-06-16 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:41 --> Total execution time: 0.0568
DEBUG - 2022-06-16 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:41 --> Total execution time: 0.0285
DEBUG - 2022-06-16 09:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:43 --> Total execution time: 0.0479
DEBUG - 2022-06-16 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:46 --> Total execution time: 0.0431
DEBUG - 2022-06-16 09:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:21:54 --> Total execution time: 0.0821
DEBUG - 2022-06-16 09:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:15 --> Total execution time: 0.0454
DEBUG - 2022-06-16 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:19 --> Total execution time: 0.0410
DEBUG - 2022-06-16 09:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:33 --> Total execution time: 0.0538
DEBUG - 2022-06-16 09:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:36 --> Total execution time: 0.0611
DEBUG - 2022-06-16 09:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:39 --> Total execution time: 0.1067
DEBUG - 2022-06-16 09:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:53 --> Total execution time: 0.0863
DEBUG - 2022-06-16 09:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:57 --> Total execution time: 0.0512
DEBUG - 2022-06-16 09:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:00 --> Total execution time: 0.0449
DEBUG - 2022-06-16 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:04 --> Total execution time: 0.0656
DEBUG - 2022-06-16 09:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:11 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:11 --> Total execution time: 0.0634
DEBUG - 2022-06-16 09:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:17 --> Total execution time: 0.0691
DEBUG - 2022-06-16 09:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:17 --> Total execution time: 0.1123
DEBUG - 2022-06-16 09:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:18 --> Total execution time: 0.0450
DEBUG - 2022-06-16 09:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:18 --> Total execution time: 0.0369
DEBUG - 2022-06-16 09:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:19 --> Total execution time: 0.0917
DEBUG - 2022-06-16 09:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:21 --> Total execution time: 0.0752
DEBUG - 2022-06-16 09:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:23 --> Total execution time: 0.0975
DEBUG - 2022-06-16 09:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:23 --> Total execution time: 0.0412
DEBUG - 2022-06-16 09:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:25 --> Total execution time: 0.0670
DEBUG - 2022-06-16 09:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 09:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:27 --> Total execution time: 0.0430
DEBUG - 2022-06-16 09:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:49 --> Total execution time: 0.0512
DEBUG - 2022-06-16 09:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:24:56 --> Total execution time: 0.0609
DEBUG - 2022-06-16 09:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:07 --> Total execution time: 0.0532
DEBUG - 2022-06-16 09:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:11 --> Total execution time: 0.0447
DEBUG - 2022-06-16 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:25 --> Total execution time: 0.0588
DEBUG - 2022-06-16 09:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:28 --> Total execution time: 0.0332
DEBUG - 2022-06-16 09:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:34 --> Total execution time: 0.0416
DEBUG - 2022-06-16 09:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:35 --> Total execution time: 0.0414
DEBUG - 2022-06-16 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:27:20 --> Total execution time: 0.0440
DEBUG - 2022-06-16 09:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:28:30 --> Total execution time: 0.0564
DEBUG - 2022-06-16 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:29:43 --> Total execution time: 0.0465
DEBUG - 2022-06-16 09:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 09:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 09:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:29:58 --> Total execution time: 0.1115
DEBUG - 2022-06-16 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:30:02 --> Total execution time: 0.0527
DEBUG - 2022-06-16 10:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:00:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:30:33 --> Total execution time: 0.0315
DEBUG - 2022-06-16 10:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:30:35 --> Total execution time: 0.0837
DEBUG - 2022-06-16 10:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:30:47 --> Total execution time: 0.0531
DEBUG - 2022-06-16 10:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:31:56 --> Total execution time: 0.0510
DEBUG - 2022-06-16 10:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:32:07 --> Total execution time: 0.0761
DEBUG - 2022-06-16 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:21 --> Total execution time: 0.0387
DEBUG - 2022-06-16 10:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:32:25 --> Total execution time: 0.0398
DEBUG - 2022-06-16 10:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:29 --> Total execution time: 0.0858
DEBUG - 2022-06-16 10:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:32 --> Total execution time: 0.0700
DEBUG - 2022-06-16 10:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:35 --> Total execution time: 0.0422
DEBUG - 2022-06-16 10:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:36 --> Total execution time: 0.0455
DEBUG - 2022-06-16 10:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:32:44 --> Total execution time: 0.0479
DEBUG - 2022-06-16 10:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:44 --> Total execution time: 0.0783
DEBUG - 2022-06-16 10:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:50 --> Total execution time: 0.0385
DEBUG - 2022-06-16 10:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:02:59 --> Total execution time: 0.0400
DEBUG - 2022-06-16 10:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:03:01 --> Total execution time: 0.1034
DEBUG - 2022-06-16 10:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:03:03 --> Total execution time: 0.0370
DEBUG - 2022-06-16 10:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 10:03:12 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 10:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 10:03:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 10:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 10:03:17 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 10:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 10:03:23 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:33:37 --> Total execution time: 0.0385
DEBUG - 2022-06-16 10:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:33:58 --> Total execution time: 0.0806
DEBUG - 2022-06-16 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:08 --> Total execution time: 0.0384
DEBUG - 2022-06-16 10:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:37 --> Total execution time: 0.0508
DEBUG - 2022-06-16 10:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:41 --> Total execution time: 0.0442
DEBUG - 2022-06-16 10:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:04:43 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:43 --> Total execution time: 0.0436
DEBUG - 2022-06-16 10:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:43 --> Total execution time: 0.0408
DEBUG - 2022-06-16 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:04 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:04 --> Total execution time: 0.0492
DEBUG - 2022-06-16 10:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:12 --> Total execution time: 0.0485
DEBUG - 2022-06-16 10:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:30 --> Total execution time: 0.1031
DEBUG - 2022-06-16 10:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:34 --> Total execution time: 0.0381
DEBUG - 2022-06-16 10:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:38 --> Total execution time: 0.0377
DEBUG - 2022-06-16 10:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:44 --> Total execution time: 0.0528
DEBUG - 2022-06-16 10:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:51 --> Total execution time: 0.0740
DEBUG - 2022-06-16 10:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:36:00 --> Total execution time: 0.0504
DEBUG - 2022-06-16 10:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:06:23 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:36:23 --> Total execution time: 0.0368
DEBUG - 2022-06-16 10:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:06:38 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:36:39 --> Total execution time: 0.0346
DEBUG - 2022-06-16 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:36:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 10:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:36:45 --> Total execution time: 0.0631
DEBUG - 2022-06-16 10:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:36:54 --> Total execution time: 0.0503
DEBUG - 2022-06-16 10:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:08 --> Total execution time: 0.0598
DEBUG - 2022-06-16 10:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:16 --> Total execution time: 0.2263
DEBUG - 2022-06-16 10:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:17 --> Total execution time: 0.0444
DEBUG - 2022-06-16 10:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:25 --> Total execution time: 0.0418
DEBUG - 2022-06-16 10:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:26 --> Total execution time: 0.0422
DEBUG - 2022-06-16 10:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:30 --> Total execution time: 0.0647
DEBUG - 2022-06-16 10:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:39 --> Total execution time: 0.0400
DEBUG - 2022-06-16 10:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:45 --> Total execution time: 0.0517
DEBUG - 2022-06-16 10:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:45 --> Total execution time: 0.0542
DEBUG - 2022-06-16 10:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:46 --> Total execution time: 0.0555
DEBUG - 2022-06-16 10:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:38:50 --> Total execution time: 0.0372
DEBUG - 2022-06-16 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:12:17 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:42:18 --> Total execution time: 0.0990
DEBUG - 2022-06-16 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:12:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:42:40 --> Total execution time: 0.0289
DEBUG - 2022-06-16 10:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:13:15 --> Total execution time: 0.0547
DEBUG - 2022-06-16 10:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:13:36 --> Total execution time: 0.0511
DEBUG - 2022-06-16 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:13:37 --> Total execution time: 0.0551
DEBUG - 2022-06-16 10:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:13:41 --> Total execution time: 0.0622
DEBUG - 2022-06-16 10:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:13:41 --> Total execution time: 0.1220
DEBUG - 2022-06-16 10:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:13:49 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:43:49 --> Total execution time: 0.0448
DEBUG - 2022-06-16 10:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:13:56 --> Total execution time: 0.0448
DEBUG - 2022-06-16 10:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:14:00 --> Total execution time: 0.0474
DEBUG - 2022-06-16 10:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:14:00 --> Total execution time: 0.0704
DEBUG - 2022-06-16 10:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:44:00 --> Total execution time: 0.0422
DEBUG - 2022-06-16 10:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:45:13 --> Total execution time: 0.0418
DEBUG - 2022-06-16 10:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:45:18 --> Total execution time: 0.0612
DEBUG - 2022-06-16 10:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:45:31 --> Total execution time: 0.0582
DEBUG - 2022-06-16 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:45:34 --> Total execution time: 0.0681
DEBUG - 2022-06-16 10:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:45:47 --> Total execution time: 0.0392
DEBUG - 2022-06-16 10:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:46:26 --> Total execution time: 0.1083
DEBUG - 2022-06-16 10:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:46:31 --> Total execution time: 0.0477
DEBUG - 2022-06-16 10:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:46:39 --> Total execution time: 0.0416
DEBUG - 2022-06-16 10:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:46:45 --> Total execution time: 0.0465
DEBUG - 2022-06-16 10:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:46:49 --> Total execution time: 0.0454
DEBUG - 2022-06-16 10:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:46:52 --> Total execution time: 0.0538
DEBUG - 2022-06-16 10:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:47:00 --> Total execution time: 0.0447
DEBUG - 2022-06-16 10:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:47:02 --> Total execution time: 0.0548
DEBUG - 2022-06-16 10:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:47:10 --> Total execution time: 0.0437
DEBUG - 2022-06-16 10:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:51:44 --> Total execution time: 0.1653
DEBUG - 2022-06-16 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:55:15 --> Total execution time: 0.1981
DEBUG - 2022-06-16 10:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:56:58 --> Total execution time: 0.0487
DEBUG - 2022-06-16 10:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:58:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 10:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:58:39 --> Total execution time: 0.0479
DEBUG - 2022-06-16 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:59:38 --> Total execution time: 0.0505
DEBUG - 2022-06-16 10:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:59:45 --> Total execution time: 0.0562
DEBUG - 2022-06-16 10:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:59:52 --> Total execution time: 0.1258
DEBUG - 2022-06-16 10:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:59:55 --> Total execution time: 0.1086
DEBUG - 2022-06-16 10:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:00:13 --> Total execution time: 0.0775
DEBUG - 2022-06-16 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:00:16 --> Total execution time: 0.0449
DEBUG - 2022-06-16 10:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:00:19 --> Total execution time: 0.0574
DEBUG - 2022-06-16 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:00:27 --> Total execution time: 0.0374
DEBUG - 2022-06-16 10:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:00:31 --> Total execution time: 0.1384
DEBUG - 2022-06-16 10:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:00:37 --> Total execution time: 0.0596
DEBUG - 2022-06-16 10:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:01:00 --> Total execution time: 0.0655
DEBUG - 2022-06-16 10:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:01:00 --> Total execution time: 0.0463
DEBUG - 2022-06-16 10:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:31:17 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:01:17 --> Total execution time: 0.0387
DEBUG - 2022-06-16 10:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:01:32 --> Total execution time: 0.0579
DEBUG - 2022-06-16 10:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:01:48 --> Total execution time: 0.0577
DEBUG - 2022-06-16 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:02:57 --> Total execution time: 0.1037
DEBUG - 2022-06-16 10:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:05:51 --> Total execution time: 0.0829
DEBUG - 2022-06-16 10:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:05:55 --> Total execution time: 0.0523
DEBUG - 2022-06-16 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:06:00 --> Total execution time: 0.0504
DEBUG - 2022-06-16 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:06:03 --> Total execution time: 0.0463
DEBUG - 2022-06-16 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:06:21 --> Total execution time: 0.0495
DEBUG - 2022-06-16 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:06:29 --> Total execution time: 0.0662
DEBUG - 2022-06-16 10:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:06:47 --> Total execution time: 0.0500
DEBUG - 2022-06-16 10:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:07:39 --> Total execution time: 0.0487
DEBUG - 2022-06-16 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:07:45 --> Total execution time: 0.1020
DEBUG - 2022-06-16 10:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:07:55 --> Total execution time: 0.0509
DEBUG - 2022-06-16 10:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:38:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:08:33 --> Total execution time: 0.0347
DEBUG - 2022-06-16 10:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:08:48 --> Total execution time: 0.0376
DEBUG - 2022-06-16 10:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:09:24 --> Total execution time: 0.0759
DEBUG - 2022-06-16 10:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:09:31 --> Total execution time: 0.0597
DEBUG - 2022-06-16 10:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:43:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:13:20 --> Total execution time: 0.0879
DEBUG - 2022-06-16 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:43:36 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:13:36 --> Total execution time: 0.0948
DEBUG - 2022-06-16 10:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:46:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:22 --> Total execution time: 0.0809
DEBUG - 2022-06-16 10:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:59 --> Total execution time: 0.0546
DEBUG - 2022-06-16 10:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:17:06 --> Total execution time: 0.0572
DEBUG - 2022-06-16 10:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:17:17 --> Total execution time: 0.0738
DEBUG - 2022-06-16 10:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:47:35 --> Total execution time: 0.0400
DEBUG - 2022-06-16 10:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:47:36 --> Total execution time: 0.0434
DEBUG - 2022-06-16 10:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:17:36 --> Total execution time: 0.0596
DEBUG - 2022-06-16 10:47:36 --> Total execution time: 0.0994
DEBUG - 2022-06-16 10:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:48:26 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:18:26 --> Total execution time: 0.0945
DEBUG - 2022-06-16 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:51:42 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:21:42 --> Total execution time: 0.1199
DEBUG - 2022-06-16 10:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:21:44 --> Total execution time: 0.0273
DEBUG - 2022-06-16 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:21:52 --> Total execution time: 0.0490
DEBUG - 2022-06-16 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:21:55 --> Total execution time: 0.0721
DEBUG - 2022-06-16 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:21:55 --> Total execution time: 0.0668
DEBUG - 2022-06-16 10:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:52:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 10:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:07 --> Total execution time: 2.0110
DEBUG - 2022-06-16 10:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:52:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 10:52:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 10:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:25 --> Total execution time: 0.0596
DEBUG - 2022-06-16 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:31 --> Total execution time: 0.0377
DEBUG - 2022-06-16 10:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:39 --> Total execution time: 0.1049
DEBUG - 2022-06-16 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:50 --> Total execution time: 0.0496
DEBUG - 2022-06-16 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:53:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:23:00 --> Total execution time: 0.0288
DEBUG - 2022-06-16 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:53:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:23:00 --> Total execution time: 0.0328
DEBUG - 2022-06-16 10:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:53:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 10:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:23:22 --> Total execution time: 0.0623
DEBUG - 2022-06-16 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 10:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:49 --> Total execution time: 0.0402
DEBUG - 2022-06-16 10:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 21:24:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 21:24:51 --> Total execution time: 0.1661
DEBUG - 2022-06-16 10:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:26:07 --> Total execution time: 0.0524
DEBUG - 2022-06-16 10:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:26:20 --> Total execution time: 0.0585
DEBUG - 2022-06-16 10:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:26:38 --> Total execution time: 0.0698
DEBUG - 2022-06-16 10:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:26:51 --> Total execution time: 0.0961
DEBUG - 2022-06-16 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:27:15 --> Total execution time: 0.0918
DEBUG - 2022-06-16 10:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:27:28 --> Total execution time: 0.0545
DEBUG - 2022-06-16 10:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:27:47 --> Total execution time: 0.0383
DEBUG - 2022-06-16 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:28:01 --> Total execution time: 0.0801
DEBUG - 2022-06-16 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:28:43 --> Total execution time: 0.0488
DEBUG - 2022-06-16 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 10:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 10:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 10:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:28:53 --> Total execution time: 0.0465
DEBUG - 2022-06-16 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:30:02 --> Total execution time: 0.0549
DEBUG - 2022-06-16 11:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:02:06 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:32:07 --> Total execution time: 0.1715
DEBUG - 2022-06-16 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:31 --> Total execution time: 0.1368
DEBUG - 2022-06-16 11:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:35:20 --> Total execution time: 0.0491
DEBUG - 2022-06-16 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:40:32 --> Total execution time: 0.0482
DEBUG - 2022-06-16 11:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:40:35 --> Total execution time: 0.0523
DEBUG - 2022-06-16 11:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:40:58 --> Total execution time: 0.0638
DEBUG - 2022-06-16 11:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:41:03 --> Total execution time: 0.1124
DEBUG - 2022-06-16 11:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:11:37 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:41:37 --> Total execution time: 0.0442
DEBUG - 2022-06-16 11:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:11:42 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:41:42 --> Total execution time: 0.0303
DEBUG - 2022-06-16 11:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:12:17 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:42:17 --> Total execution time: 0.0402
DEBUG - 2022-06-16 11:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:42:31 --> Total execution time: 2.0390
DEBUG - 2022-06-16 11:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:12:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 11:12:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 11:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:43:21 --> Total execution time: 0.1103
DEBUG - 2022-06-16 11:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:43:28 --> Total execution time: 0.0461
DEBUG - 2022-06-16 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:43:33 --> Total execution time: 0.0558
DEBUG - 2022-06-16 11:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:43:42 --> Total execution time: 0.0514
DEBUG - 2022-06-16 11:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:44:03 --> Total execution time: 0.0595
DEBUG - 2022-06-16 11:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:44:28 --> Total execution time: 1.4872
DEBUG - 2022-06-16 11:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:14:28 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:44:28 --> Total execution time: 0.0399
DEBUG - 2022-06-16 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:44:42 --> Total execution time: 0.1001
DEBUG - 2022-06-16 11:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:44:43 --> Total execution time: 0.0535
DEBUG - 2022-06-16 11:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:25 --> Total execution time: 0.0551
DEBUG - 2022-06-16 11:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:27 --> Total execution time: 0.0462
DEBUG - 2022-06-16 11:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:28 --> Total execution time: 0.0334
DEBUG - 2022-06-16 11:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:45 --> Total execution time: 0.0405
DEBUG - 2022-06-16 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:48 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:48 --> Total execution time: 0.0340
DEBUG - 2022-06-16 11:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:51 --> Total execution time: 0.0473
DEBUG - 2022-06-16 11:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:57 --> Total execution time: 0.0515
DEBUG - 2022-06-16 11:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:58 --> Total execution time: 0.0535
DEBUG - 2022-06-16 11:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:58 --> Total execution time: 0.0355
DEBUG - 2022-06-16 11:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:58 --> Total execution time: 0.0384
DEBUG - 2022-06-16 11:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:58 --> Total execution time: 0.0354
DEBUG - 2022-06-16 11:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:59 --> Total execution time: 0.0370
DEBUG - 2022-06-16 11:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:59 --> Total execution time: 0.0392
DEBUG - 2022-06-16 11:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:00 --> Total execution time: 0.0486
DEBUG - 2022-06-16 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:00 --> Total execution time: 0.0451
DEBUG - 2022-06-16 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:00 --> Total execution time: 0.0417
DEBUG - 2022-06-16 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:00 --> Total execution time: 0.0354
DEBUG - 2022-06-16 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:00 --> Total execution time: 0.0407
DEBUG - 2022-06-16 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:00 --> Total execution time: 0.0345
DEBUG - 2022-06-16 11:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:07 --> Total execution time: 0.0674
DEBUG - 2022-06-16 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:18:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:48:18 --> Total execution time: 0.0895
DEBUG - 2022-06-16 11:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:18:28 --> Total execution time: 0.0518
DEBUG - 2022-06-16 11:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:18:34 --> Total execution time: 0.0453
DEBUG - 2022-06-16 11:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:18:34 --> Total execution time: 0.0408
DEBUG - 2022-06-16 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:19:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:44 --> Total execution time: 0.0299
DEBUG - 2022-06-16 11:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:19:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:50 --> Total execution time: 0.0459
DEBUG - 2022-06-16 11:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:19:55 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:55 --> Total execution time: 0.0406
DEBUG - 2022-06-16 11:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:50:15 --> Total execution time: 1.4946
DEBUG - 2022-06-16 11:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:21:17 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:51:17 --> Total execution time: 0.0497
DEBUG - 2022-06-16 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:21:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:51:33 --> Total execution time: 1.4565
DEBUG - 2022-06-16 11:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:22:35 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:52:35 --> Total execution time: 0.0335
DEBUG - 2022-06-16 11:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:22:45 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:52:45 --> Total execution time: 0.0876
DEBUG - 2022-06-16 11:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:22:47 --> Total execution time: 0.0445
DEBUG - 2022-06-16 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:23:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:53:30 --> Total execution time: 0.1049
DEBUG - 2022-06-16 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:53:44 --> Total execution time: 1.5641
DEBUG - 2022-06-16 11:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 11:23:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 11:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:53:50 --> Total execution time: 0.0422
DEBUG - 2022-06-16 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:53:56 --> Total execution time: 0.0707
DEBUG - 2022-06-16 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:24:11 --> Total execution time: 0.0826
DEBUG - 2022-06-16 11:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:24:12 --> Total execution time: 0.1375
DEBUG - 2022-06-16 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:54:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:54:25 --> Total execution time: 0.0414
DEBUG - 2022-06-16 11:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:54:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 21:54:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 21:54:28 --> Total execution time: 0.2071
DEBUG - 2022-06-16 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:25:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:56:05 --> Total execution time: 2.4802
DEBUG - 2022-06-16 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:56:43 --> Total execution time: 0.0405
DEBUG - 2022-06-16 11:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:27:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 11:27:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 11:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:57:10 --> Total execution time: 0.0702
DEBUG - 2022-06-16 11:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:57:20 --> Total execution time: 0.0792
DEBUG - 2022-06-16 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:57:50 --> Total execution time: 0.0523
DEBUG - 2022-06-16 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:28:54 --> Total execution time: 0.0392
DEBUG - 2022-06-16 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:29:36 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:59:36 --> Total execution time: 0.0288
DEBUG - 2022-06-16 11:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:29:37 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:59:37 --> Total execution time: 0.0300
DEBUG - 2022-06-16 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:30:10 --> Total execution time: 0.0364
DEBUG - 2022-06-16 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:30:18 --> Total execution time: 0.0416
DEBUG - 2022-06-16 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:30:18 --> Total execution time: 0.0539
DEBUG - 2022-06-16 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:00:25 --> Total execution time: 0.0915
DEBUG - 2022-06-16 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:30:28 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:00:28 --> Total execution time: 0.0297
DEBUG - 2022-06-16 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:00:41 --> Total execution time: 0.0352
DEBUG - 2022-06-16 11:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:00:44 --> Total execution time: 0.0265
DEBUG - 2022-06-16 11:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:01:04 --> Total execution time: 0.0457
DEBUG - 2022-06-16 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:01:16 --> Total execution time: 0.0470
DEBUG - 2022-06-16 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:01:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:01:17 --> Total execution time: 0.0432
DEBUG - 2022-06-16 11:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:32:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:02:32 --> Total execution time: 0.0575
DEBUG - 2022-06-16 11:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:02:38 --> Total execution time: 0.0329
DEBUG - 2022-06-16 11:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:03:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:03:08 --> Total execution time: 0.0531
DEBUG - 2022-06-16 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:03:10 --> Total execution time: 0.0366
DEBUG - 2022-06-16 11:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:03:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 22:03:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 22:03:21 --> Total execution time: 0.2508
DEBUG - 2022-06-16 11:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:33:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:03:34 --> Total execution time: 0.0552
DEBUG - 2022-06-16 11:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:34:37 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:04:37 --> Total execution time: 0.0479
DEBUG - 2022-06-16 11:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:04:37 --> Total execution time: 0.0495
DEBUG - 2022-06-16 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:39 --> Total execution time: 0.1661
DEBUG - 2022-06-16 11:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:08:19 --> Total execution time: 0.0461
DEBUG - 2022-06-16 11:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:08:29 --> Total execution time: 0.0541
DEBUG - 2022-06-16 11:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:32 --> Total execution time: 0.0469
DEBUG - 2022-06-16 11:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:35 --> Total execution time: 0.0527
DEBUG - 2022-06-16 11:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:48 --> Total execution time: 0.0968
DEBUG - 2022-06-16 11:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:49 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:49 --> Total execution time: 0.1204
DEBUG - 2022-06-16 11:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:52 --> Total execution time: 0.0631
DEBUG - 2022-06-16 11:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:39:55 --> Total execution time: 0.0480
DEBUG - 2022-06-16 11:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:56 --> Total execution time: 0.0422
DEBUG - 2022-06-16 11:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:39:56 --> Total execution time: 0.0459
DEBUG - 2022-06-16 11:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:39:56 --> Total execution time: 0.0873
DEBUG - 2022-06-16 11:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:59 --> Total execution time: 0.0778
DEBUG - 2022-06-16 11:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:10:13 --> Total execution time: 0.0445
DEBUG - 2022-06-16 11:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:10:18 --> Total execution time: 0.0739
DEBUG - 2022-06-16 11:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:10:19 --> Total execution time: 0.0868
DEBUG - 2022-06-16 11:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:10:19 --> Total execution time: 0.0426
DEBUG - 2022-06-16 11:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:10:22 --> Total execution time: 0.0405
DEBUG - 2022-06-16 11:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:10:29 --> Total execution time: 0.0704
DEBUG - 2022-06-16 11:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:10:34 --> Total execution time: 0.0705
DEBUG - 2022-06-16 11:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:40:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:10:57 --> Total execution time: 1.8516
DEBUG - 2022-06-16 11:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:10:58 --> Total execution time: 0.0421
DEBUG - 2022-06-16 11:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:11:06 --> Total execution time: 0.0501
DEBUG - 2022-06-16 11:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:11:13 --> Total execution time: 0.0679
DEBUG - 2022-06-16 11:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:11:18 --> Total execution time: 0.0550
DEBUG - 2022-06-16 11:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:11:20 --> Total execution time: 0.0408
DEBUG - 2022-06-16 11:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:11:23 --> Total execution time: 0.0746
DEBUG - 2022-06-16 11:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:11:27 --> Total execution time: 0.0405
DEBUG - 2022-06-16 11:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:41:33 --> Total execution time: 0.0422
DEBUG - 2022-06-16 11:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:41:43 --> Total execution time: 0.0481
DEBUG - 2022-06-16 11:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:41:50 --> Total execution time: 0.0375
DEBUG - 2022-06-16 11:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:12:01 --> Total execution time: 0.1002
DEBUG - 2022-06-16 11:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:14 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:12:14 --> Total execution time: 0.0425
DEBUG - 2022-06-16 11:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:42:16 --> Total execution time: 0.0393
DEBUG - 2022-06-16 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:42:34 --> Total execution time: 0.0482
DEBUG - 2022-06-16 11:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:12:44 --> Total execution time: 1.4207
DEBUG - 2022-06-16 11:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 11:42:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:42:56 --> Total execution time: 0.0414
DEBUG - 2022-06-16 11:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:42:59 --> Total execution time: 0.0427
DEBUG - 2022-06-16 11:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:43:02 --> Total execution time: 0.0528
DEBUG - 2022-06-16 11:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:43:03 --> Total execution time: 0.0378
DEBUG - 2022-06-16 11:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:13:08 --> Total execution time: 0.0531
DEBUG - 2022-06-16 11:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:13 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:13:13 --> Total execution time: 0.0429
DEBUG - 2022-06-16 11:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:13:15 --> Total execution time: 0.0594
DEBUG - 2022-06-16 11:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:13:24 --> Total execution time: 0.0482
DEBUG - 2022-06-16 11:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:13:26 --> Total execution time: 0.0546
DEBUG - 2022-06-16 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:13:35 --> Total execution time: 0.0715
DEBUG - 2022-06-16 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:43:51 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:13:51 --> Total execution time: 0.0517
DEBUG - 2022-06-16 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:44:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:14:02 --> Total execution time: 0.0466
DEBUG - 2022-06-16 11:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:14:11 --> Total execution time: 1.5375
DEBUG - 2022-06-16 11:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 11:44:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 11:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:09 --> Total execution time: 0.0875
DEBUG - 2022-06-16 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:13 --> Total execution time: 0.0561
DEBUG - 2022-06-16 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:17 --> Total execution time: 0.0453
DEBUG - 2022-06-16 11:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:25 --> Total execution time: 0.0332
DEBUG - 2022-06-16 11:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:26 --> Total execution time: 0.1142
DEBUG - 2022-06-16 11:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:27 --> Total execution time: 0.0724
DEBUG - 2022-06-16 11:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:31 --> Total execution time: 0.0747
DEBUG - 2022-06-16 11:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:33 --> Total execution time: 0.0418
DEBUG - 2022-06-16 11:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:33 --> Total execution time: 0.0484
DEBUG - 2022-06-16 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:36 --> Total execution time: 0.0633
DEBUG - 2022-06-16 11:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:45:37 --> Total execution time: 0.0425
DEBUG - 2022-06-16 11:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:38 --> Total execution time: 0.0677
DEBUG - 2022-06-16 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:45:39 --> Total execution time: 0.0646
DEBUG - 2022-06-16 11:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:45:39 --> Total execution time: 0.1223
DEBUG - 2022-06-16 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:47 --> Total execution time: 0.2053
DEBUG - 2022-06-16 11:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:55 --> Total execution time: 0.0411
DEBUG - 2022-06-16 11:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:46:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:16:08 --> Total execution time: 0.0309
DEBUG - 2022-06-16 11:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:46:26 --> Total execution time: 0.0406
DEBUG - 2022-06-16 11:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:47:04 --> Total execution time: 0.0426
DEBUG - 2022-06-16 11:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:47:04 --> Total execution time: 0.0827
DEBUG - 2022-06-16 11:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:17:48 --> Total execution time: 0.0293
DEBUG - 2022-06-16 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:17:51 --> Total execution time: 0.0485
DEBUG - 2022-06-16 11:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:18:01 --> Total execution time: 0.0550
DEBUG - 2022-06-16 11:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:18:08 --> Total execution time: 0.0750
DEBUG - 2022-06-16 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:18:21 --> Total execution time: 0.0436
DEBUG - 2022-06-16 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:48:37 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:18:37 --> Total execution time: 0.0422
DEBUG - 2022-06-16 11:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:18:40 --> Total execution time: 0.0462
DEBUG - 2022-06-16 11:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:18:57 --> Total execution time: 0.0462
DEBUG - 2022-06-16 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:49:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:19:17 --> Total execution time: 1.4721
DEBUG - 2022-06-16 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:19:18 --> Total execution time: 0.0277
DEBUG - 2022-06-16 11:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:19:35 --> Total execution time: 0.0531
DEBUG - 2022-06-16 11:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:50:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 11:50:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:20:05 --> Total execution time: 1.6117
DEBUG - 2022-06-16 11:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:20:11 --> Total execution time: 0.0461
DEBUG - 2022-06-16 11:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:20:22 --> Total execution time: 0.0505
DEBUG - 2022-06-16 11:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:20:27 --> Total execution time: 0.0591
DEBUG - 2022-06-16 11:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:20:37 --> Total execution time: 0.1555
DEBUG - 2022-06-16 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:21:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:21:11 --> Total execution time: 0.0785
DEBUG - 2022-06-16 11:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:21:19 --> Total execution time: 0.0672
DEBUG - 2022-06-16 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:22:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:22:53 --> Total execution time: 0.0413
DEBUG - 2022-06-16 11:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:22:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 22:22:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 22:22:58 --> Total execution time: 0.1898
DEBUG - 2022-06-16 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:23:41 --> Total execution time: 0.0497
DEBUG - 2022-06-16 11:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:54:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:24:01 --> Total execution time: 0.0341
DEBUG - 2022-06-16 11:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:24:12 --> Total execution time: 0.0397
DEBUG - 2022-06-16 11:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:54:31 --> Total execution time: 0.0488
DEBUG - 2022-06-16 11:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:54:36 --> Total execution time: 0.0545
DEBUG - 2022-06-16 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:55:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:25:00 --> Total execution time: 0.0332
DEBUG - 2022-06-16 11:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:55:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:25:01 --> Total execution time: 0.0317
DEBUG - 2022-06-16 11:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:55:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:25:01 --> Total execution time: 0.0312
DEBUG - 2022-06-16 11:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:25:34 --> Total execution time: 0.0710
DEBUG - 2022-06-16 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:25:45 --> Total execution time: 0.0756
DEBUG - 2022-06-16 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:56:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 11:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:26:22 --> Total execution time: 0.0523
DEBUG - 2022-06-16 11:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:27:42 --> Total execution time: 0.0480
DEBUG - 2022-06-16 11:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:27:53 --> Total execution time: 0.0720
DEBUG - 2022-06-16 11:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:28:07 --> Total execution time: 0.0445
DEBUG - 2022-06-16 11:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:28:20 --> Total execution time: 0.0592
DEBUG - 2022-06-16 11:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:28:30 --> Total execution time: 0.0422
DEBUG - 2022-06-16 11:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:28:33 --> Total execution time: 0.0704
DEBUG - 2022-06-16 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:28:47 --> Total execution time: 0.0267
DEBUG - 2022-06-16 11:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 11:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:28:59 --> Total execution time: 0.0411
DEBUG - 2022-06-16 11:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:29:08 --> Total execution time: 0.0631
DEBUG - 2022-06-16 11:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:29:49 --> Total execution time: 0.0471
DEBUG - 2022-06-16 11:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:29:52 --> Total execution time: 0.0436
DEBUG - 2022-06-16 11:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 11:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 11:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:29:59 --> Total execution time: 0.1009
DEBUG - 2022-06-16 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:30:03 --> Total execution time: 0.0599
DEBUG - 2022-06-16 12:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:30:18 --> Total execution time: 0.0864
DEBUG - 2022-06-16 12:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:30:45 --> Total execution time: 0.0424
DEBUG - 2022-06-16 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:00:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:30:50 --> Total execution time: 0.0432
DEBUG - 2022-06-16 12:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:30:52 --> Total execution time: 0.1513
DEBUG - 2022-06-16 12:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:31:07 --> Total execution time: 0.0281
DEBUG - 2022-06-16 12:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:31:37 --> Total execution time: 0.0588
DEBUG - 2022-06-16 12:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:31:51 --> Total execution time: 0.0428
DEBUG - 2022-06-16 12:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:32:12 --> Total execution time: 0.0489
DEBUG - 2022-06-16 12:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:10 --> Total execution time: 0.1240
DEBUG - 2022-06-16 12:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:25 --> Total execution time: 0.0421
DEBUG - 2022-06-16 12:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:33 --> Total execution time: 0.0448
DEBUG - 2022-06-16 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:37 --> Total execution time: 0.0557
DEBUG - 2022-06-16 12:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:39 --> Total execution time: 0.0446
DEBUG - 2022-06-16 12:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:42 --> Total execution time: 0.0371
DEBUG - 2022-06-16 12:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:46 --> Total execution time: 0.0538
DEBUG - 2022-06-16 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:47 --> Total execution time: 0.0376
DEBUG - 2022-06-16 12:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:55 --> Total execution time: 0.0555
DEBUG - 2022-06-16 12:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:59 --> Total execution time: 0.0504
DEBUG - 2022-06-16 12:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:34:08 --> Total execution time: 0.0924
DEBUG - 2022-06-16 12:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:34:53 --> Total execution time: 0.0451
DEBUG - 2022-06-16 12:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:04 --> Total execution time: 0.0478
DEBUG - 2022-06-16 12:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:14 --> Total execution time: 0.0458
DEBUG - 2022-06-16 12:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:23 --> Total execution time: 0.0646
DEBUG - 2022-06-16 12:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:26 --> Total execution time: 0.0502
DEBUG - 2022-06-16 12:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:28 --> Total execution time: 0.0442
DEBUG - 2022-06-16 12:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:31 --> Total execution time: 0.0500
DEBUG - 2022-06-16 12:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:40 --> Total execution time: 0.0734
DEBUG - 2022-06-16 12:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:51 --> Total execution time: 0.0496
DEBUG - 2022-06-16 12:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:06 --> Total execution time: 0.0430
DEBUG - 2022-06-16 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:13 --> Total execution time: 0.0468
DEBUG - 2022-06-16 12:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:18 --> Total execution time: 0.0774
DEBUG - 2022-06-16 12:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:30 --> Total execution time: 0.0464
DEBUG - 2022-06-16 12:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:32 --> Total execution time: 0.0377
DEBUG - 2022-06-16 12:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:40 --> Total execution time: 0.0540
DEBUG - 2022-06-16 12:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:54 --> Total execution time: 0.0434
DEBUG - 2022-06-16 12:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:01 --> Total execution time: 0.0716
DEBUG - 2022-06-16 12:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:12 --> Total execution time: 0.0411
DEBUG - 2022-06-16 12:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:16 --> Total execution time: 0.1313
DEBUG - 2022-06-16 12:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:16 --> Total execution time: 0.0468
DEBUG - 2022-06-16 12:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:16 --> Total execution time: 0.0468
DEBUG - 2022-06-16 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:19 --> Total execution time: 0.0437
DEBUG - 2022-06-16 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:22 --> Total execution time: 0.0466
DEBUG - 2022-06-16 12:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:26 --> Total execution time: 0.0422
DEBUG - 2022-06-16 12:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:34 --> Total execution time: 0.0741
DEBUG - 2022-06-16 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:39 --> Total execution time: 0.1077
DEBUG - 2022-06-16 12:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:42 --> Total execution time: 0.0419
DEBUG - 2022-06-16 12:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:45 --> Total execution time: 0.0392
DEBUG - 2022-06-16 12:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:05 --> Total execution time: 0.0623
DEBUG - 2022-06-16 12:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:10 --> Total execution time: 0.0833
DEBUG - 2022-06-16 12:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:19 --> Total execution time: 0.0906
DEBUG - 2022-06-16 12:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:26 --> Total execution time: 0.0377
DEBUG - 2022-06-16 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:30 --> Total execution time: 0.0441
DEBUG - 2022-06-16 12:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:33 --> Total execution time: 0.0514
DEBUG - 2022-06-16 12:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:43 --> Total execution time: 0.0870
DEBUG - 2022-06-16 12:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:47 --> Total execution time: 0.0405
DEBUG - 2022-06-16 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:52 --> Total execution time: 0.0432
DEBUG - 2022-06-16 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:58 --> Total execution time: 0.0420
DEBUG - 2022-06-16 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:39:03 --> Total execution time: 0.0486
DEBUG - 2022-06-16 12:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:39:27 --> Total execution time: 0.0493
DEBUG - 2022-06-16 12:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:09:45 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:39:45 --> Total execution time: 0.0461
DEBUG - 2022-06-16 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:39:57 --> Total execution time: 0.0379
DEBUG - 2022-06-16 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:08 --> Total execution time: 0.0298
DEBUG - 2022-06-16 12:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:09 --> Total execution time: 0.0413
DEBUG - 2022-06-16 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:12 --> Total execution time: 0.0409
DEBUG - 2022-06-16 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:16 --> Total execution time: 0.0465
DEBUG - 2022-06-16 12:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:19 --> Total execution time: 0.0443
DEBUG - 2022-06-16 12:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:29 --> Total execution time: 0.0489
DEBUG - 2022-06-16 12:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:30 --> Total execution time: 0.0559
DEBUG - 2022-06-16 12:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:31 --> Total execution time: 0.1077
DEBUG - 2022-06-16 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:53 --> Total execution time: 0.0472
DEBUG - 2022-06-16 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:40:55 --> Total execution time: 0.0755
DEBUG - 2022-06-16 12:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:41:07 --> Total execution time: 0.0881
DEBUG - 2022-06-16 12:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:41:21 --> Total execution time: 0.0477
DEBUG - 2022-06-16 12:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:41:40 --> Total execution time: 0.0445
DEBUG - 2022-06-16 12:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:11:56 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:41:56 --> Total execution time: 0.0417
DEBUG - 2022-06-16 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:42:14 --> Total execution time: 0.0458
DEBUG - 2022-06-16 12:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:42:19 --> Total execution time: 0.0403
DEBUG - 2022-06-16 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:42:25 --> Total execution time: 0.0868
DEBUG - 2022-06-16 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:42:27 --> Total execution time: 0.0435
DEBUG - 2022-06-16 12:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:42:35 --> Total execution time: 0.0792
DEBUG - 2022-06-16 12:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:42:43 --> Total execution time: 0.0433
DEBUG - 2022-06-16 12:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:42:56 --> Total execution time: 0.0743
DEBUG - 2022-06-16 12:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:43:12 --> Total execution time: 0.0484
DEBUG - 2022-06-16 12:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:43:13 --> Total execution time: 0.0580
DEBUG - 2022-06-16 12:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:43:16 --> Total execution time: 0.0524
DEBUG - 2022-06-16 12:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:13:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:43:18 --> Total execution time: 0.0394
DEBUG - 2022-06-16 12:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:13:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:43:47 --> Total execution time: 0.0954
DEBUG - 2022-06-16 12:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:14:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:44:00 --> Total execution time: 0.0461
DEBUG - 2022-06-16 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:44:16 --> Total execution time: 0.1002
DEBUG - 2022-06-16 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:14:16 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:44:16 --> Total execution time: 0.1004
DEBUG - 2022-06-16 12:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:14:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:44:19 --> Total execution time: 0.1094
DEBUG - 2022-06-16 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:14:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:44:22 --> Total execution time: 0.0968
DEBUG - 2022-06-16 12:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:44:40 --> Total execution time: 0.0439
DEBUG - 2022-06-16 12:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:44:51 --> Total execution time: 0.0617
DEBUG - 2022-06-16 12:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:01 --> Total execution time: 0.0557
DEBUG - 2022-06-16 12:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:17 --> Total execution time: 0.0387
DEBUG - 2022-06-16 12:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:23 --> Total execution time: 0.0383
DEBUG - 2022-06-16 12:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:32 --> Total execution time: 0.0377
DEBUG - 2022-06-16 12:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:45:38 --> Total execution time: 0.0497
DEBUG - 2022-06-16 12:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:56 --> Total execution time: 0.0380
DEBUG - 2022-06-16 12:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:15:58 --> Total execution time: 0.0450
DEBUG - 2022-06-16 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:16:01 --> Total execution time: 0.0641
DEBUG - 2022-06-16 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:01 --> Total execution time: 0.0462
DEBUG - 2022-06-16 12:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:03 --> Total execution time: 0.0608
DEBUG - 2022-06-16 12:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:06 --> Total execution time: 0.0475
DEBUG - 2022-06-16 12:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:07 --> Total execution time: 0.0424
DEBUG - 2022-06-16 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:10 --> Total execution time: 0.0403
DEBUG - 2022-06-16 12:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:12 --> Total execution time: 0.0471
DEBUG - 2022-06-16 12:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:24 --> Total execution time: 0.0454
DEBUG - 2022-06-16 12:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:24 --> Total execution time: 0.0505
DEBUG - 2022-06-16 12:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:16:29 --> Total execution time: 0.0559
DEBUG - 2022-06-16 12:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:30 --> Total execution time: 0.0418
DEBUG - 2022-06-16 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:16:31 --> Total execution time: 0.0500
DEBUG - 2022-06-16 12:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:16:31 --> Total execution time: 0.0813
DEBUG - 2022-06-16 12:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:33 --> Total execution time: 0.0513
DEBUG - 2022-06-16 12:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:38 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:39 --> Total execution time: 0.0952
DEBUG - 2022-06-16 12:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:40 --> Total execution time: 0.0481
DEBUG - 2022-06-16 12:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:50 --> Total execution time: 0.0372
DEBUG - 2022-06-16 12:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:17:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:02 --> Total execution time: 0.0549
DEBUG - 2022-06-16 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:09 --> Total execution time: 0.0418
DEBUG - 2022-06-16 12:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:28 --> Total execution time: 1.9421
DEBUG - 2022-06-16 12:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:33 --> Total execution time: 0.0380
DEBUG - 2022-06-16 12:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 12:17:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:48:07 --> Total execution time: 0.0378
DEBUG - 2022-06-16 12:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:18:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:48:25 --> Total execution time: 0.0408
DEBUG - 2022-06-16 12:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:48:34 --> Total execution time: 1.5892
DEBUG - 2022-06-16 12:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:49:45 --> Total execution time: 0.0390
DEBUG - 2022-06-16 12:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:49:47 --> Total execution time: 0.0322
DEBUG - 2022-06-16 12:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:50:08 --> Total execution time: 0.0375
DEBUG - 2022-06-16 12:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:13 --> Total execution time: 0.0438
DEBUG - 2022-06-16 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:16 --> Total execution time: 0.0391
DEBUG - 2022-06-16 12:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:16 --> Total execution time: 0.0884
DEBUG - 2022-06-16 12:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:20:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:50:25 --> Total execution time: 0.0941
DEBUG - 2022-06-16 12:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:50:51 --> Total execution time: 0.0447
DEBUG - 2022-06-16 12:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:51:00 --> Total execution time: 0.0594
DEBUG - 2022-06-16 12:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:51:22 --> Total execution time: 0.0635
DEBUG - 2022-06-16 12:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:21:33 --> Total execution time: 0.0461
DEBUG - 2022-06-16 12:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:21:35 --> Total execution time: 0.0428
DEBUG - 2022-06-16 12:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:21:35 --> Total execution time: 0.0484
DEBUG - 2022-06-16 12:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:24:12 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:54:12 --> Total execution time: 0.1816
DEBUG - 2022-06-16 12:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:56:43 --> Total execution time: 0.1395
DEBUG - 2022-06-16 12:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:56:47 --> Total execution time: 0.0375
DEBUG - 2022-06-16 12:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:26:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:56:50 --> Total execution time: 0.0490
DEBUG - 2022-06-16 12:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:56:54 --> Total execution time: 0.0431
DEBUG - 2022-06-16 12:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:57:07 --> Total execution time: 0.0387
DEBUG - 2022-06-16 12:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:57:40 --> Total execution time: 0.0457
DEBUG - 2022-06-16 12:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:58:09 --> Total execution time: 0.0616
DEBUG - 2022-06-16 12:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:58:53 --> Total execution time: 0.0407
DEBUG - 2022-06-16 12:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:02 --> Total execution time: 0.0700
DEBUG - 2022-06-16 12:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:03 --> Total execution time: 0.0425
DEBUG - 2022-06-16 12:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:14 --> Total execution time: 0.0402
DEBUG - 2022-06-16 12:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:30 --> Total execution time: 0.0459
DEBUG - 2022-06-16 12:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:31 --> Total execution time: 0.0409
DEBUG - 2022-06-16 12:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:47 --> Total execution time: 0.0445
DEBUG - 2022-06-16 12:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:00:49 --> Total execution time: 0.0402
DEBUG - 2022-06-16 12:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:00:53 --> Total execution time: 0.0447
DEBUG - 2022-06-16 12:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:00:56 --> Total execution time: 0.0393
DEBUG - 2022-06-16 12:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:30:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:00:59 --> Total execution time: 0.0468
DEBUG - 2022-06-16 12:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:01:43 --> Total execution time: 0.0385
DEBUG - 2022-06-16 12:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:37:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:07:03 --> Total execution time: 0.1678
DEBUG - 2022-06-16 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:07:14 --> Total execution time: 0.0394
DEBUG - 2022-06-16 12:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:07:50 --> Total execution time: 0.0610
DEBUG - 2022-06-16 12:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:08:14 --> Total execution time: 0.0526
DEBUG - 2022-06-16 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:09:29 --> Total execution time: 0.0804
DEBUG - 2022-06-16 12:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:10:17 --> Total execution time: 0.0463
DEBUG - 2022-06-16 12:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:10:41 --> Total execution time: 0.0530
DEBUG - 2022-06-16 12:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:08 --> Total execution time: 0.1638
DEBUG - 2022-06-16 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:09 --> Total execution time: 0.1174
DEBUG - 2022-06-16 12:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:13 --> Total execution time: 0.0472
DEBUG - 2022-06-16 12:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:19 --> Total execution time: 0.0789
DEBUG - 2022-06-16 12:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:33 --> Total execution time: 0.0616
DEBUG - 2022-06-16 12:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:39 --> Total execution time: 0.0354
DEBUG - 2022-06-16 12:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:55 --> Total execution time: 0.0569
DEBUG - 2022-06-16 12:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:49:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:19:02 --> Total execution time: 0.1529
DEBUG - 2022-06-16 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:03 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:03 --> Total execution time: 0.0860
DEBUG - 2022-06-16 12:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:06 --> Total execution time: 0.0461
DEBUG - 2022-06-16 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 12:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:08 --> Total execution time: 0.0312
DEBUG - 2022-06-16 12:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:17 --> Total execution time: 0.0418
DEBUG - 2022-06-16 12:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:24 --> Total execution time: 0.0669
DEBUG - 2022-06-16 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:24 --> Total execution time: 0.0413
DEBUG - 2022-06-16 12:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:28 --> Total execution time: 0.0371
DEBUG - 2022-06-16 12:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:29 --> Total execution time: 0.0502
DEBUG - 2022-06-16 12:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 12:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:36 --> Total execution time: 0.0502
DEBUG - 2022-06-16 12:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:37 --> Total execution time: 0.0435
DEBUG - 2022-06-16 12:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:40 --> Total execution time: 0.0464
DEBUG - 2022-06-16 12:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:43 --> Total execution time: 0.0404
DEBUG - 2022-06-16 12:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 12:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 12:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:22:48 --> Total execution time: 0.1052
DEBUG - 2022-06-16 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:30:03 --> Total execution time: 0.1516
DEBUG - 2022-06-16 13:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:31:34 --> Total execution time: 0.1338
DEBUG - 2022-06-16 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:32:02 --> Total execution time: 0.1177
DEBUG - 2022-06-16 13:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:08 --> Total execution time: 0.0463
DEBUG - 2022-06-16 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:11 --> Total execution time: 0.0619
DEBUG - 2022-06-16 13:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:18 --> Total execution time: 0.0424
DEBUG - 2022-06-16 13:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:05:38 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:35:38 --> Total execution time: 0.1171
DEBUG - 2022-06-16 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:36:03 --> Total execution time: 0.0438
DEBUG - 2022-06-16 13:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:36:13 --> Total execution time: 0.0445
DEBUG - 2022-06-16 13:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:38:33 --> Total execution time: 0.1752
DEBUG - 2022-06-16 13:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:17 --> Total execution time: 0.0680
DEBUG - 2022-06-16 13:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:13:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:13:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:13:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:43:33 --> Total execution time: 0.0391
DEBUG - 2022-06-16 23:43:33 --> Total execution time: 0.0402
DEBUG - 2022-06-16 23:43:33 --> Total execution time: 0.0810
DEBUG - 2022-06-16 13:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:13:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:43:33 --> Total execution time: 0.0426
DEBUG - 2022-06-16 13:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:13:35 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:43:35 --> Total execution time: 0.0369
DEBUG - 2022-06-16 13:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:13:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:43:47 --> Total execution time: 0.0304
DEBUG - 2022-06-16 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:13:52 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:43:52 --> Total execution time: 0.0325
DEBUG - 2022-06-16 13:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:14:31 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:44:31 --> Total execution time: 0.0378
DEBUG - 2022-06-16 13:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:14:35 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:44:35 --> Total execution time: 0.0370
DEBUG - 2022-06-16 13:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:14:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:44:59 --> Total execution time: 0.0523
DEBUG - 2022-06-16 13:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:15:03 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:45:03 --> Total execution time: 0.0337
DEBUG - 2022-06-16 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:15:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:45:50 --> Total execution time: 0.0313
DEBUG - 2022-06-16 13:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:15:51 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:45:51 --> Total execution time: 0.0393
DEBUG - 2022-06-16 13:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:16:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:50 --> Total execution time: 0.0336
DEBUG - 2022-06-16 13:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:16:52 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:52 --> Total execution time: 0.0300
DEBUG - 2022-06-16 13:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:16:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 13:16:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 13:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:48:53 --> Total execution time: 0.0412
DEBUG - 2022-06-16 13:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:51:49 --> Total execution time: 0.0863
DEBUG - 2022-06-16 13:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:22:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:52:32 --> Total execution time: 0.0375
DEBUG - 2022-06-16 13:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:23:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:53:08 --> Total execution time: 0.0318
DEBUG - 2022-06-16 13:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:26:20 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:56:20 --> Total execution time: 0.0929
DEBUG - 2022-06-16 13:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:28 --> Total execution time: 0.0303
DEBUG - 2022-06-16 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:29 --> Total execution time: 0.0410
DEBUG - 2022-06-16 13:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:29 --> Total execution time: 0.0632
DEBUG - 2022-06-16 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:45 --> Total execution time: 0.0386
DEBUG - 2022-06-16 13:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:26:50 --> Total execution time: 0.0400
DEBUG - 2022-06-16 13:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:27:22 --> Total execution time: 0.0445
DEBUG - 2022-06-16 13:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:27:54 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:57:54 --> Total execution time: 0.0437
DEBUG - 2022-06-16 13:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:41:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:42:10 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:42:27 --> Total execution time: 0.0500
DEBUG - 2022-06-16 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:42:29 --> Total execution time: 0.0597
DEBUG - 2022-06-16 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:42:29 --> Total execution time: 0.0421
DEBUG - 2022-06-16 13:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:42:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:44:55 --> Total execution time: 0.0466
DEBUG - 2022-06-16 13:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:29 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:29 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:29 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:29 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:29 --> No URI present. Default controller set.
DEBUG - 2022-06-16 13:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:39 --> Total execution time: 0.0383
DEBUG - 2022-06-16 13:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:40 --> Total execution time: 0.0450
DEBUG - 2022-06-16 13:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:45:40 --> Total execution time: 0.0863
DEBUG - 2022-06-16 13:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:46:04 --> Total execution time: 0.1025
DEBUG - 2022-06-16 13:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 13:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 13:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 13:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:01:43 --> No URI present. Default controller set.
DEBUG - 2022-06-16 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:29:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 14:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:39:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 14:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 14:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 14:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 15:21:04 --> 404 Page Not Found: Defaul1php/index
ERROR - 2022-06-16 15:21:04 --> 404 Page Not Found: Defau11php/index
ERROR - 2022-06-16 15:21:04 --> 404 Page Not Found: Defau1tphp/index
DEBUG - 2022-06-16 15:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:23:06 --> No URI present. Default controller set.
DEBUG - 2022-06-16 15:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:23:35 --> Total execution time: 0.0921
DEBUG - 2022-06-16 15:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:23:37 --> Total execution time: 0.0696
DEBUG - 2022-06-16 15:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:23:37 --> Total execution time: 0.0785
DEBUG - 2022-06-16 15:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 15:23:44 --> Total execution time: 0.0383
DEBUG - 2022-06-16 15:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 15:24:22 --> No URI present. Default controller set.
DEBUG - 2022-06-16 15:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 15:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 16:18:05 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 16:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 16:43:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-16 16:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 16:48:04 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-06-16 16:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:50:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 16:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:50:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 16:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:50:40 --> No URI present. Default controller set.
DEBUG - 2022-06-16 16:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:50:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 16:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:51:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 16:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 16:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 16:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 16:56:14 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-06-16 16:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:57:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 16:57:56 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-16 16:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 16:58:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 16:58:13 --> 404 Page Not Found: Reselling-course/esalestrix.in
DEBUG - 2022-06-16 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:09:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 17:09:15 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 17:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:11:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 17:11:31 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-16 17:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 17:13:41 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 17:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:13:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 17:13:50 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-06-16 17:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 17:15:12 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 17:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:15:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 17:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:15:17 --> No URI present. Default controller set.
DEBUG - 2022-06-16 17:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:16:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 17:16:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 17:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:27:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 17:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 17:34:01 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 17:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:44:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 17:44:04 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-16 17:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:57:57 --> No URI present. Default controller set.
DEBUG - 2022-06-16 17:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:59:29 --> No URI present. Default controller set.
DEBUG - 2022-06-16 17:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:59:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 17:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 17:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 17:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 17:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 18:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 18:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 18:24:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 18:24:32 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-16 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:09:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 19:09:42 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-16 19:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:39:42 --> No URI present. Default controller set.
DEBUG - 2022-06-16 19:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:39:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 19:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:40:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 19:40:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 19:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 19:40:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 19:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:40:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 19:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:40:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 19:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:51:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 19:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 19:52:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-16 19:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 19:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 19:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 19:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 19:59:53 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:29 --> Total execution time: 0.0395
DEBUG - 2022-06-16 20:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:33 --> Total execution time: 0.0417
DEBUG - 2022-06-16 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:37 --> Total execution time: 0.0376
DEBUG - 2022-06-16 20:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:41 --> Total execution time: 0.0361
DEBUG - 2022-06-16 20:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:11:51 --> Total execution time: 0.0383
DEBUG - 2022-06-16 20:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:12:26 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:12:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 20:12:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 20:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:51 --> Total execution time: 0.0398
DEBUG - 2022-06-16 20:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:27:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 20:28:01 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-16 20:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 20:30:27 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-16 20:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:32:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 20:32:29 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-16 20:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:16 --> Total execution time: 0.0468
DEBUG - 2022-06-16 20:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:25 --> Total execution time: 0.0586
DEBUG - 2022-06-16 20:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:45 --> Total execution time: 0.0374
DEBUG - 2022-06-16 20:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:35:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:35:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:35:59 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:41 --> Total execution time: 0.0320
DEBUG - 2022-06-16 20:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:42 --> Total execution time: 0.0475
DEBUG - 2022-06-16 20:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:37:43 --> Total execution time: 0.1059
DEBUG - 2022-06-16 20:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:38:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:38:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:42:19 --> No URI present. Default controller set.
DEBUG - 2022-06-16 20:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 20:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:54:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 20:54:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-16 20:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 20:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 20:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:01:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:02:44 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:05:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 21:05:08 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 21:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:05:38 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:07:06 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:07:22 --> Total execution time: 0.0295
DEBUG - 2022-06-16 21:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:07:34 --> Total execution time: 0.0500
DEBUG - 2022-06-16 21:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:07:34 --> Total execution time: 0.0614
DEBUG - 2022-06-16 21:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:08:19 --> Total execution time: 0.0539
DEBUG - 2022-06-16 21:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:08:20 --> Total execution time: 0.0387
DEBUG - 2022-06-16 21:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:08:20 --> Total execution time: 0.0463
DEBUG - 2022-06-16 21:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:15:45 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:15:52 --> Total execution time: 0.0942
DEBUG - 2022-06-16 21:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:15:56 --> Total execution time: 0.0425
DEBUG - 2022-06-16 21:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:15:56 --> Total execution time: 0.0880
DEBUG - 2022-06-16 21:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:22 --> Total execution time: 0.0450
DEBUG - 2022-06-16 21:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:23 --> Total execution time: 0.0373
DEBUG - 2022-06-16 21:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:23 --> Total execution time: 0.0398
DEBUG - 2022-06-16 21:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:45 --> Total execution time: 0.0358
DEBUG - 2022-06-16 21:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:47 --> Total execution time: 0.0382
DEBUG - 2022-06-16 21:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:16:47 --> Total execution time: 0.0442
DEBUG - 2022-06-16 21:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:17:12 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:17:19 --> Total execution time: 0.0414
DEBUG - 2022-06-16 21:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:17:21 --> Total execution time: 0.0414
DEBUG - 2022-06-16 21:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:17:21 --> Total execution time: 0.0851
DEBUG - 2022-06-16 21:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:18:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:18:34 --> Total execution time: 0.0625
DEBUG - 2022-06-16 21:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:18:35 --> Total execution time: 0.0435
DEBUG - 2022-06-16 21:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:18:35 --> Total execution time: 0.0667
DEBUG - 2022-06-16 21:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:19:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 21:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:19:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 21:19:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 21:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:22:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:31:18 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:31:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 21:31:23 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-16 21:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 21:31:26 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-16 21:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:32:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:15 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 21:34:10 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-16 21:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:37 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:48:25 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:48:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:48:43 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:35 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:43 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:49:51 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:50:17 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:51:48 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:53:38 --> Total execution time: 0.0499
DEBUG - 2022-06-16 21:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:53:40 --> Total execution time: 0.0410
DEBUG - 2022-06-16 21:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:53:40 --> Total execution time: 0.0744
DEBUG - 2022-06-16 21:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:53:58 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:54:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:55:11 --> No URI present. Default controller set.
DEBUG - 2022-06-16 21:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 21:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 21:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 21:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:01:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 22:01:18 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-16 22:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 22:03:41 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-16 22:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:05:11 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:05:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 22:05:39 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-16 22:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:35 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:16 --> Total execution time: 0.0435
DEBUG - 2022-06-16 22:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:17 --> Total execution time: 0.0480
DEBUG - 2022-06-16 22:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:17 --> Total execution time: 0.0785
DEBUG - 2022-06-16 22:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:35 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 22:07:42 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-16 22:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:43 --> Total execution time: 0.0473
DEBUG - 2022-06-16 22:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:44 --> Total execution time: 0.0543
DEBUG - 2022-06-16 22:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:44 --> Total execution time: 0.0733
DEBUG - 2022-06-16 22:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:51 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:57 --> Total execution time: 0.0394
DEBUG - 2022-06-16 22:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:58 --> Total execution time: 0.0481
DEBUG - 2022-06-16 22:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:07:58 --> Total execution time: 0.1016
DEBUG - 2022-06-16 22:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:08:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:08:12 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 22:09:16 --> 404 Page Not Found: Uplphp/index
DEBUG - 2022-06-16 22:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:27:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 22:27:51 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-16 22:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:33:34 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:33:45 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:06 --> Total execution time: 0.0471
DEBUG - 2022-06-16 22:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:08 --> Total execution time: 0.0627
DEBUG - 2022-06-16 22:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:08 --> Total execution time: 0.0967
DEBUG - 2022-06-16 22:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:16 --> Total execution time: 0.0460
DEBUG - 2022-06-16 22:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:35:17 --> Total execution time: 0.0390
DEBUG - 2022-06-16 22:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-16 22:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:35 --> Total execution time: 0.0452
DEBUG - 2022-06-16 22:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:40 --> Total execution time: 0.0379
DEBUG - 2022-06-16 22:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:47 --> Total execution time: 0.0399
DEBUG - 2022-06-16 22:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:37:54 --> Total execution time: 0.0388
DEBUG - 2022-06-16 22:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:38:30 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:38:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:38:50 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:39:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:52:08 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 22:52:31 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 22:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:54:47 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:55:23 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:58:00 --> No URI present. Default controller set.
DEBUG - 2022-06-16 22:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:35 --> Total execution time: 0.0465
DEBUG - 2022-06-16 22:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 22:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 22:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 22:59:47 --> Total execution time: 0.1177
DEBUG - 2022-06-16 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:02:07 --> Total execution time: 0.0391
DEBUG - 2022-06-16 23:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:08:02 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:15:31 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-16 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:17:16 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:24 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:29:01 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:30:41 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:32:54 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-16 23:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:32:55 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:32:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:32:57 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-16 23:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:32:58 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-16 23:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:32:59 --> 404 Page Not Found: Contact/index
DEBUG - 2022-06-16 23:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:33:39 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:06 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:36:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:36:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-16 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:37:41 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-16 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:37:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 23:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:38:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:38:47 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-16 23:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:39:26 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:39:42 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:39:50 --> Total execution time: 0.0379
DEBUG - 2022-06-16 23:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:39:52 --> Total execution time: 0.0486
DEBUG - 2022-06-16 23:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:39:52 --> Total execution time: 0.0906
DEBUG - 2022-06-16 23:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:10 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:14 --> Total execution time: 0.0397
DEBUG - 2022-06-16 23:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:15 --> Total execution time: 0.0438
DEBUG - 2022-06-16 23:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:16 --> Total execution time: 0.0774
DEBUG - 2022-06-16 23:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:23 --> Total execution time: 0.0505
DEBUG - 2022-06-16 23:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:27 --> Total execution time: 0.0363
DEBUG - 2022-06-16 23:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:30 --> Total execution time: 0.0372
DEBUG - 2022-06-16 23:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:40:33 --> Total execution time: 0.0499
DEBUG - 2022-06-16 23:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:40:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:40:59 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-16 23:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:42:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:42:27 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:09 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:32 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:33 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:47:16 --> Total execution time: 0.0452
DEBUG - 2022-06-16 23:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:47:19 --> Total execution time: 0.0395
DEBUG - 2022-06-16 23:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:47:19 --> Total execution time: 0.0735
DEBUG - 2022-06-16 23:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:51:13 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:53:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:54:53 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:55:03 --> No URI present. Default controller set.
DEBUG - 2022-06-16 23:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:55:19 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-06-16 23:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-16 23:55:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-16 23:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-16 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-16 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-16 23:56:11 --> Encryption: Auto-configured driver 'openssl'.
