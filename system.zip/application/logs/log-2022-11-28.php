<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-28 14:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-28 14:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-28 14:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-28 14:23:55 --> Total execution time: 4.5501
DEBUG - 2022-11-28 14:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-28 14:23:58 --> No URI present. Default controller set.
DEBUG - 2022-11-28 14:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-28 14:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-28 18:53:58 --> Total execution time: 0.1253
DEBUG - 2022-11-28 16:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-28 16:39:14 --> No URI present. Default controller set.
DEBUG - 2022-11-28 16:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-28 16:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-28 21:09:15 --> Total execution time: 0.5200
DEBUG - 2022-11-28 16:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-28 16:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-28 16:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-28 21:09:18 --> Total execution time: 0.0589
