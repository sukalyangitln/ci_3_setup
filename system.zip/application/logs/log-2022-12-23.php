<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-23 04:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 04:23:05 --> Total execution time: 0.0582
DEBUG - 2022-12-23 04:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:23:08 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:23:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-23 08:53:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Products C:\xampp\htdocs\gopal\crowd_funding\system\core\Loader.php 348
DEBUG - 2022-12-23 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:40:06 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:40:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-23 09:10:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Products C:\xampp\htdocs\gopal\crowd_funding\system\core\Loader.php 348
DEBUG - 2022-12-23 04:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:40:52 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:40:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:40:52 --> Severity: error --> Exception: Class 'NORMAL_Controller' not found C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Welcome.php 3
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:11:22 --> Total execution time: 0.0658
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/css
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/js
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:41:22 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:12:44 --> Total execution time: 0.0413
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/vendors
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/css
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:44 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:42:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:42:45 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:43:03 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:13:03 --> Total execution time: 0.0623
DEBUG - 2022-12-23 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:43:03 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:43:03 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:43:03 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:43:03 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:43:03 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:43:03 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:43:03 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:18 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:15:18 --> Total execution time: 0.0841
DEBUG - 2022-12-23 04:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:19 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:45:19 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:45:19 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 04:45:19 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:19 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:45:19 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:45:19 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:45:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:19 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 04:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:56 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:15:56 --> Total execution time: 0.0577
DEBUG - 2022-12-23 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:56 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 04:45:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:45:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:45:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:46:21 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:16:21 --> Total execution time: 0.0560
DEBUG - 2022-12-23 04:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:48:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:48:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:48:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:48:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:28 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:18:28 --> Total execution time: 0.0538
DEBUG - 2022-12-23 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:48:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:48:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:48:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:48:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:48:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:49:42 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:19:42 --> Total execution time: 0.0651
DEBUG - 2022-12-23 04:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:51:51 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:21:51 --> Total execution time: 0.0473
DEBUG - 2022-12-23 04:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:52:49 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:22:49 --> Total execution time: 0.0393
DEBUG - 2022-12-23 04:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:54:04 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:24:04 --> Total execution time: 0.0651
DEBUG - 2022-12-23 04:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:54:28 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:24:28 --> Total execution time: 0.0386
DEBUG - 2022-12-23 04:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:08 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:25:08 --> Total execution time: 0.0485
DEBUG - 2022-12-23 04:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:55:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:55:19 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 04:55:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:55:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:34 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:25:34 --> Total execution time: 0.0698
DEBUG - 2022-12-23 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:55:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:55:34 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 04:55:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:55:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:55:54 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:25:54 --> Total execution time: 0.0662
DEBUG - 2022-12-23 04:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:56:09 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:26:09 --> Total execution time: 0.0495
DEBUG - 2022-12-23 04:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:56:41 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:26:41 --> Total execution time: 0.0776
DEBUG - 2022-12-23 04:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:57:05 --> UTF-8 Support Enabled
ERROR - 2022-12-23 04:57:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:57:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:57:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:57:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:19 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:27:19 --> Total execution time: 0.0773
DEBUG - 2022-12-23 04:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 04:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 04:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:26 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:27:26 --> Total execution time: 0.0494
DEBUG - 2022-12-23 04:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 04:57:39 --> No URI present. Default controller set.
DEBUG - 2022-12-23 04:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 04:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 04:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:27:39 --> Total execution time: 0.0508
DEBUG - 2022-12-23 05:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:01:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:01:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:01:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:01:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:37 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:31:37 --> Total execution time: 0.0720
DEBUG - 2022-12-23 05:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:01:38 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:01:38 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:01:38 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:01:38 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:02:28 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:32:28 --> Total execution time: 0.0650
DEBUG - 2022-12-23 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:02:28 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:02:28 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:02:28 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:02:28 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:26 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:33:26 --> Total execution time: 0.0688
DEBUG - 2022-12-23 05:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:03:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:03:26 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:03:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:03:27 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:41 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:33:41 --> Total execution time: 0.0622
DEBUG - 2022-12-23 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:03:41 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:03:41 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:03:41 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:03:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:03:41 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:03 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:34:03 --> Total execution time: 0.0504
DEBUG - 2022-12-23 05:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:04 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:08 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:34:09 --> Total execution time: 0.0635
DEBUG - 2022-12-23 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:09 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:09 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:04:09 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:09 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:25 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:34:25 --> Total execution time: 0.0452
DEBUG - 2022-12-23 05:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:25 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:04:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:04:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:05:04 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:35:04 --> Total execution time: 0.0579
DEBUG - 2022-12-23 05:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:05:23 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:35:23 --> Total execution time: 0.0567
DEBUG - 2022-12-23 05:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:08:52 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:38:52 --> Total execution time: 0.0634
DEBUG - 2022-12-23 05:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:09:33 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:39:33 --> Total execution time: 0.0421
DEBUG - 2022-12-23 05:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:09:44 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:39:44 --> Total execution time: 0.0546
DEBUG - 2022-12-23 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:10:13 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:10:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:10:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:10:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:11:01 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:41:01 --> Total execution time: 0.0592
DEBUG - 2022-12-23 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:12:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:12:00 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:12:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:12:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:08 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:42:08 --> Total execution time: 0.0426
DEBUG - 2022-12-23 05:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:12:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:12:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:12:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:12:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:11 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:43:11 --> Total execution time: 0.0636
DEBUG - 2022-12-23 05:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:13:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:13:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:13:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:13:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:26 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:43:26 --> Total execution time: 0.0463
DEBUG - 2022-12-23 05:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:13:27 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:13:27 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:13:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:13:27 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:13:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:13:27 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:18:35 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:48:35 --> Total execution time: 0.0437
DEBUG - 2022-12-23 05:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:18:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:18:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:18:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:18:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:19:17 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:49:17 --> Total execution time: 0.0385
DEBUG - 2022-12-23 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:19:34 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:49:34 --> Total execution time: 0.0404
DEBUG - 2022-12-23 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:19:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:19:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:19:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:19:34 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:19:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:19:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:19:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:20:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:20:35 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:20:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:20:35 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:36 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:51:36 --> Total execution time: 0.0648
DEBUG - 2022-12-23 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:21:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:21:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:21:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:21:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:56 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:51:56 --> Total execution time: 0.0662
DEBUG - 2022-12-23 05:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:21:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:21:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:21:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:21:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:21:57 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:23:20 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:53:20 --> Total execution time: 0.0614
DEBUG - 2022-12-23 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:23:20 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:23:20 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:23:20 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:23:20 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:25:46 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:55:47 --> Total execution time: 0.0687
DEBUG - 2022-12-23 05:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:25:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:25:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:25:47 --> UTF-8 Support Enabled
ERROR - 2022-12-23 05:25:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:25:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:25:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:25:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:25:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:27:23 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:57:23 --> Total execution time: 0.0710
DEBUG - 2022-12-23 05:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:29:02 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:59:02 --> Total execution time: 0.0523
DEBUG - 2022-12-23 05:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:29:34 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 09:59:34 --> Total execution time: 0.0561
DEBUG - 2022-12-23 05:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:05 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:00:05 --> Total execution time: 0.0383
DEBUG - 2022-12-23 05:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:08 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:25 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:00:25 --> Total execution time: 0.0399
DEBUG - 2022-12-23 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:25 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:46 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:00:46 --> Total execution time: 0.0424
DEBUG - 2022-12-23 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:59 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:00:59 --> Total execution time: 0.0536
DEBUG - 2022-12-23 05:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:30:59 --> UTF-8 Support Enabled
ERROR - 2022-12-23 05:30:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:30:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:30:59 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:31:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:31:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:31:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:31:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:32:07 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:02:07 --> Total execution time: 0.0368
DEBUG - 2022-12-23 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:32:07 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:32:07 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:32:07 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:32:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:32:07 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:38:20 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:08:20 --> Total execution time: 0.0384
DEBUG - 2022-12-23 05:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:38:20 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:38:20 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:38:20 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:38:20 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:23 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:10:23 --> Total execution time: 0.0652
DEBUG - 2022-12-23 05:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:40:23 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:40:23 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:40:23 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:40:23 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:43 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:10:43 --> Total execution time: 0.0489
DEBUG - 2022-12-23 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:40:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:40:44 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:40:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:40:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:45:54 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:15:54 --> Total execution time: 0.0535
DEBUG - 2022-12-23 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:45:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:45:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:45:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:45:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:46:29 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:16:29 --> Total execution time: 0.0593
DEBUG - 2022-12-23 05:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:46:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:46:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:46:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:46:30 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:46:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:46:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:46:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:02 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:17:02 --> Total execution time: 0.0446
DEBUG - 2022-12-23 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:47:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:47:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:47:02 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:47:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:47:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:56 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:17:56 --> Total execution time: 0.0636
DEBUG - 2022-12-23 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:47:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:47:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:47:56 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 05:47:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:47:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 05:47:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 05:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:48:15 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:18:15 --> Total execution time: 0.0860
DEBUG - 2022-12-23 05:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:48:33 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:18:33 --> Total execution time: 0.0692
DEBUG - 2022-12-23 05:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:48:48 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:18:48 --> Total execution time: 0.0876
DEBUG - 2022-12-23 05:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:49:33 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:19:33 --> Total execution time: 0.0383
DEBUG - 2022-12-23 05:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:49:50 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:19:50 --> Total execution time: 0.0499
DEBUG - 2022-12-23 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:50:16 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:20:16 --> Total execution time: 0.0408
DEBUG - 2022-12-23 05:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 05:50:38 --> No URI present. Default controller set.
DEBUG - 2022-12-23 05:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 05:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 05:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 10:20:39 --> Total execution time: 0.0509
DEBUG - 2022-12-23 08:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:06:41 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:36:41 --> Total execution time: 0.7262
DEBUG - 2022-12-23 08:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:06:54 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:06:54 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:06:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:06:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:10:31 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:40:31 --> Total execution time: 0.0607
DEBUG - 2022-12-23 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:10:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:10:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:10:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:10:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:10:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:14:51 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:44:51 --> Total execution time: 0.7120
DEBUG - 2022-12-23 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:14:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:14:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:14:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:14:51 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:21 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:45:22 --> Total execution time: 0.0526
DEBUG - 2022-12-23 08:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:22 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:22 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:22 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:22 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:36 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:45:36 --> Total execution time: 0.0386
DEBUG - 2022-12-23 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:36 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:15:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:49 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:45:49 --> Total execution time: 0.0536
DEBUG - 2022-12-23 08:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:15:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:16:42 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:46:42 --> Total execution time: 0.0388
DEBUG - 2022-12-23 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:16:43 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:16:43 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:16:43 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:16:43 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:20 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:48:20 --> Total execution time: 0.0638
DEBUG - 2022-12-23 08:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:18:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:18:21 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:18:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:18:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:56 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:48:56 --> Total execution time: 0.0500
DEBUG - 2022-12-23 08:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:18:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:18:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:18:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:18:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:18:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:19:56 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:49:56 --> Total execution time: 0.0451
DEBUG - 2022-12-23 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:19:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:19:56 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:19:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:19:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:23:14 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:53:14 --> Total execution time: 0.0489
DEBUG - 2022-12-23 08:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:23:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:23:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:23:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:23:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:00 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:54:00 --> Total execution time: 0.0553
DEBUG - 2022-12-23 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:24:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:24:00 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:24:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:24:00 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:24:15 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:24:15 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:24:15 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:24:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:24:15 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:28:43 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 12:58:43 --> Total execution time: 0.0621
DEBUG - 2022-12-23 08:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:28:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:28:43 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:28:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:28:43 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:28:43 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:28:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:28:43 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:20 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:05:20 --> Total execution time: 0.0608
DEBUG - 2022-12-23 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:35:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:35:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:35:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:35:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:42 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:05:42 --> Total execution time: 0.0574
DEBUG - 2022-12-23 08:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:35:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:35:42 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:35:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:35:42 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:37:13 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:07:13 --> Total execution time: 0.0404
DEBUG - 2022-12-23 08:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:37:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:37:14 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:37:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:37:14 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:38:19 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:08:19 --> Total execution time: 0.0411
DEBUG - 2022-12-23 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:38:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:38:19 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:38:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:38:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:29 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:09:29 --> Total execution time: 0.0372
DEBUG - 2022-12-23 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:39:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:39:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:39:29 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:39:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:39:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:52 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:09:52 --> Total execution time: 0.0615
DEBUG - 2022-12-23 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:39:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:39:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:39:52 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:39:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:39:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:39:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:41:29 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:11:29 --> Total execution time: 0.0389
DEBUG - 2022-12-23 08:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:41:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:41:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:41:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:41:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:41:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:42:38 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:42:38 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:42:38 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:42:38 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:43:29 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:13:29 --> Total execution time: 0.0705
DEBUG - 2022-12-23 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:43:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:43:30 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:43:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:43:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:49:18 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:19:18 --> Total execution time: 0.0612
DEBUG - 2022-12-23 08:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:49:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:49:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:49:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:49:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:49:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:51:32 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:21:32 --> Total execution time: 0.0545
DEBUG - 2022-12-23 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:51:32 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:51:32 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:51:32 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:51:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:51:32 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:53:33 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:23:33 --> Total execution time: 0.0425
DEBUG - 2022-12-23 08:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:53:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:53:33 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:53:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:53:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:53:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:00 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:24:00 --> Total execution time: 0.0639
DEBUG - 2022-12-23 08:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:54:01 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:54:01 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:54:01 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:54:01 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:21 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:24:21 --> Total execution time: 0.0764
DEBUG - 2022-12-23 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:54:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:54:21 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:54:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:54:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:05 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:25:05 --> Total execution time: 0.0629
DEBUG - 2022-12-23 08:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:05 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:55:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:05 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:25 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:25:25 --> Total execution time: 0.0416
DEBUG - 2022-12-23 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:55 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:25:55 --> Total execution time: 0.0402
DEBUG - 2022-12-23 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:55 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 08:55:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 08:55:55 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 08:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 08:57:47 --> No URI present. Default controller set.
DEBUG - 2022-12-23 08:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 08:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 08:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 13:27:47 --> Total execution time: 0.0540
DEBUG - 2022-12-23 12:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:12:09 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 16:42:10 --> Total execution time: 0.4574
DEBUG - 2022-12-23 12:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:17:19 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 16:47:19 --> Total execution time: 0.0536
DEBUG - 2022-12-23 12:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:41:10 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:11:10 --> Total execution time: 0.0410
DEBUG - 2022-12-23 12:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:44:26 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:14:26 --> Total execution time: 0.0602
DEBUG - 2022-12-23 12:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:44:42 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:14:42 --> Total execution time: 0.0747
DEBUG - 2022-12-23 12:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:45:30 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:15:30 --> Total execution time: 0.0459
DEBUG - 2022-12-23 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:45:50 --> UTF-8 Support Enabled
ERROR - 2022-12-23 12:45:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 12:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 12:45:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 12:45:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 12:45:50 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 12:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:48:19 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:18:19 --> Total execution time: 0.0686
DEBUG - 2022-12-23 12:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:49:43 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:19:43 --> Total execution time: 0.0517
DEBUG - 2022-12-23 12:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:49:56 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:19:56 --> Total execution time: 0.1004
DEBUG - 2022-12-23 12:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:50:06 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:20:06 --> Total execution time: 0.0618
DEBUG - 2022-12-23 12:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:50:25 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:20:25 --> Total execution time: 0.0619
DEBUG - 2022-12-23 12:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:50:35 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:20:35 --> Total execution time: 0.0748
DEBUG - 2022-12-23 12:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:51:18 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:21:18 --> Total execution time: 0.0564
DEBUG - 2022-12-23 12:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:51:28 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:21:28 --> Total execution time: 0.0449
DEBUG - 2022-12-23 12:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:51:40 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:21:40 --> Total execution time: 0.0683
DEBUG - 2022-12-23 12:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:52:05 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:22:05 --> Total execution time: 0.0836
DEBUG - 2022-12-23 12:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:52:22 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:22:22 --> Total execution time: 0.0525
DEBUG - 2022-12-23 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:52:57 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:22:57 --> Total execution time: 0.0432
DEBUG - 2022-12-23 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:53:03 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:23:03 --> Total execution time: 0.0747
DEBUG - 2022-12-23 12:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:53:53 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:23:53 --> Total execution time: 0.0623
DEBUG - 2022-12-23 12:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:54:18 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:24:18 --> Total execution time: 0.0624
DEBUG - 2022-12-23 12:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:55:14 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:25:14 --> Total execution time: 0.0585
DEBUG - 2022-12-23 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 12:55:23 --> No URI present. Default controller set.
DEBUG - 2022-12-23 12:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 12:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 12:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:25:23 --> Total execution time: 0.0871
DEBUG - 2022-12-23 13:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:04:17 --> No URI present. Default controller set.
DEBUG - 2022-12-23 13:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:34:17 --> Total execution time: 0.0464
DEBUG - 2022-12-23 13:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:10:29 --> No URI present. Default controller set.
DEBUG - 2022-12-23 13:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:40:29 --> Total execution time: 0.0650
DEBUG - 2022-12-23 13:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:40:33 --> Total execution time: 0.0628
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:41:58 --> Total execution time: 0.0392
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 13:11:58 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:11:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:59 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 13:11:59 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 13:11:59 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:11:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:59 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:11:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:11:59 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:42:51 --> Total execution time: 0.0505
DEBUG - 2022-12-23 13:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:13:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:13:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:13:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:13:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:13:31 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:44:36 --> Total execution time: 0.0402
DEBUG - 2022-12-23 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:14:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:14:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:14:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:14:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:45:14 --> Total execution time: 0.0600
DEBUG - 2022-12-23 13:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:45:37 --> Total execution time: 0.0638
DEBUG - 2022-12-23 13:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:47:51 --> Total execution time: 0.0688
DEBUG - 2022-12-23 13:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:49:52 --> Total execution time: 0.0391
DEBUG - 2022-12-23 13:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:50:06 --> Total execution time: 0.0831
DEBUG - 2022-12-23 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:20:07 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:20:07 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:20:07 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:20:07 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:52:49 --> Total execution time: 0.0568
DEBUG - 2022-12-23 13:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:52:54 --> Total execution time: 0.0384
DEBUG - 2022-12-23 13:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:22:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:22:54 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:22:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:22:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 13:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:54:13 --> Total execution time: 0.0393
DEBUG - 2022-12-23 13:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:24:13 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:55:11 --> Total execution time: 0.0585
DEBUG - 2022-12-23 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:25:11 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:55:40 --> Total execution time: 0.0561
DEBUG - 2022-12-23 13:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:25:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 13:25:40 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 13:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 13:25:53 --> No URI present. Default controller set.
DEBUG - 2022-12-23 13:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 13:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 13:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 17:55:53 --> Total execution time: 0.0400
DEBUG - 2022-12-23 14:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:41:48 --> No URI present. Default controller set.
DEBUG - 2022-12-23 14:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:11:48 --> Total execution time: 0.6464
DEBUG - 2022-12-23 14:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:18:05 --> Total execution time: 0.0690
DEBUG - 2022-12-23 14:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:50:05 --> No URI present. Default controller set.
DEBUG - 2022-12-23 14:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:20:05 --> Total execution time: 0.0428
DEBUG - 2022-12-23 14:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:20:07 --> Total execution time: 0.0398
DEBUG - 2022-12-23 14:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:50:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 14:50:07 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 14:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:20:49 --> Total execution time: 0.0388
DEBUG - 2022-12-23 14:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:21:21 --> Total execution time: 0.0380
DEBUG - 2022-12-23 14:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:21:32 --> Total execution time: 0.0417
DEBUG - 2022-12-23 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 14:51:37 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 14:51:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 14:51:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 14:51:37 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:22:17 --> Total execution time: 0.0391
DEBUG - 2022-12-23 14:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:22:29 --> Total execution time: 0.0388
DEBUG - 2022-12-23 14:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:23:54 --> Total execution time: 0.0386
DEBUG - 2022-12-23 14:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:23:57 --> Total execution time: 0.0623
DEBUG - 2022-12-23 14:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:24:05 --> Total execution time: 0.0641
DEBUG - 2022-12-23 14:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:24:48 --> Total execution time: 0.0641
DEBUG - 2022-12-23 14:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:24:49 --> Total execution time: 0.0617
DEBUG - 2022-12-23 14:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:26:49 --> Total execution time: 0.0384
DEBUG - 2022-12-23 14:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 14:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 14:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 14:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:27:48 --> Total execution time: 0.0542
DEBUG - 2022-12-23 15:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:00:17 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:30:17 --> Total execution time: 0.0416
DEBUG - 2022-12-23 15:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:00:46 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:30:46 --> Total execution time: 0.0436
DEBUG - 2022-12-23 15:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:31:02 --> Total execution time: 0.0398
DEBUG - 2022-12-23 15:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:32:03 --> Total execution time: 0.0627
DEBUG - 2022-12-23 15:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:32:08 --> Total execution time: 0.0590
DEBUG - 2022-12-23 15:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:32:22 --> Total execution time: 0.0545
DEBUG - 2022-12-23 15:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:32:23 --> Total execution time: 0.0628
DEBUG - 2022-12-23 15:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:33:20 --> Total execution time: 0.0649
DEBUG - 2022-12-23 15:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:33:27 --> Total execution time: 0.0477
DEBUG - 2022-12-23 15:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:03:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:03:27 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:55:01 --> Total execution time: 0.0411
DEBUG - 2022-12-23 15:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:25:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:25:01 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 19:59:06 --> Total execution time: 0.0548
DEBUG - 2022-12-23 15:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:29:06 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:33:25 --> Severity: Compile Error --> Cannot redeclare Welcome::about_us() C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Welcome.php 19
DEBUG - 2022-12-23 15:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:03:41 --> Total execution time: 0.0596
DEBUG - 2022-12-23 15:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:33:41 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:04:01 --> Total execution time: 0.0577
DEBUG - 2022-12-23 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:34:01 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:04:11 --> Total execution time: 0.0601
DEBUG - 2022-12-23 15:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:34:11 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:04:29 --> Total execution time: 0.0592
DEBUG - 2022-12-23 15:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:34:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:34:29 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:05:26 --> Total execution time: 0.0624
DEBUG - 2022-12-23 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:35:26 --> UTF-8 Support Enabled
ERROR - 2022-12-23 15:35:26 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 15:35:26 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:35:26 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:35:26 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:35:26 --> 404 Page Not Found: Assets/images
ERROR - 2022-12-23 15:35:26 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-23 15:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:05:44 --> Total execution time: 0.0541
DEBUG - 2022-12-23 15:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:06:13 --> Total execution time: 0.0489
DEBUG - 2022-12-23 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:36:19 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:06:19 --> Total execution time: 0.0576
DEBUG - 2022-12-23 15:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:38:17 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:08:17 --> Total execution time: 0.0375
DEBUG - 2022-12-23 15:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:41:34 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:11:34 --> Total execution time: 0.0517
DEBUG - 2022-12-23 15:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:41:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:02 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:12:02 --> Total execution time: 0.0581
DEBUG - 2022-12-23 15:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:06 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:40 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:12:40 --> Total execution time: 0.0428
DEBUG - 2022-12-23 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:42:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:43:36 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:13:36 --> Total execution time: 0.0436
DEBUG - 2022-12-23 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:43:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:43:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:43:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:43:44 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:30 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:14:30 --> Total execution time: 0.0534
DEBUG - 2022-12-23 15:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:44:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:44:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:44:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:44:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:40 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:14:40 --> Total execution time: 0.0478
DEBUG - 2022-12-23 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:44:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:44:40 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-23 15:44:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:44:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:44:40 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:46:12 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:16:12 --> Total execution time: 0.0637
DEBUG - 2022-12-23 15:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:46:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:46:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:46:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:46:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:46:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:46:13 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:01 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:19:01 --> Total execution time: 0.0399
DEBUG - 2022-12-23 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:49:01 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:49:01 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:49:01 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:49:01 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:49:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:49:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:49:11 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-23 15:49:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-23 15:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:19:29 --> Total execution time: 0.0436
DEBUG - 2022-12-23 15:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:34 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:19:34 --> Total execution time: 0.0402
DEBUG - 2022-12-23 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:49:59 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:19:59 --> Total execution time: 0.0512
DEBUG - 2022-12-23 15:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-23 15:50:55 --> No URI present. Default controller set.
DEBUG - 2022-12-23 15:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-23 15:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-23 15:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-23 20:20:55 --> Total execution time: 0.0569
