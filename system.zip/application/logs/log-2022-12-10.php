<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:55 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:37:56 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
DEBUG - 2022-12-10 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-10 13:38:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-10 13:38:20 --> 404 Page Not Found: Assets/front
