<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-21 00:02:03 --> Total execution time: 0.0425
DEBUG - 2022-06-21 00:02:10 --> Total execution time: 0.0455
DEBUG - 2022-06-21 00:02:14 --> Total execution time: 0.0606
DEBUG - 2022-06-21 00:03:01 --> Total execution time: 0.0762
DEBUG - 2022-06-21 00:03:04 --> Total execution time: 0.0380
DEBUG - 2022-06-21 00:03:13 --> Total execution time: 0.0530
DEBUG - 2022-06-21 00:03:34 --> Total execution time: 0.0508
DEBUG - 2022-06-21 00:03:42 --> Total execution time: 0.0498
DEBUG - 2022-06-21 00:03:46 --> Total execution time: 0.0433
DEBUG - 2022-06-21 00:03:48 --> Total execution time: 0.0724
DEBUG - 2022-06-21 00:03:54 --> Total execution time: 0.0478
DEBUG - 2022-06-21 00:04:31 --> Total execution time: 0.0803
DEBUG - 2022-06-21 00:04:38 --> Total execution time: 0.0464
DEBUG - 2022-06-21 00:04:56 --> Total execution time: 0.0562
DEBUG - 2022-06-21 00:05:03 --> Total execution time: 0.0649
DEBUG - 2022-06-21 00:08:04 --> Total execution time: 0.1637
DEBUG - 2022-06-21 00:08:40 --> Total execution time: 0.0323
DEBUG - 2022-06-21 00:08:46 --> Total execution time: 0.0409
DEBUG - 2022-06-21 00:08:50 --> Total execution time: 0.0309
DEBUG - 2022-06-21 00:08:54 --> Total execution time: 0.0404
DEBUG - 2022-06-21 00:09:10 --> Total execution time: 0.0313
DEBUG - 2022-06-21 00:09:29 --> Total execution time: 0.0407
DEBUG - 2022-06-21 00:09:42 --> Total execution time: 0.0404
DEBUG - 2022-06-21 00:09:45 --> Total execution time: 0.0374
DEBUG - 2022-06-21 00:10:07 --> Total execution time: 0.0456
DEBUG - 2022-06-21 00:10:13 --> Total execution time: 0.0504
DEBUG - 2022-06-21 00:10:17 --> Total execution time: 0.0551
DEBUG - 2022-06-21 00:10:27 --> Total execution time: 0.0470
DEBUG - 2022-06-21 00:10:30 --> Total execution time: 0.0443
DEBUG - 2022-06-21 00:14:04 --> Total execution time: 0.0832
DEBUG - 2022-06-21 00:14:04 --> Total execution time: 0.0361
DEBUG - 2022-06-21 00:30:02 --> Total execution time: 0.2901
DEBUG - 2022-06-21 00:33:50 --> Total execution time: 0.1087
DEBUG - 2022-06-21 00:33:53 --> Total execution time: 0.0396
DEBUG - 2022-06-21 00:33:54 --> Total execution time: 0.0412
DEBUG - 2022-06-21 00:33:55 --> Total execution time: 0.0406
DEBUG - 2022-06-21 00:33:56 --> Total execution time: 0.0411
DEBUG - 2022-06-21 00:33:57 --> Total execution time: 0.0413
DEBUG - 2022-06-21 00:33:58 --> Total execution time: 0.0440
DEBUG - 2022-06-21 00:33:59 --> Total execution time: 0.0432
DEBUG - 2022-06-21 00:34:42 --> Total execution time: 0.0343
DEBUG - 2022-06-21 00:34:46 --> Total execution time: 0.0259
DEBUG - 2022-06-21 00:35:28 --> Total execution time: 0.0349
DEBUG - 2022-06-21 00:36:21 --> Total execution time: 0.0291
DEBUG - 2022-06-21 00:36:25 --> Total execution time: 0.0336
DEBUG - 2022-06-21 00:50:09 --> Total execution time: 0.1154
DEBUG - 2022-06-21 00:51:05 --> Total execution time: 0.0455
DEBUG - 2022-06-21 00:51:34 --> Total execution time: 0.0585
DEBUG - 2022-06-21 00:53:04 --> Total execution time: 0.0337
DEBUG - 2022-06-21 00:53:08 --> Total execution time: 0.0479
DEBUG - 2022-06-21 00:53:18 --> Total execution time: 0.0552
DEBUG - 2022-06-21 00:53:20 --> Total execution time: 0.0332
DEBUG - 2022-06-21 00:53:48 --> Total execution time: 0.1002
DEBUG - 2022-06-21 00:54:31 --> Total execution time: 0.0315
DEBUG - 2022-06-21 00:54:31 --> Total execution time: 0.0340
DEBUG - 2022-06-21 00:57:49 --> Total execution time: 0.1455
DEBUG - 2022-06-21 01:02:47 --> Total execution time: 0.0910
DEBUG - 2022-06-21 01:04:47 --> Total execution time: 0.0311
DEBUG - 2022-06-21 01:04:51 --> Total execution time: 0.0398
DEBUG - 2022-06-21 01:04:51 --> Total execution time: 0.0495
DEBUG - 2022-06-21 01:04:51 --> Total execution time: 0.0537
DEBUG - 2022-06-21 01:04:52 --> Total execution time: 0.0447
DEBUG - 2022-06-21 01:04:52 --> Total execution time: 0.0520
DEBUG - 2022-06-21 01:04:52 --> Total execution time: 0.0605
DEBUG - 2022-06-21 01:04:53 --> Total execution time: 0.0399
DEBUG - 2022-06-21 01:04:53 --> Total execution time: 0.0438
DEBUG - 2022-06-21 01:04:53 --> Total execution time: 0.0485
DEBUG - 2022-06-21 01:04:53 --> Total execution time: 0.0708
DEBUG - 2022-06-21 01:04:54 --> Total execution time: 0.0400
DEBUG - 2022-06-21 01:19:29 --> Total execution time: 0.0446
DEBUG - 2022-06-21 01:19:36 --> Total execution time: 0.0663
DEBUG - 2022-06-21 01:19:38 --> Total execution time: 0.0667
DEBUG - 2022-06-21 01:20:44 --> Total execution time: 0.1485
DEBUG - 2022-06-21 01:23:23 --> Total execution time: 0.0870
DEBUG - 2022-06-21 01:23:25 --> Total execution time: 0.0339
DEBUG - 2022-06-21 01:23:26 --> Total execution time: 0.0337
DEBUG - 2022-06-21 01:24:06 --> Total execution time: 0.0971
DEBUG - 2022-06-21 01:24:44 --> Total execution time: 0.0411
DEBUG - 2022-06-21 01:30:02 --> Total execution time: 0.1373
DEBUG - 2022-06-21 02:20:20 --> Total execution time: 0.1676
DEBUG - 2022-06-21 02:20:24 --> Total execution time: 0.0306
DEBUG - 2022-06-21 02:20:39 --> Total execution time: 0.0677
DEBUG - 2022-06-21 02:30:02 --> Total execution time: 0.2241
DEBUG - 2022-06-21 02:48:23 --> Total execution time: 0.0413
DEBUG - 2022-06-21 03:30:03 --> Total execution time: 0.3306
DEBUG - 2022-06-21 03:34:50 --> Total execution time: 0.0954
DEBUG - 2022-06-21 03:35:13 --> Total execution time: 0.0489
DEBUG - 2022-06-21 03:35:18 --> Total execution time: 0.0538
DEBUG - 2022-06-21 03:35:33 --> Total execution time: 0.0436
DEBUG - 2022-06-21 03:35:41 --> Total execution time: 0.0415
DEBUG - 2022-06-21 03:36:11 --> Total execution time: 0.0464
DEBUG - 2022-06-21 03:38:43 --> Total execution time: 0.0944
DEBUG - 2022-06-21 03:38:44 --> Total execution time: 0.0447
DEBUG - 2022-06-21 03:41:17 --> Total execution time: 0.1507
DEBUG - 2022-06-21 03:41:25 --> Total execution time: 0.0974
DEBUG - 2022-06-21 03:42:58 --> Total execution time: 0.0680
DEBUG - 2022-06-21 03:43:31 --> Total execution time: 0.0897
DEBUG - 2022-06-21 03:43:45 --> Total execution time: 0.0465
DEBUG - 2022-06-21 03:44:14 --> Total execution time: 0.0509
DEBUG - 2022-06-21 03:44:22 --> Total execution time: 0.0685
DEBUG - 2022-06-21 03:44:36 --> Total execution time: 0.0460
DEBUG - 2022-06-21 03:44:43 --> Total execution time: 0.0489
DEBUG - 2022-06-21 03:45:11 --> Total execution time: 0.0545
DEBUG - 2022-06-21 03:45:18 --> Total execution time: 0.0502
DEBUG - 2022-06-21 03:45:35 --> Total execution time: 0.0561
DEBUG - 2022-06-21 03:45:44 --> Total execution time: 0.1001
DEBUG - 2022-06-21 03:49:46 --> Total execution time: 0.1466
DEBUG - 2022-06-21 03:49:51 --> Total execution time: 0.0476
DEBUG - 2022-06-21 03:50:01 --> Total execution time: 0.0531
DEBUG - 2022-06-21 03:50:14 --> Total execution time: 0.0571
DEBUG - 2022-06-21 03:50:25 --> Total execution time: 0.0460
DEBUG - 2022-06-21 03:50:28 --> Total execution time: 0.0454
DEBUG - 2022-06-21 04:00:55 --> Total execution time: 0.1305
DEBUG - 2022-06-21 04:00:56 --> Total execution time: 0.0418
DEBUG - 2022-06-21 04:00:58 --> Total execution time: 0.0401
DEBUG - 2022-06-21 04:28:22 --> Total execution time: 0.1145
DEBUG - 2022-06-21 04:30:02 --> Total execution time: 0.1128
DEBUG - 2022-06-21 04:52:06 --> Total execution time: 0.1617
DEBUG - 2022-06-21 04:55:22 --> Total execution time: 0.1042
DEBUG - 2022-06-21 05:11:03 --> Total execution time: 0.1108
DEBUG - 2022-06-21 05:30:03 --> Total execution time: 0.1059
DEBUG - 2022-06-21 05:42:26 --> Total execution time: 0.1415
DEBUG - 2022-06-21 05:42:27 --> Total execution time: 0.0308
DEBUG - 2022-06-21 05:42:27 --> Total execution time: 0.0308
DEBUG - 2022-06-21 05:42:27 --> Total execution time: 0.0372
DEBUG - 2022-06-21 05:42:27 --> Total execution time: 0.0447
DEBUG - 2022-06-21 05:42:27 --> Total execution time: 0.0579
DEBUG - 2022-06-21 05:42:27 --> Total execution time: 0.0350
DEBUG - 2022-06-21 05:42:28 --> Total execution time: 0.0405
DEBUG - 2022-06-21 05:42:28 --> Total execution time: 0.0352
DEBUG - 2022-06-21 05:53:01 --> Total execution time: 0.0898
DEBUG - 2022-06-21 06:05:58 --> Total execution time: 0.0870
DEBUG - 2022-06-21 06:06:00 --> Total execution time: 0.0324
DEBUG - 2022-06-21 06:07:51 --> Total execution time: 0.0298
DEBUG - 2022-06-21 06:07:53 --> Total execution time: 0.0248
DEBUG - 2022-06-21 06:12:29 --> Total execution time: 0.0445
DEBUG - 2022-06-21 06:13:17 --> Total execution time: 0.0394
DEBUG - 2022-06-21 06:15:30 --> Total execution time: 0.0956
DEBUG - 2022-06-21 06:21:34 --> Total execution time: 0.0900
DEBUG - 2022-06-21 06:21:43 --> Total execution time: 0.0657
DEBUG - 2022-06-21 06:21:47 --> Total execution time: 0.0972
DEBUG - 2022-06-21 06:22:00 --> Total execution time: 0.0375
DEBUG - 2022-06-21 06:22:04 --> Total execution time: 0.0399
DEBUG - 2022-06-21 06:22:05 --> Total execution time: 0.0390
DEBUG - 2022-06-21 06:22:07 --> Total execution time: 0.0336
DEBUG - 2022-06-21 06:22:08 --> Total execution time: 0.0455
DEBUG - 2022-06-21 06:30:03 --> Total execution time: 0.1551
DEBUG - 2022-06-21 06:33:03 --> Total execution time: 0.0845
DEBUG - 2022-06-21 06:33:19 --> Total execution time: 0.0534
DEBUG - 2022-06-21 06:33:45 --> Total execution time: 0.0321
DEBUG - 2022-06-21 06:39:58 --> Total execution time: 0.0941
DEBUG - 2022-06-21 06:40:27 --> Total execution time: 0.0421
DEBUG - 2022-06-21 06:40:46 --> Total execution time: 0.0531
DEBUG - 2022-06-21 06:41:04 --> Total execution time: 0.0759
DEBUG - 2022-06-21 06:41:18 --> Total execution time: 0.0739
DEBUG - 2022-06-21 06:41:19 --> Total execution time: 0.0479
DEBUG - 2022-06-21 06:41:32 --> Total execution time: 0.0534
DEBUG - 2022-06-21 06:41:32 --> Total execution time: 0.0480
DEBUG - 2022-06-21 06:41:44 --> Total execution time: 0.0439
DEBUG - 2022-06-21 06:41:58 --> Total execution time: 0.0435
DEBUG - 2022-06-21 06:44:32 --> Total execution time: 0.0427
DEBUG - 2022-06-21 06:44:40 --> Total execution time: 0.0488
DEBUG - 2022-06-21 06:44:43 --> Total execution time: 0.0555
DEBUG - 2022-06-21 06:44:52 --> Total execution time: 0.0597
DEBUG - 2022-06-21 06:44:57 --> Total execution time: 0.0400
DEBUG - 2022-06-21 06:45:04 --> Total execution time: 0.0407
DEBUG - 2022-06-21 06:47:45 --> Total execution time: 0.0839
DEBUG - 2022-06-21 06:47:47 --> Total execution time: 0.0434
DEBUG - 2022-06-21 06:47:48 --> Total execution time: 0.0402
DEBUG - 2022-06-21 06:52:08 --> Total execution time: 0.1353
DEBUG - 2022-06-21 06:52:37 --> Total execution time: 0.0400
DEBUG - 2022-06-21 06:52:46 --> Total execution time: 0.0438
DEBUG - 2022-06-21 06:53:05 --> Total execution time: 0.0515
DEBUG - 2022-06-21 06:53:18 --> Total execution time: 0.0495
DEBUG - 2022-06-21 06:53:30 --> Total execution time: 0.0480
DEBUG - 2022-06-21 06:53:37 --> Total execution time: 0.0447
DEBUG - 2022-06-21 06:55:00 --> Total execution time: 0.0405
DEBUG - 2022-06-21 07:08:12 --> Total execution time: 0.0454
DEBUG - 2022-06-21 07:09:17 --> Total execution time: 0.0550
DEBUG - 2022-06-21 07:14:09 --> Total execution time: 0.0839
DEBUG - 2022-06-21 07:17:59 --> Total execution time: 0.0477
DEBUG - 2022-06-21 07:18:24 --> Total execution time: 0.0681
DEBUG - 2022-06-21 07:18:30 --> Total execution time: 0.0732
DEBUG - 2022-06-21 07:18:33 --> Total execution time: 0.0490
DEBUG - 2022-06-21 07:18:37 --> Total execution time: 0.0521
DEBUG - 2022-06-21 07:22:29 --> Total execution time: 0.0896
DEBUG - 2022-06-21 07:23:14 --> Total execution time: 0.0284
DEBUG - 2022-06-21 07:23:30 --> Total execution time: 0.0295
DEBUG - 2022-06-21 07:23:42 --> Total execution time: 0.0304
DEBUG - 2022-06-21 07:24:16 --> Total execution time: 0.0456
DEBUG - 2022-06-21 07:24:23 --> Total execution time: 0.0483
DEBUG - 2022-06-21 07:24:30 --> Total execution time: 0.0683
DEBUG - 2022-06-21 07:24:51 --> Total execution time: 0.0404
DEBUG - 2022-06-21 07:28:17 --> Total execution time: 0.0813
DEBUG - 2022-06-21 07:28:54 --> Total execution time: 0.0330
DEBUG - 2022-06-21 07:28:59 --> Total execution time: 0.0414
DEBUG - 2022-06-21 07:30:03 --> Total execution time: 0.1210
DEBUG - 2022-06-21 07:32:24 --> Total execution time: 0.0317
DEBUG - 2022-06-21 07:33:44 --> Total execution time: 0.0644
DEBUG - 2022-06-21 07:39:13 --> Total execution time: 0.1133
DEBUG - 2022-06-21 07:39:16 --> Total execution time: 0.0347
DEBUG - 2022-06-21 07:39:33 --> Total execution time: 0.0454
DEBUG - 2022-06-21 07:39:43 --> Total execution time: 0.0400
DEBUG - 2022-06-21 07:39:56 --> Total execution time: 0.0651
DEBUG - 2022-06-21 07:40:03 --> Total execution time: 0.0563
DEBUG - 2022-06-21 07:40:12 --> Total execution time: 0.0457
DEBUG - 2022-06-21 07:40:22 --> Total execution time: 0.0547
DEBUG - 2022-06-21 07:40:24 --> Total execution time: 0.0470
DEBUG - 2022-06-21 07:40:29 --> Total execution time: 0.0462
DEBUG - 2022-06-21 07:40:34 --> Total execution time: 0.0452
DEBUG - 2022-06-21 07:40:45 --> Total execution time: 0.0486
DEBUG - 2022-06-21 07:40:49 --> Total execution time: 0.0508
DEBUG - 2022-06-21 07:40:50 --> Total execution time: 0.0466
DEBUG - 2022-06-21 07:40:56 --> Total execution time: 0.0408
DEBUG - 2022-06-21 07:41:29 --> Total execution time: 0.0632
DEBUG - 2022-06-21 07:41:31 --> Total execution time: 0.0483
DEBUG - 2022-06-21 07:41:37 --> Total execution time: 0.0490
DEBUG - 2022-06-21 07:41:47 --> Total execution time: 0.0893
DEBUG - 2022-06-21 07:41:57 --> Total execution time: 0.0464
DEBUG - 2022-06-21 07:42:05 --> Total execution time: 0.0642
DEBUG - 2022-06-21 07:42:11 --> Total execution time: 0.0573
DEBUG - 2022-06-21 07:42:16 --> Total execution time: 0.0399
DEBUG - 2022-06-21 07:42:23 --> Total execution time: 0.0587
DEBUG - 2022-06-21 07:43:07 --> Total execution time: 0.0403
DEBUG - 2022-06-21 07:43:15 --> Total execution time: 0.0919
DEBUG - 2022-06-21 07:43:41 --> Total execution time: 0.0399
DEBUG - 2022-06-21 07:43:59 --> Total execution time: 0.0434
DEBUG - 2022-06-21 07:46:19 --> Total execution time: 0.0425
DEBUG - 2022-06-21 07:47:10 --> Total execution time: 0.0338
DEBUG - 2022-06-21 07:47:21 --> Total execution time: 0.0424
DEBUG - 2022-06-21 07:47:30 --> Total execution time: 0.0430
DEBUG - 2022-06-21 07:47:30 --> Total execution time: 0.0460
DEBUG - 2022-06-21 07:47:44 --> Total execution time: 0.0507
DEBUG - 2022-06-21 07:47:53 --> Total execution time: 0.0474
DEBUG - 2022-06-21 07:48:00 --> Total execution time: 0.0901
DEBUG - 2022-06-21 07:48:01 --> Total execution time: 0.0638
DEBUG - 2022-06-21 07:48:45 --> Total execution time: 0.0490
DEBUG - 2022-06-21 07:48:52 --> Total execution time: 0.0349
DEBUG - 2022-06-21 07:49:25 --> Total execution time: 0.0461
DEBUG - 2022-06-21 07:50:16 --> Total execution time: 0.0444
DEBUG - 2022-06-21 07:51:55 --> Total execution time: 0.0519
DEBUG - 2022-06-21 08:02:43 --> Total execution time: 0.0899
DEBUG - 2022-06-21 08:11:21 --> Total execution time: 0.0441
DEBUG - 2022-06-21 08:30:02 --> Total execution time: 0.2067
DEBUG - 2022-06-21 08:34:52 --> Total execution time: 0.1025
DEBUG - 2022-06-21 08:35:00 --> Total execution time: 0.0445
DEBUG - 2022-06-21 08:35:03 --> Total execution time: 0.0413
DEBUG - 2022-06-21 08:35:06 --> Total execution time: 0.0366
DEBUG - 2022-06-21 08:35:20 --> Total execution time: 0.0384
DEBUG - 2022-06-21 08:44:43 --> Total execution time: 0.0793
DEBUG - 2022-06-21 08:45:47 --> Total execution time: 0.0409
DEBUG - 2022-06-21 08:45:57 --> Total execution time: 0.1324
DEBUG - 2022-06-21 08:46:17 --> Total execution time: 0.0534
DEBUG - 2022-06-21 08:46:52 --> Total execution time: 0.0539
DEBUG - 2022-06-21 08:50:27 --> Total execution time: 0.0505
DEBUG - 2022-06-21 08:51:00 --> Total execution time: 0.0454
DEBUG - 2022-06-21 08:51:08 --> Total execution time: 0.0513
DEBUG - 2022-06-21 08:51:13 --> Total execution time: 0.1058
DEBUG - 2022-06-21 08:51:55 --> Total execution time: 0.0541
DEBUG - 2022-06-21 08:52:14 --> Total execution time: 0.1696
DEBUG - 2022-06-21 08:52:38 --> Total execution time: 0.0843
DEBUG - 2022-06-21 08:52:47 --> Total execution time: 0.0843
DEBUG - 2022-06-21 08:52:55 --> Total execution time: 0.0897
DEBUG - 2022-06-21 08:53:01 --> Total execution time: 0.0459
DEBUG - 2022-06-21 08:53:10 --> Total execution time: 0.0477
DEBUG - 2022-06-21 08:54:07 --> Total execution time: 0.0436
DEBUG - 2022-06-21 08:54:10 --> Total execution time: 0.0450
DEBUG - 2022-06-21 08:54:14 --> Total execution time: 0.0407
DEBUG - 2022-06-21 08:54:15 --> Total execution time: 0.0420
DEBUG - 2022-06-21 08:54:28 --> Total execution time: 0.0436
DEBUG - 2022-06-21 08:54:41 --> Total execution time: 0.0501
DEBUG - 2022-06-21 08:54:46 --> Total execution time: 0.0667
DEBUG - 2022-06-21 08:55:48 --> Total execution time: 0.0544
DEBUG - 2022-06-21 08:56:05 --> Total execution time: 0.0763
DEBUG - 2022-06-21 08:56:30 --> Total execution time: 0.0435
DEBUG - 2022-06-21 08:57:05 --> Total execution time: 0.0505
DEBUG - 2022-06-21 08:57:09 --> Total execution time: 0.0304
DEBUG - 2022-06-21 08:57:13 --> Total execution time: 0.0424
DEBUG - 2022-06-21 08:57:14 --> Total execution time: 0.0448
DEBUG - 2022-06-21 08:57:27 --> Total execution time: 0.0761
DEBUG - 2022-06-21 08:57:53 --> Total execution time: 0.0444
DEBUG - 2022-06-21 08:58:12 --> Total execution time: 0.0510
DEBUG - 2022-06-21 08:58:21 --> Total execution time: 0.0324
DEBUG - 2022-06-21 09:00:06 --> Total execution time: 0.0498
DEBUG - 2022-06-21 09:00:16 --> Total execution time: 0.0593
DEBUG - 2022-06-21 09:00:28 --> Total execution time: 0.0585
DEBUG - 2022-06-21 09:04:52 --> Total execution time: 0.0845
DEBUG - 2022-06-21 09:05:30 --> Total execution time: 0.0535
DEBUG - 2022-06-21 09:05:46 --> Total execution time: 0.0631
DEBUG - 2022-06-21 09:05:56 --> Total execution time: 0.0705
DEBUG - 2022-06-21 09:06:19 --> Total execution time: 0.0535
DEBUG - 2022-06-21 09:06:26 --> Total execution time: 0.0561
DEBUG - 2022-06-21 09:06:38 --> Total execution time: 0.0505
DEBUG - 2022-06-21 09:07:10 --> Total execution time: 0.0487
DEBUG - 2022-06-21 09:07:58 --> Total execution time: 0.0305
DEBUG - 2022-06-21 09:13:32 --> Total execution time: 0.1829
DEBUG - 2022-06-21 09:27:25 --> Total execution time: 0.1775
DEBUG - 2022-06-21 09:30:03 --> Total execution time: 0.0497
DEBUG - 2022-06-21 09:30:03 --> Total execution time: 0.0500
DEBUG - 2022-06-21 09:30:08 --> Total execution time: 0.0453
DEBUG - 2022-06-21 09:30:17 --> Total execution time: 0.0558
DEBUG - 2022-06-21 09:30:24 --> Total execution time: 0.0790
DEBUG - 2022-06-21 09:30:27 --> Total execution time: 0.0619
DEBUG - 2022-06-21 09:30:35 --> Total execution time: 0.0556
DEBUG - 2022-06-21 09:36:04 --> Total execution time: 0.0862
DEBUG - 2022-06-21 09:36:31 --> Total execution time: 0.0367
DEBUG - 2022-06-21 09:36:37 --> Total execution time: 0.0411
DEBUG - 2022-06-21 09:36:52 --> Total execution time: 0.0483
DEBUG - 2022-06-21 09:37:01 --> Total execution time: 0.0582
DEBUG - 2022-06-21 09:37:11 --> Total execution time: 0.0640
DEBUG - 2022-06-21 09:37:34 --> Total execution time: 0.0404
DEBUG - 2022-06-21 09:40:46 --> Total execution time: 0.1483
DEBUG - 2022-06-21 09:40:48 --> Total execution time: 0.0434
DEBUG - 2022-06-21 09:40:49 --> Total execution time: 0.0403
DEBUG - 2022-06-21 09:40:58 --> Total execution time: 0.0356
DEBUG - 2022-06-21 09:41:50 --> Total execution time: 0.0644
DEBUG - 2022-06-21 09:41:58 --> Total execution time: 0.0419
DEBUG - 2022-06-21 09:42:16 --> Total execution time: 0.0442
DEBUG - 2022-06-21 09:45:55 --> Total execution time: 0.1997
DEBUG - 2022-06-21 09:45:58 --> Total execution time: 0.0488
DEBUG - 2022-06-21 09:45:59 --> Total execution time: 0.0438
DEBUG - 2022-06-21 09:45:59 --> Total execution time: 0.0461
DEBUG - 2022-06-21 09:46:28 --> Total execution time: 0.0328
DEBUG - 2022-06-21 09:46:30 --> Total execution time: 0.0294
DEBUG - 2022-06-21 09:46:39 --> Total execution time: 0.0456
DEBUG - 2022-06-21 09:46:41 --> Total execution time: 0.0746
DEBUG - 2022-06-21 09:46:47 --> Total execution time: 0.2360
DEBUG - 2022-06-21 09:46:56 --> Total execution time: 0.0395
DEBUG - 2022-06-21 09:47:59 --> Total execution time: 0.0331
DEBUG - 2022-06-21 09:49:16 --> Total execution time: 0.0306
DEBUG - 2022-06-21 09:49:31 --> Total execution time: 0.0395
DEBUG - 2022-06-21 09:49:38 --> Total execution time: 0.0307
DEBUG - 2022-06-21 09:49:41 --> Total execution time: 0.0387
DEBUG - 2022-06-21 09:50:08 --> Total execution time: 0.1228
DEBUG - 2022-06-21 09:50:08 --> Total execution time: 0.1332
DEBUG - 2022-06-21 09:50:08 --> Total execution time: 0.1312
DEBUG - 2022-06-21 09:50:09 --> Total execution time: 0.1619
DEBUG - 2022-06-21 09:50:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 09:50:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 09:50:12 --> Total execution time: 0.0844
DEBUG - 2022-06-21 09:50:22 --> Total execution time: 0.0471
DEBUG - 2022-06-21 09:50:39 --> Total execution time: 0.0460
DEBUG - 2022-06-21 09:50:50 --> Total execution time: 0.0351
DEBUG - 2022-06-21 09:51:22 --> Total execution time: 0.0348
DEBUG - 2022-06-21 09:51:25 --> Total execution time: 1.8764
DEBUG - 2022-06-21 09:51:28 --> Total execution time: 0.0545
DEBUG - 2022-06-21 09:51:29 --> Total execution time: 0.0509
DEBUG - 2022-06-21 09:51:58 --> Total execution time: 0.0460
DEBUG - 2022-06-21 09:53:02 --> Total execution time: 0.0418
DEBUG - 2022-06-21 09:53:04 --> Total execution time: 0.0491
DEBUG - 2022-06-21 09:53:34 --> Total execution time: 0.0487
DEBUG - 2022-06-21 09:53:50 --> Total execution time: 0.0707
DEBUG - 2022-06-21 09:54:00 --> Total execution time: 0.0715
DEBUG - 2022-06-21 09:54:18 --> Total execution time: 0.0975
DEBUG - 2022-06-21 09:54:23 --> Total execution time: 0.0398
DEBUG - 2022-06-21 09:54:32 --> Total execution time: 0.0471
DEBUG - 2022-06-21 09:55:40 --> Total execution time: 0.0402
DEBUG - 2022-06-21 09:56:16 --> Total execution time: 0.0409
DEBUG - 2022-06-21 09:56:37 --> Total execution time: 0.0459
DEBUG - 2022-06-21 09:57:23 --> Total execution time: 0.0440
DEBUG - 2022-06-21 09:57:45 --> Total execution time: 0.0632
DEBUG - 2022-06-21 09:59:02 --> Total execution time: 0.1212
DEBUG - 2022-06-21 09:59:13 --> Total execution time: 0.0495
DEBUG - 2022-06-21 09:59:25 --> Total execution time: 0.0402
DEBUG - 2022-06-21 09:59:44 --> Total execution time: 0.0457
DEBUG - 2022-06-21 09:59:58 --> Total execution time: 0.0403
DEBUG - 2022-06-21 10:00:11 --> Total execution time: 0.0422
DEBUG - 2022-06-21 10:00:23 --> Total execution time: 0.0673
DEBUG - 2022-06-21 10:00:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 10:00:24 --> Total execution time: 0.0484
DEBUG - 2022-06-21 10:01:38 --> Total execution time: 0.0430
DEBUG - 2022-06-21 10:02:33 --> Total execution time: 0.0473
DEBUG - 2022-06-21 10:03:09 --> Total execution time: 0.0587
DEBUG - 2022-06-21 10:03:11 --> Total execution time: 0.0560
DEBUG - 2022-06-21 10:04:04 --> Total execution time: 0.0572
DEBUG - 2022-06-21 10:04:32 --> Total execution time: 0.1246
DEBUG - 2022-06-21 10:04:43 --> Total execution time: 0.0441
DEBUG - 2022-06-21 10:04:43 --> Total execution time: 0.0409
DEBUG - 2022-06-21 10:05:03 --> Total execution time: 0.1159
DEBUG - 2022-06-21 10:05:16 --> Total execution time: 0.0521
DEBUG - 2022-06-21 10:05:34 --> Total execution time: 0.0561
DEBUG - 2022-06-21 10:06:27 --> Total execution time: 0.0374
DEBUG - 2022-06-21 10:06:28 --> Total execution time: 0.0507
DEBUG - 2022-06-21 10:06:46 --> Total execution time: 0.0438
DEBUG - 2022-06-21 10:07:09 --> Total execution time: 0.0297
DEBUG - 2022-06-21 10:07:10 --> Total execution time: 0.0274
DEBUG - 2022-06-21 10:09:56 --> Total execution time: 0.0929
DEBUG - 2022-06-21 10:10:22 --> Total execution time: 0.0850
DEBUG - 2022-06-21 10:10:29 --> Total execution time: 0.1121
DEBUG - 2022-06-21 10:11:50 --> Total execution time: 0.0435
DEBUG - 2022-06-21 10:11:50 --> Total execution time: 0.0502
DEBUG - 2022-06-21 10:12:07 --> Total execution time: 0.0496
DEBUG - 2022-06-21 10:12:15 --> Total execution time: 0.0572
DEBUG - 2022-06-21 10:19:51 --> Total execution time: 0.1839
DEBUG - 2022-06-21 10:20:47 --> Total execution time: 0.0666
DEBUG - 2022-06-21 10:25:15 --> Total execution time: 0.1284
DEBUG - 2022-06-21 10:25:25 --> Total execution time: 0.0414
DEBUG - 2022-06-21 10:25:26 --> Total execution time: 0.0748
DEBUG - 2022-06-21 10:25:34 --> Total execution time: 0.0404
DEBUG - 2022-06-21 10:25:35 --> Total execution time: 0.1209
DEBUG - 2022-06-21 10:25:37 --> Total execution time: 0.0585
DEBUG - 2022-06-21 10:25:40 --> Total execution time: 0.0989
DEBUG - 2022-06-21 10:25:48 --> Total execution time: 0.0720
DEBUG - 2022-06-21 10:26:03 --> Total execution time: 0.0465
DEBUG - 2022-06-21 10:26:08 --> Total execution time: 0.0538
DEBUG - 2022-06-21 10:26:28 --> Total execution time: 0.0575
DEBUG - 2022-06-21 10:29:15 --> Total execution time: 0.1818
DEBUG - 2022-06-21 10:29:28 --> Total execution time: 0.0722
DEBUG - 2022-06-21 10:29:37 --> Total execution time: 0.1140
DEBUG - 2022-06-21 10:29:40 --> Total execution time: 0.0489
DEBUG - 2022-06-21 10:29:46 --> Total execution time: 0.0454
DEBUG - 2022-06-21 10:29:55 --> Total execution time: 0.0474
DEBUG - 2022-06-21 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:30:02 --> Total execution time: 0.0568
DEBUG - 2022-06-21 00:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:30:36 --> Total execution time: 0.0293
DEBUG - 2022-06-21 00:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:30:39 --> Total execution time: 0.0528
DEBUG - 2022-06-21 00:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:30:47 --> Total execution time: 0.0429
DEBUG - 2022-06-21 00:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:30:50 --> Total execution time: 0.0411
DEBUG - 2022-06-21 00:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:34:20 --> Total execution time: 0.1022
DEBUG - 2022-06-21 00:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:34:36 --> Total execution time: 0.0470
DEBUG - 2022-06-21 00:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:34:59 --> Total execution time: 0.0577
DEBUG - 2022-06-21 00:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:35:07 --> Total execution time: 0.0457
DEBUG - 2022-06-21 00:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:35:14 --> Total execution time: 0.0542
DEBUG - 2022-06-21 00:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:35:34 --> Total execution time: 0.0522
DEBUG - 2022-06-21 00:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:35:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 00:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:35:35 --> Total execution time: 0.0407
DEBUG - 2022-06-21 00:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:09:52 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:39:52 --> Total execution time: 0.1068
DEBUG - 2022-06-21 00:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:09:55 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:39:55 --> Total execution time: 0.0306
DEBUG - 2022-06-21 00:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 00:10:05 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 00:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:11:14 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:41:14 --> Total execution time: 0.0563
DEBUG - 2022-06-21 00:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:44:21 --> Total execution time: 0.0970
DEBUG - 2022-06-21 00:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:44:51 --> Total execution time: 0.0713
DEBUG - 2022-06-21 00:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 00:15:04 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-21 00:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 00:15:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 00:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:20:32 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:50:32 --> Total execution time: 0.0951
DEBUG - 2022-06-21 00:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:20:32 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:50:32 --> Total execution time: 0.0328
DEBUG - 2022-06-21 00:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:53:24 --> Total execution time: 0.1721
DEBUG - 2022-06-21 00:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:53:35 --> Total execution time: 0.0487
DEBUG - 2022-06-21 00:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:55:25 --> Total execution time: 0.1049
DEBUG - 2022-06-21 00:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:25:51 --> Total execution time: 0.0435
DEBUG - 2022-06-21 00:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:25:57 --> Total execution time: 0.0580
DEBUG - 2022-06-21 00:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:25:57 --> Total execution time: 0.0981
DEBUG - 2022-06-21 00:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:26:17 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:56:17 --> Total execution time: 0.0383
DEBUG - 2022-06-21 00:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:01:37 --> Total execution time: 0.0987
DEBUG - 2022-06-21 00:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:01:59 --> Total execution time: 0.0453
DEBUG - 2022-06-21 00:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:02:34 --> Total execution time: 0.0285
DEBUG - 2022-06-21 00:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:02:50 --> Total execution time: 0.0493
DEBUG - 2022-06-21 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:32:51 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:02:51 --> Total execution time: 0.0514
DEBUG - 2022-06-21 00:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:34:34 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:04:34 --> Total execution time: 0.1308
DEBUG - 2022-06-21 00:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:35:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:05:10 --> Total execution time: 0.1302
DEBUG - 2022-06-21 00:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:38:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:08:58 --> Total execution time: 0.1138
DEBUG - 2022-06-21 00:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:39:29 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:09:29 --> Total execution time: 0.0326
DEBUG - 2022-06-21 00:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:39:45 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:09:45 --> Total execution time: 0.0431
DEBUG - 2022-06-21 00:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:10:05 --> Total execution time: 0.0403
DEBUG - 2022-06-21 00:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:11:22 --> Total execution time: 0.0651
DEBUG - 2022-06-21 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:11:34 --> Total execution time: 0.0937
DEBUG - 2022-06-21 00:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:42:54 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:12:54 --> Total execution time: 0.0323
DEBUG - 2022-06-21 00:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:13:02 --> Total execution time: 0.0422
DEBUG - 2022-06-21 00:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:13:38 --> Total execution time: 0.0537
DEBUG - 2022-06-21 00:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:13:52 --> Total execution time: 0.0597
DEBUG - 2022-06-21 00:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:13:56 --> Total execution time: 0.0682
DEBUG - 2022-06-21 00:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:14:02 --> Total execution time: 0.0543
DEBUG - 2022-06-21 00:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:45:01 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:15:01 --> Total execution time: 0.1262
DEBUG - 2022-06-21 00:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:16:50 --> Total execution time: 0.0357
DEBUG - 2022-06-21 00:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:47:40 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:17:40 --> Total execution time: 0.0388
DEBUG - 2022-06-21 00:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:17:42 --> Total execution time: 0.0379
DEBUG - 2022-06-21 00:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:17:49 --> Total execution time: 0.0610
DEBUG - 2022-06-21 00:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:17:54 --> Total execution time: 0.0535
DEBUG - 2022-06-21 00:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:17:56 --> Total execution time: 0.0538
DEBUG - 2022-06-21 00:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:18:09 --> Total execution time: 0.0509
DEBUG - 2022-06-21 00:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:18:17 --> Total execution time: 0.0457
DEBUG - 2022-06-21 00:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:18:20 --> Total execution time: 0.0467
DEBUG - 2022-06-21 00:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:18:50 --> Total execution time: 0.0570
DEBUG - 2022-06-21 00:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:49:17 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:19:17 --> Total execution time: 0.0331
DEBUG - 2022-06-21 00:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:50:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:20:10 --> Total execution time: 0.0334
DEBUG - 2022-06-21 00:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:20:12 --> Total execution time: 0.0417
DEBUG - 2022-06-21 00:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:20:22 --> Total execution time: 0.0470
DEBUG - 2022-06-21 00:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:20:26 --> Total execution time: 0.0699
DEBUG - 2022-06-21 00:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:20:38 --> Total execution time: 0.0600
DEBUG - 2022-06-21 00:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:52:48 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:22:48 --> Total execution time: 0.1232
DEBUG - 2022-06-21 00:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:22:53 --> Total execution time: 0.0444
DEBUG - 2022-06-21 00:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:22:56 --> Total execution time: 0.0698
DEBUG - 2022-06-21 00:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:22:56 --> Total execution time: 0.0455
DEBUG - 2022-06-21 00:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:22:59 --> Total execution time: 0.0542
DEBUG - 2022-06-21 00:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:23:10 --> Total execution time: 0.0500
DEBUG - 2022-06-21 00:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:23:10 --> Total execution time: 0.0453
DEBUG - 2022-06-21 00:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:23:19 --> Total execution time: 0.0560
DEBUG - 2022-06-21 00:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:23:24 --> Total execution time: 0.0609
DEBUG - 2022-06-21 00:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:23:27 --> Total execution time: 0.0457
DEBUG - 2022-06-21 00:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:23:31 --> Total execution time: 0.1219
DEBUG - 2022-06-21 00:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:24:12 --> Total execution time: 0.0481
DEBUG - 2022-06-21 00:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:24:14 --> Total execution time: 0.0557
DEBUG - 2022-06-21 00:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:24:16 --> Total execution time: 0.0628
DEBUG - 2022-06-21 00:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:54:17 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:24:18 --> Total execution time: 0.0580
DEBUG - 2022-06-21 00:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:25:11 --> Total execution time: 0.0583
DEBUG - 2022-06-21 00:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:25:51 --> Total execution time: 0.0467
DEBUG - 2022-06-21 00:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:26:26 --> Total execution time: 0.0666
DEBUG - 2022-06-21 00:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:26:29 --> Total execution time: 0.0466
DEBUG - 2022-06-21 00:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:57:09 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:27:09 --> Total execution time: 0.0401
DEBUG - 2022-06-21 00:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:58:16 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:28:16 --> Total execution time: 0.0372
DEBUG - 2022-06-21 00:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:28:20 --> Total execution time: 0.0342
DEBUG - 2022-06-21 00:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 00:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:29:28 --> Total execution time: 0.0520
DEBUG - 2022-06-21 00:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:29:35 --> Total execution time: 0.0480
DEBUG - 2022-06-21 00:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:29:42 --> Total execution time: 0.0500
DEBUG - 2022-06-21 00:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:29:44 --> Total execution time: 0.0478
DEBUG - 2022-06-21 00:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 00:59:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 00:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 00:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:29:59 --> Total execution time: 0.0549
DEBUG - 2022-06-21 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:02 --> Total execution time: 0.0636
DEBUG - 2022-06-21 01:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:14 --> Total execution time: 0.0846
DEBUG - 2022-06-21 01:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:15 --> Total execution time: 0.0639
DEBUG - 2022-06-21 01:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:21 --> Total execution time: 0.0513
DEBUG - 2022-06-21 01:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:24 --> Total execution time: 0.0533
DEBUG - 2022-06-21 01:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:25 --> Total execution time: 0.0621
DEBUG - 2022-06-21 01:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:25 --> Total execution time: 0.0994
DEBUG - 2022-06-21 01:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:25 --> Total execution time: 0.0629
DEBUG - 2022-06-21 01:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:35 --> Total execution time: 0.0451
DEBUG - 2022-06-21 01:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:45 --> Total execution time: 0.1126
DEBUG - 2022-06-21 01:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:48 --> Total execution time: 0.0483
DEBUG - 2022-06-21 01:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:50 --> Total execution time: 0.0475
DEBUG - 2022-06-21 01:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:52 --> Total execution time: 0.0409
DEBUG - 2022-06-21 01:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:30:54 --> Total execution time: 0.0719
DEBUG - 2022-06-21 01:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:00:59 --> Total execution time: 0.0458
DEBUG - 2022-06-21 01:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:31:00 --> Total execution time: 0.0644
DEBUG - 2022-06-21 01:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:01:06 --> Total execution time: 0.0708
DEBUG - 2022-06-21 01:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:32:42 --> Total execution time: 0.0568
DEBUG - 2022-06-21 01:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:32:53 --> Total execution time: 0.0415
DEBUG - 2022-06-21 01:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:33:03 --> Total execution time: 0.1026
DEBUG - 2022-06-21 01:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:33:17 --> Total execution time: 0.0536
DEBUG - 2022-06-21 01:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:33:30 --> Total execution time: 0.1413
DEBUG - 2022-06-21 01:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:33:45 --> Total execution time: 0.0587
DEBUG - 2022-06-21 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:34:00 --> Total execution time: 0.0501
DEBUG - 2022-06-21 01:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:34:03 --> Total execution time: 0.0455
DEBUG - 2022-06-21 01:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:04:07 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:34:07 --> Total execution time: 0.0647
DEBUG - 2022-06-21 01:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:00 --> Total execution time: 0.0455
DEBUG - 2022-06-21 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:18 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:18 --> Total execution time: 0.0698
DEBUG - 2022-06-21 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:18 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:19 --> Total execution time: 0.0397
DEBUG - 2022-06-21 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:19 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:19 --> Total execution time: 0.0360
DEBUG - 2022-06-21 01:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:27 --> Total execution time: 0.0681
DEBUG - 2022-06-21 01:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:34 --> Total execution time: 0.0531
DEBUG - 2022-06-21 01:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:42 --> Total execution time: 0.0903
DEBUG - 2022-06-21 01:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:45 --> Total execution time: 0.0464
DEBUG - 2022-06-21 01:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:46 --> Total execution time: 0.0625
DEBUG - 2022-06-21 01:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:05:48 --> Total execution time: 0.0626
DEBUG - 2022-06-21 01:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:35:50 --> Total execution time: 0.0541
DEBUG - 2022-06-21 01:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:06:06 --> Total execution time: 0.1180
DEBUG - 2022-06-21 01:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:36:10 --> Total execution time: 0.0606
DEBUG - 2022-06-21 01:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:36:13 --> Total execution time: 0.0580
DEBUG - 2022-06-21 01:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:36:21 --> Total execution time: 0.0449
DEBUG - 2022-06-21 01:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:36:31 --> Total execution time: 0.0651
DEBUG - 2022-06-21 01:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:36:45 --> Total execution time: 0.0514
DEBUG - 2022-06-21 01:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:36:47 --> Total execution time: 0.0799
DEBUG - 2022-06-21 01:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:36:51 --> Total execution time: 0.0535
DEBUG - 2022-06-21 01:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:38:02 --> Total execution time: 0.0499
DEBUG - 2022-06-21 01:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:38:05 --> Total execution time: 0.0520
DEBUG - 2022-06-21 01:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:38:08 --> Total execution time: 0.0548
DEBUG - 2022-06-21 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:38:12 --> Total execution time: 0.0430
DEBUG - 2022-06-21 01:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:38:19 --> Total execution time: 0.0801
DEBUG - 2022-06-21 01:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:38:44 --> Total execution time: 0.1098
DEBUG - 2022-06-21 01:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:38:48 --> Total execution time: 0.0846
DEBUG - 2022-06-21 01:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:39:02 --> Total execution time: 0.0637
DEBUG - 2022-06-21 01:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:39:04 --> Total execution time: 0.0641
DEBUG - 2022-06-21 01:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:39:08 --> Total execution time: 0.0600
DEBUG - 2022-06-21 01:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:39:15 --> Total execution time: 0.0631
DEBUG - 2022-06-21 01:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:39:18 --> Total execution time: 0.0769
DEBUG - 2022-06-21 01:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:39:59 --> Total execution time: 0.0532
DEBUG - 2022-06-21 01:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:39:59 --> Total execution time: 0.0795
DEBUG - 2022-06-21 01:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:40:00 --> Total execution time: 0.0666
DEBUG - 2022-06-21 01:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:10:39 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:40:39 --> Total execution time: 0.0470
DEBUG - 2022-06-21 01:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:40:40 --> Total execution time: 0.1001
DEBUG - 2022-06-21 01:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:40:48 --> Total execution time: 0.0560
DEBUG - 2022-06-21 01:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:40:52 --> Total execution time: 0.0739
DEBUG - 2022-06-21 01:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:41:04 --> Total execution time: 0.0312
DEBUG - 2022-06-21 01:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:41:23 --> Total execution time: 0.0670
DEBUG - 2022-06-21 01:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:41:29 --> Total execution time: 0.0452
DEBUG - 2022-06-21 01:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:41:31 --> Total execution time: 0.0408
DEBUG - 2022-06-21 01:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:41:33 --> Total execution time: 0.0420
DEBUG - 2022-06-21 01:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:41:36 --> Total execution time: 0.0545
DEBUG - 2022-06-21 01:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:42:55 --> Total execution time: 0.0571
DEBUG - 2022-06-21 01:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:13:27 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:43:27 --> Total execution time: 0.0437
DEBUG - 2022-06-21 01:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:43:39 --> Total execution time: 0.0497
DEBUG - 2022-06-21 01:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:43:56 --> Total execution time: 0.1437
DEBUG - 2022-06-21 01:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:44:02 --> Total execution time: 0.0433
DEBUG - 2022-06-21 01:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:44:25 --> Total execution time: 0.0791
DEBUG - 2022-06-21 01:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:44:32 --> Total execution time: 0.0813
DEBUG - 2022-06-21 01:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:44:43 --> Total execution time: 0.1034
DEBUG - 2022-06-21 01:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:46:44 --> Total execution time: 0.1216
DEBUG - 2022-06-21 01:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:46:51 --> Total execution time: 0.0684
DEBUG - 2022-06-21 01:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:46:58 --> Total execution time: 0.0480
DEBUG - 2022-06-21 01:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:47:06 --> Total execution time: 0.0465
DEBUG - 2022-06-21 01:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:47:08 --> Total execution time: 0.0489
DEBUG - 2022-06-21 01:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:47:12 --> Total execution time: 0.0450
DEBUG - 2022-06-21 01:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:15 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:47:15 --> Total execution time: 0.0544
DEBUG - 2022-06-21 01:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:47:21 --> Total execution time: 0.0463
DEBUG - 2022-06-21 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:47:32 --> Total execution time: 0.0480
DEBUG - 2022-06-21 01:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:48:03 --> Total execution time: 0.0723
DEBUG - 2022-06-21 01:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:18:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:18:06 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 01:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:48:52 --> Total execution time: 0.0400
DEBUG - 2022-06-21 01:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:49:08 --> Total execution time: 0.0352
DEBUG - 2022-06-21 01:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:49:30 --> Total execution time: 0.0436
DEBUG - 2022-06-21 01:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:19:37 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:49:38 --> Total execution time: 0.0448
DEBUG - 2022-06-21 01:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:49:47 --> Total execution time: 0.0412
DEBUG - 2022-06-21 01:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:20:30 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 01:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:51:31 --> Total execution time: 0.0510
DEBUG - 2022-06-21 01:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:51:56 --> Total execution time: 0.0672
DEBUG - 2022-06-21 01:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:52:10 --> Total execution time: 0.0461
DEBUG - 2022-06-21 01:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:52:16 --> Total execution time: 0.0671
DEBUG - 2022-06-21 01:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:52:22 --> Total execution time: 0.0457
DEBUG - 2022-06-21 01:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:22:35 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 01:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:52:39 --> Total execution time: 0.0680
DEBUG - 2022-06-21 01:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:52:58 --> Total execution time: 0.0610
DEBUG - 2022-06-21 01:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:15 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:54:15 --> Total execution time: 0.0340
DEBUG - 2022-06-21 01:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:18 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:54:18 --> Total execution time: 0.0322
DEBUG - 2022-06-21 01:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:24:25 --> Total execution time: 0.0574
DEBUG - 2022-06-21 01:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:26 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:54:26 --> Total execution time: 0.0339
DEBUG - 2022-06-21 01:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:54:26 --> Total execution time: 0.0401
DEBUG - 2022-06-21 01:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:24:32 --> Total execution time: 0.0993
DEBUG - 2022-06-21 01:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:54:32 --> Total execution time: 0.0542
DEBUG - 2022-06-21 01:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:54:40 --> Total execution time: 0.0657
DEBUG - 2022-06-21 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:55:56 --> Total execution time: 0.0595
DEBUG - 2022-06-21 01:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:56:07 --> Total execution time: 0.0538
DEBUG - 2022-06-21 01:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:27:24 --> Total execution time: 0.0489
DEBUG - 2022-06-21 01:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:27:33 --> Total execution time: 0.0730
DEBUG - 2022-06-21 01:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:57:42 --> Total execution time: 0.0528
DEBUG - 2022-06-21 01:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:58:07 --> Total execution time: 0.0730
DEBUG - 2022-06-21 01:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:58:19 --> Total execution time: 0.0731
DEBUG - 2022-06-21 01:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:58:35 --> Total execution time: 0.0744
DEBUG - 2022-06-21 01:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:58:43 --> Total execution time: 0.0718
DEBUG - 2022-06-21 01:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:58:51 --> Total execution time: 0.0456
DEBUG - 2022-06-21 01:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:59:13 --> Total execution time: 0.0465
DEBUG - 2022-06-21 01:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:59:49 --> Total execution time: 0.0523
DEBUG - 2022-06-21 01:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:00:23 --> Total execution time: 0.0433
DEBUG - 2022-06-21 01:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:00:36 --> Total execution time: 0.0494
DEBUG - 2022-06-21 01:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:00:51 --> Total execution time: 0.0629
DEBUG - 2022-06-21 01:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:01:00 --> Total execution time: 0.1007
DEBUG - 2022-06-21 01:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:01:09 --> Total execution time: 0.0493
DEBUG - 2022-06-21 01:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:02:00 --> Total execution time: 0.0675
DEBUG - 2022-06-21 01:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:02:40 --> Total execution time: 0.1371
DEBUG - 2022-06-21 01:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:03:51 --> Total execution time: 0.0475
DEBUG - 2022-06-21 01:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:03:57 --> Total execution time: 0.0443
DEBUG - 2022-06-21 01:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:04:01 --> Total execution time: 0.1247
DEBUG - 2022-06-21 01:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:04:08 --> Total execution time: 0.0458
DEBUG - 2022-06-21 01:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:34:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:04:10 --> Total execution time: 0.0390
DEBUG - 2022-06-21 01:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:04:12 --> Total execution time: 0.0465
DEBUG - 2022-06-21 01:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:04:16 --> Total execution time: 0.0459
DEBUG - 2022-06-21 01:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:04:19 --> Total execution time: 0.0485
DEBUG - 2022-06-21 01:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:34:37 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:04:37 --> Total execution time: 0.0447
DEBUG - 2022-06-21 01:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:00 --> Total execution time: 0.0513
DEBUG - 2022-06-21 01:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:04 --> Total execution time: 0.0327
DEBUG - 2022-06-21 01:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:06 --> Total execution time: 0.0415
DEBUG - 2022-06-21 01:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:09 --> Total execution time: 0.0556
DEBUG - 2022-06-21 01:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:14 --> Total execution time: 0.0329
DEBUG - 2022-06-21 01:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:21 --> Total execution time: 0.0540
DEBUG - 2022-06-21 01:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:27 --> Total execution time: 0.0474
DEBUG - 2022-06-21 01:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:30 --> Total execution time: 0.0476
DEBUG - 2022-06-21 01:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:58 --> Total execution time: 0.0571
DEBUG - 2022-06-21 01:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:02 --> Total execution time: 0.0977
DEBUG - 2022-06-21 01:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:36:02 --> Total execution time: 0.0313
DEBUG - 2022-06-21 01:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:05 --> Total execution time: 0.0777
DEBUG - 2022-06-21 01:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:07 --> Total execution time: 0.0492
DEBUG - 2022-06-21 01:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:16 --> Total execution time: 0.0514
DEBUG - 2022-06-21 01:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:23 --> Total execution time: 0.0462
DEBUG - 2022-06-21 01:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:30 --> Total execution time: 0.0525
DEBUG - 2022-06-21 01:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:32 --> Total execution time: 0.0483
DEBUG - 2022-06-21 01:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:34 --> Total execution time: 0.0553
DEBUG - 2022-06-21 01:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:37 --> Total execution time: 0.0508
DEBUG - 2022-06-21 01:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:06:40 --> Total execution time: 0.0466
DEBUG - 2022-06-21 01:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:08:33 --> Total execution time: 0.0481
DEBUG - 2022-06-21 01:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:08:45 --> Total execution time: 0.0667
DEBUG - 2022-06-21 01:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:40:20 --> Total execution time: 0.0482
DEBUG - 2022-06-21 01:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:40:26 --> Total execution time: 0.1079
DEBUG - 2022-06-21 01:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:40:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:10:58 --> Total execution time: 0.0336
DEBUG - 2022-06-21 01:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:11:09 --> Total execution time: 0.0434
DEBUG - 2022-06-21 01:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:11:49 --> Total execution time: 0.0866
DEBUG - 2022-06-21 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:11:51 --> Total execution time: 0.1322
DEBUG - 2022-06-21 01:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:41:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:41:56 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 01:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:41:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:41:57 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-21 01:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:11:58 --> Total execution time: 0.0875
DEBUG - 2022-06-21 01:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:12:02 --> Total execution time: 0.0664
DEBUG - 2022-06-21 01:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:12:08 --> Total execution time: 0.0436
DEBUG - 2022-06-21 01:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:12:11 --> Total execution time: 0.0418
DEBUG - 2022-06-21 01:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:12:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 01:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:12:22 --> Total execution time: 0.0774
DEBUG - 2022-06-21 01:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:12:30 --> Total execution time: 0.0766
DEBUG - 2022-06-21 01:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:12:37 --> Total execution time: 0.0500
DEBUG - 2022-06-21 01:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:12:45 --> Total execution time: 0.0622
DEBUG - 2022-06-21 01:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:13:00 --> Total execution time: 0.1121
DEBUG - 2022-06-21 01:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:13:25 --> Total execution time: 0.1115
DEBUG - 2022-06-21 01:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:13:36 --> Total execution time: 0.0469
DEBUG - 2022-06-21 01:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:13:52 --> Total execution time: 0.0694
DEBUG - 2022-06-21 01:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:14:08 --> Total execution time: 0.0442
DEBUG - 2022-06-21 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:16:58 --> Total execution time: 0.1544
DEBUG - 2022-06-21 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:47:52 --> 404 Page Not Found: Adstxt/index
ERROR - 2022-06-21 01:47:52 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-21 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:47:52 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-21 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:47:52 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-21 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:47:53 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-21 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:47:53 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-21 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:47:54 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-21 01:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:47:56 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-06-21 01:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:47:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:17:59 --> Total execution time: 0.0532
DEBUG - 2022-06-21 01:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:22:18 --> Total execution time: 0.1791
DEBUG - 2022-06-21 01:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:22:27 --> Total execution time: 0.0417
DEBUG - 2022-06-21 01:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:56:03 --> Total execution time: 0.0862
DEBUG - 2022-06-21 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:56:05 --> Total execution time: 0.0726
DEBUG - 2022-06-21 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:56:05 --> Total execution time: 0.1150
DEBUG - 2022-06-21 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:26:05 --> Total execution time: 0.0362
DEBUG - 2022-06-21 01:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:25 --> No URI present. Default controller set.
DEBUG - 2022-06-21 01:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:26:25 --> Total execution time: 0.0480
DEBUG - 2022-06-21 01:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:26:29 --> Total execution time: 0.0418
DEBUG - 2022-06-21 01:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:26:35 --> Total execution time: 0.0502
DEBUG - 2022-06-21 01:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:26:39 --> Total execution time: 0.0639
DEBUG - 2022-06-21 01:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:26:42 --> Total execution time: 0.0541
DEBUG - 2022-06-21 01:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:26:54 --> Total execution time: 0.0523
DEBUG - 2022-06-21 01:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:57:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 01:57:02 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 01:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:29:28 --> Total execution time: 0.1556
DEBUG - 2022-06-21 01:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 01:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 01:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 01:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:29:53 --> Total execution time: 0.0477
DEBUG - 2022-06-21 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:30:03 --> Total execution time: 0.0535
DEBUG - 2022-06-21 02:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:00:51 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:30:51 --> Total execution time: 0.0333
DEBUG - 2022-06-21 02:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:31:07 --> Total execution time: 0.0419
DEBUG - 2022-06-21 02:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:19 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:31:19 --> Total execution time: 0.0558
DEBUG - 2022-06-21 02:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:28 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:31:28 --> Total execution time: 0.0448
DEBUG - 2022-06-21 02:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:28 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:31:28 --> Total execution time: 0.0511
DEBUG - 2022-06-21 02:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:28 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:31:28 --> Total execution time: 0.0487
DEBUG - 2022-06-21 02:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:01:32 --> Total execution time: 0.0493
DEBUG - 2022-06-21 02:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:01:34 --> Total execution time: 0.0495
DEBUG - 2022-06-21 02:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:01:34 --> Total execution time: 0.1233
DEBUG - 2022-06-21 02:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:31:42 --> Total execution time: 0.1268
DEBUG - 2022-06-21 02:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:31:49 --> Total execution time: 0.0506
DEBUG - 2022-06-21 02:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:02:48 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:32:48 --> Total execution time: 0.0328
DEBUG - 2022-06-21 02:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:02:49 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:32:49 --> Total execution time: 0.0446
DEBUG - 2022-06-21 02:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:04:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 02:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:34:04 --> Total execution time: 1.9746
DEBUG - 2022-06-21 02:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 02:04:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 02:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:38:27 --> Total execution time: 0.1593
DEBUG - 2022-06-21 02:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:38:31 --> Total execution time: 0.0623
DEBUG - 2022-06-21 02:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:38:33 --> Total execution time: 0.0542
DEBUG - 2022-06-21 02:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:38:36 --> Total execution time: 0.0573
DEBUG - 2022-06-21 02:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:38:40 --> Total execution time: 0.0437
DEBUG - 2022-06-21 02:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:10:17 --> Total execution time: 0.0369
DEBUG - 2022-06-21 02:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:10:23 --> Total execution time: 0.0415
DEBUG - 2022-06-21 02:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:10:23 --> Total execution time: 0.0633
DEBUG - 2022-06-21 02:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:13:13 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:43:13 --> Total execution time: 0.1051
DEBUG - 2022-06-21 02:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:43:20 --> Total execution time: 0.0497
DEBUG - 2022-06-21 02:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:43:28 --> Total execution time: 0.0524
DEBUG - 2022-06-21 02:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:43:31 --> Total execution time: 0.0527
DEBUG - 2022-06-21 02:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:13:38 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:43:38 --> Total execution time: 0.0313
DEBUG - 2022-06-21 02:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:43:39 --> Total execution time: 0.0506
DEBUG - 2022-06-21 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:13:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:43:59 --> Total execution time: 0.0308
DEBUG - 2022-06-21 02:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:44:01 --> Total execution time: 0.0477
DEBUG - 2022-06-21 02:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:44:02 --> Total execution time: 0.0395
DEBUG - 2022-06-21 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:45:53 --> Total execution time: 0.0468
DEBUG - 2022-06-21 02:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:48:27 --> Total execution time: 0.1011
DEBUG - 2022-06-21 02:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:49:04 --> Total execution time: 0.0357
DEBUG - 2022-06-21 02:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:49:10 --> Total execution time: 0.0552
DEBUG - 2022-06-21 02:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:49:14 --> Total execution time: 0.0556
DEBUG - 2022-06-21 02:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:49:19 --> Total execution time: 0.0492
DEBUG - 2022-06-21 02:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:49:27 --> Total execution time: 0.0414
DEBUG - 2022-06-21 02:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 02:20:12 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-21 02:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:20:30 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:50:30 --> Total execution time: 0.0521
DEBUG - 2022-06-21 02:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:21:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:51:22 --> Total execution time: 0.0489
DEBUG - 2022-06-21 02:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:21:23 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:51:23 --> Total execution time: 0.0331
DEBUG - 2022-06-21 02:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 02:21:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 02:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 02:21:59 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-21 02:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:56:19 --> Total execution time: 0.1916
DEBUG - 2022-06-21 02:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:57:15 --> Total execution time: 0.0469
DEBUG - 2022-06-21 02:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:57:23 --> Total execution time: 0.0544
DEBUG - 2022-06-21 02:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:57:27 --> Total execution time: 0.0554
DEBUG - 2022-06-21 02:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:57:29 --> Total execution time: 0.0651
DEBUG - 2022-06-21 02:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:57:31 --> Total execution time: 0.0343
DEBUG - 2022-06-21 02:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:39:26 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:09:26 --> Total execution time: 0.1967
DEBUG - 2022-06-21 02:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:09:38 --> Total execution time: 0.0429
DEBUG - 2022-06-21 02:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:10:26 --> Total execution time: 0.0924
DEBUG - 2022-06-21 02:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:10:32 --> Total execution time: 0.0714
DEBUG - 2022-06-21 02:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:10:36 --> Total execution time: 0.0638
DEBUG - 2022-06-21 02:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:10:54 --> Total execution time: 0.0446
DEBUG - 2022-06-21 02:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:11:27 --> Total execution time: 0.1895
DEBUG - 2022-06-21 02:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:11:45 --> Total execution time: 0.0619
DEBUG - 2022-06-21 02:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:11:52 --> Total execution time: 0.0587
DEBUG - 2022-06-21 02:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:12:31 --> Total execution time: 0.0659
DEBUG - 2022-06-21 02:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:45:06 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:15:06 --> Total execution time: 0.0968
DEBUG - 2022-06-21 02:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:45:08 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:15:08 --> Total execution time: 0.0352
DEBUG - 2022-06-21 02:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:45:41 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:15:41 --> Total execution time: 0.0566
DEBUG - 2022-06-21 02:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:20:26 --> Total execution time: 0.1002
DEBUG - 2022-06-21 02:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 02:52:56 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-21 02:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 02:52:56 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-21 02:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:52:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 02:52:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 02:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:58:35 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:28:36 --> Total execution time: 0.1285
DEBUG - 2022-06-21 02:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:28:53 --> Total execution time: 0.0522
DEBUG - 2022-06-21 02:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 02:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:29:00 --> Total execution time: 0.0708
DEBUG - 2022-06-21 02:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 02:59:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 02:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 02:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:29:42 --> Total execution time: 0.0361
DEBUG - 2022-06-21 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:30:02 --> Total execution time: 0.0597
DEBUG - 2022-06-21 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:35:02 --> Total execution time: 0.0629
DEBUG - 2022-06-21 03:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:35:14 --> Total execution time: 0.0504
DEBUG - 2022-06-21 03:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:35:17 --> Total execution time: 0.0556
DEBUG - 2022-06-21 03:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:35:24 --> Total execution time: 0.0539
DEBUG - 2022-06-21 03:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:35:32 --> Total execution time: 0.0416
DEBUG - 2022-06-21 03:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:37:57 --> Total execution time: 0.0512
DEBUG - 2022-06-21 03:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:44 --> Total execution time: 0.0284
DEBUG - 2022-06-21 03:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:39:12 --> Total execution time: 0.0476
DEBUG - 2022-06-21 03:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:39:32 --> Total execution time: 0.0613
DEBUG - 2022-06-21 03:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:40:01 --> Total execution time: 0.1186
DEBUG - 2022-06-21 03:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:10:23 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:40:23 --> Total execution time: 0.0507
DEBUG - 2022-06-21 03:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:10:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:40:24 --> Total execution time: 0.0398
DEBUG - 2022-06-21 03:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:40:50 --> Total execution time: 0.1012
DEBUG - 2022-06-21 03:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:41:47 --> Total execution time: 0.0495
DEBUG - 2022-06-21 03:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:42:06 --> Total execution time: 0.0476
DEBUG - 2022-06-21 03:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 03:12:45 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 03:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:15:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 03:15:18 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 03:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 03:17:31 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 03:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:50:23 --> Total execution time: 0.0443
DEBUG - 2022-06-21 03:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:55:09 --> Total execution time: 0.1715
DEBUG - 2022-06-21 03:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:55:19 --> Total execution time: 0.0432
DEBUG - 2022-06-21 03:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:25:35 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:55:35 --> Total execution time: 0.0379
DEBUG - 2022-06-21 03:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:55:52 --> Total execution time: 0.0345
DEBUG - 2022-06-21 03:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:56:23 --> Total execution time: 0.0526
DEBUG - 2022-06-21 03:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:56:41 --> Total execution time: 0.0766
DEBUG - 2022-06-21 03:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:56:56 --> Total execution time: 0.0558
DEBUG - 2022-06-21 03:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:56:57 --> Total execution time: 0.0592
DEBUG - 2022-06-21 03:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:26:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:56:58 --> Total execution time: 0.0431
DEBUG - 2022-06-21 03:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:29:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:59:44 --> Total execution time: 0.1297
DEBUG - 2022-06-21 03:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:05:00 --> Total execution time: 0.0993
DEBUG - 2022-06-21 03:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:05:50 --> Total execution time: 0.1681
DEBUG - 2022-06-21 03:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:05:57 --> Total execution time: 0.2371
DEBUG - 2022-06-21 03:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:06:27 --> Total execution time: 0.0720
DEBUG - 2022-06-21 03:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:06:32 --> Total execution time: 0.0546
DEBUG - 2022-06-21 03:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:06:39 --> Total execution time: 0.0536
DEBUG - 2022-06-21 03:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:06:48 --> Total execution time: 0.0439
DEBUG - 2022-06-21 03:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:39:45 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:09:45 --> Total execution time: 0.0553
DEBUG - 2022-06-21 03:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:09:47 --> Total execution time: 0.0288
DEBUG - 2022-06-21 03:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:09:52 --> Total execution time: 0.0481
DEBUG - 2022-06-21 03:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:09:55 --> Total execution time: 0.0740
DEBUG - 2022-06-21 03:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:09:58 --> Total execution time: 0.0477
DEBUG - 2022-06-21 03:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:10:15 --> Total execution time: 0.0438
DEBUG - 2022-06-21 03:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:10:50 --> Total execution time: 0.0287
DEBUG - 2022-06-21 03:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 03:40:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 03:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:11:45 --> Total execution time: 0.0490
DEBUG - 2022-06-21 03:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:42:02 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:12:02 --> Total execution time: 0.1134
DEBUG - 2022-06-21 03:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:12:06 --> Total execution time: 0.0709
DEBUG - 2022-06-21 03:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:12:15 --> Total execution time: 0.0752
DEBUG - 2022-06-21 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:12:42 --> Total execution time: 0.0503
DEBUG - 2022-06-21 03:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:42:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:12:44 --> Total execution time: 0.0643
DEBUG - 2022-06-21 03:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:44:23 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:14:23 --> Total execution time: 0.0328
DEBUG - 2022-06-21 03:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:44:36 --> Total execution time: 0.0446
DEBUG - 2022-06-21 03:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:44:39 --> Total execution time: 0.0456
DEBUG - 2022-06-21 03:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:44:39 --> Total execution time: 0.0934
DEBUG - 2022-06-21 03:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:14:41 --> Total execution time: 0.0314
DEBUG - 2022-06-21 03:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:14:51 --> Total execution time: 0.0444
DEBUG - 2022-06-21 03:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:15:37 --> Total execution time: 0.0424
DEBUG - 2022-06-21 03:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:45:45 --> Total execution time: 0.0549
DEBUG - 2022-06-21 03:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:45:46 --> Total execution time: 0.0531
DEBUG - 2022-06-21 03:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:45:46 --> Total execution time: 0.0678
DEBUG - 2022-06-21 03:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:45:51 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:15:51 --> Total execution time: 0.0441
DEBUG - 2022-06-21 03:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:45:54 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:15:54 --> Total execution time: 0.0417
DEBUG - 2022-06-21 03:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:00 --> Total execution time: 0.0473
DEBUG - 2022-06-21 03:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:00 --> Total execution time: 0.0414
DEBUG - 2022-06-21 03:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:01 --> Total execution time: 0.0505
DEBUG - 2022-06-21 03:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:01 --> Total execution time: 0.0839
DEBUG - 2022-06-21 03:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:02 --> Total execution time: 0.0397
DEBUG - 2022-06-21 03:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:16 --> Total execution time: 0.0426
DEBUG - 2022-06-21 03:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:22 --> Total execution time: 0.0449
DEBUG - 2022-06-21 03:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:25 --> Total execution time: 0.0452
DEBUG - 2022-06-21 03:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:32 --> Total execution time: 0.0431
DEBUG - 2022-06-21 03:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:33 --> Total execution time: 0.0586
DEBUG - 2022-06-21 03:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:33 --> Total execution time: 0.1189
DEBUG - 2022-06-21 03:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:37 --> Total execution time: 0.0563
DEBUG - 2022-06-21 03:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:37 --> Total execution time: 0.0472
DEBUG - 2022-06-21 03:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:38 --> Total execution time: 0.0440
DEBUG - 2022-06-21 03:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:39 --> Total execution time: 0.0906
DEBUG - 2022-06-21 03:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:41 --> Total execution time: 0.0415
DEBUG - 2022-06-21 03:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:42 --> Total execution time: 0.0417
DEBUG - 2022-06-21 03:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:46:42 --> Total execution time: 0.0748
DEBUG - 2022-06-21 03:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:44 --> Total execution time: 0.0435
DEBUG - 2022-06-21 03:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:47 --> Total execution time: 0.0672
DEBUG - 2022-06-21 03:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:54 --> Total execution time: 0.1090
DEBUG - 2022-06-21 03:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:16:58 --> Total execution time: 0.0869
DEBUG - 2022-06-21 03:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:17:06 --> Total execution time: 0.0428
DEBUG - 2022-06-21 03:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:17:08 --> Total execution time: 0.0400
DEBUG - 2022-06-21 03:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:17:08 --> Total execution time: 0.0371
DEBUG - 2022-06-21 03:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:47:13 --> Total execution time: 0.0391
DEBUG - 2022-06-21 03:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:47:14 --> Total execution time: 0.0435
DEBUG - 2022-06-21 03:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:47:14 --> Total execution time: 0.0515
DEBUG - 2022-06-21 03:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:17:14 --> Total execution time: 0.0440
DEBUG - 2022-06-21 03:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:17:23 --> Total execution time: 0.0471
DEBUG - 2022-06-21 03:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:17:31 --> Total execution time: 0.0351
DEBUG - 2022-06-21 03:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:19:32 --> Total execution time: 0.0467
DEBUG - 2022-06-21 03:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:19:48 --> Total execution time: 0.0997
DEBUG - 2022-06-21 03:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:49:49 --> Total execution time: 0.0423
DEBUG - 2022-06-21 03:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:49:50 --> Total execution time: 0.0439
DEBUG - 2022-06-21 03:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:49:50 --> Total execution time: 0.1086
DEBUG - 2022-06-21 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:50:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 03:50:34 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-06-21 03:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:00 --> Total execution time: 0.0465
DEBUG - 2022-06-21 03:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:04 --> Total execution time: 0.0591
DEBUG - 2022-06-21 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:06 --> Total execution time: 0.0456
DEBUG - 2022-06-21 03:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:06 --> Total execution time: 0.0742
DEBUG - 2022-06-21 03:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:07 --> Total execution time: 0.0455
DEBUG - 2022-06-21 03:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:08 --> Total execution time: 0.0485
DEBUG - 2022-06-21 03:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:08 --> Total execution time: 0.0972
DEBUG - 2022-06-21 03:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:09 --> No URI present. Default controller set.
DEBUG - 2022-06-21 03:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:21:09 --> Total execution time: 0.0454
DEBUG - 2022-06-21 03:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:13 --> Total execution time: 0.0496
DEBUG - 2022-06-21 03:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:14 --> Total execution time: 0.0573
DEBUG - 2022-06-21 03:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:51:14 --> Total execution time: 0.0895
DEBUG - 2022-06-21 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:21:16 --> Total execution time: 0.0404
DEBUG - 2022-06-21 03:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:21:17 --> Total execution time: 0.0429
DEBUG - 2022-06-21 03:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:21:23 --> Total execution time: 0.0443
DEBUG - 2022-06-21 03:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:21:32 --> Total execution time: 0.0429
DEBUG - 2022-06-21 03:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:21:54 --> Total execution time: 0.0412
DEBUG - 2022-06-21 03:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:22:02 --> Total execution time: 0.0411
DEBUG - 2022-06-21 03:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 03:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:22:06 --> Total execution time: 0.0464
DEBUG - 2022-06-21 03:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:23:30 --> Total execution time: 0.1013
DEBUG - 2022-06-21 03:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 03:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 03:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:23:32 --> Total execution time: 0.0411
DEBUG - 2022-06-21 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:30:03 --> Total execution time: 0.1271
DEBUG - 2022-06-21 04:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:31:58 --> Total execution time: 0.0433
DEBUG - 2022-06-21 04:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:02:47 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:32:47 --> Total execution time: 0.1078
DEBUG - 2022-06-21 04:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:32:51 --> Total execution time: 0.0540
DEBUG - 2022-06-21 04:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:32:55 --> Total execution time: 0.0508
DEBUG - 2022-06-21 04:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:03:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 04:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:33:03 --> Total execution time: 0.0553
DEBUG - 2022-06-21 04:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:33:24 --> Total execution time: 0.0524
DEBUG - 2022-06-21 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:33:32 --> Total execution time: 0.0432
DEBUG - 2022-06-21 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:37:54 --> Total execution time: 0.1189
DEBUG - 2022-06-21 04:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:12:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:42:58 --> Total execution time: 0.1078
DEBUG - 2022-06-21 04:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:43:04 --> Total execution time: 0.0397
DEBUG - 2022-06-21 04:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:43:06 --> Total execution time: 0.0299
DEBUG - 2022-06-21 04:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:43:08 --> Total execution time: 0.0308
DEBUG - 2022-06-21 04:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:43:08 --> Total execution time: 0.0381
DEBUG - 2022-06-21 04:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:43:36 --> Total execution time: 0.0600
DEBUG - 2022-06-21 04:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:43:39 --> Total execution time: 0.0296
DEBUG - 2022-06-21 04:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:43:47 --> Total execution time: 0.1059
DEBUG - 2022-06-21 04:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:43:49 --> Total execution time: 0.0450
DEBUG - 2022-06-21 04:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:44:12 --> Total execution time: 0.1081
DEBUG - 2022-06-21 04:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:14:40 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:44:40 --> Total execution time: 0.0310
DEBUG - 2022-06-21 04:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:44:45 --> Total execution time: 0.1336
DEBUG - 2022-06-21 04:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:44:46 --> Total execution time: 0.0716
DEBUG - 2022-06-21 04:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:44:48 --> Total execution time: 0.0287
DEBUG - 2022-06-21 04:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:45:16 --> Total execution time: 0.0989
DEBUG - 2022-06-21 04:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:15:23 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:45:23 --> Total execution time: 0.1354
DEBUG - 2022-06-21 04:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:16:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:46:04 --> Total execution time: 0.0419
DEBUG - 2022-06-21 04:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:46:08 --> Total execution time: 0.0361
DEBUG - 2022-06-21 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:47:00 --> Total execution time: 0.0461
DEBUG - 2022-06-21 04:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:47:34 --> Total execution time: 0.0585
DEBUG - 2022-06-21 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:47:35 --> Total execution time: 0.0417
DEBUG - 2022-06-21 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:35 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:47:35 --> Total execution time: 0.0630
DEBUG - 2022-06-21 04:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:47:36 --> Total execution time: 0.0502
DEBUG - 2022-06-21 04:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:36 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:47:36 --> Total execution time: 0.0822
DEBUG - 2022-06-21 04:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:47:47 --> Total execution time: 0.0490
DEBUG - 2022-06-21 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:48:03 --> Total execution time: 0.0536
DEBUG - 2022-06-21 04:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:48:27 --> Total execution time: 0.0405
DEBUG - 2022-06-21 04:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:49:32 --> Total execution time: 0.0407
DEBUG - 2022-06-21 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:51:00 --> Total execution time: 0.0462
DEBUG - 2022-06-21 04:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:51:23 --> Total execution time: 0.0750
DEBUG - 2022-06-21 04:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:51:28 --> Total execution time: 0.1040
DEBUG - 2022-06-21 04:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:51:43 --> Total execution time: 0.0512
DEBUG - 2022-06-21 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:51:56 --> Total execution time: 0.0787
DEBUG - 2022-06-21 04:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:52:21 --> Total execution time: 0.0643
DEBUG - 2022-06-21 04:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:52:29 --> Total execution time: 0.0493
DEBUG - 2022-06-21 04:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:53:00 --> Total execution time: 0.0470
DEBUG - 2022-06-21 04:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:53:07 --> Total execution time: 0.0552
DEBUG - 2022-06-21 04:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:53:15 --> Total execution time: 0.0757
DEBUG - 2022-06-21 04:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:54:31 --> Total execution time: 0.0628
DEBUG - 2022-06-21 04:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:24:39 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:54:39 --> Total execution time: 0.0402
DEBUG - 2022-06-21 04:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:54:47 --> Total execution time: 0.0452
DEBUG - 2022-06-21 04:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:54:50 --> Total execution time: 0.0525
DEBUG - 2022-06-21 04:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:54:52 --> Total execution time: 0.0685
DEBUG - 2022-06-21 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:54:55 --> Total execution time: 0.0745
DEBUG - 2022-06-21 04:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:28:49 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:58:49 --> Total execution time: 0.1493
DEBUG - 2022-06-21 04:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:32:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:32:50 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-06-21 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:32:52 --> 404 Page Not Found: Wp-loadphp/index
DEBUG - 2022-06-21 04:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:34:15 --> 404 Page Not Found: Shop/feed
DEBUG - 2022-06-21 04:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:04:17 --> Total execution time: 0.3418
DEBUG - 2022-06-21 04:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:04:21 --> Total execution time: 0.0702
DEBUG - 2022-06-21 04:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:07:17 --> Total execution time: 0.0954
DEBUG - 2022-06-21 04:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:09:24 --> Total execution time: 0.2063
DEBUG - 2022-06-21 04:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:09:28 --> Total execution time: 0.0498
DEBUG - 2022-06-21 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:09:39 --> Total execution time: 0.0497
DEBUG - 2022-06-21 04:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:39:54 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:09:54 --> Total execution time: 0.0407
DEBUG - 2022-06-21 04:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:09:59 --> Total execution time: 0.1179
DEBUG - 2022-06-21 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:42:29 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:12:29 --> Total execution time: 0.1241
DEBUG - 2022-06-21 04:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:42:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:12:33 --> Total execution time: 0.0457
DEBUG - 2022-06-21 04:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:43:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:43:31 --> 404 Page Not Found: Category/health
DEBUG - 2022-06-21 04:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:45:32 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:15:32 --> Total execution time: 0.0333
DEBUG - 2022-06-21 04:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:45:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:45:37 --> 404 Page Not Found: Category/culture
DEBUG - 2022-06-21 04:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:15:40 --> Total execution time: 0.0325
DEBUG - 2022-06-21 04:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:15:55 --> Total execution time: 0.0416
DEBUG - 2022-06-21 04:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:16:12 --> Total execution time: 0.0441
DEBUG - 2022-06-21 04:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:16:18 --> Total execution time: 0.0489
DEBUG - 2022-06-21 04:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:16:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 04:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:16:19 --> Total execution time: 0.0436
DEBUG - 2022-06-21 04:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:17:12 --> Total execution time: 0.0401
DEBUG - 2022-06-21 04:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:17:19 --> Total execution time: 0.0430
DEBUG - 2022-06-21 04:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:17:20 --> Total execution time: 0.0530
DEBUG - 2022-06-21 04:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:17:35 --> Total execution time: 0.0477
DEBUG - 2022-06-21 04:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:49:54 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:19:54 --> Total execution time: 0.0906
DEBUG - 2022-06-21 04:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:49:54 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:19:54 --> Total execution time: 0.0486
DEBUG - 2022-06-21 04:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:19:58 --> Total execution time: 0.0417
DEBUG - 2022-06-21 04:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:20:20 --> Total execution time: 0.0471
DEBUG - 2022-06-21 04:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:20:30 --> Total execution time: 0.0375
DEBUG - 2022-06-21 04:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:30 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:20:31 --> Total execution time: 0.0378
DEBUG - 2022-06-21 04:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:40 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:20:40 --> Total execution time: 0.0584
DEBUG - 2022-06-21 04:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:50:50 --> Total execution time: 0.0533
DEBUG - 2022-06-21 04:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:50:52 --> Total execution time: 0.0552
DEBUG - 2022-06-21 04:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:50:52 --> Total execution time: 0.0925
DEBUG - 2022-06-21 04:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:50:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:20:59 --> Total execution time: 0.0638
DEBUG - 2022-06-21 04:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:51:06 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-06-21 04:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:51:26 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 04:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:21:34 --> Total execution time: 0.0685
DEBUG - 2022-06-21 04:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:22:10 --> Total execution time: 0.0470
DEBUG - 2022-06-21 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:22:27 --> Total execution time: 0.0526
DEBUG - 2022-06-21 04:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:22:32 --> Total execution time: 0.1053
DEBUG - 2022-06-21 04:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:23:07 --> Total execution time: 0.0753
DEBUG - 2022-06-21 04:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:23:11 --> Total execution time: 0.0500
DEBUG - 2022-06-21 04:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:23:16 --> Total execution time: 0.0905
DEBUG - 2022-06-21 04:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:23:19 --> Total execution time: 0.0616
DEBUG - 2022-06-21 04:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:38 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:23:38 --> Total execution time: 0.0421
DEBUG - 2022-06-21 15:23:38 --> Total execution time: 0.0530
DEBUG - 2022-06-21 04:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:43 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:23:43 --> Total execution time: 0.0435
DEBUG - 2022-06-21 04:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:53:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:53:58 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 04:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:54:17 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:24:17 --> Total execution time: 0.0431
DEBUG - 2022-06-21 04:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:24:19 --> Total execution time: 0.0404
DEBUG - 2022-06-21 04:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 04:56:02 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 04:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:26:14 --> Total execution time: 0.0420
DEBUG - 2022-06-21 04:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:26:47 --> Total execution time: 0.0619
DEBUG - 2022-06-21 04:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:27:11 --> Total execution time: 0.0574
DEBUG - 2022-06-21 04:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:27:13 --> Total execution time: 0.0617
DEBUG - 2022-06-21 04:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:27:31 --> Total execution time: 0.0509
DEBUG - 2022-06-21 04:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:27:35 --> Total execution time: 0.0638
DEBUG - 2022-06-21 04:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:27:51 --> Total execution time: 0.0488
DEBUG - 2022-06-21 04:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:58:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 04:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:28:24 --> Total execution time: 0.0335
DEBUG - 2022-06-21 04:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:28:28 --> Total execution time: 0.0332
DEBUG - 2022-06-21 04:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:28:42 --> Total execution time: 0.0563
DEBUG - 2022-06-21 04:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:28:44 --> Total execution time: 0.0483
DEBUG - 2022-06-21 04:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:28:47 --> Total execution time: 0.0485
DEBUG - 2022-06-21 04:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:28:56 --> Total execution time: 0.0449
DEBUG - 2022-06-21 04:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:28:59 --> Total execution time: 0.0439
DEBUG - 2022-06-21 04:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 04:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 04:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 04:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:29:04 --> Total execution time: 0.0424
DEBUG - 2022-06-21 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:30:03 --> Total execution time: 0.0483
DEBUG - 2022-06-21 05:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 05:01:28 --> 404 Page Not Found: Category/reviews
DEBUG - 2022-06-21 05:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 05:02:01 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 05:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:04:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:34:12 --> Total execution time: 0.1556
DEBUG - 2022-06-21 05:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:34:38 --> Total execution time: 0.0447
DEBUG - 2022-06-21 05:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:34:42 --> Total execution time: 0.0467
DEBUG - 2022-06-21 05:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:34:49 --> Total execution time: 0.0487
DEBUG - 2022-06-21 05:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:05:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 05:05:06 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 05:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:38:11 --> Total execution time: 0.1102
DEBUG - 2022-06-21 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:38:12 --> Total execution time: 0.0427
DEBUG - 2022-06-21 05:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:38:51 --> Total execution time: 0.0456
DEBUG - 2022-06-21 05:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:38:58 --> Total execution time: 0.0448
DEBUG - 2022-06-21 05:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:10:01 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:40:01 --> Total execution time: 0.0349
DEBUG - 2022-06-21 05:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:40:02 --> Total execution time: 0.0413
DEBUG - 2022-06-21 05:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:40:04 --> Total execution time: 0.0463
DEBUG - 2022-06-21 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:41:04 --> Total execution time: 0.0301
DEBUG - 2022-06-21 05:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:13:00 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:43:00 --> Total execution time: 0.0328
DEBUG - 2022-06-21 05:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:43:07 --> Total execution time: 0.1526
DEBUG - 2022-06-21 05:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:43:09 --> Total execution time: 0.0514
DEBUG - 2022-06-21 05:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:43:11 --> Total execution time: 0.0518
DEBUG - 2022-06-21 05:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:43:19 --> Total execution time: 0.0528
DEBUG - 2022-06-21 05:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:43:19 --> Total execution time: 0.0467
DEBUG - 2022-06-21 05:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:43:20 --> Total execution time: 0.0645
DEBUG - 2022-06-21 05:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:43:28 --> Total execution time: 0.0478
DEBUG - 2022-06-21 05:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:44:07 --> Total execution time: 0.0475
DEBUG - 2022-06-21 05:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:44:10 --> Total execution time: 0.0548
DEBUG - 2022-06-21 05:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:44:21 --> Total execution time: 0.0486
DEBUG - 2022-06-21 05:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:44:22 --> Total execution time: 0.0478
DEBUG - 2022-06-21 05:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:44:25 --> Total execution time: 0.0532
DEBUG - 2022-06-21 05:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:44:27 --> Total execution time: 0.0462
DEBUG - 2022-06-21 05:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:14:38 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:44:38 --> Total execution time: 0.0338
DEBUG - 2022-06-21 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:15:02 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:45:02 --> Total execution time: 0.0433
DEBUG - 2022-06-21 05:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:45:15 --> Total execution time: 0.0435
DEBUG - 2022-06-21 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:15:22 --> Total execution time: 0.0480
DEBUG - 2022-06-21 05:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:45:25 --> Total execution time: 0.0467
DEBUG - 2022-06-21 05:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:19:27 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:49:27 --> Total execution time: 0.0851
DEBUG - 2022-06-21 05:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 05:19:39 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:51:36 --> Total execution time: 0.0687
DEBUG - 2022-06-21 05:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:51:47 --> Total execution time: 0.0405
DEBUG - 2022-06-21 05:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:51:50 --> Total execution time: 0.0602
DEBUG - 2022-06-21 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:52:00 --> Total execution time: 0.0582
DEBUG - 2022-06-21 05:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:52:28 --> Total execution time: 0.0484
DEBUG - 2022-06-21 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:52:40 --> Total execution time: 0.0596
DEBUG - 2022-06-21 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:53:14 --> Total execution time: 0.0442
DEBUG - 2022-06-21 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:54:26 --> Total execution time: 0.0451
DEBUG - 2022-06-21 05:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:56:53 --> Total execution time: 0.1603
DEBUG - 2022-06-21 05:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:56:53 --> Total execution time: 0.0460
DEBUG - 2022-06-21 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:26:54 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:56:54 --> Total execution time: 0.1023
DEBUG - 2022-06-21 05:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:56:57 --> Total execution time: 0.0515
DEBUG - 2022-06-21 05:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:04 --> Total execution time: 0.0582
DEBUG - 2022-06-21 05:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:09 --> Total execution time: 0.0449
DEBUG - 2022-06-21 05:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:12 --> Total execution time: 0.0464
DEBUG - 2022-06-21 05:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:28 --> Total execution time: 0.0526
DEBUG - 2022-06-21 05:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:31 --> Total execution time: 0.0480
DEBUG - 2022-06-21 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:35 --> Total execution time: 0.0515
DEBUG - 2022-06-21 05:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:35 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:35 --> Total execution time: 0.0323
DEBUG - 2022-06-21 05:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:40 --> Total execution time: 0.0286
DEBUG - 2022-06-21 05:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:46 --> Total execution time: 0.0543
DEBUG - 2022-06-21 05:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:57 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:57 --> Total execution time: 0.0355
DEBUG - 2022-06-21 05:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:58 --> Total execution time: 0.0540
DEBUG - 2022-06-21 05:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:57:59 --> Total execution time: 0.0474
DEBUG - 2022-06-21 05:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:02 --> Total execution time: 0.0383
DEBUG - 2022-06-21 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:13 --> Total execution time: 0.0457
DEBUG - 2022-06-21 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:19 --> Total execution time: 0.0502
DEBUG - 2022-06-21 05:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:22 --> Total execution time: 0.0425
DEBUG - 2022-06-21 05:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:23 --> Total execution time: 0.0508
DEBUG - 2022-06-21 05:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:25 --> Total execution time: 0.0643
DEBUG - 2022-06-21 05:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:32 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:32 --> Total execution time: 0.0570
DEBUG - 2022-06-21 05:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:35 --> Total execution time: 0.0465
DEBUG - 2022-06-21 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:42 --> Total execution time: 0.1155
DEBUG - 2022-06-21 05:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:52 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:52 --> Total execution time: 0.0630
DEBUG - 2022-06-21 05:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:53 --> Total execution time: 0.0553
DEBUG - 2022-06-21 05:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:56 --> Total execution time: 0.0414
DEBUG - 2022-06-21 05:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:58:58 --> Total execution time: 0.0397
DEBUG - 2022-06-21 05:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:04 --> Total execution time: 0.0724
DEBUG - 2022-06-21 05:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:07 --> Total execution time: 0.0522
DEBUG - 2022-06-21 05:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:13 --> Total execution time: 0.0504
DEBUG - 2022-06-21 05:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:17 --> Total execution time: 0.0478
DEBUG - 2022-06-21 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:21 --> Total execution time: 0.0926
DEBUG - 2022-06-21 05:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:23 --> Total execution time: 0.0597
DEBUG - 2022-06-21 05:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:25 --> Total execution time: 0.0670
DEBUG - 2022-06-21 05:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:28 --> Total execution time: 0.0444
DEBUG - 2022-06-21 05:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:59:33 --> Total execution time: 0.0491
DEBUG - 2022-06-21 05:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:16 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:00:16 --> Total execution time: 0.0374
DEBUG - 2022-06-21 05:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:00:20 --> Total execution time: 0.0415
DEBUG - 2022-06-21 05:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:00:22 --> Total execution time: 0.0433
DEBUG - 2022-06-21 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:00:26 --> Total execution time: 0.0701
DEBUG - 2022-06-21 05:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:00:30 --> Total execution time: 0.0463
DEBUG - 2022-06-21 05:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:00:33 --> Total execution time: 0.0513
DEBUG - 2022-06-21 05:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:00:44 --> Total execution time: 0.0477
DEBUG - 2022-06-21 05:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:01:13 --> Total execution time: 0.0669
DEBUG - 2022-06-21 05:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:01:54 --> Total execution time: 0.0594
DEBUG - 2022-06-21 05:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:32:00 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:00 --> Total execution time: 0.0433
DEBUG - 2022-06-21 05:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:09 --> Total execution time: 0.1428
DEBUG - 2022-06-21 05:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:13 --> Total execution time: 0.0785
DEBUG - 2022-06-21 05:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:17 --> Total execution time: 0.0437
DEBUG - 2022-06-21 05:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:21 --> Total execution time: 0.0405
DEBUG - 2022-06-21 05:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:30 --> Total execution time: 0.0615
DEBUG - 2022-06-21 05:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:03:00 --> Total execution time: 0.0884
DEBUG - 2022-06-21 05:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:03:37 --> Total execution time: 0.0436
DEBUG - 2022-06-21 05:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:04:03 --> Total execution time: 0.1076
DEBUG - 2022-06-21 05:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:04:06 --> Total execution time: 0.0491
DEBUG - 2022-06-21 05:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:04:12 --> Total execution time: 0.0478
DEBUG - 2022-06-21 05:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:06:05 --> Total execution time: 0.0485
DEBUG - 2022-06-21 05:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:06:30 --> Total execution time: 0.0510
DEBUG - 2022-06-21 05:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:37:29 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:07:29 --> Total execution time: 0.0344
DEBUG - 2022-06-21 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:07:45 --> Total execution time: 0.0401
DEBUG - 2022-06-21 05:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:39:09 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:09:10 --> Total execution time: 0.0325
DEBUG - 2022-06-21 05:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:09:46 --> Total execution time: 0.0481
DEBUG - 2022-06-21 05:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:39:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:09:59 --> Total execution time: 0.1107
DEBUG - 2022-06-21 05:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 05:40:36 --> 404 Page Not Found: Lessons/how-to-use-canva-for-personal-branding
DEBUG - 2022-06-21 05:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:44:34 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:14:35 --> Total execution time: 0.0912
DEBUG - 2022-06-21 05:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:14:47 --> Total execution time: 0.1358
DEBUG - 2022-06-21 05:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:45:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:15:44 --> Total execution time: 0.0364
DEBUG - 2022-06-21 05:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:15:48 --> Total execution time: 0.0322
DEBUG - 2022-06-21 05:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:16:15 --> Total execution time: 0.0517
DEBUG - 2022-06-21 05:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:16:42 --> Total execution time: 0.0502
DEBUG - 2022-06-21 05:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:17:38 --> Total execution time: 0.0616
DEBUG - 2022-06-21 05:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:47:39 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:17:39 --> Total execution time: 0.0354
DEBUG - 2022-06-21 05:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:17:45 --> Total execution time: 0.0409
DEBUG - 2022-06-21 05:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:48:03 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:18:03 --> Total execution time: 0.0485
DEBUG - 2022-06-21 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:48:13 --> Total execution time: 0.0745
DEBUG - 2022-06-21 05:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:48:18 --> Total execution time: 0.0582
DEBUG - 2022-06-21 05:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:48:18 --> Total execution time: 0.1018
DEBUG - 2022-06-21 05:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:49:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 05:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:19:30 --> Total execution time: 1.8991
DEBUG - 2022-06-21 05:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 05:50:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 05:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:20:40 --> Total execution time: 0.0641
DEBUG - 2022-06-21 05:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:21:02 --> Total execution time: 0.1072
DEBUG - 2022-06-21 05:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:22:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 05:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:22:05 --> Total execution time: 0.0439
DEBUG - 2022-06-21 05:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:22:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 16:22:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 16:22:08 --> Total execution time: 0.1863
DEBUG - 2022-06-21 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:23:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:23:00 --> Total execution time: 0.0466
DEBUG - 2022-06-21 05:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:23:43 --> Total execution time: 0.0461
DEBUG - 2022-06-21 05:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:23:46 --> Total execution time: 0.0488
DEBUG - 2022-06-21 05:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:23:59 --> Total execution time: 0.0514
DEBUG - 2022-06-21 05:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:01 --> Total execution time: 0.0564
DEBUG - 2022-06-21 05:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:07 --> Total execution time: 0.0477
DEBUG - 2022-06-21 05:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:12 --> Total execution time: 0.0461
DEBUG - 2022-06-21 05:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:43 --> Total execution time: 0.0294
DEBUG - 2022-06-21 05:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:56 --> Total execution time: 0.0439
DEBUG - 2022-06-21 05:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:58 --> Total execution time: 0.0288
DEBUG - 2022-06-21 05:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:03 --> Total execution time: 0.1063
DEBUG - 2022-06-21 16:25:03 --> Total execution time: 0.1068
DEBUG - 2022-06-21 05:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:15 --> Total execution time: 0.0696
DEBUG - 2022-06-21 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:22 --> Total execution time: 0.0618
DEBUG - 2022-06-21 05:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:25 --> Total execution time: 0.0728
DEBUG - 2022-06-21 05:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:36 --> Total execution time: 0.0344
DEBUG - 2022-06-21 05:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:48 --> Total execution time: 0.0414
DEBUG - 2022-06-21 05:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:26:02 --> Total execution time: 0.0495
DEBUG - 2022-06-21 05:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:26:37 --> Total execution time: 0.0459
DEBUG - 2022-06-21 05:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 05:56:40 --> 404 Page Not Found: Lessons/law-of-averages
DEBUG - 2022-06-21 05:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:26:49 --> Total execution time: 0.0488
DEBUG - 2022-06-21 05:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:26:59 --> Total execution time: 0.1287
DEBUG - 2022-06-21 05:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:28:17 --> Total execution time: 0.0409
DEBUG - 2022-06-21 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:28:27 --> Total execution time: 0.0613
DEBUG - 2022-06-21 05:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:28:48 --> Total execution time: 0.0725
DEBUG - 2022-06-21 05:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:28:52 --> Total execution time: 0.0402
DEBUG - 2022-06-21 05:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:28:54 --> Total execution time: 0.0852
DEBUG - 2022-06-21 05:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:28:59 --> Total execution time: 0.0498
DEBUG - 2022-06-21 05:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:29:07 --> Total execution time: 0.0505
DEBUG - 2022-06-21 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:29:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 16:29:10 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-06-21 05:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:29:11 --> Total execution time: 0.0780
DEBUG - 2022-06-21 05:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:29:16 --> Total execution time: 0.0721
DEBUG - 2022-06-21 05:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:29:25 --> Total execution time: 0.0539
DEBUG - 2022-06-21 05:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:28 --> No URI present. Default controller set.
DEBUG - 2022-06-21 05:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:29:28 --> Total execution time: 0.0320
DEBUG - 2022-06-21 05:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 05:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:29:31 --> Total execution time: 0.1010
DEBUG - 2022-06-21 05:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 05:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 05:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:29:45 --> Total execution time: 0.0884
DEBUG - 2022-06-21 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:30:02 --> Total execution time: 0.0418
DEBUG - 2022-06-21 06:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:30:06 --> Total execution time: 0.1893
DEBUG - 2022-06-21 06:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:30:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 06:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:30:16 --> Total execution time: 0.0823
DEBUG - 2022-06-21 06:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:00:19 --> Total execution time: 0.0367
DEBUG - 2022-06-21 06:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:00:39 --> Total execution time: 0.0386
DEBUG - 2022-06-21 06:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:49 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:30:49 --> Total execution time: 0.0429
DEBUG - 2022-06-21 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:01:00 --> Total execution time: 0.0396
DEBUG - 2022-06-21 06:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:01:06 --> Total execution time: 0.0440
DEBUG - 2022-06-21 06:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:01:08 --> Total execution time: 0.0395
DEBUG - 2022-06-21 06:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:13 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:31:13 --> Total execution time: 0.0449
DEBUG - 2022-06-21 06:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:31:15 --> Total execution time: 0.0931
DEBUG - 2022-06-21 06:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:31:48 --> Total execution time: 0.0287
DEBUG - 2022-06-21 06:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:01:53 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-21 06:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:31:54 --> Total execution time: 0.0563
DEBUG - 2022-06-21 06:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:32:24 --> Total execution time: 0.0675
DEBUG - 2022-06-21 06:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:32:37 --> Total execution time: 0.0476
DEBUG - 2022-06-21 06:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:32:41 --> Total execution time: 0.0377
DEBUG - 2022-06-21 06:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:32:51 --> Total execution time: 0.0462
DEBUG - 2022-06-21 06:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:00 --> Total execution time: 0.0449
DEBUG - 2022-06-21 06:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:08 --> Total execution time: 0.0484
DEBUG - 2022-06-21 06:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:13 --> Total execution time: 0.0450
DEBUG - 2022-06-21 06:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:16 --> Total execution time: 0.0809
DEBUG - 2022-06-21 06:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:19 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:19 --> Total execution time: 0.0265
DEBUG - 2022-06-21 06:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:20 --> Total execution time: 0.0410
DEBUG - 2022-06-21 06:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:36 --> Total execution time: 0.0408
DEBUG - 2022-06-21 06:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:38 --> Total execution time: 0.1370
DEBUG - 2022-06-21 06:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:40 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:40 --> Total execution time: 0.0264
DEBUG - 2022-06-21 06:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:03:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:33:44 --> Total execution time: 0.0420
DEBUG - 2022-06-21 06:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:34:12 --> Total execution time: 0.0394
DEBUG - 2022-06-21 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:34:15 --> Total execution time: 0.0700
DEBUG - 2022-06-21 06:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:04:16 --> Total execution time: 0.0366
DEBUG - 2022-06-21 06:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:04:17 --> Total execution time: 0.0454
DEBUG - 2022-06-21 06:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:04:17 --> Total execution time: 0.0706
DEBUG - 2022-06-21 06:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:34:20 --> Total execution time: 0.0745
DEBUG - 2022-06-21 06:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:36 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:34:37 --> Total execution time: 0.0446
DEBUG - 2022-06-21 06:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:34:46 --> Total execution time: 0.0418
DEBUG - 2022-06-21 06:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:05:19 --> Total execution time: 0.0435
DEBUG - 2022-06-21 06:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:05:21 --> Total execution time: 0.0452
DEBUG - 2022-06-21 06:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:05:21 --> Total execution time: 0.0669
DEBUG - 2022-06-21 06:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:35:26 --> Total execution time: 0.0301
DEBUG - 2022-06-21 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:05:37 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:35:37 --> Total execution time: 0.1065
DEBUG - 2022-06-21 06:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:36:46 --> Total execution time: 0.0429
DEBUG - 2022-06-21 06:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:07:00 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:37:00 --> Total execution time: 0.0440
DEBUG - 2022-06-21 06:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:07:44 --> Total execution time: 0.0429
DEBUG - 2022-06-21 06:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:07:57 --> Total execution time: 0.0554
DEBUG - 2022-06-21 06:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:08:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:08:12 --> 404 Page Not Found: Wp-includes/widgets
DEBUG - 2022-06-21 06:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:40:45 --> Total execution time: 0.0854
DEBUG - 2022-06-21 06:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:41:01 --> Total execution time: 0.0983
DEBUG - 2022-06-21 06:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:41:14 --> Total execution time: 0.1108
DEBUG - 2022-06-21 06:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:41:25 --> Total execution time: 0.0503
DEBUG - 2022-06-21 06:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:41:32 --> Total execution time: 0.1101
DEBUG - 2022-06-21 06:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:41:53 --> Total execution time: 0.0580
DEBUG - 2022-06-21 06:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:42:03 --> Total execution time: 0.0516
DEBUG - 2022-06-21 06:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:42:12 --> Total execution time: 0.0460
DEBUG - 2022-06-21 06:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:42:34 --> Total execution time: 0.0420
DEBUG - 2022-06-21 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:42:39 --> Total execution time: 0.0551
DEBUG - 2022-06-21 06:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:43:28 --> Total execution time: 0.0346
DEBUG - 2022-06-21 06:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:14:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:44:33 --> Total execution time: 0.0356
DEBUG - 2022-06-21 06:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:14:38 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:44:38 --> Total execution time: 0.0347
DEBUG - 2022-06-21 06:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:06 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:46:06 --> Total execution time: 0.0503
DEBUG - 2022-06-21 06:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:46:10 --> Total execution time: 0.0404
DEBUG - 2022-06-21 06:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:46:20 --> Total execution time: 0.0444
DEBUG - 2022-06-21 06:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:46:32 --> Total execution time: 0.0344
DEBUG - 2022-06-21 06:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:46:36 --> Total execution time: 0.0397
DEBUG - 2022-06-21 06:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:46:43 --> Total execution time: 0.0380
DEBUG - 2022-06-21 06:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:46:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 06:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:46:44 --> Total execution time: 0.0348
DEBUG - 2022-06-21 06:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:47:29 --> Total execution time: 0.0447
DEBUG - 2022-06-21 06:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:47:45 --> Total execution time: 0.0552
DEBUG - 2022-06-21 06:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:49:54 --> Total execution time: 0.1859
DEBUG - 2022-06-21 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:50:03 --> Total execution time: 0.0497
DEBUG - 2022-06-21 06:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:50:06 --> Total execution time: 0.0424
DEBUG - 2022-06-21 06:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:50:28 --> Total execution time: 0.0526
DEBUG - 2022-06-21 06:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:50:30 --> Total execution time: 0.0550
DEBUG - 2022-06-21 06:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:50:52 --> Total execution time: 0.0480
DEBUG - 2022-06-21 06:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:51:09 --> Total execution time: 0.1228
DEBUG - 2022-06-21 06:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:51:13 --> Total execution time: 0.0721
DEBUG - 2022-06-21 06:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:51:16 --> Total execution time: 0.1024
DEBUG - 2022-06-21 06:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:51:29 --> Total execution time: 0.0664
DEBUG - 2022-06-21 06:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:51:29 --> Total execution time: 0.0525
DEBUG - 2022-06-21 06:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:21:52 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:51:52 --> Total execution time: 0.0981
DEBUG - 2022-06-21 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:52:13 --> Total execution time: 0.0399
DEBUG - 2022-06-21 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:52:17 --> Total execution time: 0.0449
DEBUG - 2022-06-21 06:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:52:35 --> Total execution time: 0.0484
DEBUG - 2022-06-21 06:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:52:40 --> Total execution time: 0.0635
DEBUG - 2022-06-21 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:28:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:58:37 --> Total execution time: 0.0449
DEBUG - 2022-06-21 06:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:58:44 --> Total execution time: 0.0526
DEBUG - 2022-06-21 06:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:59:15 --> Total execution time: 0.0650
DEBUG - 2022-06-21 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:59:23 --> Total execution time: 0.0492
DEBUG - 2022-06-21 06:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:59:32 --> Total execution time: 0.0595
DEBUG - 2022-06-21 06:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:59:37 --> Total execution time: 0.0455
DEBUG - 2022-06-21 06:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:29:45 --> Total execution time: 0.0444
DEBUG - 2022-06-21 06:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:30:16 --> Total execution time: 0.1069
DEBUG - 2022-06-21 06:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:30:26 --> Total execution time: 0.0676
DEBUG - 2022-06-21 06:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:30:30 --> Total execution time: 0.0652
DEBUG - 2022-06-21 06:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:00:32 --> Total execution time: 0.0538
DEBUG - 2022-06-21 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:00:39 --> Total execution time: 0.0560
DEBUG - 2022-06-21 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:00:43 --> Total execution time: 0.0728
DEBUG - 2022-06-21 06:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:00:51 --> Total execution time: 0.1150
DEBUG - 2022-06-21 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:01:04 --> Total execution time: 0.0961
DEBUG - 2022-06-21 06:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:31:15 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 06:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:31:20 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:01:20 --> Total execution time: 0.0529
DEBUG - 2022-06-21 06:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:33:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 06:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:35:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:35:52 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 06:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:11 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:07:11 --> Total execution time: 0.1146
DEBUG - 2022-06-21 06:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:07:17 --> Total execution time: 0.0481
DEBUG - 2022-06-21 06:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:07:26 --> Total execution time: 0.0506
DEBUG - 2022-06-21 06:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:07:33 --> Total execution time: 0.0452
DEBUG - 2022-06-21 06:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:07:37 --> Total execution time: 0.0510
DEBUG - 2022-06-21 06:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:07:42 --> Total execution time: 0.0771
DEBUG - 2022-06-21 06:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:07:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 06:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:07:43 --> Total execution time: 0.0455
DEBUG - 2022-06-21 06:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:08:22 --> Total execution time: 0.0640
DEBUG - 2022-06-21 06:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:08:24 --> Total execution time: 0.0451
DEBUG - 2022-06-21 06:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:08:31 --> Total execution time: 0.0517
DEBUG - 2022-06-21 06:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:08:40 --> Total execution time: 0.0468
DEBUG - 2022-06-21 06:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:08:42 --> Total execution time: 0.0824
DEBUG - 2022-06-21 06:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:08:50 --> Total execution time: 0.0439
DEBUG - 2022-06-21 06:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:09:51 --> Total execution time: 0.0498
DEBUG - 2022-06-21 06:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:11:32 --> Total execution time: 0.1704
DEBUG - 2022-06-21 06:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:42:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:12:10 --> Total execution time: 0.0428
DEBUG - 2022-06-21 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:43:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:13:10 --> Total execution time: 0.0392
DEBUG - 2022-06-21 06:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:43:19 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:13:19 --> Total execution time: 0.0959
DEBUG - 2022-06-21 06:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:43:36 --> Total execution time: 0.0501
DEBUG - 2022-06-21 06:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:43:42 --> Total execution time: 0.0824
DEBUG - 2022-06-21 06:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:43:43 --> Total execution time: 0.1241
DEBUG - 2022-06-21 06:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:43:47 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 06:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:44:01 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:14:02 --> Total execution time: 0.0628
DEBUG - 2022-06-21 06:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:44:02 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 06:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:44:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:44:15 --> 404 Page Not Found: Category/uncategorized
DEBUG - 2022-06-21 06:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 06:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:15:06 --> Total execution time: 0.0669
DEBUG - 2022-06-21 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:15:14 --> Total execution time: 0.0536
DEBUG - 2022-06-21 06:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:15:26 --> Total execution time: 0.0607
DEBUG - 2022-06-21 06:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:18:54 --> Total execution time: 0.1273
DEBUG - 2022-06-21 06:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:19:20 --> Total execution time: 0.0488
DEBUG - 2022-06-21 06:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:53:09 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 06:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:54:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 06:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 06:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:24:05 --> Total execution time: 0.0963
DEBUG - 2022-06-21 06:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:57:03 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 06:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:58:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:58:15 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 06:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 06:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 06:59:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:30:03 --> Total execution time: 0.2643
DEBUG - 2022-06-21 07:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:30:25 --> Total execution time: 0.0514
DEBUG - 2022-06-21 07:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:30:47 --> Total execution time: 0.0578
DEBUG - 2022-06-21 07:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:30:49 --> Total execution time: 0.0662
DEBUG - 2022-06-21 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:30:50 --> Total execution time: 0.0448
DEBUG - 2022-06-21 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:30:52 --> Total execution time: 0.0668
DEBUG - 2022-06-21 07:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:30:57 --> Total execution time: 0.0514
DEBUG - 2022-06-21 07:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:31:05 --> Total execution time: 0.0669
DEBUG - 2022-06-21 07:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:31:11 --> Total execution time: 0.0551
DEBUG - 2022-06-21 07:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:31:33 --> Total execution time: 0.0427
DEBUG - 2022-06-21 07:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:02:03 --> No URI present. Default controller set.
DEBUG - 2022-06-21 07:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:32:03 --> Total execution time: 0.0372
DEBUG - 2022-06-21 07:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:42:16 --> Total execution time: 0.0918
DEBUG - 2022-06-21 07:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:42:22 --> Total execution time: 0.0420
DEBUG - 2022-06-21 07:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:42:25 --> Total execution time: 0.0555
DEBUG - 2022-06-21 07:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:42:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 07:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:42:26 --> Total execution time: 0.0445
DEBUG - 2022-06-21 07:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:42:34 --> Total execution time: 0.0493
DEBUG - 2022-06-21 07:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:42:38 --> Total execution time: 0.0444
DEBUG - 2022-06-21 07:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:12:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 07:12:47 --> 404 Page Not Found: Event/importance-of-research-seminar
DEBUG - 2022-06-21 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:43:01 --> Total execution time: 0.0662
DEBUG - 2022-06-21 07:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:43:04 --> Total execution time: 0.0497
DEBUG - 2022-06-21 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:43:09 --> Total execution time: 0.0498
DEBUG - 2022-06-21 07:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:43:27 --> Total execution time: 0.0703
DEBUG - 2022-06-21 07:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:43:44 --> Total execution time: 0.0500
DEBUG - 2022-06-21 07:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:43:49 --> Total execution time: 0.0613
DEBUG - 2022-06-21 07:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:43:52 --> Total execution time: 0.0655
DEBUG - 2022-06-21 07:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:43:58 --> Total execution time: 0.0746
DEBUG - 2022-06-21 07:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:15:45 --> No URI present. Default controller set.
DEBUG - 2022-06-21 07:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:45:45 --> Total execution time: 0.1445
DEBUG - 2022-06-21 07:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:45:50 --> Total execution time: 0.0496
DEBUG - 2022-06-21 07:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:46:16 --> Total execution time: 0.0604
DEBUG - 2022-06-21 07:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:46:28 --> Total execution time: 0.0533
DEBUG - 2022-06-21 07:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:46:32 --> Total execution time: 0.0552
DEBUG - 2022-06-21 07:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:16:53 --> No URI present. Default controller set.
DEBUG - 2022-06-21 07:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:46:53 --> Total execution time: 0.0324
DEBUG - 2022-06-21 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:47:01 --> Total execution time: 0.0584
DEBUG - 2022-06-21 07:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:47:06 --> Total execution time: 0.0467
DEBUG - 2022-06-21 07:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:47:15 --> Total execution time: 0.0523
DEBUG - 2022-06-21 07:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:47:15 --> Total execution time: 0.0480
DEBUG - 2022-06-21 07:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:47:47 --> Total execution time: 0.1149
DEBUG - 2022-06-21 07:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:47:54 --> Total execution time: 0.0493
DEBUG - 2022-06-21 07:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:48:02 --> Total execution time: 0.0496
DEBUG - 2022-06-21 07:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:48:02 --> Total execution time: 0.0739
DEBUG - 2022-06-21 07:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:49:11 --> Total execution time: 0.0499
DEBUG - 2022-06-21 07:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:19:30 --> No URI present. Default controller set.
DEBUG - 2022-06-21 07:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:49:30 --> Total execution time: 0.0445
DEBUG - 2022-06-21 07:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:19:31 --> No URI present. Default controller set.
DEBUG - 2022-06-21 07:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:49:31 --> Total execution time: 0.0496
DEBUG - 2022-06-21 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:49:56 --> Total execution time: 0.0291
DEBUG - 2022-06-21 07:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:50:04 --> Total execution time: 0.0484
DEBUG - 2022-06-21 07:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:50:18 --> Total execution time: 0.0585
DEBUG - 2022-06-21 07:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:50:21 --> Total execution time: 0.0489
DEBUG - 2022-06-21 07:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:51:28 --> Total execution time: 0.0442
DEBUG - 2022-06-21 07:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:51:30 --> Total execution time: 0.0324
DEBUG - 2022-06-21 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:51:54 --> Total execution time: 0.0781
DEBUG - 2022-06-21 07:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:52:02 --> Total execution time: 0.0649
DEBUG - 2022-06-21 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:52:10 --> Total execution time: 0.0485
DEBUG - 2022-06-21 07:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:52:21 --> Total execution time: 0.0747
DEBUG - 2022-06-21 07:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:54:49 --> Total execution time: 0.0603
DEBUG - 2022-06-21 07:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:56:16 --> Total execution time: 0.0470
DEBUG - 2022-06-21 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:57:34 --> Total execution time: 0.0537
DEBUG - 2022-06-21 07:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:57:50 --> Total execution time: 0.1152
DEBUG - 2022-06-21 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:58:26 --> Total execution time: 0.0662
DEBUG - 2022-06-21 07:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:58:27 --> Total execution time: 0.0824
DEBUG - 2022-06-21 07:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:58:46 --> Total execution time: 0.0528
DEBUG - 2022-06-21 07:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 07:29:06 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 07:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:59:09 --> Total execution time: 0.1003
DEBUG - 2022-06-21 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:00:00 --> Total execution time: 0.1008
DEBUG - 2022-06-21 07:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:00:32 --> Total execution time: 0.0619
DEBUG - 2022-06-21 07:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:00:43 --> Total execution time: 0.0593
DEBUG - 2022-06-21 07:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:00:57 --> Total execution time: 0.0564
DEBUG - 2022-06-21 07:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:02:12 --> Total execution time: 0.0372
DEBUG - 2022-06-21 07:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:02:23 --> Total execution time: 0.0503
DEBUG - 2022-06-21 07:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 07:32:24 --> 404 Page Not Found: Category/world
DEBUG - 2022-06-21 07:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:33:14 --> No URI present. Default controller set.
DEBUG - 2022-06-21 07:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:03:14 --> Total execution time: 0.0689
DEBUG - 2022-06-21 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:35:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 07:35:33 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 07:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:35:39 --> No URI present. Default controller set.
DEBUG - 2022-06-21 07:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:05:39 --> Total execution time: 0.0869
DEBUG - 2022-06-21 07:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 07:41:41 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 07:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:46:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 07:46:02 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 07:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:20:22 --> Total execution time: 0.0863
DEBUG - 2022-06-21 07:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 07:53:56 --> 404 Page Not Found: Category/news
DEBUG - 2022-06-21 07:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:55:11 --> No URI present. Default controller set.
DEBUG - 2022-06-21 07:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:25:11 --> Total execution time: 0.1201
DEBUG - 2022-06-21 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:25:13 --> Total execution time: 0.0426
DEBUG - 2022-06-21 07:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:25:14 --> Total execution time: 0.0406
DEBUG - 2022-06-21 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:57:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 07:57:12 --> 404 Page Not Found: News/feed
DEBUG - 2022-06-21 07:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 07:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 07:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 07:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:29:59 --> Total execution time: 0.0457
DEBUG - 2022-06-21 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:30:02 --> Total execution time: 0.0712
DEBUG - 2022-06-21 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:00:02 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:30:02 --> Total execution time: 0.0819
DEBUG - 2022-06-21 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:00:27 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:30:27 --> Total execution time: 0.0467
DEBUG - 2022-06-21 08:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:31:22 --> Total execution time: 0.0340
DEBUG - 2022-06-21 08:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:01:40 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:31:40 --> Total execution time: 0.0424
DEBUG - 2022-06-21 08:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:04:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:04:02 --> 404 Page Not Found: Appphp/feed
DEBUG - 2022-06-21 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:09:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:39:59 --> Total execution time: 0.1207
DEBUG - 2022-06-21 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:10:00 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:40:00 --> Total execution time: 0.0465
DEBUG - 2022-06-21 08:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:10:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:10:00 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 08:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:11:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:11:10 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 08:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:12:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:12:36 --> 404 Page Not Found: Blog/feed
DEBUG - 2022-06-21 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:13:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:13:42 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 08:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:15:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:15:53 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 08:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:16:55 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:46:55 --> Total execution time: 0.0925
DEBUG - 2022-06-21 08:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:51:54 --> Total execution time: 0.0507
DEBUG - 2022-06-21 08:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:22:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:52:42 --> Total execution time: 0.0516
DEBUG - 2022-06-21 08:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:22:43 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:52:43 --> Total execution time: 0.0367
DEBUG - 2022-06-21 08:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:57:26 --> Total execution time: 0.0627
DEBUG - 2022-06-21 08:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:30:08 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:00:08 --> Total execution time: 0.0589
DEBUG - 2022-06-21 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:00:58 --> Total execution time: 0.0637
DEBUG - 2022-06-21 08:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:10 --> Total execution time: 0.0678
DEBUG - 2022-06-21 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:13 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:13 --> Total execution time: 0.0424
DEBUG - 2022-06-21 08:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:14 --> Total execution time: 0.0491
DEBUG - 2022-06-21 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:21 --> Total execution time: 0.0307
DEBUG - 2022-06-21 08:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:26 --> Total execution time: 0.0699
DEBUG - 2022-06-21 08:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:32 --> Total execution time: 0.0804
DEBUG - 2022-06-21 08:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:40 --> Total execution time: 0.0558
DEBUG - 2022-06-21 08:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:42 --> Total execution time: 0.0307
DEBUG - 2022-06-21 08:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:43 --> Total execution time: 0.0779
DEBUG - 2022-06-21 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:47 --> Total execution time: 0.0459
DEBUG - 2022-06-21 08:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:52 --> Total execution time: 0.0511
DEBUG - 2022-06-21 08:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:52 --> Total execution time: 0.0464
DEBUG - 2022-06-21 08:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:54 --> Total execution time: 0.0506
DEBUG - 2022-06-21 08:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:59 --> Total execution time: 0.0485
DEBUG - 2022-06-21 08:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:05:59 --> Total execution time: 0.0674
DEBUG - 2022-06-21 08:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:06:01 --> Total execution time: 0.0671
DEBUG - 2022-06-21 08:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:06:01 --> Total execution time: 0.0753
DEBUG - 2022-06-21 08:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:06:32 --> Total execution time: 0.0446
DEBUG - 2022-06-21 08:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:07:00 --> Total execution time: 0.0408
DEBUG - 2022-06-21 08:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:07:06 --> Total execution time: 0.0551
DEBUG - 2022-06-21 08:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:07:26 --> Total execution time: 0.0456
DEBUG - 2022-06-21 08:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:07:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 08:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:07:27 --> Total execution time: 0.0468
DEBUG - 2022-06-21 08:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:08:02 --> Total execution time: 0.0579
DEBUG - 2022-06-21 08:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:08:09 --> Total execution time: 0.0418
DEBUG - 2022-06-21 08:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:08:11 --> Total execution time: 0.0471
DEBUG - 2022-06-21 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:08:46 --> Total execution time: 0.0474
DEBUG - 2022-06-21 08:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:08:55 --> Total execution time: 0.0507
DEBUG - 2022-06-21 08:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:08:57 --> Total execution time: 0.0481
DEBUG - 2022-06-21 08:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:08:59 --> Total execution time: 0.0483
DEBUG - 2022-06-21 08:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:09:10 --> Total execution time: 0.0496
DEBUG - 2022-06-21 08:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:09:11 --> Total execution time: 0.0527
DEBUG - 2022-06-21 08:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:39:19 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 08:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:40:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:10:24 --> Total execution time: 0.0410
DEBUG - 2022-06-21 08:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:40:47 --> Total execution time: 0.0529
DEBUG - 2022-06-21 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:10:53 --> Total execution time: 0.0609
DEBUG - 2022-06-21 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:11:01 --> Total execution time: 0.0516
DEBUG - 2022-06-21 08:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:41:37 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:11:37 --> Total execution time: 0.0364
DEBUG - 2022-06-21 08:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:11:44 --> Total execution time: 0.0296
DEBUG - 2022-06-21 08:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:11:44 --> Total execution time: 0.0459
DEBUG - 2022-06-21 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:11:48 --> Total execution time: 0.0457
DEBUG - 2022-06-21 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:11:52 --> Total execution time: 0.0545
DEBUG - 2022-06-21 08:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:12:02 --> Total execution time: 0.0658
DEBUG - 2022-06-21 08:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:12:06 --> Total execution time: 0.0546
DEBUG - 2022-06-21 08:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:43:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:13:11 --> Total execution time: 0.0329
DEBUG - 2022-06-21 08:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:13:57 --> Total execution time: 0.0509
DEBUG - 2022-06-21 08:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:13:59 --> Total execution time: 0.0618
DEBUG - 2022-06-21 08:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:44:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:44:03 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 08:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:14:04 --> Total execution time: 0.0480
DEBUG - 2022-06-21 08:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:44:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:44:06 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 08:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:44:11 --> Total execution time: 0.0510
DEBUG - 2022-06-21 08:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:44:13 --> Total execution time: 0.0660
DEBUG - 2022-06-21 08:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:44:13 --> Total execution time: 0.1187
DEBUG - 2022-06-21 08:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:14:23 --> Total execution time: 0.0420
DEBUG - 2022-06-21 08:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:45:11 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:15:11 --> Total execution time: 0.0562
DEBUG - 2022-06-21 08:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:45:16 --> Total execution time: 0.0520
DEBUG - 2022-06-21 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:45:17 --> Total execution time: 0.0494
DEBUG - 2022-06-21 08:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:45:17 --> Total execution time: 0.0739
DEBUG - 2022-06-21 08:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:46:08 --> Total execution time: 0.0477
DEBUG - 2022-06-21 08:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:46:10 --> Total execution time: 0.0485
DEBUG - 2022-06-21 08:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:46:10 --> Total execution time: 0.0878
DEBUG - 2022-06-21 08:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:46:31 --> Total execution time: 0.0644
DEBUG - 2022-06-21 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:46:35 --> Total execution time: 0.0577
DEBUG - 2022-06-21 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:46:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:16:41 --> Total execution time: 2.0256
DEBUG - 2022-06-21 08:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:46:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 08:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:16:51 --> Total execution time: 0.0622
DEBUG - 2022-06-21 08:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:17:55 --> Total execution time: 0.0447
DEBUG - 2022-06-21 08:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:18:13 --> Total execution time: 0.0699
DEBUG - 2022-06-21 08:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:18:21 --> Total execution time: 0.1015
DEBUG - 2022-06-21 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:48:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:18:24 --> Total execution time: 0.0344
DEBUG - 2022-06-21 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:48:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:18:24 --> Total execution time: 0.0264
DEBUG - 2022-06-21 08:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:49:00 --> Total execution time: 0.0306
DEBUG - 2022-06-21 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:49:02 --> Total execution time: 0.0668
DEBUG - 2022-06-21 08:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:49:02 --> Total execution time: 0.0836
DEBUG - 2022-06-21 08:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:19:29 --> Total execution time: 0.0879
DEBUG - 2022-06-21 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:19:32 --> Total execution time: 0.0552
DEBUG - 2022-06-21 08:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:49:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 08:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:34 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:19:34 --> Total execution time: 0.1255
DEBUG - 2022-06-21 08:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:19:36 --> Total execution time: 1.4890
DEBUG - 2022-06-21 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:49:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 08:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:51:46 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:21:46 --> Total execution time: 0.0829
DEBUG - 2022-06-21 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:22:39 --> Total execution time: 0.0444
DEBUG - 2022-06-21 08:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:52:47 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:22:47 --> Total execution time: 0.0939
DEBUG - 2022-06-21 08:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:53:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 08:53:07 --> 404 Page Not Found: Category/opinion
DEBUG - 2022-06-21 08:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:56:54 --> No URI present. Default controller set.
DEBUG - 2022-06-21 08:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:26:54 --> Total execution time: 0.1251
DEBUG - 2022-06-21 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:27:01 --> Total execution time: 0.0546
DEBUG - 2022-06-21 08:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 08:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:27:26 --> Total execution time: 0.0543
DEBUG - 2022-06-21 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:27:29 --> Total execution time: 0.1198
DEBUG - 2022-06-21 08:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:27:30 --> Total execution time: 0.0536
DEBUG - 2022-06-21 08:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:27:34 --> Total execution time: 0.0617
DEBUG - 2022-06-21 08:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:27:37 --> Total execution time: 0.0573
DEBUG - 2022-06-21 08:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:57:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:27:44 --> Total execution time: 0.0632
DEBUG - 2022-06-21 08:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:28:01 --> Total execution time: 0.0465
DEBUG - 2022-06-21 08:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 08:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 08:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:29:22 --> Total execution time: 0.0415
DEBUG - 2022-06-21 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:30:02 --> Total execution time: 0.0702
DEBUG - 2022-06-21 09:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 09:00:13 --> 404 Page Not Found: Category/lifestyle
DEBUG - 2022-06-21 09:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:30:51 --> Total execution time: 0.0683
DEBUG - 2022-06-21 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:30:54 --> Total execution time: 0.0760
DEBUG - 2022-06-21 09:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:30:58 --> Total execution time: 0.0419
DEBUG - 2022-06-21 09:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:03:09 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:33:09 --> Total execution time: 0.1059
DEBUG - 2022-06-21 09:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:33:18 --> Total execution time: 0.0340
DEBUG - 2022-06-21 09:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:33:22 --> Total execution time: 0.0409
DEBUG - 2022-06-21 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:33:30 --> Total execution time: 0.0453
DEBUG - 2022-06-21 09:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:33:47 --> Total execution time: 0.0556
DEBUG - 2022-06-21 09:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:01 --> Total execution time: 0.0820
DEBUG - 2022-06-21 09:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:12 --> Total execution time: 0.0490
DEBUG - 2022-06-21 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:15 --> Total execution time: 0.0475
DEBUG - 2022-06-21 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:25 --> Total execution time: 0.0431
DEBUG - 2022-06-21 09:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:28 --> Total execution time: 0.0627
DEBUG - 2022-06-21 09:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:40 --> Total execution time: 0.0563
DEBUG - 2022-06-21 09:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:40 --> Total execution time: 0.0732
DEBUG - 2022-06-21 09:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:50 --> Total execution time: 0.0587
DEBUG - 2022-06-21 09:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:34:58 --> Total execution time: 0.0503
DEBUG - 2022-06-21 09:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:35:02 --> Total execution time: 0.0656
DEBUG - 2022-06-21 09:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:05:09 --> Total execution time: 0.0710
DEBUG - 2022-06-21 09:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:35:13 --> Total execution time: 0.0950
DEBUG - 2022-06-21 09:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:35:15 --> Total execution time: 0.0425
DEBUG - 2022-06-21 09:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:35:18 --> Total execution time: 0.0473
DEBUG - 2022-06-21 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:35:21 --> Total execution time: 0.0492
DEBUG - 2022-06-21 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:35:28 --> Total execution time: 0.1318
DEBUG - 2022-06-21 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:35:33 --> Total execution time: 0.0870
DEBUG - 2022-06-21 09:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:08:57 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:38:57 --> Total execution time: 0.0978
DEBUG - 2022-06-21 09:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:08:57 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:38:57 --> Total execution time: 0.0444
DEBUG - 2022-06-21 09:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:09:30 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:39:30 --> Total execution time: 0.0354
DEBUG - 2022-06-21 09:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:39:35 --> Total execution time: 0.0319
DEBUG - 2022-06-21 09:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:39:42 --> Total execution time: 0.0401
DEBUG - 2022-06-21 09:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:39:57 --> Total execution time: 0.0523
DEBUG - 2022-06-21 09:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 09:10:00 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 09:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:02 --> Total execution time: 0.0641
DEBUG - 2022-06-21 09:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:07 --> Total execution time: 0.0452
DEBUG - 2022-06-21 09:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 09:10:08 --> 404 Page Not Found: Category/technology
DEBUG - 2022-06-21 09:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:08 --> Total execution time: 0.0492
DEBUG - 2022-06-21 09:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:21 --> Total execution time: 0.0492
DEBUG - 2022-06-21 09:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:26 --> Total execution time: 0.0658
DEBUG - 2022-06-21 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:28 --> Total execution time: 0.0748
DEBUG - 2022-06-21 09:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:30 --> Total execution time: 0.0432
DEBUG - 2022-06-21 09:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:38 --> Total execution time: 0.0586
DEBUG - 2022-06-21 09:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:43 --> Total execution time: 0.0454
DEBUG - 2022-06-21 09:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:10:49 --> Total execution time: 0.0341
DEBUG - 2022-06-21 09:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:10:52 --> Total execution time: 0.0445
DEBUG - 2022-06-21 09:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:10:52 --> Total execution time: 0.0485
DEBUG - 2022-06-21 09:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:55 --> Total execution time: 0.0624
DEBUG - 2022-06-21 09:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:40:58 --> Total execution time: 0.0440
DEBUG - 2022-06-21 09:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:41:00 --> Total execution time: 0.0821
DEBUG - 2022-06-21 09:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:01 --> Total execution time: 0.0810
DEBUG - 2022-06-21 09:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:03 --> Total execution time: 0.0628
DEBUG - 2022-06-21 09:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:03 --> Total execution time: 0.1145
DEBUG - 2022-06-21 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:41:05 --> Total execution time: 0.0476
DEBUG - 2022-06-21 09:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:08 --> Total execution time: 0.0460
DEBUG - 2022-06-21 09:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:41:08 --> Total execution time: 0.0621
DEBUG - 2022-06-21 09:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:41:11 --> Total execution time: 0.0394
DEBUG - 2022-06-21 09:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:41:14 --> Total execution time: 0.0408
DEBUG - 2022-06-21 09:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:41:17 --> Total execution time: 0.0486
DEBUG - 2022-06-21 09:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:29 --> Total execution time: 0.0297
DEBUG - 2022-06-21 09:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:34 --> Total execution time: 0.0443
DEBUG - 2022-06-21 09:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:34 --> Total execution time: 0.0882
DEBUG - 2022-06-21 09:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:41:51 --> Total execution time: 0.0621
DEBUG - 2022-06-21 09:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:12:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 09:12:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 09:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:42:11 --> Total execution time: 0.0450
DEBUG - 2022-06-21 09:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:12:34 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:42:34 --> Total execution time: 0.0467
DEBUG - 2022-06-21 09:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:42:37 --> Total execution time: 0.0443
DEBUG - 2022-06-21 09:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:12:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:42:58 --> Total execution time: 0.0531
DEBUG - 2022-06-21 09:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:13:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:43:12 --> Total execution time: 0.0452
DEBUG - 2022-06-21 09:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:43:30 --> Total execution time: 0.0891
DEBUG - 2022-06-21 09:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:43:54 --> Total execution time: 0.0676
DEBUG - 2022-06-21 09:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:44:05 --> Total execution time: 0.0458
DEBUG - 2022-06-21 09:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:44:46 --> Total execution time: 0.0593
DEBUG - 2022-06-21 09:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:45:09 --> Total execution time: 0.0414
DEBUG - 2022-06-21 09:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:45:23 --> Total execution time: 0.0554
DEBUG - 2022-06-21 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:45:28 --> Total execution time: 0.0536
DEBUG - 2022-06-21 09:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:46:08 --> Total execution time: 0.1399
DEBUG - 2022-06-21 09:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:46:32 --> Total execution time: 0.0669
DEBUG - 2022-06-21 09:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:46:52 --> Total execution time: 0.0860
DEBUG - 2022-06-21 09:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:47:18 --> Total execution time: 0.0457
DEBUG - 2022-06-21 09:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:48:23 --> Total execution time: 0.1121
DEBUG - 2022-06-21 09:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:48:30 --> Total execution time: 0.0796
DEBUG - 2022-06-21 09:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:48:45 --> Total execution time: 0.0715
DEBUG - 2022-06-21 09:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:20:01 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:50:01 --> Total execution time: 0.0422
DEBUG - 2022-06-21 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:50:20 --> Total execution time: 0.0295
DEBUG - 2022-06-21 09:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:50:31 --> Total execution time: 0.0422
DEBUG - 2022-06-21 09:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:22:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:52:24 --> Total execution time: 0.0524
DEBUG - 2022-06-21 09:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:22:47 --> Total execution time: 0.0580
DEBUG - 2022-06-21 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:22:49 --> Total execution time: 0.0477
DEBUG - 2022-06-21 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:22:49 --> Total execution time: 0.0581
DEBUG - 2022-06-21 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:24:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:54:56 --> Total execution time: 1.9157
DEBUG - 2022-06-21 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 09:24:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:55:00 --> Total execution time: 0.1142
DEBUG - 2022-06-21 09:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:55:08 --> Total execution time: 0.0433
DEBUG - 2022-06-21 09:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:55:23 --> Total execution time: 0.0870
DEBUG - 2022-06-21 09:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:25:30 --> Total execution time: 0.0743
DEBUG - 2022-06-21 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:25:57 --> Total execution time: 0.0416
DEBUG - 2022-06-21 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:56:08 --> Total execution time: 0.0598
DEBUG - 2022-06-21 09:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:56:11 --> Total execution time: 0.0863
DEBUG - 2022-06-21 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:56:12 --> Total execution time: 0.0762
DEBUG - 2022-06-21 09:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:56:16 --> Total execution time: 0.1107
DEBUG - 2022-06-21 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:56:59 --> Total execution time: 0.4263
DEBUG - 2022-06-21 09:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:57:16 --> Total execution time: 0.0678
DEBUG - 2022-06-21 09:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:57:20 --> Total execution time: 0.0475
DEBUG - 2022-06-21 09:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:57:21 --> Total execution time: 0.0456
DEBUG - 2022-06-21 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:57:28 --> Total execution time: 0.0442
DEBUG - 2022-06-21 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:57:30 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 09:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:57:30 --> Total execution time: 0.0700
DEBUG - 2022-06-21 09:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-06-21 19:57:31 --> Severity: Notice --> Trying to get property 'ul_login_status' of non-object /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-06-21 19:57:31 --> Total execution time: 0.0521
DEBUG - 2022-06-21 09:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:57:47 --> Total execution time: 0.0518
DEBUG - 2022-06-21 09:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:58:07 --> Total execution time: 0.0643
DEBUG - 2022-06-21 09:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:58:15 --> Total execution time: 0.0493
DEBUG - 2022-06-21 09:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:58:20 --> Total execution time: 0.0725
DEBUG - 2022-06-21 09:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:28:35 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:58:35 --> Total execution time: 0.0513
DEBUG - 2022-06-21 09:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:29:03 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:59:03 --> Total execution time: 0.0426
DEBUG - 2022-06-21 09:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:42:49 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:12:49 --> Total execution time: 0.1258
DEBUG - 2022-06-21 09:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:12:54 --> Total execution time: 0.0524
DEBUG - 2022-06-21 09:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:13:19 --> Total execution time: 0.0410
DEBUG - 2022-06-21 09:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:13:38 --> Total execution time: 0.0728
DEBUG - 2022-06-21 09:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:13:44 --> Total execution time: 0.0794
DEBUG - 2022-06-21 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:13:50 --> Total execution time: 0.0632
DEBUG - 2022-06-21 09:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:14:02 --> Total execution time: 0.1102
DEBUG - 2022-06-21 09:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:14:05 --> Total execution time: 0.0414
DEBUG - 2022-06-21 09:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:21:02 --> Total execution time: 0.0743
DEBUG - 2022-06-21 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:21:46 --> Total execution time: 0.0406
DEBUG - 2022-06-21 09:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:51:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 09:51:56 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:54:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 09:54:30 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 09:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:54:52 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:24:52 --> Total execution time: 0.0871
DEBUG - 2022-06-21 09:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:55:01 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:25:01 --> Total execution time: 0.1264
DEBUG - 2022-06-21 09:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 09:56:37 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 09:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:57:16 --> No URI present. Default controller set.
DEBUG - 2022-06-21 09:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:27:16 --> Total execution time: 0.0356
DEBUG - 2022-06-21 09:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:27:19 --> Total execution time: 0.0263
DEBUG - 2022-06-21 09:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:27:37 --> Total execution time: 0.0603
DEBUG - 2022-06-21 09:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:27:41 --> Total execution time: 0.0522
DEBUG - 2022-06-21 09:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:27:48 --> Total execution time: 0.0499
DEBUG - 2022-06-21 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:27:52 --> Total execution time: 0.0499
DEBUG - 2022-06-21 09:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:28:50 --> Total execution time: 0.1026
DEBUG - 2022-06-21 09:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:28:55 --> Total execution time: 0.0462
DEBUG - 2022-06-21 09:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:29:11 --> Total execution time: 0.0500
DEBUG - 2022-06-21 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:29:20 --> Total execution time: 0.0448
DEBUG - 2022-06-21 09:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:29:31 --> Total execution time: 0.0426
DEBUG - 2022-06-21 09:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:29:41 --> Total execution time: 0.0450
DEBUG - 2022-06-21 09:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 09:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 09:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:29:46 --> Total execution time: 0.0426
DEBUG - 2022-06-21 10:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:30:00 --> Total execution time: 0.0425
DEBUG - 2022-06-21 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:30:02 --> Total execution time: 0.0413
DEBUG - 2022-06-21 10:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:05:55 --> 404 Page Not Found: Category/features
DEBUG - 2022-06-21 10:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:36:14 --> Total execution time: 0.1462
DEBUG - 2022-06-21 10:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:36:16 --> Total execution time: 0.0485
DEBUG - 2022-06-21 10:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:36:22 --> Total execution time: 0.0422
DEBUG - 2022-06-21 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:12:52 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:42:52 --> Total execution time: 0.0892
DEBUG - 2022-06-21 10:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:43:19 --> Total execution time: 0.0426
DEBUG - 2022-06-21 10:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:13:19 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:43:19 --> Total execution time: 0.0409
DEBUG - 2022-06-21 10:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:15:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:15:08 --> 404 Page Not Found: Event/inspiration-memento-live-commission-art
DEBUG - 2022-06-21 10:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:48:16 --> Total execution time: 0.0981
DEBUG - 2022-06-21 10:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:18:25 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:48:25 --> Total execution time: 0.0466
DEBUG - 2022-06-21 10:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:48:26 --> Total execution time: 0.0417
DEBUG - 2022-06-21 10:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:19:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:49:22 --> Total execution time: 0.0328
DEBUG - 2022-06-21 10:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:19:53 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:49:53 --> Total execution time: 0.0359
DEBUG - 2022-06-21 10:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:20:01 --> Total execution time: 0.0999
DEBUG - 2022-06-21 10:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:20:07 --> Total execution time: 0.0442
DEBUG - 2022-06-21 10:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:20:08 --> Total execution time: 0.1203
DEBUG - 2022-06-21 10:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:20:15 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 10:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:53:36 --> Total execution time: 0.1790
DEBUG - 2022-06-21 10:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:53:44 --> Total execution time: 0.0822
DEBUG - 2022-06-21 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:53:52 --> Total execution time: 0.0455
DEBUG - 2022-06-21 10:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:25:06 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:55:06 --> Total execution time: 0.0417
DEBUG - 2022-06-21 10:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:25:19 --> Total execution time: 0.0485
DEBUG - 2022-06-21 10:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:25:24 --> Total execution time: 0.0480
DEBUG - 2022-06-21 10:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:25:24 --> Total execution time: 0.0566
DEBUG - 2022-06-21 10:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:56:10 --> Total execution time: 0.0325
DEBUG - 2022-06-21 10:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:26:29 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:56:29 --> Total execution time: 0.0431
DEBUG - 2022-06-21 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:28:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:58:22 --> Total execution time: 0.0328
DEBUG - 2022-06-21 10:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:28:39 --> Total execution time: 0.0438
DEBUG - 2022-06-21 10:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:30:11 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:11 --> Total execution time: 0.0499
DEBUG - 2022-06-21 10:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:30:24 --> Total execution time: 0.0413
DEBUG - 2022-06-21 10:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:30:37 --> Total execution time: 0.0419
DEBUG - 2022-06-21 10:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:30:37 --> Total execution time: 0.0901
DEBUG - 2022-06-21 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:30:53 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:53 --> Total execution time: 0.0374
DEBUG - 2022-06-21 10:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:31:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 10:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:57 --> Total execution time: 1.8863
DEBUG - 2022-06-21 10:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:32:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:32:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:25 --> Total execution time: 0.0486
DEBUG - 2022-06-21 10:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 10:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:51 --> Total execution time: 0.0464
DEBUG - 2022-06-21 10:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 21:03:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 21:03:53 --> Total execution time: 0.1830
DEBUG - 2022-06-21 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:56 --> Total execution time: 0.0551
DEBUG - 2022-06-21 10:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:00 --> Total execution time: 0.0737
DEBUG - 2022-06-21 10:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:05:29 --> Total execution time: 0.0469
DEBUG - 2022-06-21 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:05:36 --> Total execution time: 0.0576
DEBUG - 2022-06-21 10:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:05:39 --> Total execution time: 0.0713
DEBUG - 2022-06-21 10:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:06:14 --> Total execution time: 0.0448
DEBUG - 2022-06-21 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:06:20 --> Total execution time: 0.0477
DEBUG - 2022-06-21 10:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:37:52 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:07:52 --> Total execution time: 0.0493
DEBUG - 2022-06-21 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:09:18 --> Total execution time: 0.1062
DEBUG - 2022-06-21 10:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:41:36 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:11:36 --> Total execution time: 0.1037
DEBUG - 2022-06-21 10:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:11:37 --> Total execution time: 0.0403
DEBUG - 2022-06-21 10:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:11:39 --> Total execution time: 0.0400
DEBUG - 2022-06-21 10:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:43:03 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:13:03 --> Total execution time: 0.0341
DEBUG - 2022-06-21 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:43:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:13:04 --> Total execution time: 0.0314
DEBUG - 2022-06-21 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:13:09 --> Total execution time: 0.0335
DEBUG - 2022-06-21 10:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:13:31 --> Total execution time: 0.0877
DEBUG - 2022-06-21 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:13:44 --> Total execution time: 0.0516
DEBUG - 2022-06-21 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:13:54 --> Total execution time: 0.0858
DEBUG - 2022-06-21 10:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:14:04 --> Total execution time: 0.0651
DEBUG - 2022-06-21 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:14:09 --> Total execution time: 0.0667
DEBUG - 2022-06-21 10:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:14:34 --> Total execution time: 0.0505
DEBUG - 2022-06-21 10:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:15:21 --> Total execution time: 0.0338
DEBUG - 2022-06-21 10:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:15:31 --> Total execution time: 0.0475
DEBUG - 2022-06-21 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:15:41 --> Total execution time: 0.0709
DEBUG - 2022-06-21 10:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:46:45 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:16:46 --> Total execution time: 0.0326
DEBUG - 2022-06-21 10:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:46:46 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:16:46 --> Total execution time: 0.0490
DEBUG - 2022-06-21 10:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:46:59 --> Total execution time: 0.0349
DEBUG - 2022-06-21 10:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:17:00 --> Total execution time: 0.1053
DEBUG - 2022-06-21 10:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:47:00 --> Total execution time: 0.0556
DEBUG - 2022-06-21 10:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:47:01 --> Total execution time: 0.0828
DEBUG - 2022-06-21 10:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:17:06 --> Total execution time: 0.0402
DEBUG - 2022-06-21 10:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:17:11 --> Total execution time: 0.0521
DEBUG - 2022-06-21 10:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:17:16 --> Total execution time: 0.0642
DEBUG - 2022-06-21 10:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:17:33 --> Total execution time: 0.0724
DEBUG - 2022-06-21 10:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:36 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:17:36 --> Total execution time: 0.0272
DEBUG - 2022-06-21 10:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:47:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 10:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:17:40 --> Total execution time: 1.5543
DEBUG - 2022-06-21 10:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:47:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:47:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:17 --> Total execution time: 0.0451
DEBUG - 2022-06-21 10:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:29 --> Total execution time: 0.1281
DEBUG - 2022-06-21 10:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:32 --> Total execution time: 0.0456
DEBUG - 2022-06-21 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:34 --> Total execution time: 0.0581
DEBUG - 2022-06-21 10:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:34 --> Total execution time: 0.0624
DEBUG - 2022-06-21 10:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:37 --> Total execution time: 0.0552
DEBUG - 2022-06-21 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:41 --> Total execution time: 0.0536
DEBUG - 2022-06-21 10:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:42 --> Total execution time: 0.1001
DEBUG - 2022-06-21 10:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:46 --> Total execution time: 0.0548
DEBUG - 2022-06-21 10:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:51 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:51 --> Total execution time: 0.0483
DEBUG - 2022-06-21 10:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:55 --> Total execution time: 0.0535
DEBUG - 2022-06-21 10:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:48:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:58 --> Total execution time: 0.0468
DEBUG - 2022-06-21 10:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:01 --> Total execution time: 0.0693
DEBUG - 2022-06-21 10:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:49:02 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:02 --> Total execution time: 0.0524
DEBUG - 2022-06-21 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:06 --> Total execution time: 0.0802
DEBUG - 2022-06-21 10:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:11 --> Total execution time: 0.0442
DEBUG - 2022-06-21 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:18 --> Total execution time: 0.0605
DEBUG - 2022-06-21 10:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:21 --> Total execution time: 0.0441
DEBUG - 2022-06-21 10:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:25 --> Total execution time: 0.0487
DEBUG - 2022-06-21 10:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:50:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:50:35 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:50:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:50:39 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 10:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:43 --> Total execution time: 0.0319
DEBUG - 2022-06-21 10:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:50:52 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:52 --> Total execution time: 0.0363
DEBUG - 2022-06-21 10:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:54 --> Total execution time: 0.0431
DEBUG - 2022-06-21 10:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:21:00 --> Total execution time: 0.0512
DEBUG - 2022-06-21 10:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:21:03 --> Total execution time: 0.0437
DEBUG - 2022-06-21 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:21:12 --> Total execution time: 0.0474
DEBUG - 2022-06-21 10:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:22:09 --> Total execution time: 0.0457
DEBUG - 2022-06-21 10:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:55:32 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:25:32 --> Total execution time: 0.1133
DEBUG - 2022-06-21 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:26:41 --> Total execution time: 0.0428
DEBUG - 2022-06-21 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:56:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:26:42 --> Total execution time: 0.1017
DEBUG - 2022-06-21 10:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:26:52 --> Total execution time: 0.1326
DEBUG - 2022-06-21 10:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:26:53 --> Total execution time: 0.0535
DEBUG - 2022-06-21 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:26:57 --> Total execution time: 0.0786
DEBUG - 2022-06-21 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:26:58 --> Total execution time: 0.0843
DEBUG - 2022-06-21 10:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:57:06 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:57:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:57:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 10:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:19 --> Total execution time: 0.0482
DEBUG - 2022-06-21 10:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:29 --> Total execution time: 0.0645
DEBUG - 2022-06-21 10:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:57:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:57:41 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 10:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:57:52 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:52 --> Total execution time: 0.0600
DEBUG - 2022-06-21 10:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:57:52 --> 404 Page Not Found: Lessons/dow-theory-how-to-work-with-dow-theory
DEBUG - 2022-06-21 10:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:58:04 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 10:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:28:12 --> Total execution time: 0.0457
DEBUG - 2022-06-21 10:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:16 --> No URI present. Default controller set.
DEBUG - 2022-06-21 10:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:28:16 --> Total execution time: 0.0491
DEBUG - 2022-06-21 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 10:58:22 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:58:44 --> Total execution time: 0.0462
DEBUG - 2022-06-21 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:58:45 --> Total execution time: 0.0453
DEBUG - 2022-06-21 10:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:58:45 --> Total execution time: 0.0956
DEBUG - 2022-06-21 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:28:45 --> Total execution time: 0.0443
DEBUG - 2022-06-21 10:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:28:53 --> Total execution time: 0.1096
DEBUG - 2022-06-21 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 10:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 10:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 10:59:53 --> Total execution time: 0.0288
DEBUG - 2022-06-21 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:30:02 --> Total execution time: 0.0697
DEBUG - 2022-06-21 11:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:01:40 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:31:40 --> Total execution time: 0.0530
DEBUG - 2022-06-21 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:01:41 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:31:41 --> Total execution time: 0.0428
DEBUG - 2022-06-21 11:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:33:19 --> Total execution time: 0.0486
DEBUG - 2022-06-21 11:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:33:38 --> Total execution time: 0.0553
DEBUG - 2022-06-21 11:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:33:42 --> Total execution time: 0.0540
DEBUG - 2022-06-21 11:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:34:57 --> Total execution time: 0.1033
DEBUG - 2022-06-21 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:32 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:35:32 --> Total execution time: 0.0433
DEBUG - 2022-06-21 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:32 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:35:32 --> Total execution time: 0.0431
DEBUG - 2022-06-21 11:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:35:33 --> Total execution time: 0.0437
DEBUG - 2022-06-21 11:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:35:33 --> Total execution time: 0.0496
DEBUG - 2022-06-21 11:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:34 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:35:34 --> Total execution time: 0.0499
DEBUG - 2022-06-21 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:35:38 --> Total execution time: 0.0459
DEBUG - 2022-06-21 11:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:35:58 --> Total execution time: 0.0471
DEBUG - 2022-06-21 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:36:08 --> Total execution time: 0.0647
DEBUG - 2022-06-21 11:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 11:06:32 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 11:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:06:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 11:06:35 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 11:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:06:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:36:58 --> Total execution time: 0.0449
DEBUG - 2022-06-21 11:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:37:12 --> Total execution time: 0.0451
DEBUG - 2022-06-21 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:07:16 --> Total execution time: 0.0500
DEBUG - 2022-06-21 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:07:29 --> Total execution time: 0.0924
DEBUG - 2022-06-21 11:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:38:18 --> Total execution time: 0.0407
DEBUG - 2022-06-21 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:38:19 --> Total execution time: 0.0989
DEBUG - 2022-06-21 11:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:40:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:40:10 --> Total execution time: 0.0649
DEBUG - 2022-06-21 11:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:10:17 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:40:18 --> Total execution time: 0.0354
DEBUG - 2022-06-21 11:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:40:28 --> Total execution time: 0.0459
DEBUG - 2022-06-21 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:11:13 --> Total execution time: 0.0629
DEBUG - 2022-06-21 11:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:11:21 --> Total execution time: 0.0564
DEBUG - 2022-06-21 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:42:04 --> Total execution time: 0.0706
DEBUG - 2022-06-21 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:42:10 --> Total execution time: 0.0800
DEBUG - 2022-06-21 11:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:42:16 --> Total execution time: 0.0466
DEBUG - 2022-06-21 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:42:21 --> Total execution time: 0.0950
DEBUG - 2022-06-21 11:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:42:26 --> Total execution time: 0.0487
DEBUG - 2022-06-21 11:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:42:29 --> Total execution time: 0.0378
DEBUG - 2022-06-21 11:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:44:22 --> Total execution time: 0.0493
DEBUG - 2022-06-21 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:45:16 --> Total execution time: 0.0714
DEBUG - 2022-06-21 11:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:45:34 --> Total execution time: 0.0452
DEBUG - 2022-06-21 11:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:45:38 --> Total execution time: 0.0516
DEBUG - 2022-06-21 11:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:46:09 --> Total execution time: 0.0492
DEBUG - 2022-06-21 11:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:46:14 --> Total execution time: 0.0384
DEBUG - 2022-06-21 11:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:46:16 --> Total execution time: 0.0516
DEBUG - 2022-06-21 11:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:46:43 --> Total execution time: 0.0514
DEBUG - 2022-06-21 11:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:48:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:48:34 --> Total execution time: 0.0435
DEBUG - 2022-06-21 11:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:48:56 --> Total execution time: 0.0796
DEBUG - 2022-06-21 11:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:49:08 --> Total execution time: 0.0647
DEBUG - 2022-06-21 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:49:23 --> Total execution time: 0.0658
DEBUG - 2022-06-21 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:49:25 --> Total execution time: 0.0452
DEBUG - 2022-06-21 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:49:27 --> Total execution time: 0.0448
DEBUG - 2022-06-21 11:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:49:32 --> Total execution time: 0.0511
DEBUG - 2022-06-21 11:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:51:49 --> Total execution time: 0.0373
DEBUG - 2022-06-21 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:52:19 --> Total execution time: 0.0570
DEBUG - 2022-06-21 11:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:52:31 --> Total execution time: 0.1156
DEBUG - 2022-06-21 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:52:34 --> Total execution time: 0.0509
DEBUG - 2022-06-21 11:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:52:37 --> Total execution time: 0.0701
DEBUG - 2022-06-21 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:52:48 --> Total execution time: 0.0438
DEBUG - 2022-06-21 11:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:53:05 --> Total execution time: 0.0518
DEBUG - 2022-06-21 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:53:30 --> Total execution time: 0.0504
DEBUG - 2022-06-21 11:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:53:37 --> Total execution time: 0.0477
DEBUG - 2022-06-21 11:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:53:42 --> Total execution time: 0.0406
DEBUG - 2022-06-21 11:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:53:49 --> Total execution time: 0.0410
DEBUG - 2022-06-21 11:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:53:54 --> Total execution time: 0.0680
DEBUG - 2022-06-21 11:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:54:02 --> Total execution time: 0.0453
DEBUG - 2022-06-21 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:54:10 --> Total execution time: 0.0412
DEBUG - 2022-06-21 11:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:54:13 --> Total execution time: 0.0399
DEBUG - 2022-06-21 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:54:23 --> Total execution time: 0.0466
DEBUG - 2022-06-21 11:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:25:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:55:33 --> Total execution time: 0.0359
DEBUG - 2022-06-21 11:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 11:32:01 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:34:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 11:34:32 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 11:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:05:15 --> Total execution time: 0.1427
DEBUG - 2022-06-21 11:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:05:35 --> Total execution time: 0.0845
DEBUG - 2022-06-21 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:35:46 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:05:46 --> Total execution time: 0.1073
DEBUG - 2022-06-21 11:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:35:49 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:05:49 --> Total execution time: 0.0316
DEBUG - 2022-06-21 11:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:02 --> Total execution time: 0.1470
DEBUG - 2022-06-21 11:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:08 --> Total execution time: 0.0651
DEBUG - 2022-06-21 11:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:12 --> Total execution time: 0.0456
DEBUG - 2022-06-21 11:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:14 --> Total execution time: 0.0558
DEBUG - 2022-06-21 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:18 --> Total execution time: 0.0839
DEBUG - 2022-06-21 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:28 --> Total execution time: 0.0477
DEBUG - 2022-06-21 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 11:36:39 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 11:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:45 --> Total execution time: 0.0409
DEBUG - 2022-06-21 11:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:59 --> Total execution time: 0.0531
DEBUG - 2022-06-21 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:37:13 --> Total execution time: 0.0445
DEBUG - 2022-06-21 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:37:14 --> Total execution time: 0.0453
DEBUG - 2022-06-21 11:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:37:14 --> Total execution time: 0.0977
DEBUG - 2022-06-21 11:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:07:16 --> Total execution time: 0.0663
DEBUG - 2022-06-21 11:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:07:35 --> Total execution time: 0.0457
DEBUG - 2022-06-21 11:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:37 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:07:37 --> Total execution time: 0.0319
DEBUG - 2022-06-21 11:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:07:39 --> Total execution time: 0.1190
DEBUG - 2022-06-21 11:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:49 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:07:49 --> Total execution time: 0.0454
DEBUG - 2022-06-21 11:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:07:51 --> Total execution time: 0.0773
DEBUG - 2022-06-21 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:39:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:09:10 --> Total execution time: 1.9211
DEBUG - 2022-06-21 11:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:39:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 11:39:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 11:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:10:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 11:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:10:12 --> Total execution time: 0.0546
DEBUG - 2022-06-21 11:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:10:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 22:10:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 22:10:14 --> Total execution time: 0.1906
DEBUG - 2022-06-21 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:43:41 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:41 --> Total execution time: 0.1574
DEBUG - 2022-06-21 11:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:45 --> Total execution time: 0.0507
DEBUG - 2022-06-21 11:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:50 --> Total execution time: 0.0437
DEBUG - 2022-06-21 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:55 --> Total execution time: 0.0405
DEBUG - 2022-06-21 11:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:58 --> Total execution time: 0.0411
DEBUG - 2022-06-21 11:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:04 --> Total execution time: 0.0619
DEBUG - 2022-06-21 11:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:08 --> Total execution time: 0.0724
DEBUG - 2022-06-21 11:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:14 --> Total execution time: 0.0932
DEBUG - 2022-06-21 11:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:49:48 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:48 --> Total execution time: 0.0982
DEBUG - 2022-06-21 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:59 --> Total execution time: 0.0490
DEBUG - 2022-06-21 11:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:34 --> Total execution time: 0.1098
DEBUG - 2022-06-21 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:59 --> Total execution time: 0.0686
DEBUG - 2022-06-21 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:17 --> Total execution time: 0.0426
DEBUG - 2022-06-21 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:17 --> Total execution time: 0.0671
DEBUG - 2022-06-21 11:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:23 --> Total execution time: 0.0511
DEBUG - 2022-06-21 11:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:27 --> Total execution time: 0.0497
DEBUG - 2022-06-21 11:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:52:50 --> No URI present. Default controller set.
DEBUG - 2022-06-21 11:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:50 --> Total execution time: 0.0311
DEBUG - 2022-06-21 11:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:51 --> Total execution time: 0.0411
DEBUG - 2022-06-21 11:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:23:06 --> Total execution time: 0.0460
DEBUG - 2022-06-21 11:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:23:19 --> Total execution time: 0.0426
DEBUG - 2022-06-21 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:29 --> Total execution time: 0.0411
DEBUG - 2022-06-21 11:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:44 --> Total execution time: 0.0753
DEBUG - 2022-06-21 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:26:22 --> Total execution time: 0.1147
DEBUG - 2022-06-21 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:26:26 --> Total execution time: 0.0466
DEBUG - 2022-06-21 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 11:57:27 --> 404 Page Not Found: Cdn-cgi/l
DEBUG - 2022-06-21 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:29:06 --> Total execution time: 0.0784
DEBUG - 2022-06-21 11:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 11:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 11:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:29:09 --> Total execution time: 0.0423
DEBUG - 2022-06-21 11:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 11:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 11:59:58 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:30:03 --> Total execution time: 0.0553
DEBUG - 2022-06-21 12:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:19 --> Total execution time: 0.0474
DEBUG - 2022-06-21 12:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:21 --> Total execution time: 0.0422
DEBUG - 2022-06-21 12:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:32 --> Total execution time: 0.0479
DEBUG - 2022-06-21 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:38 --> Total execution time: 0.0806
DEBUG - 2022-06-21 12:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:47 --> Total execution time: 0.0460
DEBUG - 2022-06-21 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:53 --> Total execution time: 0.0562
DEBUG - 2022-06-21 12:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:56 --> Total execution time: 0.0600
DEBUG - 2022-06-21 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:36:08 --> Total execution time: 0.0520
DEBUG - 2022-06-21 12:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:36:08 --> Total execution time: 0.0570
DEBUG - 2022-06-21 12:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:36:18 --> Total execution time: 0.0435
DEBUG - 2022-06-21 12:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:36:48 --> Total execution time: 0.0426
DEBUG - 2022-06-21 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:37:05 --> Total execution time: 0.0801
DEBUG - 2022-06-21 12:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 12:14:45 --> 404 Page Not Found: Cart/index
DEBUG - 2022-06-21 12:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 12:14:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 12:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:37 --> Total execution time: 0.0818
DEBUG - 2022-06-21 12:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:39 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:39 --> Total execution time: 0.0518
DEBUG - 2022-06-21 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:43 --> Total execution time: 0.0421
DEBUG - 2022-06-21 12:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:50 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:50 --> Total execution time: 0.0317
DEBUG - 2022-06-21 12:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:52 --> Total execution time: 0.0298
DEBUG - 2022-06-21 12:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:53 --> Total execution time: 0.0505
DEBUG - 2022-06-21 12:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:59 --> Total execution time: 0.0502
DEBUG - 2022-06-21 12:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:46:04 --> Total execution time: 0.0573
DEBUG - 2022-06-21 12:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:46:06 --> Total execution time: 0.0691
DEBUG - 2022-06-21 12:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:46:12 --> Total execution time: 0.0963
DEBUG - 2022-06-21 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:50:03 --> Total execution time: 0.0456
DEBUG - 2022-06-21 12:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:24 --> Total execution time: 0.1009
DEBUG - 2022-06-21 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:29 --> Total execution time: 0.0628
DEBUG - 2022-06-21 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:23:00 --> Total execution time: 0.0840
DEBUG - 2022-06-21 12:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:23:12 --> Total execution time: 0.0639
DEBUG - 2022-06-21 12:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:53:59 --> Total execution time: 0.0468
DEBUG - 2022-06-21 12:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:57:06 --> Total execution time: 0.0526
DEBUG - 2022-06-21 12:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:57:26 --> Total execution time: 0.0571
DEBUG - 2022-06-21 12:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:58:46 --> Total execution time: 0.0487
DEBUG - 2022-06-21 12:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:58:53 --> Total execution time: 0.0445
DEBUG - 2022-06-21 12:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 12:28:55 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 12:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 12:28:57 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-21 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:32:41 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:02:41 --> Total execution time: 0.1178
DEBUG - 2022-06-21 12:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:34:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:04:33 --> Total execution time: 0.0399
DEBUG - 2022-06-21 12:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:04:37 --> Total execution time: 0.0339
DEBUG - 2022-06-21 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:04:48 --> Total execution time: 0.0509
DEBUG - 2022-06-21 12:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:04:51 --> Total execution time: 0.0481
DEBUG - 2022-06-21 12:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:04:57 --> Total execution time: 0.0581
DEBUG - 2022-06-21 12:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:05:05 --> Total execution time: 0.0414
DEBUG - 2022-06-21 12:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:05:56 --> Total execution time: 0.0774
DEBUG - 2022-06-21 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:05:59 --> Total execution time: 0.0737
DEBUG - 2022-06-21 12:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:06:03 --> Total execution time: 0.0533
DEBUG - 2022-06-21 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:06:08 --> Total execution time: 0.0405
DEBUG - 2022-06-21 12:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:07:27 --> Total execution time: 0.0592
DEBUG - 2022-06-21 12:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:07:35 --> Total execution time: 0.0479
DEBUG - 2022-06-21 12:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:07:43 --> Total execution time: 0.0497
DEBUG - 2022-06-21 12:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:37:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:07:44 --> Total execution time: 0.0553
DEBUG - 2022-06-21 12:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:07:46 --> Total execution time: 0.0418
DEBUG - 2022-06-21 12:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:07:48 --> Total execution time: 0.0458
DEBUG - 2022-06-21 12:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:07:52 --> Total execution time: 0.0477
DEBUG - 2022-06-21 12:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:07 --> Total execution time: 0.0441
DEBUG - 2022-06-21 12:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:24 --> Total execution time: 0.0463
DEBUG - 2022-06-21 12:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:29 --> Total execution time: 0.0562
DEBUG - 2022-06-21 12:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:36 --> Total execution time: 0.0419
DEBUG - 2022-06-21 12:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:43 --> Total execution time: 0.0406
DEBUG - 2022-06-21 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:52 --> Total execution time: 0.0465
DEBUG - 2022-06-21 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:55 --> Total execution time: 0.0980
DEBUG - 2022-06-21 12:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:56 --> Total execution time: 0.0344
DEBUG - 2022-06-21 12:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:09:30 --> Total execution time: 0.1048
DEBUG - 2022-06-21 12:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:09:54 --> Total execution time: 0.0785
DEBUG - 2022-06-21 12:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:09:58 --> Total execution time: 0.2170
DEBUG - 2022-06-21 12:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:10:10 --> Total execution time: 0.0568
DEBUG - 2022-06-21 12:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:10:28 --> Total execution time: 0.0573
DEBUG - 2022-06-21 12:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:10:38 --> Total execution time: 0.0785
DEBUG - 2022-06-21 12:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:10:43 --> Total execution time: 0.0648
DEBUG - 2022-06-21 12:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:10:46 --> Total execution time: 0.0553
DEBUG - 2022-06-21 12:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:10:50 --> Total execution time: 0.0411
DEBUG - 2022-06-21 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:11:30 --> Total execution time: 0.0472
DEBUG - 2022-06-21 12:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:11:33 --> Total execution time: 0.0645
DEBUG - 2022-06-21 12:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:11:36 --> Total execution time: 0.0449
DEBUG - 2022-06-21 12:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:11:40 --> Total execution time: 0.0471
DEBUG - 2022-06-21 12:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:11:46 --> Total execution time: 0.0574
DEBUG - 2022-06-21 12:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:11:49 --> Total execution time: 0.0540
DEBUG - 2022-06-21 12:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:12:27 --> Total execution time: 0.1441
DEBUG - 2022-06-21 12:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:15:06 --> Total execution time: 0.1679
DEBUG - 2022-06-21 12:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:46:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:16:42 --> Total execution time: 0.0369
DEBUG - 2022-06-21 12:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:46:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:16:42 --> Total execution time: 0.0332
DEBUG - 2022-06-21 12:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:16:47 --> Total execution time: 0.0307
DEBUG - 2022-06-21 12:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:17:00 --> Total execution time: 0.0659
DEBUG - 2022-06-21 12:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:17:12 --> Total execution time: 0.0655
DEBUG - 2022-06-21 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:17:28 --> Total execution time: 0.0473
DEBUG - 2022-06-21 12:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:17:31 --> Total execution time: 0.0699
DEBUG - 2022-06-21 12:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:47:47 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:17:47 --> Total execution time: 0.0374
DEBUG - 2022-06-21 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:48:06 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:18:06 --> Total execution time: 0.0438
DEBUG - 2022-06-21 12:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:48:45 --> Total execution time: 0.0549
DEBUG - 2022-06-21 12:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:48:47 --> Total execution time: 0.0471
DEBUG - 2022-06-21 12:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:48:47 --> Total execution time: 0.0982
DEBUG - 2022-06-21 12:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:19:23 --> Total execution time: 0.0777
DEBUG - 2022-06-21 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:19:26 --> Total execution time: 0.0467
DEBUG - 2022-06-21 12:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:19:29 --> Total execution time: 0.0506
DEBUG - 2022-06-21 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:20:01 --> Total execution time: 0.0991
DEBUG - 2022-06-21 12:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:21:06 --> Total execution time: 0.0425
DEBUG - 2022-06-21 12:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:21:20 --> Total execution time: 0.0403
DEBUG - 2022-06-21 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:51:31 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:21:31 --> Total execution time: 0.0433
DEBUG - 2022-06-21 12:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:21:40 --> Total execution time: 0.0466
DEBUG - 2022-06-21 12:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:21:51 --> Total execution time: 0.0419
DEBUG - 2022-06-21 12:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:22:05 --> Total execution time: 0.0479
DEBUG - 2022-06-21 12:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:22:13 --> Total execution time: 0.0492
DEBUG - 2022-06-21 12:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:52:15 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:22:15 --> Total execution time: 0.0557
DEBUG - 2022-06-21 12:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:22:49 --> Total execution time: 0.0513
DEBUG - 2022-06-21 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:22:57 --> Total execution time: 0.0556
DEBUG - 2022-06-21 12:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:23:32 --> Total execution time: 0.0476
DEBUG - 2022-06-21 12:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:23:45 --> Total execution time: 0.0606
DEBUG - 2022-06-21 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:11 --> Total execution time: 0.0294
DEBUG - 2022-06-21 12:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:55:40 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:40 --> Total execution time: 0.0993
DEBUG - 2022-06-21 12:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:55:57 --> Total execution time: 0.0545
DEBUG - 2022-06-21 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:55:59 --> Total execution time: 0.0441
DEBUG - 2022-06-21 12:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:55:59 --> Total execution time: 0.0409
DEBUG - 2022-06-21 12:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:57:15 --> No URI present. Default controller set.
DEBUG - 2022-06-21 12:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:27:15 --> Total execution time: 0.0376
DEBUG - 2022-06-21 12:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:27:20 --> Total execution time: 0.0287
DEBUG - 2022-06-21 12:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 12:59:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 12:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 12:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:29:18 --> Total execution time: 1.9057
DEBUG - 2022-06-21 12:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 12:59:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 12:59:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:30:03 --> Total execution time: 0.0662
DEBUG - 2022-06-21 13:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:30:15 --> Total execution time: 0.0402
DEBUG - 2022-06-21 13:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:30:57 --> Total execution time: 0.0507
DEBUG - 2022-06-21 13:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:00:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 13:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:30:59 --> Total execution time: 0.0317
DEBUG - 2022-06-21 13:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:01:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 13:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:04 --> Total execution time: 0.1011
DEBUG - 2022-06-21 13:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:01:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 13:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:12 --> Total execution time: 0.0457
DEBUG - 2022-06-21 23:31:13 --> Total execution time: 1.5580
DEBUG - 2022-06-21 13:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:22 --> Total execution time: 0.0956
DEBUG - 2022-06-21 13:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:30 --> Total execution time: 0.0636
DEBUG - 2022-06-21 13:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:44 --> Total execution time: 0.0703
DEBUG - 2022-06-21 13:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:32:52 --> Total execution time: 0.0430
DEBUG - 2022-06-21 13:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:07 --> Total execution time: 0.0407
DEBUG - 2022-06-21 13:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:04:42 --> Total execution time: 0.0487
DEBUG - 2022-06-21 13:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:34:48 --> Total execution time: 0.0454
DEBUG - 2022-06-21 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:17 --> Total execution time: 0.0480
DEBUG - 2022-06-21 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:07:56 --> No URI present. Default controller set.
DEBUG - 2022-06-21 13:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:56 --> Total execution time: 0.0975
DEBUG - 2022-06-21 13:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:09:50 --> No URI present. Default controller set.
DEBUG - 2022-06-21 13:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:39:50 --> Total execution time: 0.0352
DEBUG - 2022-06-21 13:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:39:53 --> Total execution time: 0.0552
DEBUG - 2022-06-21 13:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:40:14 --> Total execution time: 0.0470
DEBUG - 2022-06-21 13:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 13:10:15 --> 404 Page Not Found: Designer-bag-bingo-new-choices-fundraiser-2/esalestrix.in
DEBUG - 2022-06-21 13:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:10:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 13:10:21 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:40:23 --> Total execution time: 0.1027
DEBUG - 2022-06-21 13:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:40:34 --> Total execution time: 0.0558
DEBUG - 2022-06-21 13:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 13:12:52 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 13:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 13:15:01 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:45:50 --> Total execution time: 0.1865
DEBUG - 2022-06-21 13:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:20:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 13:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:50:22 --> Total execution time: 0.0883
DEBUG - 2022-06-21 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:50:23 --> Total execution time: 0.0422
DEBUG - 2022-06-21 13:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:50:25 --> Total execution time: 0.0399
DEBUG - 2022-06-21 13:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:20:36 --> No URI present. Default controller set.
DEBUG - 2022-06-21 13:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:50:36 --> Total execution time: 0.0369
DEBUG - 2022-06-21 13:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:49 --> Total execution time: 0.0467
DEBUG - 2022-06-21 13:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:56 --> Total execution time: 0.0588
DEBUG - 2022-06-21 13:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:02 --> Total execution time: 0.0513
DEBUG - 2022-06-21 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:05 --> Total execution time: 0.0841
DEBUG - 2022-06-21 13:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:11 --> Total execution time: 0.0508
DEBUG - 2022-06-21 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:20 --> Total execution time: 0.0944
DEBUG - 2022-06-21 13:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:49 --> Total execution time: 0.1278
DEBUG - 2022-06-21 13:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:57:49 --> Total execution time: 0.0457
DEBUG - 2022-06-21 13:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 13:38:10 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 13:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:54:26 --> Total execution time: 0.0433
DEBUG - 2022-06-21 13:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 13:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 13:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 13:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 14:03:28 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 14:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:03:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 14:03:37 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-06-21 14:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:04:46 --> No URI present. Default controller set.
DEBUG - 2022-06-21 14:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 14:05:42 --> 404 Page Not Found: Lessons/affiliate-marketing-introduction
DEBUG - 2022-06-21 14:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 14:17:56 --> 404 Page Not Found: Atime/index
DEBUG - 2022-06-21 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:32:13 --> No URI present. Default controller set.
DEBUG - 2022-06-21 14:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:48:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 14:48:15 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 14:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:50:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 14:50:43 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 14:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 14:52:49 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 14:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 14:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 14:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:11:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 15:11:10 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 15:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:11:13 --> No URI present. Default controller set.
DEBUG - 2022-06-21 15:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:11:14 --> No URI present. Default controller set.
DEBUG - 2022-06-21 15:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 15:11:15 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 15:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 15:11:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 15:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 15:15:25 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 15:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 15:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 15:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 15:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:02:13 --> No URI present. Default controller set.
DEBUG - 2022-06-21 16:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:03:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 16:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:06:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 16:06:07 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 16:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:06:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 16:06:31 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 16:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:06:36 --> No URI present. Default controller set.
DEBUG - 2022-06-21 16:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:52 --> Total execution time: 0.0429
DEBUG - 2022-06-21 16:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 16:25:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 16:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 16:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 16:27:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 16:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 16:29:47 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 16:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 16:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 16:52:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:39:08 --> No URI present. Default controller set.
DEBUG - 2022-06-21 17:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 17:42:58 --> 404 Page Not Found: Index3php/index
DEBUG - 2022-06-21 17:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 17:42:58 --> 404 Page Not Found: Index3php/index
DEBUG - 2022-06-21 17:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:47:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 17:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:53:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 17:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 17:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 17:53:29 --> No URI present. Default controller set.
DEBUG - 2022-06-21 17:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 17:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:01:31 --> No URI present. Default controller set.
DEBUG - 2022-06-21 18:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 18:01:32 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 18:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:02:50 --> No URI present. Default controller set.
DEBUG - 2022-06-21 18:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 18:03:58 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 18:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 18:06:08 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 18:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 18:17:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 18:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 18:17:55 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-06-21 18:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:17:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 18:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 18:28:40 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 18:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:41:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 18:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 18:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 18:44:25 --> No URI present. Default controller set.
DEBUG - 2022-06-21 18:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 18:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:19:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 19:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:23:56 --> No URI present. Default controller set.
DEBUG - 2022-06-21 19:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:35:13 --> No URI present. Default controller set.
DEBUG - 2022-06-21 19:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:37:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 19:37:43 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 19:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:40:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 19:40:10 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 19:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:42:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 19:42:09 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 19:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:50:03 --> No URI present. Default controller set.
DEBUG - 2022-06-21 19:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 19:50:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 19:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:50:11 --> No URI present. Default controller set.
DEBUG - 2022-06-21 19:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:54:23 --> No URI present. Default controller set.
DEBUG - 2022-06-21 19:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 19:54:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 19:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 19:54:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 19:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:54:30 --> No URI present. Default controller set.
DEBUG - 2022-06-21 19:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 19:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 19:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 19:58:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 19:58:18 --> 404 Page Not Found: Affiliate-tos-page-2/esalestrix.in
DEBUG - 2022-06-21 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:04:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 20:04:42 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 20:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:12:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 20:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:13:30 --> No URI present. Default controller set.
DEBUG - 2022-06-21 20:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:24:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 20:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:24:05 --> No URI present. Default controller set.
DEBUG - 2022-06-21 20:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:38:19 --> No URI present. Default controller set.
DEBUG - 2022-06-21 20:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:39:20 --> No URI present. Default controller set.
DEBUG - 2022-06-21 20:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:57:54 --> No URI present. Default controller set.
DEBUG - 2022-06-21 20:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:58:53 --> Total execution time: 0.0516
DEBUG - 2022-06-21 20:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:58:55 --> Total execution time: 0.0824
DEBUG - 2022-06-21 20:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:58:55 --> Total execution time: 0.1410
DEBUG - 2022-06-21 20:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:59:48 --> No URI present. Default controller set.
DEBUG - 2022-06-21 20:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 20:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 20:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 20:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 20:59:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 21:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:01 --> Total execution time: 0.0426
DEBUG - 2022-06-21 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:02 --> Total execution time: 0.1029
DEBUG - 2022-06-21 21:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:02 --> Total execution time: 0.1502
DEBUG - 2022-06-21 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:38 --> Total execution time: 0.0384
DEBUG - 2022-06-21 21:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:39 --> Total execution time: 0.0414
DEBUG - 2022-06-21 21:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:00:39 --> Total execution time: 0.0791
DEBUG - 2022-06-21 21:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:00 --> Total execution time: 0.0414
DEBUG - 2022-06-21 21:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:01 --> Total execution time: 0.1007
DEBUG - 2022-06-21 21:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:01 --> Total execution time: 0.1682
DEBUG - 2022-06-21 21:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:01 --> Total execution time: 0.1330
DEBUG - 2022-06-21 21:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:03 --> Total execution time: 0.0444
DEBUG - 2022-06-21 21:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:03 --> Total execution time: 0.0868
DEBUG - 2022-06-21 21:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 21:01:41 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-06-21 21:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:02:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:03:55 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:04 --> Total execution time: 0.0567
DEBUG - 2022-06-21 21:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:05 --> Total execution time: 0.0472
DEBUG - 2022-06-21 21:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:05 --> Total execution time: 0.0791
DEBUG - 2022-06-21 21:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:27 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:12:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 21:12:53 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 21:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 21:15:21 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:17:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 21:17:21 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 21:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:25:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:27:11 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:24 --> Total execution time: 0.0526
DEBUG - 2022-06-21 21:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:25 --> Total execution time: 0.0544
DEBUG - 2022-06-21 21:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:26 --> Total execution time: 0.1092
DEBUG - 2022-06-21 21:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:27:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 21:39:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 21:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:50:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 21:50:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 21:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:58:06 --> No URI present. Default controller set.
DEBUG - 2022-06-21 21:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 21:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 21:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 21:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:01:28 --> Total execution time: 0.0472
DEBUG - 2022-06-21 22:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:01:29 --> Total execution time: 0.0478
DEBUG - 2022-06-21 22:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:01:29 --> Total execution time: 0.1172
DEBUG - 2022-06-21 22:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:01:34 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:06:11 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:06:37 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:08:56 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:09:07 --> Total execution time: 0.0498
DEBUG - 2022-06-21 22:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:09:08 --> Total execution time: 0.0462
DEBUG - 2022-06-21 22:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:09:08 --> Total execution time: 0.0859
DEBUG - 2022-06-21 22:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:11:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:23 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:55 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:14:56 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:16:01 --> Total execution time: 0.0519
DEBUG - 2022-06-21 22:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:16:02 --> Total execution time: 0.0704
DEBUG - 2022-06-21 22:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:16:02 --> Total execution time: 0.1211
DEBUG - 2022-06-21 22:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:16:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:17:22 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-21 22:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:17:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:17:25 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-21 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:17:31 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-06-21 22:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:38 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:18:59 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:19:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:19:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 22:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:31 --> Total execution time: 0.0416
DEBUG - 2022-06-21 22:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:40:58 --> Total execution time: 0.0415
DEBUG - 2022-06-21 22:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:12 --> Total execution time: 0.0466
DEBUG - 2022-06-21 22:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:18 --> Total execution time: 0.0449
DEBUG - 2022-06-21 22:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:26 --> Total execution time: 0.0558
DEBUG - 2022-06-21 22:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:30 --> Total execution time: 0.0430
DEBUG - 2022-06-21 22:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:32 --> Total execution time: 0.0576
DEBUG - 2022-06-21 22:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:42:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:42:32 --> 404 Page Not Found: Lessons/when-dont-want-to-invest
DEBUG - 2022-06-21 22:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:45:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:45:13 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:45:22 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:45:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:36 --> Total execution time: 0.0404
DEBUG - 2022-06-21 22:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:47:41 --> 404 Page Not Found: Author/admin
DEBUG - 2022-06-21 22:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:49:55 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:49:56 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:50:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:50:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-06-21 22:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:51:14 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:51:15 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:51:50 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:51:51 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:56 --> Total execution time: 0.0810
DEBUG - 2022-06-21 22:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:58 --> Total execution time: 0.1252
DEBUG - 2022-06-21 22:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:51:58 --> Total execution time: 0.1903
DEBUG - 2022-06-21 22:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:52:02 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:52:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 22:52:03 --> 404 Page Not Found: Category/business
DEBUG - 2022-06-21 22:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:54:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 22:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:56:17 --> Total execution time: 0.0442
DEBUG - 2022-06-21 22:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:56:29 --> Total execution time: 0.0577
DEBUG - 2022-06-21 22:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:56:29 --> Total execution time: 0.1070
DEBUG - 2022-06-21 22:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 22:59:01 --> Total execution time: 0.0684
DEBUG - 2022-06-21 22:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 22:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 22:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:03:02 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 23:14:20 --> 404 Page Not Found: Feed/index
DEBUG - 2022-06-21 23:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:18:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:18:24 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:18:30 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:18:33 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 23:20:40 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-06-21 23:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:25:57 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:28:44 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:31:03 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:33:08 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:33:32 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:03 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:35:42 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:03 --> Total execution time: 0.0561
DEBUG - 2022-06-21 23:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:09 --> Total execution time: 0.0451
DEBUG - 2022-06-21 23:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:09 --> Total execution time: 0.0447
DEBUG - 2022-06-21 23:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:11 --> Total execution time: 0.0638
DEBUG - 2022-06-21 23:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:29 --> Total execution time: 0.0418
DEBUG - 2022-06-21 23:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 23:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 23:37:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 23:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:48 --> Total execution time: 0.0412
DEBUG - 2022-06-21 23:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:53 --> Total execution time: 0.0443
DEBUG - 2022-06-21 23:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:37:55 --> Total execution time: 0.0407
DEBUG - 2022-06-21 23:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:42:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:42:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:42:12 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:43:04 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:45:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 23:45:37 --> 404 Page Not Found: Membership-account/membership-checkout
DEBUG - 2022-06-21 23:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:07 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:26 --> Total execution time: 0.0528
DEBUG - 2022-06-21 23:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:28 --> Total execution time: 0.0455
DEBUG - 2022-06-21 23:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:28 --> Total execution time: 0.1081
DEBUG - 2022-06-21 23:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:29 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:31 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:52:28 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:52:29 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:05 --> Total execution time: 0.0497
DEBUG - 2022-06-21 23:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:14 --> Total execution time: 0.0643
DEBUG - 2022-06-21 23:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:14 --> Total execution time: 0.1048
DEBUG - 2022-06-21 23:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:19 --> Total execution time: 0.0843
DEBUG - 2022-06-21 23:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:25 --> Total execution time: 0.1419
DEBUG - 2022-06-21 23:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:25 --> Total execution time: 0.2170
DEBUG - 2022-06-21 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:49 --> Total execution time: 0.0607
DEBUG - 2022-06-21 23:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:51 --> Total execution time: 0.0519
DEBUG - 2022-06-21 23:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:51 --> Total execution time: 0.1010
DEBUG - 2022-06-21 23:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:19 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:30 --> Total execution time: 0.0924
DEBUG - 2022-06-21 23:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:31 --> Total execution time: 0.1230
DEBUG - 2022-06-21 23:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:31 --> Total execution time: 0.2519
DEBUG - 2022-06-21 23:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:34 --> Total execution time: 0.0882
DEBUG - 2022-06-21 23:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:35 --> Total execution time: 0.0694
DEBUG - 2022-06-21 23:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:35 --> Total execution time: 0.1461
DEBUG - 2022-06-21 23:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:50 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:51 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:51 --> Total execution time: 0.0500
DEBUG - 2022-06-21 23:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:53 --> Total execution time: 0.0708
DEBUG - 2022-06-21 23:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:55:53 --> Total execution time: 0.0913
DEBUG - 2022-06-21 23:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:55:57 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:06 --> Total execution time: 0.0446
DEBUG - 2022-06-21 23:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:10 --> Total execution time: 0.0863
DEBUG - 2022-06-21 23:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:10 --> Total execution time: 0.1174
DEBUG - 2022-06-21 23:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:10 --> Total execution time: 0.2069
DEBUG - 2022-06-21 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:12 --> Total execution time: 0.0900
DEBUG - 2022-06-21 23:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:12 --> Total execution time: 0.2129
DEBUG - 2022-06-21 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:39 --> Total execution time: 0.0508
DEBUG - 2022-06-21 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:41 --> Total execution time: 0.0771
DEBUG - 2022-06-21 23:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:56:41 --> Total execution time: 0.1088
DEBUG - 2022-06-21 23:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:57:10 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:58:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-06-21 23:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-21 23:58:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-21 23:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:58:58 --> No URI present. Default controller set.
DEBUG - 2022-06-21 23:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-06-21 23:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-21 23:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-21 23:59:58 --> Encryption: Auto-configured driver 'openssl'.
