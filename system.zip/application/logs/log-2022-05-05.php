<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-05 03:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 03:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:22:09 --> Total execution time: 0.1754
DEBUG - 2022-05-05 03:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 03:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:22:37 --> Total execution time: 0.0516
DEBUG - 2022-05-05 03:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:22:37 --> Total execution time: 0.0356
DEBUG - 2022-05-05 03:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 03:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:23:01 --> Total execution time: 0.9407
DEBUG - 2022-05-05 03:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:23:02 --> Total execution time: 0.0332
DEBUG - 2022-05-05 03:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 03:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:23:26 --> Total execution time: 0.0456
DEBUG - 2022-05-05 03:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:23:34 --> Total execution time: 0.0550
DEBUG - 2022-05-05 03:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 03:53:43 --> No URI present. Default controller set.
DEBUG - 2022-05-05 03:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 03:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:23:43 --> Total execution time: 0.0833
DEBUG - 2022-05-05 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 04:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 04:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 04:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 04:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:56:28 --> Total execution time: 0.0736
DEBUG - 2022-05-05 04:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 04:26:41 --> No URI present. Default controller set.
DEBUG - 2022-05-05 04:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 04:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:56:41 --> Total execution time: 0.0689
DEBUG - 2022-05-05 04:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 04:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 04:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:57:10 --> Total execution time: 0.0301
DEBUG - 2022-05-05 04:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 04:27:31 --> No URI present. Default controller set.
DEBUG - 2022-05-05 04:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 04:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 09:57:31 --> Total execution time: 0.0298
DEBUG - 2022-05-05 04:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 04:58:04 --> No URI present. Default controller set.
DEBUG - 2022-05-05 04:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 04:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:28:05 --> Total execution time: 0.8436
DEBUG - 2022-05-05 05:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:03:15 --> No URI present. Default controller set.
DEBUG - 2022-05-05 05:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:33:16 --> Total execution time: 0.8095
DEBUG - 2022-05-05 05:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:04:49 --> No URI present. Default controller set.
DEBUG - 2022-05-05 05:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:34:49 --> Total execution time: 0.0394
DEBUG - 2022-05-05 05:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:35:55 --> Total execution time: 0.0330
DEBUG - 2022-05-05 05:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 05:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:36:05 --> Total execution time: 0.0918
DEBUG - 2022-05-05 05:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:36:07 --> Total execution time: 0.0491
DEBUG - 2022-05-05 05:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:36:10 --> Total execution time: 0.0417
DEBUG - 2022-05-05 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:06:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:06:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:06:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:06:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:06:19 --> UTF-8 Support Enabled
ERROR - 2022-05-05 05:06:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:06:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:06:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:06:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-05 05:06:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:07:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:07:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:07:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:07:17 --> UTF-8 Support Enabled
ERROR - 2022-05-05 05:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:07:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:37:17 --> Total execution time: 0.0763
DEBUG - 2022-05-05 05:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:37:42 --> Total execution time: 0.0307
DEBUG - 2022-05-05 05:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 05:07:51 --> Total execution time: 0.1373
DEBUG - 2022-05-05 05:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 05:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:37:58 --> Total execution time: 0.1991
DEBUG - 2022-05-05 05:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:38:01 --> Total execution time: 0.0612
DEBUG - 2022-05-05 05:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:38:05 --> Total execution time: 0.0841
DEBUG - 2022-05-05 05:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 05:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:45:23 --> Total execution time: 0.0843
DEBUG - 2022-05-05 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:45:28 --> Total execution time: 0.1712
DEBUG - 2022-05-05 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:15:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:15:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-05 05:15:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:15:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:15:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-05 05:15:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:16:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 05:16:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 05:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 05:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 05:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 10:46:19 --> Total execution time: 0.0375
DEBUG - 2022-05-05 06:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:44:44 --> Total execution time: 0.0607
DEBUG - 2022-05-05 06:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:44:59 --> Total execution time: 0.0290
DEBUG - 2022-05-05 06:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:45:09 --> Total execution time: 0.0348
DEBUG - 2022-05-05 06:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:45:36 --> Total execution time: 0.0292
DEBUG - 2022-05-05 06:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:37 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:45:37 --> Total execution time: 0.0569
DEBUG - 2022-05-05 06:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:15:41 --> Total execution time: 0.0376
DEBUG - 2022-05-05 06:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:45:44 --> Total execution time: 0.0295
DEBUG - 2022-05-05 06:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:15:53 --> Total execution time: 0.0287
DEBUG - 2022-05-05 06:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:16:02 --> Total execution time: 0.0300
DEBUG - 2022-05-05 06:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:46:22 --> Total execution time: 0.0296
DEBUG - 2022-05-05 06:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 06:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:46:38 --> Total execution time: 0.0294
DEBUG - 2022-05-05 06:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:16:41 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:46:42 --> Total execution time: 0.0324
DEBUG - 2022-05-05 06:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:17:13 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:47:13 --> Total execution time: 0.0317
DEBUG - 2022-05-05 06:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:50:30 --> Total execution time: 0.0318
DEBUG - 2022-05-05 06:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:20:32 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:50:32 --> Total execution time: 0.0311
DEBUG - 2022-05-05 06:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:50:39 --> Total execution time: 0.0364
DEBUG - 2022-05-05 06:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:20:46 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:50:46 --> Total execution time: 0.0368
DEBUG - 2022-05-05 06:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:51:05 --> Total execution time: 0.2536
DEBUG - 2022-05-05 06:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:22:00 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:52:00 --> Total execution time: 0.0329
DEBUG - 2022-05-05 06:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:52:10 --> Total execution time: 0.0322
DEBUG - 2022-05-05 06:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:22:50 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:52:50 --> Total execution time: 0.0300
DEBUG - 2022-05-05 06:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:23:04 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:53:04 --> Total execution time: 0.0327
DEBUG - 2022-05-05 06:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:23:42 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 11:53:43 --> Total execution time: 0.0309
DEBUG - 2022-05-05 06:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:51:51 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 12:21:52 --> Total execution time: 1.2670
DEBUG - 2022-05-05 06:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 06:52:03 --> No URI present. Default controller set.
DEBUG - 2022-05-05 06:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 06:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 12:22:03 --> Total execution time: 0.0318
DEBUG - 2022-05-05 08:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 08:30:59 --> No URI present. Default controller set.
DEBUG - 2022-05-05 08:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 08:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 14:01:00 --> Total execution time: 1.1169
DEBUG - 2022-05-05 13:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:12:36 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:42:37 --> Total execution time: 1.2743
DEBUG - 2022-05-05 13:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:12:43 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:42:43 --> Total execution time: 0.0321
DEBUG - 2022-05-05 13:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:12:43 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:42:43 --> Total execution time: 0.0300
DEBUG - 2022-05-05 13:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:12:51 --> Total execution time: 0.0422
DEBUG - 2022-05-05 13:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:12:52 --> Total execution time: 0.0281
DEBUG - 2022-05-05 13:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:12:55 --> Total execution time: 0.0285
DEBUG - 2022-05-05 13:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:43:01 --> Total execution time: 0.1760
DEBUG - 2022-05-05 13:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:43:11 --> Total execution time: 0.0770
DEBUG - 2022-05-05 13:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:43:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-05 18:43:18 --> You did not select a file to upload.
DEBUG - 2022-05-05 18:43:18 --> You did not select a file to upload.
DEBUG - 2022-05-05 13:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:43:19 --> Total execution time: 0.0327
DEBUG - 2022-05-05 13:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:13:21 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:43:21 --> Total execution time: 0.0337
DEBUG - 2022-05-05 13:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:21:26 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:51:27 --> Total execution time: 0.8097
DEBUG - 2022-05-05 13:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:23:03 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:53:03 --> Total execution time: 0.0330
DEBUG - 2022-05-05 13:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:53:42 --> Total execution time: 0.1417
DEBUG - 2022-05-05 13:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:53:54 --> Total execution time: 0.0805
DEBUG - 2022-05-05 13:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:24:12 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:54:12 --> Total execution time: 0.0477
DEBUG - 2022-05-05 13:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:54:13 --> Total execution time: 0.0375
DEBUG - 2022-05-05 13:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:54:40 --> Total execution time: 0.0446
DEBUG - 2022-05-05 13:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:54:40 --> Total execution time: 0.0291
DEBUG - 2022-05-05 13:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:54:52 --> Total execution time: 0.0918
DEBUG - 2022-05-05 13:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:54:58 --> Total execution time: 0.0536
DEBUG - 2022-05-05 13:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:56:18 --> Total execution time: 0.0356
DEBUG - 2022-05-05 13:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:56:54 --> Total execution time: 0.0321
DEBUG - 2022-05-05 13:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-05 13:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-05 13:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:28:26 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 18:58:26 --> Total execution time: 0.0306
DEBUG - 2022-05-05 13:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:32:32 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:02:33 --> Total execution time: 0.8079
DEBUG - 2022-05-05 13:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:32:52 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:02:52 --> Total execution time: 0.0314
DEBUG - 2022-05-05 13:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:33:22 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:03:22 --> Total execution time: 0.0321
DEBUG - 2022-05-05 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:34:05 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:04:05 --> Total execution time: 0.0317
DEBUG - 2022-05-05 13:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:34:30 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:04:30 --> Total execution time: 0.0333
DEBUG - 2022-05-05 13:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:37:14 --> No URI present. Default controller set.
DEBUG - 2022-05-05 13:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:07:14 --> Total execution time: 0.0321
DEBUG - 2022-05-05 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:07:56 --> Total execution time: 0.0765
DEBUG - 2022-05-05 13:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:11:11 --> Total execution time: 0.0318
DEBUG - 2022-05-05 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 13:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:13:28 --> Total execution time: 0.0829
DEBUG - 2022-05-05 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 13:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 13:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 19:13:57 --> Total execution time: 0.0429
DEBUG - 2022-05-05 14:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 14:40:32 --> No URI present. Default controller set.
DEBUG - 2022-05-05 14:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 14:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:10:33 --> Total execution time: 0.9388
DEBUG - 2022-05-05 14:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 14:40:34 --> No URI present. Default controller set.
DEBUG - 2022-05-05 14:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 14:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:10:34 --> Total execution time: 0.0366
DEBUG - 2022-05-05 20:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:14:46 --> No URI present. Default controller set.
DEBUG - 2022-05-05 20:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-05 20:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-05 20:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-05 20:16:03 --> Encryption: Auto-configured driver 'openssl'.
