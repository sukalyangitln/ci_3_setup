<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-05 11:13:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 11:13:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:43:52 --> Total execution time: 1.4375
DEBUG - 2021-11-05 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:13:55 --> No URI present. Default controller set.
DEBUG - 2021-11-05 11:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:43:55 --> Total execution time: 0.0738
DEBUG - 2021-11-05 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:13:55 --> No URI present. Default controller set.
DEBUG - 2021-11-05 11:13:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 11:13:55 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-05 11:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:43:55 --> Total execution time: 0.0374
DEBUG - 2021-11-05 11:14:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 11:14:04 --> Total execution time: 0.1013
DEBUG - 2021-11-05 11:14:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 11:14:05 --> Total execution time: 0.0298
DEBUG - 2021-11-05 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:44:15 --> Total execution time: 0.1313
DEBUG - 2021-11-05 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:49:24 --> Total execution time: 0.1243
DEBUG - 2021-11-05 11:48:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:18:57 --> Total execution time: 0.0461
DEBUG - 2021-11-05 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 11:48:59 --> 404 Page Not Found: Admin-whatsapp-login/index
DEBUG - 2021-11-05 11:51:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 11:53:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:23:07 --> Total execution time: 0.0450
DEBUG - 2021-11-05 11:54:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 11:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 11:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:24:09 --> Total execution time: 0.0503
DEBUG - 2021-11-05 12:02:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:32:52 --> Total execution time: 0.0385
DEBUG - 2021-11-05 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:33:45 --> Total execution time: 0.0489
DEBUG - 2021-11-05 12:03:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:33:46 --> Total execution time: 0.0331
DEBUG - 2021-11-05 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:33:47 --> Total execution time: 0.0379
DEBUG - 2021-11-05 12:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:33:48 --> Total execution time: 0.0363
DEBUG - 2021-11-05 12:16:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:46:19 --> Total execution time: 0.0405
DEBUG - 2021-11-05 12:36:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:36:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:06:35 --> Severity: error --> Exception: Call to undefined method WhatsAppLogin_Controller::createInstant() /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 17
DEBUG - 2021-11-05 12:36:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:06:50 --> Total execution time: 1.0067
DEBUG - 2021-11-05 12:51:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:21:12 --> Total execution time: 0.5474
DEBUG - 2021-11-05 12:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 12:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 12:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 13:02:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 13:03:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:33:02 --> Total execution time: 0.0646
DEBUG - 2021-11-05 13:03:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:33:19 --> Total execution time: 0.0373
DEBUG - 2021-11-05 13:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:33:39 --> Total execution time: 0.0395
DEBUG - 2021-11-05 13:03:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:33:59 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:28:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:35 --> Severity: Notice --> Undefined variable: instance /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-whatsapp-login.php 70
ERROR - 2021-11-05 18:58:35 --> Severity: Notice --> Trying to get property 'admin_instant_id' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-whatsapp-login.php 70
ERROR - 2021-11-05 18:58:35 --> Severity: Notice --> Undefined variable: instance /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-whatsapp-login.php 71
ERROR - 2021-11-05 18:58:35 --> Severity: Notice --> Trying to get property 'admin_instant_qr_code' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-whatsapp-login.php 71
DEBUG - 2021-11-05 18:58:35 --> Total execution time: 0.0570
DEBUG - 2021-11-05 13:28:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:36 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:36 --> Total execution time: 0.3233
DEBUG - 2021-11-05 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:37 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:37 --> Total execution time: 0.0426
DEBUG - 2021-11-05 13:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:38 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:38 --> Total execution time: 0.0465
DEBUG - 2021-11-05 13:28:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:39 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:39 --> Total execution time: 0.0442
DEBUG - 2021-11-05 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:40 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:40 --> Total execution time: 0.0391
DEBUG - 2021-11-05 13:28:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:41 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:41 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:42 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:42 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:28:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:43 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:43 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:28:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:44 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:44 --> Total execution time: 0.0359
DEBUG - 2021-11-05 13:28:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:45 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:45 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:28:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:46 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:46 --> Total execution time: 0.0332
DEBUG - 2021-11-05 13:28:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:47 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:47 --> Total execution time: 0.0374
DEBUG - 2021-11-05 13:28:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:48 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:48 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:28:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:49 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:49 --> Total execution time: 0.0466
DEBUG - 2021-11-05 13:28:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:50 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:50 --> Total execution time: 0.0480
DEBUG - 2021-11-05 13:28:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:51 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:51 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:28:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:52 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:52 --> Total execution time: 0.0503
DEBUG - 2021-11-05 13:28:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:53 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:53 --> Total execution time: 0.0430
DEBUG - 2021-11-05 13:28:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:54 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:54 --> Total execution time: 0.0351
DEBUG - 2021-11-05 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:55 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:55 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:28:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:56 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:56 --> Total execution time: 0.0335
DEBUG - 2021-11-05 13:28:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:57 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:57 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:58 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:58 --> Total execution time: 0.0439
DEBUG - 2021-11-05 13:28:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:28:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:58:59 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:58:59 --> Total execution time: 0.0396
DEBUG - 2021-11-05 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:59:00 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:59:00 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:29:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:59:01 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:59:01 --> Total execution time: 0.0518
DEBUG - 2021-11-05 13:29:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:59:02 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:59:02 --> Total execution time: 0.0663
DEBUG - 2021-11-05 13:29:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:59:03 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:59:03 --> Total execution time: 0.0474
DEBUG - 2021-11-05 13:29:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:59:04 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:59:04 --> Total execution time: 0.0319
DEBUG - 2021-11-05 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 18:59:05 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 186
DEBUG - 2021-11-05 18:59:05 --> Total execution time: 0.0396
DEBUG - 2021-11-05 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:05 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:29:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:06 --> Total execution time: 0.0497
DEBUG - 2021-11-05 13:29:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:07 --> Total execution time: 0.0391
DEBUG - 2021-11-05 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:08 --> Total execution time: 0.0418
DEBUG - 2021-11-05 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:29:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:29:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:29:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:29:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:29:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:29:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:09 --> Total execution time: 0.0441
DEBUG - 2021-11-05 13:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:10 --> Total execution time: 0.0458
DEBUG - 2021-11-05 13:29:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:11 --> Total execution time: 0.0463
DEBUG - 2021-11-05 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:12 --> Total execution time: 0.0497
DEBUG - 2021-11-05 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:13 --> Total execution time: 0.0504
DEBUG - 2021-11-05 13:29:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:14 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:15 --> Total execution time: 0.0405
DEBUG - 2021-11-05 13:29:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:16 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:17 --> Total execution time: 0.0380
DEBUG - 2021-11-05 13:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:18 --> Total execution time: 0.0383
DEBUG - 2021-11-05 13:29:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:19 --> Total execution time: 0.0363
DEBUG - 2021-11-05 13:29:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:20 --> Total execution time: 0.0337
DEBUG - 2021-11-05 13:29:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:21 --> Total execution time: 0.0379
DEBUG - 2021-11-05 13:29:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:22 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:29:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:23 --> Total execution time: 0.0361
DEBUG - 2021-11-05 13:29:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:24 --> Total execution time: 0.0595
DEBUG - 2021-11-05 13:29:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:25 --> Total execution time: 0.0578
DEBUG - 2021-11-05 13:29:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:26 --> Total execution time: 0.0381
DEBUG - 2021-11-05 13:29:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:27 --> Total execution time: 0.0659
DEBUG - 2021-11-05 13:29:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:28 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:29:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:29 --> Total execution time: 0.0389
DEBUG - 2021-11-05 13:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:30 --> Total execution time: 0.0406
DEBUG - 2021-11-05 13:29:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:31 --> Total execution time: 0.0499
DEBUG - 2021-11-05 13:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:32 --> Total execution time: 0.0363
DEBUG - 2021-11-05 13:29:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:33 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:29:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:34 --> Total execution time: 0.0391
DEBUG - 2021-11-05 13:29:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:35 --> Total execution time: 0.0359
DEBUG - 2021-11-05 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:36 --> Total execution time: 0.0399
DEBUG - 2021-11-05 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:36 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:29:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:37 --> Total execution time: 0.0323
DEBUG - 2021-11-05 13:29:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:38 --> Total execution time: 0.0433
DEBUG - 2021-11-05 13:29:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:39 --> Total execution time: 0.0364
DEBUG - 2021-11-05 13:29:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:40 --> Total execution time: 0.0387
DEBUG - 2021-11-05 13:29:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:41 --> Total execution time: 0.0373
DEBUG - 2021-11-05 13:29:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:42 --> Total execution time: 0.0531
DEBUG - 2021-11-05 13:29:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:43 --> Total execution time: 0.0330
DEBUG - 2021-11-05 13:29:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:44 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:29:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:45 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:29:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:46 --> Total execution time: 0.0363
DEBUG - 2021-11-05 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:47 --> Total execution time: 0.0436
DEBUG - 2021-11-05 13:29:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:48 --> Total execution time: 0.0362
DEBUG - 2021-11-05 13:29:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:49 --> Total execution time: 0.0322
DEBUG - 2021-11-05 13:29:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:50 --> Total execution time: 0.0385
DEBUG - 2021-11-05 13:29:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:51 --> Total execution time: 0.0366
DEBUG - 2021-11-05 13:29:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:52 --> Total execution time: 0.0371
DEBUG - 2021-11-05 13:29:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:53 --> Total execution time: 0.0372
DEBUG - 2021-11-05 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:54 --> Total execution time: 0.0495
DEBUG - 2021-11-05 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:55 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:29:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:56 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:29:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:57 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:29:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:58 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:29:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 18:59:59 --> Total execution time: 0.0424
DEBUG - 2021-11-05 13:30:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:00 --> Total execution time: 0.0368
DEBUG - 2021-11-05 13:30:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:01 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:30:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:02 --> Total execution time: 0.1042
DEBUG - 2021-11-05 13:30:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:03 --> Total execution time: 0.0558
DEBUG - 2021-11-05 13:30:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:04 --> Total execution time: 0.0572
DEBUG - 2021-11-05 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:05 --> Total execution time: 0.0561
DEBUG - 2021-11-05 13:30:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:06 --> Total execution time: 0.0482
DEBUG - 2021-11-05 13:30:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:07 --> Total execution time: 0.0517
DEBUG - 2021-11-05 13:30:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:08 --> Total execution time: 0.0524
DEBUG - 2021-11-05 13:30:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:09 --> Total execution time: 0.0412
DEBUG - 2021-11-05 13:30:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:10 --> Total execution time: 0.0495
DEBUG - 2021-11-05 13:30:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:11 --> Total execution time: 0.0332
DEBUG - 2021-11-05 13:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:12 --> Total execution time: 0.0474
DEBUG - 2021-11-05 13:30:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:13 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:30:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:14 --> Total execution time: 0.0740
DEBUG - 2021-11-05 13:30:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:15 --> Total execution time: 0.0362
DEBUG - 2021-11-05 13:30:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:16 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:30:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:17 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:30:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:18 --> Total execution time: 0.0389
DEBUG - 2021-11-05 13:30:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:19 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:30:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:20 --> Total execution time: 0.0435
DEBUG - 2021-11-05 13:30:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:21 --> Total execution time: 0.0356
DEBUG - 2021-11-05 13:30:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:22 --> Total execution time: 0.0476
DEBUG - 2021-11-05 13:30:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:23 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:30:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:24 --> Total execution time: 0.0604
DEBUG - 2021-11-05 13:30:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:25 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:30:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:26 --> Total execution time: 0.0380
DEBUG - 2021-11-05 13:30:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:27 --> Total execution time: 0.0388
DEBUG - 2021-11-05 13:30:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:28 --> Total execution time: 0.0322
DEBUG - 2021-11-05 13:30:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:29 --> Total execution time: 0.0421
DEBUG - 2021-11-05 13:30:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:30 --> Total execution time: 0.0423
DEBUG - 2021-11-05 13:30:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:31 --> Total execution time: 0.0331
DEBUG - 2021-11-05 13:30:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:32 --> Total execution time: 0.3524
DEBUG - 2021-11-05 13:30:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:33 --> Total execution time: 0.0594
DEBUG - 2021-11-05 13:30:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:34 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:30:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:35 --> Total execution time: 0.0488
DEBUG - 2021-11-05 13:30:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:36 --> Total execution time: 0.0741
DEBUG - 2021-11-05 13:30:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:37 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:30:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:38 --> Total execution time: 0.0395
DEBUG - 2021-11-05 13:30:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:39 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:30:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:40 --> Total execution time: 0.0450
DEBUG - 2021-11-05 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:41 --> Total execution time: 0.0575
DEBUG - 2021-11-05 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:42 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:30:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:43 --> Total execution time: 0.0376
DEBUG - 2021-11-05 13:30:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:44 --> Total execution time: 0.0446
DEBUG - 2021-11-05 13:30:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:45 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:30:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:46 --> Total execution time: 0.0392
DEBUG - 2021-11-05 13:30:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:47 --> Total execution time: 0.0502
DEBUG - 2021-11-05 13:30:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:48 --> Total execution time: 0.0441
DEBUG - 2021-11-05 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:49 --> Total execution time: 0.0321
DEBUG - 2021-11-05 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:50 --> Total execution time: 0.0546
DEBUG - 2021-11-05 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:51 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:52 --> Total execution time: 0.0340
DEBUG - 2021-11-05 13:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:53 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:30:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:54 --> Total execution time: 0.0467
DEBUG - 2021-11-05 13:30:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:55 --> Total execution time: 0.0441
DEBUG - 2021-11-05 13:30:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:56 --> Total execution time: 0.0364
DEBUG - 2021-11-05 13:30:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:57 --> Total execution time: 0.0447
DEBUG - 2021-11-05 13:30:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:58 --> Total execution time: 0.0386
DEBUG - 2021-11-05 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:00:59 --> Total execution time: 0.0407
DEBUG - 2021-11-05 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:00 --> Total execution time: 0.0390
DEBUG - 2021-11-05 13:31:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:01 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:02 --> Total execution time: 0.0445
DEBUG - 2021-11-05 13:31:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:03 --> Total execution time: 0.0753
DEBUG - 2021-11-05 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:04 --> Total execution time: 0.0343
DEBUG - 2021-11-05 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:05 --> Total execution time: 0.0382
DEBUG - 2021-11-05 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:06 --> Total execution time: 0.0407
DEBUG - 2021-11-05 13:31:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:07 --> Total execution time: 0.0449
DEBUG - 2021-11-05 13:31:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:08 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:31:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:09 --> Total execution time: 0.0472
DEBUG - 2021-11-05 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:10 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:31:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:11 --> Total execution time: 0.0391
DEBUG - 2021-11-05 13:31:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:12 --> Total execution time: 0.0514
DEBUG - 2021-11-05 13:31:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:13 --> Total execution time: 0.0419
DEBUG - 2021-11-05 13:31:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:14 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:15 --> Total execution time: 0.0351
DEBUG - 2021-11-05 13:31:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:16 --> Total execution time: 0.0457
DEBUG - 2021-11-05 13:31:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:17 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:31:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:18 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:31:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:19 --> Total execution time: 0.0506
DEBUG - 2021-11-05 13:31:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:20 --> Total execution time: 0.0461
DEBUG - 2021-11-05 13:31:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:21 --> Total execution time: 0.0422
DEBUG - 2021-11-05 13:31:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:22 --> Total execution time: 0.0391
DEBUG - 2021-11-05 13:31:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:23 --> Total execution time: 0.0413
DEBUG - 2021-11-05 13:31:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:24 --> Total execution time: 0.0389
DEBUG - 2021-11-05 13:31:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:25 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:26 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:27 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:31:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:28 --> Total execution time: 0.0353
DEBUG - 2021-11-05 13:31:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:29 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:31:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:30 --> Total execution time: 0.0374
DEBUG - 2021-11-05 13:31:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:31 --> Total execution time: 0.0378
DEBUG - 2021-11-05 13:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:32 --> Total execution time: 0.0315
DEBUG - 2021-11-05 13:31:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:33 --> Total execution time: 0.0455
DEBUG - 2021-11-05 13:31:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:34 --> Total execution time: 0.0319
DEBUG - 2021-11-05 13:31:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:35 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:36 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:37 --> Total execution time: 0.0347
DEBUG - 2021-11-05 13:31:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:38 --> Total execution time: 0.0367
DEBUG - 2021-11-05 13:31:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:39 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:31:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:40 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:41 --> Total execution time: 0.0510
DEBUG - 2021-11-05 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:42 --> Total execution time: 0.0506
DEBUG - 2021-11-05 13:31:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:43 --> Total execution time: 0.0442
DEBUG - 2021-11-05 13:31:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:44 --> Total execution time: 0.0456
DEBUG - 2021-11-05 13:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:45 --> Total execution time: 0.0401
DEBUG - 2021-11-05 13:31:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:46 --> Total execution time: 0.0347
DEBUG - 2021-11-05 13:31:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:47 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:48 --> Total execution time: 0.0337
DEBUG - 2021-11-05 13:31:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:49 --> Total execution time: 0.0324
DEBUG - 2021-11-05 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:50 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:51 --> Total execution time: 0.0323
DEBUG - 2021-11-05 13:31:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:52 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:31:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:53 --> Total execution time: 0.0469
DEBUG - 2021-11-05 13:31:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:54 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:31:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:55 --> Total execution time: 0.0440
DEBUG - 2021-11-05 13:31:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:56 --> Total execution time: 0.0606
DEBUG - 2021-11-05 13:31:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:57 --> Total execution time: 0.0436
DEBUG - 2021-11-05 13:31:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:58 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:31:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:01:59 --> Total execution time: 0.0319
DEBUG - 2021-11-05 13:32:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:00 --> Total execution time: 0.0340
DEBUG - 2021-11-05 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:01 --> Total execution time: 0.0476
DEBUG - 2021-11-05 13:32:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:02 --> Total execution time: 0.0672
DEBUG - 2021-11-05 13:32:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:03 --> Total execution time: 0.0665
DEBUG - 2021-11-05 13:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:04 --> Total execution time: 0.0465
DEBUG - 2021-11-05 13:32:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:05 --> Total execution time: 0.0402
DEBUG - 2021-11-05 13:32:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:06 --> Total execution time: 0.0318
DEBUG - 2021-11-05 13:32:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:07 --> Total execution time: 0.0374
DEBUG - 2021-11-05 13:32:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:08 --> Total execution time: 0.0337
DEBUG - 2021-11-05 13:32:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:09 --> Total execution time: 0.0387
DEBUG - 2021-11-05 13:32:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:10 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:11 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:32:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:12 --> Total execution time: 0.0483
DEBUG - 2021-11-05 13:32:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:13 --> Total execution time: 0.0371
DEBUG - 2021-11-05 13:32:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:14 --> Total execution time: 0.0318
DEBUG - 2021-11-05 13:32:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:15 --> Total execution time: 0.0363
DEBUG - 2021-11-05 13:32:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:16 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:32:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:17 --> Total execution time: 0.0331
DEBUG - 2021-11-05 13:32:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:18 --> Total execution time: 0.0454
DEBUG - 2021-11-05 13:32:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:19 --> Total execution time: 0.0332
DEBUG - 2021-11-05 13:32:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:20 --> Total execution time: 0.0346
DEBUG - 2021-11-05 13:32:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:21 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:32:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:22 --> Total execution time: 0.0485
DEBUG - 2021-11-05 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:24 --> Total execution time: 0.4642
DEBUG - 2021-11-05 13:32:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:24 --> Total execution time: 0.0451
DEBUG - 2021-11-05 13:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:25 --> Total execution time: 0.0737
DEBUG - 2021-11-05 13:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:27 --> Total execution time: 0.0427
DEBUG - 2021-11-05 13:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:27 --> Total execution time: 0.0394
DEBUG - 2021-11-05 13:32:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:28 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:32:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:29 --> Total execution time: 0.0443
DEBUG - 2021-11-05 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:30 --> Total execution time: 0.0430
DEBUG - 2021-11-05 13:32:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:31 --> Total execution time: 0.0439
DEBUG - 2021-11-05 13:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:32 --> Total execution time: 0.0401
DEBUG - 2021-11-05 13:32:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:33 --> Total execution time: 0.0327
DEBUG - 2021-11-05 13:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:34 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:32:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:35 --> Total execution time: 0.0324
DEBUG - 2021-11-05 13:32:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:36 --> Total execution time: 0.0389
DEBUG - 2021-11-05 13:32:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:37 --> Total execution time: 0.0497
DEBUG - 2021-11-05 13:32:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:38 --> Total execution time: 0.0513
DEBUG - 2021-11-05 13:32:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:39 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:32:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:40 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:32:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:41 --> Total execution time: 0.0379
DEBUG - 2021-11-05 13:32:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:42 --> Total execution time: 0.0529
DEBUG - 2021-11-05 13:32:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:43 --> Total execution time: 0.0404
DEBUG - 2021-11-05 13:32:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:44 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:45 --> Total execution time: 0.0372
DEBUG - 2021-11-05 13:32:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:46 --> Total execution time: 0.0529
DEBUG - 2021-11-05 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:47 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:48 --> Total execution time: 0.0481
DEBUG - 2021-11-05 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:49 --> Total execution time: 0.0674
DEBUG - 2021-11-05 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:50 --> Total execution time: 0.0621
DEBUG - 2021-11-05 13:32:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:51 --> Total execution time: 0.0417
DEBUG - 2021-11-05 13:32:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:52 --> Total execution time: 0.0419
DEBUG - 2021-11-05 13:32:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:53 --> Total execution time: 0.0452
DEBUG - 2021-11-05 13:32:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:54 --> Total execution time: 0.0585
DEBUG - 2021-11-05 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:55 --> Total execution time: 0.0315
DEBUG - 2021-11-05 13:32:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:56 --> Total execution time: 0.0367
DEBUG - 2021-11-05 13:32:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:57 --> Total execution time: 0.0407
DEBUG - 2021-11-05 13:32:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:58 --> Total execution time: 0.0323
DEBUG - 2021-11-05 13:32:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:02:59 --> Total execution time: 0.0313
DEBUG - 2021-11-05 13:33:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:00 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:33:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:01 --> Total execution time: 0.0390
DEBUG - 2021-11-05 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:02 --> Total execution time: 0.0471
DEBUG - 2021-11-05 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:03 --> Total execution time: 0.0470
DEBUG - 2021-11-05 13:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:04 --> Total execution time: 0.0424
DEBUG - 2021-11-05 13:33:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:05 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:33:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:06 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:33:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:07 --> Total execution time: 0.0412
DEBUG - 2021-11-05 13:33:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:08 --> Total execution time: 0.0329
DEBUG - 2021-11-05 13:33:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:09 --> Total execution time: 0.0409
DEBUG - 2021-11-05 13:33:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:10 --> Total execution time: 0.0401
DEBUG - 2021-11-05 13:33:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:11 --> Total execution time: 0.0434
DEBUG - 2021-11-05 13:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:12 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:13 --> Total execution time: 0.0444
DEBUG - 2021-11-05 13:33:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:14 --> Total execution time: 0.0366
DEBUG - 2021-11-05 13:33:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:15 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:16 --> Total execution time: 0.0383
DEBUG - 2021-11-05 13:33:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:17 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:33:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:18 --> Total execution time: 0.0462
DEBUG - 2021-11-05 13:33:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:19 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:33:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:20 --> Total execution time: 0.0411
DEBUG - 2021-11-05 13:33:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:21 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:33:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:22 --> Total execution time: 0.0434
DEBUG - 2021-11-05 13:33:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:23 --> Total execution time: 0.0483
DEBUG - 2021-11-05 13:33:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:24 --> Total execution time: 0.0442
DEBUG - 2021-11-05 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:25 --> Total execution time: 0.0514
DEBUG - 2021-11-05 13:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:25 --> Total execution time: 0.0392
DEBUG - 2021-11-05 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:33:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:33:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:33:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:33:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:25 --> Total execution time: 0.0396
DEBUG - 2021-11-05 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:26 --> Total execution time: 0.0537
DEBUG - 2021-11-05 13:33:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:27 --> Total execution time: 0.0340
DEBUG - 2021-11-05 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:28 --> Total execution time: 0.0509
DEBUG - 2021-11-05 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:29 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:30 --> Total execution time: 0.0379
DEBUG - 2021-11-05 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:31 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:32 --> Total execution time: 0.0432
DEBUG - 2021-11-05 13:33:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:33 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:33:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:34 --> Total execution time: 0.0318
DEBUG - 2021-11-05 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:35 --> Total execution time: 0.0410
DEBUG - 2021-11-05 13:33:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:36 --> Total execution time: 0.0386
DEBUG - 2021-11-05 13:33:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:37 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:33:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:38 --> Total execution time: 0.0426
DEBUG - 2021-11-05 13:33:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:39 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:33:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:40 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:33:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:40 --> Total execution time: 0.0371
DEBUG - 2021-11-05 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:33:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:33:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:33:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 19:03:41 --> Total execution time: 0.0533
DEBUG - 2021-11-05 13:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:33:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:42 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:33:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:43 --> Total execution time: 0.0390
DEBUG - 2021-11-05 13:33:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:44 --> Total execution time: 0.0396
DEBUG - 2021-11-05 13:33:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:45 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:33:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:46 --> Total execution time: 0.0500
DEBUG - 2021-11-05 13:33:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:47 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:33:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:48 --> Total execution time: 0.0401
DEBUG - 2021-11-05 13:33:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:49 --> Total execution time: 0.0332
DEBUG - 2021-11-05 13:33:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:50 --> Total execution time: 0.0384
DEBUG - 2021-11-05 13:33:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:51 --> Total execution time: 0.0318
DEBUG - 2021-11-05 13:33:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:52 --> Total execution time: 0.0487
DEBUG - 2021-11-05 13:33:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:53 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:33:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:54 --> Total execution time: 0.0633
DEBUG - 2021-11-05 13:33:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:55 --> Total execution time: 0.0374
DEBUG - 2021-11-05 13:33:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:56 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:33:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:57 --> Total execution time: 0.0491
DEBUG - 2021-11-05 13:33:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:58 --> Total execution time: 0.0403
DEBUG - 2021-11-05 13:33:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:03:59 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:34:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:00 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:34:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:01 --> Total execution time: 0.0336
DEBUG - 2021-11-05 13:34:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:02 --> Total execution time: 0.0504
DEBUG - 2021-11-05 13:34:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:03 --> Total execution time: 0.0561
DEBUG - 2021-11-05 13:34:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:04 --> Total execution time: 0.0319
DEBUG - 2021-11-05 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:05 --> Total execution time: 0.0322
DEBUG - 2021-11-05 13:34:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:06 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:07 --> Total execution time: 0.0480
DEBUG - 2021-11-05 13:34:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:08 --> Total execution time: 0.0446
DEBUG - 2021-11-05 13:34:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:09 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:10 --> Total execution time: 0.0373
DEBUG - 2021-11-05 13:34:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:11 --> Total execution time: 0.0415
DEBUG - 2021-11-05 13:34:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:12 --> Total execution time: 0.0420
DEBUG - 2021-11-05 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:13 --> Total execution time: 0.0490
DEBUG - 2021-11-05 13:34:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:14 --> Total execution time: 0.0522
DEBUG - 2021-11-05 13:34:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:15 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:34:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:16 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:34:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:17 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:34:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:18 --> Total execution time: 0.0343
DEBUG - 2021-11-05 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:19 --> Total execution time: 0.0395
DEBUG - 2021-11-05 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:19 --> Total execution time: 0.0401
DEBUG - 2021-11-05 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:34:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:19 --> UTF-8 Support Enabled
ERROR - 2021-11-05 13:34:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:34:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:34:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:34:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:34:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:20 --> Total execution time: 0.0428
DEBUG - 2021-11-05 13:34:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:21 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:34:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:22 --> Total execution time: 0.0405
DEBUG - 2021-11-05 13:34:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:23 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:24 --> Total execution time: 0.0520
DEBUG - 2021-11-05 13:34:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:25 --> Total execution time: 0.0499
DEBUG - 2021-11-05 13:34:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:26 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:34:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:27 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:34:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:28 --> Total execution time: 0.0329
DEBUG - 2021-11-05 13:34:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:29 --> Total execution time: 0.0424
DEBUG - 2021-11-05 13:34:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:30 --> Total execution time: 0.0697
DEBUG - 2021-11-05 13:34:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:31 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:34:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:32 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:34:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:33 --> Total execution time: 0.0475
DEBUG - 2021-11-05 13:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:34 --> Total execution time: 0.0410
DEBUG - 2021-11-05 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:35 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:34:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:36 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:34:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:37 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:34:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:38 --> Total execution time: 0.0332
DEBUG - 2021-11-05 13:34:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:39 --> Total execution time: 0.0401
DEBUG - 2021-11-05 13:34:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:40 --> Total execution time: 0.0437
DEBUG - 2021-11-05 13:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:41 --> Total execution time: 0.0446
DEBUG - 2021-11-05 13:34:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:42 --> Total execution time: 0.0399
DEBUG - 2021-11-05 13:34:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:43 --> Total execution time: 0.0376
DEBUG - 2021-11-05 13:34:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:44 --> Total execution time: 0.0370
DEBUG - 2021-11-05 13:34:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:45 --> Total execution time: 0.0360
DEBUG - 2021-11-05 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:46 --> Total execution time: 0.0370
DEBUG - 2021-11-05 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:47 --> Total execution time: 0.0314
DEBUG - 2021-11-05 13:34:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:48 --> Total execution time: 0.0351
DEBUG - 2021-11-05 13:34:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:49 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:34:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:50 --> Total execution time: 0.0403
DEBUG - 2021-11-05 13:34:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:51 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:34:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:52 --> Total execution time: 0.0377
DEBUG - 2021-11-05 13:34:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:53 --> Total execution time: 0.0437
DEBUG - 2021-11-05 13:34:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:54 --> Total execution time: 0.0439
DEBUG - 2021-11-05 13:34:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:55 --> Total execution time: 0.0455
DEBUG - 2021-11-05 13:34:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:56 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:34:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:57 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:34:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:58 --> Total execution time: 0.0352
DEBUG - 2021-11-05 13:34:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:04:59 --> Total execution time: 0.0364
DEBUG - 2021-11-05 13:35:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:00 --> Total execution time: 0.0322
DEBUG - 2021-11-05 13:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:01 --> Total execution time: 0.2410
DEBUG - 2021-11-05 13:35:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:02 --> Total execution time: 0.0566
DEBUG - 2021-11-05 13:35:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:03 --> Total execution time: 0.0685
DEBUG - 2021-11-05 13:35:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:04 --> Total execution time: 0.0564
DEBUG - 2021-11-05 13:35:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:05 --> Total execution time: 0.0518
DEBUG - 2021-11-05 13:35:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:06 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:35:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:07 --> Total execution time: 0.0387
DEBUG - 2021-11-05 13:35:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:08 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:35:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:09 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:10 --> Total execution time: 0.0384
DEBUG - 2021-11-05 13:35:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:11 --> Total execution time: 0.0322
DEBUG - 2021-11-05 13:35:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:12 --> Total execution time: 0.0430
DEBUG - 2021-11-05 13:35:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:13 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:35:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:14 --> Total execution time: 0.0325
DEBUG - 2021-11-05 13:35:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:15 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:35:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:16 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:35:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:17 --> Total execution time: 0.0380
DEBUG - 2021-11-05 13:35:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:18 --> Total execution time: 0.0494
DEBUG - 2021-11-05 13:35:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:19 --> Total execution time: 0.0413
DEBUG - 2021-11-05 13:35:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:20 --> Total execution time: 0.0335
DEBUG - 2021-11-05 13:35:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:21 --> Total execution time: 0.0352
DEBUG - 2021-11-05 13:35:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:22 --> Total execution time: 0.0434
DEBUG - 2021-11-05 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:23 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:35:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:24 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:35:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:25 --> Total execution time: 0.0381
DEBUG - 2021-11-05 13:35:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:26 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:35:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:27 --> Total execution time: 0.0489
DEBUG - 2021-11-05 13:35:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:28 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:35:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:29 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:35:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:30 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:35:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:31 --> Total execution time: 0.0324
DEBUG - 2021-11-05 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:32 --> Total execution time: 0.0347
DEBUG - 2021-11-05 13:35:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:33 --> Total execution time: 0.0446
DEBUG - 2021-11-05 13:35:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:34 --> Total execution time: 0.0456
DEBUG - 2021-11-05 13:35:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:35 --> Total execution time: 0.0404
DEBUG - 2021-11-05 13:35:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:36 --> Total execution time: 0.0371
DEBUG - 2021-11-05 13:35:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:37 --> Total execution time: 0.0451
DEBUG - 2021-11-05 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:38 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:39 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:35:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:40 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:35:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:41 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:35:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:42 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:35:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:43 --> Total execution time: 0.0389
DEBUG - 2021-11-05 13:35:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:44 --> Total execution time: 0.0481
DEBUG - 2021-11-05 13:35:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:45 --> Total execution time: 0.0466
DEBUG - 2021-11-05 13:35:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:46 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:35:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:47 --> Total execution time: 0.0317
DEBUG - 2021-11-05 13:35:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:48 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:49 --> Total execution time: 0.0335
DEBUG - 2021-11-05 13:35:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:50 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:51 --> Total execution time: 0.0309
DEBUG - 2021-11-05 13:35:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:52 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:35:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:53 --> Total execution time: 0.0359
DEBUG - 2021-11-05 13:35:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:54 --> Total execution time: 0.0343
DEBUG - 2021-11-05 13:35:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:55 --> Total execution time: 0.0377
DEBUG - 2021-11-05 13:35:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:56 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:35:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:57 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:58 --> Total execution time: 0.0359
DEBUG - 2021-11-05 13:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:05:59 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:36:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:00 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:36:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:01 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:36:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:02 --> Total execution time: 0.0617
DEBUG - 2021-11-05 13:36:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:03 --> Total execution time: 0.0608
DEBUG - 2021-11-05 13:36:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:04 --> Total execution time: 0.0455
DEBUG - 2021-11-05 13:36:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:05 --> Total execution time: 0.0390
DEBUG - 2021-11-05 13:36:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:06 --> Total execution time: 0.0346
DEBUG - 2021-11-05 13:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:07 --> Total execution time: 0.0340
DEBUG - 2021-11-05 13:36:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:08 --> Total execution time: 0.0376
DEBUG - 2021-11-05 13:36:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:09 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:36:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:10 --> Total execution time: 0.0368
DEBUG - 2021-11-05 13:36:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:11 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:36:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:12 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:13 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:14 --> Total execution time: 0.0485
DEBUG - 2021-11-05 13:36:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:15 --> Total execution time: 0.0332
DEBUG - 2021-11-05 13:36:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:16 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:36:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:17 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:36:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:18 --> Total execution time: 0.0460
DEBUG - 2021-11-05 13:36:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:19 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:36:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:20 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:36:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:21 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:36:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:22 --> Total execution time: 0.0385
DEBUG - 2021-11-05 13:36:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:23 --> Total execution time: 0.0315
DEBUG - 2021-11-05 13:36:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:24 --> Total execution time: 0.0429
DEBUG - 2021-11-05 13:36:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:25 --> Total execution time: 0.0459
DEBUG - 2021-11-05 13:36:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:26 --> Total execution time: 0.0402
DEBUG - 2021-11-05 13:36:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:27 --> Total execution time: 0.0402
DEBUG - 2021-11-05 13:36:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:28 --> Total execution time: 0.0388
DEBUG - 2021-11-05 13:36:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:29 --> Total execution time: 0.0346
DEBUG - 2021-11-05 13:36:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:30 --> Total execution time: 0.0423
DEBUG - 2021-11-05 13:36:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:31 --> Total execution time: 0.0314
DEBUG - 2021-11-05 13:36:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:32 --> Total execution time: 0.0408
DEBUG - 2021-11-05 13:36:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:33 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:34 --> Total execution time: 0.0436
DEBUG - 2021-11-05 13:36:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:35 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:36 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:36:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:37 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:36:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:38 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:36:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:39 --> Total execution time: 0.0364
DEBUG - 2021-11-05 13:36:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:40 --> Total execution time: 0.0364
DEBUG - 2021-11-05 13:36:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:41 --> Total execution time: 0.0376
DEBUG - 2021-11-05 13:36:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:42 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:36:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:43 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:36:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:44 --> Total execution time: 0.0374
DEBUG - 2021-11-05 13:36:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:45 --> Total execution time: 0.0320
DEBUG - 2021-11-05 13:36:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:46 --> Total execution time: 0.0313
DEBUG - 2021-11-05 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:47 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:48 --> Total execution time: 0.0431
DEBUG - 2021-11-05 13:36:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:49 --> Total execution time: 0.0425
DEBUG - 2021-11-05 13:36:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:50 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:36:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:51 --> Total execution time: 0.0331
DEBUG - 2021-11-05 13:36:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:52 --> Total execution time: 0.0315
DEBUG - 2021-11-05 13:36:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:53 --> Total execution time: 0.0382
DEBUG - 2021-11-05 13:36:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:54 --> Total execution time: 0.0420
DEBUG - 2021-11-05 13:36:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:55 --> Total execution time: 0.0421
DEBUG - 2021-11-05 13:36:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:56 --> Total execution time: 0.0384
DEBUG - 2021-11-05 13:36:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:57 --> Total execution time: 0.0373
DEBUG - 2021-11-05 13:36:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:58 --> Total execution time: 0.0410
DEBUG - 2021-11-05 13:36:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:06:59 --> Total execution time: 0.0327
DEBUG - 2021-11-05 13:37:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:00 --> Total execution time: 0.0351
DEBUG - 2021-11-05 13:37:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:01 --> Total execution time: 0.0599
DEBUG - 2021-11-05 13:37:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:02 --> Total execution time: 0.0360
DEBUG - 2021-11-05 13:37:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:03 --> Total execution time: 0.0327
DEBUG - 2021-11-05 13:37:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:04 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:05 --> Total execution time: 0.0414
DEBUG - 2021-11-05 13:37:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:06 --> Total execution time: 0.0394
DEBUG - 2021-11-05 13:37:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:07 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:08 --> Total execution time: 0.0343
DEBUG - 2021-11-05 13:37:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:09 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:37:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:10 --> Total execution time: 0.0319
DEBUG - 2021-11-05 13:37:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:11 --> Total execution time: 0.0414
DEBUG - 2021-11-05 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:12 --> Total execution time: 0.0351
DEBUG - 2021-11-05 13:37:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:13 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:14 --> Total execution time: 0.0421
DEBUG - 2021-11-05 13:37:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:15 --> Total execution time: 0.0387
DEBUG - 2021-11-05 13:37:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:16 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:37:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:17 --> Total execution time: 0.0404
DEBUG - 2021-11-05 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:18 --> Total execution time: 0.0467
DEBUG - 2021-11-05 13:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:19 --> Total execution time: 0.0399
DEBUG - 2021-11-05 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:20 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:37:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:21 --> Total execution time: 0.0420
DEBUG - 2021-11-05 13:37:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:23 --> Total execution time: 0.8053
DEBUG - 2021-11-05 13:37:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:23 --> Total execution time: 0.0526
DEBUG - 2021-11-05 13:37:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:25 --> Total execution time: 0.7215
DEBUG - 2021-11-05 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:25 --> Total execution time: 0.0830
DEBUG - 2021-11-05 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:26 --> Total execution time: 0.0641
DEBUG - 2021-11-05 13:37:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:27 --> Total execution time: 0.0417
DEBUG - 2021-11-05 13:37:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:28 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:29 --> Total execution time: 0.0325
DEBUG - 2021-11-05 13:37:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:30 --> Total execution time: 0.0490
DEBUG - 2021-11-05 13:37:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:31 --> Total execution time: 0.0363
DEBUG - 2021-11-05 13:37:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:32 --> Total execution time: 0.0377
DEBUG - 2021-11-05 13:37:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:33 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:37:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:34 --> Total execution time: 0.0321
DEBUG - 2021-11-05 13:37:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:35 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:36 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:37:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:37 --> Total execution time: 0.0510
DEBUG - 2021-11-05 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:38 --> Total execution time: 0.0450
DEBUG - 2021-11-05 13:37:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:39 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:37:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:40 --> Total execution time: 0.0405
DEBUG - 2021-11-05 13:37:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:41 --> Total execution time: 0.0336
DEBUG - 2021-11-05 13:37:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:42 --> Total execution time: 0.0323
DEBUG - 2021-11-05 13:37:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:43 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:37:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:44 --> Total execution time: 0.0364
DEBUG - 2021-11-05 13:37:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:45 --> Total execution time: 0.0335
DEBUG - 2021-11-05 13:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:46 --> Total execution time: 0.0371
DEBUG - 2021-11-05 13:37:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:47 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:48 --> Total execution time: 0.0360
DEBUG - 2021-11-05 13:37:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:49 --> Total execution time: 0.0323
DEBUG - 2021-11-05 13:37:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:50 --> Total execution time: 0.0388
DEBUG - 2021-11-05 13:37:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:51 --> Total execution time: 0.0420
DEBUG - 2021-11-05 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:52 --> Total execution time: 0.0388
DEBUG - 2021-11-05 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:53 --> Total execution time: 0.0363
DEBUG - 2021-11-05 13:37:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:54 --> Total execution time: 0.0415
DEBUG - 2021-11-05 13:37:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:55 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:56 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:37:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:57 --> Total execution time: 0.0336
DEBUG - 2021-11-05 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:58 --> Total execution time: 0.0328
DEBUG - 2021-11-05 13:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:07:59 --> Total execution time: 0.0352
DEBUG - 2021-11-05 13:38:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:00 --> Total execution time: 0.0336
DEBUG - 2021-11-05 13:38:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:01 --> Total execution time: 0.0323
DEBUG - 2021-11-05 13:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:02 --> Total execution time: 0.0725
DEBUG - 2021-11-05 13:38:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:03 --> Total execution time: 0.0671
DEBUG - 2021-11-05 13:38:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:04 --> Total execution time: 0.0399
DEBUG - 2021-11-05 13:38:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:05 --> Total execution time: 0.0381
DEBUG - 2021-11-05 13:38:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:06 --> Total execution time: 0.0413
DEBUG - 2021-11-05 13:38:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:07 --> Total execution time: 0.0422
DEBUG - 2021-11-05 13:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:08 --> Total execution time: 0.0387
DEBUG - 2021-11-05 13:38:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:09 --> Total execution time: 0.0429
DEBUG - 2021-11-05 13:38:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:10 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:38:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:11 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:38:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:12 --> Total execution time: 0.0385
DEBUG - 2021-11-05 13:38:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:13 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:38:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:14 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:38:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:15 --> Total execution time: 0.0353
DEBUG - 2021-11-05 13:38:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:16 --> Total execution time: 0.0406
DEBUG - 2021-11-05 13:38:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:17 --> Total execution time: 0.0412
DEBUG - 2021-11-05 13:38:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:18 --> Total execution time: 0.0410
DEBUG - 2021-11-05 13:38:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:19 --> Total execution time: 0.0353
DEBUG - 2021-11-05 13:38:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:20 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:38:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:21 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:38:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:22 --> Total execution time: 0.0332
DEBUG - 2021-11-05 13:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:23 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:24 --> Total execution time: 0.0651
DEBUG - 2021-11-05 13:38:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:25 --> Total execution time: 0.0437
DEBUG - 2021-11-05 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:26 --> Total execution time: 0.0421
DEBUG - 2021-11-05 13:38:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:27 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:38:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:28 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:29 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:38:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:30 --> Total execution time: 0.0439
DEBUG - 2021-11-05 13:38:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:31 --> Total execution time: 0.0329
DEBUG - 2021-11-05 13:38:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:32 --> Total execution time: 0.0340
DEBUG - 2021-11-05 13:38:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:33 --> Total execution time: 0.0352
DEBUG - 2021-11-05 13:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:34 --> Total execution time: 0.0404
DEBUG - 2021-11-05 13:38:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:35 --> Total execution time: 0.0483
DEBUG - 2021-11-05 13:38:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:36 --> Total execution time: 0.0392
DEBUG - 2021-11-05 13:38:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:37 --> Total execution time: 0.0317
DEBUG - 2021-11-05 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:38 --> Total execution time: 0.0318
DEBUG - 2021-11-05 13:38:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:39 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:40 --> Total execution time: 0.0352
DEBUG - 2021-11-05 13:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:41 --> Total execution time: 0.0514
DEBUG - 2021-11-05 13:38:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:42 --> Total execution time: 0.0376
DEBUG - 2021-11-05 13:38:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:43 --> Total execution time: 0.0368
DEBUG - 2021-11-05 13:38:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:44 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:45 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:38:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:46 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:47 --> Total execution time: 0.0324
DEBUG - 2021-11-05 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:48 --> Total execution time: 0.0382
DEBUG - 2021-11-05 13:38:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:49 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:38:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:50 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:38:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:51 --> Total execution time: 0.0341
DEBUG - 2021-11-05 13:38:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:52 --> Total execution time: 0.0318
DEBUG - 2021-11-05 13:38:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:53 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:38:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:54 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:38:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:55 --> Total execution time: 0.0362
DEBUG - 2021-11-05 13:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:56 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:57 --> Total execution time: 0.0344
DEBUG - 2021-11-05 13:38:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:58 --> Total execution time: 0.0330
DEBUG - 2021-11-05 13:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:08:59 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:39:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:00 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:39:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:01 --> Total execution time: 0.0674
DEBUG - 2021-11-05 13:39:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:02 --> Total execution time: 0.0617
DEBUG - 2021-11-05 13:39:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:03 --> Total execution time: 0.0647
DEBUG - 2021-11-05 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:04 --> Total execution time: 0.0522
DEBUG - 2021-11-05 13:39:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:05 --> Total execution time: 0.0527
DEBUG - 2021-11-05 13:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:06 --> Total execution time: 0.0390
DEBUG - 2021-11-05 13:39:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:07 --> Total execution time: 0.0405
DEBUG - 2021-11-05 13:39:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:08 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:39:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:09 --> Total execution time: 0.0336
DEBUG - 2021-11-05 13:39:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:10 --> Total execution time: 0.0343
DEBUG - 2021-11-05 13:39:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:11 --> Total execution time: 0.0317
DEBUG - 2021-11-05 13:39:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:12 --> Total execution time: 0.0353
DEBUG - 2021-11-05 13:39:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:13 --> Total execution time: 0.0391
DEBUG - 2021-11-05 13:39:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:14 --> Total execution time: 0.0329
DEBUG - 2021-11-05 13:39:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:15 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:39:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:16 --> Total execution time: 0.0464
DEBUG - 2021-11-05 13:39:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:17 --> Total execution time: 0.0385
DEBUG - 2021-11-05 13:39:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:18 --> Total execution time: 0.0413
DEBUG - 2021-11-05 13:39:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:19 --> Total execution time: 0.0407
DEBUG - 2021-11-05 13:39:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:20 --> Total execution time: 0.0387
DEBUG - 2021-11-05 13:39:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:21 --> Total execution time: 0.0425
DEBUG - 2021-11-05 13:39:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:22 --> Total execution time: 0.0330
DEBUG - 2021-11-05 13:39:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:23 --> Total execution time: 0.0431
DEBUG - 2021-11-05 13:39:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:24 --> Total execution time: 0.0432
DEBUG - 2021-11-05 13:39:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:25 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:39:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:26 --> Total execution time: 0.0383
DEBUG - 2021-11-05 13:39:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:27 --> Total execution time: 0.0337
DEBUG - 2021-11-05 13:39:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:28 --> Total execution time: 0.0335
DEBUG - 2021-11-05 13:39:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:29 --> Total execution time: 0.0310
DEBUG - 2021-11-05 13:39:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:30 --> Total execution time: 0.0384
DEBUG - 2021-11-05 13:39:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:31 --> Total execution time: 0.0509
DEBUG - 2021-11-05 13:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:32 --> Total execution time: 0.0614
DEBUG - 2021-11-05 13:39:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:33 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:34 --> Total execution time: 0.0364
DEBUG - 2021-11-05 13:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:35 --> Total execution time: 0.0446
DEBUG - 2021-11-05 13:39:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:36 --> Total execution time: 0.0366
DEBUG - 2021-11-05 13:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:37 --> Total execution time: 0.0425
DEBUG - 2021-11-05 13:39:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:38 --> Total execution time: 0.0423
DEBUG - 2021-11-05 13:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:39 --> Total execution time: 0.0332
DEBUG - 2021-11-05 13:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:40 --> Total execution time: 0.0417
DEBUG - 2021-11-05 13:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:41 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:39:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:42 --> Total execution time: 0.0546
DEBUG - 2021-11-05 13:39:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:43 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:39:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:44 --> Total execution time: 0.0352
DEBUG - 2021-11-05 13:39:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:45 --> Total execution time: 0.0346
DEBUG - 2021-11-05 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:46 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:39:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:47 --> Total execution time: 0.0359
DEBUG - 2021-11-05 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:48 --> Total execution time: 0.0405
DEBUG - 2021-11-05 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:49 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:39:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:50 --> Total execution time: 0.0365
DEBUG - 2021-11-05 13:39:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:51 --> Total execution time: 0.0343
DEBUG - 2021-11-05 13:39:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:52 --> Total execution time: 0.0383
DEBUG - 2021-11-05 13:39:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:53 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:39:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:54 --> Total execution time: 0.0376
DEBUG - 2021-11-05 13:39:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:55 --> Total execution time: 0.0416
DEBUG - 2021-11-05 13:39:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:56 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:39:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:57 --> Total execution time: 0.0335
DEBUG - 2021-11-05 13:39:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:58 --> Total execution time: 0.0322
DEBUG - 2021-11-05 13:39:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:09:59 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:00 --> Total execution time: 0.0401
DEBUG - 2021-11-05 13:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:01 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:40:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:02 --> Total execution time: 0.0667
DEBUG - 2021-11-05 13:40:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:03 --> Total execution time: 0.0500
DEBUG - 2021-11-05 13:40:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:04 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:40:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:05 --> Total execution time: 0.0375
DEBUG - 2021-11-05 13:40:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:06 --> Total execution time: 0.0338
DEBUG - 2021-11-05 13:40:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:07 --> Total execution time: 0.0321
DEBUG - 2021-11-05 13:40:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:08 --> Total execution time: 0.0437
DEBUG - 2021-11-05 13:40:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:09 --> Total execution time: 0.0360
DEBUG - 2021-11-05 13:40:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:10 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:40:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:11 --> Total execution time: 0.0589
DEBUG - 2021-11-05 13:40:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:12 --> Total execution time: 0.0435
DEBUG - 2021-11-05 13:40:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:13 --> Total execution time: 0.0380
DEBUG - 2021-11-05 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:14 --> Total execution time: 0.0374
DEBUG - 2021-11-05 13:40:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:15 --> Total execution time: 0.0405
DEBUG - 2021-11-05 13:40:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:16 --> Total execution time: 0.0564
DEBUG - 2021-11-05 13:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:17 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:40:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:18 --> Total execution time: 0.0388
DEBUG - 2021-11-05 13:40:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:19 --> Total execution time: 0.0340
DEBUG - 2021-11-05 13:40:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:20 --> Total execution time: 0.0415
DEBUG - 2021-11-05 13:40:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:21 --> Total execution time: 0.0419
DEBUG - 2021-11-05 13:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:22 --> Total execution time: 0.0388
DEBUG - 2021-11-05 13:40:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:23 --> Total execution time: 0.0459
DEBUG - 2021-11-05 13:40:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:24 --> Total execution time: 0.0514
DEBUG - 2021-11-05 13:40:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:25 --> Total execution time: 0.0380
DEBUG - 2021-11-05 13:40:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:26 --> Total execution time: 0.0376
DEBUG - 2021-11-05 13:40:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:27 --> Total execution time: 0.0358
DEBUG - 2021-11-05 13:40:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:28 --> Total execution time: 0.0457
DEBUG - 2021-11-05 13:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:29 --> Total execution time: 0.0405
DEBUG - 2021-11-05 13:40:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:30 --> Total execution time: 0.0416
DEBUG - 2021-11-05 13:40:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:31 --> Total execution time: 0.0415
DEBUG - 2021-11-05 13:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:32 --> Total execution time: 0.0408
DEBUG - 2021-11-05 13:40:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:33 --> Total execution time: 0.0405
DEBUG - 2021-11-05 13:40:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:34 --> Total execution time: 0.0331
DEBUG - 2021-11-05 13:40:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:35 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:40:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:36 --> Total execution time: 0.0458
DEBUG - 2021-11-05 13:40:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:37 --> Total execution time: 0.0445
DEBUG - 2021-11-05 13:40:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:38 --> Total execution time: 0.0536
DEBUG - 2021-11-05 13:40:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:39 --> Total execution time: 0.0352
DEBUG - 2021-11-05 13:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:40 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:40:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:41 --> Total execution time: 0.0379
DEBUG - 2021-11-05 13:40:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:42 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:43 --> Total execution time: 0.0342
DEBUG - 2021-11-05 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:44 --> Total execution time: 0.0383
DEBUG - 2021-11-05 13:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:45 --> Total execution time: 0.0323
DEBUG - 2021-11-05 13:40:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:46 --> Total execution time: 0.0330
DEBUG - 2021-11-05 13:40:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:47 --> Total execution time: 0.1556
DEBUG - 2021-11-05 13:40:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:48 --> Total execution time: 0.0386
DEBUG - 2021-11-05 13:40:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:49 --> Total execution time: 0.0330
DEBUG - 2021-11-05 13:40:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:50 --> Total execution time: 0.0403
DEBUG - 2021-11-05 13:40:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:51 --> Total execution time: 0.0425
DEBUG - 2021-11-05 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:52 --> Total execution time: 0.0336
DEBUG - 2021-11-05 13:40:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:53 --> Total execution time: 0.0326
DEBUG - 2021-11-05 13:40:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:54 --> Total execution time: 0.0408
DEBUG - 2021-11-05 13:40:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:55 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:40:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:56 --> Total execution time: 0.0321
DEBUG - 2021-11-05 13:40:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:57 --> Total execution time: 0.0322
DEBUG - 2021-11-05 13:40:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:58 --> Total execution time: 0.0335
DEBUG - 2021-11-05 13:40:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:10:59 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:41:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:00 --> Total execution time: 0.0472
DEBUG - 2021-11-05 13:41:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:01 --> Total execution time: 0.0659
DEBUG - 2021-11-05 13:41:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:02 --> Total execution time: 0.0438
DEBUG - 2021-11-05 13:41:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:03 --> Total execution time: 0.0467
DEBUG - 2021-11-05 13:41:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:04 --> Total execution time: 0.0373
DEBUG - 2021-11-05 13:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:05 --> Total execution time: 0.0426
DEBUG - 2021-11-05 13:41:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:06 --> Total execution time: 0.0337
DEBUG - 2021-11-05 13:41:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:07 --> Total execution time: 0.0398
DEBUG - 2021-11-05 13:41:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:08 --> Total execution time: 0.0409
DEBUG - 2021-11-05 13:41:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:09 --> Total execution time: 0.0363
DEBUG - 2021-11-05 13:41:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:10 --> Total execution time: 0.0381
DEBUG - 2021-11-05 13:41:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:11 --> Total execution time: 0.0323
DEBUG - 2021-11-05 13:41:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:12 --> Total execution time: 0.0316
DEBUG - 2021-11-05 13:41:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:13 --> Total execution time: 0.0428
DEBUG - 2021-11-05 13:41:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:14 --> Total execution time: 0.0487
DEBUG - 2021-11-05 13:41:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:15 --> Total execution time: 0.0309
DEBUG - 2021-11-05 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:16 --> Total execution time: 0.0347
DEBUG - 2021-11-05 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:17 --> Total execution time: 0.0480
DEBUG - 2021-11-05 13:41:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:18 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:41:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:19 --> Total execution time: 0.0364
DEBUG - 2021-11-05 13:41:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:20 --> Total execution time: 0.0371
DEBUG - 2021-11-05 13:41:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:21 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:41:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:22 --> Total execution time: 0.0354
DEBUG - 2021-11-05 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:23 --> Total execution time: 0.0368
DEBUG - 2021-11-05 13:41:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:24 --> Total execution time: 0.0399
DEBUG - 2021-11-05 13:41:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:25 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:41:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:26 --> Total execution time: 0.0379
DEBUG - 2021-11-05 13:41:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:27 --> Total execution time: 0.0487
DEBUG - 2021-11-05 13:41:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:28 --> Total execution time: 0.0353
DEBUG - 2021-11-05 13:41:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:29 --> Total execution time: 0.0456
DEBUG - 2021-11-05 13:41:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:30 --> Total execution time: 0.0412
DEBUG - 2021-11-05 13:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:31 --> Total execution time: 0.0412
DEBUG - 2021-11-05 13:41:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:32 --> Total execution time: 0.0416
DEBUG - 2021-11-05 13:41:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:33 --> Total execution time: 0.0337
DEBUG - 2021-11-05 13:41:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:34 --> Total execution time: 0.0392
DEBUG - 2021-11-05 13:41:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:35 --> Total execution time: 0.0383
DEBUG - 2021-11-05 13:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:36 --> Total execution time: 0.0337
DEBUG - 2021-11-05 13:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:37 --> Total execution time: 0.0360
DEBUG - 2021-11-05 13:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:38 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:41:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:39 --> Total execution time: 0.0343
DEBUG - 2021-11-05 13:41:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:40 --> Total execution time: 0.0321
DEBUG - 2021-11-05 13:41:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:41 --> Total execution time: 0.0320
DEBUG - 2021-11-05 13:41:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:42 --> Total execution time: 0.0329
DEBUG - 2021-11-05 13:41:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:43 --> Total execution time: 0.0388
DEBUG - 2021-11-05 13:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:44 --> Total execution time: 0.0396
DEBUG - 2021-11-05 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:45 --> Total execution time: 0.0318
DEBUG - 2021-11-05 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:46 --> Total execution time: 0.0343
DEBUG - 2021-11-05 13:41:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:47 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:41:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:48 --> Total execution time: 0.0423
DEBUG - 2021-11-05 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:49 --> Total execution time: 0.0333
DEBUG - 2021-11-05 13:41:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:50 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:41:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:51 --> Total execution time: 0.0373
DEBUG - 2021-11-05 13:41:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:52 --> Total execution time: 0.0371
DEBUG - 2021-11-05 13:41:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:53 --> Total execution time: 0.0319
DEBUG - 2021-11-05 13:41:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:54 --> Total execution time: 0.0376
DEBUG - 2021-11-05 13:41:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:55 --> Total execution time: 0.0321
DEBUG - 2021-11-05 13:41:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:56 --> Total execution time: 0.0384
DEBUG - 2021-11-05 13:41:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:57 --> Total execution time: 0.0325
DEBUG - 2021-11-05 13:41:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:58 --> Total execution time: 0.0398
DEBUG - 2021-11-05 13:41:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:11:59 --> Total execution time: 0.0368
DEBUG - 2021-11-05 13:42:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:00 --> Total execution time: 0.0353
DEBUG - 2021-11-05 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:01 --> Total execution time: 0.0349
DEBUG - 2021-11-05 13:42:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:02 --> Total execution time: 0.0535
DEBUG - 2021-11-05 13:42:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:03 --> Total execution time: 0.0698
DEBUG - 2021-11-05 13:42:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:04 --> Total execution time: 0.0441
DEBUG - 2021-11-05 13:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:05 --> Total execution time: 0.0339
DEBUG - 2021-11-05 13:42:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:06 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:07 --> Total execution time: 0.0345
DEBUG - 2021-11-05 13:42:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:08 --> Total execution time: 0.0464
DEBUG - 2021-11-05 13:42:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:09 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:42:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:10 --> Total execution time: 0.0337
DEBUG - 2021-11-05 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:11 --> Total execution time: 0.0327
DEBUG - 2021-11-05 13:42:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:12 --> Total execution time: 0.0327
DEBUG - 2021-11-05 13:42:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:13 --> Total execution time: 0.0459
DEBUG - 2021-11-05 13:42:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:14 --> Total execution time: 0.0459
DEBUG - 2021-11-05 13:42:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:15 --> Total execution time: 0.0426
DEBUG - 2021-11-05 13:42:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:16 --> Total execution time: 0.0380
DEBUG - 2021-11-05 13:42:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:17 --> Total execution time: 0.0423
DEBUG - 2021-11-05 13:42:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:18 --> Total execution time: 0.0775
DEBUG - 2021-11-05 13:42:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:20 --> Total execution time: 0.6007
DEBUG - 2021-11-05 13:42:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:20 --> Total execution time: 0.0633
DEBUG - 2021-11-05 13:42:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:21 --> Total execution time: 0.0370
DEBUG - 2021-11-05 13:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:22 --> Total execution time: 0.0398
DEBUG - 2021-11-05 13:42:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:23 --> Total execution time: 0.0400
DEBUG - 2021-11-05 13:42:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:24 --> Total execution time: 0.0394
DEBUG - 2021-11-05 13:42:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:25 --> Total execution time: 0.0357
DEBUG - 2021-11-05 13:42:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:26 --> Total execution time: 0.0369
DEBUG - 2021-11-05 13:42:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:27 --> Total execution time: 0.0553
DEBUG - 2021-11-05 13:42:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:28 --> Total execution time: 0.0334
DEBUG - 2021-11-05 13:42:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:29 --> Total execution time: 0.0447
DEBUG - 2021-11-05 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:30 --> Total execution time: 0.0471
DEBUG - 2021-11-05 13:42:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:31 --> Total execution time: 0.0424
DEBUG - 2021-11-05 13:42:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:32 --> Total execution time: 0.0335
DEBUG - 2021-11-05 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:33 --> Total execution time: 0.0788
DEBUG - 2021-11-05 13:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:34 --> Total execution time: 0.0347
DEBUG - 2021-11-05 13:42:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:35 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:42:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:36 --> Total execution time: 0.0355
DEBUG - 2021-11-05 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:37 --> Total execution time: 0.0397
DEBUG - 2021-11-05 13:42:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:38 --> Total execution time: 0.0360
DEBUG - 2021-11-05 13:42:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:39 --> Total execution time: 0.0348
DEBUG - 2021-11-05 13:42:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:40 --> Total execution time: 0.0393
DEBUG - 2021-11-05 13:42:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:41 --> Total execution time: 0.0408
DEBUG - 2021-11-05 13:42:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:42 --> Total execution time: 0.0401
DEBUG - 2021-11-05 13:42:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:43 --> Total execution time: 0.0451
DEBUG - 2021-11-05 13:42:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:44 --> Total execution time: 0.0421
DEBUG - 2021-11-05 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:45 --> Total execution time: 0.0312
DEBUG - 2021-11-05 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 13:42:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:12:45 --> Total execution time: 0.0275
DEBUG - 2021-11-05 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:45:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 19:15:53 --> Severity: Notice --> Undefined variable: instant /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 199
DEBUG - 2021-11-05 19:15:53 --> Total execution time: 0.0425
DEBUG - 2021-11-05 13:46:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:16:03 --> Total execution time: 0.0515
DEBUG - 2021-11-05 13:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:19:11 --> Total execution time: 0.0454
DEBUG - 2021-11-05 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:49:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:49:16 --> UTF-8 Support Enabled
ERROR - 2021-11-05 13:49:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:49:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 13:49:16 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-05 13:49:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 13:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:22:36 --> Total execution time: 0.0352
DEBUG - 2021-11-05 13:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:22:38 --> Total execution time: 0.0390
DEBUG - 2021-11-05 13:54:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:24:32 --> Total execution time: 0.0446
DEBUG - 2021-11-05 13:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:26:05 --> Total execution time: 0.0408
DEBUG - 2021-11-05 13:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:26:47 --> Total execution time: 0.0435
DEBUG - 2021-11-05 13:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 13:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:56:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 19:26:50 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 189
DEBUG - 2021-11-05 19:26:50 --> Total execution time: 0.0496
DEBUG - 2021-11-05 13:56:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:26:58 --> Total execution time: 0.0310
DEBUG - 2021-11-05 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:57:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 19:27:25 --> Severity: Notice --> Undefined variable: qr_code /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/controllers/Admin/settings/WhatsAppLogin_Controller.php 189
DEBUG - 2021-11-05 19:27:25 --> Total execution time: 0.0350
DEBUG - 2021-11-05 13:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:27:27 --> Total execution time: 0.0286
DEBUG - 2021-11-05 13:57:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:27:40 --> Total execution time: 0.0416
DEBUG - 2021-11-05 13:57:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 13:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 13:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:27:41 --> Total execution time: 0.0335
DEBUG - 2021-11-05 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:30:27 --> Total execution time: 0.0364
DEBUG - 2021-11-05 14:00:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:30:34 --> Total execution time: 0.0604
DEBUG - 2021-11-05 14:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:30:35 --> Total execution time: 0.0309
DEBUG - 2021-11-05 14:00:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:00:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:00:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:30:37 --> Total execution time: 0.0404
DEBUG - 2021-11-05 14:00:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:30:54 --> Total execution time: 0.0360
DEBUG - 2021-11-05 14:01:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:31:05 --> Total execution time: 0.0328
DEBUG - 2021-11-05 14:01:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:31:20 --> Total execution time: 0.0362
DEBUG - 2021-11-05 14:01:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:31:58 --> Total execution time: 0.0350
DEBUG - 2021-11-05 14:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:02:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:02 --> Total execution time: 0.0542
DEBUG - 2021-11-05 14:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:03 --> Total execution time: 0.0434
DEBUG - 2021-11-05 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:05 --> Total execution time: 0.0454
DEBUG - 2021-11-05 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:05 --> Total execution time: 0.0388
DEBUG - 2021-11-05 14:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:06 --> Total execution time: 0.0466
DEBUG - 2021-11-05 14:02:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:07 --> Total execution time: 0.0463
DEBUG - 2021-11-05 14:02:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:08 --> Total execution time: 0.0353
DEBUG - 2021-11-05 14:02:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:09 --> Total execution time: 0.0381
DEBUG - 2021-11-05 14:02:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:10 --> Total execution time: 0.0422
DEBUG - 2021-11-05 14:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:11 --> Total execution time: 0.0370
DEBUG - 2021-11-05 14:02:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:12 --> Total execution time: 0.0372
DEBUG - 2021-11-05 14:02:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:13 --> Total execution time: 0.0496
DEBUG - 2021-11-05 14:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:14 --> Total execution time: 0.0322
DEBUG - 2021-11-05 14:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:15 --> Total execution time: 0.0430
DEBUG - 2021-11-05 14:02:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:16 --> Total execution time: 0.0752
DEBUG - 2021-11-05 14:02:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:16 --> Total execution time: 0.0562
DEBUG - 2021-11-05 14:02:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:17 --> Total execution time: 0.0376
DEBUG - 2021-11-05 14:02:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:18 --> Total execution time: 0.0388
DEBUG - 2021-11-05 14:02:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:19 --> Total execution time: 0.0370
DEBUG - 2021-11-05 14:02:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:20 --> Total execution time: 0.0427
DEBUG - 2021-11-05 14:02:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:22 --> Total execution time: 0.0352
DEBUG - 2021-11-05 14:02:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:23 --> Total execution time: 0.0358
DEBUG - 2021-11-05 14:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:25 --> Total execution time: 0.0394
DEBUG - 2021-11-05 14:02:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:26 --> Total execution time: 0.0361
DEBUG - 2021-11-05 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:27 --> Total execution time: 0.0675
DEBUG - 2021-11-05 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:27 --> Total execution time: 0.0378
DEBUG - 2021-11-05 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:27 --> Total execution time: 0.0447
DEBUG - 2021-11-05 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:28 --> Total execution time: 0.0359
DEBUG - 2021-11-05 14:02:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:29 --> Total execution time: 0.0422
DEBUG - 2021-11-05 14:02:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:31 --> Total execution time: 0.0445
DEBUG - 2021-11-05 14:02:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:32 --> Total execution time: 0.0340
DEBUG - 2021-11-05 14:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:33 --> Total execution time: 0.0428
DEBUG - 2021-11-05 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:34 --> Total execution time: 0.0331
DEBUG - 2021-11-05 14:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:35 --> Total execution time: 0.0320
DEBUG - 2021-11-05 14:02:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:36 --> Total execution time: 0.0370
DEBUG - 2021-11-05 14:02:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:37 --> Total execution time: 0.0373
DEBUG - 2021-11-05 14:02:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:38 --> Total execution time: 0.0376
DEBUG - 2021-11-05 14:02:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:39 --> Total execution time: 0.0367
DEBUG - 2021-11-05 14:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:40 --> Total execution time: 0.0321
DEBUG - 2021-11-05 14:02:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:41 --> Total execution time: 0.0379
DEBUG - 2021-11-05 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:42 --> Total execution time: 0.0347
DEBUG - 2021-11-05 14:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:43 --> Total execution time: 0.0381
DEBUG - 2021-11-05 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:44 --> Total execution time: 0.0348
DEBUG - 2021-11-05 14:02:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:45 --> Total execution time: 0.0323
DEBUG - 2021-11-05 14:02:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:46 --> Total execution time: 0.0543
DEBUG - 2021-11-05 14:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:47 --> Total execution time: 0.0403
DEBUG - 2021-11-05 14:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:48 --> Total execution time: 0.0339
DEBUG - 2021-11-05 14:02:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:49 --> Total execution time: 0.0318
DEBUG - 2021-11-05 14:02:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:50 --> Total execution time: 0.0317
DEBUG - 2021-11-05 14:02:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:51 --> Total execution time: 0.0436
DEBUG - 2021-11-05 14:02:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:52 --> Total execution time: 0.0330
DEBUG - 2021-11-05 14:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:53 --> Total execution time: 0.0359
DEBUG - 2021-11-05 14:02:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:54 --> Total execution time: 0.0340
DEBUG - 2021-11-05 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:55 --> Total execution time: 0.0320
DEBUG - 2021-11-05 14:02:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:56 --> Total execution time: 0.0320
DEBUG - 2021-11-05 14:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:57 --> Total execution time: 0.0429
DEBUG - 2021-11-05 14:02:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:58 --> Total execution time: 0.0371
DEBUG - 2021-11-05 14:02:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:32:59 --> Total execution time: 0.0339
DEBUG - 2021-11-05 14:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:00 --> Total execution time: 0.0335
DEBUG - 2021-11-05 14:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:01 --> Total execution time: 0.0356
DEBUG - 2021-11-05 14:03:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:02 --> Total execution time: 0.0456
DEBUG - 2021-11-05 14:03:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:03 --> Total execution time: 0.0523
DEBUG - 2021-11-05 14:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:05 --> Total execution time: 0.0478
DEBUG - 2021-11-05 14:03:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:06 --> Total execution time: 0.0350
DEBUG - 2021-11-05 14:03:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:07 --> Total execution time: 0.0318
DEBUG - 2021-11-05 14:03:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:09 --> Total execution time: 0.0411
DEBUG - 2021-11-05 14:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:10 --> Total execution time: 0.0369
DEBUG - 2021-11-05 14:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:10 --> Total execution time: 0.0373
DEBUG - 2021-11-05 14:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:11 --> Total execution time: 0.0351
DEBUG - 2021-11-05 14:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:11 --> Total execution time: 0.0370
DEBUG - 2021-11-05 14:03:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:12 --> Total execution time: 0.0328
DEBUG - 2021-11-05 14:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:13 --> Total execution time: 0.0411
DEBUG - 2021-11-05 14:03:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:14 --> Total execution time: 0.0473
DEBUG - 2021-11-05 14:03:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:15 --> Total execution time: 0.0352
DEBUG - 2021-11-05 14:03:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:16 --> Total execution time: 0.0325
DEBUG - 2021-11-05 14:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:17 --> Total execution time: 0.0366
DEBUG - 2021-11-05 14:03:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:18 --> Total execution time: 0.0347
DEBUG - 2021-11-05 14:03:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:19 --> Total execution time: 0.0321
DEBUG - 2021-11-05 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:20 --> Total execution time: 0.0399
DEBUG - 2021-11-05 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:21 --> Total execution time: 0.0344
DEBUG - 2021-11-05 14:03:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:23 --> Total execution time: 0.0435
DEBUG - 2021-11-05 14:03:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:23 --> Total execution time: 0.0334
DEBUG - 2021-11-05 14:03:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:24 --> Total execution time: 0.0448
DEBUG - 2021-11-05 14:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:25 --> Total execution time: 0.0343
DEBUG - 2021-11-05 14:03:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:26 --> Total execution time: 0.0419
DEBUG - 2021-11-05 14:03:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:27 --> Total execution time: 0.0373
DEBUG - 2021-11-05 14:03:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:28 --> Total execution time: 0.0361
DEBUG - 2021-11-05 14:03:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:29 --> Total execution time: 0.0351
DEBUG - 2021-11-05 14:03:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:30 --> Total execution time: 0.0440
DEBUG - 2021-11-05 14:03:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:31 --> Total execution time: 0.0380
DEBUG - 2021-11-05 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:32 --> Total execution time: 0.0435
DEBUG - 2021-11-05 14:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:33 --> Total execution time: 0.0391
DEBUG - 2021-11-05 14:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:34 --> Total execution time: 0.0433
DEBUG - 2021-11-05 14:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:35 --> Total execution time: 0.0510
DEBUG - 2021-11-05 14:03:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:36 --> Total execution time: 0.0413
DEBUG - 2021-11-05 14:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:37 --> Total execution time: 0.0444
DEBUG - 2021-11-05 14:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:38 --> Total execution time: 0.0608
DEBUG - 2021-11-05 14:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:40 --> Total execution time: 0.0602
DEBUG - 2021-11-05 14:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:40 --> Total execution time: 0.0439
DEBUG - 2021-11-05 14:03:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:41 --> Total execution time: 0.0331
DEBUG - 2021-11-05 14:03:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:42 --> Total execution time: 0.0383
DEBUG - 2021-11-05 14:03:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:43 --> Total execution time: 0.0510
DEBUG - 2021-11-05 14:03:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:44 --> Total execution time: 0.0396
DEBUG - 2021-11-05 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:45 --> Total execution time: 0.0615
DEBUG - 2021-11-05 14:03:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:46 --> Total execution time: 0.0355
DEBUG - 2021-11-05 14:03:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:47 --> Total execution time: 0.0427
DEBUG - 2021-11-05 14:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:48 --> Total execution time: 0.0537
DEBUG - 2021-11-05 14:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:49 --> Total execution time: 0.0450
DEBUG - 2021-11-05 14:03:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:50 --> Total execution time: 0.0451
DEBUG - 2021-11-05 14:03:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:51 --> Total execution time: 0.0446
DEBUG - 2021-11-05 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:52 --> Total execution time: 0.0419
DEBUG - 2021-11-05 14:03:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:53 --> Total execution time: 0.0408
DEBUG - 2021-11-05 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:54 --> Total execution time: 0.0393
DEBUG - 2021-11-05 14:03:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:55 --> Total execution time: 0.0383
DEBUG - 2021-11-05 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:56 --> Total execution time: 0.0907
DEBUG - 2021-11-05 14:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:57 --> Total execution time: 0.1759
DEBUG - 2021-11-05 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:58 --> Total execution time: 0.2274
DEBUG - 2021-11-05 14:03:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:59 --> Total execution time: 0.0447
DEBUG - 2021-11-05 14:03:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:33:59 --> Total execution time: 0.1030
DEBUG - 2021-11-05 14:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:01 --> Total execution time: 0.0599
DEBUG - 2021-11-05 14:04:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:02 --> Total execution time: 0.0495
DEBUG - 2021-11-05 14:04:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:03 --> Total execution time: 0.0356
DEBUG - 2021-11-05 14:04:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:04 --> Total execution time: 0.0442
DEBUG - 2021-11-05 14:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:06 --> Total execution time: 0.7006
DEBUG - 2021-11-05 14:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:06 --> Total execution time: 0.0466
DEBUG - 2021-11-05 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:07 --> Total execution time: 0.0379
DEBUG - 2021-11-05 14:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:08 --> Total execution time: 0.3612
DEBUG - 2021-11-05 14:04:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:09 --> Total execution time: 0.0392
DEBUG - 2021-11-05 14:04:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:10 --> Total execution time: 0.0333
DEBUG - 2021-11-05 14:04:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:11 --> Total execution time: 0.0388
DEBUG - 2021-11-05 14:04:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:12 --> Total execution time: 0.0329
DEBUG - 2021-11-05 14:04:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:13 --> Total execution time: 0.0350
DEBUG - 2021-11-05 14:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:14 --> Total execution time: 0.0354
DEBUG - 2021-11-05 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:15 --> Total execution time: 0.0349
DEBUG - 2021-11-05 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:16 --> Total execution time: 0.0322
DEBUG - 2021-11-05 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:17 --> Total execution time: 0.0392
DEBUG - 2021-11-05 14:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:18 --> Total execution time: 0.0317
DEBUG - 2021-11-05 14:04:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:19 --> Total execution time: 0.0350
DEBUG - 2021-11-05 14:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:20 --> Total execution time: 0.0545
DEBUG - 2021-11-05 14:04:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:21 --> Total execution time: 0.0351
DEBUG - 2021-11-05 14:04:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:22 --> Total execution time: 0.0411
DEBUG - 2021-11-05 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:23 --> Total execution time: 0.0412
DEBUG - 2021-11-05 14:04:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:24 --> Total execution time: 0.0359
DEBUG - 2021-11-05 14:04:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:25 --> Total execution time: 0.0351
DEBUG - 2021-11-05 14:04:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:26 --> Total execution time: 0.0338
DEBUG - 2021-11-05 14:04:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:27 --> Total execution time: 0.0447
DEBUG - 2021-11-05 14:04:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:28 --> Total execution time: 0.0348
DEBUG - 2021-11-05 14:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:29 --> Total execution time: 0.0323
DEBUG - 2021-11-05 14:04:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:30 --> Total execution time: 0.0452
DEBUG - 2021-11-05 14:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:31 --> Total execution time: 0.0467
DEBUG - 2021-11-05 14:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:32 --> Total execution time: 0.0382
DEBUG - 2021-11-05 14:04:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:33 --> Total execution time: 0.0448
DEBUG - 2021-11-05 14:04:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:34 --> Total execution time: 0.0362
DEBUG - 2021-11-05 14:04:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:35 --> Total execution time: 0.0391
DEBUG - 2021-11-05 14:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:36 --> Total execution time: 0.0399
DEBUG - 2021-11-05 14:04:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:37 --> Total execution time: 0.0444
DEBUG - 2021-11-05 14:04:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:37 --> Total execution time: 0.0446
DEBUG - 2021-11-05 14:04:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:38 --> Total execution time: 0.0391
DEBUG - 2021-11-05 14:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:39 --> Total execution time: 0.0324
DEBUG - 2021-11-05 14:04:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:40 --> Total execution time: 0.0374
DEBUG - 2021-11-05 14:04:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:41 --> Total execution time: 0.0334
DEBUG - 2021-11-05 14:04:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:42 --> Total execution time: 0.0376
DEBUG - 2021-11-05 14:04:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:43 --> Total execution time: 0.0331
DEBUG - 2021-11-05 14:04:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:46 --> Total execution time: 0.0315
DEBUG - 2021-11-05 14:04:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:46 --> Total execution time: 0.0402
DEBUG - 2021-11-05 14:04:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:48 --> Total execution time: 0.0385
DEBUG - 2021-11-05 14:04:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:48 --> Total execution time: 0.0372
DEBUG - 2021-11-05 14:04:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:48 --> Total execution time: 0.0414
DEBUG - 2021-11-05 14:04:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:49 --> Total execution time: 0.0335
DEBUG - 2021-11-05 14:04:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:51 --> Total execution time: 0.0345
DEBUG - 2021-11-05 14:04:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:52 --> Total execution time: 0.0389
DEBUG - 2021-11-05 14:04:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:53 --> Total execution time: 0.0424
DEBUG - 2021-11-05 14:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:54 --> Total execution time: 0.0415
DEBUG - 2021-11-05 14:04:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:55 --> Total execution time: 0.0394
DEBUG - 2021-11-05 14:04:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:56 --> Total execution time: 0.0460
DEBUG - 2021-11-05 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:57 --> Total execution time: 0.0433
DEBUG - 2021-11-05 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:58 --> Total execution time: 0.0344
DEBUG - 2021-11-05 14:04:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:34:59 --> Total execution time: 0.0447
DEBUG - 2021-11-05 14:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:00 --> Total execution time: 0.0322
DEBUG - 2021-11-05 14:05:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:01 --> Total execution time: 0.0394
DEBUG - 2021-11-05 14:05:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:01 --> Total execution time: 0.0381
DEBUG - 2021-11-05 14:05:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:02 --> Total execution time: 0.0828
DEBUG - 2021-11-05 14:05:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:03 --> Total execution time: 0.0626
DEBUG - 2021-11-05 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:05 --> Total execution time: 0.1199
DEBUG - 2021-11-05 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:08 --> Total execution time: 0.0406
DEBUG - 2021-11-05 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:08 --> Total execution time: 0.0451
DEBUG - 2021-11-05 14:05:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:09 --> Total execution time: 0.0483
DEBUG - 2021-11-05 14:05:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:09 --> Total execution time: 0.0394
DEBUG - 2021-11-05 14:05:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:10 --> Total execution time: 0.0347
DEBUG - 2021-11-05 14:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:11 --> Total execution time: 0.0385
DEBUG - 2021-11-05 14:05:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:13 --> Total execution time: 0.0537
DEBUG - 2021-11-05 14:05:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:14 --> Total execution time: 0.0449
DEBUG - 2021-11-05 14:05:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:15 --> Total execution time: 0.0336
DEBUG - 2021-11-05 14:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:16 --> Total execution time: 0.0483
DEBUG - 2021-11-05 14:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:16 --> Total execution time: 0.0401
DEBUG - 2021-11-05 14:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:22 --> Total execution time: 0.0439
DEBUG - 2021-11-05 14:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:23 --> Total execution time: 0.0395
DEBUG - 2021-11-05 14:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:23 --> Total execution time: 0.0450
DEBUG - 2021-11-05 14:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:24 --> Total execution time: 0.0537
DEBUG - 2021-11-05 14:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:24 --> Total execution time: 0.0422
DEBUG - 2021-11-05 14:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:24 --> Total execution time: 0.0330
DEBUG - 2021-11-05 14:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:24 --> Total execution time: 0.0320
DEBUG - 2021-11-05 14:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:24 --> Total execution time: 0.0417
DEBUG - 2021-11-05 14:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:25 --> Total execution time: 0.2303
DEBUG - 2021-11-05 14:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:25 --> Total execution time: 0.0442
DEBUG - 2021-11-05 14:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:26 --> Total execution time: 0.0332
DEBUG - 2021-11-05 14:05:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:27 --> Total execution time: 0.0335
DEBUG - 2021-11-05 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:28 --> Total execution time: 0.0389
DEBUG - 2021-11-05 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:29 --> Total execution time: 0.0375
DEBUG - 2021-11-05 14:05:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:30 --> Total execution time: 0.0348
DEBUG - 2021-11-05 14:05:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:31 --> Total execution time: 0.0440
DEBUG - 2021-11-05 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:32 --> Total execution time: 0.0435
DEBUG - 2021-11-05 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:33 --> Total execution time: 0.0506
DEBUG - 2021-11-05 14:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:34 --> Total execution time: 0.0477
DEBUG - 2021-11-05 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:35 --> Total execution time: 0.0357
DEBUG - 2021-11-05 14:05:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:36 --> Total execution time: 0.0465
DEBUG - 2021-11-05 14:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:37 --> Total execution time: 0.0555
DEBUG - 2021-11-05 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:38 --> Total execution time: 0.0381
DEBUG - 2021-11-05 14:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:39 --> Total execution time: 0.0346
DEBUG - 2021-11-05 14:05:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:40 --> Total execution time: 0.0337
DEBUG - 2021-11-05 14:05:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:41 --> Total execution time: 0.0404
DEBUG - 2021-11-05 14:05:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:42 --> Total execution time: 0.0390
DEBUG - 2021-11-05 14:05:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:43 --> Total execution time: 0.0368
DEBUG - 2021-11-05 14:05:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:44 --> Total execution time: 0.0616
DEBUG - 2021-11-05 14:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:45 --> Total execution time: 0.0589
DEBUG - 2021-11-05 14:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:46 --> Total execution time: 0.0445
DEBUG - 2021-11-05 14:05:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:47 --> Total execution time: 0.0554
DEBUG - 2021-11-05 14:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:48 --> Total execution time: 0.0677
DEBUG - 2021-11-05 14:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:49 --> Total execution time: 0.0394
DEBUG - 2021-11-05 14:05:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:50 --> Total execution time: 0.0517
DEBUG - 2021-11-05 14:05:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:51 --> Total execution time: 0.0364
DEBUG - 2021-11-05 14:05:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:52 --> Total execution time: 0.0324
DEBUG - 2021-11-05 14:05:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:53 --> Total execution time: 0.0412
DEBUG - 2021-11-05 14:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:54 --> Total execution time: 0.0383
DEBUG - 2021-11-05 14:05:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:55 --> Total execution time: 0.0350
DEBUG - 2021-11-05 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:57 --> Total execution time: 0.0397
DEBUG - 2021-11-05 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:57 --> Total execution time: 0.0359
DEBUG - 2021-11-05 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:35:58 --> Total execution time: 0.0407
DEBUG - 2021-11-05 14:06:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:00 --> Total execution time: 0.0383
DEBUG - 2021-11-05 14:06:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:00 --> Total execution time: 0.0384
DEBUG - 2021-11-05 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:01 --> Total execution time: 0.0361
DEBUG - 2021-11-05 14:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:02 --> Total execution time: 0.0762
DEBUG - 2021-11-05 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:03 --> Total execution time: 0.0508
DEBUG - 2021-11-05 14:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:04 --> Total execution time: 0.0349
DEBUG - 2021-11-05 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:05 --> Total execution time: 0.0329
DEBUG - 2021-11-05 14:06:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:06 --> Total execution time: 0.0419
DEBUG - 2021-11-05 14:06:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:07 --> Total execution time: 0.0361
DEBUG - 2021-11-05 14:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:08 --> Total execution time: 0.0394
DEBUG - 2021-11-05 14:06:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:09 --> Total execution time: 0.0327
DEBUG - 2021-11-05 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:10 --> Total execution time: 0.0542
DEBUG - 2021-11-05 14:06:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:13 --> Total execution time: 0.0343
DEBUG - 2021-11-05 14:06:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:13 --> Total execution time: 0.0460
DEBUG - 2021-11-05 14:06:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:14 --> Total execution time: 0.0446
DEBUG - 2021-11-05 14:06:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:06:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:15 --> Total execution time: 0.0398
DEBUG - 2021-11-05 14:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:15 --> Total execution time: 0.0365
DEBUG - 2021-11-05 19:36:16 --> Total execution time: 1.6758
DEBUG - 2021-11-05 14:06:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:16 --> Total execution time: 0.0425
DEBUG - 2021-11-05 14:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:17 --> Total execution time: 0.0331
DEBUG - 2021-11-05 14:06:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:18 --> Total execution time: 0.0534
DEBUG - 2021-11-05 14:06:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:19 --> Total execution time: 0.0482
DEBUG - 2021-11-05 14:06:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:20 --> Total execution time: 0.0426
DEBUG - 2021-11-05 14:06:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:20 --> Total execution time: 0.0570
DEBUG - 2021-11-05 14:06:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:21 --> Total execution time: 0.1945
DEBUG - 2021-11-05 14:06:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:22 --> Total execution time: 0.0478
DEBUG - 2021-11-05 14:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:23 --> Total execution time: 0.0396
DEBUG - 2021-11-05 14:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:24 --> Total execution time: 0.0387
DEBUG - 2021-11-05 14:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:25 --> Total execution time: 0.0384
DEBUG - 2021-11-05 14:06:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:26 --> Total execution time: 0.0518
DEBUG - 2021-11-05 14:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:27 --> Total execution time: 0.0409
DEBUG - 2021-11-05 14:06:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:30 --> Total execution time: 0.0458
DEBUG - 2021-11-05 14:06:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:30 --> Total execution time: 0.0349
DEBUG - 2021-11-05 14:06:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:30 --> Total execution time: 0.0412
DEBUG - 2021-11-05 14:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:31 --> Total execution time: 0.0475
DEBUG - 2021-11-05 14:06:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:32 --> Total execution time: 0.0491
DEBUG - 2021-11-05 14:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:33 --> Total execution time: 0.0450
DEBUG - 2021-11-05 14:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:33 --> Total execution time: 0.0408
DEBUG - 2021-11-05 14:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:34 --> Total execution time: 0.0435
DEBUG - 2021-11-05 14:06:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:35 --> Total execution time: 0.0477
DEBUG - 2021-11-05 14:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:36 --> Total execution time: 0.0422
DEBUG - 2021-11-05 14:06:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:37 --> Total execution time: 0.0436
DEBUG - 2021-11-05 14:06:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:38 --> Total execution time: 0.0404
DEBUG - 2021-11-05 14:06:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:39 --> Total execution time: 0.0506
DEBUG - 2021-11-05 14:06:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:40 --> Total execution time: 0.0458
DEBUG - 2021-11-05 14:06:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:41 --> Total execution time: 0.0402
DEBUG - 2021-11-05 14:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:42 --> Total execution time: 0.0728
DEBUG - 2021-11-05 14:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:43 --> Total execution time: 0.0460
DEBUG - 2021-11-05 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:44 --> Total execution time: 0.0633
DEBUG - 2021-11-05 14:06:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:45 --> Total execution time: 0.0797
DEBUG - 2021-11-05 14:06:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:46 --> Total execution time: 0.0474
DEBUG - 2021-11-05 14:06:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:47 --> Total execution time: 0.0781
DEBUG - 2021-11-05 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:48 --> Total execution time: 0.0749
DEBUG - 2021-11-05 14:06:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:49 --> Total execution time: 0.0406
DEBUG - 2021-11-05 14:06:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:50 --> Total execution time: 0.0720
DEBUG - 2021-11-05 14:06:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:51 --> Total execution time: 0.0543
DEBUG - 2021-11-05 14:06:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:52 --> Total execution time: 0.0390
DEBUG - 2021-11-05 14:06:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:53 --> Total execution time: 0.0376
DEBUG - 2021-11-05 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:54 --> Total execution time: 0.0373
DEBUG - 2021-11-05 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:55 --> Total execution time: 0.0384
DEBUG - 2021-11-05 14:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:56 --> Total execution time: 0.0364
DEBUG - 2021-11-05 14:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:57 --> Total execution time: 0.0466
DEBUG - 2021-11-05 14:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:57 --> UTF-8 Support Enabled
ERROR - 2021-11-05 14:06:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:06:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:06:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:06:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:06:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:58 --> Total execution time: 0.0410
DEBUG - 2021-11-05 14:06:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:36:59 --> Total execution time: 0.0399
DEBUG - 2021-11-05 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:00 --> Total execution time: 0.0438
DEBUG - 2021-11-05 14:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:01 --> Total execution time: 0.0443
DEBUG - 2021-11-05 14:07:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:02 --> Total execution time: 0.0539
DEBUG - 2021-11-05 14:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:03 --> Total execution time: 0.0767
DEBUG - 2021-11-05 14:07:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:04 --> Total execution time: 0.0675
DEBUG - 2021-11-05 14:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:05 --> Total execution time: 0.0474
DEBUG - 2021-11-05 14:07:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:06 --> Total execution time: 0.0373
DEBUG - 2021-11-05 14:07:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:07 --> Total execution time: 0.0452
DEBUG - 2021-11-05 14:07:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:08 --> Total execution time: 0.0408
DEBUG - 2021-11-05 14:07:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:09 --> Total execution time: 0.0458
DEBUG - 2021-11-05 14:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:10 --> Total execution time: 0.0420
DEBUG - 2021-11-05 14:07:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:11 --> Total execution time: 0.0382
DEBUG - 2021-11-05 14:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:12 --> Total execution time: 0.0315
DEBUG - 2021-11-05 14:07:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:13 --> Total execution time: 0.0328
DEBUG - 2021-11-05 14:07:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:14 --> Total execution time: 0.0340
DEBUG - 2021-11-05 14:07:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:15 --> Total execution time: 0.0364
DEBUG - 2021-11-05 14:07:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:16 --> Total execution time: 0.0565
DEBUG - 2021-11-05 14:07:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:17 --> Total execution time: 0.0446
DEBUG - 2021-11-05 14:07:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:18 --> Total execution time: 0.0492
DEBUG - 2021-11-05 14:07:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:19 --> Total execution time: 0.0351
DEBUG - 2021-11-05 14:07:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:20 --> Total execution time: 0.0834
DEBUG - 2021-11-05 14:07:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:21 --> Total execution time: 0.0367
DEBUG - 2021-11-05 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:22 --> Total execution time: 0.2389
DEBUG - 2021-11-05 14:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:23 --> Total execution time: 0.0783
DEBUG - 2021-11-05 14:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:37:23 --> Total execution time: 0.0853
DEBUG - 2021-11-05 14:09:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:39:12 --> Total execution time: 0.0485
DEBUG - 2021-11-05 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:09:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:09:23 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-05 14:09:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:09:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:09:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:09:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:39:56 --> Total execution time: 0.0502
DEBUG - 2021-11-05 14:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:06 --> Total execution time: 0.0562
DEBUG - 2021-11-05 14:10:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:10:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:13 --> Total execution time: 0.0337
DEBUG - 2021-11-05 14:10:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:10:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:24 --> Total execution time: 0.0714
DEBUG - 2021-11-05 14:10:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:26 --> No URI present. Default controller set.
DEBUG - 2021-11-05 14:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:26 --> Total execution time: 0.0544
DEBUG - 2021-11-05 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:10:27 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-05 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:27 --> No URI present. Default controller set.
DEBUG - 2021-11-05 14:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:27 --> Total execution time: 0.0356
DEBUG - 2021-11-05 14:10:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:30 --> Total execution time: 0.1293
DEBUG - 2021-11-05 14:10:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:10:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:39 --> Total execution time: 0.1397
DEBUG - 2021-11-05 14:10:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:41 --> Total execution time: 0.1797
DEBUG - 2021-11-05 14:10:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 19:40:44 --> Total execution time: 0.0577
DEBUG - 2021-11-05 14:10:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:10:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:10:45 --> 404 Page Not Found: Assets/app-assets
DEBUG - 2021-11-05 14:30:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:00:01 --> Total execution time: 0.0491
DEBUG - 2021-11-05 14:30:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:00:05 --> Total execution time: 0.0469
DEBUG - 2021-11-05 14:34:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:04:15 --> Total execution time: 0.0695
DEBUG - 2021-11-05 14:34:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:04:19 --> Total execution time: 0.0329
DEBUG - 2021-11-05 14:37:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:37:21 --> No URI present. Default controller set.
DEBUG - 2021-11-05 14:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:37:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:07:21 --> Total execution time: 0.0304
DEBUG - 2021-11-05 14:37:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:37:28 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-11-05 14:44:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 14:44:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:14:09 --> Total execution time: 0.0331
DEBUG - 2021-11-05 14:44:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:14:14 --> Total execution time: 0.1532
DEBUG - 2021-11-05 14:44:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:44:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:44:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:44:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:44:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:44:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:44:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:44:17 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-05 14:44:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:45:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:15:04 --> Total execution time: 0.0736
DEBUG - 2021-11-05 14:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:22:49 --> Total execution time: 0.0622
DEBUG - 2021-11-05 14:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:23:31 --> Total execution time: 0.0335
DEBUG - 2021-11-05 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:53:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Undefined variable: profile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 66
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Trying to get property 'comp_name' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 66
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Undefined variable: profile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 70
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Trying to get property 'comp_show_name' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 70
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Undefined variable: profile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 74
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Trying to get property 'comp_contact_no' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 74
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Undefined variable: profile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 78
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Trying to get property 'comp_whats_app_no' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 78
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Undefined variable: profile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 82
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Trying to get property 'comp_email' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 82
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Undefined variable: profile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 86
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 86
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Undefined variable: profile /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 86
ERROR - 2021-11-05 20:23:55 --> Severity: Notice --> Trying to get property 'comp_logo' of non-object /home2/whatsmessaging/cp.whatsmessaging.com/cpnew/application/views/Admin/settings/admin-company-profile.php 86
DEBUG - 2021-11-05 20:23:55 --> Total execution time: 0.0570
DEBUG - 2021-11-05 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:53:55 --> UTF-8 Support Enabled
ERROR - 2021-11-05 14:53:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:53:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:53:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:54:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:24:17 --> Total execution time: 0.0405
DEBUG - 2021-11-05 14:54:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:54:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:54:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:54:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:54:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:54:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:54:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:54:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:54:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:54:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:54:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 14:54:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 14:54:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:24:40 --> Total execution time: 0.0378
DEBUG - 2021-11-05 14:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:26:13 --> Total execution time: 0.0417
DEBUG - 2021-11-05 14:59:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 14:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 14:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:29:03 --> Total execution time: 0.0722
DEBUG - 2021-11-05 15:00:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:30:33 --> Total execution time: 0.0860
DEBUG - 2021-11-05 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:44:49 --> Total execution time: 0.0437
DEBUG - 2021-11-05 15:15:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:45:37 --> Total execution time: 0.0554
DEBUG - 2021-11-05 15:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 15:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:47:43 --> Total execution time: 0.0367
DEBUG - 2021-11-05 15:27:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:57:50 --> Total execution time: 0.0466
DEBUG - 2021-11-05 15:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:58:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-05 15:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 20:58:03 --> Total execution time: 0.0323
DEBUG - 2021-11-05 15:43:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:13:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-05 15:44:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:14:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-05 15:45:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:15:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-05 15:47:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:17:13 --> Total execution time: 0.0419
DEBUG - 2021-11-05 15:47:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:17:27 --> Total execution time: 0.0502
DEBUG - 2021-11-05 15:47:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:17:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-05 15:50:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:20:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-05 15:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:21:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-05 15:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:21:18 --> Total execution time: 0.0296
DEBUG - 2021-11-05 15:52:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:22:25 --> Total execution time: 0.0470
DEBUG - 2021-11-05 15:52:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:22:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-05 15:52:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:22:31 --> Total execution time: 0.0398
DEBUG - 2021-11-05 15:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 15:52:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 15:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 15:52:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 15:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 15:52:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 15:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-05 15:52:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-05 15:53:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:23:40 --> Total execution time: 0.0361
DEBUG - 2021-11-05 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 15:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:24:04 --> Total execution time: 0.0346
DEBUG - 2021-11-05 16:14:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:44:11 --> Total execution time: 0.0467
DEBUG - 2021-11-05 16:19:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:49:02 --> Total execution time: 0.0868
DEBUG - 2021-11-05 16:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:19:30 --> Total execution time: 0.0655
DEBUG - 2021-11-05 16:21:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:21:28 --> Total execution time: 0.0352
DEBUG - 2021-11-05 16:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:52:27 --> Total execution time: 0.0586
DEBUG - 2021-11-05 16:23:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:23:20 --> No URI present. Default controller set.
DEBUG - 2021-11-05 16:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 16:23:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:53:21 --> Total execution time: 0.1686
DEBUG - 2021-11-05 16:27:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:57:59 --> Total execution time: 0.1333
DEBUG - 2021-11-05 16:28:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:58:18 --> Total execution time: 0.0399
DEBUG - 2021-11-05 16:28:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:58:35 --> Total execution time: 0.0455
DEBUG - 2021-11-05 16:28:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 16:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 16:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 21:58:50 --> Total execution time: 0.0827
DEBUG - 2021-11-05 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 17:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 17:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 17:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 17:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 22:41:45 --> Total execution time: 0.0920
DEBUG - 2021-11-05 17:12:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 17:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 17:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 22:42:57 --> Total execution time: 0.0825
DEBUG - 2021-11-05 17:13:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-05 17:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-05 17:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-05 22:43:01 --> Total execution time: 0.0416
