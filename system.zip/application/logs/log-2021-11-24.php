<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-24 13:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:18:37 --> No URI present. Default controller set.
DEBUG - 2021-11-24 13:18:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:18:37 --> Query error: Table 'loan.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = 'gfsq56t9eovd22luf08iqoh86327fhhm'
ERROR - 2021-11-24 13:18:37 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2021-11-24 13:18:37 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: C:\xampp\tmp) Unknown 0
DEBUG - 2021-11-24 13:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:23:51 --> No URI present. Default controller set.
DEBUG - 2021-11-24 13:23:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:23:52 --> Query error: Table 'loan.ci_sessions' doesn't exist - Invalid query: SELECT 1
FROM `ci_sessions`
WHERE `id` = 'gfsq56t9eovd22luf08iqoh86327fhhm'
ERROR - 2021-11-24 13:23:52 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
DEBUG - 2021-11-24 13:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:24:18 --> No URI present. Default controller set.
DEBUG - 2021-11-24 13:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:24:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-24 17:54:18 --> Query error: Table 'loan.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2021-11-24 13:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:24:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:24:18 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-24 13:25:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:25:46 --> No URI present. Default controller set.
DEBUG - 2021-11-24 13:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:25:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-24 17:55:46 --> Query error: Table 'loan.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2021-11-24 13:25:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:25:46 --> 404 Page Not Found: Assets/front
DEBUG - 2021-11-24 13:27:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:27:13 --> No URI present. Default controller set.
DEBUG - 2021-11-24 13:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 13:27:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 13:27:21 --> Total execution time: 0.0707
DEBUG - 2021-11-24 13:28:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 13:28:55 --> Total execution time: 0.0692
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/images
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-24 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:28:55 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:32:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 13:32:28 --> Total execution time: 0.0524
DEBUG - 2021-11-24 13:34:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 13:34:30 --> Total execution time: 0.0494
DEBUG - 2021-11-24 13:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 13:35:01 --> Total execution time: 0.0511
DEBUG - 2021-11-24 13:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 13:37:08 --> Total execution time: 0.0611
DEBUG - 2021-11-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:39:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-24 18:09:48 --> Query error: Table 'loan.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2021-11-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:39:48 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:39:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:39:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:39:48 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:39:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:39:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:46:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-24 18:16:11 --> Query error: Table 'loan.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2021-11-24 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:46:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:46:11 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:46:11 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:46:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:46:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:46:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:46:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:46:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-24 18:16:53 --> Query error: Table 'loan.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2021-11-24 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:46:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:46:53 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:46:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:46:53 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:46:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:46:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:47:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-24 18:17:01 --> Query error: Table 'loan.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2021-11-24 13:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:47:01 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:47:01 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:47:01 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:17:22 --> Total execution time: 0.0758
DEBUG - 2021-11-24 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:18:31 --> Total execution time: 0.0520
DEBUG - 2021-11-24 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:31 --> 404 Page Not Found: Assets/css
ERROR - 2021-11-24 13:48:31 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:31 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/images
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/libs
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-24 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:48:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:48:32 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-24 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:19:12 --> Total execution time: 0.0678
DEBUG - 2021-11-24 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:49:13 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:49:13 --> 404 Page Not Found: Assets/css
ERROR - 2021-11-24 13:49:13 --> 404 Page Not Found: Assets/lang
DEBUG - 2021-11-24 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:19:15 --> Total execution time: 0.0502
DEBUG - 2021-11-24 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:49:15 --> 404 Page Not Found: Assets/css
ERROR - 2021-11-24 13:49:15 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:49:29 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:49:29 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:49:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:49:29 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:49:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:49:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:20:20 --> Total execution time: 0.0714
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:50:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:50:20 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:50:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:50:20 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:50:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:50:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:50:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-11-24 13:50:20 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:50:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:50:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:50:59 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:51:29 --> 404 Page Not Found: Assets/css
DEBUG - 2021-11-24 13:51:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:21:31 --> Total execution time: 0.1498
DEBUG - 2021-11-24 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:51:31 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:51:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:51:31 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:51:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:51:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:51:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:51:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:22:14 --> Total execution time: 0.0583
DEBUG - 2021-11-24 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:22:21 --> Total execution time: 0.0823
DEBUG - 2021-11-24 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:21 --> 404 Page Not Found: Csscss/index
DEBUG - 2021-11-24 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:21 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:52:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:21 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:22:27 --> Total execution time: 0.0763
DEBUG - 2021-11-24 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:27 --> 404 Page Not Found: Assets/css.css
DEBUG - 2021-11-24 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:27 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:22:35 --> Total execution time: 0.0652
DEBUG - 2021-11-24 13:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:35 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:35 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:35 --> UTF-8 Support Enabled
ERROR - 2021-11-24 13:52:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:35 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:22:48 --> Total execution time: 0.0551
DEBUG - 2021-11-24 13:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:52:49 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:52:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:23:08 --> Total execution time: 0.0521
DEBUG - 2021-11-24 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:53:08 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-24 13:53:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:53:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:53:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:53:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 13:53:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-24 13:55:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:25:26 --> Total execution time: 0.0567
DEBUG - 2021-11-24 13:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:26:14 --> Total execution time: 0.0533
DEBUG - 2021-11-24 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:26:38 --> Total execution time: 0.0767
DEBUG - 2021-11-24 13:57:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:27:08 --> Total execution time: 0.0568
DEBUG - 2021-11-24 13:57:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:27:49 --> Total execution time: 0.0772
DEBUG - 2021-11-24 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:28:24 --> Total execution time: 0.0549
DEBUG - 2021-11-24 13:58:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:28:40 --> Total execution time: 0.0717
DEBUG - 2021-11-24 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 13:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 13:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:28:49 --> Total execution time: 0.0517
DEBUG - 2021-11-24 14:00:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:30:27 --> Total execution time: 0.0515
DEBUG - 2021-11-24 14:01:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:31:40 --> Total execution time: 0.0547
DEBUG - 2021-11-24 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:32:29 --> Total execution time: 0.0554
DEBUG - 2021-11-24 14:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:32:57 --> Total execution time: 0.0537
DEBUG - 2021-11-24 14:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:33:04 --> Total execution time: 0.0787
DEBUG - 2021-11-24 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:33:21 --> Total execution time: 0.0834
DEBUG - 2021-11-24 14:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:33:49 --> Total execution time: 0.0761
DEBUG - 2021-11-24 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:34:17 --> Total execution time: 0.0631
DEBUG - 2021-11-24 14:04:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:34:28 --> Total execution time: 0.0539
DEBUG - 2021-11-24 14:04:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:34:53 --> Total execution time: 0.0610
DEBUG - 2021-11-24 14:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:35:23 --> Total execution time: 0.0661
DEBUG - 2021-11-24 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:36:03 --> Total execution time: 0.0516
DEBUG - 2021-11-24 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:09:30 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-11-24 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:39:32 --> Total execution time: 0.0664
DEBUG - 2021-11-24 14:10:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:40:46 --> Total execution time: 0.0517
DEBUG - 2021-11-24 14:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:41:09 --> Total execution time: 0.0746
DEBUG - 2021-11-24 14:12:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:42:21 --> Total execution time: 0.0699
DEBUG - 2021-11-24 14:13:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:43:34 --> Total execution time: 0.0575
DEBUG - 2021-11-24 14:15:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:45:22 --> Total execution time: 0.0687
DEBUG - 2021-11-24 14:16:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:46:41 --> Total execution time: 0.0773
DEBUG - 2021-11-24 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:46:53 --> Total execution time: 0.0559
DEBUG - 2021-11-24 14:17:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:47:06 --> Total execution time: 0.0861
DEBUG - 2021-11-24 14:19:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:49:07 --> Total execution time: 0.0579
DEBUG - 2021-11-24 14:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:49:46 --> Total execution time: 0.0536
DEBUG - 2021-11-24 14:20:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:50:20 --> Total execution time: 0.0657
DEBUG - 2021-11-24 14:21:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:51:10 --> Total execution time: 0.0539
DEBUG - 2021-11-24 14:22:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:52:41 --> Total execution time: 0.0511
DEBUG - 2021-11-24 14:23:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:53:19 --> Total execution time: 0.0515
DEBUG - 2021-11-24 14:23:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:53:48 --> Total execution time: 0.0527
DEBUG - 2021-11-24 14:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:57:04 --> Total execution time: 0.0756
DEBUG - 2021-11-24 14:27:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:57:30 --> Total execution time: 0.0545
DEBUG - 2021-11-24 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:57:57 --> Total execution time: 0.0544
DEBUG - 2021-11-24 14:29:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 18:59:37 --> Total execution time: 0.0569
DEBUG - 2021-11-24 14:30:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 19:00:07 --> Total execution time: 0.0521
DEBUG - 2021-11-24 14:30:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 19:00:49 --> Total execution time: 0.0554
DEBUG - 2021-11-24 14:33:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 19:03:59 --> Total execution time: 0.0563
DEBUG - 2021-11-24 14:36:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 19:06:28 --> Total execution time: 0.0626
DEBUG - 2021-11-24 14:36:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:36:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:36:30 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:37:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:37:20 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:37:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:37:56 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:37:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:37:58 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:37:59 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:37:59 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:37:59 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:37:59 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:37:59 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:38:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:38:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 14:38:00 --> 404 Page Not Found: Admin/settings/Admin_Settings/Company_Profile
DEBUG - 2021-11-24 14:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 19:08:24 --> Total execution time: 0.0718
DEBUG - 2021-11-24 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 19:09:28 --> Total execution time: 0.0731
DEBUG - 2021-11-24 14:40:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 19:10:20 --> Total execution time: 0.0568
DEBUG - 2021-11-24 14:40:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 14:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 14:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-24 19:10:46 --> Total execution time: 0.0729
DEBUG - 2021-11-24 16:32:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 16:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 16:32:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 29
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_id' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 29
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 32
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_name' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 32
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 36
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_show_name' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 36
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 40
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_contact_no' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 40
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 44
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_whats_app_no' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 44
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 48
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_email' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 48
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 52
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_logo' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 52
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 53
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 53
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 53
ERROR - 2021-11-24 21:02:24 --> Severity: Notice --> Trying to get property 'comp_logo' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 53
DEBUG - 2021-11-24 21:02:24 --> Total execution time: 0.1038
