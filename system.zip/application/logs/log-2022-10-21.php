<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-10-21 00:00:44 --> Total execution time: 0.1855
DEBUG - 2022-10-21 00:00:57 --> Total execution time: 0.1955
DEBUG - 2022-10-21 00:01:07 --> Total execution time: 0.1871
DEBUG - 2022-10-21 00:01:09 --> Total execution time: 0.1896
DEBUG - 2022-10-21 00:01:20 --> Total execution time: 0.1475
DEBUG - 2022-10-21 00:01:29 --> Total execution time: 0.1526
DEBUG - 2022-10-21 00:01:41 --> Total execution time: 0.1609
DEBUG - 2022-10-21 00:01:48 --> Total execution time: 0.1911
DEBUG - 2022-10-21 00:02:01 --> Total execution time: 0.1996
DEBUG - 2022-10-21 00:02:06 --> Total execution time: 0.1870
DEBUG - 2022-10-21 00:02:11 --> Total execution time: 0.1837
DEBUG - 2022-10-21 00:02:15 --> Total execution time: 0.1862
DEBUG - 2022-10-21 00:02:19 --> Total execution time: 0.1785
DEBUG - 2022-10-21 00:02:44 --> Total execution time: 0.0941
DEBUG - 2022-10-21 00:02:57 --> Total execution time: 0.0909
DEBUG - 2022-10-21 00:04:19 --> Total execution time: 0.1645
DEBUG - 2022-10-21 00:04:34 --> Total execution time: 0.1574
DEBUG - 2022-10-21 00:04:39 --> Total execution time: 0.1566
DEBUG - 2022-10-21 00:08:36 --> Total execution time: 0.4559
DEBUG - 2022-10-21 00:08:37 --> Total execution time: 0.1561
DEBUG - 2022-10-21 00:08:38 --> Total execution time: 0.1489
DEBUG - 2022-10-21 00:14:40 --> Total execution time: 0.1464
DEBUG - 2022-10-21 00:15:13 --> Total execution time: 0.1497
DEBUG - 2022-10-21 00:15:46 --> Total execution time: 0.1641
DEBUG - 2022-10-21 00:15:51 --> Total execution time: 0.1711
DEBUG - 2022-10-21 00:16:01 --> Total execution time: 0.1519
DEBUG - 2022-10-21 00:16:22 --> Total execution time: 0.1508
DEBUG - 2022-10-21 00:16:33 --> Total execution time: 0.1872
DEBUG - 2022-10-21 00:17:07 --> Total execution time: 0.1532
DEBUG - 2022-10-21 00:17:17 --> Total execution time: 0.1700
DEBUG - 2022-10-21 00:17:18 --> Total execution time: 0.1908
DEBUG - 2022-10-21 00:17:18 --> Total execution time: 0.1820
DEBUG - 2022-10-21 00:17:19 --> Total execution time: 0.1566
DEBUG - 2022-10-21 00:17:24 --> Total execution time: 0.1498
DEBUG - 2022-10-21 00:17:29 --> Total execution time: 0.1708
DEBUG - 2022-10-21 00:17:39 --> Total execution time: 0.1513
DEBUG - 2022-10-21 00:18:00 --> Total execution time: 0.0922
DEBUG - 2022-10-21 00:18:03 --> Total execution time: 0.1603
DEBUG - 2022-10-21 00:18:09 --> Total execution time: 0.1924
DEBUG - 2022-10-21 00:18:19 --> Total execution time: 0.1762
DEBUG - 2022-10-21 00:18:22 --> Total execution time: 0.4213
DEBUG - 2022-10-21 00:18:24 --> Total execution time: 0.1566
DEBUG - 2022-10-21 00:18:30 --> Total execution time: 0.2246
DEBUG - 2022-10-21 00:18:36 --> Total execution time: 0.1588
DEBUG - 2022-10-21 00:18:46 --> Total execution time: 0.1699
DEBUG - 2022-10-21 00:19:01 --> Total execution time: 0.1525
DEBUG - 2022-10-21 00:19:09 --> Total execution time: 0.2190
DEBUG - 2022-10-21 00:19:42 --> Total execution time: 0.4499
DEBUG - 2022-10-21 00:20:10 --> Total execution time: 0.1520
DEBUG - 2022-10-21 00:20:14 --> Total execution time: 0.1656
DEBUG - 2022-10-21 00:20:23 --> Total execution time: 0.1469
DEBUG - 2022-10-21 00:20:35 --> Total execution time: 0.1797
DEBUG - 2022-10-21 00:23:54 --> Total execution time: 0.1618
DEBUG - 2022-10-21 00:24:25 --> Total execution time: 0.1422
DEBUG - 2022-10-21 00:28:06 --> Total execution time: 0.1625
DEBUG - 2022-10-21 00:30:03 --> Total execution time: 0.3300
DEBUG - 2022-10-21 00:44:54 --> Total execution time: 0.3935
DEBUG - 2022-10-21 00:48:40 --> Total execution time: 0.1382
DEBUG - 2022-10-21 00:50:05 --> Total execution time: 0.1543
DEBUG - 2022-10-21 00:50:13 --> Total execution time: 0.1042
DEBUG - 2022-10-21 01:20:37 --> Total execution time: 0.5013
DEBUG - 2022-10-21 01:25:15 --> Total execution time: 0.1691
DEBUG - 2022-10-21 01:29:47 --> Total execution time: 0.1577
DEBUG - 2022-10-21 01:30:03 --> Total execution time: 0.1153
DEBUG - 2022-10-21 01:41:02 --> Total execution time: 0.1717
DEBUG - 2022-10-21 01:56:38 --> Total execution time: 0.4839
DEBUG - 2022-10-21 02:15:03 --> Total execution time: 0.4800
DEBUG - 2022-10-21 02:18:58 --> Total execution time: 0.1819
DEBUG - 2022-10-21 02:30:04 --> Total execution time: 0.6162
DEBUG - 2022-10-21 02:37:15 --> Total execution time: 0.1953
DEBUG - 2022-10-21 02:37:51 --> Total execution time: 0.0934
DEBUG - 2022-10-21 02:38:39 --> Total execution time: 0.0899
DEBUG - 2022-10-21 03:16:02 --> Total execution time: 0.5030
DEBUG - 2022-10-21 03:30:04 --> Total execution time: 0.7280
DEBUG - 2022-10-21 03:33:25 --> Total execution time: 0.1499
DEBUG - 2022-10-21 04:00:05 --> Total execution time: 1.7512
DEBUG - 2022-10-21 04:00:28 --> Total execution time: 0.0978
DEBUG - 2022-10-21 04:01:13 --> Total execution time: 0.0957
DEBUG - 2022-10-21 04:01:36 --> Total execution time: 0.1445
DEBUG - 2022-10-21 04:03:09 --> Total execution time: 0.1642
DEBUG - 2022-10-21 04:20:21 --> Total execution time: 0.1832
DEBUG - 2022-10-21 04:23:12 --> Total execution time: 0.0997
DEBUG - 2022-10-21 04:25:00 --> Total execution time: 0.1487
DEBUG - 2022-10-21 04:30:03 --> Total execution time: 0.2095
DEBUG - 2022-10-21 05:06:59 --> Total execution time: 0.1603
DEBUG - 2022-10-21 05:07:21 --> Total execution time: 0.1803
DEBUG - 2022-10-21 05:07:25 --> Total execution time: 0.2258
DEBUG - 2022-10-21 05:16:23 --> Total execution time: 0.1652
DEBUG - 2022-10-21 05:16:24 --> Total execution time: 0.0956
DEBUG - 2022-10-21 05:16:34 --> Total execution time: 0.0927
DEBUG - 2022-10-21 05:16:42 --> Total execution time: 0.1537
DEBUG - 2022-10-21 05:16:50 --> Total execution time: 0.1661
DEBUG - 2022-10-21 05:16:58 --> Total execution time: 0.1733
DEBUG - 2022-10-21 05:17:01 --> Total execution time: 0.1540
DEBUG - 2022-10-21 05:17:12 --> Total execution time: 0.1442
DEBUG - 2022-10-21 05:17:15 --> Total execution time: 0.1458
DEBUG - 2022-10-21 05:20:26 --> Total execution time: 0.0962
DEBUG - 2022-10-21 05:20:27 --> Total execution time: 0.1328
DEBUG - 2022-10-21 05:27:39 --> Total execution time: 0.1611
DEBUG - 2022-10-21 05:27:52 --> Total execution time: 0.1485
DEBUG - 2022-10-21 05:27:53 --> Total execution time: 0.1473
DEBUG - 2022-10-21 05:27:53 --> Total execution time: 0.1446
DEBUG - 2022-10-21 05:28:39 --> Total execution time: 0.1454
DEBUG - 2022-10-21 05:29:02 --> Total execution time: 0.1051
DEBUG - 2022-10-21 05:29:06 --> Total execution time: 0.0969
DEBUG - 2022-10-21 05:29:07 --> Total execution time: 0.1483
DEBUG - 2022-10-21 05:29:41 --> Total execution time: 0.1452
DEBUG - 2022-10-21 05:29:43 --> Total execution time: 0.1432
DEBUG - 2022-10-21 05:29:48 --> Total execution time: 0.3827
DEBUG - 2022-10-21 05:29:54 --> Total execution time: 0.1646
DEBUG - 2022-10-21 05:30:01 --> Total execution time: 0.2047
DEBUG - 2022-10-21 05:30:03 --> Total execution time: 0.1130
DEBUG - 2022-10-21 05:31:20 --> Total execution time: 0.1563
DEBUG - 2022-10-21 05:31:22 --> Total execution time: 0.1541
DEBUG - 2022-10-21 05:31:34 --> Total execution time: 0.1958
DEBUG - 2022-10-21 05:31:43 --> Total execution time: 0.1533
DEBUG - 2022-10-21 05:31:51 --> Total execution time: 0.1578
DEBUG - 2022-10-21 05:31:52 --> Total execution time: 0.1604
DEBUG - 2022-10-21 05:31:52 --> Total execution time: 0.1555
DEBUG - 2022-10-21 05:32:13 --> Total execution time: 0.1528
DEBUG - 2022-10-21 05:32:23 --> Total execution time: 0.1719
DEBUG - 2022-10-21 05:32:25 --> Total execution time: 0.1809
DEBUG - 2022-10-21 05:32:29 --> Total execution time: 0.1530
DEBUG - 2022-10-21 05:32:45 --> Total execution time: 0.1021
DEBUG - 2022-10-21 05:32:46 --> Total execution time: 0.0916
DEBUG - 2022-10-21 05:34:45 --> Total execution time: 0.1467
DEBUG - 2022-10-21 05:38:22 --> Total execution time: 0.1629
DEBUG - 2022-10-21 05:39:00 --> Total execution time: 0.1558
DEBUG - 2022-10-21 05:39:21 --> Total execution time: 0.1503
DEBUG - 2022-10-21 05:39:27 --> Total execution time: 0.4134
DEBUG - 2022-10-21 05:39:31 --> Total execution time: 0.2003
DEBUG - 2022-10-21 05:39:56 --> Total execution time: 0.1520
DEBUG - 2022-10-21 05:40:02 --> Total execution time: 0.2214
DEBUG - 2022-10-21 05:40:22 --> Total execution time: 0.1952
DEBUG - 2022-10-21 05:40:39 --> Total execution time: 0.1869
DEBUG - 2022-10-21 05:40:49 --> Total execution time: 0.1504
DEBUG - 2022-10-21 05:40:53 --> Total execution time: 0.1529
DEBUG - 2022-10-21 05:41:00 --> Total execution time: 0.3926
DEBUG - 2022-10-21 05:41:08 --> Total execution time: 0.1504
DEBUG - 2022-10-21 05:41:15 --> Total execution time: 0.1840
DEBUG - 2022-10-21 05:41:27 --> Total execution time: 0.1460
DEBUG - 2022-10-21 05:41:31 --> Total execution time: 0.4042
DEBUG - 2022-10-21 05:41:59 --> Total execution time: 0.1504
DEBUG - 2022-10-21 05:50:00 --> Total execution time: 0.4810
DEBUG - 2022-10-21 05:55:39 --> Total execution time: 0.1881
DEBUG - 2022-10-21 05:56:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-21 05:56:50 --> Total execution time: 0.1905
DEBUG - 2022-10-21 06:13:59 --> Total execution time: 0.4687
DEBUG - 2022-10-21 06:13:59 --> Total execution time: 0.0944
DEBUG - 2022-10-21 06:13:59 --> Total execution time: 0.0966
DEBUG - 2022-10-21 06:14:00 --> Total execution time: 0.0974
DEBUG - 2022-10-21 06:14:00 --> Total execution time: 0.1474
DEBUG - 2022-10-21 06:14:00 --> Total execution time: 0.2139
DEBUG - 2022-10-21 06:14:01 --> Total execution time: 0.3254
DEBUG - 2022-10-21 06:14:01 --> Total execution time: 0.1848
DEBUG - 2022-10-21 06:14:02 --> Total execution time: 0.3823
DEBUG - 2022-10-21 06:28:32 --> Total execution time: 0.1570
DEBUG - 2022-10-21 06:30:02 --> Total execution time: 0.1024
DEBUG - 2022-10-21 06:32:17 --> Total execution time: 0.1309
DEBUG - 2022-10-21 06:32:17 --> Total execution time: 0.0942
DEBUG - 2022-10-21 06:32:40 --> Total execution time: 0.1618
DEBUG - 2022-10-21 06:47:39 --> Total execution time: 0.2631
DEBUG - 2022-10-21 06:47:40 --> Total execution time: 0.1330
DEBUG - 2022-10-21 06:47:50 --> Total execution time: 0.0935
DEBUG - 2022-10-21 06:47:59 --> Total execution time: 0.1740
DEBUG - 2022-10-21 06:48:06 --> Total execution time: 0.1741
DEBUG - 2022-10-21 06:48:13 --> Total execution time: 0.1548
DEBUG - 2022-10-21 06:48:33 --> Total execution time: 0.1500
DEBUG - 2022-10-21 06:48:37 --> Total execution time: 0.1570
DEBUG - 2022-10-21 06:57:09 --> Total execution time: 0.1612
DEBUG - 2022-10-21 07:09:55 --> Total execution time: 0.1760
DEBUG - 2022-10-21 07:11:32 --> Total execution time: 0.1474
DEBUG - 2022-10-21 07:11:52 --> Total execution time: 0.1988
DEBUG - 2022-10-21 07:15:06 --> Total execution time: 0.1624
DEBUG - 2022-10-21 07:15:21 --> Total execution time: 0.0986
DEBUG - 2022-10-21 07:16:11 --> Total execution time: 0.1757
DEBUG - 2022-10-21 07:16:17 --> Total execution time: 0.1442
DEBUG - 2022-10-21 07:21:23 --> Total execution time: 0.4774
DEBUG - 2022-10-21 07:24:24 --> Total execution time: 0.1978
DEBUG - 2022-10-21 07:24:27 --> Total execution time: 0.4684
DEBUG - 2022-10-21 07:24:36 --> Total execution time: 0.1498
DEBUG - 2022-10-21 07:24:58 --> Total execution time: 0.1800
DEBUG - 2022-10-21 07:25:10 --> Total execution time: 0.1490
DEBUG - 2022-10-21 07:25:16 --> Total execution time: 0.1662
DEBUG - 2022-10-21 07:25:29 --> Total execution time: 0.1538
DEBUG - 2022-10-21 07:26:02 --> Total execution time: 0.2205
DEBUG - 2022-10-21 07:26:28 --> Total execution time: 0.1998
DEBUG - 2022-10-21 07:27:35 --> Total execution time: 0.0941
DEBUG - 2022-10-21 07:28:26 --> Total execution time: 0.1012
DEBUG - 2022-10-21 07:29:26 --> Total execution time: 0.1022
DEBUG - 2022-10-21 07:29:50 --> Total execution time: 0.1513
DEBUG - 2022-10-21 07:29:55 --> Total execution time: 0.1493
DEBUG - 2022-10-21 07:30:03 --> Total execution time: 0.1548
DEBUG - 2022-10-21 07:30:12 --> Total execution time: 0.4866
DEBUG - 2022-10-21 07:30:26 --> Total execution time: 0.1994
DEBUG - 2022-10-21 07:30:27 --> Total execution time: 0.1851
DEBUG - 2022-10-21 07:36:56 --> Total execution time: 0.1970
DEBUG - 2022-10-21 07:38:53 --> Total execution time: 0.1430
DEBUG - 2022-10-21 07:40:18 --> Total execution time: 0.1434
DEBUG - 2022-10-21 07:45:18 --> Total execution time: 0.1621
DEBUG - 2022-10-21 07:45:26 --> Total execution time: 0.0984
DEBUG - 2022-10-21 07:46:07 --> Total execution time: 0.4090
DEBUG - 2022-10-21 07:46:18 --> Total execution time: 0.1566
DEBUG - 2022-10-21 07:46:37 --> Total execution time: 0.1412
DEBUG - 2022-10-21 07:46:40 --> Total execution time: 0.0931
DEBUG - 2022-10-21 07:46:46 --> Total execution time: 0.1438
DEBUG - 2022-10-21 07:46:53 --> Total execution time: 0.0981
DEBUG - 2022-10-21 07:47:06 --> Total execution time: 0.2087
DEBUG - 2022-10-21 07:47:20 --> Total execution time: 0.2201
DEBUG - 2022-10-21 07:47:29 --> Total execution time: 0.1498
DEBUG - 2022-10-21 07:47:41 --> Total execution time: 0.1586
DEBUG - 2022-10-21 07:47:47 --> Total execution time: 0.1565
DEBUG - 2022-10-21 07:48:17 --> Total execution time: 0.1500
DEBUG - 2022-10-21 07:48:35 --> Total execution time: 0.1625
DEBUG - 2022-10-21 07:54:04 --> Total execution time: 0.4821
DEBUG - 2022-10-21 07:54:15 --> Total execution time: 0.1619
DEBUG - 2022-10-21 07:54:17 --> Total execution time: 0.1479
DEBUG - 2022-10-21 07:55:03 --> Total execution time: 0.1035
DEBUG - 2022-10-21 07:56:48 --> Total execution time: 0.0959
DEBUG - 2022-10-21 07:56:54 --> Total execution time: 0.1659
DEBUG - 2022-10-21 07:57:31 --> Total execution time: 0.1618
DEBUG - 2022-10-21 07:57:55 --> Total execution time: 0.1989
DEBUG - 2022-10-21 07:58:18 --> Total execution time: 0.1729
DEBUG - 2022-10-21 07:59:13 --> Total execution time: 0.1431
DEBUG - 2022-10-21 08:02:31 --> Total execution time: 0.1460
DEBUG - 2022-10-21 08:02:53 --> Total execution time: 0.1381
DEBUG - 2022-10-21 08:03:11 --> Total execution time: 0.1469
DEBUG - 2022-10-21 08:03:12 --> Total execution time: 0.1796
DEBUG - 2022-10-21 08:03:19 --> Total execution time: 0.1548
DEBUG - 2022-10-21 08:03:28 --> Total execution time: 0.1462
DEBUG - 2022-10-21 08:03:36 --> Total execution time: 0.1921
DEBUG - 2022-10-21 08:03:46 --> Total execution time: 0.1832
DEBUG - 2022-10-21 08:03:58 --> Total execution time: 0.1662
DEBUG - 2022-10-21 08:04:06 --> Total execution time: 0.1867
DEBUG - 2022-10-21 08:04:12 --> Total execution time: 0.1499
DEBUG - 2022-10-21 08:04:15 --> Total execution time: 0.1509
DEBUG - 2022-10-21 08:04:16 --> Total execution time: 0.1476
DEBUG - 2022-10-21 08:05:06 --> Total execution time: 0.0997
DEBUG - 2022-10-21 08:05:10 --> Total execution time: 0.1034
DEBUG - 2022-10-21 08:07:57 --> Total execution time: 2.5731
DEBUG - 2022-10-21 08:08:46 --> Total execution time: 0.0903
DEBUG - 2022-10-21 08:08:52 --> Total execution time: 0.1535
DEBUG - 2022-10-21 08:09:04 --> Total execution time: 0.1516
DEBUG - 2022-10-21 08:09:13 --> Total execution time: 0.1529
DEBUG - 2022-10-21 08:09:17 --> Total execution time: 0.1574
DEBUG - 2022-10-21 08:09:29 --> Total execution time: 0.1631
DEBUG - 2022-10-21 08:09:44 --> Total execution time: 0.2377
DEBUG - 2022-10-21 08:09:54 --> Total execution time: 0.0926
DEBUG - 2022-10-21 08:10:45 --> Total execution time: 0.1540
DEBUG - 2022-10-21 08:11:24 --> Total execution time: 0.2127
DEBUG - 2022-10-21 08:12:05 --> Total execution time: 0.1507
DEBUG - 2022-10-21 08:12:42 --> Total execution time: 0.0963
DEBUG - 2022-10-21 08:13:45 --> Total execution time: 0.1667
DEBUG - 2022-10-21 08:13:57 --> Total execution time: 0.4379
DEBUG - 2022-10-21 08:14:59 --> Total execution time: 0.1815
DEBUG - 2022-10-21 08:15:15 --> Total execution time: 0.1510
DEBUG - 2022-10-21 08:15:28 --> Total execution time: 0.1525
DEBUG - 2022-10-21 08:15:47 --> Total execution time: 0.1563
DEBUG - 2022-10-21 08:15:58 --> Total execution time: 0.1500
DEBUG - 2022-10-21 08:16:17 --> Total execution time: 0.4282
DEBUG - 2022-10-21 08:19:00 --> Total execution time: 0.4633
DEBUG - 2022-10-21 08:19:43 --> Total execution time: 0.1481
DEBUG - 2022-10-21 08:22:55 --> Total execution time: 0.1663
DEBUG - 2022-10-21 08:30:04 --> Total execution time: 0.1603
DEBUG - 2022-10-21 08:30:29 --> Total execution time: 0.1005
DEBUG - 2022-10-21 08:30:43 --> Total execution time: 0.0975
DEBUG - 2022-10-21 08:30:54 --> Total execution time: 0.1067
DEBUG - 2022-10-21 08:31:13 --> Total execution time: 0.0992
DEBUG - 2022-10-21 08:31:34 --> Total execution time: 0.1721
DEBUG - 2022-10-21 08:31:51 --> Total execution time: 0.1555
DEBUG - 2022-10-21 08:31:56 --> Total execution time: 0.1439
DEBUG - 2022-10-21 08:32:29 --> Total execution time: 0.1654
DEBUG - 2022-10-21 08:32:31 --> Total execution time: 0.1501
DEBUG - 2022-10-21 08:33:03 --> Total execution time: 0.1397
DEBUG - 2022-10-21 08:33:04 --> Total execution time: 0.1530
DEBUG - 2022-10-21 08:33:43 --> Total execution time: 0.1693
DEBUG - 2022-10-21 08:34:11 --> Total execution time: 0.1683
DEBUG - 2022-10-21 08:34:17 --> Total execution time: 0.1564
DEBUG - 2022-10-21 08:34:31 --> Total execution time: 0.1430
DEBUG - 2022-10-21 08:39:35 --> Total execution time: 0.1606
DEBUG - 2022-10-21 08:42:28 --> Total execution time: 0.1603
DEBUG - 2022-10-21 08:42:28 --> Total execution time: 0.0984
DEBUG - 2022-10-21 08:42:35 --> Total execution time: 0.1510
DEBUG - 2022-10-21 08:42:42 --> Total execution time: 0.1448
DEBUG - 2022-10-21 08:42:50 --> Total execution time: 0.1547
DEBUG - 2022-10-21 08:42:58 --> Total execution time: 0.2046
DEBUG - 2022-10-21 08:43:22 --> Total execution time: 0.1812
DEBUG - 2022-10-21 08:43:37 --> Total execution time: 0.4148
DEBUG - 2022-10-21 08:43:43 --> Total execution time: 0.1587
DEBUG - 2022-10-21 08:43:44 --> Total execution time: 0.1534
DEBUG - 2022-10-21 08:43:52 --> Total execution time: 0.1952
DEBUG - 2022-10-21 08:43:54 --> Total execution time: 0.1470
DEBUG - 2022-10-21 08:43:58 --> Total execution time: 0.1590
DEBUG - 2022-10-21 08:44:03 --> Total execution time: 0.1788
DEBUG - 2022-10-21 08:44:03 --> Total execution time: 0.1563
DEBUG - 2022-10-21 08:45:48 --> Total execution time: 0.1630
DEBUG - 2022-10-21 08:46:00 --> Total execution time: 0.1495
DEBUG - 2022-10-21 08:46:01 --> Total execution time: 0.1622
DEBUG - 2022-10-21 08:46:03 --> Total execution time: 0.1618
DEBUG - 2022-10-21 08:48:38 --> Total execution time: 0.1488
DEBUG - 2022-10-21 08:48:39 --> Total execution time: 0.0873
DEBUG - 2022-10-21 08:51:07 --> Total execution time: 0.1640
DEBUG - 2022-10-21 08:51:08 --> Total execution time: 0.0928
DEBUG - 2022-10-21 08:51:13 --> Total execution time: 0.0940
DEBUG - 2022-10-21 08:51:19 --> Total execution time: 0.1599
DEBUG - 2022-10-21 08:51:20 --> Total execution time: 0.1465
DEBUG - 2022-10-21 08:51:27 --> Total execution time: 0.2041
DEBUG - 2022-10-21 08:59:00 --> Total execution time: 0.1705
DEBUG - 2022-10-21 08:59:39 --> Total execution time: 0.1489
DEBUG - 2022-10-21 09:00:39 --> Total execution time: 0.1098
DEBUG - 2022-10-21 09:00:40 --> Total execution time: 0.0936
DEBUG - 2022-10-21 09:01:13 --> Total execution time: 0.0910
DEBUG - 2022-10-21 09:01:38 --> Total execution time: 0.1708
DEBUG - 2022-10-21 09:01:54 --> Total execution time: 0.1488
DEBUG - 2022-10-21 09:02:00 --> Total execution time: 0.1951
DEBUG - 2022-10-21 09:02:18 --> Total execution time: 0.1375
DEBUG - 2022-10-21 09:02:19 --> Total execution time: 0.1460
DEBUG - 2022-10-21 09:02:31 --> Total execution time: 0.1506
DEBUG - 2022-10-21 09:02:36 --> Total execution time: 0.1590
DEBUG - 2022-10-21 09:03:52 --> Total execution time: 0.1475
DEBUG - 2022-10-21 09:04:00 --> Total execution time: 0.1418
DEBUG - 2022-10-21 09:04:31 --> Total execution time: 0.1535
DEBUG - 2022-10-21 09:04:44 --> Total execution time: 0.1467
DEBUG - 2022-10-21 09:04:51 --> Total execution time: 0.1907
DEBUG - 2022-10-21 09:06:45 --> Total execution time: 0.4314
DEBUG - 2022-10-21 09:06:46 --> Total execution time: 0.4203
DEBUG - 2022-10-21 09:07:39 --> Total execution time: 0.0906
DEBUG - 2022-10-21 09:07:46 --> Total execution time: 0.1509
DEBUG - 2022-10-21 09:07:47 --> Total execution time: 0.1424
DEBUG - 2022-10-21 09:07:54 --> Total execution time: 0.2288
DEBUG - 2022-10-21 09:13:58 --> Total execution time: 0.5117
DEBUG - 2022-10-21 09:14:04 --> Total execution time: 0.1778
DEBUG - 2022-10-21 09:14:14 --> Total execution time: 0.1543
DEBUG - 2022-10-21 09:14:20 --> Total execution time: 0.2010
DEBUG - 2022-10-21 09:14:31 --> Total execution time: 0.1499
DEBUG - 2022-10-21 09:14:32 --> Total execution time: 0.3898
DEBUG - 2022-10-21 09:14:53 --> Total execution time: 0.1484
DEBUG - 2022-10-21 09:15:03 --> Total execution time: 0.1637
DEBUG - 2022-10-21 09:15:09 --> Total execution time: 0.1560
DEBUG - 2022-10-21 09:15:30 --> Total execution time: 0.1445
DEBUG - 2022-10-21 09:20:18 --> Total execution time: 0.2153
DEBUG - 2022-10-21 09:21:01 --> Total execution time: 0.1888
DEBUG - 2022-10-21 09:22:48 --> Total execution time: 0.1133
DEBUG - 2022-10-21 09:22:53 --> Total execution time: 0.1469
DEBUG - 2022-10-21 09:22:54 --> Total execution time: 0.1537
DEBUG - 2022-10-21 09:22:55 --> Total execution time: 0.1447
DEBUG - 2022-10-21 09:23:49 --> Total execution time: 0.0933
DEBUG - 2022-10-21 09:23:55 --> Total execution time: 0.1769
DEBUG - 2022-10-21 09:25:54 --> Total execution time: 0.5012
DEBUG - 2022-10-21 09:27:33 --> Total execution time: 0.1721
DEBUG - 2022-10-21 09:27:35 --> Total execution time: 0.1689
DEBUG - 2022-10-21 09:27:40 --> Total execution time: 0.1516
DEBUG - 2022-10-21 09:27:43 --> Total execution time: 0.1693
DEBUG - 2022-10-21 09:28:42 --> Total execution time: 0.1758
DEBUG - 2022-10-21 09:30:01 --> Total execution time: 0.1001
DEBUG - 2022-10-21 09:30:03 --> Total execution time: 0.2087
DEBUG - 2022-10-21 09:30:10 --> Total execution time: 0.1679
DEBUG - 2022-10-21 09:30:48 --> Total execution time: 0.4206
DEBUG - 2022-10-21 09:31:35 --> Total execution time: 0.1624
DEBUG - 2022-10-21 09:31:44 --> Total execution time: 0.1542
DEBUG - 2022-10-21 09:34:54 --> Total execution time: 0.1910
DEBUG - 2022-10-21 09:35:07 --> Total execution time: 0.1963
DEBUG - 2022-10-21 09:35:18 --> Total execution time: 0.1777
DEBUG - 2022-10-21 09:35:29 --> Total execution time: 0.1567
DEBUG - 2022-10-21 09:35:30 --> Total execution time: 0.1947
DEBUG - 2022-10-21 09:43:38 --> Total execution time: 0.1773
DEBUG - 2022-10-21 09:46:01 --> Total execution time: 2.6178
DEBUG - 2022-10-21 09:46:48 --> Total execution time: 0.1866
DEBUG - 2022-10-21 09:46:50 --> Total execution time: 0.3623
DEBUG - 2022-10-21 09:47:00 --> Total execution time: 0.1594
DEBUG - 2022-10-21 09:47:09 --> Total execution time: 0.1921
DEBUG - 2022-10-21 09:47:16 --> Total execution time: 0.1488
DEBUG - 2022-10-21 09:47:18 --> Total execution time: 0.1388
DEBUG - 2022-10-21 09:47:24 --> Total execution time: 0.1547
DEBUG - 2022-10-21 09:47:32 --> Total execution time: 0.1827
DEBUG - 2022-10-21 09:47:33 --> Total execution time: 0.1418
DEBUG - 2022-10-21 09:47:35 --> Total execution time: 0.1431
DEBUG - 2022-10-21 09:47:37 --> Total execution time: 0.1463
DEBUG - 2022-10-21 09:47:43 --> Total execution time: 0.2443
DEBUG - 2022-10-21 09:47:45 --> Total execution time: 0.1567
DEBUG - 2022-10-21 09:47:51 --> Total execution time: 0.1778
DEBUG - 2022-10-21 09:48:42 --> Total execution time: 0.1899
DEBUG - 2022-10-21 09:48:46 --> Total execution time: 0.1507
DEBUG - 2022-10-21 09:49:33 --> Total execution time: 0.0943
DEBUG - 2022-10-21 09:50:38 --> Total execution time: 0.1379
DEBUG - 2022-10-21 09:51:03 --> Total execution time: 0.0977
DEBUG - 2022-10-21 09:51:11 --> Total execution time: 0.1480
DEBUG - 2022-10-21 09:51:13 --> Total execution time: 0.1661
DEBUG - 2022-10-21 09:51:22 --> Total execution time: 0.1423
DEBUG - 2022-10-21 09:51:28 --> Total execution time: 2.0352
DEBUG - 2022-10-21 09:51:31 --> Total execution time: 0.1575
DEBUG - 2022-10-21 09:51:39 --> Total execution time: 0.1620
DEBUG - 2022-10-21 09:51:48 --> Total execution time: 0.1103
DEBUG - 2022-10-21 09:51:48 --> Total execution time: 0.1590
DEBUG - 2022-10-21 09:51:56 --> Total execution time: 0.1493
DEBUG - 2022-10-21 09:52:00 --> Total execution time: 0.1509
DEBUG - 2022-10-21 09:52:10 --> Total execution time: 0.1539
DEBUG - 2022-10-21 09:52:20 --> Total execution time: 0.3957
DEBUG - 2022-10-21 09:52:23 --> Total execution time: 0.1901
DEBUG - 2022-10-21 09:52:26 --> Total execution time: 0.1482
DEBUG - 2022-10-21 09:52:42 --> Total execution time: 0.1494
DEBUG - 2022-10-21 09:53:43 --> Total execution time: 0.1581
DEBUG - 2022-10-21 09:53:56 --> Total execution time: 0.1478
DEBUG - 2022-10-21 09:53:57 --> Total execution time: 0.1539
DEBUG - 2022-10-21 09:53:57 --> Total execution time: 0.1466
DEBUG - 2022-10-21 09:54:07 --> Total execution time: 0.1758
DEBUG - 2022-10-21 09:54:18 --> Total execution time: 0.1549
DEBUG - 2022-10-21 09:54:30 --> Total execution time: 0.1710
DEBUG - 2022-10-21 10:02:51 --> Total execution time: 0.1928
DEBUG - 2022-10-21 10:02:55 --> Total execution time: 0.1072
DEBUG - 2022-10-21 10:03:19 --> Total execution time: 0.1746
DEBUG - 2022-10-21 10:03:32 --> Total execution time: 0.1577
DEBUG - 2022-10-21 10:03:50 --> Total execution time: 0.1995
DEBUG - 2022-10-21 10:04:52 --> Total execution time: 0.4143
DEBUG - 2022-10-21 10:07:21 --> Total execution time: 0.2588
DEBUG - 2022-10-21 10:08:06 --> Total execution time: 0.4043
DEBUG - 2022-10-21 10:08:15 --> Total execution time: 0.1487
DEBUG - 2022-10-21 10:08:34 --> Total execution time: 0.3842
DEBUG - 2022-10-21 10:09:37 --> Total execution time: 0.1512
DEBUG - 2022-10-21 10:10:30 --> Total execution time: 0.4531
DEBUG - 2022-10-21 10:11:27 --> Total execution time: 0.1214
DEBUG - 2022-10-21 10:11:43 --> Total execution time: 0.4046
DEBUG - 2022-10-21 10:12:04 --> Total execution time: 0.4071
DEBUG - 2022-10-21 10:14:34 --> Total execution time: 0.2004
DEBUG - 2022-10-21 10:14:36 --> Total execution time: 0.1505
DEBUG - 2022-10-21 10:14:57 --> Total execution time: 0.0954
DEBUG - 2022-10-21 10:15:18 --> Total execution time: 0.1566
DEBUG - 2022-10-21 10:15:32 --> Total execution time: 0.0990
DEBUG - 2022-10-21 10:16:20 --> Total execution time: 0.1233
DEBUG - 2022-10-21 10:17:47 --> Total execution time: 0.4165
DEBUG - 2022-10-21 10:18:12 --> Total execution time: 0.1454
DEBUG - 2022-10-21 10:18:40 --> Total execution time: 0.1444
DEBUG - 2022-10-21 10:20:38 --> Total execution time: 0.1491
DEBUG - 2022-10-21 10:21:06 --> Total execution time: 0.1486
DEBUG - 2022-10-21 10:21:36 --> Total execution time: 0.1554
DEBUG - 2022-10-21 10:22:51 --> Total execution time: 0.1878
DEBUG - 2022-10-21 10:23:12 --> Total execution time: 0.1869
DEBUG - 2022-10-21 10:26:07 --> Total execution time: 0.1008
DEBUG - 2022-10-21 10:28:03 --> Total execution time: 0.1227
DEBUG - 2022-10-21 10:28:05 --> Total execution time: 0.1488
DEBUG - 2022-10-21 10:28:14 --> Total execution time: 0.1830
DEBUG - 2022-10-21 10:28:36 --> Total execution time: 0.0917
DEBUG - 2022-10-21 10:29:39 --> Total execution time: 0.1586
DEBUG - 2022-10-21 10:29:46 --> Total execution time: 0.1590
DEBUG - 2022-10-21 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:30:04 --> Total execution time: 0.1586
DEBUG - 2022-10-21 00:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:30:09 --> Total execution time: 0.1815
DEBUG - 2022-10-21 00:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:30:45 --> Total execution time: 0.1573
DEBUG - 2022-10-21 00:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:15 --> Total execution time: 0.1110
DEBUG - 2022-10-21 00:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:22 --> Total execution time: 0.1679
DEBUG - 2022-10-21 00:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:29 --> Total execution time: 0.2424
DEBUG - 2022-10-21 00:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:30 --> Total execution time: 0.1710
DEBUG - 2022-10-21 00:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:36 --> Total execution time: 0.1507
DEBUG - 2022-10-21 00:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:37 --> Total execution time: 0.1438
DEBUG - 2022-10-21 00:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:49 --> Total execution time: 0.1879
DEBUG - 2022-10-21 00:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:53 --> Total execution time: 0.1694
DEBUG - 2022-10-21 00:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:32:06 --> Total execution time: 0.2242
DEBUG - 2022-10-21 00:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:32:40 --> Total execution time: 0.1545
DEBUG - 2022-10-21 00:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:32:41 --> Total execution time: 0.1412
DEBUG - 2022-10-21 00:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:33:09 --> Total execution time: 0.1449
DEBUG - 2022-10-21 00:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:33:12 --> Total execution time: 0.1878
DEBUG - 2022-10-21 00:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:34:19 --> Total execution time: 0.1705
DEBUG - 2022-10-21 00:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:34:34 --> Total execution time: 0.1600
DEBUG - 2022-10-21 00:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:06:04 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:36:04 --> Total execution time: 0.1044
DEBUG - 2022-10-21 00:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:37:58 --> Total execution time: 0.4147
DEBUG - 2022-10-21 00:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:41:11 --> Total execution time: 0.2376
DEBUG - 2022-10-21 00:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:41:55 --> Total execution time: 0.1543
DEBUG - 2022-10-21 00:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:42:06 --> Total execution time: 0.1621
DEBUG - 2022-10-21 00:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:13:04 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:43:04 --> Total execution time: 0.0950
DEBUG - 2022-10-21 00:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:49:18 --> Total execution time: 0.1422
DEBUG - 2022-10-21 00:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:53:42 --> Total execution time: 0.4731
DEBUG - 2022-10-21 00:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:53:54 --> Total execution time: 0.2398
DEBUG - 2022-10-21 00:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:54:12 --> Total execution time: 0.2031
DEBUG - 2022-10-21 00:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:55:15 --> Total execution time: 0.1563
DEBUG - 2022-10-21 00:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:55:28 --> Total execution time: 0.1608
DEBUG - 2022-10-21 00:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:55:46 --> Total execution time: 0.1563
DEBUG - 2022-10-21 00:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:56:34 --> Total execution time: 0.1604
DEBUG - 2022-10-21 00:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:56:46 --> Total execution time: 0.1755
DEBUG - 2022-10-21 00:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:57:14 --> Total execution time: 0.1882
DEBUG - 2022-10-21 00:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:57:25 --> Total execution time: 0.1513
DEBUG - 2022-10-21 00:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:27:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:57:42 --> Total execution time: 0.1602
DEBUG - 2022-10-21 00:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:28:25 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:58:25 --> Total execution time: 0.0975
DEBUG - 2022-10-21 00:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:58:35 --> Total execution time: 0.1439
DEBUG - 2022-10-21 00:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:28:36 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:58:36 --> Total execution time: 0.4023
DEBUG - 2022-10-21 00:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:58:49 --> Total execution time: 0.1553
DEBUG - 2022-10-21 00:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:29:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:59:08 --> Total execution time: 0.1530
DEBUG - 2022-10-21 00:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:59:12 --> Total execution time: 0.1549
DEBUG - 2022-10-21 00:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:59:21 --> Total execution time: 0.1950
DEBUG - 2022-10-21 00:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:59:55 --> Total execution time: 0.1535
DEBUG - 2022-10-21 00:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:00:07 --> Total execution time: 0.2243
DEBUG - 2022-10-21 00:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:00:24 --> Total execution time: 0.1503
DEBUG - 2022-10-21 00:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:00:30 --> Total execution time: 0.1428
DEBUG - 2022-10-21 00:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:01:27 --> Total execution time: 0.4229
DEBUG - 2022-10-21 00:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:01:35 --> Total execution time: 0.1904
DEBUG - 2022-10-21 00:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:01:54 --> Total execution time: 0.1781
DEBUG - 2022-10-21 00:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:32:34 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:02:34 --> Total execution time: 0.1031
DEBUG - 2022-10-21 00:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:04:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-21 00:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:06:07 --> Total execution time: 0.2055
DEBUG - 2022-10-21 00:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:36:08 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:06:08 --> Total execution time: 0.1052
DEBUG - 2022-10-21 00:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:06:09 --> Total execution time: 0.1514
DEBUG - 2022-10-21 00:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:06:16 --> Total execution time: 0.1053
DEBUG - 2022-10-21 00:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:06:18 --> Total execution time: 0.2452
DEBUG - 2022-10-21 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:06:34 --> Total execution time: 0.1453
DEBUG - 2022-10-21 00:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:07:03 --> Total execution time: 0.1528
DEBUG - 2022-10-21 00:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:07:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-21 00:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:07:24 --> Total execution time: 0.1947
DEBUG - 2022-10-21 00:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:07:27 --> Total execution time: 0.1538
DEBUG - 2022-10-21 00:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:07:51 --> Total execution time: 0.1526
DEBUG - 2022-10-21 00:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:08:07 --> Total execution time: 0.1456
DEBUG - 2022-10-21 00:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:10:36 --> Total execution time: 0.1828
DEBUG - 2022-10-21 00:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:10:38 --> Total execution time: 0.1606
DEBUG - 2022-10-21 00:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:10:50 --> Total execution time: 0.1796
DEBUG - 2022-10-21 00:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:10:51 --> Total execution time: 0.1547
DEBUG - 2022-10-21 00:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:11:30 --> Total execution time: 0.4270
DEBUG - 2022-10-21 00:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:11:56 --> Total execution time: 0.1784
DEBUG - 2022-10-21 00:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:41:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:11:58 --> Total execution time: 0.1090
DEBUG - 2022-10-21 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:12:04 --> Total execution time: 0.1503
DEBUG - 2022-10-21 00:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:12:05 --> Total execution time: 0.1877
DEBUG - 2022-10-21 00:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:12:14 --> Total execution time: 0.1797
DEBUG - 2022-10-21 00:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:12:19 --> Total execution time: 0.1558
DEBUG - 2022-10-21 00:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:12:29 --> Total execution time: 0.4689
DEBUG - 2022-10-21 00:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:43:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:43:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:13:01 --> Total execution time: 0.0945
DEBUG - 2022-10-21 00:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:13:01 --> Total execution time: 0.0975
DEBUG - 2022-10-21 00:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:13:10 --> Total execution time: 0.4199
DEBUG - 2022-10-21 00:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:13:12 --> Total execution time: 0.1584
DEBUG - 2022-10-21 00:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:13:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-21 00:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:13:52 --> Total execution time: 0.1780
DEBUG - 2022-10-21 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:14:02 --> Total execution time: 0.2558
DEBUG - 2022-10-21 00:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:14:08 --> Total execution time: 0.1996
DEBUG - 2022-10-21 00:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:15:27 --> Total execution time: 0.2636
DEBUG - 2022-10-21 00:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:16:22 --> Total execution time: 0.4067
DEBUG - 2022-10-21 00:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:16:26 --> Total execution time: 0.1565
DEBUG - 2022-10-21 00:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:46:40 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:16:40 --> Total execution time: 0.4002
DEBUG - 2022-10-21 00:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:16:40 --> Total execution time: 0.1688
DEBUG - 2022-10-21 00:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:16:58 --> Total execution time: 0.1611
DEBUG - 2022-10-21 00:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:47:41 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:17:41 --> Total execution time: 0.1744
DEBUG - 2022-10-21 00:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:18:00 --> Total execution time: 0.1961
DEBUG - 2022-10-21 00:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:48:04 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:18:04 --> Total execution time: 0.1570
DEBUG - 2022-10-21 00:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:18:14 --> Total execution time: 0.1844
DEBUG - 2022-10-21 00:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:48:28 --> Total execution time: 0.0993
DEBUG - 2022-10-21 00:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:19:00 --> Total execution time: 0.1902
DEBUG - 2022-10-21 00:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:20:00 --> Total execution time: 0.1641
DEBUG - 2022-10-21 00:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:20:46 --> Total execution time: 0.1618
DEBUG - 2022-10-21 00:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:22:01 --> Total execution time: 0.4117
DEBUG - 2022-10-21 00:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:23:24 --> Total execution time: 0.1969
DEBUG - 2022-10-21 00:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:54:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:24:26 --> Total execution time: 0.1523
DEBUG - 2022-10-21 00:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:24:34 --> Total execution time: 0.1515
DEBUG - 2022-10-21 00:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:55:36 --> No URI present. Default controller set.
DEBUG - 2022-10-21 00:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:25:36 --> Total execution time: 0.1043
DEBUG - 2022-10-21 00:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 00:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:26:02 --> Total execution time: 0.1609
DEBUG - 2022-10-21 00:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:26:12 --> Total execution time: 0.1849
DEBUG - 2022-10-21 00:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:26:13 --> Total execution time: 0.1485
DEBUG - 2022-10-21 00:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:26:23 --> Total execution time: 0.1426
DEBUG - 2022-10-21 00:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:26:46 --> Total execution time: 0.1499
DEBUG - 2022-10-21 00:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:27:49 --> Total execution time: 0.3950
DEBUG - 2022-10-21 00:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:28:02 --> Total execution time: 0.1803
DEBUG - 2022-10-21 00:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 00:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 00:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:28:14 --> Total execution time: 0.1550
DEBUG - 2022-10-21 01:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:30:08 --> Total execution time: 0.1123
DEBUG - 2022-10-21 01:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:00:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:30:26 --> Total execution time: 0.1091
DEBUG - 2022-10-21 01:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:32:10 --> Total execution time: 0.1856
DEBUG - 2022-10-21 01:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:32:22 --> Total execution time: 0.1512
DEBUG - 2022-10-21 01:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:32:33 --> Total execution time: 0.1559
DEBUG - 2022-10-21 01:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:32:36 --> Total execution time: 0.1596
DEBUG - 2022-10-21 01:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:32:47 --> Total execution time: 0.1798
DEBUG - 2022-10-21 01:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:33:06 --> Total execution time: 0.4100
DEBUG - 2022-10-21 01:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:34:19 --> Total execution time: 0.4547
DEBUG - 2022-10-21 01:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:34:40 --> Total execution time: 0.1533
DEBUG - 2022-10-21 01:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:34:42 --> Total execution time: 0.1628
DEBUG - 2022-10-21 01:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:34:49 --> Total execution time: 0.2274
DEBUG - 2022-10-21 01:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:35:00 --> Total execution time: 0.1441
DEBUG - 2022-10-21 01:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:05:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:35:13 --> Total execution time: 0.1476
DEBUG - 2022-10-21 01:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:05:23 --> Total execution time: 0.1479
DEBUG - 2022-10-21 01:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:05:27 --> Total execution time: 0.2096
DEBUG - 2022-10-21 01:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:05:28 --> Total execution time: 0.1554
DEBUG - 2022-10-21 01:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:36:49 --> Total execution time: 2.7626
DEBUG - 2022-10-21 01:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:06:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:06:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 01:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:37:47 --> Total execution time: 0.1548
DEBUG - 2022-10-21 01:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:37:50 --> Total execution time: 0.3184
DEBUG - 2022-10-21 01:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:37:56 --> Total execution time: 0.1666
DEBUG - 2022-10-21 01:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:08:07 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 01:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:08:08 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-10-21 01:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:38:13 --> Total execution time: 0.1500
DEBUG - 2022-10-21 01:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:38:24 --> Total execution time: 0.1507
DEBUG - 2022-10-21 01:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:38:34 --> Total execution time: 0.1982
DEBUG - 2022-10-21 01:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:39:07 --> Total execution time: 0.1455
DEBUG - 2022-10-21 01:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:40:18 --> Total execution time: 0.1436
DEBUG - 2022-10-21 01:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:40:26 --> Total execution time: 0.1925
DEBUG - 2022-10-21 01:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:40:31 --> Total execution time: 0.1492
DEBUG - 2022-10-21 01:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:41:45 --> Total execution time: 2.2385
DEBUG - 2022-10-21 01:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:07 --> Total execution time: 0.4003
DEBUG - 2022-10-21 01:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:13:34 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:34 --> Total execution time: 0.0974
DEBUG - 2022-10-21 01:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:55 --> Total execution time: 0.1623
DEBUG - 2022-10-21 01:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:44:09 --> Total execution time: 0.1623
DEBUG - 2022-10-21 01:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:44:18 --> Total execution time: 0.1945
DEBUG - 2022-10-21 01:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:44:42 --> Total execution time: 0.4190
DEBUG - 2022-10-21 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:44:52 --> Total execution time: 0.1566
DEBUG - 2022-10-21 01:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:45:20 --> Total execution time: 0.1760
DEBUG - 2022-10-21 01:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:22 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:45:22 --> Total execution time: 0.0991
DEBUG - 2022-10-21 01:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:45:31 --> Total execution time: 0.1694
DEBUG - 2022-10-21 01:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:45:33 --> Total execution time: 0.1447
DEBUG - 2022-10-21 01:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:45:43 --> Total execution time: 0.1637
DEBUG - 2022-10-21 01:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:45:45 --> Total execution time: 0.1581
DEBUG - 2022-10-21 01:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:45:50 --> Total execution time: 0.1692
DEBUG - 2022-10-21 01:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:46:03 --> Total execution time: 0.1530
DEBUG - 2022-10-21 01:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:46:09 --> Total execution time: 0.1679
DEBUG - 2022-10-21 01:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:46:10 --> Total execution time: 0.1961
DEBUG - 2022-10-21 01:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:46:10 --> Total execution time: 0.1509
DEBUG - 2022-10-21 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:46:39 --> Total execution time: 0.1830
DEBUG - 2022-10-21 01:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:16:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:16:43 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 01:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:47:04 --> Total execution time: 0.2860
DEBUG - 2022-10-21 01:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:47:31 --> Total execution time: 0.1758
DEBUG - 2022-10-21 01:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:47:46 --> Total execution time: 0.1633
DEBUG - 2022-10-21 01:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:47:47 --> Total execution time: 0.1698
DEBUG - 2022-10-21 01:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:47:48 --> Total execution time: 0.1716
DEBUG - 2022-10-21 01:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:47:58 --> Total execution time: 0.1966
DEBUG - 2022-10-21 01:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:18:08 --> Total execution time: 0.1406
DEBUG - 2022-10-21 01:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:18:11 --> Total execution time: 0.1497
DEBUG - 2022-10-21 01:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:18:11 --> Total execution time: 0.1563
DEBUG - 2022-10-21 01:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:48:21 --> Total execution time: 0.2078
DEBUG - 2022-10-21 01:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:48:32 --> Total execution time: 0.1839
DEBUG - 2022-10-21 01:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:52:49 --> Total execution time: 0.4681
DEBUG - 2022-10-21 01:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:23:15 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:53:15 --> Total execution time: 0.0957
DEBUG - 2022-10-21 01:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:53:31 --> Total execution time: 0.1561
DEBUG - 2022-10-21 01:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:53:55 --> Total execution time: 0.1455
DEBUG - 2022-10-21 01:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:15 --> Total execution time: 0.0950
DEBUG - 2022-10-21 01:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:28 --> Total execution time: 0.1582
DEBUG - 2022-10-21 01:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:42 --> Total execution time: 0.1452
DEBUG - 2022-10-21 01:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:54 --> Total execution time: 0.1589
DEBUG - 2022-10-21 01:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:58 --> Total execution time: 0.1594
DEBUG - 2022-10-21 01:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:55:54 --> Total execution time: 0.1478
DEBUG - 2022-10-21 01:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:56:12 --> Total execution time: 0.2134
DEBUG - 2022-10-21 01:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:56:22 --> Total execution time: 0.4818
DEBUG - 2022-10-21 01:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:29:34 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:59:35 --> Total execution time: 0.1670
DEBUG - 2022-10-21 01:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:29:53 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:59:53 --> Total execution time: 0.1755
DEBUG - 2022-10-21 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:59:56 --> Total execution time: 0.1542
DEBUG - 2022-10-21 01:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:03 --> Total execution time: 0.2083
DEBUG - 2022-10-21 01:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:07 --> Total execution time: 0.1988
DEBUG - 2022-10-21 01:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:13 --> Total execution time: 0.1771
DEBUG - 2022-10-21 01:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:13 --> Total execution time: 0.1938
DEBUG - 2022-10-21 01:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:26 --> Total execution time: 0.1549
DEBUG - 2022-10-21 01:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:31 --> Total execution time: 0.0976
DEBUG - 2022-10-21 01:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:36 --> Total execution time: 0.1444
DEBUG - 2022-10-21 01:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:31:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:01:26 --> Total execution time: 0.1240
DEBUG - 2022-10-21 01:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:01:32 --> Total execution time: 0.1602
DEBUG - 2022-10-21 01:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:01:36 --> Total execution time: 0.1496
DEBUG - 2022-10-21 01:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:01:57 --> Total execution time: 0.1452
DEBUG - 2022-10-21 01:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:32:01 --> Total execution time: 0.1523
DEBUG - 2022-10-21 01:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:32:03 --> Total execution time: 0.2479
DEBUG - 2022-10-21 01:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:32:04 --> Total execution time: 0.1613
DEBUG - 2022-10-21 01:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:02:23 --> Total execution time: 0.1603
DEBUG - 2022-10-21 01:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:02:32 --> Total execution time: 0.1522
DEBUG - 2022-10-21 01:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:02:41 --> Total execution time: 0.1644
DEBUG - 2022-10-21 01:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:03:46 --> Total execution time: 0.1533
DEBUG - 2022-10-21 01:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:04:08 --> Total execution time: 0.1648
DEBUG - 2022-10-21 01:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:04:15 --> Total execution time: 0.1634
DEBUG - 2022-10-21 01:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:04:41 --> Total execution time: 0.1759
DEBUG - 2022-10-21 01:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:04:54 --> Total execution time: 0.1549
DEBUG - 2022-10-21 01:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:34:59 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:04:59 --> Total execution time: 0.1267
DEBUG - 2022-10-21 01:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:35:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:05:31 --> Total execution time: 0.0935
DEBUG - 2022-10-21 01:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:05:36 --> Total execution time: 0.1005
DEBUG - 2022-10-21 01:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:05:41 --> Total execution time: 0.1471
DEBUG - 2022-10-21 01:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:05:42 --> Total execution time: 0.1548
DEBUG - 2022-10-21 01:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:05:47 --> Total execution time: 0.1902
DEBUG - 2022-10-21 01:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:07:09 --> Total execution time: 2.3704
DEBUG - 2022-10-21 01:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:37:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 01:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:40:12 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:13 --> Total execution time: 0.5173
DEBUG - 2022-10-21 01:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:17 --> Total execution time: 0.1000
DEBUG - 2022-10-21 01:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:26 --> Total execution time: 0.2420
DEBUG - 2022-10-21 01:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:33 --> Total execution time: 0.2493
DEBUG - 2022-10-21 01:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:39 --> Total execution time: 0.1636
DEBUG - 2022-10-21 01:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:46 --> Total execution time: 0.2110
DEBUG - 2022-10-21 01:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:52 --> Total execution time: 0.2296
DEBUG - 2022-10-21 01:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:11:23 --> Total execution time: 0.1429
DEBUG - 2022-10-21 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:11:52 --> Total execution time: 0.1893
DEBUG - 2022-10-21 01:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:12:12 --> Total execution time: 0.1777
DEBUG - 2022-10-21 01:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:12:33 --> Total execution time: 0.2665
DEBUG - 2022-10-21 01:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:12:39 --> Total execution time: 0.1631
DEBUG - 2022-10-21 01:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:12:43 --> Total execution time: 0.1633
DEBUG - 2022-10-21 01:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:43:06 --> 404 Page Not Found: Wp-commentinphp/index
DEBUG - 2022-10-21 01:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:43:09 --> 404 Page Not Found: Wp-commentinphp/index
DEBUG - 2022-10-21 01:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:43:16 --> 404 Page Not Found: Wp-admin/shell20211028.php
DEBUG - 2022-10-21 01:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 01:43:19 --> 404 Page Not Found: Wp-admin/shell20211028.php
DEBUG - 2022-10-21 01:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:13:26 --> Total execution time: 0.0986
DEBUG - 2022-10-21 01:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:13:45 --> Total execution time: 0.0946
DEBUG - 2022-10-21 01:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:13:53 --> Total execution time: 0.0965
DEBUG - 2022-10-21 01:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:13:55 --> Total execution time: 0.0849
DEBUG - 2022-10-21 01:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:13:55 --> Total execution time: 0.1000
DEBUG - 2022-10-21 01:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:14:10 --> Total execution time: 0.1734
DEBUG - 2022-10-21 01:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:14:13 --> Total execution time: 0.1006
DEBUG - 2022-10-21 01:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:14:49 --> Total execution time: 0.1560
DEBUG - 2022-10-21 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:22 --> Total execution time: 0.1992
DEBUG - 2022-10-21 01:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:22 --> Total execution time: 0.1528
DEBUG - 2022-10-21 01:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:27 --> Total execution time: 0.1927
DEBUG - 2022-10-21 01:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:30 --> Total execution time: 0.0969
DEBUG - 2022-10-21 01:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:30 --> Total execution time: 0.1795
DEBUG - 2022-10-21 01:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:33 --> Total execution time: 0.1936
DEBUG - 2022-10-21 01:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:42 --> Total execution time: 0.1630
DEBUG - 2022-10-21 01:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:48 --> Total execution time: 0.1812
DEBUG - 2022-10-21 01:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:15:58 --> Total execution time: 0.2087
DEBUG - 2022-10-21 01:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:47:40 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:17:40 --> Total execution time: 0.4259
DEBUG - 2022-10-21 01:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:17:44 --> Total execution time: 0.0970
DEBUG - 2022-10-21 01:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:17:53 --> Total execution time: 0.1547
DEBUG - 2022-10-21 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:17:54 --> Total execution time: 0.1490
DEBUG - 2022-10-21 01:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:18:02 --> Total execution time: 0.3150
DEBUG - 2022-10-21 01:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:50:10 --> Total execution time: 0.4523
DEBUG - 2022-10-21 01:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:51:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:21:55 --> Total execution time: 0.1046
DEBUG - 2022-10-21 01:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:52:18 --> Total execution time: 0.1485
DEBUG - 2022-10-21 01:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:52:35 --> Total execution time: 0.1919
DEBUG - 2022-10-21 01:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:52:41 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:22:41 --> Total execution time: 0.1178
DEBUG - 2022-10-21 01:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:52:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:22:42 --> Total execution time: 0.0996
DEBUG - 2022-10-21 01:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:53:15 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:23:15 --> Total execution time: 0.1303
DEBUG - 2022-10-21 01:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:53:40 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:23:41 --> Total execution time: 0.4178
DEBUG - 2022-10-21 01:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:23:53 --> Total execution time: 0.1588
DEBUG - 2022-10-21 01:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:24:12 --> Total execution time: 0.1503
DEBUG - 2022-10-21 01:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:55:38 --> No URI present. Default controller set.
DEBUG - 2022-10-21 01:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:25:38 --> Total execution time: 0.1555
DEBUG - 2022-10-21 01:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:25:45 --> Total execution time: 0.1504
DEBUG - 2022-10-21 01:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 01:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:26:18 --> Total execution time: 0.1943
DEBUG - 2022-10-21 01:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:27:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-21 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:27:27 --> Total execution time: 0.2422
DEBUG - 2022-10-21 01:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:27:50 --> Total execution time: 0.1852
DEBUG - 2022-10-21 01:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:27:51 --> Total execution time: 0.2006
DEBUG - 2022-10-21 01:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:28:38 --> Total execution time: 0.3935
DEBUG - 2022-10-21 01:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:28:50 --> Total execution time: 0.0952
DEBUG - 2022-10-21 01:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:28:51 --> Total execution time: 0.1707
DEBUG - 2022-10-21 01:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 01:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 01:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:29:35 --> Total execution time: 0.1741
DEBUG - 2022-10-21 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:30:02 --> Total execution time: 0.1924
DEBUG - 2022-10-21 02:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:01:39 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:31:39 --> Total execution time: 0.1626
DEBUG - 2022-10-21 02:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 02:02:28 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:38:30 --> Total execution time: 1.0107
DEBUG - 2022-10-21 02:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:38:35 --> Total execution time: 0.1605
DEBUG - 2022-10-21 02:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:08:43 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:38:43 --> Total execution time: 0.1592
DEBUG - 2022-10-21 02:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:39:05 --> Total execution time: 0.1926
DEBUG - 2022-10-21 02:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:39:09 --> Total execution time: 0.1451
DEBUG - 2022-10-21 02:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:09:14 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:39:15 --> Total execution time: 0.4009
DEBUG - 2022-10-21 02:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:09:22 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:39:22 --> Total execution time: 0.1507
DEBUG - 2022-10-21 02:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:11:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 02:11:55 --> 404 Page Not Found: _ignition/health-check
DEBUG - 2022-10-21 02:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:11:56 --> Total execution time: 0.1611
DEBUG - 2022-10-21 02:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 02:11:58 --> 404 Page Not Found: Public/_ignition
DEBUG - 2022-10-21 02:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:11:58 --> Total execution time: 0.2201
DEBUG - 2022-10-21 02:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:13:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:43:02 --> Total execution time: 0.0983
DEBUG - 2022-10-21 02:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:45:05 --> Total execution time: 0.3984
DEBUG - 2022-10-21 02:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:48:25 --> Total execution time: 0.5172
DEBUG - 2022-10-21 02:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:48:26 --> Total execution time: 0.0886
DEBUG - 2022-10-21 02:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:49:14 --> Total execution time: 0.1876
DEBUG - 2022-10-21 02:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:49:55 --> Total execution time: 0.2108
DEBUG - 2022-10-21 02:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:50:09 --> Total execution time: 0.2523
DEBUG - 2022-10-21 02:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:20:17 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:50:18 --> Total execution time: 0.4272
DEBUG - 2022-10-21 02:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:20:39 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:50:40 --> Total execution time: 0.0977
DEBUG - 2022-10-21 02:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:21:25 --> Total execution time: 0.1474
DEBUG - 2022-10-21 02:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:21:27 --> Total execution time: 0.1625
DEBUG - 2022-10-21 02:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:21:28 --> Total execution time: 0.1548
DEBUG - 2022-10-21 02:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:21:29 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:51:29 --> Total execution time: 0.0942
DEBUG - 2022-10-21 02:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:22:16 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:52:16 --> Total execution time: 0.1509
DEBUG - 2022-10-21 02:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:22:21 --> Total execution time: 0.1423
DEBUG - 2022-10-21 02:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:22:23 --> Total execution time: 0.1529
DEBUG - 2022-10-21 02:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:22:24 --> Total execution time: 0.1753
DEBUG - 2022-10-21 02:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:22:48 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:52:49 --> Total execution time: 0.1526
DEBUG - 2022-10-21 02:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:22:54 --> Total execution time: 0.1519
DEBUG - 2022-10-21 02:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:22:56 --> Total execution time: 0.1897
DEBUG - 2022-10-21 02:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:22:57 --> Total execution time: 0.1858
DEBUG - 2022-10-21 02:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:23:04 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:53:05 --> Total execution time: 0.0951
DEBUG - 2022-10-21 02:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:23:15 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:53:15 --> Total execution time: 0.0943
DEBUG - 2022-10-21 02:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:53:30 --> Total execution time: 4.2685
DEBUG - 2022-10-21 02:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 02:23:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 02:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:23:51 --> Total execution time: 0.1486
DEBUG - 2022-10-21 02:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:23:54 --> Total execution time: 0.1500
DEBUG - 2022-10-21 02:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:23:54 --> Total execution time: 0.1508
DEBUG - 2022-10-21 02:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:24:05 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:54:05 --> Total execution time: 0.1526
DEBUG - 2022-10-21 02:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:54:40 --> Total execution time: 0.1441
DEBUG - 2022-10-21 02:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:54:48 --> Total execution time: 0.1511
DEBUG - 2022-10-21 02:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:54:56 --> Total execution time: 0.1876
DEBUG - 2022-10-21 02:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:25:22 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:55:22 --> Total execution time: 0.1554
DEBUG - 2022-10-21 02:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:55:30 --> Total execution time: 0.1965
DEBUG - 2022-10-21 02:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:25:50 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:55:50 --> Total execution time: 0.3969
DEBUG - 2022-10-21 02:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:09 --> Total execution time: 0.1957
DEBUG - 2022-10-21 02:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:10 --> Total execution time: 0.4196
DEBUG - 2022-10-21 02:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:26:13 --> Total execution time: 0.1505
DEBUG - 2022-10-21 02:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:14 --> Total execution time: 0.1590
DEBUG - 2022-10-21 02:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:18 --> Total execution time: 0.1759
DEBUG - 2022-10-21 02:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:20 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:20 --> Total execution time: 0.0981
DEBUG - 2022-10-21 02:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:21 --> Total execution time: 0.2006
DEBUG - 2022-10-21 02:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:24 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:24 --> Total execution time: 0.0960
DEBUG - 2022-10-21 02:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:30 --> Total execution time: 0.2011
DEBUG - 2022-10-21 12:56:30 --> Total execution time: 0.1805
DEBUG - 2022-10-21 02:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:37 --> Total execution time: 0.2200
DEBUG - 2022-10-21 02:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:38 --> Total execution time: 0.1487
DEBUG - 2022-10-21 02:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:39 --> Total execution time: 0.1477
DEBUG - 2022-10-21 02:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:48 --> Total execution time: 0.1543
DEBUG - 2022-10-21 02:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:26:57 --> Total execution time: 0.1560
DEBUG - 2022-10-21 02:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:59 --> Total execution time: 0.1509
DEBUG - 2022-10-21 02:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:27:11 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:57:11 --> Total execution time: 0.1504
DEBUG - 2022-10-21 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:57:18 --> Total execution time: 0.1603
DEBUG - 2022-10-21 02:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:57:43 --> Total execution time: 0.1620
DEBUG - 2022-10-21 02:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:57:49 --> Total execution time: 0.1551
DEBUG - 2022-10-21 02:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:57:50 --> Total execution time: 0.1554
DEBUG - 2022-10-21 02:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:06 --> Total execution time: 0.1801
DEBUG - 2022-10-21 02:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:14 --> Total execution time: 0.1607
DEBUG - 2022-10-21 02:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:15 --> Total execution time: 0.1616
DEBUG - 2022-10-21 02:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:15 --> Total execution time: 0.1664
DEBUG - 2022-10-21 02:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:16 --> Total execution time: 0.1603
DEBUG - 2022-10-21 02:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:19 --> Total execution time: 0.1978
DEBUG - 2022-10-21 02:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:21 --> Total execution time: 0.1978
DEBUG - 2022-10-21 02:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:23 --> Total execution time: 0.1603
DEBUG - 2022-10-21 02:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:28:24 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:58:25 --> Total execution time: 0.1482
DEBUG - 2022-10-21 02:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:59:54 --> Total execution time: 0.0977
DEBUG - 2022-10-21 02:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:31:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:01:55 --> Total execution time: 0.1001
DEBUG - 2022-10-21 02:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:04:46 --> Total execution time: 0.1521
DEBUG - 2022-10-21 02:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:05:11 --> Total execution time: 0.3942
DEBUG - 2022-10-21 02:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:13:02 --> Total execution time: 0.1456
DEBUG - 2022-10-21 02:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:13:15 --> Total execution time: 0.1698
DEBUG - 2022-10-21 02:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:13:19 --> Total execution time: 0.1999
DEBUG - 2022-10-21 02:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:13:44 --> Total execution time: 0.1741
DEBUG - 2022-10-21 02:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:14:00 --> Total execution time: 0.2123
DEBUG - 2022-10-21 02:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:14:10 --> Total execution time: 0.2894
DEBUG - 2022-10-21 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:14:32 --> Total execution time: 0.1609
DEBUG - 2022-10-21 02:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:14:40 --> Total execution time: 0.1967
DEBUG - 2022-10-21 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:14:49 --> Total execution time: 0.1888
DEBUG - 2022-10-21 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:19:39 --> Total execution time: 0.4871
DEBUG - 2022-10-21 02:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:19:41 --> Total execution time: 0.1561
DEBUG - 2022-10-21 02:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:53:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 02:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:23:44 --> Total execution time: 0.1949
DEBUG - 2022-10-21 02:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:58:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 02:58:04 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-10-21 02:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:58:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 02:58:08 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-10-21 02:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:58:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 02:58:24 --> 404 Page Not Found: Wp-includes/wp-class.php
DEBUG - 2022-10-21 02:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 02:58:31 --> 404 Page Not Found: Wp-includes/wp-class.php
DEBUG - 2022-10-21 02:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:29:47 --> Total execution time: 0.1572
DEBUG - 2022-10-21 02:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 02:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 02:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 02:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:29:59 --> Total execution time: 0.1545
DEBUG - 2022-10-21 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:30:03 --> Total execution time: 0.1044
DEBUG - 2022-10-21 03:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:30:09 --> Total execution time: 0.1814
DEBUG - 2022-10-21 03:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:30:13 --> Total execution time: 0.2070
DEBUG - 2022-10-21 03:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:30:23 --> Total execution time: 0.1784
DEBUG - 2022-10-21 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:07:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:37:55 --> Total execution time: 0.2022
DEBUG - 2022-10-21 03:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:08:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:38:03 --> Total execution time: 0.3862
DEBUG - 2022-10-21 03:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:38:26 --> Total execution time: 0.1968
DEBUG - 2022-10-21 03:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:38:45 --> Total execution time: 0.1538
DEBUG - 2022-10-21 03:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:39:00 --> Total execution time: 0.1438
DEBUG - 2022-10-21 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:39:10 --> Total execution time: 0.1488
DEBUG - 2022-10-21 03:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:39:21 --> Total execution time: 0.1490
DEBUG - 2022-10-21 03:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:39:30 --> Total execution time: 0.1446
DEBUG - 2022-10-21 03:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:39:47 --> Total execution time: 0.1633
DEBUG - 2022-10-21 03:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:12:35 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:42:36 --> Total execution time: 0.1708
DEBUG - 2022-10-21 03:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:42:43 --> Total execution time: 0.0933
DEBUG - 2022-10-21 03:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:43:06 --> Total execution time: 0.4248
DEBUG - 2022-10-21 03:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:43:31 --> Total execution time: 0.1548
DEBUG - 2022-10-21 03:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:43:37 --> Total execution time: 0.3575
DEBUG - 2022-10-21 03:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:43:39 --> Total execution time: 0.1613
DEBUG - 2022-10-21 03:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:43:39 --> Total execution time: 0.2973
DEBUG - 2022-10-21 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:43:44 --> Total execution time: 0.1565
DEBUG - 2022-10-21 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:43:55 --> Total execution time: 0.1519
DEBUG - 2022-10-21 03:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:47:29 --> Total execution time: 0.2859
DEBUG - 2022-10-21 03:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:47:33 --> Total execution time: 0.1632
DEBUG - 2022-10-21 03:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:47:41 --> Total execution time: 0.1612
DEBUG - 2022-10-21 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:47:52 --> Total execution time: 0.4031
DEBUG - 2022-10-21 03:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:47:54 --> Total execution time: 0.1526
DEBUG - 2022-10-21 03:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:48:02 --> Total execution time: 0.2290
DEBUG - 2022-10-21 03:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:48:05 --> Total execution time: 0.1517
DEBUG - 2022-10-21 03:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:48:12 --> Total execution time: 0.1449
DEBUG - 2022-10-21 03:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:48:24 --> Total execution time: 0.1530
DEBUG - 2022-10-21 03:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:48:36 --> Total execution time: 0.1844
DEBUG - 2022-10-21 03:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:48:39 --> Total execution time: 0.2126
DEBUG - 2022-10-21 03:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:49:31 --> Total execution time: 0.1574
DEBUG - 2022-10-21 03:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:49:41 --> Total execution time: 0.1924
DEBUG - 2022-10-21 03:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:49:45 --> Total execution time: 0.2169
DEBUG - 2022-10-21 03:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:49:51 --> Total execution time: 0.1911
DEBUG - 2022-10-21 03:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:49:58 --> Total execution time: 0.1424
DEBUG - 2022-10-21 03:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:20:12 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:50:12 --> Total execution time: 0.0972
DEBUG - 2022-10-21 03:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:22:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:52:02 --> Total execution time: 0.1310
DEBUG - 2022-10-21 03:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:52:23 --> Total execution time: 0.1181
DEBUG - 2022-10-21 03:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:52:39 --> Total execution time: 0.1560
DEBUG - 2022-10-21 03:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:53:16 --> Total execution time: 0.1548
DEBUG - 2022-10-21 03:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:53:26 --> Total execution time: 0.1651
DEBUG - 2022-10-21 03:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:53:27 --> Total execution time: 0.1020
DEBUG - 2022-10-21 03:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:53:33 --> Total execution time: 0.1533
DEBUG - 2022-10-21 03:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:53:37 --> Total execution time: 0.1499
DEBUG - 2022-10-21 03:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:53:41 --> Total execution time: 0.1790
DEBUG - 2022-10-21 03:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:23:42 --> Total execution time: 0.1465
DEBUG - 2022-10-21 03:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:23:44 --> Total execution time: 0.1487
DEBUG - 2022-10-21 03:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:23:45 --> Total execution time: 0.1495
DEBUG - 2022-10-21 03:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:54:00 --> Total execution time: 0.1795
DEBUG - 2022-10-21 03:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:54:11 --> Total execution time: 0.1989
DEBUG - 2022-10-21 03:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:24:20 --> Total execution time: 0.1423
DEBUG - 2022-10-21 03:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:24:22 --> Total execution time: 0.1553
DEBUG - 2022-10-21 03:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:24:22 --> Total execution time: 0.1436
DEBUG - 2022-10-21 03:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:54:40 --> Total execution time: 0.1805
DEBUG - 2022-10-21 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:54:52 --> Total execution time: 0.1792
DEBUG - 2022-10-21 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:54:52 --> Total execution time: 0.1479
DEBUG - 2022-10-21 03:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:54:54 --> Total execution time: 0.1477
DEBUG - 2022-10-21 03:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:24:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:54:55 --> Total execution time: 0.1464
DEBUG - 2022-10-21 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:55:05 --> Total execution time: 0.4743
DEBUG - 2022-10-21 03:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:25:18 --> Total execution time: 0.1457
DEBUG - 2022-10-21 03:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:25:20 --> Total execution time: 0.1485
DEBUG - 2022-10-21 03:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:25:20 --> Total execution time: 0.3394
DEBUG - 2022-10-21 03:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:55:27 --> Total execution time: 0.1446
DEBUG - 2022-10-21 03:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:25:33 --> Total execution time: 0.1473
DEBUG - 2022-10-21 03:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:25:36 --> Total execution time: 0.1711
DEBUG - 2022-10-21 03:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:25:36 --> Total execution time: 0.1594
DEBUG - 2022-10-21 03:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:55:48 --> Total execution time: 0.0972
DEBUG - 2022-10-21 03:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:57:30 --> Total execution time: 0.1605
DEBUG - 2022-10-21 03:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:58:05 --> Total execution time: 0.1030
DEBUG - 2022-10-21 03:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:58:35 --> Total execution time: 0.1517
DEBUG - 2022-10-21 03:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:58:41 --> Total execution time: 0.2111
DEBUG - 2022-10-21 03:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:58:54 --> Total execution time: 0.1924
DEBUG - 2022-10-21 03:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:29:15 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:59:15 --> Total execution time: 0.4264
DEBUG - 2022-10-21 03:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:29:23 --> Total execution time: 0.1481
DEBUG - 2022-10-21 03:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:29:25 --> Total execution time: 0.1592
DEBUG - 2022-10-21 03:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:29:25 --> Total execution time: 0.1513
DEBUG - 2022-10-21 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:29:59 --> Total execution time: 0.1429
DEBUG - 2022-10-21 03:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:30:01 --> Total execution time: 0.1529
DEBUG - 2022-10-21 03:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:30:01 --> Total execution time: 0.2590
DEBUG - 2022-10-21 03:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:01:02 --> Total execution time: 0.0944
DEBUG - 2022-10-21 03:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:01:07 --> Total execution time: 0.1525
DEBUG - 2022-10-21 03:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:01:09 --> Total execution time: 0.1471
DEBUG - 2022-10-21 03:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:24 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:01:24 --> Total execution time: 0.1485
DEBUG - 2022-10-21 03:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:01:27 --> Total execution time: 0.1462
DEBUG - 2022-10-21 03:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:01:31 --> Total execution time: 0.1478
DEBUG - 2022-10-21 03:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:31:36 --> Total execution time: 0.1672
DEBUG - 2022-10-21 03:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:31:37 --> Total execution time: 0.1569
DEBUG - 2022-10-21 03:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:31:38 --> Total execution time: 0.1713
DEBUG - 2022-10-21 03:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:02:03 --> Total execution time: 0.1582
DEBUG - 2022-10-21 03:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:02:33 --> Total execution time: 0.1436
DEBUG - 2022-10-21 03:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:02:42 --> Total execution time: 0.1422
DEBUG - 2022-10-21 03:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:02:52 --> Total execution time: 0.1426
DEBUG - 2022-10-21 03:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:33:28 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:03:28 --> Total execution time: 0.1488
DEBUG - 2022-10-21 03:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:03:44 --> Total execution time: 0.1495
DEBUG - 2022-10-21 03:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:12 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:04:12 --> Total execution time: 0.1668
DEBUG - 2022-10-21 03:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:04:18 --> Total execution time: 0.1408
DEBUG - 2022-10-21 03:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:04:18 --> Total execution time: 0.3904
DEBUG - 2022-10-21 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:04:19 --> Total execution time: 0.1385
DEBUG - 2022-10-21 03:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:04:27 --> Total execution time: 0.1469
DEBUG - 2022-10-21 03:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:04:34 --> Total execution time: 0.2086
DEBUG - 2022-10-21 03:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:04:40 --> Total execution time: 0.2193
DEBUG - 2022-10-21 03:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:04:47 --> Total execution time: 0.1532
DEBUG - 2022-10-21 03:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:05:20 --> Total execution time: 0.2023
DEBUG - 2022-10-21 03:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:05:21 --> Total execution time: 0.3718
DEBUG - 2022-10-21 03:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:05:21 --> Total execution time: 0.4078
DEBUG - 2022-10-21 03:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:05:22 --> Total execution time: 0.1877
DEBUG - 2022-10-21 03:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:05:31 --> Total execution time: 0.2322
DEBUG - 2022-10-21 03:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:05:32 --> Total execution time: 0.1426
DEBUG - 2022-10-21 03:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:05:40 --> Total execution time: 0.1683
DEBUG - 2022-10-21 03:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:05:48 --> Total execution time: 0.1672
DEBUG - 2022-10-21 03:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:36:10 --> Total execution time: 0.1301
DEBUG - 2022-10-21 03:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:36:13 --> Total execution time: 0.1648
DEBUG - 2022-10-21 03:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:36:13 --> Total execution time: 0.3410
DEBUG - 2022-10-21 03:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:06:17 --> Total execution time: 0.1618
DEBUG - 2022-10-21 03:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:06:23 --> Total execution time: 0.1582
DEBUG - 2022-10-21 03:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:06:33 --> Total execution time: 0.1601
DEBUG - 2022-10-21 03:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 03:39:14 --> 404 Page Not Found: Contact/index
DEBUG - 2022-10-21 03:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:41:05 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:11:05 --> Total execution time: 0.1580
DEBUG - 2022-10-21 03:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:47:09 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:17:09 --> Total execution time: 0.1931
DEBUG - 2022-10-21 03:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:18:07 --> Total execution time: 0.1479
DEBUG - 2022-10-21 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:18:17 --> Total execution time: 0.1599
DEBUG - 2022-10-21 03:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 03:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:18:18 --> Total execution time: 0.1506
DEBUG - 2022-10-21 03:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:18:25 --> Total execution time: 0.2033
DEBUG - 2022-10-21 03:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:50:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 03:50:06 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-10-21 03:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:50:11 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:20:11 --> Total execution time: 0.1511
DEBUG - 2022-10-21 03:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 03:55:53 --> No URI present. Default controller set.
DEBUG - 2022-10-21 03:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 03:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:25:53 --> Total execution time: 0.1682
DEBUG - 2022-10-21 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:30:03 --> Total execution time: 0.2037
DEBUG - 2022-10-21 04:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:32:00 --> Total execution time: 0.1570
DEBUG - 2022-10-21 04:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:02:35 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:32:35 --> Total execution time: 0.1071
DEBUG - 2022-10-21 04:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:05:12 --> Total execution time: 0.1854
DEBUG - 2022-10-21 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:35:18 --> Total execution time: 0.1530
DEBUG - 2022-10-21 04:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:35:24 --> Total execution time: 0.2389
DEBUG - 2022-10-21 04:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:35:25 --> Total execution time: 0.2336
DEBUG - 2022-10-21 04:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:06:03 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:36:03 --> Total execution time: 0.1063
DEBUG - 2022-10-21 04:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:36:14 --> Total execution time: 0.1111
DEBUG - 2022-10-21 04:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:36:27 --> Total execution time: 0.1567
DEBUG - 2022-10-21 04:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:36:41 --> Total execution time: 0.2636
DEBUG - 2022-10-21 04:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:09:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:39:13 --> Total execution time: 0.1900
DEBUG - 2022-10-21 04:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:09:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:39:55 --> Total execution time: 0.0953
DEBUG - 2022-10-21 04:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:40:00 --> Total execution time: 0.1471
DEBUG - 2022-10-21 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:40:16 --> Total execution time: 0.1515
DEBUG - 2022-10-21 04:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:40:22 --> Total execution time: 0.2503
DEBUG - 2022-10-21 04:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:40:25 --> Total execution time: 0.1856
DEBUG - 2022-10-21 04:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:15:15 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:45:16 --> Total execution time: 0.4697
DEBUG - 2022-10-21 04:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:15:43 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:45:43 --> Total execution time: 0.1477
DEBUG - 2022-10-21 04:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:45:52 --> Total execution time: 0.1529
DEBUG - 2022-10-21 04:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:15:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:45:58 --> Total execution time: 0.1490
DEBUG - 2022-10-21 04:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:51:22 --> Total execution time: 0.1750
DEBUG - 2022-10-21 04:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:51:31 --> Total execution time: 0.1535
DEBUG - 2022-10-21 04:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:51:33 --> Total execution time: 0.1451
DEBUG - 2022-10-21 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:51:40 --> Total execution time: 0.2111
DEBUG - 2022-10-21 04:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:21:53 --> Total execution time: 0.1431
DEBUG - 2022-10-21 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:21:57 --> Total execution time: 0.1448
DEBUG - 2022-10-21 04:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:01 --> Total execution time: 0.1577
DEBUG - 2022-10-21 04:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:05 --> Total execution time: 0.1435
DEBUG - 2022-10-21 04:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:07 --> Total execution time: 0.1464
DEBUG - 2022-10-21 04:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:13 --> Total execution time: 0.1499
DEBUG - 2022-10-21 04:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:15 --> Total execution time: 0.1432
DEBUG - 2022-10-21 04:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:22:17 --> Total execution time: 0.1457
DEBUG - 2022-10-21 04:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:52:20 --> Total execution time: 0.2072
DEBUG - 2022-10-21 04:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:52:23 --> Total execution time: 0.1232
DEBUG - 2022-10-21 04:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:52:27 --> Total execution time: 0.1536
DEBUG - 2022-10-21 04:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:52:53 --> Total execution time: 0.1651
DEBUG - 2022-10-21 04:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:52:59 --> Total execution time: 0.1523
DEBUG - 2022-10-21 04:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:53:04 --> Total execution time: 0.1564
DEBUG - 2022-10-21 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:53:13 --> Total execution time: 0.1532
DEBUG - 2022-10-21 04:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:55:15 --> Total execution time: 0.4639
DEBUG - 2022-10-21 04:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:58:38 --> Total execution time: 0.5242
DEBUG - 2022-10-21 04:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:00:43 --> Total execution time: 0.5482
DEBUG - 2022-10-21 04:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:32:35 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:02:35 --> Total execution time: 0.0983
DEBUG - 2022-10-21 04:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:32:37 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:02:37 --> Total execution time: 0.0923
DEBUG - 2022-10-21 04:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:32:54 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:02:54 --> Total execution time: 0.0973
DEBUG - 2022-10-21 04:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:32:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:02:55 --> Total execution time: 0.0879
DEBUG - 2022-10-21 04:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:33:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:03:07 --> Total execution time: 0.0929
DEBUG - 2022-10-21 04:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:33:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:03:44 --> Total execution time: 0.1483
DEBUG - 2022-10-21 04:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:33:50 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:03:50 --> Total execution time: 0.0931
DEBUG - 2022-10-21 04:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:33:50 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:03:50 --> Total execution time: 0.0996
DEBUG - 2022-10-21 04:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:34:49 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:04:50 --> Total execution time: 0.1555
DEBUG - 2022-10-21 04:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:05:16 --> Total execution time: 0.1449
DEBUG - 2022-10-21 04:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:36:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:36:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:06:13 --> Total execution time: 0.1502
DEBUG - 2022-10-21 04:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:06:13 --> Total execution time: 0.1143
DEBUG - 2022-10-21 04:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:06:23 --> Total execution time: 0.1484
DEBUG - 2022-10-21 04:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:06:26 --> Total execution time: 0.1436
DEBUG - 2022-10-21 04:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:06:46 --> Total execution time: 0.1550
DEBUG - 2022-10-21 04:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:06:52 --> Total execution time: 0.1470
DEBUG - 2022-10-21 04:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:07:03 --> Total execution time: 0.1524
DEBUG - 2022-10-21 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:07:05 --> Total execution time: 0.1489
DEBUG - 2022-10-21 04:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:37:14 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:07:14 --> Total execution time: 0.0933
DEBUG - 2022-10-21 04:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:08:27 --> Total execution time: 0.1476
DEBUG - 2022-10-21 04:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:08:30 --> Total execution time: 0.1554
DEBUG - 2022-10-21 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:38:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:38:45 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-10-21 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:38:45 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-10-21 04:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:08:48 --> Total execution time: 0.0959
DEBUG - 2022-10-21 04:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:08:55 --> Total execution time: 0.1483
DEBUG - 2022-10-21 04:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:09:00 --> Total execution time: 0.0914
DEBUG - 2022-10-21 04:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:14:10 --> Total execution time: 0.1506
DEBUG - 2022-10-21 04:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:16 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:14:16 --> Total execution time: 0.0966
DEBUG - 2022-10-21 04:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:14:18 --> Total execution time: 0.1544
DEBUG - 2022-10-21 04:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:14:28 --> Total execution time: 0.1524
DEBUG - 2022-10-21 04:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:14:32 --> Total execution time: 0.2265
DEBUG - 2022-10-21 04:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:14:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-21 04:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:14:53 --> Total execution time: 0.1976
DEBUG - 2022-10-21 04:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:15:02 --> Total execution time: 0.1988
DEBUG - 2022-10-21 04:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:46:32 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:16:32 --> Total execution time: 0.4018
DEBUG - 2022-10-21 04:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:17:13 --> Total execution time: 0.1533
DEBUG - 2022-10-21 04:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:44 --> 404 Page Not Found: Wordpress/index
DEBUG - 2022-10-21 04:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:45 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:17:45 --> Total execution time: 0.1248
DEBUG - 2022-10-21 04:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:46 --> 404 Page Not Found: Wp/index
DEBUG - 2022-10-21 04:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:47 --> 404 Page Not Found: Bc/index
DEBUG - 2022-10-21 04:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:48 --> 404 Page Not Found: Bk/index
DEBUG - 2022-10-21 04:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:49 --> 404 Page Not Found: Backup/index
DEBUG - 2022-10-21 04:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:50 --> 404 Page Not Found: Old/index
DEBUG - 2022-10-21 04:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:51 --> 404 Page Not Found: New/index
DEBUG - 2022-10-21 04:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:52 --> 404 Page Not Found: Main/index
DEBUG - 2022-10-21 04:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:47:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 04:47:53 --> 404 Page Not Found: Home/index
DEBUG - 2022-10-21 04:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:20:20 --> Total execution time: 0.1573
DEBUG - 2022-10-21 04:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:20:40 --> Total execution time: 0.1765
DEBUG - 2022-10-21 04:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:51:23 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:21:23 --> Total execution time: 0.1323
DEBUG - 2022-10-21 04:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:22:31 --> Total execution time: 0.1858
DEBUG - 2022-10-21 04:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:23:33 --> Total execution time: 0.0966
DEBUG - 2022-10-21 04:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:23:50 --> Total execution time: 0.1496
DEBUG - 2022-10-21 04:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:24:32 --> Total execution time: 0.2129
DEBUG - 2022-10-21 04:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:24:50 --> Total execution time: 0.1617
DEBUG - 2022-10-21 04:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:24:54 --> Total execution time: 0.1625
DEBUG - 2022-10-21 04:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:55:06 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:25:06 --> Total execution time: 0.1032
DEBUG - 2022-10-21 04:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:55:12 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:25:12 --> Total execution time: 0.1115
DEBUG - 2022-10-21 04:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:25:25 --> Total execution time: 0.1580
DEBUG - 2022-10-21 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:25:30 --> Total execution time: 0.1752
DEBUG - 2022-10-21 04:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:55:48 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:25:48 --> Total execution time: 0.0977
DEBUG - 2022-10-21 04:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:25:53 --> Total execution time: 0.1460
DEBUG - 2022-10-21 04:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:26:51 --> Total execution time: 0.1386
DEBUG - 2022-10-21 04:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:57:00 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:01 --> Total execution time: 0.1030
DEBUG - 2022-10-21 04:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:57:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:02 --> Total execution time: 0.0916
DEBUG - 2022-10-21 04:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:06 --> Total execution time: 0.1452
DEBUG - 2022-10-21 04:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 04:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:13 --> Total execution time: 0.1795
DEBUG - 2022-10-21 04:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:23 --> Total execution time: 0.2007
DEBUG - 2022-10-21 04:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:57 --> Total execution time: 0.2271
DEBUG - 2022-10-21 04:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:59:05 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:59:05 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:29:05 --> Total execution time: 0.1017
DEBUG - 2022-10-21 04:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:29:05 --> Total execution time: 0.0992
DEBUG - 2022-10-21 04:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:29:11 --> Total execution time: 0.1967
DEBUG - 2022-10-21 04:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:59:47 --> No URI present. Default controller set.
DEBUG - 2022-10-21 04:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:29:47 --> Total execution time: 0.1229
DEBUG - 2022-10-21 04:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:29:49 --> Total execution time: 0.1541
DEBUG - 2022-10-21 04:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:29:52 --> Total execution time: 0.1463
DEBUG - 2022-10-21 04:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 04:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 04:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:29:56 --> Total execution time: 0.1561
DEBUG - 2022-10-21 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:00:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:30:02 --> Total execution time: 0.2761
DEBUG - 2022-10-21 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:30:03 --> Total execution time: 0.1198
DEBUG - 2022-10-21 05:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:30:12 --> Total execution time: 0.1458
DEBUG - 2022-10-21 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:30:16 --> Total execution time: 0.1606
DEBUG - 2022-10-21 05:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:30:26 --> Total execution time: 0.1627
DEBUG - 2022-10-21 05:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:30:33 --> Total execution time: 0.1832
DEBUG - 2022-10-21 05:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:31:04 --> Total execution time: 0.1441
DEBUG - 2022-10-21 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:04:09 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:34:09 --> Total execution time: 0.4817
DEBUG - 2022-10-21 05:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:34:21 --> Total execution time: 0.1527
DEBUG - 2022-10-21 05:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:34:28 --> Total execution time: 0.1744
DEBUG - 2022-10-21 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:34:31 --> Total execution time: 0.1597
DEBUG - 2022-10-21 05:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:34:40 --> Total execution time: 0.1451
DEBUG - 2022-10-21 05:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:35:55 --> Total execution time: 0.0939
DEBUG - 2022-10-21 05:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:06:04 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:36:04 --> Total execution time: 0.1103
DEBUG - 2022-10-21 05:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:36:22 --> Total execution time: 0.1670
DEBUG - 2022-10-21 05:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:36:41 --> Total execution time: 0.2398
DEBUG - 2022-10-21 05:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:37:11 --> Total execution time: 0.1983
DEBUG - 2022-10-21 05:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:37:22 --> Total execution time: 0.1871
DEBUG - 2022-10-21 05:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:37:39 --> Total execution time: 0.1555
DEBUG - 2022-10-21 05:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:37:40 --> Total execution time: 0.1689
DEBUG - 2022-10-21 05:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:37:42 --> Total execution time: 0.1550
DEBUG - 2022-10-21 05:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:37:42 --> Total execution time: 0.1495
DEBUG - 2022-10-21 05:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:37:43 --> Total execution time: 0.1703
DEBUG - 2022-10-21 05:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:38:44 --> Total execution time: 0.1543
DEBUG - 2022-10-21 05:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:08:46 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:38:46 --> Total execution time: 0.3895
DEBUG - 2022-10-21 05:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:08:47 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:38:48 --> Total execution time: 0.1615
DEBUG - 2022-10-21 05:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:38:48 --> Total execution time: 0.1811
DEBUG - 2022-10-21 05:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:38:53 --> Total execution time: 0.1491
DEBUG - 2022-10-21 05:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:38:55 --> Total execution time: 0.1442
DEBUG - 2022-10-21 05:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:39:00 --> Total execution time: 0.1886
DEBUG - 2022-10-21 05:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:39:03 --> Total execution time: 0.2031
DEBUG - 2022-10-21 05:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:39:21 --> Total execution time: 0.1943
DEBUG - 2022-10-21 05:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:39:34 --> Total execution time: 0.1812
DEBUG - 2022-10-21 05:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:39:39 --> Total execution time: 0.1979
DEBUG - 2022-10-21 05:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:39:41 --> Total execution time: 0.1777
DEBUG - 2022-10-21 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:06 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:41:06 --> Total execution time: 0.1507
DEBUG - 2022-10-21 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:41:07 --> Total execution time: 0.1517
DEBUG - 2022-10-21 05:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:41:12 --> Total execution time: 0.1827
DEBUG - 2022-10-21 05:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:41:22 --> Total execution time: 0.1423
DEBUG - 2022-10-21 05:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:41:32 --> Total execution time: 0.1840
DEBUG - 2022-10-21 05:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:41:37 --> Total execution time: 0.1778
DEBUG - 2022-10-21 05:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:43:02 --> Total execution time: 0.1568
DEBUG - 2022-10-21 05:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:43:47 --> Total execution time: 0.1712
DEBUG - 2022-10-21 05:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:14:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:44:56 --> Total execution time: 0.4139
DEBUG - 2022-10-21 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:15:14 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:45:14 --> Total execution time: 0.0985
DEBUG - 2022-10-21 05:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:17:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 05:17:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 05:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:47:18 --> Total execution time: 0.4802
DEBUG - 2022-10-21 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:17:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:47:27 --> Total execution time: 0.1093
DEBUG - 2022-10-21 05:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:47:34 --> Total execution time: 0.1485
DEBUG - 2022-10-21 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:19:11 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:49:11 --> Total execution time: 0.0943
DEBUG - 2022-10-21 05:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:22:34 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:52:34 --> Total execution time: 0.1954
DEBUG - 2022-10-21 05:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:23:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:53:10 --> Total execution time: 0.1075
DEBUG - 2022-10-21 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:25:53 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:55:53 --> Total execution time: 0.1696
DEBUG - 2022-10-21 05:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:56:00 --> Total execution time: 0.1075
DEBUG - 2022-10-21 05:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:56:31 --> Total execution time: 0.1582
DEBUG - 2022-10-21 05:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:56:54 --> Total execution time: 0.1626
DEBUG - 2022-10-21 05:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:26:59 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:56:59 --> Total execution time: 0.0877
DEBUG - 2022-10-21 05:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:57:01 --> Total execution time: 0.1975
DEBUG - 2022-10-21 05:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:57:18 --> Total execution time: 0.1861
DEBUG - 2022-10-21 05:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:28:00 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:58:00 --> Total execution time: 0.1544
DEBUG - 2022-10-21 05:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:58:08 --> Total execution time: 0.1641
DEBUG - 2022-10-21 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:58:13 --> Total execution time: 0.2105
DEBUG - 2022-10-21 05:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:37:59 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:07:59 --> Total execution time: 0.1196
DEBUG - 2022-10-21 05:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:39:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 05:39:43 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 05:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:44:24 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:14:24 --> Total execution time: 0.1644
DEBUG - 2022-10-21 05:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:44:25 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:14:25 --> Total execution time: 0.0935
DEBUG - 2022-10-21 05:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:14:35 --> Total execution time: 0.1514
DEBUG - 2022-10-21 05:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:45:19 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:15:19 --> Total execution time: 0.0976
DEBUG - 2022-10-21 05:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:45:39 --> Total execution time: 0.1484
DEBUG - 2022-10-21 05:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:45:41 --> Total execution time: 0.1564
DEBUG - 2022-10-21 05:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:45:41 --> Total execution time: 0.1449
DEBUG - 2022-10-21 05:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:16:45 --> Total execution time: 2.5055
DEBUG - 2022-10-21 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 05:46:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 05:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:17:20 --> Total execution time: 0.1577
DEBUG - 2022-10-21 05:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:49:54 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:19:54 --> Total execution time: 0.1496
DEBUG - 2022-10-21 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:50:11 --> Total execution time: 0.1515
DEBUG - 2022-10-21 05:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:50:18 --> Total execution time: 0.1673
DEBUG - 2022-10-21 05:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:50:18 --> Total execution time: 0.3167
DEBUG - 2022-10-21 05:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:50:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:20:44 --> Total execution time: 0.0971
DEBUG - 2022-10-21 05:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:50:50 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:20:50 --> Total execution time: 0.1070
DEBUG - 2022-10-21 05:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:50:52 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:20:52 --> Total execution time: 0.1000
DEBUG - 2022-10-21 05:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:50:59 --> Total execution time: 0.1454
DEBUG - 2022-10-21 05:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:51:01 --> Total execution time: 0.1559
DEBUG - 2022-10-21 05:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:51:02 --> Total execution time: 0.1558
DEBUG - 2022-10-21 05:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:51:04 --> Total execution time: 0.1532
DEBUG - 2022-10-21 05:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:51:30 --> Total execution time: 0.1517
DEBUG - 2022-10-21 05:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:35 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:21:35 --> Total execution time: 0.1516
DEBUG - 2022-10-21 05:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:21:44 --> Total execution time: 1.7050
DEBUG - 2022-10-21 05:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:51:44 --> Total execution time: 0.0922
DEBUG - 2022-10-21 05:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:51:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 05:51:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 05:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:52:02 --> Total execution time: 0.1786
DEBUG - 2022-10-21 05:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:52:04 --> Total execution time: 0.1686
DEBUG - 2022-10-21 05:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:52:04 --> Total execution time: 0.1721
DEBUG - 2022-10-21 16:22:05 --> Total execution time: 1.9636
DEBUG - 2022-10-21 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:22:25 --> Total execution time: 0.1565
DEBUG - 2022-10-21 05:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:22:27 --> Total execution time: 0.3139
DEBUG - 2022-10-21 05:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:22:33 --> Total execution time: 0.1534
DEBUG - 2022-10-21 05:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:22:38 --> Total execution time: 0.2199
DEBUG - 2022-10-21 05:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:22:56 --> Total execution time: 0.1533
DEBUG - 2022-10-21 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:23:01 --> Total execution time: 0.1601
DEBUG - 2022-10-21 05:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:23:02 --> Total execution time: 0.1555
DEBUG - 2022-10-21 05:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:23:07 --> Total execution time: 0.2365
DEBUG - 2022-10-21 05:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:15 --> Total execution time: 0.1571
DEBUG - 2022-10-21 05:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:17 --> Total execution time: 0.1449
DEBUG - 2022-10-21 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:18 --> Total execution time: 0.1532
DEBUG - 2022-10-21 05:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:40 --> Total execution time: 0.1463
DEBUG - 2022-10-21 05:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:42 --> Total execution time: 0.1861
DEBUG - 2022-10-21 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:53:42 --> Total execution time: 0.1576
DEBUG - 2022-10-21 05:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:53:51 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:23:51 --> Total execution time: 0.1078
DEBUG - 2022-10-21 05:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:24:18 --> Total execution time: 0.1417
DEBUG - 2022-10-21 05:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:24:19 --> Total execution time: 0.2004
DEBUG - 2022-10-21 05:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:56:37 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:26:38 --> Total execution time: 0.4705
DEBUG - 2022-10-21 05:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:56:43 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:26:43 --> Total execution time: 0.1506
DEBUG - 2022-10-21 05:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:56:50 --> Total execution time: 0.1545
DEBUG - 2022-10-21 05:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:56:52 --> Total execution time: 0.1517
DEBUG - 2022-10-21 05:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:56:53 --> Total execution time: 0.1422
DEBUG - 2022-10-21 05:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:58:04 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:28:04 --> Total execution time: 0.0939
DEBUG - 2022-10-21 05:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:58:15 --> Total execution time: 0.1515
DEBUG - 2022-10-21 05:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:58:17 --> Total execution time: 0.1436
DEBUG - 2022-10-21 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:58:18 --> Total execution time: 0.3316
DEBUG - 2022-10-21 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:58:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:28:28 --> Total execution time: 0.1538
DEBUG - 2022-10-21 05:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:59:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:29:42 --> Total execution time: 0.1160
DEBUG - 2022-10-21 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:59:50 --> No URI present. Default controller set.
DEBUG - 2022-10-21 05:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:29:50 --> Total execution time: 0.1645
DEBUG - 2022-10-21 05:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 05:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 05:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 05:59:59 --> Total execution time: 0.1436
DEBUG - 2022-10-21 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:00:01 --> Total execution time: 0.1457
DEBUG - 2022-10-21 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:00:01 --> Total execution time: 0.1515
DEBUG - 2022-10-21 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:30:03 --> Total execution time: 0.1289
DEBUG - 2022-10-21 06:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:31:58 --> Total execution time: 1.9040
DEBUG - 2022-10-21 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:02:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 06:02:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:02:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:32:42 --> Total execution time: 0.1046
DEBUG - 2022-10-21 06:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 06:02:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 06:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:07:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:37:55 --> Total execution time: 0.1659
DEBUG - 2022-10-21 06:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:38:50 --> Total execution time: 0.1471
DEBUG - 2022-10-21 06:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:38:57 --> Total execution time: 0.1735
DEBUG - 2022-10-21 06:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:39:01 --> Total execution time: 0.2149
DEBUG - 2022-10-21 06:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:39:07 --> Total execution time: 0.2369
DEBUG - 2022-10-21 06:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:13:59 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:43:59 --> Total execution time: 0.1615
DEBUG - 2022-10-21 06:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:14:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:44:01 --> Total execution time: 0.1054
DEBUG - 2022-10-21 06:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:44:53 --> Total execution time: 0.1042
DEBUG - 2022-10-21 06:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:45:33 --> Total execution time: 0.1176
DEBUG - 2022-10-21 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:46:26 --> Total execution time: 0.1460
DEBUG - 2022-10-21 06:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:46:33 --> Total execution time: 0.1550
DEBUG - 2022-10-21 06:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:49:47 --> Total execution time: 0.1471
DEBUG - 2022-10-21 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:03 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:03 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:03 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:03 --> Total execution time: 0.1008
DEBUG - 2022-10-21 06:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:03 --> Total execution time: 0.0982
DEBUG - 2022-10-21 06:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:03 --> Total execution time: 0.0979
DEBUG - 2022-10-21 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:04 --> Total execution time: 0.0927
DEBUG - 2022-10-21 06:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:05 --> Total execution time: 0.1231
DEBUG - 2022-10-21 06:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:21 --> Total execution time: 0.1515
DEBUG - 2022-10-21 06:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:27 --> Total execution time: 0.1799
DEBUG - 2022-10-21 06:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:38 --> Total execution time: 0.1603
DEBUG - 2022-10-21 06:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:41 --> Total execution time: 0.1535
DEBUG - 2022-10-21 06:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:44 --> Total execution time: 0.1641
DEBUG - 2022-10-21 06:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:53 --> Total execution time: 0.1422
DEBUG - 2022-10-21 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:55:23 --> Total execution time: 0.5122
DEBUG - 2022-10-21 06:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:26:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:56:07 --> Total execution time: 0.1060
DEBUG - 2022-10-21 06:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:26:19 --> Total execution time: 0.1612
DEBUG - 2022-10-21 06:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:26:21 --> Total execution time: 0.1609
DEBUG - 2022-10-21 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:26:22 --> Total execution time: 0.1530
DEBUG - 2022-10-21 06:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:57:55 --> Total execution time: 0.1833
DEBUG - 2022-10-21 06:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:58:05 --> Total execution time: 0.1469
DEBUG - 2022-10-21 06:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:58:11 --> Total execution time: 0.1483
DEBUG - 2022-10-21 06:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:28:51 --> Total execution time: 0.1633
DEBUG - 2022-10-21 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:28:53 --> Total execution time: 0.1538
DEBUG - 2022-10-21 06:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:28:53 --> Total execution time: 0.3435
DEBUG - 2022-10-21 06:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:28:56 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:58:56 --> Total execution time: 0.1475
DEBUG - 2022-10-21 06:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:29:04 --> Total execution time: 0.1564
DEBUG - 2022-10-21 06:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:29:15 --> Total execution time: 0.1571
DEBUG - 2022-10-21 06:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:29:15 --> Total execution time: 0.3437
DEBUG - 2022-10-21 06:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:39 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:29:40 --> Total execution time: 0.1599
DEBUG - 2022-10-21 06:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:59:40 --> Total execution time: 0.4171
DEBUG - 2022-10-21 06:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:29:40 --> Total execution time: 0.6118
DEBUG - 2022-10-21 06:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:29:47 --> Total execution time: 0.1467
DEBUG - 2022-10-21 06:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:29:50 --> Total execution time: 0.1463
DEBUG - 2022-10-21 06:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:29:50 --> Total execution time: 0.3330
DEBUG - 2022-10-21 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:00:02 --> Total execution time: 0.1829
DEBUG - 2022-10-21 06:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:30:03 --> Total execution time: 0.1481
DEBUG - 2022-10-21 06:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:05 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:00:05 --> Total execution time: 0.1504
DEBUG - 2022-10-21 06:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:30:05 --> Total execution time: 0.2915
DEBUG - 2022-10-21 06:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:30:06 --> Total execution time: 0.5106
DEBUG - 2022-10-21 06:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:00:26 --> Total execution time: 0.1447
DEBUG - 2022-10-21 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:30:44 --> Total execution time: 0.1501
DEBUG - 2022-10-21 06:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:30:46 --> Total execution time: 0.1863
DEBUG - 2022-10-21 06:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:30:46 --> Total execution time: 0.1672
DEBUG - 2022-10-21 06:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:04:49 --> Total execution time: 0.1565
DEBUG - 2022-10-21 06:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:04:50 --> Total execution time: 0.1466
DEBUG - 2022-10-21 06:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:04:58 --> Total execution time: 0.1522
DEBUG - 2022-10-21 06:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:05:03 --> Total execution time: 0.1526
DEBUG - 2022-10-21 06:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:05:07 --> Total execution time: 0.1716
DEBUG - 2022-10-21 06:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:05:11 --> Total execution time: 0.1528
DEBUG - 2022-10-21 06:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:05:15 --> Total execution time: 0.1913
DEBUG - 2022-10-21 06:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:05:21 --> Total execution time: 0.1656
DEBUG - 2022-10-21 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:39:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 06:39:43 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 06:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:42:24 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:12:24 --> Total execution time: 0.1690
DEBUG - 2022-10-21 06:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:12:56 --> Total execution time: 0.1045
DEBUG - 2022-10-21 06:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:12:58 --> Total execution time: 0.1669
DEBUG - 2022-10-21 06:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 06:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:13:30 --> Total execution time: 0.1540
DEBUG - 2022-10-21 06:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:13:54 --> Total execution time: 0.1659
DEBUG - 2022-10-21 06:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:14:20 --> Total execution time: 0.2699
DEBUG - 2022-10-21 06:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 06:48:59 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-10-21 06:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 06:49:05 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-10-21 06:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:19:24 --> Total execution time: 0.4480
DEBUG - 2022-10-21 06:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:19:35 --> Total execution time: 0.1540
DEBUG - 2022-10-21 06:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:19:51 --> Total execution time: 0.1481
DEBUG - 2022-10-21 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:20:00 --> Total execution time: 0.1554
DEBUG - 2022-10-21 06:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:51:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:21:44 --> Total execution time: 0.1067
DEBUG - 2022-10-21 06:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:52:39 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:22:39 --> Total execution time: 0.0934
DEBUG - 2022-10-21 06:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:24:05 --> Total execution time: 0.3933
DEBUG - 2022-10-21 06:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:24:08 --> Total execution time: 0.1914
DEBUG - 2022-10-21 06:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:56:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:26:01 --> Total execution time: 0.2487
DEBUG - 2022-10-21 06:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:26:06 --> Total execution time: 0.1087
DEBUG - 2022-10-21 06:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:56:34 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:26:34 --> Total execution time: 0.1054
DEBUG - 2022-10-21 06:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:27:50 --> Total execution time: 0.4406
DEBUG - 2022-10-21 06:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:58:35 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:28:35 --> Total execution time: 0.1020
DEBUG - 2022-10-21 06:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:58:38 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:28:39 --> Total execution time: 0.4106
DEBUG - 2022-10-21 06:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:58:41 --> No URI present. Default controller set.
DEBUG - 2022-10-21 06:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:58:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:28:41 --> Total execution time: 0.0949
DEBUG - 2022-10-21 06:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:29:40 --> Total execution time: 0.1529
DEBUG - 2022-10-21 06:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 06:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 06:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:29:49 --> Total execution time: 0.2084
DEBUG - 2022-10-21 07:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:30:01 --> Total execution time: 0.1931
DEBUG - 2022-10-21 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:30:03 --> Total execution time: 0.1283
DEBUG - 2022-10-21 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:30:04 --> Total execution time: 0.1949
DEBUG - 2022-10-21 07:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:00:13 --> Total execution time: 0.1711
DEBUG - 2022-10-21 07:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:30:14 --> Total execution time: 0.1471
DEBUG - 2022-10-21 07:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:00:15 --> Total execution time: 0.1816
DEBUG - 2022-10-21 07:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:00:15 --> Total execution time: 0.1463
DEBUG - 2022-10-21 07:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:01:50 --> Total execution time: 0.1567
DEBUG - 2022-10-21 07:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:02:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:32:42 --> Total execution time: 0.1496
DEBUG - 2022-10-21 07:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:36:09 --> Total execution time: 0.1521
DEBUG - 2022-10-21 07:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:36:18 --> Total execution time: 0.1512
DEBUG - 2022-10-21 07:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:36:27 --> Total execution time: 0.2439
DEBUG - 2022-10-21 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:37:50 --> Total execution time: 0.1482
DEBUG - 2022-10-21 07:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:37:57 --> Total execution time: 0.1459
DEBUG - 2022-10-21 07:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:38:03 --> Total execution time: 0.1021
DEBUG - 2022-10-21 07:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:09:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:39:08 --> Total execution time: 0.1114
DEBUG - 2022-10-21 07:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:09:08 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:39:08 --> Total execution time: 0.0946
DEBUG - 2022-10-21 07:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:09:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:39:10 --> Total execution time: 0.0981
DEBUG - 2022-10-21 07:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:09:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:39:10 --> Total execution time: 0.1176
DEBUG - 2022-10-21 07:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:09:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:39:11 --> Total execution time: 0.0947
DEBUG - 2022-10-21 07:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:41:11 --> Total execution time: 0.4269
DEBUG - 2022-10-21 07:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:11:32 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:41:32 --> Total execution time: 0.0933
DEBUG - 2022-10-21 07:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:12:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:42:55 --> Total execution time: 0.1089
DEBUG - 2022-10-21 07:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:43:10 --> Total execution time: 0.5377
DEBUG - 2022-10-21 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:44:32 --> Total execution time: 0.1963
DEBUG - 2022-10-21 07:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 07:17:27 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 07:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:50:55 --> Total execution time: 0.5008
DEBUG - 2022-10-21 07:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:29:36 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:59:36 --> Total execution time: 0.1783
DEBUG - 2022-10-21 07:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:33:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:03:27 --> Total execution time: 0.1715
DEBUG - 2022-10-21 07:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:06:04 --> Total execution time: 0.0975
DEBUG - 2022-10-21 07:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:06:25 --> Total execution time: 0.2133
DEBUG - 2022-10-21 07:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:06:34 --> Total execution time: 0.1909
DEBUG - 2022-10-21 07:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:06:46 --> Total execution time: 0.1567
DEBUG - 2022-10-21 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:06:52 --> Total execution time: 0.1634
DEBUG - 2022-10-21 07:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:07:08 --> Total execution time: 0.1572
DEBUG - 2022-10-21 07:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:37:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:07:59 --> Total execution time: 0.1059
DEBUG - 2022-10-21 07:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:08:07 --> Total execution time: 0.0945
DEBUG - 2022-10-21 07:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:08:16 --> Total execution time: 0.3956
DEBUG - 2022-10-21 07:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:08:35 --> Total execution time: 0.1556
DEBUG - 2022-10-21 07:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:08:45 --> Total execution time: 0.1489
DEBUG - 2022-10-21 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:09:09 --> Total execution time: 0.0916
DEBUG - 2022-10-21 07:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:09:26 --> Total execution time: 0.1604
DEBUG - 2022-10-21 07:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:09:37 --> Total execution time: 0.2003
DEBUG - 2022-10-21 07:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:09:55 --> Total execution time: 0.6146
DEBUG - 2022-10-21 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:10:22 --> Total execution time: 0.1460
DEBUG - 2022-10-21 07:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:40:25 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:10:26 --> Total execution time: 0.1479
DEBUG - 2022-10-21 07:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:14:56 --> Total execution time: 0.4678
DEBUG - 2022-10-21 07:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:15:10 --> Total execution time: 0.1928
DEBUG - 2022-10-21 07:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:15:14 --> Total execution time: 0.1547
DEBUG - 2022-10-21 07:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:15:28 --> Total execution time: 0.1518
DEBUG - 2022-10-21 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:16:13 --> Total execution time: 0.1541
DEBUG - 2022-10-21 07:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:16:17 --> Total execution time: 0.1596
DEBUG - 2022-10-21 07:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:16:24 --> Total execution time: 0.1743
DEBUG - 2022-10-21 07:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:16:52 --> Total execution time: 0.0951
DEBUG - 2022-10-21 07:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:16:53 --> Total execution time: 0.1485
DEBUG - 2022-10-21 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:16:56 --> Total execution time: 0.1533
DEBUG - 2022-10-21 07:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:47:03 --> Total execution time: 0.1046
DEBUG - 2022-10-21 07:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 07:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:08 --> Total execution time: 0.1459
DEBUG - 2022-10-21 07:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:11 --> Total execution time: 0.1882
DEBUG - 2022-10-21 07:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:13 --> Total execution time: 0.2351
DEBUG - 2022-10-21 07:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:17 --> Total execution time: 0.1955
DEBUG - 2022-10-21 07:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:18 --> Total execution time: 0.1856
DEBUG - 2022-10-21 07:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:19 --> Total execution time: 0.3376
DEBUG - 2022-10-21 07:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:19 --> Total execution time: 0.2148
DEBUG - 2022-10-21 07:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:20 --> Total execution time: 0.3932
DEBUG - 2022-10-21 07:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:20 --> Total execution time: 0.2076
DEBUG - 2022-10-21 07:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:21 --> Total execution time: 0.2060
DEBUG - 2022-10-21 07:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:31 --> Total execution time: 0.1917
DEBUG - 2022-10-21 07:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:32 --> Total execution time: 0.1852
DEBUG - 2022-10-21 07:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:32 --> Total execution time: 0.1856
DEBUG - 2022-10-21 07:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:33 --> Total execution time: 0.2137
DEBUG - 2022-10-21 07:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:38 --> Total execution time: 0.2505
DEBUG - 2022-10-21 07:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:17:58 --> Total execution time: 0.1615
DEBUG - 2022-10-21 07:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:18:02 --> Total execution time: 0.2334
DEBUG - 2022-10-21 07:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:18:45 --> Total execution time: 0.1472
DEBUG - 2022-10-21 07:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:51:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:21:55 --> Total execution time: 0.1785
DEBUG - 2022-10-21 07:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 07:52:35 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 07:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:23:15 --> Total execution time: 0.4034
DEBUG - 2022-10-21 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:23:19 --> Total execution time: 0.1896
DEBUG - 2022-10-21 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:53:36 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:23:36 --> Total execution time: 0.0930
DEBUG - 2022-10-21 07:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:53:37 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:23:37 --> Total execution time: 0.1692
DEBUG - 2022-10-21 07:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:23:45 --> Total execution time: 0.2357
DEBUG - 2022-10-21 07:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:54:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 07:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:24:31 --> Total execution time: 0.1153
DEBUG - 2022-10-21 07:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 07:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 07:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:24:59 --> Total execution time: 0.1300
DEBUG - 2022-10-21 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:30:03 --> Total execution time: 0.1920
DEBUG - 2022-10-21 08:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:07:08 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:37:08 --> Total execution time: 0.1680
DEBUG - 2022-10-21 08:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:37:13 --> Total execution time: 0.1157
DEBUG - 2022-10-21 08:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:37:26 --> Total execution time: 0.2636
DEBUG - 2022-10-21 08:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:37:34 --> Total execution time: 0.1832
DEBUG - 2022-10-21 08:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:37:40 --> Total execution time: 0.1532
DEBUG - 2022-10-21 08:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:08:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 08:08:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 08:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:38:49 --> Total execution time: 0.1442
DEBUG - 2022-10-21 08:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:39:06 --> Total execution time: 0.1599
DEBUG - 2022-10-21 08:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:39:09 --> Total execution time: 0.1555
DEBUG - 2022-10-21 08:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:39:13 --> Total execution time: 0.1632
DEBUG - 2022-10-21 08:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:39:33 --> Total execution time: 0.1616
DEBUG - 2022-10-21 08:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:17:25 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:47:25 --> Total execution time: 0.1670
DEBUG - 2022-10-21 08:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:49:54 --> Total execution time: 0.1592
DEBUG - 2022-10-21 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:22:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:52:01 --> Total execution time: 0.1637
DEBUG - 2022-10-21 08:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:52:06 --> Total execution time: 0.1779
DEBUG - 2022-10-21 08:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:52:15 --> Total execution time: 0.1464
DEBUG - 2022-10-21 08:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:56:10 --> Total execution time: 0.2247
DEBUG - 2022-10-21 08:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:57:13 --> Total execution time: 0.1486
DEBUG - 2022-10-21 08:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:02:48 --> Total execution time: 0.4668
DEBUG - 2022-10-21 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:03:05 --> Total execution time: 0.1623
DEBUG - 2022-10-21 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:03:14 --> Total execution time: 0.1541
DEBUG - 2022-10-21 08:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:03:23 --> Total execution time: 0.2070
DEBUG - 2022-10-21 08:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:03:56 --> Total execution time: 0.1595
DEBUG - 2022-10-21 08:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:04:35 --> Total execution time: 0.1580
DEBUG - 2022-10-21 08:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:04:43 --> Total execution time: 0.1584
DEBUG - 2022-10-21 08:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:36:42 --> Total execution time: 0.1694
DEBUG - 2022-10-21 08:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:07:03 --> Total execution time: 0.1214
DEBUG - 2022-10-21 08:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:07:23 --> Total execution time: 0.1617
DEBUG - 2022-10-21 08:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:07:50 --> Total execution time: 0.4559
DEBUG - 2022-10-21 08:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:07:59 --> Total execution time: 0.1942
DEBUG - 2022-10-21 08:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:08:07 --> Total execution time: 0.1542
DEBUG - 2022-10-21 08:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:08:26 --> Total execution time: 0.1695
DEBUG - 2022-10-21 08:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:08:52 --> Total execution time: 0.1875
DEBUG - 2022-10-21 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:09:01 --> Total execution time: 0.1684
DEBUG - 2022-10-21 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:40:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:10:14 --> Total execution time: 0.0972
DEBUG - 2022-10-21 08:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:10:44 --> Total execution time: 0.1541
DEBUG - 2022-10-21 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:13:39 --> Total execution time: 0.4566
DEBUG - 2022-10-21 08:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:14:15 --> Total execution time: 0.1711
DEBUG - 2022-10-21 08:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:14:37 --> Total execution time: 0.1417
DEBUG - 2022-10-21 08:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:14:44 --> Total execution time: 0.1666
DEBUG - 2022-10-21 08:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:16:32 --> Total execution time: 0.0922
DEBUG - 2022-10-21 08:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:16:47 --> Total execution time: 0.0921
DEBUG - 2022-10-21 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:17:16 --> Total execution time: 0.1514
DEBUG - 2022-10-21 08:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:17:29 --> Total execution time: 0.1657
DEBUG - 2022-10-21 08:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:17:38 --> Total execution time: 0.1586
DEBUG - 2022-10-21 08:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:17:57 --> Total execution time: 0.1576
DEBUG - 2022-10-21 08:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:18:37 --> Total execution time: 0.2206
DEBUG - 2022-10-21 08:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:18:37 --> Total execution time: 0.1832
DEBUG - 2022-10-21 08:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:18:38 --> Total execution time: 0.1822
DEBUG - 2022-10-21 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 08:48:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 08:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:48:53 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:18:53 --> Total execution time: 0.1520
DEBUG - 2022-10-21 08:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:18:57 --> Total execution time: 0.1515
DEBUG - 2022-10-21 08:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:19:02 --> Total execution time: 0.1678
DEBUG - 2022-10-21 08:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:19:08 --> Total execution time: 0.1639
DEBUG - 2022-10-21 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:19:11 --> Total execution time: 0.1781
DEBUG - 2022-10-21 08:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:19:19 --> Total execution time: 0.2152
DEBUG - 2022-10-21 08:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:49:33 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:19:33 --> Total execution time: 0.0948
DEBUG - 2022-10-21 08:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:18 --> Total execution time: 0.1599
DEBUG - 2022-10-21 08:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:24 --> Total execution time: 0.1503
DEBUG - 2022-10-21 08:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:29 --> Total execution time: 0.1507
DEBUG - 2022-10-21 08:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:36 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:36 --> Total execution time: 0.0991
DEBUG - 2022-10-21 08:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:40 --> Total execution time: 0.1490
DEBUG - 2022-10-21 08:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:43 --> Total execution time: 0.1481
DEBUG - 2022-10-21 08:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:50 --> Total execution time: 0.1720
DEBUG - 2022-10-21 08:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:53 --> Total execution time: 0.1788
DEBUG - 2022-10-21 08:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:57 --> Total execution time: 0.1547
DEBUG - 2022-10-21 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:20:59 --> Total execution time: 0.1564
DEBUG - 2022-10-21 08:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:51:03 --> Total execution time: 0.1496
DEBUG - 2022-10-21 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:51:05 --> Total execution time: 0.1482
DEBUG - 2022-10-21 08:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:51:05 --> Total execution time: 0.1475
DEBUG - 2022-10-21 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:21:06 --> Total execution time: 0.1455
DEBUG - 2022-10-21 08:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:21:07 --> Total execution time: 0.1468
DEBUG - 2022-10-21 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:21:10 --> Total execution time: 0.1504
DEBUG - 2022-10-21 08:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:21:12 --> Total execution time: 0.0885
DEBUG - 2022-10-21 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:10 --> Total execution time: 0.1430
DEBUG - 2022-10-21 08:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:11 --> Total execution time: 0.1437
DEBUG - 2022-10-21 08:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:19 --> Total execution time: 0.1415
DEBUG - 2022-10-21 08:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:23 --> Total execution time: 0.1475
DEBUG - 2022-10-21 08:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:27 --> Total execution time: 0.1423
DEBUG - 2022-10-21 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:32 --> Total execution time: 0.1615
DEBUG - 2022-10-21 08:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:34 --> Total execution time: 0.1510
DEBUG - 2022-10-21 08:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:35 --> Total execution time: 0.1432
DEBUG - 2022-10-21 08:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:36 --> Total execution time: 0.1440
DEBUG - 2022-10-21 08:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:41 --> Total execution time: 0.0966
DEBUG - 2022-10-21 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:43 --> Total execution time: 0.1560
DEBUG - 2022-10-21 08:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:46 --> Total execution time: 0.1430
DEBUG - 2022-10-21 08:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:52:46 --> Total execution time: 0.1498
DEBUG - 2022-10-21 19:22:46 --> Total execution time: 2.4166
DEBUG - 2022-10-21 08:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:47 --> Total execution time: 0.1659
DEBUG - 2022-10-21 08:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:50 --> Total execution time: 0.1447
DEBUG - 2022-10-21 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:52:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 08:52:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 08:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:22:55 --> Total execution time: 0.1454
DEBUG - 2022-10-21 08:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:17 --> Total execution time: 0.1633
DEBUG - 2022-10-21 08:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:18 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:18 --> Total execution time: 0.1555
DEBUG - 2022-10-21 08:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:18 --> Total execution time: 0.1484
DEBUG - 2022-10-21 08:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:23 --> Total execution time: 0.1580
DEBUG - 2022-10-21 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:27 --> Total execution time: 0.1566
DEBUG - 2022-10-21 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:28 --> Total execution time: 0.3911
DEBUG - 2022-10-21 08:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:42 --> Total execution time: 0.1563
DEBUG - 2022-10-21 08:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:49 --> Total execution time: 0.1494
DEBUG - 2022-10-21 08:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:56 --> Total execution time: 0.1544
DEBUG - 2022-10-21 08:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:23:59 --> Total execution time: 0.1497
DEBUG - 2022-10-21 08:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:24:26 --> Total execution time: 0.1641
DEBUG - 2022-10-21 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:24:44 --> Total execution time: 0.4468
DEBUG - 2022-10-21 08:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:24:54 --> Total execution time: 0.1443
DEBUG - 2022-10-21 08:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:25:01 --> Total execution time: 0.1551
DEBUG - 2022-10-21 08:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:25:11 --> Total execution time: 0.1454
DEBUG - 2022-10-21 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:25:46 --> Total execution time: 0.1416
DEBUG - 2022-10-21 08:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:56:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 08:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:26:13 --> Total execution time: 0.0938
DEBUG - 2022-10-21 08:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:26:19 --> Total execution time: 0.1495
DEBUG - 2022-10-21 08:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:26:33 --> Total execution time: 0.1486
DEBUG - 2022-10-21 08:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:26:42 --> Total execution time: 0.1587
DEBUG - 2022-10-21 08:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:26:46 --> Total execution time: 0.1611
DEBUG - 2022-10-21 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:27:00 --> Total execution time: 0.3813
DEBUG - 2022-10-21 08:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:27:16 --> Total execution time: 0.1515
DEBUG - 2022-10-21 08:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:27:22 --> Total execution time: 0.2251
DEBUG - 2022-10-21 08:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:27:32 --> Total execution time: 0.1595
DEBUG - 2022-10-21 08:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:27:34 --> Total execution time: 0.3860
DEBUG - 2022-10-21 08:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:28:18 --> Total execution time: 0.1600
DEBUG - 2022-10-21 08:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:28:24 --> Total execution time: 0.1823
DEBUG - 2022-10-21 08:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:28:35 --> Total execution time: 0.1821
DEBUG - 2022-10-21 08:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 08:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 08:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 08:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:28:37 --> Total execution time: 0.1683
DEBUG - 2022-10-21 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:30:03 --> Total execution time: 0.1392
DEBUG - 2022-10-21 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:31:00 --> Total execution time: 0.0911
DEBUG - 2022-10-21 09:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:31:30 --> Total execution time: 0.1419
DEBUG - 2022-10-21 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:01:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:31:31 --> Total execution time: 0.0974
DEBUG - 2022-10-21 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:31:32 --> Total execution time: 0.1482
DEBUG - 2022-10-21 09:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:31:33 --> Total execution time: 0.1477
DEBUG - 2022-10-21 09:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:02:14 --> Total execution time: 0.0927
DEBUG - 2022-10-21 09:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:02:17 --> Total execution time: 0.1500
DEBUG - 2022-10-21 09:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:02:17 --> Total execution time: 0.1569
DEBUG - 2022-10-21 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:02:57 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:32:57 --> Total execution time: 0.1469
DEBUG - 2022-10-21 09:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:05:45 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:35:46 --> Total execution time: 0.1609
DEBUG - 2022-10-21 09:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:35:59 --> Total execution time: 0.1565
DEBUG - 2022-10-21 09:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:04 --> Total execution time: 0.4655
DEBUG - 2022-10-21 09:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:04 --> Total execution time: 0.0948
DEBUG - 2022-10-21 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:05 --> Total execution time: 0.0915
DEBUG - 2022-10-21 09:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:10 --> Total execution time: 0.1587
DEBUG - 2022-10-21 09:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:22 --> Total execution time: 0.1511
DEBUG - 2022-10-21 09:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:37 --> Total execution time: 0.1532
DEBUG - 2022-10-21 09:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:44 --> Total execution time: 0.2016
DEBUG - 2022-10-21 09:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:45 --> Total execution time: 0.1503
DEBUG - 2022-10-21 09:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:06:49 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:36:49 --> Total execution time: 0.1047
DEBUG - 2022-10-21 09:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:37:16 --> Total execution time: 0.1495
DEBUG - 2022-10-21 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:38:01 --> Total execution time: 0.1857
DEBUG - 2022-10-21 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:40:03 --> Total execution time: 0.2104
DEBUG - 2022-10-21 09:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:10:49 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:40:49 --> Total execution time: 0.0994
DEBUG - 2022-10-21 09:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 09:11:03 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 09:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:41:04 --> Total execution time: 0.1190
DEBUG - 2022-10-21 09:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:41:19 --> Total execution time: 0.1459
DEBUG - 2022-10-21 09:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:41:44 --> Total execution time: 0.2170
DEBUG - 2022-10-21 09:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:41:47 --> Total execution time: 0.1521
DEBUG - 2022-10-21 09:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:41:56 --> Total execution time: 0.1485
DEBUG - 2022-10-21 09:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:11:57 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:41:57 --> Total execution time: 0.1820
DEBUG - 2022-10-21 09:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:42:51 --> Total execution time: 0.1495
DEBUG - 2022-10-21 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:14:37 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:44:37 --> Total execution time: 0.0971
DEBUG - 2022-10-21 09:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:44:42 --> Total execution time: 0.1471
DEBUG - 2022-10-21 09:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:15:01 --> Total execution time: 0.1524
DEBUG - 2022-10-21 09:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:15:05 --> Total execution time: 0.1474
DEBUG - 2022-10-21 09:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:15:05 --> Total execution time: 0.1442
DEBUG - 2022-10-21 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:45:30 --> Total execution time: 0.1496
DEBUG - 2022-10-21 09:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:17:11 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:47:11 --> Total execution time: 0.0995
DEBUG - 2022-10-21 09:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:18:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:48:42 --> Total execution time: 0.1116
DEBUG - 2022-10-21 09:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:19:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:49:10 --> Total execution time: 0.1097
DEBUG - 2022-10-21 09:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:19:28 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:49:28 --> Total execution time: 0.1285
DEBUG - 2022-10-21 09:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:49:32 --> Total execution time: 0.1631
DEBUG - 2022-10-21 09:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:49:45 --> Total execution time: 0.1858
DEBUG - 2022-10-21 09:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:49:53 --> Total execution time: 0.1613
DEBUG - 2022-10-21 09:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:50:02 --> Total execution time: 0.1511
DEBUG - 2022-10-21 09:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:50:12 --> Total execution time: 0.1464
DEBUG - 2022-10-21 09:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:50:18 --> Total execution time: 0.1510
DEBUG - 2022-10-21 09:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:22 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:50:23 --> Total execution time: 0.1460
DEBUG - 2022-10-21 09:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:30 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:50:31 --> Total execution time: 0.1484
DEBUG - 2022-10-21 09:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:20:40 --> Total execution time: 0.3887
DEBUG - 2022-10-21 09:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:20:43 --> Total execution time: 0.1637
DEBUG - 2022-10-21 09:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:50:43 --> Total execution time: 0.1512
DEBUG - 2022-10-21 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:20:44 --> Total execution time: 0.1513
DEBUG - 2022-10-21 09:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:51:08 --> Total execution time: 0.1545
DEBUG - 2022-10-21 09:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:51:46 --> Total execution time: 0.1532
DEBUG - 2022-10-21 09:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:23:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:53:31 --> Total execution time: 0.1075
DEBUG - 2022-10-21 09:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:53:36 --> Total execution time: 0.1014
DEBUG - 2022-10-21 09:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:53:54 --> Total execution time: 0.1573
DEBUG - 2022-10-21 09:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:54:02 --> Total execution time: 0.1522
DEBUG - 2022-10-21 09:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:54:08 --> Total execution time: 0.1691
DEBUG - 2022-10-21 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:54:09 --> Total execution time: 0.1707
DEBUG - 2022-10-21 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:54:21 --> Total execution time: 0.1606
DEBUG - 2022-10-21 09:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:54:29 --> Total execution time: 0.1644
DEBUG - 2022-10-21 09:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:54:47 --> Total execution time: 0.1464
DEBUG - 2022-10-21 09:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:54:56 --> Total execution time: 0.1617
DEBUG - 2022-10-21 09:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:54:58 --> Total execution time: 0.1556
DEBUG - 2022-10-21 09:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:55:05 --> Total execution time: 0.1614
DEBUG - 2022-10-21 09:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:55:07 --> Total execution time: 0.1713
DEBUG - 2022-10-21 09:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:55:18 --> Total execution time: 0.2451
DEBUG - 2022-10-21 09:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:04 --> Total execution time: 0.4397
DEBUG - 2022-10-21 09:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:05 --> Total execution time: 0.1876
DEBUG - 2022-10-21 09:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:06 --> Total execution time: 0.1562
DEBUG - 2022-10-21 09:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:10 --> Total execution time: 0.1791
DEBUG - 2022-10-21 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:26:29 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:29 --> Total execution time: 0.1473
DEBUG - 2022-10-21 09:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:36 --> Total execution time: 0.1914
DEBUG - 2022-10-21 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:27:08 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:57:09 --> Total execution time: 0.1022
DEBUG - 2022-10-21 09:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:57:14 --> Total execution time: 2.4377
DEBUG - 2022-10-21 09:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 09:27:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 09:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:28:54 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:54 --> Total execution time: 0.1518
DEBUG - 2022-10-21 09:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:58 --> Total execution time: 0.1606
DEBUG - 2022-10-21 09:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:08 --> Total execution time: 0.1141
DEBUG - 2022-10-21 09:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:21 --> Total execution time: 0.1548
DEBUG - 2022-10-21 09:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:24 --> Total execution time: 0.0913
DEBUG - 2022-10-21 09:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:29 --> Total execution time: 0.1787
DEBUG - 2022-10-21 09:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:35 --> Total execution time: 0.1793
DEBUG - 2022-10-21 09:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:43 --> Total execution time: 0.1487
DEBUG - 2022-10-21 09:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:00:01 --> Total execution time: 0.0959
DEBUG - 2022-10-21 09:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:00:06 --> Total execution time: 0.1487
DEBUG - 2022-10-21 09:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:00:07 --> Total execution time: 0.1528
DEBUG - 2022-10-21 09:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:00:22 --> Total execution time: 0.1773
DEBUG - 2022-10-21 09:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:25 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:00:25 --> Total execution time: 0.1456
DEBUG - 2022-10-21 09:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:00:43 --> Total execution time: 0.1553
DEBUG - 2022-10-21 20:00:43 --> Total execution time: 0.1564
DEBUG - 2022-10-21 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:01 --> Total execution time: 0.1854
DEBUG - 2022-10-21 09:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:09 --> Total execution time: 0.2088
DEBUG - 2022-10-21 09:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:34 --> Total execution time: 0.1518
DEBUG - 2022-10-21 09:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:31:47 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:47 --> Total execution time: 0.1469
DEBUG - 2022-10-21 09:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:52 --> Total execution time: 0.1575
DEBUG - 2022-10-21 09:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:31:57 --> Total execution time: 0.1452
DEBUG - 2022-10-21 09:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:01 --> Total execution time: 0.1499
DEBUG - 2022-10-21 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:32:07 --> Total execution time: 0.1469
DEBUG - 2022-10-21 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:32:07 --> Total execution time: 0.1745
DEBUG - 2022-10-21 09:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:32:09 --> Total execution time: 0.1577
DEBUG - 2022-10-21 09:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:32:10 --> Total execution time: 0.1540
DEBUG - 2022-10-21 09:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:23 --> Total execution time: 0.1741
DEBUG - 2022-10-21 09:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:41 --> Total execution time: 0.2244
DEBUG - 2022-10-21 09:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:56 --> Total execution time: 0.1507
DEBUG - 2022-10-21 09:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:03:12 --> Total execution time: 0.1816
DEBUG - 2022-10-21 09:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:03:29 --> Total execution time: 0.1516
DEBUG - 2022-10-21 09:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:03:40 --> Total execution time: 0.1674
DEBUG - 2022-10-21 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:03:52 --> Total execution time: 1.7865
DEBUG - 2022-10-21 09:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 09:33:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 09:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:04:05 --> Total execution time: 0.1620
DEBUG - 2022-10-21 09:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:04:38 --> Total execution time: 0.4212
DEBUG - 2022-10-21 09:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:04:39 --> Total execution time: 0.1620
DEBUG - 2022-10-21 09:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:34:39 --> Total execution time: 0.1423
DEBUG - 2022-10-21 09:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 09:35:22 --> 404 Page Not Found: Courses-v3/esalestrix.in
DEBUG - 2022-10-21 09:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:07:27 --> Total execution time: 1.7801
DEBUG - 2022-10-21 09:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:06 --> Total execution time: 0.1782
DEBUG - 2022-10-21 09:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:42:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:31 --> Total execution time: 0.1091
DEBUG - 2022-10-21 09:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:43 --> Total execution time: 0.4211
DEBUG - 2022-10-21 09:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:54 --> Total execution time: 0.1798
DEBUG - 2022-10-21 09:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:03 --> Total execution time: 0.1487
DEBUG - 2022-10-21 09:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:11 --> Total execution time: 0.1561
DEBUG - 2022-10-21 09:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 09:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:12 --> Total execution time: 0.1416
DEBUG - 2022-10-21 09:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:15 --> Total execution time: 0.1558
DEBUG - 2022-10-21 09:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:35 --> Total execution time: 0.1517
DEBUG - 2022-10-21 09:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:44 --> Total execution time: 0.1495
DEBUG - 2022-10-21 09:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:14:11 --> Total execution time: 0.1515
DEBUG - 2022-10-21 09:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:14:52 --> Total execution time: 0.1506
DEBUG - 2022-10-21 09:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:14:59 --> Total execution time: 0.1566
DEBUG - 2022-10-21 09:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:45:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:15:03 --> Total execution time: 0.1411
DEBUG - 2022-10-21 09:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:15:03 --> Total execution time: 0.1927
DEBUG - 2022-10-21 09:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:15:12 --> Total execution time: 0.1580
DEBUG - 2022-10-21 09:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:15:34 --> Total execution time: 0.1593
DEBUG - 2022-10-21 09:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:15:35 --> Total execution time: 0.1518
DEBUG - 2022-10-21 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 09:51:24 --> No URI present. Default controller set.
DEBUG - 2022-10-21 09:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 09:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:21:25 --> Total execution time: 0.1918
DEBUG - 2022-10-21 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:30:03 --> Total execution time: 0.1773
DEBUG - 2022-10-21 10:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:03:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:33:58 --> Total execution time: 0.1963
DEBUG - 2022-10-21 10:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:04:06 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:34:07 --> Total execution time: 0.1453
DEBUG - 2022-10-21 10:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:34:12 --> Total execution time: 0.0990
DEBUG - 2022-10-21 10:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:34:20 --> Total execution time: 0.1565
DEBUG - 2022-10-21 10:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:34:37 --> Total execution time: 0.1947
DEBUG - 2022-10-21 10:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:35:24 --> Total execution time: 0.3722
DEBUG - 2022-10-21 10:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:35:30 --> Total execution time: 0.2289
DEBUG - 2022-10-21 10:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:37:08 --> Total execution time: 0.2186
DEBUG - 2022-10-21 10:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:37:09 --> Total execution time: 0.2443
DEBUG - 2022-10-21 10:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:37:17 --> Total execution time: 1.1144
DEBUG - 2022-10-21 10:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:37:35 --> Total execution time: 0.2282
DEBUG - 2022-10-21 10:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:37:37 --> Total execution time: 0.3248
DEBUG - 2022-10-21 10:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:07:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 10:07:41 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-10-21 10:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:37:43 --> Total execution time: 0.6920
DEBUG - 2022-10-21 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:40:31 --> Total execution time: 0.1418
DEBUG - 2022-10-21 10:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:11:48 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:41:48 --> Total execution time: 0.0980
DEBUG - 2022-10-21 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:11:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 10:11:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 10:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:12:05 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:42:05 --> Total execution time: 0.1459
DEBUG - 2022-10-21 10:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:42:28 --> Total execution time: 0.1258
DEBUG - 2022-10-21 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:42:42 --> Total execution time: 0.1449
DEBUG - 2022-10-21 10:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:42:52 --> Total execution time: 0.1620
DEBUG - 2022-10-21 10:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:43:19 --> Total execution time: 0.4939
DEBUG - 2022-10-21 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:13:37 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:43:37 --> Total execution time: 0.0957
DEBUG - 2022-10-21 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:14:30 --> Total execution time: 0.1454
DEBUG - 2022-10-21 10:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:14:37 --> Total execution time: 0.1535
DEBUG - 2022-10-21 10:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:14:37 --> Total execution time: 0.3326
DEBUG - 2022-10-21 10:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:17:14 --> Total execution time: 0.1446
DEBUG - 2022-10-21 10:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:47:27 --> Total execution time: 0.1468
DEBUG - 2022-10-21 10:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:47:34 --> Total execution time: 0.2019
DEBUG - 2022-10-21 10:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:47:37 --> Total execution time: 0.1862
DEBUG - 2022-10-21 10:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:47:43 --> Total execution time: 0.1669
DEBUG - 2022-10-21 20:47:45 --> Total execution time: 2.3033
DEBUG - 2022-10-21 10:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:17:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 10:17:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 10:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:48:44 --> Total execution time: 0.1940
DEBUG - 2022-10-21 10:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:48:45 --> Total execution time: 0.3546
DEBUG - 2022-10-21 10:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:48:53 --> Total execution time: 0.4234
DEBUG - 2022-10-21 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:49:35 --> Total execution time: 0.1525
DEBUG - 2022-10-21 10:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:23:38 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:53:38 --> Total execution time: 0.1739
DEBUG - 2022-10-21 10:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:26:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:56:55 --> Total execution time: 0.1644
DEBUG - 2022-10-21 10:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:05 --> Total execution time: 0.0939
DEBUG - 2022-10-21 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:19 --> Total execution time: 0.1538
DEBUG - 2022-10-21 10:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:33 --> Total execution time: 0.1872
DEBUG - 2022-10-21 10:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:06 --> Total execution time: 0.1849
DEBUG - 2022-10-21 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:14 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:14 --> Total execution time: 0.0954
DEBUG - 2022-10-21 10:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:24 --> Total execution time: 0.0915
DEBUG - 2022-10-21 10:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:33 --> Total execution time: 0.1537
DEBUG - 2022-10-21 10:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:39 --> Total execution time: 0.1581
DEBUG - 2022-10-21 10:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:45 --> Total execution time: 0.1533
DEBUG - 2022-10-21 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:49 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:49 --> Total execution time: 0.0946
DEBUG - 2022-10-21 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:55 --> Total execution time: 0.0912
DEBUG - 2022-10-21 10:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:59:36 --> Total execution time: 0.1444
DEBUG - 2022-10-21 10:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:59:41 --> Total execution time: 0.1370
DEBUG - 2022-10-21 10:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:30:28 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:00:29 --> Total execution time: 0.0936
DEBUG - 2022-10-21 10:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:30:57 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:00:57 --> Total execution time: 0.0981
DEBUG - 2022-10-21 10:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:28 --> Total execution time: 0.1453
DEBUG - 2022-10-21 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:36 --> Total execution time: 0.1519
DEBUG - 2022-10-21 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:31:37 --> Total execution time: 0.1433
DEBUG - 2022-10-21 10:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:02:09 --> Total execution time: 0.1435
DEBUG - 2022-10-21 10:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:02:29 --> Total execution time: 0.1618
DEBUG - 2022-10-21 10:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:02:31 --> Total execution time: 0.1495
DEBUG - 2022-10-21 10:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:02:33 --> Total execution time: 0.1864
DEBUG - 2022-10-21 10:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:02:41 --> Total execution time: 1.7793
DEBUG - 2022-10-21 10:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:02:45 --> Total execution time: 0.1499
DEBUG - 2022-10-21 10:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:02:50 --> Total execution time: 0.1543
DEBUG - 2022-10-21 10:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 10:32:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 10:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:03:01 --> Total execution time: 0.1553
DEBUG - 2022-10-21 10:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:03:09 --> Total execution time: 0.1460
DEBUG - 2022-10-21 10:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 10:33:31 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:33:38 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:03:39 --> Total execution time: 0.0913
DEBUG - 2022-10-21 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:03:54 --> Total execution time: 0.1447
DEBUG - 2022-10-21 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:04:01 --> Total execution time: 0.1486
DEBUG - 2022-10-21 10:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:04:05 --> Total execution time: 0.1565
DEBUG - 2022-10-21 10:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:04:12 --> Total execution time: 0.1535
DEBUG - 2022-10-21 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:04:14 --> Total execution time: 0.1580
DEBUG - 2022-10-21 10:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:35:46 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:05:46 --> Total execution time: 0.0992
DEBUG - 2022-10-21 10:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:37:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:07:10 --> Total execution time: 0.1001
DEBUG - 2022-10-21 10:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:37:21 --> Total execution time: 0.1549
DEBUG - 2022-10-21 10:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:37:23 --> Total execution time: 0.1511
DEBUG - 2022-10-21 10:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:37:23 --> Total execution time: 0.1608
DEBUG - 2022-10-21 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 10:38:12 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-10-21 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:38:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:08:13 --> Total execution time: 0.0904
DEBUG - 2022-10-21 10:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 10:38:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-10-21 10:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:38:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 10:38:18 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-10-21 10:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:08:26 --> Total execution time: 0.0866
DEBUG - 2022-10-21 10:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:39:00 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:09:01 --> Total execution time: 0.4147
DEBUG - 2022-10-21 10:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:39:09 --> Total execution time: 0.1578
DEBUG - 2022-10-21 10:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:39:12 --> Total execution time: 0.1527
DEBUG - 2022-10-21 10:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:39:12 --> Total execution time: 0.3921
DEBUG - 2022-10-21 10:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:40:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:10:01 --> Total execution time: 0.1331
DEBUG - 2022-10-21 10:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:41:31 --> Total execution time: 0.1457
DEBUG - 2022-10-21 10:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:41:33 --> Total execution time: 0.1459
DEBUG - 2022-10-21 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:41:34 --> Total execution time: 0.1524
DEBUG - 2022-10-21 10:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:13:00 --> Total execution time: 0.1772
DEBUG - 2022-10-21 10:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:17 --> Total execution time: 0.1374
DEBUG - 2022-10-21 10:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:27 --> Total execution time: 0.1508
DEBUG - 2022-10-21 10:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:35 --> Total execution time: 0.1530
DEBUG - 2022-10-21 10:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:44:40 --> Total execution time: 0.1438
DEBUG - 2022-10-21 10:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:43 --> Total execution time: 0.1513
DEBUG - 2022-10-21 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:44 --> Total execution time: 0.1496
DEBUG - 2022-10-21 10:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:49 --> Total execution time: 0.1921
DEBUG - 2022-10-21 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:57 --> Total execution time: 0.1658
DEBUG - 2022-10-21 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:58 --> Total execution time: 0.1481
DEBUG - 2022-10-21 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:07 --> Total execution time: 0.1816
DEBUG - 2022-10-21 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:14 --> Total execution time: 0.1821
DEBUG - 2022-10-21 10:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:19 --> Total execution time: 0.1738
DEBUG - 2022-10-21 10:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:25 --> Total execution time: 0.1530
DEBUG - 2022-10-21 10:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:59 --> Total execution time: 0.1521
DEBUG - 2022-10-21 10:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:16:03 --> Total execution time: 0.1557
DEBUG - 2022-10-21 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:16:13 --> Total execution time: 0.1498
DEBUG - 2022-10-21 10:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:26 --> Total execution time: 0.1504
DEBUG - 2022-10-21 10:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:27 --> Total execution time: 0.1476
DEBUG - 2022-10-21 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:28 --> Total execution time: 0.1502
DEBUG - 2022-10-21 10:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:31 --> Total execution time: 0.8821
DEBUG - 2022-10-21 10:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:19:51 --> Total execution time: 0.4473
DEBUG - 2022-10-21 10:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:19:52 --> Total execution time: 0.1859
DEBUG - 2022-10-21 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:20:29 --> Total execution time: 0.3333
DEBUG - 2022-10-21 10:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:20:47 --> Total execution time: 0.1784
DEBUG - 2022-10-21 10:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:23:19 --> Total execution time: 0.1434
DEBUG - 2022-10-21 10:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:23:31 --> Total execution time: 0.1526
DEBUG - 2022-10-21 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 10:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:25:35 --> Total execution time: 0.1422
DEBUG - 2022-10-21 10:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 10:59:14 --> No URI present. Default controller set.
DEBUG - 2022-10-21 10:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 10:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:29:15 --> Total execution time: 0.1728
DEBUG - 2022-10-21 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:30:02 --> Total execution time: 0.1063
DEBUG - 2022-10-21 11:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:30:06 --> Total execution time: 0.1650
DEBUG - 2022-10-21 11:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:31:46 --> Total execution time: 0.1438
DEBUG - 2022-10-21 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:50 --> Total execution time: 0.1464
DEBUG - 2022-10-21 11:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:36:04 --> Total execution time: 0.1871
DEBUG - 2022-10-21 11:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:36:06 --> Total execution time: 0.1506
DEBUG - 2022-10-21 11:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:36:07 --> Total execution time: 0.4335
DEBUG - 2022-10-21 11:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:36:20 --> Total execution time: 0.2207
DEBUG - 2022-10-21 11:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:36:32 --> Total execution time: 0.1473
DEBUG - 2022-10-21 11:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:06:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:36:45 --> Total execution time: 0.1554
DEBUG - 2022-10-21 11:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:07:11 --> Total execution time: 0.1485
DEBUG - 2022-10-21 11:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:07:14 --> Total execution time: 0.1503
DEBUG - 2022-10-21 11:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:07:14 --> Total execution time: 0.1512
DEBUG - 2022-10-21 11:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:08:20 --> Total execution time: 0.1019
DEBUG - 2022-10-21 11:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:38:35 --> Total execution time: 2.4965
DEBUG - 2022-10-21 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 11:09:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 11:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:09:08 --> Total execution time: 0.1418
DEBUG - 2022-10-21 11:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:39:08 --> Total execution time: 0.1441
DEBUG - 2022-10-21 11:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:39:46 --> Total execution time: 0.1507
DEBUG - 2022-10-21 11:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:39:48 --> Total execution time: 0.3099
DEBUG - 2022-10-21 11:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:39:50 --> Total execution time: 0.1694
DEBUG - 2022-10-21 11:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:39:57 --> Total execution time: 0.1463
DEBUG - 2022-10-21 11:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:39:58 --> Total execution time: 0.1643
DEBUG - 2022-10-21 11:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:40:06 --> Total execution time: 0.1501
DEBUG - 2022-10-21 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:40:11 --> Total execution time: 0.1848
DEBUG - 2022-10-21 11:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:41:40 --> Total execution time: 0.1726
DEBUG - 2022-10-21 11:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:42:45 --> Total execution time: 0.4656
DEBUG - 2022-10-21 11:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:43:17 --> Total execution time: 0.1431
DEBUG - 2022-10-21 11:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:13:52 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:43:52 --> Total execution time: 0.0955
DEBUG - 2022-10-21 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:44:03 --> Total execution time: 0.1599
DEBUG - 2022-10-21 11:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:44:04 --> Total execution time: 0.1518
DEBUG - 2022-10-21 11:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:44:10 --> Total execution time: 0.2226
DEBUG - 2022-10-21 11:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:44:40 --> Total execution time: 0.0944
DEBUG - 2022-10-21 11:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:45:09 --> Total execution time: 0.1515
DEBUG - 2022-10-21 11:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:45:13 --> Total execution time: 0.1532
DEBUG - 2022-10-21 11:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:45:26 --> Total execution time: 0.1821
DEBUG - 2022-10-21 11:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:46:03 --> Total execution time: 0.1424
DEBUG - 2022-10-21 11:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:46:29 --> Total execution time: 0.1505
DEBUG - 2022-10-21 11:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:46:33 --> Total execution time: 0.1419
DEBUG - 2022-10-21 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:46:54 --> Total execution time: 0.1529
DEBUG - 2022-10-21 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:46:55 --> Total execution time: 0.1615
DEBUG - 2022-10-21 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:01 --> Total execution time: 0.1454
DEBUG - 2022-10-21 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:11 --> Total execution time: 0.1468
DEBUG - 2022-10-21 11:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:25 --> Total execution time: 0.1522
DEBUG - 2022-10-21 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:29 --> Total execution time: 0.1566
DEBUG - 2022-10-21 11:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:37 --> Total execution time: 0.1421
DEBUG - 2022-10-21 11:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:50 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:50 --> Total execution time: 0.1321
DEBUG - 2022-10-21 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:56 --> Total execution time: 0.1624
DEBUG - 2022-10-21 11:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:48:02 --> Total execution time: 0.1906
DEBUG - 2022-10-21 11:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:48:03 --> Total execution time: 0.1101
DEBUG - 2022-10-21 11:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:48:12 --> Total execution time: 0.1862
DEBUG - 2022-10-21 11:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:48:13 --> Total execution time: 0.1683
DEBUG - 2022-10-21 11:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:48:18 --> Total execution time: 0.1494
DEBUG - 2022-10-21 11:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:48:30 --> Total execution time: 0.1610
DEBUG - 2022-10-21 11:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:48:35 --> Total execution time: 0.1656
DEBUG - 2022-10-21 11:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:48:53 --> Total execution time: 0.1573
DEBUG - 2022-10-21 11:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:49:03 --> Total execution time: 0.1709
DEBUG - 2022-10-21 11:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:19:12 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:49:12 --> Total execution time: 0.1636
DEBUG - 2022-10-21 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:49:26 --> Total execution time: 0.1697
DEBUG - 2022-10-21 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:49:29 --> Total execution time: 0.1716
DEBUG - 2022-10-21 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:49:29 --> Total execution time: 0.1982
DEBUG - 2022-10-21 11:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:49:30 --> Total execution time: 0.3567
DEBUG - 2022-10-21 11:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:50:45 --> Total execution time: 0.0986
DEBUG - 2022-10-21 11:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:50:47 --> Total execution time: 0.1744
DEBUG - 2022-10-21 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:23:11 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:53:11 --> Total execution time: 0.1784
DEBUG - 2022-10-21 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:24:19 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:54:19 --> Total execution time: 0.1118
DEBUG - 2022-10-21 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:54:31 --> Total execution time: 0.1494
DEBUG - 2022-10-21 11:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:54:39 --> Total execution time: 0.1595
DEBUG - 2022-10-21 11:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:54:52 --> Total execution time: 0.1921
DEBUG - 2022-10-21 11:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:55:03 --> Total execution time: 0.1754
DEBUG - 2022-10-21 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:55:07 --> Total execution time: 0.1852
DEBUG - 2022-10-21 11:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:55:30 --> Total execution time: 0.1520
DEBUG - 2022-10-21 11:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:55:34 --> Total execution time: 0.2005
DEBUG - 2022-10-21 11:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:55:35 --> Total execution time: 0.4450
DEBUG - 2022-10-21 11:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:55:58 --> Total execution time: 0.1512
DEBUG - 2022-10-21 11:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:56:01 --> Total execution time: 0.1564
DEBUG - 2022-10-21 11:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:56:05 --> Total execution time: 0.1507
DEBUG - 2022-10-21 11:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:56:16 --> Total execution time: 0.1541
DEBUG - 2022-10-21 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:56:39 --> Total execution time: 0.1446
DEBUG - 2022-10-21 11:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:57:08 --> Total execution time: 0.4309
DEBUG - 2022-10-21 11:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:00 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:00 --> Total execution time: 0.1032
DEBUG - 2022-10-21 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:02 --> Total execution time: 0.0904
DEBUG - 2022-10-21 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:03 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:03 --> Total execution time: 0.1546
DEBUG - 2022-10-21 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:16 --> Total execution time: 0.0916
DEBUG - 2022-10-21 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:27 --> Total execution time: 0.0932
DEBUG - 2022-10-21 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:28 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:28 --> Total execution time: 0.0871
DEBUG - 2022-10-21 11:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:34 --> Total execution time: 0.1419
DEBUG - 2022-10-21 11:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:44 --> Total execution time: 0.0948
DEBUG - 2022-10-21 11:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:44 --> Total execution time: 0.1552
DEBUG - 2022-10-21 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:48 --> Total execution time: 0.0936
DEBUG - 2022-10-21 11:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:50 --> Total execution time: 0.1378
DEBUG - 2022-10-21 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:53 --> Total execution time: 0.0866
DEBUG - 2022-10-21 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:04 --> Total execution time: 0.1454
DEBUG - 2022-10-21 11:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:08 --> Total execution time: 0.4004
DEBUG - 2022-10-21 11:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:12 --> Total execution time: 0.1590
DEBUG - 2022-10-21 11:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:14 --> Total execution time: 0.1457
DEBUG - 2022-10-21 11:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:15 --> Total execution time: 0.1421
DEBUG - 2022-10-21 11:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:15 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:15 --> Total execution time: 0.3841
DEBUG - 2022-10-21 11:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:19 --> Total execution time: 0.1512
DEBUG - 2022-10-21 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:29 --> Total execution time: 0.1685
DEBUG - 2022-10-21 11:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:50 --> Total execution time: 0.1508
DEBUG - 2022-10-21 11:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:52 --> Total execution time: 0.1487
DEBUG - 2022-10-21 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:57 --> Total execution time: 0.1648
DEBUG - 2022-10-21 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:00:03 --> Total execution time: 0.1704
DEBUG - 2022-10-21 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:00:13 --> Total execution time: 0.1592
DEBUG - 2022-10-21 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:00:19 --> Total execution time: 0.2811
DEBUG - 2022-10-21 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:00:35 --> Total execution time: 0.1572
DEBUG - 2022-10-21 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:01:15 --> Total execution time: 0.1910
DEBUG - 2022-10-21 11:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:01:53 --> Total execution time: 0.1549
DEBUG - 2022-10-21 11:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:03:07 --> Total execution time: 0.0920
DEBUG - 2022-10-21 11:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:33:52 --> Total execution time: 0.1514
DEBUG - 2022-10-21 11:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:34:10 --> Total execution time: 0.1880
DEBUG - 2022-10-21 11:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:04:38 --> Total execution time: 0.1554
DEBUG - 2022-10-21 11:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:05:04 --> Total execution time: 0.3876
DEBUG - 2022-10-21 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:05:11 --> Total execution time: 0.3983
DEBUG - 2022-10-21 11:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:05:27 --> Total execution time: 0.1589
DEBUG - 2022-10-21 11:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:09:02 --> Total execution time: 0.2158
DEBUG - 2022-10-21 11:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:40:30 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:10:30 --> Total execution time: 0.0973
DEBUG - 2022-10-21 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:41:25 --> Total execution time: 0.1893
DEBUG - 2022-10-21 11:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:41:26 --> Total execution time: 0.1496
DEBUG - 2022-10-21 11:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:41:28 --> Total execution time: 0.1529
DEBUG - 2022-10-21 11:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:41:29 --> Total execution time: 0.1431
DEBUG - 2022-10-21 11:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:41:36 --> Total execution time: 0.1647
DEBUG - 2022-10-21 11:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:42:12 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:12:12 --> Total execution time: 0.1530
DEBUG - 2022-10-21 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:12:40 --> Total execution time: 0.1471
DEBUG - 2022-10-21 11:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:42:45 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:12:45 --> Total execution time: 0.1168
DEBUG - 2022-10-21 11:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:04 --> Total execution time: 0.2126
DEBUG - 2022-10-21 11:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:17 --> Total execution time: 0.1444
DEBUG - 2022-10-21 11:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:18 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:18 --> Total execution time: 0.0934
DEBUG - 2022-10-21 11:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:19 --> Total execution time: 0.1559
DEBUG - 2022-10-21 11:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:19 --> Total execution time: 0.1544
DEBUG - 2022-10-21 11:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:24 --> Total execution time: 0.1432
DEBUG - 2022-10-21 11:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:25 --> Total execution time: 0.0915
DEBUG - 2022-10-21 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:41 --> Total execution time: 0.1455
DEBUG - 2022-10-21 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:51 --> Total execution time: 0.1545
DEBUG - 2022-10-21 11:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:55 --> Total execution time: 0.1502
DEBUG - 2022-10-21 11:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:57 --> Total execution time: 0.1452
DEBUG - 2022-10-21 11:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-10-21 11:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:16 --> Total execution time: 0.1877
DEBUG - 2022-10-21 11:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:19 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:19 --> Total execution time: 0.1079
DEBUG - 2022-10-21 11:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:24 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:24 --> Total execution time: 0.1529
DEBUG - 2022-10-21 11:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:33 --> Total execution time: 0.1424
DEBUG - 2022-10-21 11:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:37 --> Total execution time: 0.1793
DEBUG - 2022-10-21 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:37 --> Total execution time: 0.1370
DEBUG - 2022-10-21 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:52 --> Total execution time: 0.1478
DEBUG - 2022-10-21 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:15:05 --> Total execution time: 0.1496
DEBUG - 2022-10-21 11:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:16:14 --> Total execution time: 0.1508
DEBUG - 2022-10-21 11:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:16:49 --> Total execution time: 0.2200
DEBUG - 2022-10-21 11:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:16:52 --> Total execution time: 0.1541
DEBUG - 2022-10-21 11:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:17:20 --> Total execution time: 0.2280
DEBUG - 2022-10-21 11:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:39 --> Total execution time: 0.4004
DEBUG - 2022-10-21 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:53 --> Total execution time: 0.1529
DEBUG - 2022-10-21 11:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:07 --> Total execution time: 0.1458
DEBUG - 2022-10-21 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:25 --> Total execution time: 0.1783
DEBUG - 2022-10-21 11:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:39 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:39 --> Total execution time: 0.1111
DEBUG - 2022-10-21 11:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:45 --> Total execution time: 0.4147
DEBUG - 2022-10-21 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:49 --> Total execution time: 0.1805
DEBUG - 2022-10-21 11:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:50 --> Total execution time: 0.2464
DEBUG - 2022-10-21 11:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:52 --> Total execution time: 0.2516
DEBUG - 2022-10-21 11:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:56 --> Total execution time: 0.2041
DEBUG - 2022-10-21 11:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:57 --> Total execution time: 0.1868
DEBUG - 2022-10-21 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:58 --> Total execution time: 0.1704
DEBUG - 2022-10-21 11:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:20:07 --> Total execution time: 0.2181
DEBUG - 2022-10-21 11:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:50:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:20:10 --> Total execution time: 0.2010
DEBUG - 2022-10-21 11:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:50:11 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:20:11 --> Total execution time: 0.1664
DEBUG - 2022-10-21 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:20:19 --> Total execution time: 0.1427
DEBUG - 2022-10-21 11:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:20:36 --> Total execution time: 0.4245
DEBUG - 2022-10-21 11:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:20:42 --> Total execution time: 0.1544
DEBUG - 2022-10-21 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:20:59 --> Total execution time: 0.1479
DEBUG - 2022-10-21 11:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:21:03 --> Total execution time: 0.1442
DEBUG - 2022-10-21 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:22:34 --> Total execution time: 0.1745
DEBUG - 2022-10-21 11:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:52:42 --> Total execution time: 0.1450
DEBUG - 2022-10-21 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:52:55 --> Total execution time: 0.1572
DEBUG - 2022-10-21 11:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:22:57 --> Total execution time: 0.1467
DEBUG - 2022-10-21 11:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:53:22 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:23:22 --> Total execution time: 0.3944
DEBUG - 2022-10-21 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:53:35 --> Total execution time: 0.1428
DEBUG - 2022-10-21 11:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:53:47 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:23:47 --> Total execution time: 0.1542
DEBUG - 2022-10-21 11:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:53:48 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:23:48 --> Total execution time: 0.1408
DEBUG - 2022-10-21 11:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:53:49 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:23:50 --> Total execution time: 0.1450
DEBUG - 2022-10-21 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:47 --> Total execution time: 0.1469
DEBUG - 2022-10-21 11:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:54:53 --> Total execution time: 0.1463
DEBUG - 2022-10-21 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:55:03 --> Total execution time: 0.1522
DEBUG - 2022-10-21 11:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:55:24 --> Total execution time: 0.1746
DEBUG - 2022-10-21 11:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:55:33 --> Total execution time: 0.1411
DEBUG - 2022-10-21 11:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:55:36 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:25:36 --> Total execution time: 0.0976
DEBUG - 2022-10-21 11:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 11:55:51 --> Total execution time: 0.1467
DEBUG - 2022-10-21 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 11:56:34 --> No URI present. Default controller set.
DEBUG - 2022-10-21 11:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 11:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:26:34 --> Total execution time: 0.1070
DEBUG - 2022-10-21 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:30:03 --> Total execution time: 0.1704
DEBUG - 2022-10-21 12:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:43 --> Total execution time: 0.4014
DEBUG - 2022-10-21 12:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:00:54 --> Total execution time: 0.1475
DEBUG - 2022-10-21 12:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:05 --> Total execution time: 0.1571
DEBUG - 2022-10-21 12:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:14 --> Total execution time: 0.1799
DEBUG - 2022-10-21 12:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:22 --> Total execution time: 0.1570
DEBUG - 2022-10-21 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:34 --> Total execution time: 0.1656
DEBUG - 2022-10-21 12:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:43 --> Total execution time: 0.1824
DEBUG - 2022-10-21 12:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:49 --> Total execution time: 0.1559
DEBUG - 2022-10-21 12:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:03:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:55 --> Total execution time: 0.1009
DEBUG - 2022-10-21 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:01 --> Total execution time: 0.1544
DEBUG - 2022-10-21 12:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:06 --> Total execution time: 0.1540
DEBUG - 2022-10-21 12:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:10 --> Total execution time: 0.0956
DEBUG - 2022-10-21 12:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:13 --> Total execution time: 0.1649
DEBUG - 2022-10-21 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:38 --> Total execution time: 0.1478
DEBUG - 2022-10-21 12:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:48 --> Total execution time: 0.4161
DEBUG - 2022-10-21 12:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:18 --> Total execution time: 0.1441
DEBUG - 2022-10-21 12:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:18 --> Total execution time: 0.1531
DEBUG - 2022-10-21 12:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:42 --> Total execution time: 0.1504
DEBUG - 2022-10-21 12:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:36:00 --> Total execution time: 0.1966
DEBUG - 2022-10-21 12:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:36:08 --> Total execution time: 0.1860
DEBUG - 2022-10-21 12:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:36:13 --> Total execution time: 0.1522
DEBUG - 2022-10-21 12:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:36:22 --> Total execution time: 0.1885
DEBUG - 2022-10-21 12:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:06:37 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:36:37 --> Total execution time: 0.0944
DEBUG - 2022-10-21 12:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:37:24 --> Total execution time: 0.4017
DEBUG - 2022-10-21 12:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:39:00 --> Total execution time: 0.0973
DEBUG - 2022-10-21 12:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:09:09 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:39:09 --> Total execution time: 0.1482
DEBUG - 2022-10-21 12:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:09:19 --> Total execution time: 0.1581
DEBUG - 2022-10-21 12:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:09:21 --> Total execution time: 0.1516
DEBUG - 2022-10-21 12:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:09:22 --> Total execution time: 0.1500
DEBUG - 2022-10-21 12:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:09:35 --> Total execution time: 0.1452
DEBUG - 2022-10-21 12:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:09:41 --> Total execution time: 0.1556
DEBUG - 2022-10-21 12:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:02 --> Total execution time: 0.1435
DEBUG - 2022-10-21 12:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:40:58 --> Total execution time: 0.1912
DEBUG - 2022-10-21 12:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:40:59 --> Total execution time: 0.1493
DEBUG - 2022-10-21 12:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:10 --> Total execution time: 0.1531
DEBUG - 2022-10-21 12:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:16 --> Total execution time: 0.1490
DEBUG - 2022-10-21 12:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:22 --> Total execution time: 0.1666
DEBUG - 2022-10-21 12:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:25 --> Total execution time: 0.3887
DEBUG - 2022-10-21 12:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:32 --> Total execution time: 0.2369
DEBUG - 2022-10-21 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:11:35 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:35 --> Total execution time: 0.1478
DEBUG - 2022-10-21 12:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:45 --> Total execution time: 0.1813
DEBUG - 2022-10-21 12:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:46 --> Total execution time: 0.1545
DEBUG - 2022-10-21 12:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:42:12 --> Total execution time: 0.1508
DEBUG - 2022-10-21 12:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:42:41 --> Total execution time: 0.1635
DEBUG - 2022-10-21 12:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:42:48 --> Total execution time: 0.1886
DEBUG - 2022-10-21 12:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:12:51 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:42:51 --> Total execution time: 0.1498
DEBUG - 2022-10-21 12:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:43:01 --> Total execution time: 2.3492
DEBUG - 2022-10-21 12:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:13:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 12:13:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 12:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:43:12 --> Total execution time: 0.4238
DEBUG - 2022-10-21 12:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:43:17 --> Total execution time: 0.1554
DEBUG - 2022-10-21 12:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:43:57 --> Total execution time: 0.1518
DEBUG - 2022-10-21 12:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:01 --> Total execution time: 0.1782
DEBUG - 2022-10-21 12:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:04 --> Total execution time: 0.3089
DEBUG - 2022-10-21 12:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:13 --> Total execution time: 1.7629
DEBUG - 2022-10-21 12:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:15:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:45:58 --> Total execution time: 0.1477
DEBUG - 2022-10-21 12:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:15:59 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:45:59 --> Total execution time: 0.2155
DEBUG - 2022-10-21 12:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:16:15 --> Total execution time: 0.1596
DEBUG - 2022-10-21 12:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:46:30 --> Total execution time: 0.1501
DEBUG - 2022-10-21 12:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 12:16:50 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:48:13 --> Total execution time: 0.3827
DEBUG - 2022-10-21 12:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:48:37 --> Total execution time: 0.1489
DEBUG - 2022-10-21 12:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:24:08 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:54:08 --> Total execution time: 0.4808
DEBUG - 2022-10-21 12:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:54:24 --> Total execution time: 0.1730
DEBUG - 2022-10-21 12:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:54:36 --> Total execution time: 0.1974
DEBUG - 2022-10-21 12:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:54:46 --> Total execution time: 0.1926
DEBUG - 2022-10-21 12:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:24:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:54:58 --> Total execution time: 0.0956
DEBUG - 2022-10-21 12:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:55:02 --> Total execution time: 0.1803
DEBUG - 2022-10-21 12:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:55:15 --> Total execution time: 0.2250
DEBUG - 2022-10-21 12:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 12:26:00 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-10-21 12:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:26:00 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:56:00 --> Total execution time: 0.0979
DEBUG - 2022-10-21 12:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 12:26:01 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-10-21 12:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:56:01 --> Total execution time: 0.0913
DEBUG - 2022-10-21 12:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:26:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 12:26:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 12:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:56:02 --> Total execution time: 0.1052
DEBUG - 2022-10-21 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:56:14 --> Total execution time: 0.1853
DEBUG - 2022-10-21 12:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:32 --> Total execution time: 0.2000
DEBUG - 2022-10-21 12:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:33 --> Total execution time: 0.1817
DEBUG - 2022-10-21 12:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:34 --> Total execution time: 0.1852
DEBUG - 2022-10-21 12:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:58:35 --> Total execution time: 0.1805
DEBUG - 2022-10-21 12:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:35 --> Total execution time: 0.2044
DEBUG - 2022-10-21 12:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:28:37 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:37 --> Total execution time: 0.1462
DEBUG - 2022-10-21 12:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:28:56 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:56 --> Total execution time: 0.1538
DEBUG - 2022-10-21 12:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:59:01 --> Total execution time: 0.1799
DEBUG - 2022-10-21 12:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:59:09 --> Total execution time: 0.1854
DEBUG - 2022-10-21 12:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:29:43 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:59:43 --> Total execution time: 0.3842
DEBUG - 2022-10-21 12:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:59:50 --> Total execution time: 0.1490
DEBUG - 2022-10-21 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:00:36 --> Total execution time: 0.1536
DEBUG - 2022-10-21 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:00:43 --> Total execution time: 0.1816
DEBUG - 2022-10-21 12:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:01:44 --> Total execution time: 0.0925
DEBUG - 2022-10-21 12:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:01:51 --> Total execution time: 0.1831
DEBUG - 2022-10-21 12:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:01:52 --> Total execution time: 0.1655
DEBUG - 2022-10-21 12:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:31:52 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:01:53 --> Total execution time: 0.3906
DEBUG - 2022-10-21 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:01:56 --> Total execution time: 0.1765
DEBUG - 2022-10-21 12:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:01 --> Total execution time: 0.1974
DEBUG - 2022-10-21 12:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:09 --> Total execution time: 0.1923
DEBUG - 2022-10-21 12:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:16 --> Total execution time: 0.1559
DEBUG - 2022-10-21 12:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:21 --> Total execution time: 0.1713
DEBUG - 2022-10-21 12:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:30 --> Total execution time: 0.1975
DEBUG - 2022-10-21 12:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:31 --> Total execution time: 0.1490
DEBUG - 2022-10-21 12:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:37 --> Total execution time: 0.1889
DEBUG - 2022-10-21 12:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:38 --> Total execution time: 0.1633
DEBUG - 2022-10-21 12:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:42 --> Total execution time: 0.1502
DEBUG - 2022-10-21 12:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:43 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:43 --> Total execution time: 0.1459
DEBUG - 2022-10-21 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:44 --> Total execution time: 0.1461
DEBUG - 2022-10-21 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:44 --> Total execution time: 0.1459
DEBUG - 2022-10-21 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:50 --> Total execution time: 0.1563
DEBUG - 2022-10-21 12:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:02:52 --> Total execution time: 0.1438
DEBUG - 2022-10-21 12:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:03:02 --> Total execution time: 0.1665
DEBUG - 2022-10-21 12:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:03:03 --> Total execution time: 0.1518
DEBUG - 2022-10-21 12:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:03:03 --> Total execution time: 0.1571
DEBUG - 2022-10-21 12:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:03:04 --> Total execution time: 0.1854
DEBUG - 2022-10-21 12:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:03:15 --> Total execution time: 0.1824
DEBUG - 2022-10-21 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:03:47 --> Total execution time: 0.1828
DEBUG - 2022-10-21 12:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:03:48 --> Total execution time: 0.1449
DEBUG - 2022-10-21 12:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:03:51 --> Total execution time: 0.1442
DEBUG - 2022-10-21 12:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:04:10 --> Total execution time: 0.1445
DEBUG - 2022-10-21 12:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:04:15 --> Total execution time: 0.1370
DEBUG - 2022-10-21 12:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:04:30 --> Total execution time: 0.1436
DEBUG - 2022-10-21 12:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:05:35 --> Total execution time: 0.4257
DEBUG - 2022-10-21 12:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:35:50 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:05:50 --> Total execution time: 0.0971
DEBUG - 2022-10-21 12:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:08:59 --> Total execution time: 0.2303
DEBUG - 2022-10-21 12:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:39:36 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:09:36 --> Total execution time: 0.1117
DEBUG - 2022-10-21 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:00 --> Total execution time: 0.2494
DEBUG - 2022-10-21 12:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:00 --> Total execution time: 0.1867
DEBUG - 2022-10-21 12:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:40:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:02 --> Total execution time: 0.4571
DEBUG - 2022-10-21 12:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:22 --> Total execution time: 0.1521
DEBUG - 2022-10-21 12:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:28 --> Total execution time: 0.2020
DEBUG - 2022-10-21 12:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:42:38 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:12:38 --> Total execution time: 0.1489
DEBUG - 2022-10-21 12:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:15:38 --> Total execution time: 0.1504
DEBUG - 2022-10-21 12:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:46:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:16:08 --> Total execution time: 0.1570
DEBUG - 2022-10-21 12:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:17:25 --> Total execution time: 0.1446
DEBUG - 2022-10-21 12:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:48:39 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:18:39 --> Total execution time: 0.1159
DEBUG - 2022-10-21 12:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:48:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 12:48:57 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-10-21 12:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 12:48:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 12:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 12:48:58 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-10-21 12:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:49:28 --> Total execution time: 0.0941
DEBUG - 2022-10-21 12:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:49:30 --> Total execution time: 0.1700
DEBUG - 2022-10-21 12:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:49:30 --> Total execution time: 0.1471
DEBUG - 2022-10-21 12:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:53:52 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:23:52 --> Total execution time: 0.1145
DEBUG - 2022-10-21 12:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:53:53 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:23:53 --> Total execution time: 0.0911
DEBUG - 2022-10-21 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:54:51 --> Total execution time: 0.0930
DEBUG - 2022-10-21 12:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:54:52 --> Total execution time: 0.1490
DEBUG - 2022-10-21 12:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:54:53 --> Total execution time: 0.1441
DEBUG - 2022-10-21 12:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:55:03 --> No URI present. Default controller set.
DEBUG - 2022-10-21 12:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:25:03 --> Total execution time: 0.1461
DEBUG - 2022-10-21 12:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:25:14 --> Total execution time: 0.1409
DEBUG - 2022-10-21 12:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 12:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:26:09 --> Total execution time: 0.1519
DEBUG - 2022-10-21 12:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 12:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 12:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:26:20 --> Total execution time: 0.1900
DEBUG - 2022-10-21 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:30:02 --> Total execution time: 0.2313
DEBUG - 2022-10-21 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:10:58 --> Total execution time: 0.1955
DEBUG - 2022-10-21 13:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:11:09 --> Total execution time: 0.1748
DEBUG - 2022-10-21 13:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:11:09 --> Total execution time: 0.1548
DEBUG - 2022-10-21 13:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:13:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 13:13:15 --> 404 Page Not Found: Summer-course-starts-from-june/index
DEBUG - 2022-10-21 13:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:13:15 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:43:15 --> Total execution time: 0.1046
DEBUG - 2022-10-21 13:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:14:18 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:44:18 --> Total execution time: 0.1465
DEBUG - 2022-10-21 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:18:05 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:48:05 --> Total execution time: 0.1709
DEBUG - 2022-10-21 13:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:48:11 --> Total execution time: 0.1457
DEBUG - 2022-10-21 13:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:48:49 --> Total execution time: 0.1555
DEBUG - 2022-10-21 13:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:48:58 --> Total execution time: 0.1709
DEBUG - 2022-10-21 13:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:49:00 --> Total execution time: 0.1601
DEBUG - 2022-10-21 13:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:19:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 13:19:01 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-10-21 13:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:49:08 --> Total execution time: 0.1705
DEBUG - 2022-10-21 13:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:49:17 --> Total execution time: 0.1472
DEBUG - 2022-10-21 13:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:49:23 --> Total execution time: 0.1603
DEBUG - 2022-10-21 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:49:28 --> Total execution time: 0.1718
DEBUG - 2022-10-21 13:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 13:19:43 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 13:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:19:45 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:49:45 --> Total execution time: 0.1100
DEBUG - 2022-10-21 13:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 13:20:00 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 13:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:36:28 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:40:04 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:41:03 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:41:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:52:06 --> No URI present. Default controller set.
DEBUG - 2022-10-21 13:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 13:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 13:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 13:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:26:34 --> Total execution time: 0.1393
DEBUG - 2022-10-21 14:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:31:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 14:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:32:57 --> Total execution time: 0.0945
DEBUG - 2022-10-21 14:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:33:00 --> Total execution time: 0.1448
DEBUG - 2022-10-21 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:33:00 --> Total execution time: 0.1457
DEBUG - 2022-10-21 14:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:33:35 --> No URI present. Default controller set.
DEBUG - 2022-10-21 14:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:38:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 14:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 14:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 14:53:44 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 14:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 14:54:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 14:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 14:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:06:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 15:06:39 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 15:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:12:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 15:12:14 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 15:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:13:01 --> No URI present. Default controller set.
DEBUG - 2022-10-21 15:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:23:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 15:23:53 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-10-21 15:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:25:09 --> No URI present. Default controller set.
DEBUG - 2022-10-21 15:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:25:38 --> No URI present. Default controller set.
DEBUG - 2022-10-21 15:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 15:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:27 --> Total execution time: 0.1453
DEBUG - 2022-10-21 15:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:29 --> Total execution time: 0.1573
DEBUG - 2022-10-21 15:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:30 --> Total execution time: 0.1444
DEBUG - 2022-10-21 15:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:39:52 --> No URI present. Default controller set.
DEBUG - 2022-10-21 15:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:52:33 --> No URI present. Default controller set.
DEBUG - 2022-10-21 15:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 15:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 15:53:18 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 15:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 15:58:24 --> No URI present. Default controller set.
DEBUG - 2022-10-21 15:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 15:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:31:28 --> No URI present. Default controller set.
DEBUG - 2022-10-21 16:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:32:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 16:32:18 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 16:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:35:00 --> No URI present. Default controller set.
DEBUG - 2022-10-21 16:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:49:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 16:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:01 --> Total execution time: 0.1544
DEBUG - 2022-10-21 16:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:04 --> Total execution time: 0.1443
DEBUG - 2022-10-21 16:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:04 --> Total execution time: 0.3716
DEBUG - 2022-10-21 16:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:16 --> No URI present. Default controller set.
DEBUG - 2022-10-21 16:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:19 --> No URI present. Default controller set.
DEBUG - 2022-10-21 16:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:24 --> Total execution time: 0.1431
DEBUG - 2022-10-21 16:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 16:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 16:58:09 --> 404 Page Not Found: Summer-course-starts-from-june/index
DEBUG - 2022-10-21 16:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 16:58:09 --> No URI present. Default controller set.
DEBUG - 2022-10-21 16:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 16:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 17:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 17:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 17:20:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 17:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 17:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 18:12:59 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 18:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:31:32 --> No URI present. Default controller set.
DEBUG - 2022-10-21 18:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 18:37:29 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 18:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 18:50:50 --> 404 Page Not Found: Git/config
DEBUG - 2022-10-21 18:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:53:32 --> No URI present. Default controller set.
DEBUG - 2022-10-21 18:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 18:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 18:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 18:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:00:56 --> 404 Page Not Found: _profiler/phpinfo
DEBUG - 2022-10-21 19:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:00:57 --> 404 Page Not Found: Phpinfophp/index
DEBUG - 2022-10-21 19:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:00:57 --> 404 Page Not Found: Phpinfo/index
DEBUG - 2022-10-21 19:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:00:57 --> 404 Page Not Found: Awsyml/index
DEBUG - 2022-10-21 19:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:00:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:00:58 --> 404 Page Not Found: Infophp/index
DEBUG - 2022-10-21 19:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:01:00 --> 404 Page Not Found: Aws/credentials
DEBUG - 2022-10-21 19:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:01:00 --> No URI present. Default controller set.
DEBUG - 2022-10-21 19:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:01:00 --> 404 Page Not Found: Config/aws.yml
DEBUG - 2022-10-21 19:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:01:00 --> No URI present. Default controller set.
DEBUG - 2022-10-21 19:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:01:01 --> 404 Page Not Found: Configjs/index
DEBUG - 2022-10-21 19:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:13:53 --> No URI present. Default controller set.
DEBUG - 2022-10-21 19:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:14:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 19:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:26:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:26:59 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-10-21 19:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 19:33:33 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 19:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:34:34 --> No URI present. Default controller set.
DEBUG - 2022-10-21 19:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:41:30 --> No URI present. Default controller set.
DEBUG - 2022-10-21 19:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:41:56 --> No URI present. Default controller set.
DEBUG - 2022-10-21 19:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:55:47 --> Total execution time: 0.1623
DEBUG - 2022-10-21 19:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:55:57 --> Total execution time: 0.1384
DEBUG - 2022-10-21 19:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:08 --> Total execution time: 0.1399
DEBUG - 2022-10-21 19:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:24 --> Total execution time: 0.1770
DEBUG - 2022-10-21 19:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:56:54 --> Total execution time: 0.1475
DEBUG - 2022-10-21 19:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:01 --> Total execution time: 0.2158
DEBUG - 2022-10-21 19:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:58:11 --> No URI present. Default controller set.
DEBUG - 2022-10-21 19:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 19:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 19:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 19:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:11:56 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:12:43 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:17:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 20:17:12 --> 404 Page Not Found: Teacher/harry-j-bryant
DEBUG - 2022-10-21 20:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 20:18:10 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:21:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 20:21:14 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-10-21 20:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:24:48 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:25:14 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:25:25 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:26:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:26:16 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:27:52 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:27:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:30:48 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:36:45 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 20:38:59 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 20:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:43:14 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:58:05 --> No URI present. Default controller set.
DEBUG - 2022-10-21 20:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 20:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 20:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 20:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:05:55 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:06:50 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:06:59 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:07:03 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:07:41 --> Total execution time: 0.1709
DEBUG - 2022-10-21 21:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:07:43 --> Total execution time: 0.1957
DEBUG - 2022-10-21 21:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:07:44 --> Total execution time: 0.1548
DEBUG - 2022-10-21 21:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:07:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 21:07:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 21:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:08:06 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:08:11 --> Total execution time: 0.1511
DEBUG - 2022-10-21 21:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:08:14 --> Total execution time: 0.1601
DEBUG - 2022-10-21 21:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:08:14 --> Total execution time: 0.3527
DEBUG - 2022-10-21 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:13:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:13:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:14:23 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 21:16:07 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 21:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:16:15 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:16:16 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:16:19 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:01 --> Total execution time: 0.1466
DEBUG - 2022-10-21 21:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:03 --> Total execution time: 0.1589
DEBUG - 2022-10-21 21:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:03 --> Total execution time: 0.1513
DEBUG - 2022-10-21 21:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 21:17:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 21:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:19:35 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:20:22 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:21:07 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:22 --> Total execution time: 0.0995
DEBUG - 2022-10-21 21:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:26 --> Total execution time: 0.1532
DEBUG - 2022-10-21 21:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:26 --> Total execution time: 0.1627
DEBUG - 2022-10-21 21:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 21:35:34 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-10-21 21:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 21:35:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 21:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:35:38 --> Total execution time: 0.1471
DEBUG - 2022-10-21 21:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 21:38:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 21:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:39:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 21:39:32 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 21:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 21:39:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-10-21 21:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:39:45 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:47:23 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:58:44 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:59:10 --> No URI present. Default controller set.
DEBUG - 2022-10-21 21:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 21:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 21:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 21:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:02:26 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:02:27 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-10-21 22:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:02:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:02:27 --> 404 Page Not Found: Media/system
DEBUG - 2022-10-21 22:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:05:11 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:05:42 --> Total execution time: 0.1504
DEBUG - 2022-10-21 22:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:05:47 --> Total execution time: 0.1518
DEBUG - 2022-10-21 22:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:05:47 --> Total execution time: 0.1489
DEBUG - 2022-10-21 22:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:06:16 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:08:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:09:25 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:11:28 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:12:42 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:13:19 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:13:20 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:13:20 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:13:20 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:28 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:47 --> Total execution time: 0.1575
DEBUG - 2022-10-21 22:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:49 --> Total execution time: 0.1752
DEBUG - 2022-10-21 22:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:55 --> Total execution time: 0.1986
DEBUG - 2022-10-21 22:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:18:58 --> Total execution time: 0.1565
DEBUG - 2022-10-21 22:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:07 --> Total execution time: 0.1447
DEBUG - 2022-10-21 22:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:15 --> Total execution time: 0.1459
DEBUG - 2022-10-21 22:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:18 --> Total execution time: 0.1469
DEBUG - 2022-10-21 22:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:20 --> Total execution time: 0.1440
DEBUG - 2022-10-21 22:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:19:25 --> Total execution time: 0.1569
DEBUG - 2022-10-21 22:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:22:44 --> 404 Page Not Found: Makhdamxshellphp/index
DEBUG - 2022-10-21 22:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:22:47 --> 404 Page Not Found: Wp-admin/includes
DEBUG - 2022-10-21 22:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:22:50 --> 404 Page Not Found: Wp-includes/wp-class.php
DEBUG - 2022-10-21 22:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:22:55 --> 404 Page Not Found: Radiophp/index
DEBUG - 2022-10-21 22:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:03 --> 404 Page Not Found: Fwphp/index
DEBUG - 2022-10-21 22:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:09 --> 404 Page Not Found: Fxphp/index
DEBUG - 2022-10-21 22:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:12 --> 404 Page Not Found: Upsphp/index
DEBUG - 2022-10-21 22:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:20 --> 404 Page Not Found: Wikindexphp/index
DEBUG - 2022-10-21 22:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:23 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-10-21 22:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:25 --> 404 Page Not Found: 0php/index
DEBUG - 2022-10-21 22:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:31 --> 404 Page Not Found: 01php/index
DEBUG - 2022-10-21 22:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:34 --> 404 Page Not Found: 0byte/index
DEBUG - 2022-10-21 22:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:41 --> 404 Page Not Found: 0bytephp/index
DEBUG - 2022-10-21 22:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:47 --> 404 Page Not Found: 1php/index
DEBUG - 2022-10-21 22:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:48 --> 404 Page Not Found: 10php/index
DEBUG - 2022-10-21 22:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:23:55 --> 404 Page Not Found: 100php/index
DEBUG - 2022-10-21 22:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:01 --> 404 Page Not Found: 11indexphp/index
DEBUG - 2022-10-21 22:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:03 --> 404 Page Not Found: 13php/index
DEBUG - 2022-10-21 22:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:07 --> 404 Page Not Found: 1337php/index
DEBUG - 2022-10-21 22:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:13 --> 404 Page Not Found: 2php/index
DEBUG - 2022-10-21 22:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:20 --> 404 Page Not Found: 2indexphp/index
DEBUG - 2022-10-21 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:23 --> 404 Page Not Found: 3php/index
DEBUG - 2022-10-21 22:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:25 --> 404 Page Not Found: 4php/index
DEBUG - 2022-10-21 22:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:28 --> 404 Page Not Found: 403php/index
DEBUG - 2022-10-21 22:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:30 --> 404 Page Not Found: 404php/index
DEBUG - 2022-10-21 22:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:33 --> 404 Page Not Found: 5php/index
DEBUG - 2022-10-21 22:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:36 --> 404 Page Not Found: 9php/index
DEBUG - 2022-10-21 22:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:41 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-10-21 22:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:43 --> 404 Page Not Found: FoxWSOphp/index
DEBUG - 2022-10-21 22:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:45 --> 404 Page Not Found: WSOphp/index
DEBUG - 2022-10-21 22:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:49 --> 404 Page Not Found: Aphp/index
DEBUG - 2022-10-21 22:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:56 --> 404 Page Not Found: Aboutphp/index
DEBUG - 2022-10-21 22:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:24:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:24:59 --> 404 Page Not Found: Alfphp/index
DEBUG - 2022-10-21 22:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:02 --> 404 Page Not Found: Alfaphp/index
DEBUG - 2022-10-21 22:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:08 --> 404 Page Not Found: Alfashellphp/index
DEBUG - 2022-10-21 22:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:11 --> 404 Page Not Found: Alwsophp/index
DEBUG - 2022-10-21 22:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:25:20 --> Total execution time: 0.0945
DEBUG - 2022-10-21 22:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:21 --> 404 Page Not Found: Autoload_classmapphp/index
DEBUG - 2022-10-21 22:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:25:22 --> Total execution time: 0.1648
DEBUG - 2022-10-21 22:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:25:23 --> Total execution time: 0.3114
DEBUG - 2022-10-21 22:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:25 --> 404 Page Not Found: Bphp/index
DEBUG - 2022-10-21 22:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:28 --> 404 Page Not Found: Blogphp/index
DEBUG - 2022-10-21 22:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:32 --> 404 Page Not Found: Blog/fw.php
DEBUG - 2022-10-21 22:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:36 --> 404 Page Not Found: Bypassphp/index
DEBUG - 2022-10-21 22:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:45 --> 404 Page Not Found: Cphp/index
DEBUG - 2022-10-21 22:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:25:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:25:56 --> 404 Page Not Found: Contentphp/index
DEBUG - 2022-10-21 22:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:00 --> 404 Page Not Found: Datephp/index
DEBUG - 2022-10-21 22:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:07 --> 404 Page Not Found: Docphp/index
DEBUG - 2022-10-21 22:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:11 --> 404 Page Not Found: Ephp/index
DEBUG - 2022-10-21 22:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:16 --> 404 Page Not Found: Edit-formphp/index
DEBUG - 2022-10-21 22:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:26 --> 404 Page Not Found: Fphp/index
DEBUG - 2022-10-21 22:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:27 --> 404 Page Not Found: Foxphp/index
DEBUG - 2022-10-21 22:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:31 --> 404 Page Not Found: Gphp/index
DEBUG - 2022-10-21 22:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:31 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:39 --> 404 Page Not Found: Goodsphp/index
DEBUG - 2022-10-21 22:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:42 --> 404 Page Not Found: Hphp/index
DEBUG - 2022-10-21 22:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:50 --> 404 Page Not Found: Haxorphp/index
DEBUG - 2022-10-21 22:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:26:54 --> 404 Page Not Found: Hellophp/index
DEBUG - 2022-10-21 22:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:02 --> 404 Page Not Found: Iphp/index
DEBUG - 2022-10-21 22:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:06 --> 404 Page Not Found: Images/about.php
DEBUG - 2022-10-21 22:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:12 --> 404 Page Not Found: Jindexphp/index
DEBUG - 2022-10-21 22:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:21 --> 404 Page Not Found: Kphp/index
DEBUG - 2022-10-21 22:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:24 --> 404 Page Not Found: Lphp/index
DEBUG - 2022-10-21 22:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:30 --> 404 Page Not Found: Licensephp/index
DEBUG - 2022-10-21 22:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:33 --> 404 Page Not Found: Mphp/index
DEBUG - 2022-10-21 22:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:36 --> 404 Page Not Found: Marphp/index
DEBUG - 2022-10-21 22:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:40 --> 404 Page Not Found: Mariphp/index
DEBUG - 2022-10-21 22:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:44 --> 404 Page Not Found: Marijuanaphp/index
DEBUG - 2022-10-21 22:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:50 --> 404 Page Not Found: Miniphp/index
DEBUG - 2022-10-21 22:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:52 --> 404 Page Not Found: Nphp/index
DEBUG - 2022-10-21 22:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:53 --> 404 Page Not Found: Newphp/index
DEBUG - 2022-10-21 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:27:59 --> 404 Page Not Found: Ophp/index
DEBUG - 2022-10-21 22:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:03 --> 404 Page Not Found: Okphp/index
DEBUG - 2022-10-21 22:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:08 --> 404 Page Not Found: Old-indexphp/index
DEBUG - 2022-10-21 22:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:09 --> 404 Page Not Found: Pphp/index
DEBUG - 2022-10-21 22:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:17 --> 404 Page Not Found: Priv8php/index
DEBUG - 2022-10-21 22:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:19 --> 404 Page Not Found: Public/403.php
DEBUG - 2022-10-21 22:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:25 --> 404 Page Not Found: Qphp/index
DEBUG - 2022-10-21 22:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:31 --> 404 Page Not Found: Rphp/index
DEBUG - 2022-10-21 22:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:34 --> 404 Page Not Found: Rootphp/index
DEBUG - 2022-10-21 22:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:40 --> 404 Page Not Found: Rssphp/index
DEBUG - 2022-10-21 22:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:44 --> 404 Page Not Found: Sphp/index
DEBUG - 2022-10-21 22:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:47 --> 404 Page Not Found: Shphp/index
DEBUG - 2022-10-21 22:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:49 --> 404 Page Not Found: Shellphp/index
DEBUG - 2022-10-21 22:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:28:55 --> 404 Page Not Found: Shxphp/index
DEBUG - 2022-10-21 22:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:04 --> 404 Page Not Found: Smallphp/index
DEBUG - 2022-10-21 22:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:07 --> 404 Page Not Found: Templates/beez5
DEBUG - 2022-10-21 22:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:09 --> 404 Page Not Found: Uphp/index
DEBUG - 2022-10-21 22:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:17 --> 404 Page Not Found: Upphp/index
DEBUG - 2022-10-21 22:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:22 --> 404 Page Not Found: Uploaderphp/index
DEBUG - 2022-10-21 22:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:25 --> 404 Page Not Found: Uploads/up.php
DEBUG - 2022-10-21 22:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:30 --> 404 Page Not Found: Vphp/index
DEBUG - 2022-10-21 22:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:38 --> 404 Page Not Found: Vulnphp/index
DEBUG - 2022-10-21 22:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:41 --> 404 Page Not Found: Wphp/index
DEBUG - 2022-10-21 22:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:44 --> 404 Page Not Found: W3llstorephp/index
DEBUG - 2022-10-21 22:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:49 --> 404 Page Not Found: Wp-adminphp/index
DEBUG - 2022-10-21 22:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:52 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-10-21 22:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:54 --> 404 Page Not Found: Wp-admin/fw.php
DEBUG - 2022-10-21 22:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:29:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:29:58 --> 404 Page Not Found: Wp-admin/maint
DEBUG - 2022-10-21 22:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:04 --> 404 Page Not Found: Wp-admin/radio.php
DEBUG - 2022-10-21 22:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:08 --> 404 Page Not Found: Wp-blogphp/index
DEBUG - 2022-10-21 22:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:10 --> 404 Page Not Found: Wp-classphp/index
DEBUG - 2022-10-21 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:13 --> 404 Page Not Found: Wp-content/about.php
DEBUG - 2022-10-21 22:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:14 --> 404 Page Not Found: Wp-content/fw.php
DEBUG - 2022-10-21 22:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:19 --> 404 Page Not Found: Wp-content/wp.php
DEBUG - 2022-10-21 22:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:29 --> 404 Page Not Found: Wp-content/x.php
DEBUG - 2022-10-21 22:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:37 --> 404 Page Not Found: Wp-filephp/index
DEBUG - 2022-10-21 22:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:41 --> 404 Page Not Found: Wp-includes/991176.php
DEBUG - 2022-10-21 22:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:47 --> 404 Page Not Found: Wp-includes/about.php
DEBUG - 2022-10-21 22:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:50 --> 404 Page Not Found: Wp-includes/shell20211028.php
DEBUG - 2022-10-21 22:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:52 --> 404 Page Not Found: Wp-infophp/index
DEBUG - 2022-10-21 22:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:30:54 --> 404 Page Not Found: Wp-uploadsphp/index
DEBUG - 2022-10-21 22:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:00 --> 404 Page Not Found: Wpphp/index
DEBUG - 2022-10-21 22:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:03 --> 404 Page Not Found: Wp2php/index
DEBUG - 2022-10-21 22:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:10 --> 404 Page Not Found: Wp_wrong_datlibphp/index
DEBUG - 2022-10-21 22:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:16 --> 404 Page Not Found: Wsphp/index
DEBUG - 2022-10-21 22:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:19 --> 404 Page Not Found: Wsophp/index
DEBUG - 2022-10-21 22:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:20 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:21 --> 404 Page Not Found: Wso1php/index
DEBUG - 2022-10-21 22:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:23 --> 404 Page Not Found: Wso2php/index
DEBUG - 2022-10-21 22:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:27 --> 404 Page Not Found: Xphp/index
DEBUG - 2022-10-21 22:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:31 --> 404 Page Not Found: Xlphp/index
DEBUG - 2022-10-21 22:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:37 --> 404 Page Not Found: Xleetphp/index
DEBUG - 2022-10-21 22:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:40 --> 404 Page Not Found: Xmlrpcphp/index
DEBUG - 2022-10-21 22:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:43 --> 404 Page Not Found: Xxphp/index
DEBUG - 2022-10-21 22:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:44 --> 404 Page Not Found: Xxxphp/index
DEBUG - 2022-10-21 22:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:51 --> 404 Page Not Found: Yphp/index
DEBUG - 2022-10-21 22:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:31:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:31:57 --> 404 Page Not Found: Zphp/index
DEBUG - 2022-10-21 22:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:35:33 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:39:34 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:40:13 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:40:14 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:41:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:53:40 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:53:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 22:53:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-10-21 22:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:54:02 --> No URI present. Default controller set.
DEBUG - 2022-10-21 22:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 22:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 22:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 22:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:01:41 --> Total execution time: 0.1589
DEBUG - 2022-10-21 23:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:02:38 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 23:04:40 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 23:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:07:20 --> Total execution time: 0.2798
DEBUG - 2022-10-21 23:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:09:16 --> Total execution time: 0.1605
DEBUG - 2022-10-21 23:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:09:59 --> Total execution time: 0.1523
DEBUG - 2022-10-21 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:20 --> Total execution time: 0.1491
DEBUG - 2022-10-21 23:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:32 --> Total execution time: 0.1487
DEBUG - 2022-10-21 23:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:10:48 --> Total execution time: 0.1593
DEBUG - 2022-10-21 23:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:11:59 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:16:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 23:16:28 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-10-21 23:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:19:30 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:19:54 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-21 23:20:58 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-10-21 23:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:43:25 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:43:27 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:48:39 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:48:58 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:53:51 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:55:19 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:55:20 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:58:40 --> No URI present. Default controller set.
DEBUG - 2022-10-21 23:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:59:15 --> Total execution time: 0.1620
DEBUG - 2022-10-21 23:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:59:22 --> Total execution time: 0.2043
DEBUG - 2022-10-21 23:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:59:22 --> Total execution time: 0.3962
DEBUG - 2022-10-21 23:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-10-21 23:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-21 23:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-21 23:59:38 --> Encryption: Auto-configured driver 'openssl'.
